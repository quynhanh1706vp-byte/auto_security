# coding: utf-8
"""
FORCE FULL VSP UI GATEWAY
- Make gunicorn serve the real Flask app (vsp_demo_app.app)
- Avoid any exportpdf-only/preempt wrappers hijacking /api/vsp/*
"""
from vsp_demo_app import app as application  # gunicorn entrypoint
app = application



# === VSP_WSGI_STATUSV2_ALWAYS8_V3 ===
# Post-process /api/vsp/run_status_v2/* JSON at WSGI layer to always expose 8 tool lanes.
import json

def _vsp_build_tools_always8_v3(out: dict) -> dict:
    CANON = ["SEMGREP","GITLEAKS","TRIVY","CODEQL","KICS","GRYPE","SYFT","BANDIT"]
    ZERO = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0}

    def norm_counts(c):
        d = dict(ZERO)
        if isinstance(c, dict):
            for k,v in c.items():
                kk = str(k).upper()
                if kk in d:
                    try: d[kk] = int(v)
                    except Exception: d[kk] = 0
        return d

    def mk(tool, has_key=None, total_key=None, verdict_key=None, counts_key=None, reason_missing="missing_fields"):
        hasv = out.get(has_key) if has_key else None
        try: hasv = bool(hasv) if has_key else None
        except Exception: hasv = None

        total = out.get(total_key, 0) if total_key else 0
        verdict = out.get(verdict_key) if verdict_key else None
        counts = norm_counts(out.get(counts_key, {})) if counts_key else dict(ZERO)

        if has_key and hasv is False:
            return {"tool":tool,"status":"NOT_RUN","verdict":"NOT_RUN","total":0,"counts":dict(ZERO),"reason":"has_flag_false"}

        if verdict is None and (not total) and counts == ZERO:
            return {"tool":tool,"status":"NOT_RUN","verdict":"NOT_RUN","total":0,"counts":dict(ZERO),"reason":reason_missing}

        vv = str(verdict).upper() if verdict is not None else "OK"
        try: total_i = int(total)
        except Exception: total_i = 0
        return {"tool":tool,"status":vv,"verdict":vv,"total":total_i,"counts":counts}

    tools = {}
    # your current flat keys in status_v2 response
    tools["CODEQL"]   = mk("CODEQL",   "has_codeql",   "codeql_total",   "codeql_verdict",   None)
    tools["GITLEAKS"] = mk("GITLEAKS", "has_gitleaks", "gitleaks_total", "gitleaks_verdict", "gitleaks_counts")
    tools["SEMGREP"]  = mk("SEMGREP",  "has_semgrep",  "semgrep_total",  "semgrep_verdict",  "semgrep_counts")
    tools["TRIVY"]    = mk("TRIVY",    "has_trivy",    "trivy_total",    "trivy_verdict",    "trivy_counts")

    # no converters yet -> NOT_RUN but lane must exist
    for t in ["KICS","GRYPE","SYFT","BANDIT"]:
        tools[t] = {"tool":t,"status":"NOT_RUN","verdict":"NOT_RUN","total":0,"counts":dict(ZERO),"reason":"no_converter_yet"}

    out["tools"] = tools
    out["tools_order"] = CANON

    gs = out.get("run_gate_summary")
    if not isinstance(gs, dict):
        gs = {}
    for t in CANON:
        if t not in gs:
            gs[t] = {"tool":t,"verdict": tools[t].get("verdict","NOT_RUN"), "total": tools[t].get("total",0)}
    out["run_gate_summary"] = gs
    return out

def _vsp_wrap_statusv2_always8_v3(app):
    def _app(environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if not path.startswith("/api/vsp/run_status_v2/"):
            return app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = headers
            captured["exc"] = exc_info
            return lambda x: None

        res_iter = app(environ, _sr)
        try:
            body = b"".join(res_iter or [])
        finally:
            try:
                close = getattr(res_iter, "close", None)
                if callable(close): close()
            except Exception:
                pass

        headers = captured["headers"] or []
        ctype = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ctype = str(v)
                break

        if "application/json" not in ctype.lower():
            start_response(captured["status"] or "200 OK", headers, captured["exc"])
            return [body]

        try:
            out = json.loads((body.decode("utf-8", errors="ignore") or "{}"))
            if isinstance(out, dict) and (out.get("tools") is None):
                out = _vsp_build_tools_always8_v3(out)
                new_body = json.dumps(out, ensure_ascii=False).encode("utf-8")

                new_headers = []
                for k,v in headers:
                    if str(k).lower() == "content-length":
                        continue
                    new_headers.append((k,v))
                new_headers.append(("Content-Length", str(len(new_body))))

                start_response(captured["status"] or "200 OK", new_headers, captured["exc"])
                return [new_body]
        except Exception:
            pass

        start_response(captured["status"] or "200 OK", headers, captured["exc"])
        return [body]
    return _app

# Wrap if 'application' exists (gunicorn uses wsgi_vsp_ui_gateway:application)
try:
    application = _vsp_wrap_statusv2_always8_v3(application)
except Exception:
    pass



# === VSP_RULE_OVERRIDES_FORCE_BIND_V1 BEGIN ===
import json as _json
from pathlib import Path as _Path
from datetime import datetime as _dt, timezone as _tz
import os as _os
import tempfile as _tempfile

_VSP_RULE_OVR_PATH = _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/vsp_rule_overrides_v1.json")

def _vsp_rule_ovr_default_v1():
    return {"meta":{"version":"v1","updated_at":None},"overrides":[]}

def _vsp_rule_ovr_atomic_write_v1(path:_Path, obj:dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = _tempfile.mkstemp(prefix=path.name+".", dir=str(path.parent))
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as f:
            _json.dump(obj, f, ensure_ascii=False, indent=2)
        _os.replace(tmp, str(path))
    finally:
        try:
            _os.unlink(tmp)
        except Exception:
            pass

class VSPRuleOverridesForceBindV1:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/rule_overrides_v1"):
            return self.app(environ, start_response)

        method = (environ.get("REQUEST_METHOD") or "GET").upper()
        try:
            if method == "GET":
                if _VSP_RULE_OVR_PATH.exists():
                    try:
                        data = _json.load(open(_VSP_RULE_OVR_PATH, "r", encoding="utf-8"))
                    except Exception:
                        data = _vsp_rule_ovr_default_v1()
                else:
                    data = _vsp_rule_ovr_default_v1()

                body = _json.dumps(data, ensure_ascii=False).encode("utf-8")
                hdrs = [
                    ("Content-Type","application/json; charset=utf-8"),
                    ("Content-Length", str(len(body))),
                    ("Cache-Control","no-cache"),
                    ("X-VSP-RULE-OVERRIDES-MODE","FORCE_BIND_V1"),
                ]
                start_response("200 OK", hdrs)
                return [body]

            if method == "POST":
                try:
                    n = int(environ.get("CONTENT_LENGTH") or "0")
                except Exception:
                    n = 0
                raw = environ["wsgi.input"].read(n) if n > 0 else b"{}"
                obj = _json.loads(raw.decode("utf-8", errors="replace") or "{}")
                if not isinstance(obj, dict):
                    obj = _vsp_rule_ovr_default_v1()
                obj.setdefault("meta", {})
                obj["meta"]["updated_at"] = _dt.now(_tz.utc).isoformat()
                _vsp_rule_ovr_atomic_write_v1(_VSP_RULE_OVR_PATH, obj)

                out = {"ok": True, "file": str(_VSP_RULE_OVR_PATH), "mode":"FORCE_BIND_V1"}
                body = _json.dumps(out, ensure_ascii=False).encode("utf-8")
                hdrs = [
                    ("Content-Type","application/json; charset=utf-8"),
                    ("Content-Length", str(len(body))),
                    ("Cache-Control","no-cache"),
                    ("X-VSP-RULE-OVERRIDES-MODE","FORCE_BIND_V1"),
                ]
                start_response("200 OK", hdrs)
                return [body]

            body = b'{"ok":false,"error":"METHOD_NOT_ALLOWED"}'
            start_response("405 Method Not Allowed", [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
            ])
            return [body]
        except Exception as e:
            body = _json.dumps({"ok":False,"error":"RULE_OVERRIDES_FORCE_BIND_ERR","detail":str(e)}, ensure_ascii=False).encode("utf-8")
            start_response("500 Internal Server Error", [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
                ("X-VSP-RULE-OVERRIDES-MODE","FORCE_BIND_V1"),
            ])
            return [body]
# === VSP_RULE_OVERRIDES_FORCE_BIND_V1 END ===


# VSP_RULE_OVERRIDES_FORCE_BIND_V1 WRAP
application = VSPRuleOverridesForceBindV1(application)


# === VSP_RUN_STATUS_V2_GUARD_V1 BEGIN ===
import json as _json
from datetime import datetime as _dt, timezone as _tz
import traceback as _tb

class VSPRunStatusV2GuardV1:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/run_status_v2/"):
            return self.app(environ, start_response)

        # normalize rid in PATH_INFO
        try:
            rid = path.split("/api/vsp/run_status_v2/", 1)[1]
        except Exception:
            rid = ""
        rid = (rid or "").strip()
        rid_norm = rid[4:] if rid.startswith("RUN_") else rid

        # rewrite path if needed
        if rid_norm != rid:
            environ = dict(environ)
            environ["PATH_INFO"] = "/api/vsp/run_status_v2/" + rid_norm

        try:
            return self.app(environ, start_response)
        except Exception as e:
            payload = {
                "ok": False,
                "status": "ERROR",
                "final": True,
                "http_code": 500,
                "error": "RUN_STATUS_V2_EXCEPTION_GUARDED",
                "rid": rid,
                "rid_norm": rid_norm,
                "detail": str(e),
                "ts_utc": _dt.now(_tz.utc).isoformat(),
            }
            body = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
            hdrs = [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
                ("Cache-Control","no-cache"),
                ("X-VSP-RUNSTATUSV2-MODE","GUARD_V1"),
            ]
            start_response("200 OK", hdrs)
            return [body]
# === VSP_RUN_STATUS_V2_GUARD_V1 END ===


# VSP_RUN_STATUS_V2_GUARD_V1 WRAP
application = VSPRunStatusV2GuardV1(application)


# === VSP_WSGI_STATUS_CONTRACT_MW_P1_V1_BEGIN ===
import os, json, re
from pathlib import Path

def _vsp_read_json(fp):
    try:
        with open(fp, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _vsp_findings_total(run_dir: str):
    if not run_dir:
        return None
    for fn in ("findings_unified.json","reports/findings_unified.json","findings_unified.sarif","findings_unified.sarif.json"):
        fp=os.path.join(run_dir, fn)
        if os.path.isfile(fp):
            j=_vsp_read_json(fp)
            if isinstance(j, dict):
                if isinstance(j.get("total"), int):
                    return j["total"]
                items=j.get("items")
                if isinstance(items, list):
                    return len(items)
    fp=os.path.join(run_dir,"summary_unified.json")
    j=_vsp_read_json(fp) if os.path.isfile(fp) else None
    if isinstance(j, dict):
        t=j.get("total") or j.get("total_findings")
        if isinstance(t, int):
            return t
    return None

def _vsp_degraded_info(run_dir: str):
    if not run_dir:
        return (None, None)
    # prefer runner.log
    cand = os.path.join(run_dir,"runner.log")
    if not os.path.isfile(cand):
        # fallbacks
        for alt in ("kics/kics.log","codeql/codeql.log","trivy/trivy.log"):
            ap=os.path.join(run_dir,alt)
            if os.path.isfile(ap):
                cand=ap; break
        else:
            return (None, None)
    try:
        txt=Path(cand).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return (None, None)

    tools = ["BANDIT","SEMGREP","GITLEAKS","KICS","TRIVY","SYFT","GRYPE","CODEQL"]
    degraded=set()
    for t in tools:
        pats = [
            fr"VSP_{t}_TIMEOUT_DEGRADE",
            fr"\[{t}\].*DEGRADED",
            fr"{t}.*timeout.*degrad",
            fr"{t}.*missing.*degrad",
        ]
        for pat in pats:
            if re.search(pat, txt, flags=re.I):
                degraded.add(t)
                break
    n=len(degraded)
    return (n, n>0)

class VSPStatusContractMWP1V1:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if not path.startswith("/api/vsp/run_status_v2/"):
            return self.app(environ, start_response)

        captured = {"status":"200 OK","headers":[],"exc":None}

        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = headers or []
            captured["exc"] = exc_info
            # delay calling start_response

        it = self.app(environ, _sr)
        try:
            body = b"".join(it)
        finally:
            try:
                it.close()
            except Exception:
                pass

        headers = captured["headers"]
        ctype = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ctype = str(v)
                break

        # only postprocess JSON
        if "application/json" not in ctype.lower():
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        try:
            obj = json.loads(body.decode("utf-8","ignore"))
        except Exception:
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        if not isinstance(obj, dict):
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        rid = path.rsplit("/",1)[-1]
        obj["run_id"] = obj.get("run_id") or rid

        run_dir = obj.get("ci_run_dir") or obj.get("ci")
        if run_dir and os.path.isdir(run_dir):
            t = _vsp_findings_total(run_dir)
            if isinstance(t, int):
                obj["total_findings"] = t
                obj["has_findings"] = True if t > 0 else False

            dn, da = _vsp_degraded_info(run_dir)
            if isinstance(dn, int):
                obj["degraded_n"] = dn
            if isinstance(da, bool):
                obj["degraded_any"] = da

        obj.setdefault("ok", True)

        out = json.dumps(obj, ensure_ascii=False).encode("utf-8")

        # fix content-length
        new_headers=[]
        for k,v in headers:
            if str(k).lower() == "content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(out))))

        start_response(captured["status"], new_headers, captured["exc"])
        return [out]

# wrap if possible
try:
    application = VSPStatusContractMWP1V1(application)
except Exception:
    pass
# === VSP_WSGI_STATUS_CONTRACT_MW_P1_V1_END ===


# === VSP_WSGI_RUNS_INDEX_ENRICH_MW_P1_V1_BEGIN ===
import json
import urllib.parse

class VSPRunsIndexEnrichMWP1V1:
    """
    Post-process /api/vsp/runs_index_v3_fs_resolved JSON items by attaching:
      total_findings, has_findings, degraded_n, degraded_any
    derived deterministically from ci_run_dir (no heuristics).
    """
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if path != "/api/vsp/runs_index_v3_fs_resolved":
            return self.app(environ, start_response)

        captured = {"status":"200 OK","headers":[],"exc":None}
        def _sr(status, headers, exc_info=None):
            captured["status"]=status
            captured["headers"]=headers or []
            captured["exc"]=exc_info

        it = self.app(environ, _sr)
        try:
            body = b"".join(it)
        finally:
            try: it.close()
            except Exception: pass

        headers = captured["headers"]
        ctype=""
        for k,v in headers:
            if str(k).lower()=="content-type":
                ctype=str(v); break
        if "application/json" not in ctype.lower():
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        try:
            obj=json.loads(body.decode("utf-8","ignore"))
        except Exception:
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        if not isinstance(obj, dict):
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        items = obj.get("items")
        if not isinstance(items, list):
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        # cap enrich to avoid heavy IO if someone requests huge limit
        qs = environ.get("QUERY_STRING","") or ""
        q = urllib.parse.parse_qs(qs)
        try:
            limit = int((q.get("limit") or ["50"])[0])
        except Exception:
            limit = 50
        hard_cap = 120
        n = min(len(items), min(limit, hard_cap))

        for i in range(n):
            it0 = items[i]
            if not isinstance(it0, dict):
                continue
            run_dir = it0.get("ci_run_dir") or it0.get("ci") or None
            if not run_dir:
                continue
            try:
                # reuse helpers from status MW (already injected earlier)
                t = _vsp_findings_total(run_dir)
                if isinstance(t, int):
                    it0["total_findings"] = t
                    it0["has_findings"] = True if t>0 else False
                dn, da = _vsp_degraded_info(run_dir)
                if isinstance(dn, int):
                    it0["degraded_n"] = dn
                if isinstance(da, bool):
                    it0["degraded_any"] = da
            except Exception:
                pass

        out=json.dumps(obj, ensure_ascii=False).encode("utf-8")

        new_headers=[]
        for k,v in headers:
            if str(k).lower()=="content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(out))))

        start_response(captured["status"], new_headers, captured["exc"])
        return [out]

try:
    application = VSPRunsIndexEnrichMWP1V1(application)
except Exception:
    pass
# === VSP_WSGI_RUNS_INDEX_ENRICH_MW_P1_V1_END ===


# === VSP_WSGI_FINDINGS_UNIFIED_API_P1_V1 (commercial) ===
# Ensure /api/vsp/findings_unified_v1/<rid> is registered on the ACTUAL gunicorn "application"
import os, json, glob
from flask import request, jsonify

VSP_UIREQ_DIR = os.environ.get("VSP_UIREQ_DIR", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")
VSP_CI_OUT_GLOB = os.environ.get("VSP_CI_OUT_GLOB", "/home/test/Data/**/out_ci/VSP_CI_*")

_SEV_W = {"CRITICAL": 50, "HIGH": 40, "MEDIUM": 30, "LOW": 20, "INFO": 10, "TRACE": 0}
def _sev_w(x): return _SEV_W.get((x or "").upper(), -1)

def _read_json(path):
  try:
    with open(path, "r", encoding="utf-8") as f:
      return json.load(f)
  except Exception:
    return None

def _resolve_run_dir_from_rid(rid: str):
  st = _read_json(os.path.join(VSP_UIREQ_DIR, f"{rid}.json")) or {}
  for k in ("ci_run_dir","ci_run_dir_resolved","run_dir","RUN_DIR"):
    v = st.get(k)
    if isinstance(v,str) and v.strip():
      return v.strip(), "uireq_state"
  cands=[]
  for d in glob.glob(VSP_CI_OUT_GLOB, recursive=True):
    if rid in (os.path.basename(d) or "") or rid in d:
      cands.append(d)
  cands = sorted(set(cands), key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)
  if cands: return cands[0], "scan_out_ci"
  return None, "not_found"

def _apply_filters(items, q=None, sev=None, tool=None, cwe=None, fileq=None):
  q=(q or "").strip().lower(); fileq=(fileq or "").strip().lower()
  sev=(sev or "").strip().upper(); tool=(tool or "").strip().lower(); cwe=(cwe or "").strip().upper()
  out=[]
  for it in items or []:
    t=(it.get("title") or "")
    f=(it.get("file") or "")
    sv=(it.get("severity") or "").upper()
    tl=(it.get("tool") or "").lower()
    cw=it.get("cwe")
    c=""
    if isinstance(cw,list) and cw: c=str(cw[0] or "").upper()
    elif isinstance(cw,str): c=cw.upper()
    if sev and sv!=sev: continue
    if tool and tool!=tl: continue
    if cwe and cwe!=c: continue
    if fileq and fileq not in f.lower(): continue
    if q:
      hay=(t+" "+f+" "+(it.get("id") or "")).lower()
      if q not in hay: continue
    out.append(it)
  return out

# avoid double-register if hot reload
try:
  _has = any(getattr(r, "rule", "")=="/api/vsp/findings_unified_v1/<rid>" for r in app.url_map.iter_rules())
except Exception:
  _has = False

if not _has:
  @app.route("/api/vsp/findings_unified_v1/<rid>", methods=["GET"])
  def api_vsp_findings_unified_v1(rid):
    page=int(request.args.get("page","1") or "1")
    limit=int(request.args.get("limit","50") or "50")
    page=1 if page<1 else page
    limit=50 if limit<1 else (500 if limit>500 else limit)

    q=request.args.get("q"); sev=request.args.get("sev"); tool=request.args.get("tool")
    cwe=request.args.get("cwe"); fileq=request.args.get("file")

    run_dir, src = _resolve_run_dir_from_rid(rid)
    if not run_dir:
      return jsonify({"ok":False,"warning":"run_dir_not_found","rid":rid,"resolve_source":src,"total":0,"items":[]}), 200

    fp=os.path.join(run_dir,"findings_unified.json")
    data=_read_json(fp)
    if not data or not isinstance(data,dict):
      return jsonify({"ok":True,"warning":"findings_unified_not_found_or_bad","rid":rid,"resolve_source":src,"run_dir":run_dir,"file":fp,"total":0,"items":[]}), 200

    items=data.get("items") or []
    items=_apply_filters(items,q=q,sev=sev,tool=tool,cwe=cwe,fileq=fileq)


    # === VSP_CWE_SAFE_GRYE_V2 ===
    # Fill item.cwe from item.raw.vulnerability.cwes[*].cwe (GRYPE)
    try:
      for _it in (items or []):
        if _it.get("cwe"):
          continue
        if str(_it.get("tool") or "").upper() != "GRYPE":
          continue
        _raw = _it.get("raw") or {}
        _vuln = _raw.get("vulnerability") or {}
        _cwes = _vuln.get("cwes") or []
        _out = []
        for _c in _cwes:
          _v = _c.get("cwe") if isinstance(_c, dict) else _c
          if not _v:
            continue
          _v = str(_v).strip()
          if not _v:
            continue
          if (not _v.upper().startswith("CWE-")) and _v.isdigit():
            _v = "CWE-" + _v
          _out.append(_v.upper())
        if _out:
          _it["cwe"] = list(dict.fromkeys(_out))
    except Exception:
      pass
    # === /VSP_CWE_SAFE_GRYE_V2 ===

    # === VSP_CWE_ENRICH_FROM_ITEM_RAW_V1 ===
    # Fill item.cwe from item.raw.vulnerability.cwes[*].cwe (GRYPE proven has this)
    try:
      for _it in items or []:
        if _it.get("cwe"):
          continue
        _raw = _it.get("raw") or {}
        _vuln = _raw.get("vulnerability") or {}
        _cwes = _vuln.get("cwes") or []
        _out = []
        for _c in _cwes:
          _v = _c.get("cwe") if isinstance(_c, dict) else _c
          if not _v:
            continue
          _v = str(_v).strip()
          if not _v:
            continue
          if (not _v.upper().startswith("CWE-")) and _v.isdigit():
            _v = "CWE-" + _v
          _out.append(_v.upper())
        if _out:
          _it["cwe"] = list(dict.fromkeys(_out))
    except Exception:
      pass
    # === /VSP_CWE_ENRICH_FROM_ITEM_RAW_V1 ===

    # enrich CWE from GRYPE raw file (safe; unified items may not carry raw)
    grype_map = _build_grype_cwe_map(run_dir)
    if grype_map:
      try:
        items = [_maybe_set_cwe_from_grype(dict(it), grype_map) for it in items]
      except Exception:
        pass
    items.sort(key=lambda it: (-_sev_w(it.get("severity")), (it.get("tool") or ""), (it.get("file") or ""), int(it.get("line") or 0)))
    total=len(items)
    start=(page-1)*limit; end=start+limit
    page_items=items[start:end]

    by_sev={}; by_tool={}; by_cwe={}
    for it in items:
      sv=(it.get("severity") or "UNKNOWN").upper()
      tl=(it.get("tool") or "UNKNOWN")
      cws = _vsp_extract_cwe_list(it)
      if cws and not it.get('cwe'):
        it['cwe'] = cws
      c = (str(cws[0]).upper() if cws else 'UNKNOWN')
      by_sev[sv]=by_sev.get(sv,0)+1
      by_tool[tl]=by_tool.get(tl,0)+1
      by_cwe[c]=by_cwe.get(c,0)+1
    unknown_count = by_cwe.get("UNKNOWN", 0)
    top_cwe = sorted([(k,v) for (k,v) in by_cwe.items() if k!="UNKNOWN"], key=lambda kv: kv[1], reverse=True)[:10]

    return jsonify({
      "ok":True,"rid":rid,"run_dir":run_dir,"resolve_source":src,"file":fp,
      "page":page,"limit":limit,"total":total,
      "counts":{"by_sev":by_sev,"by_tool":by_tool,"top_cwe":top_cwe},
      "items":page_items,
      "filters":{"q":q,"sev":sev,"tool":tool,"cwe":cwe,"file":fileq},
    }), 200
# === /VSP_WSGI_FINDINGS_UNIFIED_API_P1_V1 ===


# --- VSP_CWE_ENRICH_FROM_GRYPE_P1_V2 ---
import re as _re

_CVE_RE = _re.compile(r'(CVE-\d{4}-\d+)', _re.I)

def _build_grype_cwe_map(run_dir):
  """Return {CVE-xxxx-yyy: [CWE-79, ...]} from run_dir/grype/grype.json if exists."""
  try:
    fp = os.path.join(run_dir, "grype", "grype.json")
    j = _read_json(fp)
    if not j or not isinstance(j, dict):
      return {}
    out = {}
    for m in (j.get("matches") or []):
      vuln = (m.get("vulnerability") or {})
      vid = (vuln.get("id") or "").strip()
      if not vid:
        continue
      cwes = []
      for c in (vuln.get("cwes") or []):
        cwe = (c.get("cwe") or "").strip()
        if cwe:
          if not cwe.upper().startswith("CWE-") and cwe.isdigit():
            cwe = "CWE-" + cwe
          cwes.append(cwe)
      if cwes:
        out[vid.upper()] = list(dict.fromkeys(cwes))
    return out
  except Exception:
    return {}

def _maybe_set_cwe_from_grype(it, grype_map):
  if it.get("cwe"):
    return it
  tool = (it.get("tool") or "").upper()
  if tool != "GRYPE":
    return it
  cand = (it.get("id") or "").strip()
  if not cand:
    # try parse CVE from title
    t = (it.get("title") or "")
    m = _CVE_RE.search(t or "")
    cand = m.group(1) if m else ""
  cand = (cand or "").upper()
  if cand and cand in grype_map:
    it["cwe"] = grype_map[cand]
  return it
# --- /VSP_CWE_ENRICH_FROM_GRYPE_P1_V2 ---


# --- VSP_CWE_FROM_RAW_ITEMS_P1_V3 ---
def _vsp_norm_cwe(x):
  try:
    x = str(x or "").strip()
    if not x:
      return None
    u = x.upper()
    if u.startswith("CWE-"):
      return u
    if x.isdigit():
      return "CWE-" + x
    return u
  except Exception:
    return None

def _vsp_extract_cwe_list(it):
  """Best-effort CWE extraction from unified item or item.raw.
  Works for GRYPE (raw.vulnerability.cwes) and some SARIF/CodeQL shapes.
  """
  try:
    # 1) already normalized in item.cwe
    cw = it.get("cwe")
    if isinstance(cw, list) and cw:
      out=[]
      for v in cw:
        nv=_vsp_norm_cwe(v)
        if nv: out.append(nv)
      if out: return list(dict.fromkeys(out))
    if isinstance(cw, str) and cw.strip():
      nv=_vsp_norm_cwe(cw)
      return [nv] if nv else None

    raw = it.get("raw") or {}

    # 2) GRYPE: raw.vulnerability.cwes[*].cwe
    vuln = raw.get("vulnerability") or {}
    cwes = vuln.get("cwes") or []
    out=[]
    for c in cwes:
      if isinstance(c, dict):
        nv=_vsp_norm_cwe(c.get("cwe"))
      else:
        nv=_vsp_norm_cwe(c)
      if nv: out.append(nv)
    if out: return list(dict.fromkeys(out))

    # 3) relatedVulnerabilities[*].cwes[*].cwe (some feeds)
    rv = raw.get("relatedVulnerabilities") or []
    out=[]
    for v in rv:
      for c in (v.get("cwes") or []):
        nv=_vsp_norm_cwe((c.get("cwe") if isinstance(c, dict) else c))
        if nv: out.append(nv)
    if out: return list(dict.fromkeys(out))

    # 4) SARIF-ish: raw.rule.properties.cwe or raw.properties.cwe
    for path in [
      ("rule","properties","cwe"),
      ("properties","cwe"),
      ("rule","cwe"),
      ("cwe",),
    ]:
      cur = raw
      ok=True
      for k in path:
        if isinstance(cur, dict) and k in cur:
          cur = cur[k]
        else:
          ok=False; break
      if ok and cur:
        if isinstance(cur, list) and cur:
          nv=_vsp_norm_cwe(cur[0])
          return [nv] if nv else None
        nv=_vsp_norm_cwe(cur)
        return [nv] if nv else None
  except Exception:
    pass
  return None
# --- /VSP_CWE_FROM_RAW_ITEMS_P1_V3 ---


# === VSP_FINDINGS_UNIFIED_V2_ENRICHED_V1 ===
# New endpoint (non-invasive): /api/vsp/findings_unified_v2/<rid>
# Goal: commercial-safe enrichment (CWE from item.raw) + stable counts/top_cwe.
import os, json, glob
from flask import request, jsonify

VSP_UIREQ_DIR = os.environ.get("VSP_UIREQ_DIR", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")
VSP_CI_OUT_GLOB = os.environ.get("VSP_CI_OUT_GLOB", "/home/test/Data/**/out_ci/VSP_CI_*")

_SEV_W = {"CRITICAL": 50, "HIGH": 40, "MEDIUM": 30, "LOW": 20, "INFO": 10, "TRACE": 0}
def _sev_w(x): return _SEV_W.get((x or "").upper(), -1)

def _read_json(path):
  try:
    with open(path, "r", encoding="utf-8") as f:
      return json.load(f)
  except Exception:
    return None

def _resolve_run_dir_from_rid(rid: str):
  st = _read_json(os.path.join(VSP_UIREQ_DIR, f"{rid}.json")) or {}
  for k in ("ci_run_dir","ci_run_dir_resolved","run_dir","RUN_DIR"):
    v = st.get(k)
    if isinstance(v, str) and v.strip():
      return v.strip(), "uireq_state"
  cands=[]
  for d in glob.glob(VSP_CI_OUT_GLOB, recursive=True):
    if rid in (os.path.basename(d) or "") or rid in d:
      cands.append(d)
  cands = sorted(set(cands), key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)
  if cands:
    return cands[0], "scan_out_ci"
  return None, "not_found"

def _norm_cwe(v):
  try:
    v = str(v or "").strip()
    if not v: return None
    u = v.upper()
    if u.startswith("CWE-"): return u
    if v.isdigit(): return "CWE-" + v
    return u
  except Exception:
    return None

def _extract_cwe_list(it):
  # Prefer item.cwe
  cw = it.get("cwe")
  out=[]
  if isinstance(cw, list):
    for x in cw:
      nx = _norm_cwe(x)
      if nx: out.append(nx)
  elif isinstance(cw, str):
    nx=_norm_cwe(cw)
    if nx: out.append(nx)
  if out:
    return list(dict.fromkeys(out))

  # Fallback: item.raw.* (GRYPE proven here)
  raw = it.get("raw") or {}
  vuln = (raw.get("vulnerability") or {})
  cwes = vuln.get("cwes") or []
  out=[]
  for c in cwes:
    v = c.get("cwe") if isinstance(c, dict) else c
    nx=_norm_cwe(v)
    if nx: out.append(nx)
  if out:
    return list(dict.fromkeys(out))

  rv = raw.get("relatedVulnerabilities") or []
  out=[]
  for vv in rv:
    for c in (vv.get("cwes") or []):
      v = c.get("cwe") if isinstance(c, dict) else c
      nx=_norm_cwe(v)
      if nx: out.append(nx)
  if out:
    return list(dict.fromkeys(out))

  # SARIF-ish (best-effort)
  for path in [
    ("rule","properties","cwe"),
    ("properties","cwe"),
    ("rule","cwe"),
    ("cwe",),
  ]:
    cur = raw
    ok=True
    for k in path:
      if isinstance(cur, dict) and k in cur:
        cur = cur[k]
      else:
        ok=False; break
    if ok and cur:
      if isinstance(cur, list) and cur:
        nx=_norm_cwe(cur[0])
        return [nx] if nx else None
      nx=_norm_cwe(cur)
      return [nx] if nx else None

  return None

def _apply_filters(items, q=None, sev=None, tool=None, cwe=None, fileq=None):
  q=(q or "").strip().lower()
  fileq=(fileq or "").strip().lower()
  sev=(sev or "").strip().upper()
  tool=(tool or "").strip().lower()
  cwe=(cwe or "").strip().upper()
  out=[]
  for it in items or []:
    t=(it.get("title") or "")
    f=(it.get("file") or "")
    sv=(it.get("severity") or "").upper()
    tl=(it.get("tool") or "").lower()
    cws = _extract_cwe_list(it) or []
    c0 = (str(cws[0]).upper() if cws else "UNKNOWN")

    if sev and sv != sev: 
      continue
    if tool and tool != tl:
      continue
    if cwe and cwe != c0:
      continue
    if fileq and fileq not in f.lower():
      continue
    if q:
      hay=(t+" "+f+" "+(it.get("id") or "")).lower()
      if q not in hay:
        continue

    # ensure item.cwe filled for UI
    if cws and not it.get("cwe"):
      it["cwe"] = cws
    out.append(it)
  return out

@app.route("/api/vsp/findings_unified_v2/<rid>", methods=["GET"])
def api_vsp_findings_unified_v2(rid):
  page = int(request.args.get("page","1") or "1")
  limit = int(request.args.get("limit","50") or "50")
  page = 1 if page < 1 else page
  limit = 50 if limit < 1 else (500 if limit > 500 else limit)

  q = request.args.get("q")
  sev = request.args.get("sev")
  tool = request.args.get("tool")
  cwe = request.args.get("cwe")
  fileq = request.args.get("file")

  run_dir, src = _resolve_run_dir_from_rid(rid)
  if not run_dir:
    return jsonify({
      "ok": False,
      "warning": "run_dir_not_found",
      "rid": rid,
      "resolve_source": src,
      "total": 0,
      "items": [],
    }), 200

  fp = os.path.join(run_dir, "findings_unified.json")
  data = _read_json(fp)
  if not data or not isinstance(data, dict):
    return jsonify({
      "ok": True,
      "warning": "findings_unified_not_found_or_bad",
      "rid": rid,
      "resolve_source": src,
      "run_dir": run_dir,
      "file": fp,
      "total": 0,
      "items": [],
    }), 200

  items = data.get("items") or []
  items = _apply_filters(items, q=q, sev=sev, tool=tool, cwe=cwe, fileq=fileq)

  items.sort(key=lambda it: (-_sev_w(it.get("severity")), (it.get("tool") or ""), (it.get("file") or ""), int(it.get("line") or 0)))
  total = len(items)
  start = (page-1)*limit
  end = start + limit
  page_items = items[start:end]

  by_sev={}; by_tool={}; by_cwe={}
  for it in items:
    sv=(it.get("severity") or "UNKNOWN").upper()
    tl=(it.get("tool") or "UNKNOWN")
    cws = _extract_cwe_list(it) or []
    c0 = (str(cws[0]).upper() if cws else "UNKNOWN")
    by_sev[sv]=by_sev.get(sv,0)+1
    by_tool[tl]=by_tool.get(tl,0)+1
    by_cwe[c0]=by_cwe.get(c0,0)+1

  unknown_count = by_cwe.get("UNKNOWN", 0)
  top_cwe = sorted([(k,v) for (k,v) in by_cwe.items() if k!="UNKNOWN"], key=lambda kv: kv[1], reverse=True)[:10]

  return jsonify({
    "ok": True,
    "rid": rid,
    "run_dir": run_dir,
    "resolve_source": src,
    "file": fp,
    "page": page,
    "limit": limit,
    "total": total,
    "counts": {
      "by_sev": by_sev,
      "by_tool": by_tool,
      "top_cwe": top_cwe,
      "unknown_count": unknown_count
    },
    "items": page_items,
    "filters": {"q": q, "sev": sev, "tool": tool, "cwe": cwe, "file": fileq},
    "debug": ({"marker":"VSP_FINDINGS_UNIFIED_V2_ENRICHED_V1","flask_var":"app"} if request.args.get("debug")=="1" else None)
  }), 200
# === /VSP_FINDINGS_UNIFIED_V2_ENRICHED_V1 ===


# === VSP_DASHBOARD_V3_EXTRAS_FROM_V2_P1_V1 ===
@app.route("/api/vsp/dashboard_v3_extras_v1", methods=["GET"])
def api_vsp_dashboard_v3_extras_v1():
  rid = (request.args.get("rid") or "").strip()
  if not rid:
    # fallback: take latest from runs_index if exists
    try:
      j = api_vsp_runs_index_v3_fs_resolved()
      rid = (j.json.get("items") or [{}])[0].get("run_id") or ""
    except Exception:
      rid = ""
  rid = str(rid).strip()

  # call V2 handler directly (same process) for counts
  try:
    # simulate request args for V2: limit=1
    args = request.args.to_dict(flat=True)
    args.pop("rid", None)
    args["limit"]="1"
    # Temporarily patch request.args? (avoid): call function and parse JSON through flask response
    resp = api_vsp_findings_unified_v2(rid)
    # resp may be (response, code)
    if isinstance(resp, tuple):
      resp_obj = resp[0]
    else:
      resp_obj = resp
    data = resp_obj.get_json(silent=True) or {}
  except Exception:
    data = {}

  counts = (data.get("counts") or {})
  by_sev = counts.get("by_sev") or {}
  by_tool = counts.get("by_tool") or {}
  top_cwe = counts.get("top_cwe") or []
  unknown_count = int(counts.get("unknown_count") or 0)
  total = int(data.get("total") or 0)

  # score heuristic (commercial-ish): 100 - weighted findings / scale
  w = 0
  for k,v in by_sev.items():
    k = str(k or "").upper()
    v = int(v or 0)
    if k == "CRITICAL": w += v*50
    elif k == "HIGH": w += v*30
    elif k == "MEDIUM": w += v*15
    elif k == "LOW": w += v*5
    elif k == "INFO": w += v*1
  score = max(0, int(100 - (w/ max(1, 200))))  # scale factor 200

  # degraded/effective (P1): degraded = unknown_count, effective = total-unknown
  degraded = unknown_count
  effective = max(0, total - unknown_count)

  return jsonify({
    "ok": True,
    "rid": rid,
    "kpi": {
      "total": total,
      "effective": effective,
      "degraded": degraded,
      "score": score,
      "by_sev": by_sev,
      "by_tool": by_tool,
      "top_cwe": top_cwe,
      "unknown_count": unknown_count
    },
    "sources": {
      "findings_api": "/api/vsp/findings_unified_v2/<rid>",
      "marker": "VSP_DASHBOARD_V3_EXTRAS_FROM_V2_P1_V1"
    }
  }), 200
# === /VSP_DASHBOARD_V3_EXTRAS_FROM_V2_P1_V1 ===

