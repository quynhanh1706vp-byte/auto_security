import shutil
import zipfile


# === VSP_RUN_STATUS_V2_CONTRACT_P1_V1_BEGIN ===
import os, json, glob

def _vsp_read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _vsp_find_run_dir(rid: str):
    """Best-effort resolve run dir for VSP_CI_* RID."""
    if not rid:
        return None
    # candidate roots (add more if needed)
    roots = [
        os.environ.get("VSP_OUT_CI_ROOT", ""),
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
    ]
    roots = [r for r in roots if r and os.path.isdir(r)]
    for r in roots:
        cand = os.path.join(r, rid)
        if os.path.isdir(cand):
            return cand
    # fallback glob
    for r in roots:
        hits = glob.glob(os.path.join(r, rid + "*"))
        for h in hits:
            if os.path.isdir(h):
                return h
    return None

def _vsp_findings_total(run_dir: str):
    if not run_dir:
        return None
    # prefer unified file if exists
    for fn in ("findings_unified.json","reports/findings_unified.json","findings_unified.sarif.json"):
        fp=os.path.join(run_dir, fn)
        if os.path.isfile(fp):
            j=_vsp_read_json(fp)
            if isinstance(j, dict):
                if isinstance(j.get("total"), int):
                    return j["total"]
                items=j.get("items")
                if isinstance(items, list):
                    return len(items)
    # fallback: any findings json
    fp=os.path.join(run_dir,"summary_unified.json")
    j=_vsp_read_json(fp) if os.path.isfile(fp) else None
    if isinstance(j, dict):
        t=j.get("total") or j.get("total_findings")
        if isinstance(t, int):
            return t
    return None

def _vsp_degraded_info(run_dir: str):
    """Best-effort degraded detection from runner.log (commercial degrade markers)."""
    if not run_dir:
        return (None, None)
    logp=os.path.join(run_dir,"runner.log")
    if not os.path.isfile(logp):
        # try tool logs
        for alt in ("kics/kics.log","codeql/codeql.log","trivy/trivy.log"):
            if os.path.isfile(os.path.join(run_dir,alt)):
                logp=os.path.join(run_dir,alt); break
        else:
            return (None, None)

    try:
        txt=Path(logp).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return (None, None)

    tools = ["BANDIT","SEMGREP","GITLEAKS","KICS","TRIVY","SYFT","GRYPE","CODEQL"]
    degraded=set()
    for t in tools:
        # strong markers we already use in scripts
        pats = [
            fr"VSP_{t}_TIMEOUT_DEGRADE",
            fr"\[{t}\].*DEGRADED",
            fr"{t}.*timeout.*degrad",
            fr"{t}.*missing.*degrad",
        ]
        for pat in pats:
            if re.search(pat, txt, flags=re.I):
                degraded.add(t)
                break
    n=len(degraded)
    return (n, n>0)

# === VSP_RUN_STATUS_V2_CONTRACT_P1_V1_END ===


# === VSP_MIN_IMPORTS_COMMERCIAL_V1 ===
# Hardened minimal imports to avoid NameError chain after patches
import os, sys, json, time, re, subprocess


# ---- commercial findings resolver ----  # VSP_FINDINGS_RESOLVE_V1
def vsp_resolve_findings_file(run_dir: str):
    import os
    cands = [
        "findings_unified_current.json",
        "findings_unified_commercial_v2.json",
        "findings_unified_commercial.json",
        "findings_unified.json",
    ]
    for name in cands:
        fp = os.path.join(run_dir, name)
        if os.path.isfile(fp) and os.path.getsize(fp) > 0:
            return fp
    return None
# ---- end resolver ----


# === VSP_EXPORT_PDF_RESOLVE_RUN_DIR_FROM_STATUSV2_V2 ===
def _vsp_resolve_ci_run_dir_from_status_v2_v2(rid: str):
    """Commercial: resolve run_dir using same contract as UI (run_status_v2)."""
    try:
        # local call: avoid requests dependency by importing urllib
        import json as _json
        from urllib.request import urlopen as _urlopen
        u = "http://127.0.0.1:8910/api/vsp/run_status_v2/" + str(rid)
        with _urlopen(u, timeout=2) as r:
            data = r.read().decode("utf-8", "ignore")
        d = _json.loads(data)
        ci = d.get("ci_run_dir") or d.get("ci") or ""
        if ci and isinstance(ci, str):
            return ci
    except Exception:
        return None
    return None

from pathlib import Path

class _VSP_WSGI_BYTES_POSTPROCESS_STATUSV2_GITLEAKS_V1:
    """Outermost WSGI wrapper: mutate JSON bytes for /api/vsp/run_status_v2/* so fields can't be overwritten later."""
    # === VSP_WSGI_BYTES_POSTPROCESS_STATUSV2_GITLEAKS_V1 ===
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if "/api/vsp/run_status_v2/" not in path:
            return self.app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None, "body_via_write": []}

        def _start_response_cap(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            captured["exc"] = exc_info
            def _write(data):
                try:
                    if data:
                        captured["body_via_write"].append(data)
                except Exception:
                    pass
            return _write

        it = self.app(environ, _start_response_cap)

        chunks = []
        try:
            if captured["body_via_write"]:
                chunks.extend(captured["body_via_write"])
            if it is not None:
                for c in it:
                    if c:
                        chunks.append(c)
        finally:
            try:
                close = getattr(it, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        body = b"".join(chunks)
        status = captured["status"] or "200 OK"
        headers = captured["headers"] or []

        ct = ""
        for k, v in headers:
            if str(k).lower() == "content-type":
                ct = str(v)
                break

        if ("application/json" not in ct.lower()) or (not body):
            start_response(status, headers, captured["exc"])
            return [body]

        try:
            import json
            from pathlib import Path as _P

            payload = json.loads(body.decode("utf-8", errors="ignore"))
            if isinstance(payload, dict):
                if payload.get("overall_verdict", None) is None:
                    payload["overall_verdict"] = ""

                payload.setdefault("has_gitleaks", False)
                payload.setdefault("gitleaks_verdict", "")
                payload.setdefault("gitleaks_total", 0)
                payload.setdefault("gitleaks_counts", {})

                ci = payload.get("ci_run_dir") or payload.get("ci_dir") or payload.get("ci") or ""
                ci = str(ci).strip()
                if ci:
                    def _readj(fp):
                        try:
                            if fp and fp.exists():
                                return json.loads(fp.read_text(encoding="utf-8", errors="ignore") or "{}")
                        except Exception:
                            return None
                        return None

                    base = _P(ci)

                    gsum = _readj(base / "gitleaks" / "gitleaks_summary.json") or _readj(base / "gitleaks_summary.json")
                    if not isinstance(gsum, dict):
                        try:
                            for fp in base.rglob("gitleaks_summary.json"):
                                gsum = _readj(fp)
                                if isinstance(gsum, dict):
                                    break
                        except Exception:
                            gsum = None

                    if isinstance(gsum, dict):
                        payload["has_gitleaks"] = True
                        payload["gitleaks_verdict"] = str(gsum.get("verdict") or "")
                        try:
                            payload["gitleaks_total"] = int(gsum.get("total") or 0)
                        except Exception:
                            payload["gitleaks_total"] = 0
                        cc = gsum.get("counts")
                        payload["gitleaks_counts"] = cc if isinstance(cc, dict) else {}

                    gate = _readj(base / "run_gate_summary.json")
                    if isinstance(gate, dict):
                        payload["overall_verdict"] = str(gate.get("overall") or payload.get("overall_verdict") or "")

                new_body = json.dumps(payload, ensure_ascii=False).encode("utf-8")

                new_headers = []
                for k, v in headers:
                    if str(k).lower() == "content-length":
                        continue
                    new_headers.append((k, v))
                new_headers.append(("Content-Length", str(len(new_body))))

                start_response(status, new_headers, captured["exc"])
                return [new_body]
        except Exception:
            pass

        start_response(status, headers, captured["exc"])
        return [body]


# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===
def _vsp_read_kics_summary(ci_run_dir: str):
    try:
        from pathlib import Path as _P
        fp = _P(ci_run_dir) / "kics" / "kics_summary.json"
        if not fp.exists():
            return None
        import json as _json
        obj = _json.loads(fp.read_text(encoding="utf-8", errors="ignore") or "{}")
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===

try:
    from flask import Flask, Blueprint, request, jsonify, Response, abort, send_file
except Exception:
    # allow import-time failure to surface clearly
    Flask = Blueprint = request = jsonify = Response = abort = send_file = None
# === END VSP_MIN_IMPORTS_COMMERCIAL_V1 ===

# === VSP_DEFINE__PATH_ALIAS_V1 ===
try:
    _Path
except Exception:
    _Path = Path
# === END VSP_DEFINE__PATH_ALIAS_V1 ===
UIREQ_STATE_DIR = Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")  # VSP_UIREQ_CANON_DIR_V1
from collections import defaultdict
import functools
import re
from api.vsp_run_export_api_v3 import bp_run_export_v3
from api.vsp_settings_rules_v1 import bp_settings_rules

# === VSP_RESTORE_MISSING_BLUEPRINTS_V1 ===
try:
    from flask import Blueprint as _VSP_Blueprint
except Exception:
    _VSP_Blueprint = None

if _VSP_Blueprint is not None:
    vsp_runs_fs_bp = _VSP_Blueprint("vsp_runs_fs_bp", __name__)
# === END VSP_RESTORE_MISSING_BLUEPRINTS_V1 ===


# === VSP_KICS_TAIL_HELPERS_V2 ===
import json as _vsp_json
from pathlib import Path as _vsp_Path

def _vsp_safe_tail_text(_p, max_bytes=8192, max_lines=120):

    # === VSP_RUN_EXPORT_V3_PDF_EARLY_RETURN_V1 ===
    try:
        _fmt = (request.args.get("fmt","") or "").lower()
    except Exception:
        _fmt = ""
    if _fmt == "pdf":
        # Resolve run_dir robustly from rid
        try:
            rid_in = rid
        except Exception:
            rid_in = request.view_args.get("rid","") if hasattr(request, "view_args") else ""
        rid_norm = str(rid_in or "")
        # Normalize RUN_VSP_CI_... -> VSP_CI_...
        if rid_norm.startswith("RUN_"):
            rid_norm2 = rid_norm[len("RUN_"):]
        else:
            rid_norm2 = rid_norm

        # Candidate run dirs (keep your current base)
        bases = [
            "/home/test/Data/SECURITY-10-10-v4/out_ci",
            "/home/test/Data/SECURITY-10-10-v4/out_ci/",
        ]
        cands = []
        for b in bases:
            cands.append(os.path.join(b, rid_norm2))
            cands.append(os.path.join(b, rid_norm))
            # also allow VSP_CI_ prefix if missing
            if "VSP_CI_" not in rid_norm2 and rid_norm2:
                cands.append(os.path.join(b, "VSP_CI_" + rid_norm2))

        run_dir = None
        for c in cands:
            try:
                if os.path.isdir(c):
                    run_dir = c
                    break
            except Exception:
                pass

        # If your existing code already computed run_dir earlier, prefer it
        if "run_dir" in locals() and isinstance(locals().get("run_dir"), str) and os.path.isdir(locals().get("run_dir")):
            run_dir = locals().get("run_dir")

        files = []
        if run_dir:
            globs = [
                os.path.join(run_dir, "report*.pdf"),
                os.path.join(run_dir, "reports", "report*.pdf"),
                os.path.join(run_dir, "*.pdf"),
                os.path.join(run_dir, "reports", "*.pdf"),
            ]
            for g in globs:
                try:
                    files += glob.glob(g)
                except Exception:
                    pass

        files = [f for f in files if isinstance(f, str) and os.path.isfile(f)]
        if files:
            try:
                pick = max(files, key=lambda x: os.path.getmtime(x))
            except Exception:
                pick = files[-1]
            rsp = send_file(pick, mimetype="application/pdf", as_attachment=True, download_name=os.path.basename(pick))
            rsp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
            return rsp

        # Not found => commercial: 200 + available=0 (NOT 404)
        rsp = jsonify({
            "ok": True,
            "fmt": "pdf",
            "available": 0,
            "rid": rid_norm,
            "rid_norm": rid_norm2,
            "run_dir": run_dir,
            "reason": "pdf_not_found",
        })
        rsp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        return rsp
    try:
        _p = _vsp_Path(_p)
        if not _p.exists():
            return ""
        b = _p.read_bytes()
    except Exception:
        return ""
    if max_bytes and len(b) > max_bytes:
        b = b[-max_bytes:]
    try:
        s = b.decode("utf-8", errors="replace")
    except Exception:
        s = str(b)
    lines = s.splitlines()
    if max_lines and len(lines) > max_lines:
        lines = lines[-max_lines:]
    return "\n".join(lines).strip()
def _vsp_kics_tail_from_ci(ci_run_dir):
    """
    Commercial guarantee:
      - If KICS log exists => return tail
      - Else try degraded_tools.json for KICS (rc/reason)
      - Else try runner.log tail for KICS rc=127 / command not found / No such file / timeout
      - Else if CI dir hints KICS stage => return explicit NO_KICS_LOG/NO_EVIDENCE message (NOT empty)
      - Else return "" (non-KICS runs)
    """
    if not ci_run_dir:
        return ""
    try:
        base = _vsp_Path(str(ci_run_dir))
    except Exception:
        return ""

    # 1) kics.log
    klog = base / "kics" / "kics.log"
    if klog.exists():
        return _vsp_safe_tail_text(klog)

    # 2) degraded_tools.json (either list or {"degraded_tools":[...]})
    for dj in (base / "degraded_tools.json",):
        if dj.exists():
            try:
                raw = dj.read_text(encoding="utf-8", errors="ignore").strip() or "[]"
                data = _vsp_json.loads(raw)
                items = data.get("degraded_tools", []) if isinstance(data, dict) else data
                for it in (items or []):
                    tool = str((it or {}).get("tool","")).upper()
                    if tool == "KICS":
                        rc = (it or {}).get("rc")
                        reason = (it or {}).get("reason") or (it or {}).get("msg") or "degraded"
                        return "MISSING_TOOL: KICS (rc=%s) reason=%s" % (rc, reason)
            except Exception:
                pass

    # 3) runner.log fallback (best effort)
    rlog = base / "runner.log"
    if rlog.exists():
        tail = _vsp_safe_tail_text(rlog, max_bytes=16384, max_lines=200)
        up = tail.upper()
        # detect KICS-related failures
        if "KICS" in up:
            # common missing/rc patterns
            if ("RC=127" in up) or ("COMMAND NOT FOUND" in up) or ("NO SUCH FILE" in up) or ("NOT FOUND" in up):
                # include last few lines containing KICS / rc=127 / not found
                lines = tail.splitlines()
                keep = []
                for ln in lines[-200:]:
                    u = ln.upper()
                    if ("KICS" in u) or ("RC=127" in u) or ("COMMAND NOT FOUND" in u) or ("NO SUCH FILE" in u) or ("NOT FOUND" in u):
                        keep.append(ln)
                msg = "\n".join(keep[-30:]).strip() or tail
                return "MISSING_TOOL: KICS (from runner.log)\n" + msg

            if ("TIMEOUT" in up) or ("RC=124" in up):
                return "TIMEOUT: KICS (from runner.log)\n" + tail

            # KICS mentioned but no explicit error: still give useful context
            return "NO_KICS_LOG: %s\n(from runner.log)\n%s" % (klog, tail)

    # 4) heuristic: CI dir hints KICS stage (kics folder exists or stage marker exists somewhere)
    if (base / "kics").exists():
        return "NO_KICS_LOG: %s" % (klog,)

    # runner.log missing, kics dir missing: cannot assert it's KICS stage
    return ""

def _runsfs_safe_load_json(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return json.load(f)
    except Exception:
        return None

def _runsfs_sum_totals(totals):
    if not isinstance(totals, dict):
        return 0
    s = 0
    for k,v in totals.items():
        try:
            s += int(v)
        except Exception:
            pass
    return s

def _runsfs_pick_runs(out_root, limit=50, hide_empty=False):
    items = []
    try:
        for name in os.listdir(out_root):
            if not name.startswith("RUN_"):
                continue
            run_dir = os.path.join(out_root, name)
            if not os.path.isdir(run_dir):
                continue
            rpt = os.path.join(run_dir, "report")
            summary = os.path.join(rpt, "summary_unified.json")
            st = os.stat(run_dir)
            created_at = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(st.st_mtime))
            meta = _runsfs_safe_load_json(os.path.join(run_dir, "ci_source_meta.json")) or {}
            s = _runsfs_safe_load_json(summary) or {}
            bysev = (s.get("summary_by_severity") or s.get("by_severity") or {})
            items.append({
                "rid": name,
                "created_at": created_at,
                "profile": (meta.get("profile") or s.get("profile") or ""),
                "target": (meta.get("target") or s.get("target") or ""),
                "totals": bysev if isinstance(bysev, dict) else {},
                "total_findings": _runsfs_sum_totals(bysev if isinstance(bysev, dict) else {}),
                "has_findings": 1 if _runsfs_sum_totals(bysev if isinstance(bysev, dict) else {}) > 0 else 0,
            })
    except Exception:
        pass
    if hide_empty:
        items = [it for it in items if int(it.get('has_findings',0)) == 1]
    # prefer has_findings then by time
    items.sort(key=lambda x: (int(x.get('has_findings',0)), x.get('created_at','')), reverse=True)
    # prefer has_findings sorting
    return items[:max(1, int(limit))]

@vsp_runs_fs_bp.get("/api/vsp/runs_index_v3_fs")
def vsp_runs_index_v3_fs():
    limit = request.args.get("limit", "40")
    try:
        limit_i = max(1, min(500, int(limit)))
    except Exception:
        limit_i = 40
    bundle_root = _Path(__file__).resolve().parents[1]  # .../SECURITY_BUNDLE
    bundle_root = _Path(os.environ.get('VSP_BUNDLE_ROOT', str(bundle_root))).resolve()
    out_dir = bundle_root / "out"
    hide_empty = request.args.get('hide_empty','0') in ('1','true','yes')
    items = _runsfs_pick_runs(str(out_dir), limit_i, hide_empty=hide_empty)
    kpi = {"total_runs": len(items), "last_n": min(20, len(items))}
    # === VSP_COMMERCIAL_RUNSFS_SORT_V1 (CI-first + newest-first) ===
    try:
        # 1) newest-first (ISO string compare works for YYYY-mm-ddTHH:MM:SS)
        items.sort(key=lambda r: (str(r.get('created_at','')), str(r.get('run_id',''))), reverse=True)
        # 2) CI-first (stable sort)
        items.sort(key=lambda r: (0 if str(r.get('run_id','')).startswith('RUN_VSP_CI_') else 1))
    except Exception:
        pass
    # === END VSP_COMMERCIAL_RUNSFS_SORT_V1 ===

    return jsonify({"ok": True, "source": "fs", "items": items, "kpi": kpi})
# === END RUNS_INDEX_FS_V1 ===

import requests

# === Config chung ===
from pathlib import Path  # VSP_FORCE_PATH_SYMBOL_V3
ROOT = Path(__file__).resolve().parents[1]  # /home/test/Data/SECURITY_BUNDLE
CORE_BASE = "http://localhost:8961"         # Core API (dashboard_v3, runs_index_v3, datasource_v2)

from flask import Flask  # VSP_FORCE_FLASK_SYMBOL_V1

app = Flask(

    __name__,
    static_folder="static",
    template_folder="templates",
)

# --- VSP_ASSET_VERSION (commercial) ---
import os as _os
import time as _time
from pathlib import Path as _Path

def _vsp_asset_v():
  v = _os.environ.get("VSP_ASSET_V", "").strip()
  if v:
    return v
  try:
    bp = (_Path(__file__).resolve().parent / "static/js/vsp_bundle_commercial_v1.js")
    return str(int(bp.stat().st_mtime))
  except Exception:
    return str(int(_time.time()))

@app.context_processor
def inject_vsp_asset_v():
  # Used by templates as: {{ asset_v }}
  return {"asset_v": _vsp_asset_v()}
# --- /VSP_ASSET_VERSION ---


# === VSP_RUN_STATUS_V2_WINLAST_V6 ===
# Commercial harden: /api/vsp/run_status_v2/<rid> never 404, inject stage + degraded + KICS summary.
import json, re
def _vsp__sanitize_stage_name_v2(s: str) -> str:
    if not s:
        return ""
    s = str(s)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    # keep first line only
    s = s.split("\n", 1)[0].strip()
    # remove trailing markers
    if "=====" in s:
        s = s.split("=====", 1)[0].strip()
    # remove possible prefix like "===== [3/8]"
    s = re.sub(r"^=+\s*\[\s*\d+\s*/\s*\d+\s*\]\s*", "", s).strip()
    s = re.sub(r"\s*=+\s*$", "", s).strip()
    return s


from pathlib import Path
from flask import jsonify
_STAGE_RE_V2 = re.compile(r"=+\s*\[\s*(\d+)\s*/\s*(\d+)\s*\]\s*([^\n=]+?)\s*=+", re.IGNORECASE)

def _vsp__tail_text_v2(pp: Path, max_bytes: int = 20000) -> str:
    try:
        if not pp.exists() or not pp.is_file():
            return ""
        bs = pp.read_bytes()
        if len(bs) > max_bytes:
            bs = bs[-max_bytes:]
        return bs.decode("utf-8", errors="ignore")
    except Exception:
        return ""

def _vsp__resolve_ci_run_dir_v2(rid: str):
    fn = globals().get("_vsp_guess_ci_run_dir_from_rid_v33")
    if callable(fn):
        try:
            d = fn(rid)
            if d and Path(d).exists():
                return str(Path(d))
        except Exception:
            pass

    rid_norm = str(rid).strip()
    rid_norm = rid_norm.replace("RUN_", "").replace("VSP_UIREQ_", "VSP_CI_")
    m = re.search(r"(VSP_CI_\d{8}_\d{6})", rid_norm)
    if m:
        cand = Path("/home/test/Data/SECURITY-10-10-v4/out_ci") / m.group(1)
        if cand.exists():
            return str(cand)
    return None

def _vsp__inject_stage_progress_v2(ci_dir: str, payload: dict):
    payload.setdefault("stage_name", "")
    payload.setdefault("stage_index", 0)
    payload.setdefault("stage_total", 0)
    payload.setdefault("progress_pct", 0)
    if not ci_dir:
        return
    tail = _vsp__tail_text_v2(Path(ci_dir) / "runner.log")
    if not tail:
        return

    # Normalize CRLF/CR to LF
    tail = tail.replace("\r\n", "\n").replace("\r", "\n")

    last = None
    for line in tail.split("\n"):
        # example line: "===== [3/8] KICS (EXT) ====="
        if "=====" in line and "]" in line and "[" in line:
            if re.search(r"\[\s*\d+\s*/\s*\d+\s*\]", line):
                last = line

    if not last:
        return

    mm = re.search(r"\[\s*(\d+)\s*/\s*(\d+)\s*\]", last)
    if not mm:
        return

    si = int(mm.group(1) or 0)
    st = int(mm.group(2) or 0)

    after = last.split("]", 1)[1] if "]" in last else ""
    name = after.split("=====", 1)[0].strip()

    payload["stage_name"] = name
    payload["stage_index"] = si
    payload["stage_total"] = st
    payload["progress_pct"] = int((si / st) * 100) if st > 0 else 0


def _vsp__read_json_if_exists_v2(p):
    """Return parsed JSON if file exists, else None. Never raises."""
    try:
        import json
        from pathlib import Path as _Path
        pp = _Path(p)
        if not pp.exists():
            return None
        with pp.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _vsp__inject_degraded_tools_v2(ci_dir: str, payload: dict):
    payload.setdefault("degraded_tools", [])
    if not ci_dir:
        return
    dj = _vsp__read_json_if_exists_v2(Path(ci_dir) / "degraded_tools.json")
    if isinstance(dj, list):
        payload["degraded_tools"] = dj

def _vsp__inject_kics_summary_v2(ci_dir: str, payload: dict):
    # === VSP_PAYLOAD_DEFAULT_GITLEAKS_V1 ===
    payload.setdefault("has_gitleaks", False)
    payload.setdefault("gitleaks_verdict", "")
    payload.setdefault("gitleaks_total", 0)
    payload.setdefault("gitleaks_counts", {})
    payload.setdefault("kics_verdict", "")
    payload.setdefault("kics_total", 0)
    payload.setdefault("kics_counts", {})
    if not ci_dir:
        return
    ksum = _vsp__read_json_if_exists_v2(Path(ci_dir) / "kics" / "kics_summary.json")
    if isinstance(ksum, dict):
        payload["kics_verdict"] = str(ksum.get("verdict") or "")
        payload["kics_total"] = int(ksum.get("total") or 0)
        cnt = ksum.get("counts") or {}
        payload["kics_counts"] = cnt if isinstance(cnt, dict) else {}

def api_vsp_run_status_v2_winlast_v6(rid):
    payload = {
        "ok": True,
        "rid": str(rid),
        "ci_run_dir": None,
        "stage_name": "",
        "stage_index": 0,
        "stage_total": 0,
        "progress_pct": 0,
        "kics_verdict": "",
        "kics_total": 0,
        "kics_counts": {},
        "degraded_tools": [],
    }

    ci_dir = _vsp__resolve_ci_run_dir_v2(str(rid))
    payload["ci_run_dir"] = ci_dir
    if not ci_dir:
        payload["ok"] = False
        payload["error"] = "CI_RUN_DIR_NOT_FOUND"

        # === VSP_STATUS_V2_CALLS_FIX_NO_CI_RUN_DIR_V1 ===
        try:
            _ci = None
            # prefer response field (most stable)
            if isinstance(resp, dict):
                _ci = resp.get("ci_run_dir") or resp.get("ci_dir") or resp.get("run_dir")
            # fallback: local vars if present
            try:
                _ci = _ci or ci_run_dir
            except Exception:
                pass
            try:
                _ci = _ci or ci_dir
            except Exception:
                pass
            _vsp_inject_tool_summary(resp, _ci, "semgrep", "semgrep_summary.json")
            _vsp_inject_tool_summary(resp, _ci, "trivy",   "trivy_summary.json")
            _vsp_inject_run_gate(resp, _ci)
        except Exception:
            pass

# === VSP_STATUS_ALWAYS8_TOOLS_V1 ===
    # Force commercial invariant: always present 8 tool lanes in status payload (NOT_RUN if missing)
    try:
        _CANON_TOOLS = ["SEMGREP","GITLEAKS","TRIVY","CODEQL","KICS","GRYPE","SYFT","BANDIT"]
        _ZERO_COUNTS = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0}

        # payload variable name may differ; attempt common ones
        _payload = None
        for _nm in ["payload","rsp","out","data","ret","result"]:
            if _nm in locals() and isinstance(locals().get(_nm), dict):
                _payload = locals()[_nm]
                break
        if _payload is None:
            # fallback: try the argument passed into jsonify(...) if it is a dict var
            pass

        if isinstance(_payload, dict):
            tools = _payload.get("tools") or _payload.get("by_tool") or _payload.get("tool_status") or {}
            if isinstance(tools, dict):
                for t in _CANON_TOOLS:
                    if t not in tools:
                        tools[t] = {
                            "tool": t,
                            "status": "NOT_RUN",
                            "verdict": "NOT_RUN",
                            "total": 0,
                            "counts": dict(_ZERO_COUNTS),
                            "reason": "missing_tool_output"
                        }
                # normalize container key
                _payload["tools"] = tools

            # Optional: keep a stable ordered list for UI
            _payload["tools_order"] = _CANON_TOOLS
    except Exception as _e:
        try:
            _payload = locals().get("payload")
            if isinstance(_payload, dict):
                _payload.setdefault("warnings", []).append("always8_tools_patch_failed")
        except Exception:
            pass


        return jsonify(payload), 200

    _vsp__inject_stage_progress_v2(ci_dir, payload)
    _vsp__inject_degraded_tools_v2(ci_dir, payload)
    _vsp__inject_kics_summary_v2(ci_dir, payload)
    payload["stage_name"] = _vsp__sanitize_stage_name_v2(payload.get("stage_name",""))
    return jsonify(payload), 200
def _vsp__register_run_status_v2_winlast_v6(flask_app):
    if flask_app is None:
        return
    try:
        flask_app.add_url_rule(
            "/api/vsp/run_status_v2/<rid>",
            endpoint="api_vsp_run_status_v2_winlast_v6",
            view_func=api_vsp_run_status_v2_winlast_v6,
            methods=["GET"],
        )
    except Exception as e:
        msg = str(e)
        if "already exists" in msg or "existing endpoint function" in msg:
            return
# === END VSP_RUN_STATUS_V2_WINLAST_V6 ===

_vsp__register_run_status_v2_winlast_v6(app)
# === VSP_AFTER_REQUEST_KICS_TAIL_V2_SAFE ===
def _vsp__kics_tail_from_ci(ci_run_dir: str, max_bytes: int = 65536) -> str:
    try:
        import os
        from pathlib import Path
        NL = chr(10)
        klog = os.path.join(ci_run_dir, "kics", "kics.log")
        if not os.path.exists(klog):
            return ""
        rawb = Path(klog).read_bytes()
        if len(rawb) > max_bytes:
            rawb = rawb[-max_bytes:]
        raw = rawb.decode("utf-8", errors="ignore").replace(chr(13), NL)
        # keep last non-empty lines (avoid spinner noise)
        lines2 = [x for x in raw.splitlines() if x.strip()]
        tail = NL.join(lines2[-60:])
        # pick latest HB/rc marker
        hb = ""
        for ln in reversed(lines2):
            if ("[KICS_V" in ln and "][HB]" in ln) or ("[KICS_V" in ln and "rc=" in ln) or ("[DEGRADED]" in ln):
                hb = ln.strip()
                break
        if hb and hb not in tail:
            tail = hb + NL + tail
        return tail[-4096:]
    except Exception:
        return ""

def _vsp__load_ci_dir_from_state(req_id: str) -> str:
    try:
        import json
        from pathlib import Path
        base = Path(__file__).resolve().parent
        cands = [
            base / "out_ci" / "uireq_v1" / (req_id + ".json"),
            base / "ui" / "out_ci" / "uireq_v1" / (req_id + ".json"),
            base / "out_ci" / "ui_req_state" / (req_id + ".json"),
            base / "ui" / "out_ci" / "ui_req_state" / (req_id + ".json"),
        ]
        for fp in cands:
            if fp.exists():
                txt = fp.read_text(encoding="utf-8", errors="ignore") or ""
                j = json.loads(txt) if txt.strip() else {}
                # === VSP_PREEMPT_STATUSV2_POSTPROCESS_HOOK_V1 ===
                try:
                    j = _vsp_preempt_statusv2_postprocess_v1(j)
                except Exception:
                    pass
                ci = str(j.get("ci_run_dir") or "")
                if ci:
                    return ci
        return ""
    except Exception:
        return ""

def _vsp__after_request_kics_tail(resp):
    try:
        import json
        from flask import request
        if not request.path.startswith("/api/vsp/run_status_v1/"):
            return resp
        # only patch JSON responses
        if (getattr(resp, "mimetype", "") or "") != "application/json":
            return resp
        rid = request.path.rsplit("/", 1)[-1]
        data = resp.get_data(as_text=True) or ""
        obj = json.loads(data) if data.strip() else {}
        stage = str(obj.get("stage_name") or "").lower()
        ci = str(obj.get("ci_run_dir") or "")
        if not ci:
            ci = _vsp__load_ci_dir_from_state(rid)
        if ci and ("kics" in stage):
            kt = _vsp__kics_tail_from_ci(ci)
            if kt:
                obj["kics_tail"] = kt
                resp.set_data(json.dumps(obj, ensure_ascii=False))
                resp.headers["Content-Length"] = str(len(resp.get_data()))
        return resp
    except Exception:
        return resp

try:
    app.after_request(_vsp__after_request_kics_tail)
except Exception:
    pass
# === END VSP_AFTER_REQUEST_KICS_TAIL_V2_SAFE ===
# === VSP_RUN_API_FORCE_REGISTER_V2_AST (do not edit) ===
def _vsp__load_runapi_bp__v2():
    try:
        # normal import (package-style)
        from run_api.vsp_run_api_v1 import bp_vsp_run_api_v1
        return bp_vsp_run_api_v1
    except Exception as e1:
        try:
            # fallback: load by file path (works even if run_api isn't a package)
            import importlib.util
            from pathlib import Path as _Path
            mod_path = _Path(__file__).resolve().parent / "run_api" / "vsp_run_api_v1.py"
            spec = importlib.util.spec_from_file_location("vsp_run_api_v1_dyn_v2", str(mod_path))
            mod = importlib.util.module_from_spec(spec)
            assert spec and spec.loader
            spec.loader.exec_module(mod)
            return getattr(mod, "bp_vsp_run_api_v1", None)
        except Exception as e2:
            print("[VSP_RUN_API] WARN load failed:", repr(e1), repr(e2))
            return None

try:
    _bp = _vsp__load_runapi_bp__v2()
    if _bp is not None:
        _bps = getattr(app, "blueprints", None) or {}
        if getattr(_bp, "name", None) in _bps:
            print("[VSP_RUN_API] already registered:", _bp.name)
        else:
            app.register_blueprint(_bp)
            print("[VSP_RUN_API] OK registered: /api/vsp/run_v1 + /api/vsp/run_status_v1/<REQ_ID>")
    else:
        print("[VSP_RUN_API] WARN: bp_vsp_run_api_v1 is None")
except Exception as e:
    print("[VSP_RUN_API] WARN: cannot register run_api blueprint:", repr(e))
# === END VSP_RUN_API_FORCE_REGISTER_V2_AST ===
# === RUNS_INDEX_FS_REGISTER_V1 ===
try:
    app.register_blueprint(vsp_runs_fs_bp)
except Exception as _e:
    pass
# === END RUNS_INDEX_FS_REGISTER_V1 ===

# === Helper proxy sang core 8961 ===
from flask import Response  # VSP_FORCE_RESPONSE_SYMBOL_V1
def proxy_get(path: str) -> Response:
    """
    Proxy GET từ 8910 -> 8961, giữ nguyên query string.
    """
    core_url = CORE_BASE + path
    try:
        resp = requests.get(core_url, params=request.args, timeout=60)
    except Exception as e:
        return jsonify(ok=False, error=f"Proxy error to core {core_url}: {e}"), 502

    headers = {}
    ct = resp.headers.get("Content-Type")
    if ct:
        headers["Content-Type"] = ct
    return Response(resp.content, status=resp.status_code, headers=headers)


# === Routes UI chính ===
@app.route("/")
def index():
    # Trang VSP 5 tab (index.html đã là layout mới)
    return render_template('vsp_dashboard_2025.html')


@app.route("/security_bundle")
def security_bundle():
    # Giữ route cũ nếu có chỗ nào gọi
    return render_template('vsp_dashboard_2025.html')


# === Proxy API: dashboard_v3, runs_index_v3, datasource_v2 ===



    try:
        root = pathlib.Path(__file__).resolve().parents[1]
        out_dir = root / "out"
        if not out_dir.is_dir():
            return jsonify(ok=False, error="no_out_dir"), 404

        ci_runs = sorted(
            [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_VSP_CI_")]
        )
        if not ci_runs:
            return jsonify(ok=False, error="no_ci_runs"), 404

        latest = ci_runs[-1]
        snap_path = latest / "report" / "ci_snapshot.json"
        flag_path = latest / "report" / "ci_flag_has_findings.env"

        snap_data = {}
        if snap_path.is_file():
            try:
                snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
            except Exception as e:
                app.logger.error("[CI_SNAPSHOT_API] Lỗi đọc %s: %s", snap_path, e)

        has_flag = None
        if flag_path.is_file():
            try:
                for line in flag_path.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith("has_findings="):
                        v = line.split("=", 1)[1].strip()
                        has_flag = (v == "1")
                        break
            except Exception as e:
                app.logger.error("[CI_SNAPSHOT_API] Lỗi đọc %s: %s", flag_path, e)

        # Ưu tiên has_findings từ snapshot, fallback sang flag
        has_findings = snap_data.get("has_findings", has_flag)

        resp = {
            "ok": True,
            "rid": snap_data.get("run_id", latest.name),
            "ci_run_dir": latest.name,
            "source": snap_data.get("source", "CI"),
            "has_findings": bool(has_findings) if has_findings is not None else None,
            "total_findings": snap_data.get("total_findings"),
            "by_severity": snap_data.get("by_severity", {}),
            "top_tools": snap_data.get("top_tools", []),
            "top_cwe": snap_data.get("top_cwe", []),
            "generated_at": snap_data.get("generated_at"),
            "raw": snap_data,
        }
        return jsonify(resp)
    except Exception as e:
        app.logger.exception("[CI_SNAPSHOT_API] Exception: %s", e)
        return jsonify(ok=False, error="exception", detail=str(e)), 500




    ci_runs = sorted(
        [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_VSP_CI_")]
    )
    if not ci_runs:
        return jsonify(ok=False, error="no_ci_runs"), 404

    latest = ci_runs[-1]
    snap_path = latest / "report" / "ci_snapshot.json"
    flag_path = latest / "report" / "ci_flag_has_findings.env"

    if not snap_path.is_file():
        return jsonify(ok=False, error="no_ci_snapshot", run_dir=latest.name), 404

    try:
        snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
    except Exception as e:
        app.logger.exception("[CI_SNAPSHOT_API_V2] Lỗi parse %s: %s", snap_path, e)
        return jsonify(ok=False, error="invalid_snapshot_json", run_dir=latest.name), 500

    has_flag = None
    if flag_path.is_file():
        try:
            for line in flag_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("has_findings="):
                    v = line.split("=", 1)[1].strip()
                    has_flag = (v == "1")
                    break
        except Exception as e:
            app.logger.error("[CI_SNAPSHOT_API_V2] Lỗi đọc %s: %s", flag_path, e)

    has_findings = snap_data.get("has_findings", has_flag)

    resp = {
        "ok": True,
        "rid": snap_data.get("run_id", latest.name),
        "ci_run_dir": latest.name,
        "source": snap_data.get("source", "CI"),
        "has_findings": bool(has_findings) if has_findings is not None else None,
        "total_findings": snap_data.get("total_findings"),
        "by_severity": snap_data.get("by_severity", {}),
        "top_tools": snap_data.get("top_tools", []),
        "top_cwe": snap_data.get("top_cwe", []),
        "generated_at": snap_data.get("generated_at"),
    }
    return jsonify(resp)


@app.route("/api/vsp/ci_snapshot_latest", methods=["GET"])
def vsp_ci_snapshot_latest():
    """
    Trả về snapshot CI mới nhất:
    - Chọn RUN_VSP_CI_* mới nhất trong out/
    - Đọc report/ci_snapshot.json + ci_flag_has_findings.env
    """
    import json
    import pathlib

    root = pathlib.Path(__file__).resolve().parents[1]
    out_dir = root / "out"

    if not out_dir.is_dir():
        return jsonify(ok=False, error="no_out_dir"), 404

    ci_runs = sorted(
        [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_VSP_CI_")]
    )
    if not ci_runs:
        return jsonify(ok=False, error="no_ci_runs"), 404

    latest = ci_runs[-1]
    snap_path = latest / "report" / "ci_snapshot.json"
    flag_path = latest / "report" / "ci_flag_has_findings.env"

    if not snap_path.is_file():
        return jsonify(ok=False, error="no_ci_snapshot", run_dir=latest.name), 404

    try:
        snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
    except Exception as e:
        app.logger.exception("[CI_SNAPSHOT_API_V2] Lỗi parse %s: %s", snap_path, e)
        return jsonify(ok=False, error="invalid_snapshot_json", run_dir=latest.name), 500

    has_flag = None
    if flag_path.is_file():
        try:
            for line in flag_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("has_findings="):
                    v = line.split("=", 1)[1].strip()
                    has_flag = (v == "1")
                    break
        except Exception as e:
            app.logger.error("[CI_SNAPSHOT_API_V2] Lỗi đọc %s: %s", flag_path, e)

    has_findings = snap_data.get("has_findings", has_flag)

    resp = {
        "ok": True,
        "rid": snap_data.get("run_id", latest.name),
        "ci_run_dir": latest.name,
        "source": snap_data.get("source", "CI"),
        "has_findings": bool(has_findings) if has_findings is not None else None,
        "total_findings": snap_data.get("total_findings"),
        "by_severity": snap_data.get("by_severity", {}),
        "top_tools": snap_data.get("top_tools", []),
        "top_cwe": snap_data.get("top_cwe", []),
        "generated_at": snap_data.get("generated_at"),
    }
    return jsonify(resp)


@app.route("/api/vsp/dashboard_delta_latest", methods=["GET"])
def vsp_dashboard_delta_latest():
    """
    Lightweight API: so sánh run mới nhất với run liền trước
    dựa trên out/summary_by_run.json.
    """
    import os, json, datetime as _dt

    root = os.path.dirname(os.path.dirname(__file__))
    summary_path = os.path.join(root, "out", "summary_by_run.json")

    if not os.path.exists(summary_path):
        return jsonify({"ok": False, "error": "summary_by_run.json not found"}), 404

    try:
        with open(summary_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        return jsonify({"ok": False, "error": "failed to load summary_by_run.json: %s" % e}), 500

    # Chuẩn hoá list run
    if isinstance(data, dict):
        items = list(data.get("runs") or data.get("items") or data.values())
    else:
        items = list(data or [])

    if not items:
        return jsonify({"ok": False, "error": "no runs in summary_by_run.json"}), 200

    def extract_ts(item):
        meta = item.get("meta") or {}
        for key in ("started_at", "created_at", "generated_at"):
            v = meta.get(key) or item.get(key)
            if isinstance(v, str):
                try:
                    return _dt.datetime.fromisoformat(v.replace("Z", ""))
                except Exception:
                    pass
        # Fallback: dùng run_id như timestamp thô
        rid = str(item.get("run_id") or "")
        try:
            return _dt.datetime.strptime(rid[-15:], "%Y%m%d_%H%M%S")
        except Exception:
            return _dt.datetime.min

    def is_full_ext(item):
        profile = (item.get("profile") or item.get("mode") or "").upper()
        rid = (item.get("run_id") or "").upper()
        return ("FULL_EXT" in profile) or ("FULL_EXT" in rid)

    full_ext = [it for it in items if is_full_ext(it)]
    source_items = full_ext if len(full_ext) >= 2 else items

    source_items = [it for it in source_items if isinstance(it, dict)]
    if len(source_items) < 2:
        return jsonify({"ok": False, "error": "not enough runs for delta"}), 200

    source_items.sort(
        key=lambda it: (extract_ts(it), str(it.get("run_id") or "")),
        reverse=True,
    )

    current, previous = source_items[0], source_items[1]

    def pick_num(it, keys, default=0):
        for k in keys:
            v = it.get(k)
            if isinstance(v, (int, float)):
                return v
        summary_all = it.get("summary_all") or {}
        for k in keys:
            v = summary_all.get(k)
            if isinstance(v, (int, float)):
                return v
        return default

    cur_total = pick_num(current, ["total_findings", "findings_total"])
    prev_total = pick_num(previous, ["total_findings", "findings_total"])

    cur_score = pick_num(current, ["security_posture_score", "security_score", "score"])
    prev_score = pick_num(previous, ["security_posture_score", "security_score", "score"])

    delta_total = None if (cur_total is None or prev_total is None) else cur_total - prev_total
    delta_score = None if (cur_score is None or prev_score is None) else cur_score - prev_score

    resp = {
        "ok": True,
        "current": {
            "rid": current.get("run_id"),
            "total_findings": cur_total,
            "security_posture_score": cur_score,
        },
        "previous": {
            "rid": previous.get("run_id"),
            "total_findings": prev_total,
            "security_posture_score": prev_score,
        },
        "delta": {
            "total_findings": delta_total,
            "security_posture_score": delta_score,
        },
    }
    return jsonify(resp)
@app.route("/api/vsp/dashboard_v3", methods=["GET"])
def api_vsp_dashboard_v3():

    # [VSP_UI_DASHBOARD_V3_LATEST_JSON_PATCH] Ưu tiên đọc file out/vsp_dashboard_v3_latest.json nếu tồn tại
    try:
        import json, pathlib
        from flask import jsonify
        ui_root = pathlib.Path(__file__).resolve().parent
        root = ui_root.parent  # /home/test/Data/SECURITY_BUNDLE
        latest_path = root / "out" / "vsp_dashboard_v3_latest.json"
        if latest_path.is_file():
            model = json.loads(latest_path.read_text(encoding="utf-8"))
            return jsonify(model)
    except Exception as e:  # noqa: E722
        try:
            from flask import current_app
            current_app.logger.warning("VSP_UI_DASHBOARD_V3_LATEST_JSON_PATCH failed: %r", e)
        except Exception:
            print("VSP_UI_DASHBOARD_V3_LATEST_JSON_PATCH failed:", repr(e))
    return proxy_get("/api/vsp/dashboard_v3")






@app.route("/api/vsp/runs_index_v3")
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    - KPI + trend: cố gắng lấy từ out/summary_by_run.json (nếu có).
    - Danh sách runs (items): *không phụ thuộc* vào summary_by_run.json,
      mà tự quét out/RUN_*/report/findings_unified.json.
    """
    import json
    import datetime
    from pathlib import Path
    from flask import request, jsonify

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    kpi = {}
    trend = []

    # (1) Đọc KPI + trend (nếu có)
    if summary_path.exists():
        try:
            with summary_path.open("r", encoding="utf-8") as f:
                summary = json.load(f)
            if isinstance(summary, dict):
                kpi = summary.get("kpi") or {}
                trend = summary.get("trend_crit_high") or summary.get("trend") or []
        except Exception:
            pass

    # (2) Build items bằng cách duyệt RUN_* + findings_unified.json
    items = []

    run_dirs = [
        p for p in out_dir.iterdir()
        if p.is_dir() and p.name.startswith("RUN_")
    ]
    run_dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    for run_dir in run_dirs:
        run_id = run_dir.name
        report_dir = run_dir / "report"
        findings_file = report_dir / "findings_unified.json"
        summary_file = report_dir / "summary_unified.json"

        if not findings_file.exists() and not summary_file.exists():
            continue

        total_findings = None
        run_type = "UNKNOWN"
        source = "FULL_EXT"
        score = None
        started_at = None

        # (2a) Ưu tiên lấy total_findings từ findings_unified.json
        if findings_file.exists():
            try:
                with findings_file.open("r", encoding="utf-8") as f:
                    fd = json.load(f)
                if isinstance(fd, dict):
                    if isinstance(fd.get("items"), list):
                        items_list = fd["items"]
                        total_findings = int(fd.get("total", len(items_list)))
                    elif isinstance(fd.get("findings"), list):
                        items_list = fd["findings"]
                        total_findings = len(items_list)
                elif isinstance(fd, list):
                    total_findings = len(fd)
            except Exception:
                pass

        # (2b) Nếu vẫn chưa có total_findings, fallback sang summary_unified.json
        if total_findings is None and summary_file.exists():
            try:
                with summary_file.open("r", encoding="utf-8") as f:
                    s = json.load(f)
            except Exception:
                s = None

            if isinstance(s, dict):
                total_findings = (
                    s.get("summary_all", {}).get("total_findings")
                    if isinstance(s.get("summary_all"), dict)
                    else None
                )
                if total_findings is None:
                    total_findings = s.get("total_findings")

                if total_findings is None:
                    sev = None
                    if "summary_all" in s and isinstance(s["summary_all"], dict):
                        sev = s["summary_all"].get("by_severity")
                    if sev is None:
                        sev = s.get("by_severity")
                    if isinstance(sev, dict):
                        try:
                            total_findings = int(sum(int(v) for v in sev.values()))
                        except Exception:
                            total_findings = None

                run_profile = s.get("run_profile") if isinstance(s.get("run_profile"), dict) else {}
                run_type = run_profile.get("type") or run_profile.get("run_type") or run_type
                source = run_profile.get("source") or run_profile.get("source_type") or source
                score = s.get("security_posture_score")
                if score is None and isinstance(s.get("summary_all"), dict):
                    score = s["summary_all"].get("security_posture_score")
                started_at = run_profile.get("started_at") or run_profile.get("started") or started_at

        # (2c) Nếu vẫn không có total_findings thì bỏ run này
        if total_findings is None:
            continue

        # (2d) Nếu chưa có started_at thì lấy mtime thư mục
        if not started_at:
            try:
                dt = datetime.datetime.fromtimestamp(run_dir.stat().st_mtime)
                started_at = dt.isoformat(timespec="seconds")
            except Exception:
                started_at = ""

        item = {
            "rid": run_id,
            "run_type": run_type,
            "source": source,
            "total_findings": int(total_findings),
            "security_posture_score": score if isinstance(score, (int, float)) else None,
            "started_at": started_at,
        }
        items.append(item)

    # (3) Áp dụng limit
    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50
    items_slice = items[:limit]

    # (4) Nếu chưa có KPI thì tự build
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = total_findings_sum / float(last_n) if last_n > 0 else 0.0
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    Ưu tiên:
    1) Đọc KPI + trend từ out/summary_by_run.json (nếu có).
    2) Tự quét thư mục out/RUN_* để build danh sách items (list run)
       nên không phụ thuộc schema summary_by_run.json nữa.
    """
    import json
    from pathlib import Path
    from flask import request, jsonify
    import os
    import datetime

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    kpi = {}
    trend = []

    # (1) Đọc KPI + trend (nếu có)
    if summary_path.exists():
        try:
            with summary_path.open("r", encoding="utf-8") as f:
                summary = json.load(f)
            if isinstance(summary, dict):
                kpi = summary.get("kpi") or {}
                trend = summary.get("trend_crit_high") or summary.get("trend") or []
        except Exception:
            pass

    # (2) Quét thư mục RUN_* để build items
    items = []

    # Duyệt tất cả thư mục RUN_* trong out/
    run_dirs = [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_")]
    # Sắp xếp theo thời gian sửa đổi mới nhất (mới -> cũ)
    run_dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    for run_dir in run_dirs:
        run_id = run_dir.name
        report_dir = run_dir / "report"
        summary_file = report_dir / "summary_unified.json"
        if not summary_file.exists():
            continue

        try:
            with summary_file.open("r", encoding="utf-8") as f:
                s = json.load(f)
        except Exception:
            continue

        # Lấy total_findings
        total_findings = None
        # Ưu tiên các kiểu phổ biến
        if isinstance(s, dict):
            # Kiểu summary_all.total_findings
            total_findings = (
                s.get("summary_all", {}).get("total_findings")
                if isinstance(s.get("summary_all"), dict)
                else None
            )
            # Kiểu top-level total_findings
            if total_findings is None:
                total_findings = s.get("total_findings")

            # Nếu vẫn None, thử tính từ by_severity
            if total_findings is None:
                sev = None
                if "summary_all" in s and isinstance(s["summary_all"], dict):
                    sev = s["summary_all"].get("by_severity")
                if sev is None:
                    sev = s.get("by_severity")
                if isinstance(sev, dict):
                    try:
                        total_findings = int(sum(int(v) for v in sev.values()))
                    except Exception:
                        total_findings = None

            # Run type / source
            run_profile = s.get("run_profile") if isinstance(s.get("run_profile"), dict) else {}
            run_type = run_profile.get("type") or run_profile.get("run_type") or "UNKNOWN"
            source = run_profile.get("source") or run_profile.get("source_type") or "FULL_EXT"

            # Score nếu có
            score = s.get("security_posture_score")
            if score is None and isinstance(s.get("summary_all"), dict):
                score = s["summary_all"].get("security_posture_score")

            # Time nếu có
            started_at = run_profile.get("started_at") or run_profile.get("started") or None
        else:
            run_type = "UNKNOWN"
            source = "FULL_EXT"
            score = None
            started_at = None

        # Nếu vẫn chưa có total_findings, bỏ qua run này
        if total_findings is None:
            continue

        # Nếu không có started_at thì lấy mtime thư mục
        if not started_at:
            try:
                dt = datetime.datetime.fromtimestamp(run_dir.stat().st_mtime)
                started_at = dt.isoformat(timespec="seconds")
            except Exception:
                started_at = ""

        item = {
            "rid": run_id,
            "run_type": run_type,
            "source": source,
            "total_findings": int(total_findings),
            "security_posture_score": score if isinstance(score, (int, float)) else None,
            "started_at": started_at,
        }
        items.append(item)

    # (3) Áp dụng limit
    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50
    items_slice = items[:limit]

    # (4) Nếu chưa có KPI thì tự build
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = total_findings_sum / float(last_n) if last_n > 0 else 0.0
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    Đọc summary_by_run.json trong SECURITY_BUNDLE/out và
    expose items + kpi + trend_crit_high cho UI.
    """
    import json
    from pathlib import Path
    from flask import request, jsonify

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    try:
        with summary_path.open("r", encoding="utf-8") as f:
            summary = json.load(f)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Missing {summary_path}"}), 500

    # Chuẩn hóa items theo nhiều kiểu schema khác nhau
    if isinstance(summary, dict):
        raw_items = (
            summary.get("items")
            or summary.get("by_run")
            or summary.get("runs")
            or summary.get("data")
        )
        if isinstance(raw_items, list):
            items = raw_items
        else:
            items = []
        kpi = summary.get("kpi") or {}
        trend = summary.get("trend_crit_high") or summary.get("trend") or []
    else:
        items = summary if isinstance(summary, list) else []
        kpi = {}
        trend = []

    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50

    items_slice = items[:limit]

    # Nếu summary_by_run.json chưa có kpi ⇒ tự tính KPI cơ bản
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = total_findings_sum / float(last_n) if last_n > 0 else 0.0
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    Đọc summary_by_run.json trong SECURITY_BUNDLE/out và
    expose items + kpi + trend_crit_high cho UI.
    """
    import json
    from pathlib import Path
    from flask import request, jsonify

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    try:
        with summary_path.open("r", encoding="utf-8") as f:
            summary = json.load(f)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Missing {summary_path}"}), 500

    if isinstance(summary, dict):
        items = summary.get("items") or []
        kpi = summary.get("kpi") or {}
        trend = summary.get("trend_crit_high") or []
    else:
        items = summary
        kpi = {}
        trend = []

    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50

    items_slice = items[:limit]

    # Nếu summary_by_run.json chưa có kpi ⇒ tự tính KPI cơ bản
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = (
                total_findings_sum / float(last_n) if last_n > 0 else 0.0
            )
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    return proxy_get("/api/vsp/runs_index_v3")



@app.route("/api/vsp/datasource_v2")
def api_vsp_datasource_v2():
    """
    Local implementation cho Data Source tab (VSP 2025 UI demo).

    Thay vì proxy sang core, route này đọc trực tiếp
    findings_unified.json của latest FULL_EXT run trong
    SECURITY_BUNDLE/out.
    """
    import json
    from pathlib import Path
    from flask import request, jsonify

    # SECURITY_BUNDLE root = parent của thư mục ui/
    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"

    dash_path = out_dir / "vsp_dashboard_v3_latest.json"
    try:
        with dash_path.open("r", encoding="utf-8") as f:
            dash = json.load(f)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Missing {dash_path}"}), 500

    latest_run = dash.get("latest_run_id")
    if not latest_run:
        return jsonify(
            {"ok": False, "error": "No latest_run_id in vsp_dashboard_v3_latest.json"}
        ), 500

    findings_path = out_dir / latest_run / "report" / "findings_unified.json"
    try:
        with findings_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return jsonify(
            {
                "ok": False,
                "error": f"Missing findings_unified.json for run {latest_run}",
            }
        ), 500

    # data có thể là list hoặc {items: [...], total: N}
    if isinstance(data, dict) and "items" in data:
        items = data.get("items") or []
        total = int(data.get("total", len(items)))
    else:
        items = data
        total = len(items)

    try:
        limit = int(request.args.get("limit", 100))
    except Exception:
        limit = 100

    items_slice = items[:limit]

    return jsonify(
        {
            "ok": True,
            "rid": latest_run,
            "total": total,
            "limit": limit,
            "items": items_slice,
        }
    )
def api_vsp_datasource_v2():
    # Proxy đúng sang core, giữ nguyên run_dir, limit, filters,...
    return proxy_get("/api/vsp/datasource_v2")


# === RUN FULL SCAN EXT+ – gọi bin/vsp_selfcheck_full.sh ===

@app.route("/api/vsp/run_full_scan", methods=["POST", "OPTIONS"])
def api_vsp_run_full_scan():
    """
    Nhận JSON:
      {
        "profile": "EXT" | "FAST" | "AGGR" | "FULL" | ...,
        "source_root": "/home/test/Data/khach6",
        "target_url": "https://demo.demasterpro.com"
      }

    Gọi: bin/vsp_selfcheck_full.sh <profile> <source_root> <target_url>
    cwd = /home/test/Data/SECURITY_BUNDLE
    """
    if request.method == "OPTIONS":
        # Đơn giản trả 200 cho preflight nếu có
        return ("", 200)

    data = request.get_json(silent=True) or {}

    profile = data.get("profile") or "FULL_EXT"
    source_root = data.get("source_root") or data.get("src_path") or str(ROOT / "khach6")
    target_url = data.get("target_url") or data.get("url") or "https://demo.demasterpro.com"

    script = ROOT / "bin" / "vsp_selfcheck_full.sh"

    if not script.is_file():
        return jsonify(
            ok=False,
            error=f"Script không tồn tại: {script}",
        ), 500

    # Đảm bảo script có quyền execute
    try:
        os.chmod(str(script), 0o755)
    except Exception:
        pass

    try:
        proc = subprocess.Popen(
            [str(script), profile, source_root, target_url],
            cwd=str(ROOT),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as e:
        return jsonify(ok=False, error=f"Lỗi chạy {script}: {e}"), 500

    return jsonify(
        ok=True,
        pid=proc.pid,
        profile=profile,
        source_root=source_root,
        target_url=target_url,
    )


# === Healthcheck đơn giản (tuỳ chọn) ===
@app.route("/health")
def health():
    return jsonify(ok=True, app="vsp_demo_app", core=CORE_BASE)


# VSP_RUN_EXPORT_DIRECT_V1_BEGIN
from flask import send_file, request, jsonify, render_template
import io, json, zipfile, subprocess, shutil
from pathlib import Path

@app.route("/api/vsp/settings_v1", methods=["GET", "POST"])

def _settings_file_path():
    import os
    # Cho phép override bằng env nếu cần
    path = os.environ.get("VSP_SETTINGS_FILE")
    if path:
        return path
    return os.path.join(os.path.dirname(__file__), "config", "settings_v1.json")


def _load_settings_from_file():
    import json, os
    path = _settings_file_path()
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        # Nếu file hỏng thì trả rỗng để UI còn tự fill mặc định
        return {}


def _save_settings_to_file(data):
    import json, os
    path = _settings_file_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

@app.route("/api/vsp/settings_ui_v1", methods=["GET", "POST"])
def vsp_settings_ui_v1():
    """
    Settings API cho UI:
    - GET  -> trả JSON {ok: true, settings: {...}}
    - POST -> nhận {settings: {...}} hoặc object raw, lưu file rồi trả lại JSON.
    """
    from flask import request, jsonify

    if request.method == "GET":
        settings = _load_settings_from_file()
        return jsonify({"ok": True, "settings": settings})

    payload = request.get_json(silent=True) or {}
    # Nếu payload dạng {settings: {...}} thì lấy bên trong, còn không thì dùng cả object
    if isinstance(payload, dict) and "settings" in payload and isinstance(payload["settings"], dict):
        settings = payload["settings"]
    else:
        settings = payload

    _save_settings_to_file(settings)
    return jsonify({"ok": True, "settings": settings})


def vsp_settings_v1():
    """GET/POST settings trực tiếp trên gateway 8910 (lưu file JSON)."""
    if request.method == "GET":
        settings = _load_settings_from_file()
        return jsonify(ok=True, settings=settings)

    payload = request.get_json(silent=True) or {}
    try:
        _SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        _SETTINGS_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    return jsonify(ok=True)




    """
    UI-only wrapper cho file config/rule_overrides_v1.json.
    Dùng riêng cho tab Rules trên VSP_UI 2025.
    """
    import os, json, flask

    cfg_dir = os.path.join(os.path.dirname(__file__), "config")
    cfg_path = os.path.join(cfg_dir, "rule_overrides_v1.json")

    # POST: lưu overrides từ UI
    if flask.request.method == "POST":
        try:
            body = flask.request.get_json(force=True, silent=False)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc)), 400

        # Hỗ trợ các format:
        # - { "items": [...] }
        # - { "overrides": [...] }
        # - [ ... ]
        data = body
        if isinstance(body, dict):
            if "items" in body:
                data = body["items"]
            elif "overrides" in body:
                data = body["overrides"]

        os.makedirs(cfg_dir, exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return flask.jsonify(ok=True)

    # GET: đọc file, nếu chưa có thì trả [] để UI render bảng trống
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc), items=[], overrides=[], raw=None), 200
    else:
        raw = []

    # Chuẩn hóa: luôn có items + overrides
    if isinstance(raw, dict):
        items = raw.get("items") or raw.get("overrides") or raw
    else:
        items = raw

    return flask.jsonify(ok=True, items=items, overrides=items, raw=raw)
@app.route("/api/vsp/rule_overrides_ui_v1", methods=["GET", "POST", "OPTIONS"])
def vsp_rule_overrides_ui_v1():
    """
    UI-only wrapper cho file config/rule_overrides_v1.json.
    Dùng riêng cho tab Rules trên VSP_UI 2025.
    """
    import os, json, flask

    cfg_dir = os.path.join(os.path.dirname(__file__), "config")
    cfg_path = os.path.join(cfg_dir, "rule_overrides_v1.json")

    # POST: lưu overrides từ UI
    if flask.request.method == "POST":
        try:
            body = flask.request.get_json(force=True, silent=False)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc)), 400

        # Hỗ trợ các format:
        # - { "items": [...] }
        # - { "overrides": [...] }
        # - [ ... ]
        data = body
        if isinstance(body, dict):
            if "items" in body:
                data = body["items"]
            elif "overrides" in body:
                data = body["overrides"]

        os.makedirs(cfg_dir, exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return flask.jsonify(ok=True)

    # GET: đọc file, nếu chưa có thì trả [] để UI render bảng trống
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc), items=[], overrides=[], raw=None), 200
    else:
        raw = []

    # Chuẩn hóa: luôn có items + overrides
    if isinstance(raw, dict):
        items = raw.get("items") or raw.get("overrides") or raw
    else:
        items = raw

    return flask.jsonify(ok=True, items=items, overrides=items, raw=raw)

@app.route("/api/vsp/run_export_v3", methods=["GET"])
def vsp_run_export_v3():
    """
    Direct export HTML/ZIP/PDF/CSV cho 1 run - chạy trên UI gateway (8910).
    """
    from flask import request, jsonify, send_file
    import os, io, zipfile, json

    run_id = (request.args.get("run_id") or "").strip()
    fmt = (request.args.get("fmt") or "html").strip().lower()

    if not run_id:
        return jsonify({"ok": False, "error": "Missing run_id"}), 400

    # Thư mục out gốc: ưu tiên env VSP_OUT_ROOT, fallback ../out cạnh ui/
    base_out = os.environ.get("VSP_OUT_ROOT")
    if not base_out:
        base_out = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "out"))

    run_dir = os.path.join(base_out, run_id)
    if not os.path.isdir(run_dir):
        return jsonify({"ok": False, "error": f"Run dir not found: {run_dir}"}), 404

    report_dir = os.path.join(run_dir, "report")

    # HTML export
    if fmt == "html":
        candidates = [
            os.path.join(report_dir, "vsp_run_report_cio_v3.html"),
            os.path.join(report_dir, "vsp_run_report_cio_v2.html"),
            os.path.join(report_dir, "vsp_run_report_cio.html"),
            os.path.join(report_dir, "run_report.html"),
        ]
        for path in candidates:
            if os.path.isfile(path):
                return send_file(
                    path,
                    mimetype="text/html",
                    as_attachment=False,
                    download_name=os.path.basename(path),
                )

        # fallback – render summary_unified.json thành HTML đơn giản
        summary_path = os.path.join(report_dir, "summary_unified.json")
        summary = {}
        if os.path.isfile(summary_path):
            try:
                with open(summary_path, "r", encoding="utf-8") as f:
                    summary = json.load(f)
            except Exception:
                summary = {}

        body = json.dumps(
            summary or {"note": "No summary_unified.json found"},
            indent=2,
            ensure_ascii=False,
        )

        html = (
            "<html><head><meta charset='utf-8'>"
            "<title>VSP run {run_id}</title></head><body>"
            "<h1>VSP run {run_id}</h1>"
            "<pre>{body}</pre>"
            "</body></html>"
        ).format(run_id=run_id, body=body)

        return html

    # CSV export
    if fmt == "csv":
        csv_path = os.path.join(report_dir, "findings_unified.csv")
        if os.path.isfile(csv_path):
            return send_file(
                csv_path,
                mimetype="text/csv",
                as_attachment=True,
                download_name=f"{run_id}_findings.csv",
            )
        return jsonify({"ok": False, "error": "findings_unified.csv not found"}), 404

    # ZIP export
    if fmt == "zip":
        if not os.path.isdir(report_dir):
            return jsonify({"ok": False, "error": "report dir not found"}), 404

        mem = io.BytesIO()
        with zipfile.ZipFile(mem, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(report_dir):
                for fn in files:
                    full = os.path.join(root, fn)
                    rel = os.path.relpath(full, run_dir)
                    zf.write(full, rel)

        mem.seek(0)
        return send_file(
            mem,
            mimetype="application/zip",
            as_attachment=True,
            download_name=f"{run_id}_report.zip",
        )

    # PDF export (nếu có sẵn file PDF trong report/)
    if fmt == "pdf":
        if os.path.isdir(report_dir):
            for name in os.listdir(report_dir):
                if name.lower().endswith(".pdf"):
                    path = os.path.join(report_dir, name)
                    return send_file(
                        path,
                        mimetype="application/pdf",
                        as_attachment=True,
                        download_name=name,
                    )
        return jsonify({"ok": False, "error": "PDF report not found"}), 404

    return jsonify({"ok": False, "error": f"Unsupported fmt={fmt}"}), 400



@app.route("/api/vsp/run_fullscan_v1", methods=["POST"])
def vsp_run_fullscan_v1():
    """
    Nhận source_root / target_url / profile / mode từ UI,
    gọi shell wrapper vsp_run_fullscan_from_api_v1.sh chạy background.
    """
    import subprocess
    from pathlib import Path
    from flask import request, jsonify

    payload = request.get_json(force=True) or {}
    source_root = payload.get("source_root") or ""
    target_url = payload.get("target_url") or ""
    profile = payload.get("profile") or "FULL_EXT"
    mode = payload.get("mode") or "EXT_ONLY"

    wrapper = Path(__file__).resolve().parent.parent / "bin" / "vsp_run_fullscan_from_api_v1.sh"

    proc = subprocess.Popen(
        [str(wrapper), profile, mode, source_root, target_url],
        cwd=str(wrapper.parent.parent),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    app.logger.info("[VSP_RUN_FULLSCAN_API] payload=%s pid=%s", payload, proc.pid)

    return jsonify({
        "ok": True,
        "pid": proc.pid,
        "profile": profile,
        "mode": mode,
    })



@app.route("/api/vsp/rule_overrides_v1", methods=["GET", "POST"], endpoint="vsp_rule_overrides_v1_api_ui")
def vsp_rule_overrides_v1_api():
    """Simple file-based storage cho rule_overrides_v1.

    File lưu tại: ../config/rule_overrides_v1.json (tính từ thư mục ui/).
    """
    root = _VSP_Path2(__file__).resolve().parent.parent  # .../SECURITY_BUNDLE
    cfg_dir = root / "config"
    cfg_dir.mkdir(exist_ok=True)
    cfg_file = cfg_dir / "rule_overrides_v1.json"

    if request.method == "GET":
        if cfg_file.exists():
            try:
                data = _vsp_json2.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception as exc:  # pragma: no cover
                app.logger.warning("Invalid rule_overrides_v1.json: %s", exc)
                data = []
        else:
            data = []
        return jsonify(data)

    payload = request.get_json(force=True, silent=True)
    if payload is None:
        payload = []

    to_save = payload
    try:
        cfg_file.write_text(
            _vsp_json2.dumps(to_save, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception as exc:  # pragma: no cover
        app.logger.error("Cannot write rule_overrides_v1.json: %s", exc)
        return jsonify({"ok": False, "error": str(exc)}), 500

    return jsonify(to_save)

# === VSP Rule Overrides UI API stub V1 ===
from pathlib import Path as _VSP_Path_UI
import json as _vsp_json_ui



@app.route("/api/vsp/rule_overrides_ui_v1", methods=["GET", "POST"])
def vsp_rule_overrides_ui_v1_force():
    app.logger.info("[VSP_RULES_UI] stub handler active (vsp_rule_overrides_ui_v1_force)")
    root = _VSP_Path_UI2(__file__).resolve().parent.parent  # .../SECURITY_BUNDLE
    cfg_dir = root / "config"
    cfg_dir.mkdir(exist_ok=True)
    cfg_file = cfg_dir / "rule_overrides_v1.json"

    if request.method == "GET":
        if cfg_file.exists():
            try:
                data = _vsp_json_ui2.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception as exc:  # pragma: no cover
                app.logger.warning("Invalid rule_overrides_v1.json: %s", exc)
                data = []
        else:
            data = []
        return jsonify(data)

    payload = request.get_json(force=True, silent=True)
    if payload is None:
        payload = []

    to_save = payload
    try:
        cfg_file.write_text(
            _vsp_json_ui2.dumps(to_save, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception as exc:  # pragma: no cover
        app.logger.error("Cannot write rule_overrides_v1.json: %s", exc)
        return jsonify({"ok": False, "error": str(exc)}), 500

    return jsonify(to_save)




    """
    UI-only wrapper cho file config/rule_overrides_v1.json.
    Dùng riêng cho tab Rules trên VSP_UI 2025.
    """
    import os, json, flask

    cfg_dir = os.path.join(os.path.dirname(__file__), "config")
    cfg_path = os.path.join(cfg_dir, "rule_overrides_v1.json")

    # POST: lưu overrides từ UI
    if flask.request.method == "POST":
        try:
            body = flask.request.get_json(force=True, silent=False)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc)), 400

        # Hỗ trợ vài format:
        # - { "items": [...] }
        # - { "overrides": [...] }
        # - [ ... ]
        data = body
        if isinstance(body, dict):
            if "items" in body:
                data = body["items"]
            elif "overrides" in body:
                data = body["overrides"]

        os.makedirs(cfg_dir, exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return flask.jsonify(ok=True)

    # GET: đọc file, nếu chưa có thì trả [] để UI render bảng trống
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc), items=[], overrides=[], raw=None), 200
    else:
        raw = []

    # Chuẩn hóa: luôn có items + overrides
    if isinstance(raw, dict):
        items = raw.get("items") or raw.get("overrides") or raw
    else:
        items = raw

    return flask.jsonify(ok=True, items=items, overrides=items, raw=raw)


@app.route("/api/vsp/dashboard_extras_v1")
def vsp_dashboard_extras_v1():
    """Extras cho Dashboard: top findings, noisy paths, CVE, by_tool – stub V1.

    V1 chỉ wrap lại /api/vsp/dashboard_v3 nếu có, để UI có data tối thiểu.
    Sau này có thể mở rộng để đọc trực tiếp findings_unified.json.
    """
    from flask import jsonify

    base = {}
    try:
        # Gọi lại dashboard_v3 để lấy latest_run_id, by_tool...
        with app.test_client() as c:
            r = c.get("/api/vsp/dashboard_v3")
            if r.is_json:
                base = r.get_json() or {}
    except Exception as e:
        base = {"error": str(e)}

    by_tool = (
        base.get("by_tool")
        or base.get("summary_by_tool")
        or {}
    )

    payload = {
        "ok": True,
        "latest_run_id": base.get("latest_run_id"),
        # Các field này V1 có thể rỗng, UI sẽ hiển thị 'No data'
        "top_risky": base.get("top_risky") or [],
        "top_noisy_paths": base.get("top_noisy_paths") or [],
        "top_cves": base.get("top_cves") or [],
        "by_tool_severity": by_tool,
    }
    return jsonify(payload)


@app.route("/api/vsp/datasource_export_v1")
def vsp_datasource_export_v1():
    """Export findings_unified cho Data Source – V1: JSON + CSV.

    - Nếu có run_dir trong query thì dùng run_dir đó.
    - Nếu không, dùng latest_run_id từ /api/vsp/dashboard_v3.
    """

    from flask import request, jsonify, send_file
    import json
    import csv
    import tempfile

    ui_root = Path(__file__).resolve().parent
    bundle_root = ui_root.parent
    out_root = bundle_root / "out"

    fmt = (request.args.get("fmt") or "json").strip().lower()
    run_dir_arg = (request.args.get("run_dir") or "").strip()

    run_dir = None

    if run_dir_arg:
        run_dir = Path(run_dir_arg)
    else:
        # Lấy latest_run_id từ dashboard_v3
        try:
            with app.test_client() as c:
                r = c.get("/api/vsp/dashboard_v3")
                if r.is_json:
                    data = r.get_json() or {}
                else:
                    data = {}
            latest_run_id = data.get("latest_run_id")
            if latest_run_id:
                run_dir = out_root / latest_run_id
        except Exception as e:
            return jsonify(ok=False, error=f"Không lấy được latest_run_id: {e}"), 500

    if run_dir is None:
        return jsonify(ok=False, error="Không xác định được run_dir"), 400

    if not run_dir.is_dir():
        return jsonify(ok=False, error=f"Run dir not found: {run_dir}"), 404

    report_dir = run_dir / "report"
    findings_path = report_dir / "findings_unified.json"

    if not findings_path.is_file():
        return jsonify(ok=False, error=f"Không tìm thấy findings_unified.json trong {report_dir}"), 404

    if fmt == "json":
        # Trả thẳng file JSON
        return send_file(
            findings_path,
            mimetype="application/json",
            as_attachment=True,
            download_name=f"{run_dir.name}_findings_unified.json",
        )

    if fmt == "csv":
        # Convert JSON -> CSV với các cột chuẩn
        try:
            items = json.loads(findings_path.read_text(encoding="utf-8"))
        except Exception as e:
            return jsonify(ok=False, error=f"Không đọc được JSON: {e}"), 500

        if not isinstance(items, list):
            return jsonify(ok=False, error="findings_unified.json không phải là list"), 500

        # Giữ schema giống Data Source ext columns
        fieldnames = [
            "severity",
            "tool",
            "rule",
            "path",
            "line",
            "message",
            "run",
            "cwe",
            "cve",
            "component",
            "tags",
            "fix",
        ]

        def norm_sev(s):
            if not s:
                return ""
            up = str(s).upper()
            known = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "TRACE"]
            return up if up in known else str(s)

        def extract_line(item):
            if "line" in item and item["line"] is not None:
                return item["line"]
            if "line_number" in item and item["line_number"] is not None:
                return item["line_number"]
            loc = item.get("location") or {}
            if isinstance(loc, dict) and "line" in loc:
                return loc["line"]
            return ""

        def extract_rule(item):
            for k in ["rule_id", "rule", "check_id", "check", "rule_name", "id"]:
                if k in item and item[k]:
                    return item[k]
            return ""

        def extract_msg(item):
            for k in ["message", "msg", "description", "title"]:
                if k in item and item[k]:
                    return item[k]
            return ""

        def extract_run(item):
            for k in ["run_id", "run", "run_ref"]:
                if k in item and item[k]:
                    return item[k]
            return ""

        def extract_cwe(item):
            if item.get("cwe"):
                return item["cwe"]
            if item.get("cwe_id"):
                return item["cwe_id"]
            if isinstance(item.get("cwe_list"), list) and item["cwe_list"]:
                return ",".join(map(str, item["cwe_list"]))
            return ""

        def extract_cve(item):
            if item.get("cve"):
                return item["cve"]
            for k in ["cve_list", "cves"]:
                v = item.get(k)
                if isinstance(v, list) and v:
                    return ",".join(map(str, v))
            return ""

        def extract_component(item):
            for k in ["component", "module", "package", "image"]:
                if item.get(k):
                    return item[k]
            return ""

        def extract_tags(item):
            tags = item.get("tags") or item.get("labels")
            if not tags:
                return ""
            if isinstance(tags, list):
                return ",".join(map(str, tags))
            return str(tags)

        def extract_fix(item):
            for k in ["fix", "remediation", "recommendation"]:
                if item.get(k):
                    return item[k]
            return ""

        tmp = tempfile.NamedTemporaryFile(mode="w+", suffix=".csv", delete=False, encoding="utf-8", newline="")
        tmp_path = Path(tmp.name)

        writer = csv.DictWriter(tmp, fieldnames=fieldnames)
        writer.writeheader()

        for it in items:
            if not isinstance(it, dict):
                continue
            row = {
                "severity": norm_sev(it.get("severity") or it.get("level")),
                "tool": it.get("tool") or it.get("source") or it.get("scanner") or "",
                "rule": extract_rule(it),
                "path": it.get("path") or it.get("file") or it.get("location") or "",
                "line": extract_line(it),
                "message": extract_msg(it),
                "run": extract_run(it),
                "cwe": extract_cwe(it),
                "cve": extract_cve(it),
                "component": extract_component(it),
                "tags": extract_tags(it),
                "fix": extract_fix(it),
            }
            writer.writerow(row)

        tmp.flush()
        tmp.close()

        return send_file(
            tmp_path,
            mimetype="text/csv",
            as_attachment=True,
            download_name=f"{run_dir.name}_findings_unified.csv",
        )

    return jsonify(ok=False, error=f"Unsupported fmt={fmt} (chỉ hỗ trợ json|csv trong V1)"), 400

@app.route("/api/vsp/dashboard_v3", methods=["GET"])
def vsp_dashboard_v3():
    """
    Dashboard V3:
      - Chọn run theo:
        + Pin trong vsp_dashboard_pin_v1.json, hoặc
        + FULL_EXT mới nhất có summary_unified.json
      - Trả total_findings + by_severity + by_tool
    """
    import json
    from flask import request, jsonify

    run_id = request.args.get("run_id") or pick_dashboard_run()

    if not run_id:
        return jsonify({
            "ok": False,
            "error": "No FULL_EXT run with summary_unified.json found",
            "latest_run_id": None,
        }), 500

    summary_file = (OUT_DIR / run_id / "report" / "summary_unified.json")

    if not summary_file.is_file():
        return jsonify({
            "ok": False,
            "error": f"summary_unified.json not found for {run_id}",
            "latest_run_id": run_id,
        }), 500

    summary = json.loads(summary_file.read_text(encoding="utf-8"))

    data = {
        "ok": True,
        "latest_run_id": run_id,
        "total_findings": sum(
            s.get("count", 0) for s in summary.get("summary_by_severity", {}).values()
        ),
        "by_severity": summary["summary_by_severity"],
        "by_tool": summary.get("by_tool", {}),
    }
    return jsonify(data)




# ==== VSP_METRICS_AFTER_REQUEST_V1 ====
# Inject KPI cho /api/vsp/dashboard_v3 và /api/vsp/runs_index_v3
# Không phá code cũ – chỉ chỉnh JSON response sau khi route xử lý xong.

from flask import request
import json as _vsp_json
import pathlib as _vsp_pathlib

SEVERITY_BUCKETS = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "TRACE"]

_VSP_ROOT = _vsp_pathlib.Path(__file__).resolve().parents[1]


def _vsp_build_severity_cards(by_sev):
    """Chuẩn hoá by_severity thành đầy đủ 6 bucket."""
    cards = {sev: 0 for sev in SEVERITY_BUCKETS}
    if not isinstance(by_sev, dict):
        return cards
    for sev, v in by_sev.items():
        if sev not in cards:
            continue
        if isinstance(v, dict):
            n = v.get("count") or v.get("total") or 0
        else:
            n = v
        try:
            cards[sev] = int(n)
        except Exception:
            pass
    return cards


def _vsp_security_score_simple(cards):
    """Score 0–100, càng nhiều CRIT/HIGH thì trừ điểm mạnh."""
    crit = cards.get("CRITICAL", 0)
    high = cards.get("HIGH", 0)
    med = cards.get("MEDIUM", 0)
    low = cards.get("LOW", 0)

    # model đơn giản: mỗi CRIT trừ 8, HIGH trừ 4, MED trừ 2, LOW trừ 1
    penalty = crit * 8 + high * 4 + med * 2 + low * 1
    score = 100 - penalty
    if score < 0:
        score = 0
    if score > 100:
        score = 100
    return int(score)


def vsp_metrics_after_request_v1(resp):
    """Bơm thêm KPI vào dashboard_v3 & runs_index_v3."""
    try:
        path = request.path
    except Exception:
        return resp

    # Chỉ xử lý JSON của namespace /api/vsp/
    if not getattr(resp, "is_json", False):
        return resp
    if not (isinstance(path, str) and path.startswith("/api/vsp/")):
        return resp

    try:
        data = resp.get_json(silent=True)
    except Exception:
        return resp

    changed = False

    # ===== 1) DASHBOARD V3 KPI =====
    if path == "/api/vsp/dashboard_v3" and isinstance(data, dict):
        by_sev = data.get("by_severity") or {}
        cards = _vsp_build_severity_cards(by_sev)

        if not data.get("severity_cards"):
            data["severity_cards"] = cards
            changed = True

        if "security_posture_score" not in data or data.get("security_posture_score") is None:
            data["security_posture_score"] = _vsp_security_score_simple(cards)
            changed = True

        # Alias cho field top_* nếu backend chỉ có top_cwe, top_module
        if "top_risky_tool" not in data:
            data["top_risky_tool"] = data.get("top_risky_tool") or data.get("top_tool")
        if "top_impacted_cwe" not in data:
            data["top_impacted_cwe"] = data.get("top_impacted_cwe") or data.get("top_cwe")
        if "top_vulnerable_module" not in data:
            data["top_vulnerable_module"] = data.get("top_vulnerable_module") or data.get("top_module")
        changed = True

    # ===== 2) RUNS_INDEX V3 KPI (dùng summary_by_run.json) =====
    if path == "/api/vsp/runs_index_v3" and isinstance(data, dict):
        summary_path = _VSP_ROOT / "out" / "summary_by_run.json"
        s = {}
        try:
            if summary_path.is_file():
                s = _vsp_json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[VSP_METRICS] Lỗi đọc {summary_path}: {e}")

        kpi = s.get("kpi")
        trend = s.get("trend_crit_high")

        if "kpi" not in data and kpi is not None:
            data["kpi"] = kpi
            changed = True
        if "trend_crit_high" not in data and trend is not None:
            data["trend_crit_high"] = trend
            changed = True

    if not changed:
        return resp

    # Ghi lại body JSON mới
    try:
        new_body = _vsp_json.dumps(data, ensure_ascii=False)
        resp.set_data(new_body)
        resp.mimetype = "application/json"
        resp.headers["Content-Type"] = "application/json; charset=utf-8"
        resp.headers["Content-Length"] = str(len(new_body.encode("utf-8")))
    except Exception as e:
        print(f"[VSP_METRICS] Lỗi set_data: {e}")
    return resp

# ==== END VSP_METRICS_AFTER_REQUEST_V1 ====



# ========== VSP_METRICS_TOP_V1 START ==========
import json
import logging
from collections import Counter
from pathlib import Path
from flask import request

logger = logging.getLogger(__name__)

_VSP_RISKY_SEVERITIES_TOP = {"CRITICAL", "HIGH"}

def _vsp_root_dir_from_ui_top():
    try:
        return Path(__file__).resolve().parent.parent
    except Exception:
        return Path(".")

def _vsp_find_report_dir_top(latest_run_id):
    try:
        root = _vsp_root_dir_from_ui_top()
        report_dir = root / "out" / latest_run_id / "report"
        if report_dir.is_dir():
            return report_dir
    except Exception as exc:
        logger.warning("[VSP_METRICS_TOP] Cannot resolve report dir for %s: %s", latest_run_id, exc)
    return None

def _vsp_load_findings_top(report_dir):
    f = report_dir / "findings_unified.json"
    if not f.exists():
        logger.info("[VSP_METRICS_TOP] %s không tồn tại – bỏ qua top_*", f)
        return []

    try:
        data = json.loads(f.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("[VSP_METRICS_TOP] Lỗi đọc %s: %s", f, exc)
        return []

    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        if isinstance(data.get("findings"), list):
            return data["findings"]
        if isinstance(data.get("items"), list):
            return data["items"]
    return []

def _vsp_extract_cwe_top(f):
    # 1) Field trực tiếp
    for key in ("cwe_id", "cwe", "cwe_code", "cweid"):
        val = f.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
        if isinstance(val, list) and val:
            first = val[0]
            if isinstance(first, str) and first.strip():
                return first.strip()
            if isinstance(first, dict):
                for kk in ("id", "code", "name"):
                    v2 = first.get(kk)
                    if isinstance(v2, str) and v2.strip():
                        return v2.strip()

    # 2) Danh sách cwes / cwe_ids
    for key in ("cwes", "cwe_ids"):
        val = f.get(key)
        if isinstance(val, list) and val:
            first = val[0]
            if isinstance(first, str) and first.strip():
                return first.strip()
            if isinstance(first, dict):
                for kk in ("id", "code", "name"):
                    v2 = first.get(kk)
                    if isinstance(v2, str) and v2.strip():
                        return v2.strip()

    # 3) Bên trong extra / metadata
    for key in ("extra", "metadata", "details"):
        sub = f.get(key)
        if isinstance(sub, dict):
            for kk in ("cwe_id", "cwe", "cwe_code", "cweid"):
                val = sub.get(kk)
                if isinstance(val, str) and val.strip():
                    return val.strip()
                if isinstance(val, list) and val:
                    first = val[0]
                    if isinstance(first, str) and first.strip():
                        return first.strip()
                    if isinstance(first, dict):
                        for k2 in ("id", "code", "name"):
                            v2 = first.get(k2)
                            if isinstance(v2, str) and v2.strip():
                                return v2.strip()

    # 4) Tìm trong tags/labels có "CWE-"
    for key in ("tags", "labels", "categories"):
        val = f.get(key)
        if isinstance(val, list):
            for item in val:
                if isinstance(item, str) and "CWE-" in item.upper():
                    return item.strip()

    return None

def _vsp_extract_module_top(f):
    # 1) Các key phổ biến cho module/dependency
    for key in (
        "dependency",
        "package",
        "package_name",
        "module",
        "component",
        "image",
        "image_name",
        "target",
        "resource",
        "resource_name",
        "artifact",
    ):
        val = f.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()

    # 2) Một số tool gói trong extra/metadata
    for key in ("extra", "metadata", "details"):
        sub = f.get(key)
        if isinstance(sub, dict):
            for kk in (
                "dependency",
                "package",
                "package_name",
                "module",
                "component",
                "image",
                "image_name",
                "target",
                "resource",
                "resource_name",
                "artifact",
            ):
                val = sub.get(kk)
                if isinstance(val, str) and val.strip():
                    return val.strip()

    # 3) Fallback: dùng đường dẫn file như "module"
    for key in ("file", "filepath", "path", "location"):
        val = f.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()

    return None

def _vsp_accumulate_top_metrics(findings, risky_only):
    by_tool = Counter()
    by_cwe = Counter()
    by_module = Counter()

    for item in findings:
        if not isinstance(item, dict):
            continue
        sev = str(item.get("severity", "")).upper()
        if risky_only and sev not in _VSP_RISKY_SEVERITIES_TOP:
            continue

        # Tool / engine
        tool = (
            item.get("tool")
            or item.get("source")
            or item.get("scanner")
            or item.get("engine")
            or item.get("engine_id")
            or item.get("provider")
        )
        if isinstance(tool, str) and tool.strip():
            by_tool[tool.strip()] += 1

        cwe = _vsp_extract_cwe_top(item)
        if cwe:
            by_cwe[cwe] += 1

        module = _vsp_extract_module_top(item)
        if module:
            by_module[module] += 1

    return by_tool, by_cwe, by_module

def _vsp_compute_top_metrics_top(latest_run_id):
    report_dir = _vsp_find_report_dir_top(latest_run_id)
    if not report_dir:
        return {}

    findings = _vsp_load_findings_top(report_dir)
    if not findings:
        return {}

    # Pass 1: chỉ CRITICAL/HIGH
    by_tool, by_cwe, by_module = _vsp_accumulate_top_metrics(findings, risky_only=True)

    # Nếu CWE/module không có thì fallback dùng tất cả severity
    if not by_cwe or not by_module:
        by_tool_all, by_cwe_all, by_module_all = _vsp_accumulate_top_metrics(findings, risky_only=False)
        if not by_tool and by_tool_all:
            by_tool = by_tool_all
        if not by_cwe and by_cwe_all:
            by_cwe = by_cwe_all
        if not by_module and by_module_all:
            by_module = by_module_all

    result = {}

    if by_tool:
        tool, n = by_tool.most_common(1)[0]
        result["top_risky_tool"] = {
            "id": tool,
            "label": tool,
            "crit_high": int(n),
        }

    if by_cwe:
        cwe, n = by_cwe.most_common(1)[0]
        result["top_impacted_cwe"] = {
            "id": cwe,
            "label": cwe,
            "count": int(n),
        }

    if by_module:
        module, n = by_module.most_common(1)[0]
        result["top_vulnerable_module"] = {
            "id": module,
            "label": module,
            "count": int(n),
        }

    return result

def vsp_metrics_after_request_top_v1(response):
    # Hậu xử lý riêng cho Dashboard V3 để bơm top_* nếu thiếu.
    try:
        path = request.path
    except RuntimeError:
        return response

    if path != "/api/vsp/dashboard_v3":
        return response

    mimetype = response.mimetype or ""
    if not mimetype.startswith("application/json"):
        return response

    try:
        data = json.loads(response.get_data(as_text=True) or "{}")
    except Exception:
        logger.warning("[VSP_METRICS_TOP] Không parse được JSON từ %s", path)
        return response

    latest_run_id = data.get("latest_run_id")
    if not isinstance(latest_run_id, str) or not latest_run_id:
        return response

    top = _vsp_compute_top_metrics_top(latest_run_id)
    if not top:
        return response

    for key in ("top_risky_tool", "top_impacted_cwe", "top_vulnerable_module"):
        if key in top and not data.get(key):
            data[key] = top[key]

    new_body = json.dumps(data, ensure_ascii=False).encode("utf-8")
    response.set_data(new_body)
    response.headers["Content-Length"] = str(len(new_body))
    return response

# ========== VSP_METRICS_TOP_V1 END ==========
# == VSP_TABS_ROUTER_INJECT_ANY_V1 ==
def vsp_tabs_router_inject_any(response):
    """Inject router JS vào TẤT CẢ response text/html.
    Không phụ thuộc id vsp-dashboard-main nữa.
    """
    try:
        ctype = response.headers.get("Content-Type", "")
        if "text/html" not in ctype.lower():
            return response

        body = response.get_data(as_text=True)

        # Nếu đã có script rồi thì thôi
        if "vsp_tabs_hash_router_v1.js" in body:
            return response

        if "</body>" not in body:
            return response

        body = body.replace(
            "</body>",
            '  <script src="/static/js/vsp_tabs_hash_router_v1.js" defer></script>\n</body>'
        )
        response.set_data(body)
    except Exception as e:
        print("[VSP_TABS_ROUTER_INJECT_ANY][ERR]", e)
    return response



# === VSP UI WHOAMI DEBUG V2 + API RUN CI TRIGGER ===
@app.route("/__vsp_ui_whoami", methods=["GET"])
def vsp_ui_whoami():
    """
    Endpoint debug để kiểm tra app nào đang chạy trên gateway 8910.
    """
    from flask import jsonify
    import os
    return jsonify({
        "ok": True,
        "app": "vsp_demo_app",
        "cwd": os.getcwd(),
        "file": __file__,
    })

@app.route("/api/vsp/run", methods=["POST"])
def api_vsp_run():
    """
    Trigger scan từ UI:
    Body:
    {
      "mode": "local" | "ci",
      "profile": "FULL_EXT",
      "target_type": "path",
      "target": "/path/to/project"
    }
    """
    import subprocess
    from pathlib import Path
    from flask import request, jsonify

    try:
        data = request.get_json(force=True, silent=True) or {}
    except Exception:
        data = {}

    mode = (data.get("mode") or "local").lower()
    profile = data.get("profile") or "FULL_EXT"
    target_type = data.get("target_type") or "path"
    target = data.get("target") or ""

    ci_mode = "LOCAL_UI"
    if mode in ("ci", "gitlab", "jenkins"):
        ci_mode = mode.upper() + "_UI"

    # Hiện tại chỉ hỗ trợ target_type=path
    if target_type != "path":
        return jsonify({
            "ok": False,
            "implemented": True,
            "ci_triggered": False,
            "error": "Only target_type='path' is supported currently"
        }), 400

    # Nếu không truyền, default là project SECURITY-10-10-v4
    if not target:
        target = "/home/test/Data/SECURITY-10-10-v4"

    wrapper = Path(__file__).resolve().parents[1] / "bin" / "vsp_ci_trigger_from_ui_v1.sh"

    if not wrapper.exists():
        return jsonify({
            "ok": False,
            "implemented": False,
            "ci_triggered": False,
            "error": f"Wrapper not found: {wrapper}"
        }), 500

    try:
        proc = subprocess.Popen(
            [str(wrapper), profile, target, ci_mode],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        stdout, stderr = proc.communicate(timeout=5)
        req_id = (stdout or "").strip() or "UNKNOWN"

        if proc.returncode != 0:
            return jsonify({
                "ok": False,
                "implemented": True,
                "ci_triggered": False,
                "request_id": req_id,
                "error": f"Wrapper exited with code {proc.returncode}",
                "stderr": (stderr or "")[-4000:],
            }), 500

        return jsonify({
            "ok": True,
            "implemented": True,
            "ci_triggered": True,
            "request_id": req_id,
            "profile": profile,
            "target": target,
            "ci_mode": ci_mode,
            "message": "Scan request accepted, CI pipeline running in background."
        })
    except subprocess.TimeoutExpired:
        return jsonify({
            "ok": True,
            "implemented": True,
            "ci_triggered": True,
            "request_id": "TIMEOUT_SPAWN",
            "profile": profile,
            "target": target,
            "ci_mode": ci_mode,
            "message": "Scan request spawned (timeout on wrapper stdout)."
        })
    except Exception as e:
        return jsonify({
            "ok": False,
            "implemented": False,
            "ci_triggered": False,
            "error": str(e),
        }), 500
# === END VSP UI WHOAMI DEBUG V2 + API RUN CI TRIGGER ===



# ============================================================
# VSP UI -> CI: Status endpoint for polling (Run Scan Now UI)
# GET /api/vsp/run_status/<req_id>
# - Reads UI trigger log: SECURITY_BUNDLE/out_ci/ui_triggers/UIREQ_*.log
# - Parses ci_run_id, gate, final rc
# - Returns tail log lines
# ============================================================
def _vsp_tail_lines(p: str, n: int = 80):
    try:
        with open(p, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.read().splitlines()
        return lines[-n:]
    except Exception as e:
        return [f"[run_status][ERR] cannot read log: {e}"]

def _vsp_parse_status_from_log(lines):
    # defaults
    status = "PENDING"
    final_rc = None
    ci_run_id = None
    gate = None

    # Parse ci_run_id from OUTER banner
    rx_run = re.compile(r"\bRUN_ID\b\s*=\s*(VSP_CI_\d{8}_\d{6})")
    rx_run2 = re.compile(r"\bRUN_ID\b\s*=\s*(VSP_CI_\d{8}_\d{6})")
    rx_outer = re.compile(r"\[VSP_CI_OUTER\].*?\bRUN_ID\b\s*=\s*(VSP_CI_\d{8}_\d{6})")
    rx_pipe_end = re.compile(r"\[VSP_UI_RUN\].*?Pipeline kết thúc với RC=(\-?\d+)")
    rx_gate_final = re.compile(r"\[VSP_CI_GATE\].*?\bFinal RC\b\s*:\s*(\-?\d+)")
    rx_runner_rc = re.compile(r"\[VSP_CI_GATE\].*?Runner kết thúc với RC=(\-?\d+)")
    rx_gate_pass = re.compile(r"\[VSP_CI_GATE\].*?\bGATE PASS\b")
    rx_gate_fail = re.compile(r"\[VSP_CI_GATE\].*?\bGATE FAIL\b")

    saw_start = False
    for ln in lines:
        if "[VSP_UI_RUN]" in ln or "[VSP_CI_OUTER]" in ln or "[VSP_CI_GATE]" in ln:
            saw_start = True

        m = rx_outer.search(ln) or rx_run.search(ln) or rx_run2.search(ln)
        if m and not ci_run_id:
            ci_run_id = m.group(1)

        if rx_gate_pass.search(ln):
            gate = "PASS"
        if rx_gate_fail.search(ln):
            gate = "FAIL"

        m = rx_gate_final.search(ln)
        if m:
            final_rc = int(m.group(1))

        m = rx_pipe_end.search(ln)
        if m:
            final_rc = int(m.group(1))

        # Nếu runner chết sớm mà chưa có Final RC
        if final_rc is None:
            m = rx_runner_rc.search(ln)
            if m:
                final_rc = int(m.group(1))

    if not saw_start:
        status = "PENDING"
    else:
        # Có start
        status = "RUNNING"
        if final_rc is not None:
            status = "DONE" if final_rc == 0 else "FAILED"

    return status, ci_run_id, gate, final_rc

def _vsp_try_read_has_findings(ci_run_id: str):
    # ưu tiên nếu đã sync về VSP core: out/RUN_VSP_CI_x/report/ci_flag_has_findings.env
    if not ci_run_id:
        return None

    vsp_run_id = "RUN_" + ci_run_id.replace("VSP_CI_", "VSP_CI_")
    vsp_flag = Path("/home/test/Data/SECURITY_BUNDLE/out") / vsp_run_id / "report" / "ci_flag_has_findings.env"
    # fallback: có thể có flag trong CI_RUN_DIR/report/ci_flag_has_findings.env (nếu bạn tạo ở outer)
    ci_flag = Path("/home/test/Data/SECURITY-10-10-v4/out_ci") / ci_run_id / "report" / "ci_flag_has_findings.env"

    for fp in [vsp_flag, ci_flag]:
        try:
            if fp.is_file():
                data = fp.read_text(encoding="utf-8", errors="ignore").splitlines()
                for ln in data:
                    ln = ln.strip()
                    if ln.startswith("has_findings="):
                        return int(ln.split("=", 1)[1].strip())
        except Exception:
            continue
    return None

@app.route("/api/vsp/run_status/<req_id>", methods=["GET"])
def api_vsp_run_status(req_id):
    # req_id expected like UIREQ_YYYYmmdd_HHMMSS_pid
    log_dir = Path("/home/test/Data/SECURITY_BUNDLE/out_ci/ui_triggers")
    log_path = log_dir / f"{req_id}.log"

    if not log_path.is_file():
        return jsonify({
            "ok": False,
            "error": f"REQ log not found: {log_path}"
        }), 404

    lines = _vsp_tail_lines(str(log_path), n=90)
    status, ci_run_id, gate, final_rc = _vsp_parse_status_from_log(lines)

    has_findings = _vsp_try_read_has_findings(ci_run_id)
    flag = {}
    if has_findings is not None:
        flag["has_findings"] = has_findings

    # === VSP_API_VSP_RUN_STATUS_INJECT_CI_KICS_V1 ===
    try:
        # ensure payload exists + is dict
        _pl = payload if isinstance(locals().get("payload", None), dict) else None
        if _pl is None:
            _pl = locals().get("obj", None) if isinstance(locals().get("obj", None), dict) else None
        if _pl is not None:
            _rid = (req_id or "").strip()
            _ci = (_pl.get("ci_run_dir") or "").strip()
            if not _ci:
                try:
                    _ci = _vsp_guess_ci_run_dir_from_rid_v33(_rid) or ""
                except Exception:
                    _ci = ""
                if _ci:
                    _pl["ci_run_dir"] = _ci
            if _ci:
                # inject KICS summary (if exists)
                try:
                    import json as _json
                    from pathlib import Path as _Path
                    _ks = _Path(_ci) / "kics" / "kics_summary.json"
                    if _ks.is_file():
                        _ko = _json.loads(_ks.read_text(encoding="utf-8", errors="ignore") or "{}")
                        if isinstance(_ko, dict):
                            _pl["kics_verdict"] = _ko.get("verdict","") or _pl.get("kics_verdict","")
                            try:
                                _pl["kics_total"] = int(_ko.get("total") or 0)
                            except Exception:
                                pass
                            _pl["kics_counts"] = _ko.get("counts") or _pl.get("kics_counts") or {}
                except Exception:
                    pass
    except Exception:
        pass

    return jsonify({
        "ok": True,
        "request_id": req_id,
        "status": status,
        "ci_run_id": ci_run_id,
        "gate": gate,
        "final": final_rc,
        "flag": flag,
        "tail": lines[-60:]  # UI show last 60 lines
    })


# === VSP_JSON_ERRHANDLERS_V4 ===
# Contract: any /api/vsp/* error must still be JSON so jq never dies.
def _vsp_env_int(name, default):
    try:
        import os
        v = os.getenv(name, "")
        if str(v).strip() == "":
            return int(default)
        return int(float(v))
    except Exception:
        return int(default)

def _vsp_api_json_err(code, msg):
    from flask import jsonify
    stall = _vsp_env_int("VSP_UIREQ_STALL_TIMEOUT_SEC", _vsp_env_int("VSP_STALL_TIMEOUT_SEC", 600))
    total = _vsp_env_int("VSP_UIREQ_TOTAL_TIMEOUT_SEC", _vsp_env_int("VSP_TOTAL_TIMEOUT_SEC", 7200))
    if stall < 1: stall = 1
    if total < 1: total = 1
    payload = {
        "ok": False,
        "status": "ERROR",
        "final": True,
        "error": msg,
        "http_code": code,
        "stall_timeout_sec": stall,
        "total_timeout_sec": total,
        "progress_pct": 0,
        "stage_index": 0,
        "stage_total": 0,
        "stage_name": "",
        "stage_sig": "",
    }
    return jsonify(payload), 200

def _vsp_err_404(e):
    try:
        from flask import request
        if request.path.startswith("/api/vsp/"):
            return _vsp_api_json_err(404, "HTTP_404_NOT_FOUND")
    except Exception:
        pass
    return ("Not Found", 404)

def _vsp_err_500(e):
    try:
        from flask import request
        if request.path.startswith("/api/vsp/"):
            return _vsp_api_json_err(500, "HTTP_500_INTERNAL")
    except Exception:
        pass
    return ("Internal Server Error", 500)

app.register_error_handler(404, _vsp_err_404)
app.register_error_handler(500, _vsp_err_500)
# === END VSP_JSON_ERRHANDLERS_V4 ===

# === VSP_RUN_API_FALLBACK_V1 ===
    
import os as _os
if _os.getenv("VSP_DISABLE_RUNAPI_FALLBACK", "0") == "1":
    print("[VSP_RUN_API_FALLBACK] disabled by VSP_DISABLE_RUNAPI_FALLBACK=1")
else:
    # If real run_api blueprint fails to load, we still MUST expose /api/vsp/run_v1 and /api/vsp/run_status_v1/*
    # so UI + jq never breaks. This is the "commercial contract".
    def _vsp_env_int(name, default):
        try:
            import os
            v = os.getenv(name, "")
            if str(v).strip() == "":
                return int(default)
            return int(float(v))
        except Exception:
            return int(default)

    def _vsp_contractize(payload):
        if not isinstance(payload, dict):
            payload = {"ok": False, "status": "ERROR", "final": True, "error": "INVALID_STATUS_PAYLOAD"}
        stall = _vsp_env_int("VSP_UIREQ_STALL_TIMEOUT_SEC", _vsp_env_int("VSP_STALL_TIMEOUT_SEC", 600))
        total = _vsp_env_int("VSP_UIREQ_TOTAL_TIMEOUT_SEC", _vsp_env_int("VSP_TOTAL_TIMEOUT_SEC", 7200))
        if stall < 1: stall = 1
        if total < 1: total = 1
        payload.setdefault("ok", bool(payload.get("ok", False)))
        payload.setdefault("status", payload.get("status") or "UNKNOWN")
        payload.setdefault("final", bool(payload.get("final", False)))
        payload.setdefault("error", payload.get("error") or "")
        payload.setdefault("req_id", payload.get("req_id") or "")
        payload["stall_timeout_sec"] = int(payload.get("stall_timeout_sec") or stall)
        payload["total_timeout_sec"] = int(payload.get("total_timeout_sec") or total)
        payload.setdefault("killed", bool(payload.get("killed", False)))
        payload.setdefault("kill_reason", payload.get("kill_reason") or "")
        payload.setdefault("progress_pct", int(payload.get("progress_pct") or 0))
        payload.setdefault("stage_index", int(payload.get("stage_index") or 0))
        payload.setdefault("stage_total", int(payload.get("stage_total") or 0))
        payload.setdefault("stage_name", payload.get("stage_name") or "")
        payload.setdefault("stage_sig", payload.get("stage_sig") or "")
        payload.setdefault("updated_at", int(__import__("time").time()))
        return payload

    try:
        bp_vsp_run_api_v1  # noqa
    except Exception:
        bp_vsp_run_api_v1 = None

    if bp_vsp_run_api_v1 is None:
        from flask import Blueprint, request, jsonify
        bp_vsp_run_api_v1 = Blueprint("vsp_run_api_v1_fallback", __name__)
        _VSP_FALLBACK_REQ = {}

        @bp_vsp_run_api_v1.route("/api/vsp/run_v1", methods=["POST"])
        def _fallback_run_v1():
            # Keep same behavior: missing body => 400 but still JSON
            body = None
            try:
                body = request.get_json(silent=True)
            except Exception:
                body = None
            if not body:
                return jsonify({"ok": False, "error": "MISSING_BODY"}), 400

            req_id = "REQ_FALLBACK_" + __import__("time").strftime("%Y%m%d_%H%M%S")
            st = _vsp_contractize({
                "ok": True,
                "status": "RUNNING",
                "final": False,
                "error": "",
                "req_id": req_id,
                "progress_pct": 0,
                "stage_index": 0,
                "stage_total": 0,
                "stage_name": "INIT",
                "stage_sig": "0/0|INIT|0",
            })
            _VSP_FALLBACK_REQ[req_id] = st
            return jsonify({"ok": True, "request_id": req_id, "implemented": False, "message": "Fallback run_api active (real bp load failed)."}), 200

        @bp_vsp_run_api_v1.route("/api/vsp/run_status_v1/<req_id>", methods=["GET"])
        def _fallback_run_status_v1(req_id):
            if req_id not in _VSP_FALLBACK_REQ:
                # === VSP_KICS_TAIL_PRE_RETURN_V3_DEBUG ===
                try:
                    import os, json
                    from pathlib import Path
                    NL = chr(10)
                    d = None
                    # try common local dict vars
                    for k in ('_out','out','resp','payload','ret','data','result','st'):
                        v = locals().get(k)
                        if isinstance(v, dict):
                            d = v; break
                    # fallback store (if exists)
                    if d is None:
                        fb = globals().get('_VSP_FALLBACK_REQ')
                        if isinstance(fb, dict):
                            vv = fb.get(req_id)
                            if isinstance(vv, dict): d = vv
                    if isinstance(d, dict):
                        d['_handler'] = '_fallback_run_status_v1'
                        ci = str(d.get('ci_run_dir') or '')
                        # if ci missing, try statefile candidates
                        if not ci:
                            base = Path(__file__).resolve().parent
                            cands = [
                                base / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                                base / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                                base / 'ui' / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                            ]
                            for stp in cands:
                                if stp.exists():
                                    try:
                                        t = stp.read_text(encoding='utf-8', errors='ignore') or ''
                                        j = json.loads(t) if t.strip() else dict()
                                        ci = str(j.get('ci_run_dir') or '')
                                        if ci: break
                                    except Exception:
                                        pass
                        klog = os.path.join(ci, 'kics', 'kics.log')
                        if ci and os.path.exists(klog):
                            rawb = Path(klog).read_bytes()
                            if len(rawb) > 65536: rawb = rawb[-65536:]
                            raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                            hb = ''
                            for ln in reversed(raw.splitlines()):
                                if '][HB]' in ln and '[KICS_V' in ln:
                                    hb = ln.strip(); break
                            ls2 = [x for x in raw.splitlines() if x.strip()]
                            tail = NL.join(ls2[-30:])
                            if hb and (hb not in tail): tail = hb + NL + tail
                            d['kics_tail'] = tail[-4096:]
                        else:
                            d['kics_tail'] = '[kics_tail] ci=' + str(ci) + ' exists=' + str(os.path.exists(klog))
                except Exception:
                    pass
                # === END VSP_KICS_TAIL_PRE_RETURN_V3_DEBUG ===
                return jsonify(_vsp_contractize({
                    "ok": False,
                    "status": "NOT_FOUND",
                    "final": True,
                    "error": "REQ_ID_NOT_FOUND",
                    "req_id": req_id
                })), 200
            # === VSP_STATUS_TAIL_APPEND_KICS_HB_V6_FIXED_SAFE ===
            try:
                import os
                st = _VSP_FALLBACK_REQ.get(req_id) or {}
                _stage = str(st.get('stage_name') or '').lower()
                _ci = str(st.get('ci_run_dir') or '')
                if ('kics' in _stage) and _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if os.path.exists(_klog):
                        with open(_klog, 'rb') as fh:
                            _rawb = fh.read()
                        if len(_rawb) > 65536:
                            _rawb = _rawb[-65536:]
                        _raw = _rawb.decode('utf-8', errors='ignore').replace('\r','\n')
                        _hb = ''
                        for _ln in reversed(_raw.splitlines()):
                            if '][HB]' in _ln and '[KICS_V' in _ln:
                                _hb = _ln.strip()
                                break
                        _lines = [x for x in _raw.splitlines() if x.strip()]
                        _tail = '\n'.join(_lines[-25:])
                        if _hb and (_hb not in _tail):
                            _tail = _hb + '\n' + _tail
                        st['tail'] = (_tail or '')[-4096:]
                        _VSP_FALLBACK_REQ[req_id] = st
            except Exception:
                pass
            # === END VSP_STATUS_TAIL_APPEND_KICS_HB_V6_FIXED_SAFE ===
            _out = _vsp_contractize(_VSP_FALLBACK_REQ[req_id])
            # === VSP_STATUS_TAIL_OVERRIDE_KICS_V8 ===
            try:
                import os
                from pathlib import Path
                _stage = str(_out.get('stage_name') or '').lower()
                _ci = str(_out.get('ci_run_dir') or '')
                if _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if os.path.exists(_klog):
                        rawb = Path(_klog).read_bytes()
                        if len(rawb) > 65536:
                            rawb = rawb[-65536:]
                        raw = rawb.decode('utf-8', errors='ignore').replace('\\r','\\n')
                        hb = ''
                        for ln in reversed(raw.splitlines()):
                            if '][HB]' in ln and '[KICS_V' in ln:
                                hb = ln.strip(); break
                        clean = [x for x in raw.splitlines() if x.strip()]
                        ktail = '\\n'.join(clean[-25:])
                        if hb and (hb not in ktail):
                            ktail = hb + '\\n' + ktail
                        _out['kics_tail'] = (ktail or '')[-4096:]
                        # only override main tail when stage is KICS
                        if 'kics' in _stage:
                            _out['tail'] = _out['kics_tail']
            except Exception:
                pass
            # === END VSP_STATUS_TAIL_OVERRIDE_KICS_V8 ===
            # === VSP_STATUS_TAIL_OVERRIDE_KICS_V10_RETURNPATCH ===
            _out = _vsp_contractize(_VSP_FALLBACK_REQ[req_id])
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                _stage = str(_out.get('stage_name') or '').lower()
                _ci = str(_out.get('ci_run_dir') or '')
                if not _ci:
                    try:
                        _st = (Path(__file__).resolve().parent / 'out_ci' / 'uireq_v1' / (req_id + '.json'))
                        if _st.exists():
                            txt = _st.read_text(encoding='utf-8', errors='ignore') or ''
                            j = json.loads(txt) if txt.strip() else dict()
                            _ci = str(j.get('ci_run_dir') or '')
                    except Exception:
                        pass
                if _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if os.path.exists(_klog):
                        rawb = Path(_klog).read_bytes()
                        if len(rawb) > 65536:
                            rawb = rawb[-65536:]
                        raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                        hb = ''
                        for ln in reversed(raw.splitlines()):
                            if '][HB]' in ln and '[KICS_V' in ln:
                                hb = ln.strip()
                                break
                        clean = [x for x in raw.splitlines() if x.strip()]
                        ktail = NL.join(clean[-25:])
                        if hb and (hb not in ktail):
                            ktail = hb + NL + ktail
                        _out['kics_tail'] = (ktail or '')[-4096:]
                        if 'kics' in _stage:
                            _out['tail'] = _out.get('kics_tail','')
            except Exception:
                pass
            # === END VSP_STATUS_TAIL_OVERRIDE_KICS_V10_RETURNPATCH ===
            # === VSP_KICS_TAIL_HOTFIX_V11_LITE2 ===
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                # ensure _out exists
                if '_out' not in locals():
                    _out = _vsp_contractize(_VSP_FALLBACK_REQ[req_id])
                _stage = str(_out.get('stage_name') or '').lower()
                _ci = str(_out.get('ci_run_dir') or _out.get('ci_dir') or '')
                if not _ci:
                    base = Path(__file__).resolve().parent
                    cands = [
                        base / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                        base / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                        base / 'ui' / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                        UIREQ_STATE_DIR / (req_id + '.json'),
                        UIREQ_STATE_DIR / (req_id + '.json'),
                    ]
                    for st in cands:
                        try:
                            if st.exists():
                                txt = st.read_text(encoding='utf-8', errors='ignore') or ''
                                j = json.loads(txt) if txt.strip() else dict()
                                _ci = str(j.get('ci_run_dir') or j.get('ci_dir') or '')
                                if _ci:
                                    _out['ci_run_dir'] = _ci
                                    break
                        except Exception:
                            pass
                _klog = ''
                if _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if not os.path.exists(_klog):
                        try:
                            kd = Path(_ci) / 'kics'
                            if kd.exists():
                                logs = [x for x in kd.glob('*.log') if x.is_file()]
                                logs.sort(key=lambda x: x.stat().st_mtime, reverse=True)
                                if logs:
                                    _klog = str(logs[0])
                        except Exception:
                            pass
                _tail_msg = ''
                if _klog and os.path.exists(_klog):
                    rawb = Path(_klog).read_bytes()
                    if len(rawb) > 65536:
                        rawb = rawb[-65536:]
                    raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                    hb = ''
                    for ln in reversed(raw.splitlines()):
                        if '][HB]' in ln and '[KICS_V' in ln:
                            hb = ln.strip(); break
                    clean = [x for x in raw.splitlines() if x.strip()]
                    ktail = NL.join(clean[-25:])
                    if hb and (hb not in ktail):
                        ktail = hb + NL + ktail
                    _tail_msg = (ktail or '')[-4096:]
                else:
                    # fallback: runner.log
                    if _ci:
                        rlog = os.path.join(_ci, 'runner.log')
                        if os.path.exists(rlog):
                            rawb = Path(rlog).read_bytes()
                            if len(rawb) > 65536:
                                rawb = rawb[-65536:]
                            raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                            clean = [x for x in raw.splitlines() if x.strip()]
                            _tail_msg = ('[KICS_TAIL][fallback runner.log]' + NL + NL.join(clean[-25:]))[-4096:]
                    if not _tail_msg:
                        _tail_msg = '[KICS_TAIL] no kics log yet'
                _out['kics_tail'] = _tail_msg
                if 'kics' in _stage:
                    _out['tail'] = _tail_msg
            except Exception:
                pass
            # === END VSP_KICS_TAIL_HOTFIX_V11_LITE2 ===
            # === VSP_FORCE_KICS_TAIL_V2 ===
            _out = _vsp_contractize(_VSP_FALLBACK_REQ[req_id])
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                _ci = str(_out.get('ci_run_dir') or '')
                if not _ci:
                    cands = [
                        (Path(__file__).resolve().parent / 'out_ci' / 'uireq_v1' / (req_id + '.json')),
                        (Path(__file__).resolve().parent / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json')),
                        (Path(__file__).resolve().parent / 'ui' / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json')),
                    ]
                    for _st in cands:
                        if _st.exists():
                            txt = _st.read_text(encoding='utf-8', errors='ignore') or ''
                            j = json.loads(txt) if txt.strip() else {}
                            _ci = str(j.get('ci_run_dir') or '')
                            break
                if _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if os.path.exists(_klog):
                        rawb = Path(_klog).read_bytes()
                        if len(rawb) > 65536:
                            rawb = rawb[-65536:]
                        raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                        hb = ''
                        for ln in reversed(raw.splitlines()):
                            if '][HB]' in ln and '[KICS_V' in ln:
                                hb = ln.strip(); break
                        lines2 = [x for x in raw.splitlines() if x.strip()]
                        tail = NL.join(lines2[-60:])
                        if hb and hb not in tail:
                            tail = hb + NL + tail
                        _out['kics_tail'] = tail[-4096:]
            except Exception:
                pass
            # === END VSP_FORCE_KICS_TAIL_V2 ===
            # === VSP_FORCE_KICS_TAIL_FINAL_RETURN_V1 ===
            _out = _out
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                if isinstance(_out, dict):
                    stage = str(_out.get('stage_name') or '').lower()
                    ci = str(_out.get('ci_run_dir') or '')
                    if ('kics' in stage) and ci:
                        klog = os.path.join(ci, 'kics', 'kics.log')
                        if os.path.exists(klog):
                            rawb = Path(klog).read_bytes()
                            if len(rawb) > 65536:
                                rawb = rawb[-65536:]
                            raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                            hb = ''
                            for ln in reversed(raw.splitlines()):
                                if '][HB]' in ln and '[KICS_V' in ln:
                                    hb = ln.strip(); break
                            lines2 = [x for x in raw.splitlines() if x.strip()]
                            tail = NL.join(lines2[-30:])
                            if hb and (hb not in tail):
                                tail = hb + NL + tail
                            _out['kics_tail'] = tail[-4096:]
            except Exception:
                pass
            # === END VSP_FORCE_KICS_TAIL_FINAL_RETURN_V1 ===
            # === VSP_FORCE_KICS_TAIL_BY_ROUTE_V2 ===
            _out = _out
            try:
                import os
                from pathlib import Path
                NL = chr(10)
                if isinstance(_out, dict):
                    ci = str(_out.get('ci_run_dir') or '')
                    if ci:
                        klog = os.path.join(ci, 'kics', 'kics.log')
                        if os.path.exists(klog):
                            rawb = Path(klog).read_bytes()
                            if len(rawb) > 65536:
                                rawb = rawb[-65536:]
                            raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                            hb = ''
                            for ln in reversed(raw.splitlines()):
                                if '][HB]' in ln and '[KICS_V' in ln:
                                    hb = ln.strip(); break
                            lines2 = [x for x in raw.splitlines() if x.strip()]
                            tail = NL.join(lines2[-30:])
                            if hb and (hb not in tail):
                                tail = hb + NL + tail
                            _out['kics_tail'] = tail[-4096:]
            except Exception:
                pass
            # === END VSP_FORCE_KICS_TAIL_BY_ROUTE_V2 ===
            # === VSP_KICS_TAIL_PRE_RETURN_V3_DEBUG ===
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                d = None
                # try common local dict vars
                for k in ('_out','out','resp','payload','ret','data','result','st'):
                    v = locals().get(k)
                    if isinstance(v, dict):
                        d = v; break
                # fallback store (if exists)
                if d is None:
                    fb = globals().get('_VSP_FALLBACK_REQ')
                    if isinstance(fb, dict):
                        vv = fb.get(req_id)
                        if isinstance(vv, dict): d = vv
                if isinstance(d, dict):
                    d['_handler'] = '_fallback_run_status_v1'
                    ci = str(d.get('ci_run_dir') or '')
                    # if ci missing, try statefile candidates
                    if not ci:
                        base = Path(__file__).resolve().parent
                        cands = [
                            base / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                            base / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                            base / 'ui' / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                        ]
                        for stp in cands:
                            if stp.exists():
                                try:
                                    t = stp.read_text(encoding='utf-8', errors='ignore') or ''
                                    j = json.loads(t) if t.strip() else dict()
                                    ci = str(j.get('ci_run_dir') or '')
                                    if ci: break
                                except Exception:
                                    pass
                    klog = os.path.join(ci, 'kics', 'kics.log')
                    if ci and os.path.exists(klog):
                        rawb = Path(klog).read_bytes()
                        if len(rawb) > 65536: rawb = rawb[-65536:]
                        raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                        hb = ''
                        for ln in reversed(raw.splitlines()):
                            if '][HB]' in ln and '[KICS_V' in ln:
                                hb = ln.strip(); break
                        ls2 = [x for x in raw.splitlines() if x.strip()]
                        tail = NL.join(ls2[-30:])
                        if hb and (hb not in tail): tail = hb + NL + tail
                        d['kics_tail'] = tail[-4096:]
                    else:
                        d['kics_tail'] = '[kics_tail] ci=' + str(ci) + ' exists=' + str(os.path.exists(klog))
            except Exception:
                pass
            # === END VSP_KICS_TAIL_PRE_RETURN_V3_DEBUG ===
            # === VSP_UIREQ_PERSIST_AND_RESOLVE_CI_V1 ===
            # Persist UIREQ state under out_ci/uireq_v1 and try resolve ci_run_dir from state (commercial)
            try:
                import os, json, glob, datetime
                rid = req_id if 'req_id' in locals() else (request_id if 'request_id' in locals() else None)
                if not rid:
                    rid = (locals().get("REQ_ID") or locals().get("RID") or None)
                udir = os.path.join(os.path.dirname(__file__), "out_ci", "uireq_v1")
                os.makedirs(udir, exist_ok=True)
                spath = os.path.join(udir, f"{rid}.json") if rid else None
            
                # choose dst dict (prefer resp/out)
                dst = None
                if isinstance(locals().get("resp", None), dict): dst = resp
                if isinstance(locals().get("out", None), dict): dst = out
            
                if isinstance(dst, dict):
                    # normalize empties
                    if dst.get("stage_name") is None: dst["stage_name"] = ""
                    if dst.get("ci_run_dir") is None: dst["ci_run_dir"] = ""
            
                    # resolve ci_run_dir if empty: read previously persisted state or fallback to latest CI dir
                    if (not dst.get("ci_run_dir")) and spath and os.path.isfile(spath):
                        try:
                            j = json.load(open(spath, "r", encoding="utf-8"))
                            dst["ci_run_dir"] = j.get("ci_run_dir") or j.get("ci") or dst.get("ci_run_dir") or ""
                        except Exception:
                            pass
            
                    if (not dst.get("ci_run_dir")):
                        # fallback guess: newest CI dir under /home/test/Data/SECURITY-10-10-v4/out_ci
                        cand = sorted(glob.glob("/home/test/Data/SECURITY-10-10-v4/out_ci/VSP_CI_*"), reverse=True)
                        if cand:
                            dst["ci_run_dir"] = cand[0]
            
                    # persist state every call (so UI has stable mapping)
                    if spath:
                        payload = dict(dst)
                        payload["ts_persist"] = datetime.datetime.utcnow().isoformat() + "Z"
                        try:
                            open(spath, "w", encoding="utf-8").write(json.dumps(payload, ensure_ascii=False, indent=2))
                        except Exception:
                            pass
            except Exception:
                pass

            return jsonify(_out), 200

        try:
            app.register_blueprint(bp_vsp_run_api_v1)
            print("[VSP_RUN_API_FALLBACK] mounted /api/vsp/run_v1 + /api/vsp/run_status_v1/*")
        except Exception as e:
            print("[VSP_RUN_API_FALLBACK] mount failed:", repr(e))
# === END VSP_RUN_API_FALLBACK_V1 ===

# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===
def _vsp_try_inject_kics_into_payload(payload: dict):
    try:
        ci_dir = payload.get("ci_run_dir") or payload.get("ci_run_dir_abs") or payload.get("run_dir") or payload.get("ci_dir") or ""
        ks = _vsp_read_kics_summary(ci_dir) if ci_dir else None
        if isinstance(ks, dict):
            payload["kics_verdict"] = ks.get("verdict","") or ""
            payload["kics_counts"]  = ks.get("counts",{}) if isinstance(ks.get("counts"), dict) else {}
            payload["kics_total"]   = int(ks.get("total",0) or 0)
        else:
            payload.setdefault("kics_verdict","")
            payload.setdefault("kics_counts",{})
            payload.setdefault("kics_total",0)
    except Exception:
        payload.setdefault("kics_verdict","")
        payload.setdefault("kics_counts",{})
        payload.setdefault("kics_total",0)

def vsp_after_request_inject_kics_summary_v31(resp):
    try:
        from flask import request as _req
        path = getattr(_req, "path", "") or ""
        if not (path.startswith("/api/vsp/run_status_v1/") or path.startswith("/api/vsp/run_status_v2/")):
            return resp

        # read JSON body
        raw = resp.get_data(as_text=True) or ""
        s = raw.lstrip()
        if not s:
            return resp
        c0 = s[0]
        if c0 not in ("{", "["):
            return resp

        import json as _json
        payload = _json.loads(s)
        if not isinstance(payload, dict):
            return resp

        _vsp_try_inject_kics_into_payload(payload)

        resp.set_data(_json.dumps(payload, ensure_ascii=False))
        resp.headers["Content-Type"] = "application/json"
        return resp
    except Exception:
        # === VSP_STATUS_GUARD_INJECT_CI_KICS_V10 ===
        try:
            import json as _json
            from pathlib import Path as _Path
            from flask import request as _req
            _resp = resp
            _path = (_req.path or '')
            if _path.startswith('/api/vsp/run_status_v1/') or _path.startswith('/api/vsp/run_status_v2/'):
                _rid = (_path.rsplit('/', 1)[-1] or '').split('?', 1)[0].strip()
                _rid_norm = _rid[4:].strip() if _rid.startswith('RUN_') else _rid
                _obj = None
                try:
                    _obj = _resp.get_json(silent=True)
                except Exception:
                    _obj = None
                if not isinstance(_obj, dict):
                    try:
                        _raw = (_resp.get_data(as_text=True) or '').lstrip()
                        if _raw.startswith('{'):
                            _obj = _json.loads(_raw)
                    except Exception:
                        _obj = None
                if isinstance(_obj, dict):
                    _obj.setdefault('ci_run_dir', None)
                    _obj.setdefault('kics_verdict', '')
                    _obj.setdefault('kics_total', 0)
                    _obj.setdefault('kics_counts', {})
                    _ci = (_obj.get('ci_run_dir') or '').strip()
                    if (not _ci) and _rid_norm:
                        try:
                            _ci = _vsp_guess_ci_run_dir_from_rid_v33(_rid_norm) or ''
                        except Exception:
                            _ci = ''
                        if _ci:
                            _obj['ci_run_dir'] = _ci
                    _ci = (_obj.get('ci_run_dir') or '').strip()
                    if _ci:
                        _ks = _Path(_ci) / 'kics' / 'kics_summary.json'
                        if _ks.is_file():
                            try:
                                _jj = _json.loads(_ks.read_text(encoding='utf-8', errors='ignore') or '{}')
                                if isinstance(_jj, dict):
                                    _obj['kics_verdict'] = str(_jj.get('verdict') or _obj.get('kics_verdict') or '')
                                    try:
                                        _obj['kics_total'] = int(_jj.get('total') or _obj.get('kics_total') or 0)
                                    except Exception:
                                        pass
                                    _cc = _jj.get('counts')
                                    if isinstance(_cc, dict):
                                        _obj['kics_counts'] = _cc
                            except Exception:
                                pass
                    try:
                        _resp.set_data(_json.dumps(_obj, ensure_ascii=False))
                        _resp.mimetype = 'application/json'
                    except Exception:
                        pass
        except Exception:
            pass
        return resp
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===


# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===
try:
    app.after_request(vsp_after_request_inject_kics_summary_v31)
except Exception:
    pass
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===


# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V33 ===
def _vsp_guess_ci_run_dir_from_rid_v33(rid_norm):
    # === VSP_GUESS_CI_RUN_DIR_V33_REWRITE_CLEAN_V4 ===
    """Return absolute CI run dir for a RID (RUN_* / VSP_CI_* / VSP_UIREQ_*).
    - If RID is UIREQ: read persisted state under ui/out_ci/uireq_v1/<RID>.json
    - Else: find */out_ci/<RID> under /home/test/Data with shallow globs
    """
    try:
        import json
        from pathlib import Path
        rn = str(rid_norm or '').strip()
        if not rn:
            return None
        if rn.startswith("RUN_"):
            rn = rn[4:].strip()

        # UIREQ -> read persisted state (if exists)
        if rn.startswith("VSP_UIREQ_"):
            st = Path("/home/test/Data/SECURITY_BUNDLE/ui/ui/out_ci/uireq_v1") / (rn + ".json")
            if st.is_file():
                try:
                    obj = json.loads(st.read_text(encoding="utf-8", errors="ignore") or "{}")
                    if isinstance(obj, dict):
                        ci = (obj.get("ci_run_dir") or obj.get("ci_dir") or obj.get("ci") or "").strip()
                        if ci and Path(ci).is_dir():
                            return str(Path(ci))
                except Exception:
                    pass

        base = Path("/home/test/Data")

        # very fast common hit: /home/test/Data/*/out_ci/<rn>
        try:
            for c in base.glob("*/out_ci/" + rn):
                if c.is_dir():
                    return str(c)
        except Exception:
            pass

        # shallow fallbacks (no ** recursion)
        pats = (
            "*/*/out_ci/" + rn,
            "*/*/*/out_ci/" + rn,
            "*/*/*/*/out_ci/" + rn,
        )
        for pat in pats:
            try:
                for c in base.glob(pat):
                    if c.is_dir():
                        return str(c)
            except Exception:
                continue

        return None
    except Exception:
        return None
def _vsp_try_inject_kics_into_payload_v33(payload: dict, req_path: str):
    try:
        ci_dir = payload.get("ci_run_dir") or payload.get("ci_run_dir_abs") or payload.get("run_dir") or payload.get("ci_dir") or ""
        if not ci_dir:
            rid = payload.get("rid_norm") or payload.get("run_id") or payload.get("request_id") or ""
            if not rid and req_path:
                rid = req_path.rsplit("/", 1)[-1]
            g = _vsp_guess_ci_run_dir_from_rid_v33(rid)
            if g:
                payload["ci_run_dir"] = g
                ci_dir = g

        ks = _vsp_read_kics_summary(ci_dir) if ci_dir else None
        if isinstance(ks, dict):
            payload["kics_verdict"] = ks.get("verdict","") or ""
            payload["kics_counts"]  = ks.get("counts",{}) if isinstance(ks.get("counts"), dict) else {}
            payload["kics_total"]   = int(ks.get("total",0) or 0)
        else:
            payload.setdefault("kics_verdict","")
            payload.setdefault("kics_counts",{})
            payload.setdefault("kics_total",0)
    except Exception:
        payload.setdefault("kics_verdict","")
        payload.setdefault("kics_counts",{})
        payload.setdefault("kics_total",0)

def vsp_after_request_inject_kics_summary_v33(resp):
    try:
        from flask import request as _req
        path = getattr(_req, "path", "") or ""
        if not (path.startswith("/api/vsp/run_status_v1/") or path.startswith("/api/vsp/run_status_v2/")):
            return resp

        import json as _json
        raw = resp.get_data(as_text=True) or ""
        s = raw.lstrip()
        if not s:
            return resp
        c0 = s[0]
        # FIX: correct JSON detection
        if c0 not in ("{","["):
            return resp

        payload = _json.loads(s)
        if not isinstance(payload, dict):
            return resp

        _vsp_try_inject_kics_into_payload_v33(payload, path)

        resp.set_data(_json.dumps(payload, ensure_ascii=False))
        resp.headers["Content-Type"] = "application/json"
        return resp
    except Exception:
        return resp
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V33 ===


# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V33 ===
try:
    app.after_request(vsp_after_request_inject_kics_summary_v33)
except Exception:
    pass
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V33 ===







def _vsp_preempt_statusv2_postprocess_v1(payload):
    """Postprocess run_status_v2 JSON payload inside WSGI preempt to avoid nulls and inject tool summaries."""
    # === VSP_PREEMPT_STATUSV2_POSTPROCESS_HELPER_V1 ===
    try:
        import json
        from pathlib import Path as _P

        if not isinstance(payload, dict):
            return payload

        # never return nulls for commercial contract keys
        if payload.get("overall_verdict", None) is None:
            payload["overall_verdict"] = ""

        payload.setdefault("has_gitleaks", False)
        payload.setdefault("gitleaks_verdict", "")
        payload.setdefault("gitleaks_total", 0)
        payload.setdefault("gitleaks_counts", {})

        ci = payload.get("ci_run_dir") or payload.get("ci_dir") or payload.get("ci") or ""
        ci = str(ci).strip()
        if not ci:
            return payload

        # local helper read json
        def _readj(fp):
            try:
                if fp and fp.exists():
                    return json.loads(fp.read_text(encoding="utf-8", errors="ignore") or "{}")
            except Exception:
                return None
            return None

        # inject gitleaks from CI
        gsum = _readj(_P(ci) / "gitleaks" / "gitleaks_summary.json") or _readj(_P(ci) / "gitleaks_summary.json")
        if isinstance(gsum, dict):
            payload["has_gitleaks"] = True
            payload["gitleaks_verdict"] = str(gsum.get("verdict") or "")
            try:
                payload["gitleaks_total"] = int(gsum.get("total") or 0)
            except Exception:
                payload.setdefault('gitleaks_total', 0)
            cc = gsum.get("counts")
            payload["gitleaks_counts"] = cc if isinstance(cc, dict) else {}

        # if run_gate exists, take overall from it (single source of truth)
        gate = _readj(_P(ci) / "run_gate_summary.json")
        if isinstance(gate, dict):
            payload["overall_verdict"] = str(gate.get("overall") or payload.get("overall_verdict") or "")

        return payload
    except Exception:
        return payload


# === VSP_EXPORT_OVERRIDE_VIEWFUNC_V2 ===
import os, glob

try:
    from flask import request, jsonify, send_file
except Exception:
    # in case imports are structured differently
    pass

def _vsp_norm_rid(rid: str) -> str:
    rid = (rid or "").strip()
    return rid[4:] if rid.startswith("RUN_") else rid

def _vsp_ci_root() -> str:
    return os.environ.get("VSP_CI_OUT_ROOT") or "/home/test/Data/SECURITY-10-10-v4/out_ci"

def _vsp_resolve_ci_dir(rid: str) -> str:
    rn = _vsp_norm_rid(rid)
    base = _vsp_ci_root()
    cand = os.path.join(base, rn)
    if os.path.isdir(cand):
        return cand
    # fallback: try match substring in latest dirs
    gl = sorted(glob.glob(os.path.join(base, "VSP_CI_*")), reverse=True)
    for d in gl:
        if rn in os.path.basename(d):
            return d
    return ""

def _pick_newest(patterns):
    best = ""
    best_m = -1.0
    for pat in patterns:
        for f in glob.glob(pat):
            try:
                m = os.path.getmtime(f)
            except Exception:
                continue
            if m > best_m:
                best_m = m
                best = f
    return best

def _pick_pdf(ci_dir: str) -> str:
    return _pick_newest([
        os.path.join(ci_dir, "reports", "*.pdf"),
        os.path.join(ci_dir, "*.pdf"),
    ])

def _pick_html(ci_dir: str) -> str:
    return _pick_newest([
        os.path.join(ci_dir, "reports", "*.html"),
        os.path.join(ci_dir, "*.html"),
    ])

def _pick_zip(ci_dir: str) -> str:
    return _pick_newest([
        os.path.join(ci_dir, "reports", "*.zip"),
        os.path.join(ci_dir, "*.zip"),
    ])


    ### [COMMERCIAL] EXPORT_FORCEFS_V2 ###

    # NOTE: this is the REAL handler bound to /api/vsp/run_export_v3/<rid>

    import os, json, csv, glob, shutil, zipfile, tempfile, subprocess

    from datetime import datetime, timezone


    fmt = (request.args.get('fmt') or 'zip').lower()

    rid_str = str(rid)

    rid_norm = rid_str.replace('RUN_', '')


    def nowz():

        return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')


    def find_run_dir(rid_norm: str):

        cands = []

        cands += glob.glob('/home/test/Data/SECURITY-*/out_ci/' + rid_norm)

        cands += glob.glob('/home/test/Data/*/out_ci/' + rid_norm)

        for x in cands:

            try:

                if os.path.isdir(x):

                    return x

            except Exception:

                pass

        return None


    def ensure_report(run_dir: str):

        report_dir = os.path.join(run_dir, 'report')

        os.makedirs(report_dir, exist_ok=True)


        # copy unified json into report/ if needed

        src_json = os.path.join(run_dir, 'findings_unified.json')

        dst_json = os.path.join(report_dir, 'findings_unified.json')

        if os.path.isfile(src_json) and (not os.path.isfile(dst_json)):

            try:

                shutil.copy2(src_json, dst_json)

            except Exception:

                pass


        # build csv if missing

        dst_csv = os.path.join(report_dir, 'findings_unified.csv')

        if (not os.path.isfile(dst_csv)) and os.path.isfile(dst_json):

            cols = ['tool','severity','title','file','line','cwe','fingerprint']

            try:

                d = json.load(open(dst_json,'r',encoding='utf-8'))

                items = d.get('items') or []

                with open(dst_csv,'w',encoding='utf-8',newline='') as f:

                    w = csv.DictWriter(f, fieldnames=cols)

                    w.writeheader()

                    for it in items:

                        cwe = it.get('cwe')

                        if isinstance(cwe, list):

                            cwe = ','.join(cwe)

                        w.writerow({

                            'tool': it.get('tool'),

                            'severity': (it.get('severity_norm') or it.get('severity')),

                            'title': it.get('title'),

                            'file': it.get('file'),

                            'line': it.get('line'),

                            'cwe': cwe,

                            'fingerprint': it.get('fingerprint'),

                        })

            except Exception:

                pass


        # build minimal html if missing

        html_path = os.path.join(report_dir, 'export_v3.html')

        if not (os.path.isfile(html_path) and os.path.getsize(html_path) > 0):

            total = 0

            sev = {}

            try:

                if os.path.isfile(dst_json):

                    d = json.load(open(dst_json,'r',encoding='utf-8'))

                    items = d.get('items') or []

                    total = len(items)

                    for it in items:

                        k = (it.get('severity_norm') or it.get('severity') or 'INFO').upper()

                        sev[k] = sev.get(k, 0) + 1

            except Exception:

                pass

            rows = ''

            for k,v in sorted(sev.items(), key=lambda kv:(-kv[1], kv[0])):

                rows += f"<tr><td>{k}</td><td>{v}</td></tr>\n"

            if not rows:

                rows = "<tr><td colspan='2'>(none)</td></tr>"

            html = (

                "<!doctype html><html><head><meta charset='utf-8'/>"

                "<title>VSP Export</title>"

                "<style>body{font-family:Arial;padding:24px} table{border-collapse:collapse;width:100%}"

                "td,th{border:1px solid #eee;padding:6px 8px}</style></head><body>"

                f"<h2>VSP Export v3</h2><p>Generated: {nowz()}</p><p><b>Total findings:</b> {total}</p>"

                "<h3>By severity</h3><table><tr><th>Severity</th><th>Count</th></tr>" + rows + "</table>"

                "</body></html>"

            )

            try:

                with open(html_path,'w',encoding='utf-8') as f:

                    f.write(html)

            except Exception:

                pass


        return report_dir


    def zip_dir(report_dir: str):

        tmp = tempfile.NamedTemporaryFile(prefix='vsp_export_', suffix='.zip', delete=False)

        tmp.close()

        with zipfile.ZipFile(tmp.name, 'w', compression=zipfile.ZIP_DEFLATED) as z:

            for root, _, files in os.walk(report_dir):

                for fn in files:

                    ap = os.path.join(root, fn)

                    rel = os.path.relpath(ap, report_dir)

                    z.write(ap, arcname=rel)

        return tmp.name


    def pdf_from_html(html_file: str, timeout_sec: int = 180):

        exe = shutil.which('wkhtmltopdf')

        if not exe:

            return None, 'wkhtmltopdf_missing'

        tmp = tempfile.NamedTemporaryFile(prefix='vsp_export_', suffix='.pdf', delete=False)

        tmp.close()

        try:

            subprocess.run([exe, '--quiet', html_file, tmp.name], timeout=timeout_sec, check=True)

            if os.path.isfile(tmp.name) and os.path.getsize(tmp.name) > 0:

                return tmp.name, None

            return None, 'wkhtmltopdf_empty_output'

        except Exception as ex:

            return None, 'wkhtmltopdf_failed:' + type(ex).__name__


    # PROBE proves this handler is active

    if (request.args.get('probe') or '') == '1':

        resp = jsonify({'ok': True, 'probe': 'EXPORT_FORCEFS_V2', 'rid_norm': rid_norm, 'fmt': fmt})

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '1'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp


    run_dir = find_run_dir(rid_norm)

    if (not run_dir) or (not os.path.isdir(run_dir)):

        resp = jsonify({'ok': False, 'error': 'RUN_DIR_NOT_FOUND', 'rid_norm': rid_norm})

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '0'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp, 404


    report_dir = ensure_report(run_dir)

    html_file = os.path.join(report_dir, 'export_v3.html')


    if fmt == 'html':

        resp = send_file(html_file, mimetype='text/html', as_attachment=True, download_name=rid_norm + '.html')

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '1'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp


    if fmt == 'zip':

        zpath = zip_dir(report_dir)

        resp = send_file(zpath, mimetype='application/zip', as_attachment=True, download_name=rid_norm + '.zip')

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '1'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp


    if fmt == 'pdf':

        pdf_path, err = pdf_from_html(html_file, timeout_sec=180)

        if pdf_path:

            resp = send_file(pdf_path, mimetype='application/pdf', as_attachment=True, download_name=rid_norm + '.pdf')

            resp.headers['X-VSP-EXPORT-AVAILABLE'] = '1'

            resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

            return resp

        resp = jsonify({'ok': False, 'error': 'PDF_EXPORT_FAILED', 'detail': err})

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '0'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp, 500


    resp = jsonify({'ok': False, 'error': 'BAD_FMT', 'fmt': fmt, 'allowed': ['html','zip','pdf']})

    resp.headers['X-VSP-EXPORT-AVAILABLE'] = '0'

    resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

    return resp, 400

### [COMMERCIAL] EXPORT_FORCE_BIND_V4 ###
def _vsp_export_v3_forcefs_impl(rid=None):
    """
    Commercial force-fs export handler for:
      - /api/vsp/run_export_v3/<rid>?fmt=html|zip|pdf
      - /api/vsp/run_export_v3?rid=...&fmt=...
    """
    import os, json, csv, glob, shutil, zipfile, tempfile, subprocess
    from datetime import datetime, timezone
    from flask import request, jsonify, send_file, current_app

    fmt = (request.args.get("fmt") or "zip").lower()
    probe = (request.args.get("probe") or "") == "1"

    # allow rid via query for the non-<rid> route
    if (rid is None) or (str(rid).lower() in ("", "none", "null")):
        rid = request.args.get("rid") or request.args.get("run_id") or request.args.get("id")

    rid_str = "" if rid is None else str(rid)
    rid_norm = rid_str.replace("RUN_", "")

    def nowz():
        return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00","Z")

    def resolve_run_dir_by_status_v2(rid_value: str):
        try:
            fn = current_app.view_functions.get("api_vsp_run_status_v2_winlast_v6")
            if not fn:
                return None
            r = fn(rid_value)
            payload = None
            if isinstance(r, tuple) and len(r) >= 1 and hasattr(r[0], "get_json"):
                payload = r[0].get_json(silent=True)
            elif hasattr(r, "get_json"):
                payload = r.get_json(silent=True)
            if isinstance(payload, dict):
                rd = payload.get("ci_run_dir") or payload.get("ci") or payload.get("run_dir")
                if isinstance(rd, str) and rd and os.path.isdir(rd):
                    return rd
        except Exception:
            return None
        return None

    def resolve_run_dir_fallback(rid_norm_value: str):
        cands = []
        cands += glob.glob("/home/test/Data/SECURITY-*/out_ci/" + rid_norm_value)
        cands += glob.glob("/home/test/Data/*/out_ci/" + rid_norm_value)
        for x in cands:
            try:
                if os.path.isdir(x):
                    return x
            except Exception:
                pass
        return None

    def ensure_report(run_dir: str):
        report_dir = os.path.join(run_dir, "report")
        os.makedirs(report_dir, exist_ok=True)

        src_json = os.path.join(run_dir, "findings_unified.json")
        dst_json = os.path.join(report_dir, "findings_unified.json")
        if os.path.isfile(src_json) and (not os.path.isfile(dst_json)):
            try:
                shutil.copy2(src_json, dst_json)
            except Exception:
                pass

        dst_csv = os.path.join(report_dir, "findings_unified.csv")
        if (not os.path.isfile(dst_csv)) and os.path.isfile(dst_json):
            cols = ["tool","severity","title","file","line","cwe","fingerprint"]
            try:
                d = json.load(open(dst_json, "r", encoding="utf-8"))
                items = d.get("items") or []
                with open(dst_csv, "w", encoding="utf-8", newline="") as f:
                    w = csv.DictWriter(f, fieldnames=cols)
                    w.writeheader()
                    for it in items:
                        cwe = it.get("cwe")
                        if isinstance(cwe, list):
                            cwe = ",".join(cwe)
                        w.writerow({
                            "tool": it.get("tool"),
                            "severity": (it.get("severity_norm") or it.get("severity")),
                            "title": it.get("title"),
                            "file": it.get("file"),
                            "line": it.get("line"),
                            "cwe": cwe,
                            "fingerprint": it.get("fingerprint"),
                        })
            except Exception:
                pass

        html_path = os.path.join(report_dir, "export_v3.html")
        if not (os.path.isfile(html_path) and os.path.getsize(html_path) > 0):
            total = 0
            sev = {}
            try:
                if os.path.isfile(dst_json):
                    d = json.load(open(dst_json, "r", encoding="utf-8"))
                    items = d.get("items") or []
                    total = len(items)
                    for it in items:
                        k = (it.get("severity_norm") or it.get("severity") or "INFO").upper()
                        sev[k] = sev.get(k, 0) + 1
            except Exception:
                pass
            rows = ""
            for k,v in sorted(sev.items(), key=lambda kv:(-kv[1], kv[0])):
                rows += f"<tr><td>{k}</td><td>{v}</td></tr>\n"
            if not rows:
                rows = "<tr><td colspan='2'>(none)</td></tr>"
            html = (
                "<!doctype html><html><head><meta charset='utf-8'/>"
                "<title>VSP Export</title>"
                "<style>body{font-family:Arial;padding:24px} table{border-collapse:collapse;width:100%}"
                "td,th{border:1px solid #eee;padding:6px 8px}</style></head><body>"
                f"<h2>VSP Export v3</h2><p>Generated: {nowz()}</p><p><b>Total findings:</b> {total}</p>"
                "<h3>By severity</h3><table><tr><th>Severity</th><th>Count</th></tr>" + rows + "</table>"
                "</body></html>"
            )
            try:
                with open(html_path, "w", encoding="utf-8") as f:
                    f.write(html)
            except Exception:
                pass

        return report_dir

    def zip_dir(report_dir: str):
        tmp = tempfile.NamedTemporaryFile(prefix="vsp_export_", suffix=".zip", delete=False)
        tmp.close()
        with zipfile.ZipFile(tmp.name, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(report_dir):
                for fn in files:
                    ap = os.path.join(root, fn)
                    rel = os.path.relpath(ap, report_dir)
                    z.write(ap, arcname=rel)
        return tmp.name

    def pdf_from_html(html_file: str, timeout_sec: int = 180):
        exe = shutil.which("wkhtmltopdf")
        if not exe:
            return None, "wkhtmltopdf_missing"
        tmp = tempfile.NamedTemporaryFile(prefix="vsp_export_", suffix=".pdf", delete=False)
        tmp.close()
        try:
            subprocess.run([exe, "--quiet", html_file, tmp.name], timeout=timeout_sec, check=True)
            if os.path.isfile(tmp.name) and os.path.getsize(tmp.name) > 0:
                return tmp.name, None
            return None, "wkhtmltopdf_empty_output"
        except Exception as ex:
            return None, "wkhtmltopdf_failed:" + type(ex).__name__

    # PROBE must always prove handler is active
    if probe:
        resp = jsonify({
            "ok": True,
            "probe": "EXPORT_FORCE_BIND_V4",
            "rid": rid_str,
            "rid_norm": rid_norm,
            "fmt": fmt
        })
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp

    if not rid_str:
        resp = jsonify({"ok": False, "error": "RID_MISSING"})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp, 400

    run_dir = resolve_run_dir_by_status_v2(rid_str) or resolve_run_dir_fallback(rid_norm)
    if (not run_dir) or (not os.path.isdir(run_dir)):
        resp = jsonify({"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid_str, "rid_norm": rid_norm})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp, 404

    report_dir = ensure_report(run_dir)
    html_file = os.path.join(report_dir, "export_v3.html")

    if fmt == "html":
        resp = send_file(html_file, mimetype="text/html", as_attachment=True, download_name=rid_norm + ".html")
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp

    if fmt == "zip":
        zpath = zip_dir(report_dir)
        resp = send_file(zpath, mimetype="application/zip", as_attachment=True, download_name=rid_norm + ".zip")
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp

    if fmt == "pdf":
        pdf_path, err = pdf_from_html(html_file, timeout_sec=180)
        if pdf_path:
            resp = send_file(pdf_path, mimetype="application/pdf", as_attachment=True, download_name=rid_norm + ".pdf")
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
            resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
            return resp
        resp = jsonify({"ok": False, "error": "PDF_EXPORT_FAILED", "detail": err})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp, 500

    resp = jsonify({"ok": False, "error": "BAD_FMT", "fmt": fmt, "allowed": ["html","zip","pdf"]})
    resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
    resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
    return resp, 400


# Bind hard to endpoints (avoid route confusion)
try:
    if "api_vsp_run_export_v3_force_fs" in app.view_functions:
        app.view_functions["api_vsp_run_export_v3_force_fs"] = _vsp_export_v3_forcefs_impl
    if "vsp_run_export_v3" in app.view_functions:
        app.view_functions["vsp_run_export_v3"] = _vsp_export_v3_forcefs_impl
except Exception:
    pass

### [COMMERCIAL] EXPORT_FORCE_BIND_V5 ###
def _vsp_export_v3_forcefs_impl_v5(rid=None):
    import os, json, csv, glob, shutil, zipfile, tempfile, subprocess
    from datetime import datetime, timezone
    from flask import request, jsonify, send_file, current_app

    fmt = (request.args.get("fmt") or "zip").lower()
    probe = (request.args.get("probe") or "") == "1"

    # allow rid via query for the non-<rid> route
    if (rid is None) or (str(rid).lower() in ("", "none", "null")):
        rid = request.args.get("rid") or request.args.get("run_id") or request.args.get("id")

    rid_str = "" if rid is None else str(rid)
    rid_norm = rid_str.replace("RUN_", "")

    def nowz():
        return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00","Z")

    def resolve_run_dir_by_status_v2(rid_value: str):
        try:
            fn = current_app.view_functions.get("api_vsp_run_status_v2_winlast_v6")
            if not fn:
                return None
            r = fn(rid_value)
            payload = None
            if isinstance(r, tuple) and len(r) >= 1 and hasattr(r[0], "get_json"):
                payload = r[0].get_json(silent=True)
            elif hasattr(r, "get_json"):
                payload = r.get_json(silent=True)
            if isinstance(payload, dict):
                rd = payload.get("ci_run_dir") or payload.get("ci") or payload.get("run_dir")
                if isinstance(rd, str) and rd and os.path.isdir(rd):
                    return rd
        except Exception:
            return None
        return None

    def resolve_run_dir_fallback(rid_norm_value: str):
        cands = []
        cands += glob.glob("/home/test/Data/SECURITY-*/out_ci/" + rid_norm_value)
        cands += glob.glob("/home/test/Data/*/out_ci/" + rid_norm_value)
        for x in cands:
            try:
                if os.path.isdir(x):
                    return x
            except Exception:
                pass
        return None

    def ensure_report(run_dir: str):
        report_dir = os.path.join(run_dir, "report")
        os.makedirs(report_dir, exist_ok=True)

        src_json = os.path.join(run_dir, "findings_unified.json")
        dst_json = os.path.join(report_dir, "findings_unified.json")
        if os.path.isfile(src_json) and (not os.path.isfile(dst_json)):
            try:
                shutil.copy2(src_json, dst_json)
            except Exception:
                pass

        dst_csv = os.path.join(report_dir, "findings_unified.csv")
        if (not os.path.isfile(dst_csv)) and os.path.isfile(dst_json):
            cols = ["tool","severity","title","file","line","cwe","fingerprint"]
            try:
                d = json.load(open(dst_json, "r", encoding="utf-8"))
                items = d.get("items") or []
                with open(dst_csv, "w", encoding="utf-8", newline="") as f:
                    w = csv.DictWriter(f, fieldnames=cols)
                    w.writeheader()
                    for it in items:
                        cwe = it.get("cwe")
                        if isinstance(cwe, list):
                            cwe = ",".join(cwe)
                        w.writerow({
                            "tool": it.get("tool"),
                            "severity": (it.get("severity_norm") or it.get("severity")),
                            "title": it.get("title"),
                            "file": it.get("file"),
                            "line": it.get("line"),
                            "cwe": cwe,
                            "fingerprint": it.get("fingerprint"),
                        })
            except Exception:
                pass

        html_path = os.path.join(report_dir, "export_v3.html")
        if not (os.path.isfile(html_path) and os.path.getsize(html_path) > 0):
            total = 0
            sev = {}
            try:
                if os.path.isfile(dst_json):
                    d = json.load(open(dst_json, "r", encoding="utf-8"))
                    items = d.get("items") or []
                    total = len(items)
                    for it in items:
                        k = (it.get("severity_norm") or it.get("severity") or "INFO").upper()
                        sev[k] = sev.get(k, 0) + 1
            except Exception:
                pass
            rows = ""
            for k,v in sorted(sev.items(), key=lambda kv:(-kv[1], kv[0])):
                rows += f"<tr><td>{k}</td><td>{v}</td></tr>\n"
            if not rows:
                rows = "<tr><td colspan='2'>(none)</td></tr>"
            html = (
                "<!doctype html><html><head><meta charset='utf-8'/>"
                "<title>VSP Export</title>"
                "<style>body{font-family:Arial;padding:24px} table{border-collapse:collapse;width:100%}"
                "td,th{border:1px solid #eee;padding:6px 8px}</style></head><body>"
                f"<h2>VSP Export v3</h2><p>Generated: {nowz()}</p><p><b>Total findings:</b> {total}</p>"
                "<h3>By severity</h3><table><tr><th>Severity</th><th>Count</th></tr>" + rows + "</table>"
                "</body></html>"
            )
            try:
                with open(html_path, "w", encoding="utf-8") as f:
                    f.write(html)
            except Exception:
                pass

        return report_dir

    def zip_dir(report_dir: str):
        tmp = tempfile.NamedTemporaryFile(prefix="vsp_export_", suffix=".zip", delete=False)
        tmp.close()
        with zipfile.ZipFile(tmp.name, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(report_dir):
                for fn in files:
                    ap = os.path.join(root, fn)
                    rel = os.path.relpath(ap, report_dir)
                    z.write(ap, arcname=rel)
        return tmp.name

    def pdf_from_html(html_file: str, timeout_sec: int = 180):
        exe = shutil.which("wkhtmltopdf")
        if not exe:
            return None, "wkhtmltopdf_missing"
        tmp = tempfile.NamedTemporaryFile(prefix="vsp_export_", suffix=".pdf", delete=False)
        tmp.close()
        try:
            subprocess.run([exe, "--quiet", html_file, tmp.name], timeout=timeout_sec, check=True)
            if os.path.isfile(tmp.name) and os.path.getsize(tmp.name) > 0:
                return tmp.name, None
            return None, "wkhtmltopdf_empty_output"
        except Exception as ex:
            return None, "wkhtmltopdf_failed:" + type(ex).__name__

    if probe:
        resp = jsonify({"ok": True, "probe": "EXPORT_FORCE_BIND_V5", "rid": rid_str, "rid_norm": rid_norm, "fmt": fmt})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp

    if not rid_str:
        resp = jsonify({"ok": False, "error": "RID_MISSING"})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp, 400

    run_dir = resolve_run_dir_by_status_v2(rid_str) or resolve_run_dir_fallback(rid_norm)
    if (not run_dir) or (not os.path.isdir(run_dir)):
        resp = jsonify({"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid_str, "rid_norm": rid_norm})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp, 404

    report_dir = ensure_report(run_dir)
    html_file = os.path.join(report_dir, "export_v3.html")

    if fmt == "html":
        resp = send_file(html_file, mimetype="text/html", as_attachment=True, download_name=rid_norm + ".html")
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp

    if fmt == "zip":
        zpath = zip_dir(report_dir)
        resp = send_file(zpath, mimetype="application/zip", as_attachment=True, download_name=rid_norm + ".zip")
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp

    if fmt == "pdf":
        pdf_path, err = pdf_from_html(html_file, timeout_sec=180)
        if pdf_path:
            resp = send_file(pdf_path, mimetype="application/pdf", as_attachment=True, download_name=rid_norm + ".pdf")
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
            resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
            return resp
        resp = jsonify({"ok": False, "error": "PDF_EXPORT_FAILED", "detail": err})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp, 500

    resp = jsonify({"ok": False, "error": "BAD_FMT", "fmt": fmt, "allowed": ["html","zip","pdf"]})
    resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
    resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
    return resp, 400


# Rebind on every first request (guaranteed to happen AFTER all wrappers are installed)
try:
    @app.before_request
    def _vsp_export_v3_force_bind_v5_before_request():
        if app.config.get("VSP_EXPORT_FORCE_BIND_V5_DONE"):
            return None
        changed = []
        for rule in list(app.url_map.iter_rules()):
            if "run_export_v3" in (rule.rule or ""):
                ep = rule.endpoint
                if ep in app.view_functions:
                    app.view_functions[ep] = _vsp_export_v3_forcefs_impl_v5
                    changed.append((rule.rule, ep))
        app.config["VSP_EXPORT_FORCE_BIND_V5_DONE"] = True
        if changed:
            print("[VSP_EXPORT_FORCE_BIND_V5] rebound:", changed[:10])
        return None
except Exception as _e:
    pass

# === VSP_EXPORT_V3_COMMERCIAL_REAL_V1 BEGIN ===
# 목적: /api/vsp/run_export_v3/<rid> must return REAL html/zip/pdf (not JSON fallback)
try:
    from flask import request, jsonify, make_response, send_file, render_template
except Exception:
    request = None
    jsonify = None
    make_response = None
    send_file = None
    render_template = None

import os, json, tempfile, zipfile, shutil, subprocess
from pathlib import Path
from datetime import datetime, timezone

def _vsp_export_v3_resolve_run_dir_real_v1(rid: str):
    """
    Accepts:
      - RUN_VSP_CI_YYYYmmdd_HHMMSS  -> maps to VSP_CI_YYYYmmdd_HHMMSS
      - VSP_CI_YYYYmmdd_HHMMSS      -> direct
    Tries common parents to avoid slow rglob.
    """
    if not rid or rid == "null":
        return None, "rid_null"

    base = rid.strip()
    if base.startswith("RUN_"):
        base = base[len("RUN_"):]
    # now base usually == VSP_CI_...

    parents = [
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out",
    ]
    for parent in parents:
        p = Path(parent)
        if not p.exists():
            continue
        cand = p / base
        if cand.exists() and cand.is_dir():
            return str(cand), f"direct:{cand}"

    # last-resort bounded search (still cheap): check two well-known roots
    roots = ["/home/test/Data/SECURITY_BUNDLE", "/home/test/Data/SECURITY-10-10-v4"]
    for root in roots:
        r = Path(root)
        if not r.exists():
            continue
        for sub in (r / "out_ci" / base, r / "out" / base):
            if sub.exists() and sub.is_dir():
                return str(sub), f"glob:{sub}"

    return None, "not_found"

def _vsp_export_v3_pick_html_real_v1(run_dir: str):
    """
    Prefer an existing CIO html in report/.
    Otherwise generate a minimal HTML from findings_unified.json.
    """
    report = Path(run_dir) / "report"
    for name in [
        "vsp_run_report_cio_v3.html",
        "vsp_run_report_cio_v2.html",
        "run_report.html",
        "export_v3.html",
        "index.html",
        "report.html",
    ]:
        f = report / name
        if f.exists() and f.is_file() and f.stat().st_size > 200:
            return f, f"file:{name}"

    fu = Path(run_dir) / "findings_unified.json"
    total = None
    bysev = {}
    if fu.exists() and fu.is_file():
        try:
            data = json.load(open(fu, "r", encoding="utf-8"))
            total = data.get("total")
            # fast-ish severity count (cap to avoid worst-case memory)
            for it in (data.get("items") or [])[:200000]:
                sev = (it.get("severity") or "TRACE").upper()
                bysev[sev] = bysev.get(sev, 0) + 1
        except Exception:
            pass

    now = datetime.now(timezone.utc).isoformat()
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>VSP Export {run_dir}</title></head>
<body style="font-family: Arial, sans-serif">
<h1>VSP Export (Generated)</h1>
<p><b>run_dir</b>: {run_dir}</p>
<p><b>generated_at_utc</b>: {now}</p>
<h2>Findings summary</h2>
<p><b>total</b>: {total}</p>
<pre>{json.dumps(bysev, indent=2, ensure_ascii=False)}</pre>
</body></html>"""
    return html, "generated:inline"

def _vsp_export_v3_send_html_real_v1(html_or_path, mode: str):
    if isinstance(html_or_path, Path):
        body = html_or_path.read_text(encoding="utf-8", errors="replace")
        resp = make_response(body, 200)
        resp.headers["Content-Type"] = "text/html; charset=utf-8"
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = mode
        return resp
    else:
        resp = make_response(html_or_path, 200)
        resp.headers["Content-Type"] = "text/html; charset=utf-8"
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = mode
        return resp

def _vsp_export_v3_make_zip_real_v1(run_dir: str, rid: str):
    tmp = tempfile.NamedTemporaryFile(prefix=f"vsp_export_{rid}_", suffix=".zip", delete=False)
    tmp.close()
    zpath = Path(tmp.name)
    base = Path(run_dir)

    with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for rel in ["report", "findings_unified.json", "findings_unified.csv", "SUMMARY.txt", "runner.log"]:
            p = base / rel
            if not p.exists():
                continue
            if p.is_dir():
                for f in p.rglob("*"):
                    if f.is_file():
                        zf.write(f, arcname=str(f.relative_to(base)))
            else:
                zf.write(p, arcname=str(p.relative_to(base)))
    return zpath

def _vsp_export_v3_make_pdf_real_v1(run_dir: str, rid: str):
    wk = shutil.which("wkhtmltopdf")
    if not wk:
        return None, {"ok": False, "error": "WKHTMLTOPDF_NOT_FOUND"}

    report_dir = Path(run_dir) / "report"
    report_dir.mkdir(parents=True, exist_ok=True)

    html_or_path, mode = _vsp_export_v3_pick_html_real_v1(run_dir)
    if isinstance(html_or_path, Path):
        html_path = html_or_path
    else:
        html_path = report_dir / "export_v3_generated.html"
        html_path.write_text(html_or_path, encoding="utf-8")

    tmp = tempfile.NamedTemporaryFile(prefix=f"vsp_export_{rid}_", suffix=".pdf", delete=False)
    tmp.close()
    pdf_path = Path(tmp.name)

    cmd = [wk, "--quiet", str(html_path), str(pdf_path)]
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0 or (not pdf_path.exists()) or pdf_path.stat().st_size < 1000:
        return None, {
            "ok": False,
            "error": "WKHTMLTOPDF_FAILED",
            "rc": r.returncode,
            "stderr_tail": (r.stderr or "")[-2000:],
        }
    return pdf_path, {"ok": True, "mode": mode, "wkhtmltopdf": wk}

# Register routes SAFELY (avoid AssertionError if reloaded)
try:
    _app = app  # app must exist in vsp_demo_app.py
except Exception:
    _app = None

if _app is not None:
    # /vsp4 page (optional fix) - only if not already registered
    if "vsp4_page_commercial_real_v1" not in _app.view_functions:
        def vsp4_page_commercial_real_v1():
            # render your 4-tabs commercial template if exists; else simple message
            try:
                return render_template("vsp_4tabs_commercial_v1.html")
            except Exception:
                return "VSP4 template not found", 404
        _app.add_url_rule("/vsp4", endpoint="vsp4_page_commercial_real_v1", view_func=vsp4_page_commercial_real_v1, methods=["GET"])

    # export v3 route
    if "api_vsp_run_export_v3_commercial_real_v1" not in _app.view_functions:
        def api_vsp_run_export_v3_commercial_real_v1(rid):
            fmt = (request.args.get("fmt") or "").lower().strip()
            probe = request.args.get("probe")

            run_dir, how = _vsp_export_v3_resolve_run_dir_real_v1(rid)
            if not run_dir:
                payload = {"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid, "resolved": None, "how": how}
                return jsonify(payload), 404

            # probe = advertise capability
            if probe:
                wk = shutil.which("wkhtmltopdf")
                return jsonify({
                    "ok": True,
                    "rid": rid,
                    "run_dir": run_dir,
                    "how": how,
                    "available": {"html": True, "zip": True, "pdf": bool(wk)},
                    "wkhtmltopdf": wk
                }), 200

            if fmt in ("", "html"):
                html_or_path, mode = _vsp_export_v3_pick_html_real_v1(run_dir)
                return _vsp_export_v3_send_html_real_v1(html_or_path, mode)

            if fmt == "zip":
                zpath = _vsp_export_v3_make_zip_real_v1(run_dir, rid)
                return send_file(str(zpath), mimetype="application/zip", as_attachment=True, download_name=f"{rid}.zip")

            if fmt == "pdf":
                pdf_path, meta = _vsp_export_v3_make_pdf_real_v1(run_dir, rid)
                if not pdf_path:
                    return jsonify({"ok": False, "rid": rid, **meta}), 501 if meta.get("error") == "WKHTMLTOPDF_NOT_FOUND" else 500
                return send_file(str(pdf_path), mimetype="application/pdf", as_attachment=True, download_name=f"{rid}.pdf")

            return jsonify({"ok": False, "error": "BAD_FMT", "fmt": fmt, "rid": rid}), 400

        _app.add_url_rule(
            "/api/vsp/run_export_v3/<rid>",
            endpoint="api_vsp_run_export_v3_commercial_real_v1",
            view_func=api_vsp_run_export_v3_commercial_real_v1,
            methods=["GET"],
        )

# === VSP_EXPORT_V3_COMMERCIAL_REAL_V1 END ===

# === VSP_RULE_OVERRIDES_API_V1 BEGIN ===
import json
from pathlib import Path
from flask import request, jsonify

_RULE_OVR_PATH = Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/vsp_rule_overrides_v1.json")

def _rule_ovr_default():
    return {
        "meta": {"version": "v1", "updated_at": None},
        "overrides": []
    }

@app.route("/api/vsp/rule_overrides_v1", methods=["GET"])
def api_vsp_rule_overrides_get_v1():
    if _RULE_OVR_PATH.exists():
        try:
            return jsonify(json.load(open(_RULE_OVR_PATH, "r", encoding="utf-8")))
        except Exception:
            return jsonify(_rule_ovr_default()), 200
    return jsonify(_rule_ovr_default()), 200

@app.route("/api/vsp/rule_overrides_v1", methods=["POST"])
def api_vsp_rule_overrides_post_v1():
    data = request.get_json(silent=True) or _rule_ovr_default()
    try:
        data.setdefault("meta", {})
        data["meta"]["updated_at"] = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
        _RULE_OVR_PATH.parent.mkdir(parents=True, exist_ok=True)
        json.dump(data, open(_RULE_OVR_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        return jsonify({"ok": True, "file": str(_RULE_OVR_PATH)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500
# === VSP_RULE_OVERRIDES_API_V1 END ===


### VSP_RULE_OVERRIDES_APPLY_PREVIEW_V1 ###
# NOTE: commercial P0: preview/apply rule overrides -> effective findings
import os, json, urllib.request, urllib.error
from datetime import datetime, timezone
from flask import request, jsonify

try:
    from vsp_rule_overrides_apply_v1 import load_overrides_file, apply_overrides, summarize
except Exception as _e:
    load_overrides_file = None
    apply_overrides = None
    summarize = None

def _vsp_http_get_json_local(path, timeout_sec=1.2):
    # P0 commercial: NEVER hang worker by self-calling local HTTP. Fail-soft.
    import json, urllib.request
    url = 'http://127.0.0.1:8910' + str(path)
    try:
        req = urllib.request.Request(url, headers={'Accept': 'application/json'})
        with urllib.request.urlopen(req, timeout=float(timeout_sec)) as resp:
            raw = resp.read().decode('utf-8', 'ignore')
            return json.loads(raw) if raw else {}
    except Exception as e:
        return {'_degraded': True, '_error': str(e), '_path': str(path), '_url': url}

def _vsp_get_run_dir_from_statusv2(rid: str):
    st = _vsp_http_get_json_local(f"/api/vsp/run_status_v2/{rid}")
    rd = st.get("ci_run_dir") or st.get("ci") or st.get("run_dir")
    return rd, st

def _vsp_get_overrides_path():
    return os.environ.get("VSP_RULE_OVERRIDES_FILE") or "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/vsp_rule_overrides_v1.json"

def _vsp_load_findings_items(run_dir: str):
    f = os.path.join(run_dir, "findings_unified.json")
    if not os.path.isfile(f):
        return None, f, "findings_unified_not_found"
    try:
        doc = json.load(open(f, "r", encoding="utf-8"))
    except Exception:
        return None, f, "findings_unified_read_failed"
    items = doc.get("items") if isinstance(doc, dict) else None
    if not isinstance(items, list):
        return None, f, "findings_unified_bad_format"
    return items, f, None

def _vsp_apply_overrides_preview(rid: str):
    if not (load_overrides_file and apply_overrides and summarize):
        return {"ok":False, "error":"apply_module_missing"}

    run_dir, st = _vsp_get_run_dir_from_statusv2(rid)
    if not run_dir:
        return {"ok":False, "rid":rid, "error":"run_dir_not_resolved", "statusv2": st}

    items, fpath, err = _vsp_load_findings_items(run_dir)
    if err:
        return {"ok":False, "rid":rid, "run_dir":run_dir, "error":err, "file":fpath}

    ov_path = _vsp_get_overrides_path()
    meta, ovs = load_overrides_file(ov_path)
    now = datetime.now(timezone.utc)
    eff, delta = apply_overrides(items, ovs, now=now)

    out = {
        "ok": True,
        "rid": rid,
        "run_dir": run_dir,
        "overrides": meta,
        "delta": delta,
        "raw_summary": summarize(items),
        "effective_summary": summarize(eff),
        # return effective items for datasource
        "items": eff,
        "raw_total": len(items),
        "effective_total": len(eff),
    }
    return out

# GET: preview effective findings (raw+effective+delta)
if "api_vsp_findings_effective_v1" not in getattr(app, "view_functions", {}):
    @app.get("/api/vsp/findings_effective_v1/<rid>")
    def api_vsp_findings_effective_v1(rid):
        limit = int(request.args.get("limit", "200"))
        offset = int(request.args.get("offset", "0"))
        view = (request.args.get("view") or "effective").lower()  # effective|raw
        out = _vsp_apply_overrides_preview(rid)
        if not out.get("ok"):
            return jsonify(out), 200

        # optional raw view (no overrides)
        if view == "raw":
            run_dir = out.get("run_dir")
            items, fpath, err = _vsp_load_findings_items(run_dir)
            if err:
                return jsonify({"ok":False,"rid":rid,"error":err,"file":fpath}), 200
            out["items"] = items

        items = out.get("items") or []
        out["items_n"] = len(items)
        out["items"] = items[offset: offset+limit]
        out["offset"] = offset
        out["limit"] = limit
        out["view"] = view
        return jsonify(out), 200

# POST: apply and persist findings_effective.json to RUN_DIR
if "api_vsp_rule_overrides_apply_v1" not in getattr(app, "view_functions", {}):
    @app.post("/api/vsp/rule_overrides_apply_v1/<rid>")
    def api_vsp_rule_overrides_apply_v1(rid):
        out = _vsp_apply_overrides_preview(rid)
        if not out.get("ok"):
            return jsonify(out), 200
        run_dir = out.get("run_dir")
        f_out = os.path.join(run_dir, "findings_effective.json")
        try:
            with open(f_out, "w", encoding="utf-8") as f:
                json.dump(out, f, ensure_ascii=False, indent=2)
            out["persisted_file"] = f_out
            out["persist_ok"] = True
        except Exception as e:
            out["persist_ok"] = False
            out["persist_error"] = str(e)
        return jsonify(out), 200





### VSP_RUNS_INDEX_ALIAS_FALLBACK_V1 ###
# Backward-compat: some UI/scripts still call this; map it to filesystem scan.
if "api_vsp_runs_index_v3_fs_resolved" not in getattr(app, "view_functions", {}):
    @app.get("/api/vsp/runs_index_v3_fs_resolved")
    def api_vsp_runs_index_v3_fs_resolved():
        try:
            limit = int(request.args.get("limit","20"))
        except Exception:
            limit = 20
        items = _vsp_scan_latest_run_dirs(limit=limit)
        return jsonify({
          "ok": True,
          "items": items,
          "items_n": len(items),
          "source": "FS_FALLBACK_V1"
        }), 200

### VSP_RID_FALLBACK_FS_V1 ###
# commercial: RID fallback by filesystem when runs_index/dashboard returns null
import glob, os, json
from flask import jsonify, request

def _vsp_scan_latest_run_dirs(limit=50):
    pats = [
      "/home/test/Data/*/out_ci/VSP_CI_*",
      "/home/test/Data/*/out/VSP_CI_*",
      "/home/test/Data/SECURITY_BUNDLE/out_ci/VSP_CI_*",
      "/home/test/Data/SECURITY-10-10-v4/out_ci/VSP_CI_*",
    ]
    cands=[]
    for pat in pats:
        for d in glob.glob(pat):
            if os.path.isfile(os.path.join(d, "findings_unified.json")):
                try:
                    cands.append((os.path.getmtime(d), d))
                except Exception:
                    pass
    cands.sort(reverse=True)
    out=[]
    for _, d in cands[:max(1, int(limit))]:
        out.append({
          "rid": os.path.basename(d),
          "ci_run_dir": d,
          "has_findings_unified": True,
        })
    return out

@app.get("/api/vsp/runs_index_safe_v1")
def api_vsp_runs_index_safe_v1():
    limit = int(request.args.get("limit","20"))
    items = _vsp_scan_latest_run_dirs(limit=limit)
    return jsonify({"ok": True, "items": items, "items_n": len(items)}), 200

@app.get("/api/vsp/latest_rid_v1")
def api_vsp_latest_rid_v1():
    items = _vsp_scan_latest_run_dirs(limit=1)
    if not items:
        return jsonify({"ok": False, "error":"no_runs_found"}), 200
    item = items[0] if items else {}
    rid = item.get("run_id") or item.get("rid") or item.get("id") or item.get("run")
    ci = item.get("ci_run_dir") or item.get("run_dir") or item.get("dir")
    return jsonify({"ok": True, "rid": rid, "ci_run_dir": ci}), 200



### VSP_ARTIFACTS_API_V1 ###
# Artifacts API: list + serve selected artifacts (commercial safe whitelist)
import os, glob
from flask import jsonify, request
try:
    from flask import send_file, abort
except Exception:
    send_file = None
    abort = None

def _vsp_resolve_run_dir_by_rid(rid: str):
    if not rid:
        return None
    pats = [
      f"/home/test/Data/*/out_ci/{rid}",
      f"/home/test/Data/*/out/{rid}",
      f"/home/test/Data/SECURITY-10-10-v4/out_ci/{rid}",
      f"/home/test/Data/SECURITY_BUNDLE/out_ci/{rid}",
    ]
    for pat in pats:
        for d in glob.glob(pat.format(rid=rid)):
            if os.path.isdir(d):
                return d
    return None

# whitelist relative paths we are allowed to expose
_VSP_ART_WHITELIST = [
  "kics/kics.log",
  "kics/kics.json",
  "kics/kics_summary.json",
  "codeql/codeql.log",
  "codeql/codeql.sarif",
  "trivy/trivy.json",
  "trivy/trivy.json.err",
  "semgrep/semgrep.json",
  "gitleaks/gitleaks.json",
  "bandit/bandit.json",
  "syft/syft.json",
  "grype/grype.json",
  "SUMMARY.txt",
  "findings_unified.json",
  "findings_effective.json",
]

@app.get("/api/vsp/run_artifacts_index_v1/<rid>")
def api_vsp_run_artifacts_index_v1(rid):
    rd = _vsp_resolve_run_dir_by_rid(rid)
    if not rd:
        return jsonify({"ok": False, "rid": rid, "error": "run_dir_not_found", "items": []}), 200
    items = []
    for rel in _VSP_ART_WHITELIST:
        ap = os.path.join(rd, rel)
        if os.path.isfile(ap):
            try:
                sz = os.path.getsize(ap)
            except Exception:
                sz = None
            items.append({
              "name": rel,
              "rel": rel,
              "size": sz,
              "url": f"/api/vsp/run_artifact_raw_v1/{rid}?rel=" + rel
            })
    return jsonify({"ok": True, "rid": rid, "run_dir": rd, "items": items, "items_n": len(items)}), 200

@app.get("/api/vsp/run_artifact_raw_v1/<rid>")
def api_vsp_run_artifact_raw_v1(rid):
    if send_file is None:
        return jsonify({"ok": False, "rid": rid, "error": "send_file_unavailable"}), 500
    rel = request.args.get("rel","")
    if rel not in _VSP_ART_WHITELIST:
        return jsonify({"ok": False, "rid": rid, "error": "rel_not_allowed", "rel": rel}), 403
    rd = _vsp_resolve_run_dir_by_rid(rid)
    if not rd:
        return jsonify({"ok": False, "rid": rid, "error": "run_dir_not_found"}), 404
    ap = os.path.join(rd, rel)
    if not os.path.isfile(ap):
        return jsonify({"ok": False, "rid": rid, "error": "file_not_found", "rel": rel}), 404
    # serve inline (browser can open .log/.json)
    return send_file(ap, as_attachment=False)



### VSP_REPORT_CIO_V1 ###
import os
from flask import Response, jsonify, request

def _vsp_run_dir_report_cio_v1(rid: str):
    # Try reuse existing resolver if already defined by other patches
    for nm in ("_vsp_resolve_run_dir_by_rid", "_vsp_resolve_run_dir_by_rid_v1", "_vsp_resolve_run_dir_by_rid_v2"):
        fn = globals().get(nm)
        if callable(fn):
            rd = fn(rid)
            if rd: return rd
    # Fallback minimal glob resolver
    import glob
    pats = [
      f"/home/test/Data/*/out_ci/{rid}",
      f"/home/test/Data/*/out/{rid}",
      f"/home/test/Data/SECURITY-10-10-v4/out_ci/{rid}",
      f"/home/test/Data/SECURITY_BUNDLE/out_ci/{rid}",
    ]
    for pat in pats:
        for d in glob.glob(pat):
            if os.path.isdir(d):
                return d
    return None




### VSP_REPORT_CIO_DUALROUTE_V1 ###
import os, glob
from flask import Response, jsonify, request

def _vsp_resolve_run_dir_report_v1(rid: str):
    # prefer existing resolver if present
    for nm in ("_vsp_resolve_run_dir_by_rid", "_vsp_resolve_run_dir_by_rid_v1", "_vsp_resolve_run_dir_by_rid_v2", "_vsp_resolve_run_dir_by_rid_v3"):
        fn = globals().get(nm)
        if callable(fn):
            try:
                rd = fn(rid)
                if rd: return rd
            except Exception:
                pass
    # fallback glob
    pats = [
      f"/home/test/Data/*/out_ci/{rid}",
      f"/home/test/Data/*/out/{rid}",
      f"/home/test/Data/SECURITY-10-10-v4/out_ci/{rid}",
      f"/home/test/Data/SECURITY_BUNDLE/out_ci/{rid}",
    ]
    for pat in pats:
        for d in glob.glob(pat):
            if os.path.isdir(d):
                return d
    return None

def _vsp_build_report_ctx_v1(rid: str, rd: str):
    import traceback, importlib.util
    ui_root = os.path.abspath(os.path.dirname(__file__))
    tpl_path = os.path.join(ui_root, "report_templates", "vsp_report_cio_v1.html")
    if not os.path.isfile(tpl_path):
        return None, {"ok": False, "rid": rid, "error": "template_missing", "template": tpl_path}, 500

    try:
        mod_path = os.path.join(ui_root, "bin", "vsp_build_report_cio_v1.py")
        if not os.path.isfile(mod_path):
            return None, {"ok": False, "rid": rid, "error": "renderer_missing", "path": mod_path}, 500
        spec = importlib.util.spec_from_file_location("vsp_build_report_cio_v1", mod_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore
        if not hasattr(mod, "build"):
            return None, {"ok": False, "rid": rid, "error": "renderer_no_build"}, 500
        ctx = mod.build(rd, ui_root)
        return (ctx, {"ok": True, "rid": rid}, 200)
    except Exception as e:
        return None, {"ok": False, "rid": rid, "error": "renderer_failed", "detail": str(e), "trace": traceback.format_exc()[-2000:]}, 500

@app.get("/api/vsp/run_report_cio_v1/<rid>")
def api_vsp_run_report_cio_v1(rid):
    # API returns JSON only (commercial-safe). HTML is served by /vsp/report_cio_v1/<rid>.
    rd = _vsp_resolve_run_dir_report_v1(rid)
    if not rd:
        return jsonify({"ok": False, "rid": rid, "error": "run_dir_not_found"}), 200

    ctx, meta, code = _vsp_build_report_ctx_v1(rid, rd)
    if not ctx:
        return jsonify(meta), code

    return jsonify({
        "ok": True,
        "rid": rid,
        "run_dir": rd,
        "url": f"/vsp/report_cio_v1/{rid}",
        "note": "Open url for HTML report. API returns JSON by design."
    }), 200

@app.get("/vsp/report_cio_v1/<rid>")
def vsp_report_cio_v1(rid):
    # HTML report route (safe render with debug)
    import traceback
    from flask import render_template_string

    rd = _vsp_resolve_run_dir_report_v1(rid)
    if not rd:
        return Response(f"<h3>run_dir_not_found</h3><pre>{rid}</pre>", status=404, content_type="text/html; charset=utf-8")

    ctx, meta, code = _vsp_build_report_ctx_v1(rid, rd)
    if not ctx:
        return Response(f"<h3>report_failed</h3><pre>{meta}</pre>", status=500, content_type="text/html; charset=utf-8")

    ui_root = os.path.abspath(os.path.dirname(__file__))
    tpl_path = os.path.join(ui_root, "report_templates", "vsp_report_cio_v1.html")

    try:
        if not isinstance(ctx, dict):
            raise TypeError(f"ctx must be dict, got {type(ctx)}")
        tpl = open(tpl_path, "r", encoding="utf-8").read()
        # VSP_REPORT_CTX_RENAME_V1
        # avoid Flask arg-name collision: ctx['source'] conflicts with render_template_string(source,...)
        if isinstance(ctx, dict) and 'source' in ctx:
            ctx['source_id'] = ctx.get('source')
            ctx.pop('source', None)

        html = render_template_string(tpl, **ctx)
    except Exception as e:
        err = {
            "ok": False,
            "rid": rid,
            "error": "template_render_failed",
            "detail": str(e),
            "template": tpl_path,
            "ctx_keys_sample": sorted(list(ctx.keys()))[:80],
            "trace_tail": traceback.format_exc()[-2500:],
        }
        return Response(f"<h3>template_render_failed</h3><pre>{err}</pre>", status=500, content_type="text/html; charset=utf-8")

    # archive
    try:
        rep_dir = os.path.join(rd, "reports")
        os.makedirs(rep_dir, exist_ok=True)
        with open(os.path.join(rep_dir, "vsp_run_report_cio_v1.html"), "w", encoding="utf-8") as f:
            f.write(html)
    except Exception:
        pass

    return Response(html, status=200, content_type="text/html; charset=utf-8")


@app.get("/api/vsp/run_status_v2/<rid>")
def api_vsp_run_status_v2_contract_p1_v1(rid):
    # try to call existing v1/v2 provider if available, else return contract only
    base = {}
    try:
        # attempt reuse: if there is an internal helper, keep as-is
        pass
    except Exception:
        base = {}
    run_dir = base.get("ci_run_dir") or base.get("ci") or _vsp_find_run_dir(rid)
    if run_dir:
        base["ci_run_dir"] = run_dir
    base["run_id"] = rid

    total = _vsp_findings_total(run_dir) if run_dir else None
    if isinstance(total, int):
        base["total_findings"] = total
        base["has_findings"] = True if total > 0 else False

    dn, da = _vsp_degraded_info(run_dir) if run_dir else (None, None)
    if isinstance(dn, int):
        base["degraded_n"] = dn
    if isinstance(da, bool):
        base["degraded_any"] = da

    base.setdefault("ok", True)
    base.setdefault("status", base.get("status") or "UNKNOWN")
    return jsonify(base)


# === VSP_EXPORT_CIO_ROUTE_SAFE_V2_BEGIN ===
import os
import subprocess
from flask import send_file, request

@app.get("/api/vsp/run_export_cio_v1/<rid>")
def api_vsp_run_export_cio_v1(rid):
    fmt = (request.args.get("fmt") or "html").lower().strip()
    rebuild = (request.args.get("rebuild") or "0").strip() == "1"
    if fmt != "html":
        return jsonify({"ok": False, "error": "only_html_supported", "fmt": fmt, "rid": rid}), 400

    builder = "/home/test/Data/SECURITY_BUNDLE/bin/vsp_build_cio_report_v1.py"
    if not os.path.isfile(builder):
        return jsonify({"ok": False, "error": "missing_builder", "builder": builder, "rid": rid}), 500

    # Always build (or rebuild) deterministically
    cmd = ["python3", "-u", builder, rid]
    if rebuild:
        cmd = ["python3", "-u", builder, rid]

    r = subprocess.run(cmd, capture_output=True, text=True)
    # builder prints output path on success; parse it
    out_html = None
    for line in (r.stdout or "").splitlines():
        if "wrote " in line and "vsp_run_report_cio_v1.html" in line:
            out_html = line.split("wrote ",1)[1].split(" (run_dir=",1)[0].strip()
            break

    if not out_html or not os.path.isfile(out_html):
        # fallback: search common roots
        roots = [
          "/home/test/Data/SECURITY-10-10-v4/out_ci",
          "/home/test/Data/SECURITY_BUNDLE/out_ci",
          "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        ]
        for rr in roots:
            cand = os.path.join(rr, rid, "reports", "vsp_run_report_cio_v1.html")
            if os.path.isfile(cand):
                out_html = cand
                break

    if not out_html or not os.path.isfile(out_html):
        return jsonify({
            "ok": False,
            "error": "cio_report_not_found",
            "rid": rid,
            "builder_stdout": (r.stdout or "")[-2000:],
            "builder_stderr": (r.stderr or "")[-2000:],
            "rc": r.returncode
        }), 404

    return send_file(out_html, mimetype="text/html")
# === VSP_EXPORT_CIO_ROUTE_SAFE_V2_END ===


# === VSP_EXPORT_CIO_ROUTE_SAFE_V2B_BEGIN ===
import os
import subprocess
from flask import send_file, request

@app.get("/api/vsp/run_export_cio_v2/<rid>")
def api_vsp_run_export_cio_v2(rid):
    fmt = (request.args.get("fmt") or "html").lower().strip()

    # VSP_CIO_V2_PDF_DEGRADED_SAFE_BEGIN
    # commercial: PDF export for CIO v2 (resolve run_dir + auto-build HTML if missing)
    if fmt == "pdf":
        try:
            rid_local = rid

            # Resolve RUN_DIR by probing common roots (fast + accurate)
            run_dir_local = None
            for rr in [
                "/home/test/Data/SECURITY-10-10-v4/out_ci",
                "/home/test/Data/SECURITY_BUNDLE/out_ci",
                "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
                "/home/test/Data",
            ]:
                cand = Path(rr) / rid_local
                if cand.is_dir():
                    run_dir_local = str(cand)
                    break

            html_path_local = Path(run_dir_local) / "reports" / "vsp_run_report_cio_v2.html" if run_dir_local else None

            # Auto-build HTML if missing
            if not html_path_local or not html_path_local.is_file():
                builder = "/home/test/Data/SECURITY_BUNDLE/bin/vsp_cio_upgrade_v2_one_shot.sh"
                if Path(builder).is_file():
                    subprocess.run(["bash", builder, rid_local], timeout=60, check=False)
                if not html_path_local or not html_path_local.is_file():
                    resp = jsonify({
                        "ok": False,
                        "degraded": True,
                        "reason": "cio_v2_html_missing",
                        "hint": "run vsp_cio_upgrade_v2_one_shot.sh to build reports/vsp_run_report_cio_v2.html",
                        "run_dir": run_dir_local
                    })
                    resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
                    return resp, 200

            wk = shutil.which("wkhtmltopdf")
            if not wk:
                resp = jsonify({
                    "ok": False,
                    "degraded": True,
                    "reason": "wkhtmltopdf_missing",
                    "hint": "apt install wkhtmltopdf (or keep HTML export)"
                })
                resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
                return resp, 200

            pdf_path = str(html_path_local.with_suffix(".pdf"))
            need_build = (not Path(pdf_path).is_file()) or (Path(pdf_path).stat().st_mtime < html_path_local.stat().st_mtime)
            if need_build:
                subprocess.run([wk, "--quiet", str(html_path_local), pdf_path], timeout=90, check=True)

            resp = send_file(pdf_path, mimetype="application/pdf", as_attachment=False, download_name=Path(pdf_path).name)
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
            return resp
        except subprocess.TimeoutExpired:
            resp = jsonify({"ok": False, "degraded": True, "reason": "wkhtmltopdf_timeout"})
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
            return resp, 200
        except Exception as e:
            resp = jsonify({"ok": False, "degraded": True, "reason": "wkhtmltopdf_error", "error": str(e)})
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
            return resp, 200
    # VSP_CIO_V2_PDF_DEGRADED_SAFE_END



    rebuild = (request.args.get("rebuild") or "0").strip() == "1"
    if fmt != "html":
        return jsonify({"ok": False, "error": "only_html_supported", "fmt": fmt, "rid": rid}), 400

    builder = "/home/test/Data/SECURITY_BUNDLE/bin/vsp_build_cio_report_v2.py"
    if not os.path.isfile(builder):
        return jsonify({"ok": False, "error": "missing_builder", "builder": builder, "rid": rid}), 500

    r = subprocess.run(["python3","-u",builder,rid], capture_output=True, text=True)

    out_html = None
    for line in (r.stdout or "").splitlines():
        if "wrote " in line and "vsp_run_report_cio_v2.html" in line:
            out_html = line.split("wrote ",1)[1].split(" (run_dir=",1)[0].strip()
            break

    if rebuild or (not out_html) or (not os.path.isfile(out_html)):
        # fallback search common roots
        roots = [
          "/home/test/Data/SECURITY-10-10-v4/out_ci",
          "/home/test/Data/SECURITY_BUNDLE/out_ci",
          "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        ]
        for rr in roots:
            cand = os.path.join(rr, rid, "reports", "vsp_run_report_cio_v2.html")
            if os.path.isfile(cand):
                out_html = cand
                break

    if not out_html or not os.path.isfile(out_html):
        return jsonify({
            "ok": False,
            "error": "cio_report_not_found",
            "rid": rid,
            "builder_stdout": (r.stdout or "")[-2000:],
            "builder_stderr": (r.stderr or "")[-2000:],
            "rc": r.returncode
        }), 404

    return send_file(out_html, mimetype="text/html")
# === VSP_EXPORT_CIO_ROUTE_SAFE_V2B_END ===




### VSP_ROUTE_P_TS_204_BEGIN
@app.route("/P<token>")
def vsp_p_ts_204(token):
    # Some UI patches may accidentally embed /PYYMMDD_HHMMSS as a resource.
    # Return 204 to avoid console 404 noise; otherwise keep 404.
    try:
        if re.fullmatch(r"\d{6}_\d{6}", token or ""):
            return ("", 204, {
                "Cache-Control": "no-store",
                "Pragma": "no-cache",
            })
    except Exception:
        pass
    return ({"ok": False, "reason": "not_found"}, 404)
### VSP_ROUTE_P_TS_204_END


# === VSP_FINDINGS_UNIFIED_API_P1_V1 (commercial) ===
# Purpose:
#   - Resolve ci_run_dir from RID reliably (prefer persisted uireq state JSON)
#   - Read findings_unified.json and return paging + filters for Data Source tab
import os, json, glob
from flask import request, jsonify

VSP_UIREQ_DIR = os.environ.get("VSP_UIREQ_DIR", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")
VSP_CI_OUT_GLOB = os.environ.get("VSP_CI_OUT_GLOB", "/home/test/Data/**/out_ci/VSP_CI_*")

_SEV_W = {"CRITICAL": 50, "HIGH": 40, "MEDIUM": 30, "LOW": 20, "INFO": 10, "TRACE": 0}
def _sev_w(x): return _SEV_W.get((x or "").upper(), -1)

def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _resolve_run_dir_from_rid(rid: str):
    # 1) persisted UIREQ state (most reliable in VSP commercial flow)
    st = _read_json(os.path.join(VSP_UIREQ_DIR, f"{rid}.json")) or {}
    for k in ("ci_run_dir", "ci_run_dir_resolved", "run_dir", "RUN_DIR"):
        v = st.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip(), "uireq_state"

    # 2) scan known out_ci pattern as fallback (best-effort)
    cands = []
    for d in glob.glob(VSP_CI_OUT_GLOB, recursive=True):
        if rid in os.path.basename(d) or rid in d:
            cands.append(d)
    cands = sorted(set(cands), key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)
    if cands:
        return cands[0], "scan_out_ci"

    return None, "not_found"

def _apply_filters(items, q=None, sev=None, tool=None, cwe=None, fileq=None):
    q = (q or "").strip().lower()
    fileq = (fileq or "").strip().lower()
    sev = (sev or "").strip().upper()
    tool = (tool or "").strip().lower()
    cwe = (cwe or "").strip().upper()

    out = []
    for it in items or []:
        t = (it.get("title") or "")
        f = (it.get("file") or "")
        sv = (it.get("severity") or "").upper()
        tl = (it.get("tool") or "").lower()
        c = ""
        cw = it.get("cwe")
        if isinstance(cw, list) and cw:
            c = str(cw[0] or "").upper()
        elif isinstance(cw, str):
            c = cw.upper()

        if sev and sv != sev: 
            continue
        if tool and tool != tl:
            continue
        if cwe and cwe != c:
            continue
        if fileq and fileq not in f.lower():
            continue
        if q:
            hay = (t + " " + f + " " + (it.get("id") or "")).lower()
            if q not in hay:
                continue
        out.append(it)
    return out

@app.get("/api/vsp/findings_unified_v1/<rid>")
def api_vsp_findings_unified_v1(rid):
    page = int(request.args.get("page", "1") or "1")
    limit = int(request.args.get("limit", "50") or "50")
    page = 1 if page < 1 else page
    limit = 50 if limit < 1 else (500 if limit > 500 else limit)

    q = request.args.get("q")
    sev = request.args.get("sev")
    tool = request.args.get("tool")
    cwe = request.args.get("cwe")
    fileq = request.args.get("file")

    run_dir, src = _resolve_run_dir_from_rid(rid)
    if not run_dir:
        return jsonify({
            "ok": False,
            "warning": "run_dir_not_found",
            "rid": rid,
            "resolve_source": src,
            "total": 0,
            "items": [],
        }), 200

    fp = os.path.join(run_dir, "findings_unified.json")
    data = _read_json(fp)
    if not data or not isinstance(data, dict):
        return jsonify({
            "ok": True,
            "warning": "findings_unified_not_found_or_bad",
            "rid": rid,
            "resolve_source": src,
            "run_dir": run_dir,
            "file": fp,
            "total": 0,
            "items": [],
        }), 200

    items = data.get("items") or []
    items = _apply_filters(items, q=q, sev=sev, tool=tool, cwe=cwe, fileq=fileq)

    # sort: severity desc, tool, file, line
    items.sort(key=lambda it: (-_sev_w(it.get("severity")), (it.get("tool") or ""), (it.get("file") or ""), int(it.get("line") or 0)))

    total = len(items)
    start = (page - 1) * limit
    end = start + limit
    page_items = items[start:end]

    # quick counts (for UI filters)
    by_sev = {}
    by_tool = {}
    by_cwe = {}
    for it in items:
        sv = (it.get("severity") or "UNKNOWN").upper()
        tl = (it.get("tool") or "UNKNOWN")
        cw = it.get("cwe")
        c = "UNKNOWN"
        if isinstance(cw, list) and cw:
            c = str(cw[0] or "UNKNOWN").upper()
        elif isinstance(cw, str) and cw.strip():
            c = cw.strip().upper()
        by_sev[sv] = by_sev.get(sv, 0) + 1
        by_tool[tl] = by_tool.get(tl, 0) + 1
        by_cwe[c] = by_cwe.get(c, 0) + 1

    top_cwe = sorted(by_cwe.items(), key=lambda kv: kv[1], reverse=True)[:10]

    return jsonify({
        "ok": True,
        "rid": rid,
        "run_dir": run_dir,
        "resolve_source": src,
        "file": fp,
        "page": page,
        "limit": limit,
        "total": total,
        "counts": {
            "by_sev": by_sev,
            "by_tool": by_tool,
            "top_cwe": top_cwe,
        },
        "items": page_items,
        "filters": {"q": q, "sev": sev, "tool": tool, "cwe": cwe, "file": fileq},
    }), 200
# === /VSP_FINDINGS_UNIFIED_API_P1_V1 ===

# =========================
# P0: Canonical Gate Summary (run_gate_summary_v1) [V2 bind-multi-app]
# =========================
from pathlib import Path as _Path
import os as _os, json as _json, re as _re, datetime as _dt
from flask import jsonify as _jsonify

def _vsp_now_iso():
    try:
        return _dt.datetime.utcnow().isoformat() + "Z"
    except Exception:
        return ""

def _vsp_sanitize_rid(rid: str) -> str:
    rid = (rid or "").strip()
    if not rid:
        return ""
    if _re.fullmatch(r"[A-Za-z0-9_.:-]+", rid):
        return rid
    return ""

def _vsp_guess_run_dir(rid: str) -> str:
    if not rid:
        return ""
    roots = []
    env = (_os.environ.get("VSP_RUN_ROOTS") or "").strip()
    if env:
        roots += [x for x in env.split(":") if x.strip()]

    roots += [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
    ]

    for r in roots:
        try:
            d = _Path(r) / rid
            if d.is_dir():
                return str(d)
        except Exception:
            pass

    base = _Path("/home/test/Data")
    for pat in [f"*/out_ci/{rid}", f"*/out/{rid}"]:
        try:
            for d in base.glob(pat):
                if d.is_dir():
                    return str(d)
        except Exception:
            pass
    return ""

def _vsp_read_json(path: _Path):
    try:
        return _json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return None

def _vsp_try_gate_files(run_dir: str):
    d = _Path(run_dir)
    for name in ["run_gate_summary.json","run_gate_summary_v1.json","run_gate_summary_v2.json","run_gate.json"]:
        fp = d / name
        if fp.is_file() and fp.stat().st_size > 2:
            j = _vsp_read_json(fp)
            if isinstance(j, dict):
                j.setdefault("source", f"FILE:{name}")
                return j
    return None

def _vsp_derive_gate_from_findings(run_dir: str, rid: str):
    fu = _Path(run_dir) / "findings_unified.json"
    if not fu.is_file() or fu.stat().st_size <= 2:
        return None
    j = _vsp_read_json(fu)
    if not isinstance(j, dict):
        return None
    items = j.get("items") or []
    if not isinstance(items, list):
        items = []

    counts = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0,"UNKNOWN":0}
    for it in items:
        if not isinstance(it, dict): 
            continue
        sev = str(it.get("severity") or it.get("sev") or "UNKNOWN").upper()
        if sev not in counts:
            sev = "UNKNOWN"
        counts[sev] += 1
    total = sum(counts.values())

    if (counts["CRITICAL"] + counts["HIGH"]) > 0:
        status = "FAIL"
        reasons = [f"derived from findings_unified: CRITICAL+HIGH={counts['CRITICAL']+counts['HIGH']}"]
    elif counts["MEDIUM"] > 0:
        status = "DEGRADED"
        reasons = [f"derived from findings_unified: MEDIUM={counts['MEDIUM']}"]
    else:
        status = "OK"
        reasons = [f"derived from findings_unified: total={total}"]

    return {
        "ok": True,
        "source": "DERIVED:findings_unified.json",
        "rid": rid,
        "ci_run_dir": run_dir,
        "overall": {
            "status": status,
            "reasons": reasons + ["gate summary file missing (derived fallback)"],
            "degraded": ["gate_summary_missing_derived"],
            "ts": _vsp_now_iso(),
        },
        "counts": {"total": total, "by_severity": counts},
    }

def _vsp_run_gate_summary_v1_impl(rid):
    rid0 = _vsp_sanitize_rid(rid)
    if not rid0:
        return _jsonify({"ok": False, "status":"ERROR", "error":"BAD_RID", "http_code":400, "final":True, "rid":rid, "ts":_vsp_now_iso()}), 200

    run_dir = _vsp_guess_run_dir(rid0)
    if not run_dir:
        return _jsonify({"ok": False, "status":"ERROR", "error":"RUN_DIR_NOT_FOUND", "http_code":404, "final":True, "rid":rid0, "ts":_vsp_now_iso()}), 200

    g = _vsp_try_gate_files(run_dir)
    if isinstance(g, dict):
        g.setdefault("ok", True)
        g.setdefault("run_id", rid0)
        g.setdefault("ci_run_dir", run_dir)
        g.setdefault("overall", {"status":"DEGRADED","reasons":["missing overall in gate file"],"degraded":["gate_overall_missing"],"ts":_vsp_now_iso()})
        return _jsonify(g), 200

    d = _vsp_derive_gate_from_findings(run_dir, rid0)
    if isinstance(d, dict):
        return _jsonify(d), 200

    return _jsonify({"ok": False, "status":"ERROR", "error":"GATE_SUMMARY_MISSING", "http_code":404, "final":True, "rid":rid0, "ci_run_dir":run_dir, "ts":_vsp_now_iso()}), 200

# Bind to whichever object exists: app / application / bp / vsp_bp
_targets = []
for _name in ("app","application","bp","vsp_bp","vsp_api","api_bp"):
    try:
        _obj = globals().get(_name, None)
        if _obj is not None and hasattr(_obj, "route"):
            _targets.append((_name, _obj))
    except Exception:
        pass

for _n, _obj in _targets:
    try:
        _obj.route("/api/vsp/run_gate_summary_v1/<rid>", methods=["GET"])(lambda rid, _f=_vsp_run_gate_summary_v1_impl: _f(rid))
    except Exception:
        pass


# ================================
# VSP_VSP4_INJECT_AFTER_REQUEST_V3
# ================================
from flask import request, redirect
import re as _vsp_re

def _vsp__inject_tags_v3(html: str) -> str:
  try:
    # hash normalizer into <head>
    if 'vsp_hash_normalize_v1.js' not in html:
      tag = '<script src="/static/js/vsp_hash_normalize_v1.js?v=1765944602"></script>'
      mm = _vsp_re.search(r'<head[^>]*>', html, flags=_vsp_re.I)
      if mm:
        i = mm.end()
        html = html[:i] + '\n  ' + tag + '\n' + html[i:]
      else:
        html = tag + '\n' + html

        # drilldown stub into <head> (must be function)
    if 'vsp_drilldown_stub_safe_v1.js' not in html:
      tag2 = '<script src="/static/js/vsp_drilldown_stub_safe_v1.js?v=1765945236"></script>'
      mm2 = _vsp_re.search(r'<head[^>]*>', html, flags=_vsp_re.I)
      if mm2:
        j = mm2.end()
        html = html[:j] + '\n  ' + tag2 + '\n' + html[j:]
      else:
        html = tag2 + '\n' + html

# loader+features before </body>
    if 'vsp_ui_loader_route_v1.js' not in html:
      ins = '\n  <script src="/static/js/vsp_ui_features_v1.js?v=1765944602"></script>\n' \
            '  <script src="/static/js/vsp_ui_loader_route_v1.js?v=1765944602"></script>\n'
      if '</body>' in html:
        html = html.replace('</body>', ins + '</body>')
      else:
        html = html + ins
  except Exception:
    pass
  return html

def __vsp_after_request_inject_v3(resp):
  try:
    path = (request.path or '').rstrip('/')
    if path == '/vsp4':
      ct = (resp.headers.get('Content-Type','') or '')
      if 'text/html' in ct:
        html = resp.get_data(as_text=True)
        html2 = _vsp__inject_tags_v3(html)
        if html2 != html:
          resp.set_data(html2)
  except Exception:
    pass
  return resp


# ================================
# VSP_ROOT_FORCE_REDIRECT_V2
# ================================
try:
  from flask import redirect as _vsp_redirect
except Exception:
  _vsp_redirect = None

@app.before_request
def __vsp_force_root_to_vsp4_v2():
  try:
    # exact root only
    if request.path == "/" and _vsp_redirect is not None:
      return _vsp_redirect("/vsp4/#dashboard", code=302)
  except Exception:
    pass
  return None



# ================================
# VSP_VSP4_SLASH_REDIRECT_V1
# ================================
@app.before_request
def __vsp_redirect_vsp4_slash_v1():
  try:
    if request.path == "/vsp4/":
      return _vsp_redirect("/vsp4", code=301) if "_vsp_redirect" in globals() and _vsp_redirect else redirect("/vsp4", code=301)
  except Exception:
    pass
  return None


# ================================
# VSP_FAVICON_REDIRECT_V1
# ================================
@app.before_request
def __vsp_favicon_redirect_v1():
  try:
    pth = request.path or ""
    if pth == "/favicon.ico" or pth == "/vsp4/favicon.ico":
      return redirect("/static/favicon.ico", code=302)
  except Exception:
    pass
  return None


# ================================
# VSP_VSP4_HTML_SANITIZE_P0_V1
# - remove stray <script src="P\d{6}_\d{6}..."> which causes noisy 404
# ================================
def __vsp_vsp4_html_sanitize_p0_v1(resp):
  try:
    pth = (request.path or "")
    if pth not in ("/vsp4", "/vsp4/"):
      return resp
    ct = (resp.content_type or "")
    if "text/html" not in ct:
      return resp
    html = resp.get_data(as_text=True)
    # remove broken/stray script tags like: <script src="P251217_065927"></script>
    html2 = re.sub(r'<script\s+[^>]*src="P\d{6}_\d{6}[^"]*"[^>]*>\s*</script>\s*', '', html, flags=re.I)
    if html2 != html:
      resp.set_data(html2)
  except Exception:
    pass
  return resp


# ================================
# VSP_HTML_SANITIZE_P_SCRIPT_V2
# - remove stray script tags like /static/js/P251217_065927?... or /static/js/p251217_065927?...
# ================================
def __vsp_html_sanitize_p_script_v2(resp):
  try:
    ct = (resp.headers.get("Content-Type") or "")
    if "text/html" in ct:
      html = resp.get_data(as_text=True)
      # remove <script src="/static/js/P...._......"> stray tags (case-insensitive P/p)
      html2 = re.sub(r'(?is)<script[^>]+src="\/static\/js\/[pP]\d{6,8}_\d{6}[^"]*"[^>]*>\s*<\/script>', '', html)
      if html2 != html:
        resp.set_data(html2)
  except Exception:
    pass
  return resp


# ================================
# VSP_API_LIMIT_CAPS_P0_V1
# - prevent OOM by capping heavy list endpoints
# ================================
def __vsp__wrap_limit_redirect(app, rule_path, cap):
  try:
    from flask import request, redirect
    from urllib.parse import urlencode
  except Exception:
    return
  try:
    ep = None
    for rule in app.url_map.iter_rules():
      if getattr(rule, "rule", "") == rule_path:
        ep = rule.endpoint
        break
    if not ep:
      return
    orig = app.view_functions.get(ep)
    if not callable(orig):
      return

    def _wrapped(*a, **kw):
      try:
        lim = request.args.get("limit", "")
        if lim:
          try:
            n = int(lim)
          except Exception:
            n = cap
          if n > cap:
            q = request.args.to_dict(flat=True)
            q["limit"] = str(cap)
            url = request.path + "?" + urlencode(q)
            return redirect(url, code=302)
      except Exception:
        pass
      return orig(*a, **kw)

    app.view_functions[ep] = _wrapped
  except Exception:
    pass

try:
  # cap datasource to 200, runs list to 50 (đủ dùng UI)
  __vsp__wrap_limit_redirect(app, "/api/vsp/datasource_v2", 200)
  __vsp__wrap_limit_redirect(app, "/api/vsp/runs_index_v3", 50)
except Exception:
  pass


# --- VSP_AFTERREQ_LATEST_RID_COMPAT_P0_V1: ensure /api/vsp/latest_rid_v1 returns `rid` (compat with UI) ---
def vsp_afterreq_latest_rid_compat_p0_v1(resp):
    pass


# --- VSP_AFTERREQ_BUNDLE_ONLY_VSP4_P0_V5CLEAN: force /vsp4 to load ONLY bundle v2 (commercial) ---
@app.after_request
def vsp_afterreq_bundle_only_vsp4_p0_v5clean(resp):
    try:
        from flask import request
        import re as _re

        path = getattr(request, "path", "") or ""
        if not (path == "/vsp4" or path.startswith("/vsp4/")):
            return resp

        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype:
            return resp
        if getattr(resp, "status_code", 200) != 200:
            return resp

        body = resp.get_data(as_text=True)

        m = _re.search(r'/static/js/vsp_[^"\']+\?v=(\d+)', body, _re.I)
        asset_v = m.group(1) if m else "1"

        # drop ALL vsp_*.js script tags (we will re-insert bundle v2 once)
        pat = _re.compile(r"""(?is)<script\b[^>]*\bsrc\s*=\s*(['"])([^'"]*?/static/js/vsp_[^'"]+)\1[^>]*>\s*</script\s*>""")
        body2 = pat.sub("\n", body)

        bundle_tag = f'<script defer src="/static/js/vsp_bundle_commercial_v2.js?v={asset_v}"></script>'
        if _re.search(r"(?is)</body\s*>", body2):
            body2 = _re.sub(r"(?is)</body\s*>", "\n"+bundle_tag+"\n</body>", body2, count=1)
        else:
            body2 += "\n" + bundle_tag + "\n"

        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
    except Exception:
        pass
    return resp



# --- VSP_AFTERREQ_STRIP_PSCRIPT_P0_V1: /vsp4 keep ONLY vsp_bundle_commercial_v2.js and drop /static/js/P* script ---
@app.after_request
def vsp_afterreq_strip_pscript_p0_v1(resp):
    try:
        from flask import request
        path = getattr(request, "path", "") or ""
        if not (path == "/vsp4" or path.startswith("/vsp4/")):
            return resp
        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp

        body = resp.get_data(as_text=True)

        # Remove any <script ... src="/static/js/P....">...</script>
        # (very conservative: only matches '/static/js/P' prefix)
        body2 = re.sub(r'(?is)\s*<script\b[^>]*\bsrc\s*=\s*["\'](/static/js/P[^"\']+)["\'][^>]*>\s*</script\s*>\s*', "\n", body)

        # Also remove any other vsp_*.js tags except the bundle v2
        def keep_only_bundle(m):
            src = (m.group(1) or "")
            if "vsp_bundle_commercial_v2.js" in src:
                return m.group(0)
            if "/static/js/vsp_" in src or "static/js/vsp_" in src:
                return "\n"
            return m.group(0)

        body2 = re.sub(r'(?is)<script\b[^>]*\bsrc\s*=\s*["\']([^"\']+)["\'][^>]*>\s*</script\s*>', keep_only_bundle, body2)

        # Ensure bundle tag exists (if someone removed it)
        if "vsp_bundle_commercial_v2.js" not in body2:
            # try keep the same v= from old body if present
            mv = re.search(r'vsp_bundle_commercial_v2\.js\?v=(\d+)', body, re.I)
            vv = mv.group(1) if mv else "1"
            bundle_tag = f'<script defer src="/static/js/vsp_bundle_commercial_v2.js?v={vv}"></script>'
            if re.search(r"(?is)</body\s*>", body2):
                body2 = re.sub(r"(?is)</body\s*>", "\n"+bundle_tag+"\n</body>", body2, count=1)
            else:
                body2 += "\n" + bundle_tag + "\n"

        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-VSP-BUNDLEONLY"] = "STRIP_PSCRIPT_P0_V1"
    except Exception:
        pass
    return resp



# --- VSP_AFTERREQ_FORCE_CLEAN_BUNDLEONLY_P0_V1: hard clean /vsp4 HTML + keep ONLY bundle v2 ---
@app.after_request
def vsp_afterreq_force_clean_bundleonly_p0_v1(resp):
    try:
        from flask import request
        path = getattr(request, "path", "") or ""
        if path != "/vsp4":
            return resp

        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp

        body = resp.get_data(as_text=True)

        # (0) Drop any garbage BEFORE <!DOCTYPE or <html
        idx = body.lower().find("<!doctype")
        if idx == -1:
            idx = body.lower().find("<html")
        if idx > 0:
            body = body[idx:]

        # (1) Find asset_v from existing bundle tag, else fallback
        m = re.search(r'vsp_bundle_commercial_v2\.js\?v=(\d+)', body, re.I)
        asset_v = m.group(1) if m else "1"

        # (2) Remove ALL external script tags that reference /static/js/P* OR /static/js/vsp_* (we will re-add bundle)
        def drop_external_scripts(html: str) -> str:
            parts = html.split("<script")
            if len(parts) == 1:
                return html
            out = [parts[0]]
            for chunk in parts[1:]:
                seg = "<script" + chunk
                low = seg.lower()
                # inline script => keep
                if 'src="' not in low and "src='" not in low:
                    out.append(seg); continue
                # detect src value quickly
                if "/static/js/p" in low or "static/js/p" in low:
                    end = low.find("</script>")
                    if end != -1:
                        continue
                if "/static/js/vsp_" in low or "static/js/vsp_" in low:
                    end = low.find("</script>")
                    if end != -1:
                        continue
                out.append(seg)
            return "".join(out)

        body2 = drop_external_scripts(body)

        # (3) Ensure exactly one bundle v2 tag before </body>
        bundle_tag = f'<script defer src="/static/js/vsp_bundle_commercial_v2.js?v={asset_v}"></script>'
        # remove any existing bundle tags first
        body2 = re.sub(r'(?is)\s*<script\b[^>]*vsp_bundle_commercial_v2\.js[^>]*>\s*</script\s*>\s*', "\n", body2)

        if re.search(r"(?is)</body\s*>", body2):
            body2 = re.sub(r"(?is)</body\s*>", "\n"+bundle_tag+"\n</body>", body2, count=1)
        else:
            body2 += "\n" + bundle_tag + "\n"

        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-VSP-BUNDLEONLY"] = "FORCE_CLEAN_P0_V1"
    except Exception:
        pass
    return resp

# --- VSP_AFTERREQ_STRIP_BROKEN_P_SCRIPT_P0_V1: strip broken <script src="/static/js/P... "?v=...> tags in /vsp4 ---
@app.after_request
def vsp_afterreq_strip_broken_p_script_p0_v1(resp):
    try:
        from flask import request
        path = getattr(request, "path", "") or ""
        if path != "/vsp4":
            return resp
        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp

        body = resp.get_data(as_text=True)

        # remove any script tag that contains src="/static/js/P" even if ?v is outside quotes
        body2 = re.sub(r'(?is)\s*<script\b[^>]*src="/static/js/P[^"]*"[^>]*>\s*</script\s*>\s*', "\n", body)
        # also cover the exact broken pattern: src="/static/js/P..."?v=..."
        body2 = re.sub(r'(?is)\s*<script\b[^>]*src="/static/js/P[^"]*"\?v=[^>]*>\s*</script\s*>\s*', "\n", body2)

        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-VSP-BUNDLEONLY"] = "STRIP_BROKEN_P_P0_V1"
    except Exception:
        pass
    return resp

# --- VSP_AFTERREQ_STRIP_PSCRIPT_RESPONSE_P0_V2: force-strip /static/js/P* script tags from /vsp4 HTML (handles broken quote ?v= outside) ---
@app.after_request
def vsp_afterreq_strip_pscript_response_p0_v2(resp):
    try:
        from flask import request
        path = getattr(request, "path", "") or ""
        if path != "/vsp4":
            return resp
        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp
        body = resp.get_data(as_text=True)
        # remove <script ... src="/static/js/Pxxxx"?v=...></script>
        body2 = re.sub(r'(?is)\s*<script\b[^>]*\bsrc="/static/js/P[^"]*"(?:\?v=[^>]*)?[^>]*>\s*</script\s*>\s*', "\n", body)
        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-VSP-STRIP-P"] = "P0_V2"
    except Exception:
        pass
    return resp


# --- VSP_AFTERREQ_STRIP_PSCRIPT_RESPONSE_P0_V3: strip /static/js/P* script tags from /vsp4 HTML (robust + header) ---
@app.after_request
def vsp_afterreq_strip_pscript_response_p0_v3(resp):
    try:
        from flask import request
        import re as _re

        path = getattr(request, "path", "") or ""
        if path != "/vsp4":
            return resp
        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp

        # set probe header early (even if stripping fails)
        resp.headers["X-VSP-STRIP-P"] = "P0_V3"
        resp.headers["Cache-Control"] = "no-store"

        body = resp.get_data(as_text=True)

        # 1) remove normal P-script tags
        body2 = _re.sub(r'(?is)\s*<script\b[^>]*\bsrc="/static/js/P[^"]*"[^>]*>\s*</script\s*>\s*', "\n", body)

        # 2) remove broken quote form: src="/static/js/Pxxx"?v=....
        body2 = _re.sub(r'(?is)\s*<script\b[^>]*\bsrc="/static/js/P[^"]*"\?v=[^>]*>\s*</script\s*>\s*', "\n", body2)

        resp.set_data(body2)
    except Exception:
        pass
    return resp

# --- VSP_HEALTHZ_READYZ_P0_V1: commercial health endpoints ---
@app.get("/healthz")
def vsp_healthz_p0_v1():
    return "ok", 200

@app.get("/readyz")
def vsp_readyz_p0_v1():
    # lightweight readiness: app is up + can answer latest rid quickly
    return {"ok": True}, 200

# --- VSP_HEALTHZ_READYZ_P0_V2: commercial health endpoints ---
@app.get("/healthz")
def vsp_healthz_p0_v2():
    return "ok", 200

@app.get("/readyz")
def vsp_readyz_p0_v2():
    return {"ok": True}, 200
