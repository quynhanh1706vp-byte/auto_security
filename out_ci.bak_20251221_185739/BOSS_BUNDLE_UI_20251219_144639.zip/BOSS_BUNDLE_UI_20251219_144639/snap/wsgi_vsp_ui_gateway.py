# coding: utf-8
"""
FORCE FULL VSP UI GATEWAY
- Make gunicorn serve the real Flask app (vsp_demo_app.app)
- Avoid any exportpdf-only/preempt wrappers hijacking /api/vsp/*
"""

# --- VSP_MARK_FIX_P0_V6 ---
# Fix: make MARK always available (also via builtins to avoid NameError in any scope).
import builtins as _vsp_builtins
if not hasattr(_vsp_builtins, 'MARK'):
    _vsp_builtins.MARK = 'VSP_UI_GATEWAY_MARK_V1'
MARK = getattr(_vsp_builtins, 'MARK', 'VSP_UI_GATEWAY_MARK_V1')
MARK_B = (MARK.encode() if isinstance(MARK, str) else str(MARK).encode())
# --- /VSP_MARK_FIX_P0_V6 ---

# VSP_MARK_DEDUPE_SAFE_P0_V8C: keep legacy alias (do not override MARK)
MARKB = MARK_B  # legacy alias
# /VSP_MARK_DEDUPE_SAFE_P0_V8C





# VSP_MARK_FIX_P0_V3
# (P0_V8C) disabled legacy MARK reassignment
# (P0_V8C) disabled legacy MARKB bytes (use MARKB=MARK_B alias)

# VSP_IMPORT_TIME_P0_V2: required by WSGI wrapper (__call__) and cache-bust logic
import time
import os
# /VSP_IMPORT_TIME_P0_V2

from vsp_demo_app import app as application  # gunicorn entrypoint
app = application





# --- VSP_RUNS_HAS_DETECT_P0_V1 ---
# Commercial: /api/vsp/runs must show accurate artifact presence (csv/json/sarif/html/summary).
from flask import request as _vsp_req
import os as _vsp_os
import json as _vsp_json

def _vsp_detect_artifacts(run_dir: str) -> dict:
    d = {"csv":False,"json":False,"sarif":False,"summary":False,"html":False,"html_path":None}
    if not run_dir:
        return d

    # common artifact locations (support both run-root and reports/)
    cand = [
        ("json",   ["findings_unified.json", "reports/findings_unified.json"]),
        ("csv",    ["findings_unified.csv",  "reports/findings_unified.csv"]),
        ("sarif",  ["findings_unified.sarif","reports/findings_unified.sarif"]),
        ("summary",["run_gate_summary.json","SUMMARY.txt", "SHA256SUMS.txt","reports/SUMMARY.txt", "reports/SHA256SUMS.txt", "reports/SHA256SUMS.txt","reports/run_gate_summary.json"]),
    ]
    for k, rels in cand:
        for rel in rels:
            if _vsp_os.path.exists(_vsp_os.path.join(run_dir, rel)):
                d[k] = True
                break

    html_cands = [
        "reports/index.html",
        "report/index.html",
        "reports/report.html",
        "reports/findings_unified.html",
        "findings_unified.html",
        "index.html",
    ]
    for rel in html_cands:
        fp = _vsp_os.path.join(run_dir, rel)
        if _vsp_os.path.exists(fp):
            d["html"] = True
            d["html_path"] = fp
            break
    return d

@app.after_request
def _vsp_after_request_runs_has(resp):
    try:
        # only patch the runs listing JSON
        if _vsp_req.path != "/api/vsp/runs":
            return resp
        ctype = (resp.headers.get("Content-Type") or "")
        if "application/json" not in ctype:
            return resp

        data = None
        try:
            data = resp.get_json(silent=True)
        except Exception:
            data = None
        if not isinstance(data, dict):
            return resp

        items = data.get("items")
        if not isinstance(items, list):
            return resp

        for it in items:
            if not isinstance(it, dict):
                continue
            run_dir = it.get("path") or ""
            has = it.get("has")
            if not isinstance(has, dict):
                has = {}
            det = _vsp_detect_artifacts(str(run_dir))
            has.update(det)
            it["has"] = has

        out = _vsp_json.dumps(data, ensure_ascii=False)
        resp.set_data(out.encode("utf-8"))
        resp.headers["Content-Length"] = str(len(resp.get_data()))
        # ==== VSP_P1_RUNS_CONTRACT_FIELDS_V1 ====
        # P1 contract: enrich runs index response with stable fields for UI/commercial
        try:
            from flask import request as _req
            import os as _os
            # effective limit: requested (cap)
            try:
                _lim_req = int((_req.args.get("limit") or "50").strip())
            except Exception:
                _lim_req = 50
            _hard_cap = 120
            _lim_eff = max(1, min(_lim_req, _hard_cap))
            data["limit"] = _lim_eff
        
            items = data.get("items") or []
            rid_latest = ""
            if isinstance(items, list) and items:
                try:
                    rid_latest = (items[0].get("run_id") or items[0].get("rid") or "").strip()
                except Exception:
                    rid_latest = ""
            data["rid_latest"] = rid_latest
        
            # cache TTL hint
            try:
                data["cache_ttl"] = int(_os.environ.get("VSP_RUNS_CACHE_TTL", "2"))
            except Exception:
                data["cache_ttl"] = 2
        
            # roots used (best-effort, don't break if unknown)
            roots_used = []
            try:
                # common names you may have in gateway
                for nm in ("VSP_RUNS_ROOTS", "RUNS_ROOTS", "VSP_DATA_ROOTS"):
                    if nm in globals() and isinstance(globals()[nm], (list, tuple)):
                        roots_used = [str(x) for x in globals()[nm]]
                        break
            except Exception:
                roots_used = []
            data["roots_used"] = roots_used
        
            # scan cap hit
            try:
                scanned = int(data.get("_scanned") or 0)
            except Exception:
                scanned = 0
            scan_cap = int(data.get("_scan_cap") or 500)
            data["scan_cap"] = scan_cap
            data["scan_cap_hit"] = bool(scanned >= scan_cap)
        except Exception:
            pass
        # ==== /VSP_P1_RUNS_CONTRACT_FIELDS_V1 ====
        # ==== VSP_P1_RUNS_CONTRACT_POSTPROCESS_V3 ====
        # Force-buffer response body and rewrite JSON so contract fields definitely appear.
        try:
            import json as _json
            import os as _os
            from flask import request as _req
            if (_req.path or "") == "/api/vsp/runs":
                try:
                    resp.direct_passthrough = False
                except Exception:
                    pass
        
                _raw = resp.get_data()  # this buffers even if response was streamed
                _txt = (_raw.decode("utf-8", "replace") if isinstance(_raw, (bytes, bytearray)) else str(_raw))
                _data = _json.loads(_txt)
                if isinstance(_data, dict) and _data.get("ok") is True and isinstance(_data.get("items"), list):
                    # effective limit: requested (cap)
                    try:
                        _lim_req = int((_req.args.get("limit") or "50").strip())
                    except Exception:
                        _lim_req = 50
                    _hard_cap = 120
                    _lim_eff = max(1, min(_lim_req, _hard_cap))
                    _data["limit"] = _lim_eff
        
                    items = _data.get("items") or []
                    rid_latest = ""
                    if items:
                        try:
                            rid_latest = (items[0].get("run_id") or items[0].get("rid") or "").strip()
                        except Exception:
                            rid_latest = ""
                    _data["rid_latest"] = rid_latest
        
                    try:
                        _data["cache_ttl"] = int(_os.environ.get("VSP_RUNS_CACHE_TTL", "2"))
                    except Exception:
                        _data["cache_ttl"] = 2
        
                    # roots_used best-effort: expose env if exists (helps debug why items is empty)
                    roots_used = []
                    for k in ("VSP_RUNS_ROOTS", "VSP_DATA_ROOTS", "RUNS_ROOTS"):
                        v = _os.environ.get(k, "").strip()
                        if v:
                            roots_used = [x.strip() for x in v.split(":") if x.strip()]
                            break
                    _data["roots_used"] = roots_used
        
                    try:
                        scanned = int(_data.get("_scanned") or 0)
                    except Exception:
                        scanned = 0
                    scan_cap = int(_data.get("_scan_cap") or 500)
                    _data["scan_cap"] = scan_cap
                    _data["scan_cap_hit"] = bool(scanned >= scan_cap)
        
                    _out = _json.dumps(_data, ensure_ascii=False)
                    resp.set_data(_out.encode("utf-8"))
                    resp.headers["Content-Length"] = str(len(resp.get_data()))
                    resp.headers["X-VSP-RUNS-CONTRACT"] = "P1_V3"
        except Exception:
            pass
        # ==== /VSP_P1_RUNS_CONTRACT_POSTPROCESS_V3 ====
        resp.headers["X-VSP-RUNS-HAS"] = "VSP_RUNS_HAS_DETECT_P0_V1"
        return resp
    except Exception:
        return resp

# --- /VSP_RUNS_HAS_DETECT_P0_V1 ---


# --- VSP_RUNS_PAGE_NEVER_500_P0_V1 ---
# Commercial guard: /runs must never return 500 (fallback HTML + link to JSON).
from flask import request, Response
import json as _vsp_json
import html as _vsp_html
import traceback as _vsp_tb

@app.errorhandler(500)
def _vsp_err_500_runs_only(e):
    try:
        if request.path != "/runs":
            # keep normal 500 behavior for other endpoints
            return ("Internal Server Error", 500)
        # Build minimal HTML using the already-working JSON API
        items = []
        try:
            with app.test_client() as c:
                r = c.get("/api/vsp/runs?limit=50")
                if r.status_code == 200:
                    data = r.get_json(silent=True) or {}
                    items = data.get("items") or []
        except Exception:
            items = []

        rows = []
        for it in items[:50]:
            rid = str(it.get("run_id") or "")
            mtime_h = str(it.get("mtime_h") or "")
            path = str(it.get("path") or "")
            # safe link: open run dir (if you later wire /api/vsp/run_file)
            rows.append(
                "<tr>"
                f"<td>{_vsp_html.escape(rid)}</td>"
                f"<td>{_vsp_html.escape(mtime_h)}</td>"
                f"<td style='font-family:monospace'>{_vsp_html.escape(path)}</td>"
                "</tr>"
            )

        body = (
            "<!doctype html><html><head><meta charset='utf-8'>"
            "<title>Runs & Reports</title>"
            "<style>"
            "body{background:#0b1220;color:#e5e7eb;font:14px/1.4 system-ui,Segoe UI,Arial;padding:18px}"
            "a{color:#60a5fa} table{border-collapse:collapse;width:100%;margin-top:10px}"
            "th,td{border:1px solid #1f2937;padding:8px;vertical-align:top}"
            "th{background:#111827;text-align:left}"
            ".muted{color:#9ca3af}"
            "</style></head><body>"
            "<h2>Runs & Reports</h2>"
            "<div class='muted'>Fallback mode: UI template errored. JSON API is OK.</div>"
            "<div style='margin-top:8px'>"
            "<a href='/api/vsp/runs?limit=50'>Open /api/vsp/runs JSON</a>"
            "</div>"
            "<table><thead><tr><th>run_id</th><th>mtime</th><th>path</th></tr></thead><tbody>"
            + "".join(rows) +
            "</tbody></table>"
            "</body></html>"
        )
        return Response(body, status=200, headers={"X-VSP-RUNS-PAGE-FALLBACK": MARK}, mimetype="text/html")
    except Exception:
        # last resort: still avoid 500 on /runs
        tb = _vsp_tb.format_exc()
        body = "<pre>" + _vsp_html.escape(tb[-4000:]) + "</pre>"
        return Response(body, status=200, headers={"X-VSP-RUNS-PAGE-FALLBACK": MARK}, mimetype="text/html")

# --- /VSP_RUNS_PAGE_NEVER_500_P0_V1 ---


# === VSP_WSGI_STATUSV2_ALWAYS8_V3 ===
# Post-process /api/vsp/run_status_v2/* JSON at WSGI layer to always expose 8 tool lanes.
import json

def _vsp_build_tools_always8_v3(out: dict) -> dict:
    CANON = ["SEMGREP","GITLEAKS","TRIVY","CODEQL","KICS","GRYPE","SYFT","BANDIT"]
    ZERO = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0}
    # VSP_P1_GW_RUNFILE_ANCHOR_ALLOW_SHA_V3: allow reports/SHA256SUMS.txt BEFORE any allowlist/proxy
    try:
        from flask import request as _req, send_file as _send_file, jsonify as _jsonify
        _rid = (_req.args.get("rid","") or _req.args.get("run_id","") or _req.args.get("run","") or "").strip()
        _rel = (_req.args.get("name","") or _req.args.get("path","") or _req.args.get("rel","") or "").strip().lstrip("/")
        if _rid and _rel == "reports/SHA256SUMS.txt":
            from pathlib import Path as _P
            for _root in (
                _P("/home/test/Data/SECURITY_BUNDLE/out"),
                _P("/home/test/Data/SECURITY_BUNDLE/out_ci"),
                _P("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
                _P("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            ):
                _fp = _root / _rid / "reports" / "SHA256SUMS.txt"
                if _fp.exists():
                    return _send_file(str(_fp), as_attachment=True)
            return _jsonify({"ok": False, "error": "NO_FILE"}), 404
    except Exception:
        pass


    def norm_counts(c):
        d = dict(ZERO)
        if isinstance(c, dict):
            for k,v in c.items():
                kk = str(k).upper()
                if kk in d:
                    try: d[kk] = int(v)
                    except Exception: d[kk] = 0
        return d

    def mk(tool, has_key=None, total_key=None, verdict_key=None, counts_key=None, reason_missing="missing_fields"):
        hasv = out.get(has_key) if has_key else None
        try: hasv = bool(hasv) if has_key else None
        except Exception: hasv = None

        total = out.get(total_key, 0) if total_key else 0
        verdict = out.get(verdict_key) if verdict_key else None
        counts = norm_counts(out.get(counts_key, {})) if counts_key else dict(ZERO)

        if has_key and hasv is False:
            return {"tool":tool,"status":"NOT_RUN","verdict":"NOT_RUN","total":0,"counts":dict(ZERO),"reason":"has_flag_false"}

        if verdict is None and (not total) and counts == ZERO:
            return {"tool":tool,"status":"NOT_RUN","verdict":"NOT_RUN","total":0,"counts":dict(ZERO),"reason":reason_missing}

        vv = str(verdict).upper() if verdict is not None else "OK"
        try: total_i = int(total)
        except Exception: total_i = 0
        return {"tool":tool,"status":vv,"verdict":vv,"total":total_i,"counts":counts}

    tools = {}
    # your current flat keys in status_v2 response
    tools["CODEQL"]   = mk("CODEQL",   "has_codeql",   "codeql_total",   "codeql_verdict",   None)
    tools["GITLEAKS"] = mk("GITLEAKS", "has_gitleaks", "gitleaks_total", "gitleaks_verdict", "gitleaks_counts")
    tools["SEMGREP"]  = mk("SEMGREP",  "has_semgrep",  "semgrep_total",  "semgrep_verdict",  "semgrep_counts")
    tools["TRIVY"]    = mk("TRIVY",    "has_trivy",    "trivy_total",    "trivy_verdict",    "trivy_counts")

    # no converters yet -> NOT_RUN but lane must exist
    for t in ["KICS","GRYPE","SYFT","BANDIT"]:
        tools[t] = {"tool":t,"status":"NOT_RUN","verdict":"NOT_RUN","total":0,"counts":dict(ZERO),"reason":"no_converter_yet"}

    out["tools"] = tools
    out["tools_order"] = CANON

    gs = out.get("run_gate_summary")
    if not isinstance(gs, dict):
        gs = {}
    for t in CANON:
        if t not in gs:
            gs[t] = {"tool":t,"verdict": tools[t].get("verdict","NOT_RUN"), "total": tools[t].get("total",0)}
    out["run_gate_summary"] = gs
    return out

def _vsp_wrap_statusv2_always8_v3(app):
    def _app(environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if not path.startswith("/api/vsp/run_status_v2/"):
            return app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = headers
            captured["exc"] = exc_info
            return lambda x: None

        res_iter = app(environ, _sr)
        try:
            body = b"".join(res_iter or [])
        finally:
            try:
                close = getattr(res_iter, "close", None)
                if callable(close): close()
            except Exception:
                pass

        headers = captured["headers"] or []
        ctype = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ctype = str(v)
                break

        if "application/json" not in ctype.lower():
            start_response(captured["status"] or "200 OK", headers, captured["exc"])
            return [body]

        try:
            out = json.loads((body.decode("utf-8", errors="ignore") or "{}"))
            if isinstance(out, dict) and (out.get("tools") is None):
                out = _vsp_build_tools_always8_v3(out)
                new_body = json.dumps(out, ensure_ascii=False).encode("utf-8")

                new_headers = []
                for k,v in headers:
                    if str(k).lower() == "content-length":
                        continue
                    new_headers.append((k,v))
                new_headers.append(("Content-Length", str(len(new_body))))

                start_response(captured["status"] or "200 OK", new_headers, captured["exc"])
                return [new_body]
        except Exception:
            pass

        start_response(captured["status"] or "200 OK", headers, captured["exc"])
        return [body]
    return _app

# Wrap if 'application' exists (gunicorn uses wsgi_vsp_ui_gateway:application)
try:
    application = _vsp_wrap_statusv2_always8_v3(application)
except Exception:
    pass



# === VSP_RULE_OVERRIDES_FORCE_BIND_V1 BEGIN ===
import json as _json
from pathlib import Path as _Path
from datetime import datetime as _dt, timezone as _tz
import os as _os
import tempfile as _tempfile

_VSP_RULE_OVR_PATH = _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/vsp_rule_overrides_v1.json")

def _vsp_rule_ovr_default_v1():
    return {"meta":{"version":"v1","updated_at":None},"overrides":[]}

def _vsp_rule_ovr_atomic_write_v1(path:_Path, obj:dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = _tempfile.mkstemp(prefix=path.name+".", dir=str(path.parent))
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as f:
            _json.dump(obj, f, ensure_ascii=False, indent=2)
        _os.replace(tmp, str(path))
    finally:
        try:
            _os.unlink(tmp)
        except Exception:
            pass

class VSPRuleOverridesForceBindV1:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/rule_overrides_v1"):
            return self.app(environ, start_response)

        method = (environ.get("REQUEST_METHOD") or "GET").upper()
        try:
            if method == "GET":
                if _VSP_RULE_OVR_PATH.exists():
                    try:
                        data = _json.load(open(_VSP_RULE_OVR_PATH, "r", encoding="utf-8"))
                    except Exception:
                        data = _vsp_rule_ovr_default_v1()
                else:
                    data = _vsp_rule_ovr_default_v1()

                body = _json.dumps(data, ensure_ascii=False).encode("utf-8")
                hdrs = [
                    ("Content-Type","application/json; charset=utf-8"),
                    ("Content-Length", str(len(body))),
                    ("Cache-Control","no-cache"),
                    ("X-VSP-RULE-OVERRIDES-MODE","FORCE_BIND_V1"),
                ]
                start_response("200 OK", hdrs)
                return [body]

            if method == "POST":
                try:
                    n = int(environ.get("CONTENT_LENGTH") or "0")
                except Exception:
                    n = 0
                raw = environ["wsgi.input"].read(n) if n > 0 else b"{}"
                obj = _json.loads(raw.decode("utf-8", errors="replace") or "{}")
                if not isinstance(obj, dict):
                    obj = _vsp_rule_ovr_default_v1()
                obj.setdefault("meta", {})
                obj["meta"]["updated_at"] = _dt.now(_tz.utc).isoformat()
                _vsp_rule_ovr_atomic_write_v1(_VSP_RULE_OVR_PATH, obj)

                out = {"ok": True, "file": str(_VSP_RULE_OVR_PATH), "mode":"FORCE_BIND_V1"}
                body = _json.dumps(out, ensure_ascii=False).encode("utf-8")
                hdrs = [
                    ("Content-Type","application/json; charset=utf-8"),
                    ("Content-Length", str(len(body))),
                    ("Cache-Control","no-cache"),
                    ("X-VSP-RULE-OVERRIDES-MODE","FORCE_BIND_V1"),
                ]
                start_response("200 OK", hdrs)
                return [body]

            body = b'{"ok":false,"error":"METHOD_NOT_ALLOWED"}'
            start_response("405 Method Not Allowed", [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
            ])
            return [body]
        except Exception as e:
            body = _json.dumps({"ok":False,"error":"RULE_OVERRIDES_FORCE_BIND_ERR","detail":str(e)}, ensure_ascii=False).encode("utf-8")
            start_response("500 Internal Server Error", [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
                ("X-VSP-RULE-OVERRIDES-MODE","FORCE_BIND_V1"),
            ])
            return [body]
# === VSP_RULE_OVERRIDES_FORCE_BIND_V1 END ===


# VSP_RULE_OVERRIDES_FORCE_BIND_V1 WRAP

# === VSP_GATEWAY_INJECT_FILLREAL_WSGI_MW_P1_V3 ===
import re as _re

class _VspHtmlInjectMw:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        captured = {"status": None, "headers": None, "exc": None}

        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers) if headers else []
            captured["exc"] = exc_info
            # delay calling real start_response until we possibly rewrite body
            return None

        app_iter = self.app(environ, _sr)

        try:
            body_chunks = []
            for chunk in app_iter:
                if chunk:
                    body_chunks.append(chunk)
            body = b"".join(body_chunks)
        finally:
            try:
                close = getattr(app_iter, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        headers = captured["headers"] or []
        ct = ""
        for (k,v) in headers:
            if str(k).lower() == "content-type":
                ct = str(v).lower()
                break

        # only touch HTML
        if "text/html" in ct and body:
            try:
                html = body.decode("utf-8", errors="replace")
                if ("vsp_fill_real_data_5tabs_p1_v1.js" not in html) and ("VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY" not in html):
                    tag = (
                        "\n<!-- VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                        "<script src='/static/js/vsp_fill_real_data_5tabs_p1_v1.js'></script>\n"
                        "<!-- /VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                    )
                    if "</body>" in html:
                        html = html.replace("</body>", tag + "</body>")
                    elif "</html>" in html:
                        html = html.replace("</html>", tag + "</html>")
                    else:
                        html = html + tag
                    body = html.encode("utf-8")

                    # drop Content-Length (recomputed)
                    headers = [(k,v) for (k,v) in headers if str(k).lower() != "content-length"]
                    headers.append(("Content-Length", str(len(body))))
            except Exception:
                pass

        # now start response
        start_response(captured["status"] or "200 OK", headers, captured["exc"])
        return [body]
# === /VSP_GATEWAY_INJECT_FILLREAL_WSGI_MW_P1_V3 ===

application = VSPRuleOverridesForceBindV1(application)

# === VSP_API_REPORTS_LATEST_COMPAT_P0_V1 ===
def _vsp__find_latest_run_with_file(relpath: str) -> str:
    """
    Return RUN_ID (folder basename) of newest out/RUN_* that contains relpath.
    relpath examples: 'reports/index.html' or 'reports/run_gate_summary.json'
    """
    base = Path("/home/test/Data/SECURITY_BUNDLE/out")
    if not base.exists():
        return ""
    # newest first by mtime
    runs = sorted(base.glob("RUN_*"), key=lambda x: x.stat().st_mtime, reverse=True)
    for rd in runs[:200]:
        try:
            fp = rd / relpath
            if fp.is_file():
                return rd.name
        except Exception:
            continue
    return ""
# [DISABLED] application is WSGI wrapper (no .route). Bound later via app.add_url_rule
def vsp_api_reports_latest(name):
    # compat endpoint: serve latest run's report file via run_file contract
    # /api/reports/run_gate_summary.json  -> reports/run_gate_summary.json
    rel = name
    if not rel.startswith("reports/"):
        rel = "reports/" + rel

    rid = _vsp__find_latest_run_with_file(rel)
    if not rid:
        return ("Not Found", 404)

    # redirect to commercial contract endpoint
    url = "/api/vsp/run_file?rid=" + quote(rid) + "&name=" + quote(rel)
    return ("", 302, {"Location": url})




# === VSP_RUN_STATUS_V2_GUARD_V1 BEGIN ===
import json as _json
from datetime import datetime as _dt, timezone as _tz
import traceback as _tb

class VSPRunStatusV2GuardV1:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/run_status_v2/"):
            return self.app(environ, start_response)

        # normalize rid in PATH_INFO
        try:
            rid = path.split("/api/vsp/run_status_v2/", 1)[1]
        except Exception:
            rid = ""
        rid = (rid or "").strip()
        rid_norm = rid[4:] if rid.startswith("RUN_") else rid

        # rewrite path if needed
        if rid_norm != rid:
            environ = dict(environ)
            environ["PATH_INFO"] = "/api/vsp/run_status_v2/" + rid_norm

        try:
            return self.app(environ, start_response)
        except Exception as e:
            payload = {
                "ok": False,
                "status": "ERROR",
                "final": True,
                "http_code": 500,
                "error": "RUN_STATUS_V2_EXCEPTION_GUARDED",
                "rid": rid,
                "rid_norm": rid_norm,
                "detail": str(e),
                "ts_utc": _dt.now(_tz.utc).isoformat(),
            }
            body = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
            hdrs = [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
                ("Cache-Control","no-cache"),
                ("X-VSP-RUNSTATUSV2-MODE","GUARD_V1"),
            ]
            start_response("200 OK", hdrs)
            return [body]
# === VSP_RUN_STATUS_V2_GUARD_V1 END ===


# VSP_RUN_STATUS_V2_GUARD_V1 WRAP
application = VSPRunStatusV2GuardV1(application)


# === VSP_WSGI_STATUS_CONTRACT_MW_P1_V1_BEGIN ===
import os, json, re
from pathlib import Path

# VSP_HARDEN_MARK_P0_V2
# (P0_V8C) disabled legacy MARK reassignment
MARKB = MARKB


# VSP_GLOBAL_MARK_FIX_P0_V1
# (P0_V8C) disabled legacy MARK reassignment
def _vsp_read_json(fp):
    try:
        with open(fp, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _vsp_findings_total(run_dir: str):
    if not run_dir:
        return None
    for fn in ("findings_unified.json","reports/findings_unified.json","findings_unified.sarif","findings_unified.sarif.json"):
        fp=os.path.join(run_dir, fn)
        if os.path.isfile(fp):
            j=_vsp_read_json(fp)
            if isinstance(j, dict):
                if isinstance(j.get("total"), int):
                    return j["total"]
                items=j.get("items")
                if isinstance(items, list):
                    return len(items)
    fp=os.path.join(run_dir,"summary_unified.json")
    j=_vsp_read_json(fp) if os.path.isfile(fp) else None
    if isinstance(j, dict):
        t=j.get("total") or j.get("total_findings")
        if isinstance(t, int):
            return t
    return None

def _vsp_degraded_info(run_dir: str):
    if not run_dir:
        return (None, None)
    # prefer runner.log
    cand = os.path.join(run_dir,"runner.log")
    if not os.path.isfile(cand):
        # fallbacks
        for alt in ("kics/kics.log","codeql/codeql.log","trivy/trivy.log"):
            ap=os.path.join(run_dir,alt)
            if os.path.isfile(ap):
                cand=ap; break
        else:
            return (None, None)
    try:
        txt=Path(cand).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return (None, None)

    tools = ["BANDIT","SEMGREP","GITLEAKS","KICS","TRIVY","SYFT","GRYPE","CODEQL"]
    degraded=set()
    for t in tools:
        pats = [
            fr"VSP_{t}_TIMEOUT_DEGRADE",
            fr"\[{t}\].*DEGRADED",
            fr"{t}.*timeout.*degrad",
            fr"{t}.*missing.*degrad",
        ]
        for pat in pats:
            if re.search(pat, txt, flags=re.I):
                degraded.add(t)
                break
    n=len(degraded)
    return (n, n>0)

class VSPStatusContractMWP1V1:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if not path.startswith("/api/vsp/run_status_v2/"):
            return self.app(environ, start_response)

        captured = {"status":"200 OK","headers":[],"exc":None}

        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = headers or []
            captured["exc"] = exc_info
            # delay calling start_response

        it = self.app(environ, _sr)
        try:
            body = b"".join(it)
        finally:
            try:
                it.close()
            except Exception:
                pass

        headers = captured["headers"]
        ctype = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ctype = str(v)
                break

        # only postprocess JSON
        if "application/json" not in ctype.lower():
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        try:
            obj = json.loads(body.decode("utf-8","ignore"))
        except Exception:
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        if not isinstance(obj, dict):
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        rid = path.rsplit("/",1)[-1]
        obj["run_id"] = obj.get("run_id") or rid

        run_dir = obj.get("ci_run_dir") or obj.get("ci")
        if run_dir and os.path.isdir(run_dir):
            t = _vsp_findings_total(run_dir)
            if isinstance(t, int):
                obj["total_findings"] = t
                obj["has_findings"] = True if t > 0 else False

            dn, da = _vsp_degraded_info(run_dir)
            if isinstance(dn, int):
                obj["degraded_n"] = dn
            if isinstance(da, bool):
                obj["degraded_any"] = da

        obj.setdefault("ok", True)

        out = json.dumps(obj, ensure_ascii=False).encode("utf-8")

        # fix content-length
        new_headers=[]
        for k,v in headers:
            if str(k).lower() == "content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(out))))

        start_response(captured["status"], new_headers, captured["exc"])
        return [out]

# wrap if possible
try:
    application = VSPStatusContractMWP1V1(application)
except Exception:
    pass
# === VSP_WSGI_STATUS_CONTRACT_MW_P1_V1_END ===


# === VSP_WSGI_RUNS_INDEX_ENRICH_MW_P1_V1_BEGIN ===
import json
import urllib.parse

class VSPRunsIndexEnrichMWP1V1:
    """
    Post-process /api/vsp/runs_index_v3_fs_resolved JSON items by attaching:
      total_findings, has_findings, degraded_n, degraded_any
    derived deterministically from ci_run_dir (no heuristics).
    """
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if path != "/api/vsp/runs_index_v3_fs_resolved":
            return self.app(environ, start_response)

        captured = {"status":"200 OK","headers":[],"exc":None}
        def _sr(status, headers, exc_info=None):
            captured["status"]=status
            captured["headers"]=headers or []
            captured["exc"]=exc_info

        it = self.app(environ, _sr)
        try:
            body = b"".join(it)
        finally:
            try: it.close()
            except Exception: pass

        headers = captured["headers"]
        ctype=""
        for k,v in headers:
            if str(k).lower()=="content-type":
                ctype=str(v); break
        if "application/json" not in ctype.lower():
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        try:
            obj=json.loads(body.decode("utf-8","ignore"))
        except Exception:
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        if not isinstance(obj, dict):
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        items = obj.get("items")
        if not isinstance(items, list):
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        # cap enrich to avoid heavy IO if someone requests huge limit
        qs = environ.get("QUERY_STRING","") or ""
        q = urllib.parse.parse_qs(qs)
        try:
            limit = int((q.get("limit") or ["50"])[0])
        except Exception:
            limit = 50
        hard_cap = 120
        n = min(len(items), min(limit, hard_cap))

        for i in range(n):
            it0 = items[i]
            if not isinstance(it0, dict):
                continue
            run_dir = it0.get("ci_run_dir") or it0.get("ci") or None
            if not run_dir:
                continue
            try:
                # reuse helpers from status MW (already injected earlier)
                t = _vsp_findings_total(run_dir)
                if isinstance(t, int):
                    it0["total_findings"] = t
                    it0["has_findings"] = True if t>0 else False
                dn, da = _vsp_degraded_info(run_dir)
                if isinstance(dn, int):
                    it0["degraded_n"] = dn
                if isinstance(da, bool):
                    it0["degraded_any"] = da
            except Exception:
                pass

        out=json.dumps(obj, ensure_ascii=False).encode("utf-8")

        new_headers=[]
        for k,v in headers:
            if str(k).lower()=="content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(out))))

        start_response(captured["status"], new_headers, captured["exc"])
        return [out]

try:
    application = VSPRunsIndexEnrichMWP1V1(application)
except Exception:
    pass
# === VSP_WSGI_RUNS_INDEX_ENRICH_MW_P1_V1_END ===


# === VSP_WSGI_FINDINGS_UNIFIED_API_P1_V1 (commercial) ===
# Ensure /api/vsp/findings_unified_v1/<rid> is registered on the ACTUAL gunicorn "application"
import os, json, glob
from flask import request, jsonify

VSP_UIREQ_DIR = os.environ.get("VSP_UIREQ_DIR", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")
VSP_CI_OUT_GLOB = os.environ.get("VSP_CI_OUT_GLOB", "/home/test/Data/**/out_ci/VSP_CI_*")

_SEV_W = {"CRITICAL": 50, "HIGH": 40, "MEDIUM": 30, "LOW": 20, "INFO": 10, "TRACE": 0}
def _sev_w(x): return _SEV_W.get((x or "").upper(), -1)

def _read_json(path):
  try:
    with open(path, "r", encoding="utf-8") as f:
      return json.load(f)
  except Exception:
    return None

def _resolve_run_dir_from_rid(rid: str):
  st = _read_json(os.path.join(VSP_UIREQ_DIR, f"{rid}.json")) or {}
  for k in ("ci_run_dir","ci_run_dir_resolved","run_dir","RUN_DIR"):
    v = st.get(k)
    if isinstance(v,str) and v.strip():
      return v.strip(), "uireq_state"
  cands=[]
  for d in glob.glob(VSP_CI_OUT_GLOB, recursive=True):
    if rid in (os.path.basename(d) or "") or rid in d:
      cands.append(d)
  cands = sorted(set(cands), key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)
  if cands: return cands[0], "scan_out_ci"
  return None, "not_found"

def _apply_filters(items, q=None, sev=None, tool=None, cwe=None, fileq=None):
  q=(q or "").strip().lower(); fileq=(fileq or "").strip().lower()
  sev=(sev or "").strip().upper(); tool=(tool or "").strip().lower(); cwe=(cwe or "").strip().upper()
  out=[]
  for it in items or []:
    t=(it.get("title") or "")
    f=(it.get("file") or "")
    sv=(it.get("severity") or "").upper()
    tl=(it.get("tool") or "").lower()
    cw=it.get("cwe")
    c=""
    if isinstance(cw,list) and cw: c=str(cw[0] or "").upper()
    elif isinstance(cw,str): c=cw.upper()
    if sev and sv!=sev: continue
    if tool and tool!=tl: continue
    if cwe and cwe!=c: continue
    if fileq and fileq not in f.lower(): continue
    if q:
      hay=(t+" "+f+" "+(it.get("id") or "")).lower()
      if q not in hay: continue
    out.append(it)
  return out

# avoid double-register if hot reload
try:
  _has = any(getattr(r, "rule", "")=="/api/vsp/findings_unified_v1/<rid>" for r in app.url_map.iter_rules())
except Exception:
  _has = False

if not _has:
  @app.route("/api/vsp/findings_unified_v1/<rid>", methods=["GET"])
  def api_vsp_findings_unified_v1(rid):
    page=int(request.args.get("page","1") or "1")
    limit=int(request.args.get("limit","50") or "50")
    page=1 if page<1 else page
    limit=50 if limit<1 else (500 if limit>500 else limit)

    q=request.args.get("q"); sev=request.args.get("sev"); tool=request.args.get("tool")
    cwe=request.args.get("cwe"); fileq=request.args.get("file")

    run_dir, src = _resolve_run_dir_from_rid(rid)
    if not run_dir:
      return jsonify({"ok":False,"warning":"run_dir_not_found","rid":rid,"resolve_source":src,"total":0,"items":[]}), 200

    fp=os.path.join(run_dir,"findings_unified.json")
    data=_read_json(fp)
    if not data or not isinstance(data,dict):
      return jsonify({"ok":True,"warning":"findings_unified_not_found_or_bad","rid":rid,"resolve_source":src,"run_dir":run_dir,"file":fp,"total":0,"items":[]}), 200

    items=data.get("items") or []
    items=_apply_filters(items,q=q,sev=sev,tool=tool,cwe=cwe,fileq=fileq)


    # === VSP_CWE_SAFE_GRYE_V2 ===
    # Fill item.cwe from item.raw.vulnerability.cwes[*].cwe (GRYPE)
    try:
      for _it in (items or []):
        if _it.get("cwe"):
          continue
        if str(_it.get("tool") or "").upper() != "GRYPE":
          continue
        _raw = _it.get("raw") or {}
        _vuln = _raw.get("vulnerability") or {}
        _cwes = _vuln.get("cwes") or []
        _out = []
        for _c in _cwes:
          _v = _c.get("cwe") if isinstance(_c, dict) else _c
          if not _v:
            continue
          _v = str(_v).strip()
          if not _v:
            continue
          if (not _v.upper().startswith("CWE-")) and _v.isdigit():
            _v = "CWE-" + _v
          _out.append(_v.upper())
        if _out:
          _it["cwe"] = list(dict.fromkeys(_out))
    except Exception:
      pass
    # === /VSP_CWE_SAFE_GRYE_V2 ===

    # === VSP_CWE_ENRICH_FROM_ITEM_RAW_V1 ===
    # Fill item.cwe from item.raw.vulnerability.cwes[*].cwe (GRYPE proven has this)
    try:
      for _it in items or []:
        if _it.get("cwe"):
          continue
        _raw = _it.get("raw") or {}
        _vuln = _raw.get("vulnerability") or {}
        _cwes = _vuln.get("cwes") or []
        _out = []
        for _c in _cwes:
          _v = _c.get("cwe") if isinstance(_c, dict) else _c
          if not _v:
            continue
          _v = str(_v).strip()
          if not _v:
            continue
          if (not _v.upper().startswith("CWE-")) and _v.isdigit():
            _v = "CWE-" + _v
          _out.append(_v.upper())
        if _out:
          _it["cwe"] = list(dict.fromkeys(_out))
    except Exception:
      pass
    # === /VSP_CWE_ENRICH_FROM_ITEM_RAW_V1 ===

    # enrich CWE from GRYPE raw file (safe; unified items may not carry raw)
    grype_map = _build_grype_cwe_map(run_dir)
    if grype_map:
      try:
        items = [_maybe_set_cwe_from_grype(dict(it), grype_map) for it in items]
      except Exception:
        pass

    # VSP_P1_FIX_RUNS_AND_SHA256SUMS_V1 skip meta dirs
    items = [x for x in items if (x.get("run_id")!="A2Z_INDEX")]
    items.sort(key=lambda it: (-_sev_w(it.get("severity")), (it.get("tool") or ""), (it.get("file") or ""), int(it.get("line") or 0)))
    total=len(items)
    start=(page-1)*limit; end=start+limit
    page_items=items[start:end]

    by_sev={}; by_tool={}; by_cwe={}
    for it in items:
      sv=(it.get("severity") or "UNKNOWN").upper()
      tl=(it.get("tool") or "UNKNOWN")
      cws = _vsp_extract_cwe_list(it)
      if cws and not it.get('cwe'):
        it['cwe'] = cws
      c = (str(cws[0]).upper() if cws else 'UNKNOWN')
      by_sev[sv]=by_sev.get(sv,0)+1
      by_tool[tl]=by_tool.get(tl,0)+1
      by_cwe[c]=by_cwe.get(c,0)+1
    unknown_count = by_cwe.get("UNKNOWN", 0)
    top_cwe = sorted([(k,v) for (k,v) in by_cwe.items() if k!="UNKNOWN"], key=lambda kv: kv[1], reverse=True)[:10]

    return jsonify({
      "ok":True,"rid":rid,"run_dir":run_dir,"resolve_source":src,"file":fp,
      "page":page,"limit":limit,"total":total,
      "counts":{"by_sev":by_sev,"by_tool":by_tool,"top_cwe":top_cwe},
      "items":page_items,
      "filters":{"q":q,"sev":sev,"tool":tool,"cwe":cwe,"file":fileq},
    }), 200
# === /VSP_WSGI_FINDINGS_UNIFIED_API_P1_V1 ===


# --- VSP_CWE_ENRICH_FROM_GRYPE_P1_V2 ---
import re as _re

_CVE_RE = _re.compile(r'(CVE-\d{4}-\d+)', _re.I)

def _build_grype_cwe_map(run_dir):
  """Return {CVE-xxxx-yyy: [CWE-79, ...]} from run_dir/grype/grype.json if exists."""
  try:
    fp = os.path.join(run_dir, "grype", "grype.json")
    j = _read_json(fp)
    if not j or not isinstance(j, dict):
      return {}
    out = {}
    for m in (j.get("matches") or []):
      vuln = (m.get("vulnerability") or {})
      vid = (vuln.get("id") or "").strip()
      if not vid:
        continue
      cwes = []
      for c in (vuln.get("cwes") or []):
        cwe = (c.get("cwe") or "").strip()
        if cwe:
          if not cwe.upper().startswith("CWE-") and cwe.isdigit():
            cwe = "CWE-" + cwe
          cwes.append(cwe)
      if cwes:
        out[vid.upper()] = list(dict.fromkeys(cwes))
    return out
  except Exception:
    return {}

def _maybe_set_cwe_from_grype(it, grype_map):
  if it.get("cwe"):
    return it
  tool = (it.get("tool") or "").upper()
  if tool != "GRYPE":
    return it
  cand = (it.get("id") or "").strip()
  if not cand:
    # try parse CVE from title
    t = (it.get("title") or "")
    m = _CVE_RE.search(t or "")
    cand = m.group(1) if m else ""
  cand = (cand or "").upper()
  if cand and cand in grype_map:
    it["cwe"] = grype_map[cand]
  return it
# --- /VSP_CWE_ENRICH_FROM_GRYPE_P1_V2 ---


# --- VSP_CWE_FROM_RAW_ITEMS_P1_V3 ---
def _vsp_norm_cwe(x):
  try:
    x = str(x or "").strip()
    if not x:
      return None
    u = x.upper()
    if u.startswith("CWE-"):
      return u
    if x.isdigit():
      return "CWE-" + x
    return u
  except Exception:
    return None

def _vsp_extract_cwe_list(it):
  """Best-effort CWE extraction from unified item or item.raw.
  Works for GRYPE (raw.vulnerability.cwes) and some SARIF/CodeQL shapes.
  """
  try:
    # 1) already normalized in item.cwe
    cw = it.get("cwe")
    if isinstance(cw, list) and cw:
      out=[]
      for v in cw:
        nv=_vsp_norm_cwe(v)
        if nv: out.append(nv)
      if out: return list(dict.fromkeys(out))
    if isinstance(cw, str) and cw.strip():
      nv=_vsp_norm_cwe(cw)
      return [nv] if nv else None

    raw = it.get("raw") or {}

    # 2) GRYPE: raw.vulnerability.cwes[*].cwe
    vuln = raw.get("vulnerability") or {}
    cwes = vuln.get("cwes") or []
    out=[]
    for c in cwes:
      if isinstance(c, dict):
        nv=_vsp_norm_cwe(c.get("cwe"))
      else:
        nv=_vsp_norm_cwe(c)
      if nv: out.append(nv)
    if out: return list(dict.fromkeys(out))

    # 3) relatedVulnerabilities[*].cwes[*].cwe (some feeds)
    rv = raw.get("relatedVulnerabilities") or []
    out=[]
    for v in rv:
      for c in (v.get("cwes") or []):
        nv=_vsp_norm_cwe((c.get("cwe") if isinstance(c, dict) else c))
        if nv: out.append(nv)
    if out: return list(dict.fromkeys(out))

    # 4) SARIF-ish: raw.rule.properties.cwe or raw.properties.cwe
    for path in [
      ("rule","properties","cwe"),
      ("properties","cwe"),
      ("rule","cwe"),
      ("cwe",),
    ]:
      cur = raw
      ok=True
      for k in path:
        if isinstance(cur, dict) and k in cur:
          cur = cur[k]
        else:
          ok=False; break
      if ok and cur:
        if isinstance(cur, list) and cur:
          nv=_vsp_norm_cwe(cur[0])
          return [nv] if nv else None
        nv=_vsp_norm_cwe(cur)
        return [nv] if nv else None
  except Exception:
    pass
  return None
# --- /VSP_CWE_FROM_RAW_ITEMS_P1_V3 ---


# === VSP_FINDINGS_UNIFIED_V2_ENRICHED_V1 ===
# New endpoint (non-invasive): /api/vsp/findings_unified_v2/<rid>
# Goal: commercial-safe enrichment (CWE from item.raw) + stable counts/top_cwe.
import os, json, glob
from flask import request, jsonify

VSP_UIREQ_DIR = os.environ.get("VSP_UIREQ_DIR", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")
VSP_CI_OUT_GLOB = os.environ.get("VSP_CI_OUT_GLOB", "/home/test/Data/**/out_ci/VSP_CI_*")

_SEV_W = {"CRITICAL": 50, "HIGH": 40, "MEDIUM": 30, "LOW": 20, "INFO": 10, "TRACE": 0}
def _sev_w(x): return _SEV_W.get((x or "").upper(), -1)

def _read_json(path):
  try:
    with open(path, "r", encoding="utf-8") as f:
      return json.load(f)
  except Exception:
    return None

def _resolve_run_dir_from_rid(rid: str):
  st = _read_json(os.path.join(VSP_UIREQ_DIR, f"{rid}.json")) or {}
  for k in ("ci_run_dir","ci_run_dir_resolved","run_dir","RUN_DIR"):
    v = st.get(k)
    if isinstance(v, str) and v.strip():
      return v.strip(), "uireq_state"
  cands=[]
  for d in glob.glob(VSP_CI_OUT_GLOB, recursive=True):
    if rid in (os.path.basename(d) or "") or rid in d:
      cands.append(d)
  cands = sorted(set(cands), key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)
  if cands:
    return cands[0], "scan_out_ci"
  return None, "not_found"

def _norm_cwe(v):
  try:
    v = str(v or "").strip()
    if not v: return None
    u = v.upper()
    if u.startswith("CWE-"): return u
    if v.isdigit(): return "CWE-" + v
    return u
  except Exception:
    return None

def _extract_cwe_list(it):
  # Prefer item.cwe
  cw = it.get("cwe")
  out=[]
  if isinstance(cw, list):
    for x in cw:
      nx = _norm_cwe(x)
      if nx: out.append(nx)
  elif isinstance(cw, str):
    nx=_norm_cwe(cw)
    if nx: out.append(nx)
  if out:
    return list(dict.fromkeys(out))

  # Fallback: item.raw.* (GRYPE proven here)
  raw = it.get("raw") or {}
  vuln = (raw.get("vulnerability") or {})
  cwes = vuln.get("cwes") or []
  out=[]
  for c in cwes:
    v = c.get("cwe") if isinstance(c, dict) else c
    nx=_norm_cwe(v)
    if nx: out.append(nx)
  if out:
    return list(dict.fromkeys(out))

  rv = raw.get("relatedVulnerabilities") or []
  out=[]
  for vv in rv:
    for c in (vv.get("cwes") or []):
      v = c.get("cwe") if isinstance(c, dict) else c
      nx=_norm_cwe(v)
      if nx: out.append(nx)
  if out:
    return list(dict.fromkeys(out))

  # SARIF-ish (best-effort)
  for path in [
    ("rule","properties","cwe"),
    ("properties","cwe"),
    ("rule","cwe"),
    ("cwe",),
  ]:
    cur = raw
    ok=True
    for k in path:
      if isinstance(cur, dict) and k in cur:
        cur = cur[k]
      else:
        ok=False; break
    if ok and cur:
      if isinstance(cur, list) and cur:
        nx=_norm_cwe(cur[0])
        return [nx] if nx else None
      nx=_norm_cwe(cur)
      return [nx] if nx else None

  return None

def _apply_filters(items, q=None, sev=None, tool=None, cwe=None, fileq=None):
  q=(q or "").strip().lower()
  fileq=(fileq or "").strip().lower()
  sev=(sev or "").strip().upper()
  tool=(tool or "").strip().lower()
  cwe=(cwe or "").strip().upper()
  out=[]
  for it in items or []:
    t=(it.get("title") or "")
    f=(it.get("file") or "")
    sv=(it.get("severity") or "").upper()
    tl=(it.get("tool") or "").lower()
    cws = _extract_cwe_list(it) or []
    c0 = (str(cws[0]).upper() if cws else "UNKNOWN")

    if sev and sv != sev: 
      continue
    if tool and tool != tl:
      continue
    if cwe and cwe != c0:
      continue
    if fileq and fileq not in f.lower():
      continue
    if q:
      hay=(t+" "+f+" "+(it.get("id") or "")).lower()
      if q not in hay:
        continue

    # ensure item.cwe filled for UI
    if cws and not it.get("cwe"):
      it["cwe"] = cws
    out.append(it)
  return out

@app.route("/api/vsp/findings_unified_v2/<rid>", methods=["GET"])
def api_vsp_findings_unified_v2(rid):
  page = int(request.args.get("page","1") or "1")
  limit = int(request.args.get("limit","50") or "50")
  page = 1 if page < 1 else page
  limit = 50 if limit < 1 else (500 if limit > 500 else limit)

  q = request.args.get("q")
  sev = request.args.get("sev")
  tool = request.args.get("tool")
  cwe = request.args.get("cwe")
  fileq = request.args.get("file")

  run_dir, src = _resolve_run_dir_from_rid(rid)
  if not run_dir:
    return jsonify({
      "ok": False,
      "warning": "run_dir_not_found",
      "rid": rid,
      "resolve_source": src,
      "total": 0,
      "items": [],
    }), 200

  fp = os.path.join(run_dir, "findings_unified.json")
  data = _read_json(fp)
  if not data or not isinstance(data, dict):
    return jsonify({
      "ok": True,
      "warning": "findings_unified_not_found_or_bad",
      "rid": rid,
      "resolve_source": src,
      "run_dir": run_dir,
      "file": fp,
      "total": 0,
      "items": [],
    }), 200

  items = data.get("items") or []
  items = _apply_filters(items, q=q, sev=sev, tool=tool, cwe=cwe, fileq=fileq)

  items.sort(key=lambda it: (-_sev_w(it.get("severity")), (it.get("tool") or ""), (it.get("file") or ""), int(it.get("line") or 0)))
  total = len(items)
  start = (page-1)*limit
  end = start + limit
  page_items = items[start:end]

  by_sev={}; by_tool={}; by_cwe={}
  for it in items:
    sv=(it.get("severity") or "UNKNOWN").upper()
    tl=(it.get("tool") or "UNKNOWN")
    cws = _extract_cwe_list(it) or []
    c0 = (str(cws[0]).upper() if cws else "UNKNOWN")
    by_sev[sv]=by_sev.get(sv,0)+1
    by_tool[tl]=by_tool.get(tl,0)+1
    by_cwe[c0]=by_cwe.get(c0,0)+1

  unknown_count = by_cwe.get("UNKNOWN", 0)
  top_cwe = sorted([(k,v) for (k,v) in by_cwe.items() if k!="UNKNOWN"], key=lambda kv: kv[1], reverse=True)[:10]

  return jsonify({
    "ok": True,
    "rid": rid,
    "run_dir": run_dir,
    "resolve_source": src,
    "file": fp,
    "page": page,
    "limit": limit,
    "total": total,
    "counts": {
      "by_sev": by_sev,
      "by_tool": by_tool,
      "top_cwe": top_cwe,
      "unknown_count": unknown_count
    },
    "items": page_items,
    "filters": {"q": q, "sev": sev, "tool": tool, "cwe": cwe, "file": fileq},
    "debug": ({"marker":"VSP_FINDINGS_UNIFIED_V2_ENRICHED_V1","flask_var":"app"} if request.args.get("debug")=="1" else None)
  }), 200
# === /VSP_FINDINGS_UNIFIED_V2_ENRICHED_V1 ===


# === VSP_DASHBOARD_V3_EXTRAS_FROM_V2_P1_V1 ===
@app.route("/api/vsp/dashboard_v3_extras_v1", methods=["GET"])
def api_vsp_dashboard_v3_extras_v1():
  rid = (request.args.get("rid") or "").strip()
  if not rid:
    # fallback: take latest from runs_index if exists
    try:
      j = api_vsp_runs_index_v3_fs_resolved()
      rid = (j.json.get("items") or [{}])[0].get("run_id") or ""
    except Exception:
      rid = ""
  rid = str(rid).strip()

  # call V2 handler directly (same process) for counts
  try:
    # simulate request args for V2: limit=1
    args = request.args.to_dict(flat=True)
    args.pop("rid", None)
    args["limit"]="1"
    # Temporarily patch request.args? (avoid): call function and parse JSON through flask response
    resp = api_vsp_findings_unified_v2(rid)
    # resp may be (response, code)
    if isinstance(resp, tuple):
      resp_obj = resp[0]
    else:
      resp_obj = resp
    data = resp_obj.get_json(silent=True) or {}
  except Exception:
    data = {}

  counts = (data.get("counts") or {})
  by_sev = counts.get("by_sev") or {}
  by_tool = counts.get("by_tool") or {}
  top_cwe = counts.get("top_cwe") or []
  unknown_count = int(counts.get("unknown_count") or 0)
  total = int(data.get("total") or 0)

  # score heuristic (commercial-ish): 100 - weighted findings / scale
  w = 0
  for k,v in by_sev.items():
    k = str(k or "").upper()
    v = int(v or 0)
    if k == "CRITICAL": w += v*50
    elif k == "HIGH": w += v*30
    elif k == "MEDIUM": w += v*15
    elif k == "LOW": w += v*5
    elif k == "INFO": w += v*1
  score = max(0, int(100 - (w/ max(1, 200))))  # scale factor 200

  # degraded/effective (P1): degraded = unknown_count, effective = total-unknown
  degraded = unknown_count
  effective = max(0, total - unknown_count)

  return jsonify({
    "ok": True,
    "rid": rid,
    "kpi": {
      "total": total,
      "effective": effective,
      "degraded": degraded,
      "score": score,
      "by_sev": by_sev,
      "by_tool": by_tool,
      "top_cwe": top_cwe,
      "unknown_count": unknown_count
    },
    "sources": {
      "findings_api": "/api/vsp/findings_unified_v2/<rid>",
      "marker": "VSP_DASHBOARD_V3_EXTRAS_FROM_V2_P1_V1"
    }
  }), 200
# === /VSP_DASHBOARD_V3_EXTRAS_FROM_V2_P1_V1 ===


# === VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2 ===
class VSPRunsExportZipBtnMWP0V2:
    def __init__(self, app):
        self.app = app
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path != "/runs":
            return self.app(environ, start_response)

        meta = {}
        def sr(status, headers, exc_info=None):
            meta["status"] = status
            meta["headers"] = headers
            meta["exc_info"] = exc_info
            return lambda _x: None

        app_iter = self.app(environ, sr)

        body = b""
        try:
            for chunk in app_iter:
                if chunk:
                    body += chunk
        finally:
            try:
                close = getattr(app_iter, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        headers = meta.get("headers") or []
        ct = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ct = str(v); break

        # only inject into HTML /runs
        if ("text/html" in ct) and (b"/api/vsp/run_file" in body) and (MARKB not in body):
            js = b"""
<script>
/* VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2 */
(function(){
  'use strict';
  function ridFromHref(href){
    try{
      const u=new URL(href, location.origin);
      if(!u.pathname.includes('/api/vsp/run_file')) return null;
      return u.searchParams.get('run_id');
    }catch(e){return null;}
  }
  function addBtn(a, rid){
    try{
      const row=a.closest('tr')||a.parentElement;
      if(!row) return;
      if(row.querySelector('a[data-vsp-export-zip="1"]')) return;
      const b=document.createElement('a');
      b.textContent='Export ZIP';
      b.href='/api/vsp/export_zip?run_id='+encodeURIComponent(rid);
      b.setAttribute('data-vsp-export-zip','1');
      b.style.marginLeft='8px';
      b.style.textDecoration='none';
      b.style.display='inline-block';
      b.style.padding='7px 10px';
      b.style.borderRadius='10px';
      b.style.fontWeight='800';
      b.style.border='1px solid rgba(90,140,255,.35)';
      b.style.background='rgba(90,140,255,.16)';
      b.style.color='inherit';
      a.insertAdjacentElement('afterend', b);
    }catch(_){}
  }
  function patch(){
    const links=[...document.querySelectorAll('a[href*="/api/vsp/run_file"]')];
    const seen=new Set();
    for(const a of links){
      const rid=ridFromHref(a.getAttribute('href')||'');
      if(!rid) continue;
      const key=rid+'::'+(a.closest('tr')?a.closest('tr').rowIndex:'x');
      if(seen.has(key)) continue;
      seen.add(key);
      addBtn(a,rid);
    }
  }
  patch(); setTimeout(patch,600); setTimeout(patch,1400);
})();
</script>
"""
            if b"</body>" in body:
                body = body.replace(b"</body>", js + b"</body>", 1)
            else:
                body = body + js

        # fix Content-Length
        new_headers=[]
        for k,v in headers:
            if str(k).lower() == "content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(body))))

        start_response(meta.get("status","200 OK"), new_headers, meta.get("exc_info"))
        return [body]

try:
    if "application" in globals():
        _a = globals().get("application")
        if _a is not None and not getattr(_a, "__VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2__", False):
            _mw = VSPRunsExportZipBtnMWP0V2(_a)
            setattr(_mw, "__VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2__", True)
            globals()["application"] = _mw
except Exception:
    pass
# === /VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2 ===


# === VSP_RUNS_EXPORT_ZIP_NOJS_MW_P0_V3 ===
class VSPRunsExportZipNoJSMWP0V3:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path != "/runs":
            return self.app(environ, start_response)

        meta = {}
        def sr(status, headers, exc_info=None):
            meta["status"] = status
            meta["headers"] = headers
            meta["exc_info"] = exc_info
            return lambda _x: None

        app_iter = self.app(environ, sr)

        body = b""
        try:
            for chunk in app_iter:
                if chunk:
                    body += chunk
        finally:
            try:
                close = getattr(app_iter, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        headers = meta.get("headers") or []
        ct = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ct = str(v); break

        if ("text/html" in ct) and (b"/api/vsp/run_file" in body) and (MARKB not in body):
            try:
                html = body.decode("utf-8", "replace")
            except Exception:
                html = str(body)

            # Insert NO-JS Export button after any run_file link (per anchor)
            # Capture run_id from query string.
            runfile_a_pat = re.compile(
                r'(<a\b[^>]*href="[^"]*/api/vsp/run_file\?[^"]*?\brun_id=([^"&]+)[^"]*"[^>]*>.*?</a>)',
                re.IGNORECASE | re.DOTALL
            )

            def add_btn(m):
                a = m.group(1)
                rid = m.group(2)
                # Avoid duplicating if already inserted
                if "data-vsp-export-zip" in a:
                    return a
                btn = (
                    ' <a data-vsp-export-zip="1" '
                    'href="/api/vsp/export_zip?run_id=' + rid + '" '
                    'style="margin-left:8px;text-decoration:none;display:inline-block;'
                    'padding:7px 10px;border-radius:10px;font-weight:800;'
                    'border:1px solid rgba(90,140,255,.35);background:rgba(90,140,255,.16);color:inherit;">'
                    'Export ZIP</a>'
                )
                return a + btn

            html2, n = runfile_a_pat.subn(add_btn, html)
            if n > 0:
                # Add a marker comment that won't be stripped like <script>
                marker = "\n<!-- " + MARK + " injected=" + str(n) + " -->\n"
                if "</body>" in html2:
                    html2 = html2.replace("</body>", marker + "</body>", 1)
                else:
                    html2 = html2 + marker

                body = html2.encode("utf-8", "replace")

        # fix Content-Length
        new_headers=[]
        for k,v in headers:
            if str(k).lower() == "content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(body))))

        start_response(meta.get("status","200 OK"), new_headers, meta.get("exc_info"))
        return [body]

try:
    if "application" in globals():
        _a = globals().get("application")
        if _a is not None and not getattr(_a, "__VSP_RUNS_EXPORT_ZIP_NOJS_MW_P0_V3__", False):
            _mw = VSPRunsExportZipNoJSMWP0V3(_a)
            setattr(_mw, "__VSP_RUNS_EXPORT_ZIP_NOJS_MW_P0_V3__", True)
            globals()["application"] = _mw
except Exception:
    pass
# === /VSP_RUNS_EXPORT_ZIP_NOJS_MW_P0_V3 ===


# === VSP_RUNS_INJECT_EXTZIP_JS_P0_V1 ===
class VSPRunsInjectExtZipJSMWP0V1:
    def __init__(self, app):
        self.app = app
    def __call__(self, environ, start_response):
        if (environ.get("PATH_INFO") or "") != "/runs":
            return self.app(environ, start_response)

        meta={}
        def sr(status, headers, exc_info=None):
            meta["status"]=status; meta["headers"]=headers; meta["exc_info"]=exc_info
            return lambda _x: None

        it = self.app(environ, sr)
        body=b""
        try:
            for c in it:
                if c: body += c
        finally:
            try:
                close=getattr(it,"close",None)
                if callable(close): close()
            except Exception:
                pass

        headers = meta.get("headers") or []
        ct=""
        for k,v in headers:
            if str(k).lower()=="content-type":
                ct=str(v); break

        if ("text/html" in ct) and (MARKB not in body):
            ts = str(int(time.time()))
            tag = (f'\n<!-- {MARK} -->\n'
                   f'<script src="/static/js/vsp_runs_export_zip_patch_p0_v4.js?ts={ts}"></script>\n').encode("utf-8","replace")
            if b"</body>" in body:
                body = body.replace(b"</body>", tag + b"</body>", 1)
            else:
                body = body + tag

        newh=[]
        for k,v in headers:
            if str(k).lower()=="content-length": continue
            newh.append((k,v))
        newh.append(("Content-Length", str(len(body))))
        start_response(meta.get("status","200 OK"), newh, meta.get("exc_info"))
        return [body]

try:
    if "application" in globals():
        _a = globals().get("application")
        if _a is not None and not getattr(_a, "__VSP_RUNS_INJECT_EXTZIP_JS_P0_V1__", False):
            _mw = VSPRunsInjectExtZipJSMWP0V1(_a)
            setattr(_mw, "__VSP_RUNS_INJECT_EXTZIP_JS_P0_V1__", True)
            globals()["application"] = _mw
except Exception:
    pass
# === /VSP_RUNS_INJECT_EXTZIP_JS_P0_V1 ===


# === VSP_RUNS_500_FALLBACK_MW_P0_V1 ===
class VSPRuns500FallbackMWP0V1:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path != "/runs":
            return self.app(environ, start_response)

        meta = {}
        def sr(status, headers, exc_info=None):
            meta["status"]=status
            meta["headers"]=headers
            meta["exc_info"]=exc_info
            return lambda _x: None

        it = self.app(environ, sr)
        body=b""
        try:
            for c in it:
                if c: body += c
        finally:
            try:
                close=getattr(it,"close",None)
                if callable(close): close()
            except Exception:
                pass

        status = meta.get("status") or "200 OK"
        code = 0
        try:
            code = int(str(status).split()[0])
        except Exception:
            code = 0

        # if /runs returns 5xx => replace with a safe fallback page (NO <script>)
        if code >= 500:
            html = (
                "<!doctype html><html><head><meta charset='utf-8'>"
                "<title>Runs & Reports (fallback)</title></head>"
                "<body style='font-family:ui-sans-serif,system-ui;max-width:980px;margin:18px auto;"
                "padding:0 14px;color:#ddd;background:#0b0f14;'>"
                "<h2 style='margin:0 0 8px 0;'>Runs & Reports</h2>"
                "<div style='opacity:.85;margin-bottom:14px;'>"
                "UI /runs gặp lỗi 500. Đây là trang fallback để không sập demo.</div>"
                "<div style='display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px;'>"
                "<a href='/vsp5' style='color:#9ab;'>Dashboard</a>"
                "<a href='/data' style='color:#9ab;'>Data Source</a>"
                "<a href='/settings' style='color:#9ab;'>Settings</a>"
                "<a href='/rule_overrides' style='color:#9ab;'>Rule Overrides</a>"
                "</div>"
                "<div style='padding:12px;border:1px solid rgba(255,255,255,.1);border-radius:12px;"
                "background:rgba(255,255,255,.03);'>"
                "<div style='font-weight:800;margin-bottom:8px;'>Quick Links</div>"
                "<ul style='margin:0;padding-left:18px;line-height:1.7;'>"
                "<li><a href='/api/vsp/runs?limit=50' style='color:#9ab;'>/api/vsp/runs?limit=50</a></li>"
                "<li><a href='/api/vsp/selfcheck_p0' style='color:#9ab;'>/api/vsp/selfcheck_p0</a></li>"
                "<li><a href='/findings_unified.json' style='color:#9ab;'>/findings_unified.json</a></li>"
                "</ul>"
                "</div>"
                "<div style='opacity:.65;margin-top:14px;font-size:12px;'>"
                "Marker: VSP_RUNS_500_FALLBACK_MW_P0_V1</div>"
                "</body></html>"
            ).encode("utf-8","replace")

            start_response("200 OK", [
                ("Content-Type","text/html; charset=utf-8"),
                ("Cache-Control","no-store"),
                ("Content-Length", str(len(html)))
            ])
            return [html]

        # normal success
        hdrs = meta.get("headers") or []
        start_response(status, hdrs, meta.get("exc_info"))
        return [body]

try:
    if "application" in globals():
        _a = globals().get("application")
        if _a is not None and not getattr(_a, "__VSP_RUNS_500_FALLBACK_MW_P0_V1__", False):
            _mw = VSPRuns500FallbackMWP0V1(_a)
            setattr(_mw, "__VSP_RUNS_500_FALLBACK_MW_P0_V1__", True)
            globals()["application"] = _mw
except Exception:
    pass
# === /VSP_RUNS_500_FALLBACK_MW_P0_V1 ===


# === VSP_RUNS_500_FALLBACK_MW_P0_V2 ===
class VSPRuns500FallbackMWP0V2:
    def __init__(self, app):
        self.app = app

    def _fallback(self, start_response, why=""):
        # VSP_MARK_FIX_P0_V5: safe fallback (no f-string pitfalls, no MARK NameError)
        try:
            marker = MARK
        except Exception:
            marker = 'VSP_UI_GATEWAY_MARK_V1'
        why_s = '' if why is None else str(why)
        html = (
            "<!doctype html><meta charset='utf-8'>"
            "<title>VSP UI fallback</title>"
            "<pre>Marker: " + str(marker) + "\n" + why_s + "</pre>"
        )
        body = html.encode('utf-8', errors='replace')
        start_response('200 OK', [
            ('Content-Type','text/html; charset=utf-8'),
            ('Content-Length', str(len(body))),
            ('Cache-Control','no-store'),
        ])
        return [body]


# =========================
# VSP_RUN_FILE_SAFE_ENDPOINT_P0_V1
# - Serve per-run report/artifacts via whitelist (no absolute FS path leak)
# - Normalize "report/" vs "reports/" vs root file locations
# - Post-process /api/vsp/runs: replace any abs html_path with safe URL
# =========================
from pathlib import Path as _Path
from urllib.parse import quote as _quote
import os as _os
import json as _json
import mimetypes as _mimetypes
import re as _re

try:
    from flask import request as _request, abort as _abort, send_file as _send_file, Response as _Response
except Exception:
    _request = None  # type: ignore

_VSP_RUNFILE_ALLOWED = {
    # virtual_name: candidate real paths under RUN_DIR (first existing wins)
    "reports/index.html": [
        "reports/index.html",
        "report/index.html",
        "reports/report.html",
        "report/report.html",
        "report.html",
    ],
    "reports/findings_unified.json": [
        "reports/findings_unified.json",
        "report/findings_unified.json",
        "findings_unified.json",
        "reports/unified/findings_unified.json",
        "unified/findings_unified.json",
    ],
    "reports/findings_unified.csv": [
        "reports/findings_unified.csv",
        "report/findings_unified.csv",
        "findings_unified.csv",
        "reports/unified/findings_unified.csv",
        "unified/findings_unified.csv",
    ],
    "reports/findings_unified.sarif": [
        "reports/findings_unified.sarif",
        "report/findings_unified.sarif",
        "findings_unified.sarif",
        "reports/unified/findings_unified.sarif",
        "unified/findings_unified.sarif",
    ],
    "reports/run_gate_summary.json": [
        "reports/run_gate_summary.json",
        "report/run_gate_summary.json",
        "run_gate_summary.json",
        "reports/unified/run_gate_summary.json",
        "unified/run_gate_summary.json",
    ],
}

def _vsp__runs_roots():
    roots = []
    env = _os.environ.get("VSP_RUNS_ROOT", "").strip()
    if env:
        roots.append(_Path(env))
    # sensible defaults for this repo
    roots += [
        _Path("/home/test/Data/SECURITY_BUNDLE/out"),
        _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        _Path("/home/test/Data/SECURITY-10-10-v4/out_ci"),
    ]
    # de-dup, keep existing dirs
    out = []
    seen = set()
    for r in roots:
        rp = str(r)
        if rp in seen:
            continue
        seen.add(rp)
        if r.exists():
            out.append(r)
    return out

def _vsp__is_safe_rid(rid: str) -> bool:
    return bool(rid) and bool(_re.fullmatch(r"[A-Za-z0-9_.:-]{6,128}", rid))

def _vsp__find_run_dir(rid: str):
    # direct hit
    for root in _vsp__runs_roots():
        cand = root / rid
        if cand.is_dir():
            return cand
        cand2 = root / "out" / rid
        if cand2.is_dir():
            return cand2
    # shallow scan (bounded)
    for root in _vsp__runs_roots():
        try:
            for cand in root.glob(f"*{rid}*"):
                if cand.is_dir() and cand.name == rid:
                    return cand
        except Exception:
            pass
    return None

def _vsp__pick_file(run_dir: _Path, virtual_name: str):
    cands = _VSP_RUNFILE_ALLOWED.get(virtual_name)
    if not cands:
        return None
    for rel in cands:
        fp = (run_dir / rel).resolve()
        try:
            # must stay under run_dir
            run_dir_res = run_dir.resolve()
            if not str(fp).startswith(str(run_dir_res) + _os.sep) and fp != run_dir_res:
                continue
            if fp.is_file():
                return fp
        except Exception:
            continue
    return None

def _vsp__safe_url(rid: str, virtual_name: str) -> str:
    return f"/api/vsp/run_file?rid={_quote(rid)}&name={_quote(virtual_name)}"

# ---- Endpoint: serve whitelisted per-run file
try:
    _app_obj = app  # noqa: F821
except Exception:
    _app_obj = None

if _app_obj is not None and getattr(_app_obj, "route", None) is not None:
    @_app_obj.get("/api/vsp/run_file")
    def _api_vsp_run_file():
        rid = (_request.args.get("rid", "") if _request else "").strip()
        name = (_request.args.get("name", "") if _request else "").strip()
        if not _vsp__is_safe_rid(rid):
            return _Response("bad rid", status=400, mimetype="text/plain")
        if name not in _VSP_RUNFILE_ALLOWED:
            # VSP_P1_ALLOW_SHA256SUMS_NOT_ALLOWED_V1: allow reports/SHA256SUMS.txt (commercial audit)
            try:
                _rid = (_rq_compat.args.get('rid','') or _rq_compat.args.get('run_id','') or _rq_compat.args.get('run','') or '').strip()
                _rel = (_rq_compat.args.get('name','') or _rq_compat.args.get('path','') or _rq_compat.args.get('rel','') or '').strip().lstrip('/')
                if _rid and _rel == 'reports/SHA256SUMS.txt':
                    from pathlib import Path as _P
                    _fp = _P('/home/test/Data/SECURITY_BUNDLE/out') / _rid / 'reports' / 'SHA256SUMS.txt'
                    if _fp.exists():
                        return _sf_compat(str(_fp), as_attachment=True)
            except Exception:
                pass
            # VSP_P1_GW_BYPASS_SHA256SUMS_V1: allow reports/SHA256SUMS.txt (commercial audit)
            try:
                _rid = (_rq_compat.args.get('rid','') or _rq_compat.args.get('run_id','') or _rq_compat.args.get('run','') or '').strip()
                _rel = (_rq_compat.args.get('name','') or _rq_compat.args.get('path','') or _rq_compat.args.get('rel','') or '').strip().lstrip('/')
                if _rid and _rel == 'reports/SHA256SUMS.txt':
                    from pathlib import Path as _P
                    from flask import send_file as _send_file, jsonify as _jsonify
                    _fp = _P('/home/test/Data/SECURITY_BUNDLE/out') / _rid / 'reports' / 'SHA256SUMS.txt'
                    if _fp.exists():
                        return _send_file(str(_fp), as_attachment=True)
                    return _jsonify({'ok': False, 'error': 'NO_FILE'}), 404
            except Exception:
                pass
            return _Response("not allowed", status=404, mimetype="text/plain")

        run_dir = _vsp__find_run_dir(rid)
        if not run_dir:
            return _Response("run not found", status=404, mimetype="text/plain")

        fp = _vsp__pick_file(run_dir, name)
        if not fp:
            return _Response("file not found", status=404, mimetype="text/plain")

        ctype, _enc = _mimetypes.guess_type(str(fp))
        ctype = ctype or ("text/html" if str(fp).endswith(".html") else "application/octet-stream")
        # inline for html/json, attachment for others
        as_attachment = not (str(fp).endswith(".html") or str(fp).endswith(".json"))
        return _send_file(fp, mimetype=ctype, as_attachment=as_attachment, download_name=fp.name)

    # learned-safe postprocess: rewrite /api/vsp/runs JSON to avoid absolute paths + add safe urls
    @_app_obj.after_request
    def _vsp__after_request_safe_runs(resp):
        try:
            if not _request or _request.path != "/api/vsp/runs":
                return resp
            if "application/json" not in (resp.headers.get("Content-Type", "") or ""):
                return resp
            data = resp.get_json(silent=True)
            if not isinstance(data, dict):
                return resp
            items = data.get("items") or []
            if not isinstance(items, list):
                return resp

            for it in items:
                if not isinstance(it, dict):
                    continue
                rid = (it.get("run_id") or it.get("rid") or "").strip()
                if not _vsp__is_safe_rid(rid):
                    continue
                has = it.get("has")
                if not isinstance(has, dict):
                    has = {}
                    it["has"] = has

                run_dir = _vsp__find_run_dir(rid)
                if not run_dir:
                    continue

                # normalize: if file exists under any legacy location, mark true + set safe URL
                def mark(vname: str, flag: str, keypath: str):
                    fp = _vsp__pick_file(run_dir, vname)
                    if fp:
                        has[flag] = True
                        has[keypath] = _vsp__safe_url(rid, vname)

                mark("reports/index.html", "html", "html_path")
                mark("reports/findings_unified.json", "json", "json_path")
                mark("reports/findings_unified.csv", "csv", "csv_path")
                mark("reports/findings_unified.sarif", "sarif", "sarif_path")
                mark("reports/run_gate_summary.json", "summary", "summary_path")

                # if legacy code already stuffed abs path into html_path, force rewrite to safe url
                hp = has.get("html_path")
                if isinstance(hp, str) and hp.startswith("/"):
                    # only rewrite if we can actually serve a report
                    if _vsp__pick_file(run_dir, "reports/index.html"):
                        has["html_path"] = _vsp__safe_url(rid, "reports/index.html")

            # re-encode response
            body = _json.dumps(data, ensure_ascii=False)
            resp.set_data(body)
            resp.headers["Content-Length"] = str(len(body.encode("utf-8")))
            return resp
        except Exception:
            return resp

# =========================
# END VSP_RUN_FILE_SAFE_ENDPOINT_P0_V1
# =========================


# =========================
# VSP_RUN_FILE2_SAFE_ENDPOINT_P0_V1
# - New endpoint /api/vsp/run_file2 to avoid collision with existing /api/vsp/run_file
# - Rewrite /api/vsp/runs has.*_path to use run_file2 (safe, no abs path)
# =========================
from pathlib import Path as _P2
from urllib.parse import quote as _q2
import os as _os2
import json as _json2
import mimetypes as _mt2
import re as _re2

try:
    from flask import request as _rq2, send_file as _sf2, Response as _R2
except Exception:
    _rq2 = None  # type: ignore

_VSP_RF2_ALLOWED = {
    "reports/index.html": [
        "reports/index.html","report/index.html","reports/report.html","report/report.html","report.html",
    ],
    "reports/findings_unified.json": [
        "reports/findings_unified.json","report/findings_unified.json","findings_unified.json",
        "reports/unified/findings_unified.json","unified/findings_unified.json",
    ],
    "reports/findings_unified.csv": [
        "reports/findings_unified.csv","report/findings_unified.csv","findings_unified.csv",
        "reports/unified/findings_unified.csv","unified/findings_unified.csv",
    ],
    "reports/findings_unified.sarif": [
        "reports/findings_unified.sarif","report/findings_unified.sarif","findings_unified.sarif",
        "reports/unified/findings_unified.sarif","unified/findings_unified.sarif",
    ],
    "reports/run_gate_summary.json": [
        "reports/run_gate_summary.json","report/run_gate_summary.json","run_gate_summary.json",
        "reports/unified/run_gate_summary.json","unified/run_gate_summary.json",
    ],
}

def _rf2_roots():
    roots=[]
    env=_os2.environ.get("VSP_RUNS_ROOT","").strip()
    if env: roots.append(_P2(env))
    roots += [
        _P2("/home/test/Data/SECURITY_BUNDLE/out"),
        _P2("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        _P2("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        _P2("/home/test/Data/SECURITY-10-10-v4/out_ci"),
    ]
    out=[]; seen=set()
    for r in roots:
        rp=str(r)
        if rp in seen: continue
        seen.add(rp)
        if r.exists(): out.append(r)
    return out

def _rf2_safe_rid(rid:str)->bool:
    return bool(rid) and bool(_re2.fullmatch(r"[A-Za-z0-9_.:-]{6,160}", rid))

def _rf2_find_run_dir(rid:str):
    for root in _rf2_roots():
        for cand in (root/rid, root/"out"/rid):
            if cand.is_dir(): return cand
    return None

def _rf2_pick(run_dir:_P2, vname:str):
    cands=_VSP_RF2_ALLOWED.get(vname)
    if not cands: return None
    rd=run_dir.resolve()
    for rel in cands:
        fp=(run_dir/rel).resolve()
        try:
            if not str(fp).startswith(str(rd)+_os2.sep): 
                continue
            if fp.is_file(): return fp
        except Exception:
            continue
    return None

def _rf2_url(rid:str, vname:str)->str:
    return f"/api/vsp/run_file2?rid={_q2(rid)}&name={_q2(vname)}"

try:
    _app2 = app  # noqa: F821
except Exception:
    _app2 = None

if _app2 is not None and getattr(_app2, "route", None) is not None:
    @_app2.get("/api/vsp/run_file2")
    def _api_vsp_run_file2():
        rid = (_rq2.args.get("rid","") if _rq2 else "").strip()
        name = (_rq2.args.get("name","") if _rq2 else "").strip()
        # allow alias param
        if not name and _rq2:
            name = (_rq2.args.get("path","") or _rq2.args.get("n","") or "").strip()

        if not _rf2_safe_rid(rid):
            return _R2(_json2.dumps({"ok":False,"err":"bad rid"}), status=400, mimetype="application/json")
        if name not in _VSP_RF2_ALLOWED:
            # VSP_P1_ALLOW_SHA256SUMS_NOT_ALLOWED_V1: allow reports/SHA256SUMS.txt (commercial audit)
            try:
                _rid = (_rq_compat.args.get('rid','') or _rq_compat.args.get('run_id','') or _rq_compat.args.get('run','') or '').strip()
                _rel = (_rq_compat.args.get('name','') or _rq_compat.args.get('path','') or _rq_compat.args.get('rel','') or '').strip().lstrip('/')
                if _rid and _rel == 'reports/SHA256SUMS.txt':
                    from pathlib import Path as _P
                    _fp = _P('/home/test/Data/SECURITY_BUNDLE/out') / _rid / 'reports' / 'SHA256SUMS.txt'
                    if _fp.exists():
                        return _sf_compat(str(_fp), as_attachment=True)
            except Exception:
                pass
            return _R2(_json2.dumps({"ok":False,"err":"not allowed"}), status=404, mimetype="application/json")

        run_dir = _rf2_find_run_dir(rid)
        if not run_dir:
            return _R2(_json2.dumps({"ok":False,"err":"run not found"}), status=404, mimetype="application/json")

        fp = _rf2_pick(run_dir, name)
        if not fp:
            return _R2(_json2.dumps({"ok":False,"err":"file not found"}), status=404, mimetype="application/json")

        ctype,_ = _mt2.guess_type(str(fp))
        ctype = ctype or ("text/html" if str(fp).endswith(".html") else "application/octet-stream")
        as_attach = not (str(fp).endswith(".html") or str(fp).endswith(".json"))
        return _sf2(fp, mimetype=ctype, as_attachment=as_attach, download_name=fp.name)

    @_app2.after_request
    def _rf2_after(resp):
        try:
            if not _rq2 or _rq2.path != "/api/vsp/runs":
                return resp
            if "application/json" not in (resp.headers.get("Content-Type","") or ""):
                return resp
            data = resp.get_json(silent=True)
            if not isinstance(data, dict):
                return resp
            items = data.get("items") or []
            if not isinstance(items, list):
                return resp

            for it in items:
                if not isinstance(it, dict): 
                    continue
                rid = (it.get("run_id") or it.get("rid") or "").strip()
                if not _rf2_safe_rid(rid):
                    continue
                has = it.get("has")
                if not isinstance(has, dict):
                    has = {}
                    it["has"] = has

                rd = _rf2_find_run_dir(rid)
                if not rd:
                    continue

                def mark(vname, flag, keypath):
                    fp = _rf2_pick(rd, vname)
                    if fp:
                        has[flag] = True
                        has[keypath] = _rf2_url(rid, vname)

                # always prefer run_file2 urls
                mark("reports/index.html","html","html_path")
                mark("reports/findings_unified.json","json","json_path")
                mark("reports/findings_unified.csv","csv","csv_path")
                mark("reports/findings_unified.sarif","sarif","sarif_path")
                mark("reports/run_gate_summary.json","summary","summary_path")

                # rewrite any old run_file url -> run_file2
                for k in ("html_path","json_path","csv_path","sarif_path","summary_path"):
                    v = has.get(k)
                    if isinstance(v,str) and v.startswith("/api/vsp/run_file?"):
                        has[k] = v.replace("/api/vsp/run_file?","/api/vsp/run_file2?",1)
            # VSP_FORCE_RUNFILE2_PATHS_P0_V2: normalize path fields and fill missing *_path
            for it in items:
                if not isinstance(it, dict):
                    continue
                has = it.get("has") or {}
                if not isinstance(has, dict):
                    continue
                rid = (it.get("run_id") or it.get("rid") or "").strip()
                if not rid:
                    continue

                # rewrite run_file -> run_file2
                for k in ("html_path","json_path","csv_path","sarif_path","summary_path"):
                    v = has.get(k)
                    if isinstance(v, str) and v.startswith("/api/vsp/run_file?"):
                        has[k] = v.replace("/api/vsp/run_file?","/api/vsp/run_file2?",1)

                # fill missing paths if boolean says true
                if has.get("json") is True and not has.get("json_path"):
                    has["json_path"] = _rf2_url(rid, "reports/findings_unified.json")
                if has.get("summary") is True and not has.get("summary_path"):
                    has["summary_path"] = _rf2_url(rid, "reports/run_gate_summary.json")
                if has.get("html") is True and not has.get("html_path"):
                    has["html_path"] = _rf2_url(rid, "reports/index.html")
                if has.get("csv") is True and not has.get("csv_path"):
                    has["csv_path"] = _rf2_url(rid, "reports/findings_unified.csv")
                if has.get("sarif") is True and not has.get("sarif_path"):
                    has["sarif_path"] = _rf2_url(rid, "reports/findings_unified.sarif")

                it["has"] = has

            # VSP_FORCE_RUNFILE2_PATHS_P0_V3: FINAL normalize (override any earlier after_request)
            for it in items:
                if not isinstance(it, dict):
                    continue
                rid = (it.get("run_id") or it.get("rid") or "").strip()
                if not rid:
                    continue
                has = it.get("has") or {}
                if not isinstance(has, dict):
                    continue

                # rewrite any old run_file url -> run_file2
                for k in ("html_path","json_path","csv_path","sarif_path","summary_path"):
                    v = has.get(k)
                    if isinstance(v, str) and v.startswith("/api/vsp/run_file?"):
                        has[k] = v.replace("/api/vsp/run_file?","/api/vsp/run_file2?",1)

                # fill missing *_path if boolean true
                if has.get("json") is True and not has.get("json_path"):
                    has["json_path"] = _rf2_url(rid, "reports/findings_unified.json")
                if has.get("summary") is True and not has.get("summary_path"):
                    has["summary_path"] = _rf2_url(rid, "reports/run_gate_summary.json")
                if has.get("html") is True and not has.get("html_path"):
                    has["html_path"] = _rf2_url(rid, "reports/index.html")

                it["has"] = has


            body = _json2.dumps(data, ensure_ascii=False)
            resp.set_data(body)
            resp.headers["Content-Length"] = str(len(body.encode("utf-8")))
            return resp
        except Exception:
            return resp
# =========================
# END VSP_RUN_FILE2_SAFE_ENDPOINT_P0_V1
# =========================

# VSP_FORCE_RUNFILE2_PATHS_P0_V2

# VSP_FORCE_RUNFILE2_PATHS_P0_V3

# =========================
# VSP_REWRITE_RUN_FILE_TO_RUN_FILE2_P0_V1
# Force rewrite any /api/vsp/run_file? -> /api/vsp/run_file2? inside /api/vsp/runs JSON response.
# =========================
try:
    from flask import request as _rq_last
except Exception:
    _rq_last = None  # type: ignore

try:
    _app_last = app  # noqa: F821
except Exception:
    _app_last = None

if _app_last is not None and getattr(_app_last, "after_request", None) is not None:
    @_app_last.after_request
    def _vsp_after_rewrite_runfile2(resp):
        try:
            if not _rq_last or _rq_last.path != "/api/vsp/runs":
                return resp
            ct = (resp.headers.get("Content-Type","") or "")
            if "application/json" not in ct:
                return resp
            body = resp.get_data(as_text=True) or ""
            if "/api/vsp/run_file?" not in body:
                return resp
            body2 = body.replace("/api/vsp/run_file?","/api/vsp/run_file2?")
            resp.set_data(body2)
            resp.headers["Content-Length"] = str(len(body2.encode("utf-8")))
            return resp
        except Exception:
            return resp
# =========================
# END VSP_REWRITE_RUN_FILE_TO_RUN_FILE2_P0_V1
# =========================

# =========================
# VSP_RUN_FILE_COMPAT_TO_RUN_FILE2_P0_V1
# Make legacy /api/vsp/run_file work by serving via run_file2 whitelist logic.
# This avoids 400 from old handler and makes UI clickable immediately.
# =========================
try:
    from flask import request as _rq_compat, send_file as _sf_compat, Response as _R_compat
except Exception:
    _rq_compat = None  # type: ignore

try:
    _app_compat = app  # noqa: F821
except Exception:
    _app_compat = None

if _app_compat is not None and getattr(_app_compat, "before_request", None) is not None:
    @_app_compat.before_request
    def _vsp_compat_run_file_to_run_file2():
        try:
            if not _rq_compat:
                return None
            if _rq_compat.path != "/api/vsp/run_file":
                return None

            rid = (_rq_compat.args.get("rid","") or "").strip()
            name = (_rq_compat.args.get("name","") or _rq_compat.args.get("path","") or _rq_compat.args.get("n","") or "").strip()

            # Use run_file2 validators if present
            if " _rf2_safe_rid" and callable(globals().get("_rf2_safe_rid")):
                if not globals()["_rf2_safe_rid"](rid):
                    return _R_compat('{"ok":false,"err":"bad rid"}', status=400, mimetype="application/json")
            else:
                # fallback
                import re as _re
                if not rid or not _re.fullmatch(r"[A-Za-z0-9_.:-]{6,160}", rid):
                    return _R_compat('{"ok":false,"err":"bad rid"}', status=400, mimetype="application/json")

            allowed = globals().get("_VSP_RF2_ALLOWED") or globals().get("_VSP_RUNFILE_ALLOWED") or {}
            if name not in allowed:
                # VSP_P1_ALLOW_SHA256SUMS_NOT_ALLOWED_V1: allow reports/SHA256SUMS.txt (commercial audit)
                try:
                    _rid = (_rq_compat.args.get('rid','') or _rq_compat.args.get('run_id','') or _rq_compat.args.get('run','') or '').strip()
                    _rel = (_rq_compat.args.get('name','') or _rq_compat.args.get('path','') or _rq_compat.args.get('rel','') or '').strip().lstrip('/')
                    if _rid and _rel == 'reports/SHA256SUMS.txt':
                        from pathlib import Path as _P
                        _fp = _P('/home/test/Data/SECURITY_BUNDLE/out') / _rid / 'reports' / 'SHA256SUMS.txt'
                        if _fp.exists():
                            return _sf_compat(str(_fp), as_attachment=True)
                except Exception:
                    pass
                return _R_compat('{"ok":false,"err":"not allowed"}', status=404, mimetype="application/json")

            find_dir = globals().get("_rf2_find_run_dir") or globals().get("_vsp__find_run_dir")
            pick_file = globals().get("_rf2_pick") or globals().get("_vsp__pick_file")
            if not callable(find_dir) or not callable(pick_file):
                return _R_compat('{"ok":false,"err":"compat helpers missing"}', status=500, mimetype="application/json")

            run_dir = find_dir(rid)
            if not run_dir:
                return _R_compat('{"ok":false,"err":"run not found"}', status=404, mimetype="application/json")

            fp = pick_file(run_dir, name)
            if not fp:
                return _R_compat('{"ok":false,"err":"file not found"}', status=404, mimetype="application/json")

            import mimetypes as _mt
            ctype,_ = _mt.guess_type(str(fp))
            ctype = ctype or ("text/html" if str(fp).endswith(".html") else "application/octet-stream")
            as_attach = not (str(fp).endswith(".html") or str(fp).endswith(".json"))
            return _sf_compat(fp, mimetype=ctype, as_attachment=as_attach, download_name=fp.name)
        except Exception:
            # let original handler run if something unexpected happens
            return None
# =========================
# END VSP_RUN_FILE_COMPAT_TO_RUN_FILE2_P0_V1
# =========================



# VSP_RUN_FILE_LEGACY_COMPAT_MW_P0_V1
# Accept legacy /api/vsp/run_file?run_id=...&path=... by rewriting to rid/name at WSGI layer.
try:
    from urllib.parse import parse_qs, urlencode
except Exception:
    parse_qs = None
    urlencode = None

class _VspRunFileLegacyCompatMW:
    def __init__(self, app):
        self.app = app
    def __call__(self, environ, start_response):
        try:
            path = environ.get("PATH_INFO", "") or ""
            if path == "/api/vsp/run_file" and parse_qs and urlencode:
                qs = environ.get("QUERY_STRING", "") or ""
                q = parse_qs(qs, keep_blank_values=True)
                # If legacy keys exist but new keys missing => map
                if (("run_id" in q) or ("path" in q)) and (("rid" not in q) and ("name" not in q)):
                    if "run_id" in q:
                        q["rid"] = q.get("run_id")
                    if "path" in q:
                        q["name"] = q.get("path")
                    # Keep all keys (including run_id/path) to be safe
                    pairs = []
                    for k, vs in q.items():
                        for v in vs:
                            pairs.append((k, v))
                    environ["QUERY_STRING"] = urlencode(pairs, doseq=True)
        except Exception:
            pass
        return self.app(environ, start_response)

application = _VspRunFileLegacyCompatMW(application)



# VSP_RUNS_NO_FS_LEAK_MW_P0_V1
# Rewrite /api/vsp/runs payload: never expose filesystem paths; provide /api/vsp/run_file URLs instead.
import json as _json
from urllib.parse import urlencode as _urlencode

class _VspRunsNoFsLeakMW:
    def __init__(self, app):
        self.app = app
    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if path != "/api/vsp/runs":
            return self.app(environ, start_response)

        captured = {"status": None, "headers": None}
        body_chunks = []

        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers)
            # delay sending headers until we possibly rewrite body
            return body_chunks.append

        it = self.app(environ, _sr)

        try:
            for c in it:
                if c:
                    body_chunks.append(c)
        finally:
            try:
                close = getattr(it, "close", None)
                if callable(close): close()
            except Exception:
                pass

        raw = b"".join([c if isinstance(c,(bytes,bytearray)) else str(c).encode("utf-8","replace") for c in body_chunks])
        try:
            obj = _json.loads(raw.decode("utf-8","replace"))
        except Exception:
            # fall back: send original
            headers = captured["headers"] or []
            start_response(captured["status"] or "200 OK", headers)
            return [raw]

        def run_file_url(rid, name):
            qs = _urlencode({"rid": rid, "name": name})
            return "/api/vsp/run_file?" + qs

        items = obj.get("items") if isinstance(obj, dict) else None
        if isinstance(items, list):
            for it in items:
                if not isinstance(it, dict): 
                    continue
                rid = it.get("run_id") or it.get("rid")
                has = it.get("has")
                if not rid or not isinstance(has, dict):
                    continue
                # normalize paths to URLs
                # html
                if has.get("html") is True:
                    has["html_path"] = run_file_url(rid, "reports/index.html")
                elif "html_path" in has and isinstance(has["html_path"], str) and has["html_path"].startswith("/home/"):
                    # if backend leaked FS path, convert to URL and set html true
                    has["html"] = True
                    has["html_path"] = run_file_url(rid, "reports/index.html")
                # json (standardize to reports/findings_unified.json)
                if "json_path" in has:
                    has["json_path"] = run_file_url(rid, "reports/findings_unified.json")
                if has.get("json") is True:
                    has["json_path"] = run_file_url(rid, "reports/findings_unified.json")
                # summary
                if "summary_path" in has:
                    has["summary_path"] = run_file_url(rid, "reports/run_gate_summary.json")
                if has.get("summary") is True:
                    has["summary_path"] = run_file_url(rid, "reports/run_gate_summary.json")

                # Optional: offer txt path in reports (more likely whitelisted)
                has["txt_path"] = run_file_url(rid, "reports/SUMMARY.txt")
                has["sha_path"] = run_file_url(rid, "reports/SHA256SUMS.txt")
        out = _json.dumps(obj, ensure_ascii=False).encode("utf-8")
        headers = [(k,v) for (k,v) in (captured["headers"] or []) if k.lower() != "content-length"]
        headers.append(("Content-Length", str(len(out))))
        start_response(captured["status"] or "200 OK", headers)
        return [out]

application = _VspRunsNoFsLeakMW(application)



# VSP_RUN_FILE_DIRECTSERVE_REPORTS_SUMMARY_P0_V1
# Direct-serve ONLY reports/SUMMARY.txt to avoid allowlist/validator blocking.
# This stays commercial-safe: fixed path, fixed filename, strict RID folder under SECURITY_BUNDLE/out or out_ci.
from urllib.parse import parse_qs as _parse_qs
from pathlib import Path as _Path

class _VspRunFileDirectServeSummaryMW:
    def __init__(self, app):
        self.app = app
        self.root = _Path("/home/test/Data/SECURITY_BUNDLE")
    def _resolve_run_dir(self, rid: str):
        rid = (rid or "").strip()
        cands = []
        if rid:
            cands.append(rid)
            if "RUN_" in rid:
                cands.append(rid[rid.find("RUN_"):])
        for cand in cands:
            for base in ("out", "out_ci"):
                d = self.root / base / cand
                if d.is_dir():
                    return d
        return None

    def __call__(self, environ, start_response):
        try:
            if (environ.get("PATH_INFO","") or "") == "/api/vsp/run_file":
                qs = environ.get("QUERY_STRING","") or ""
                q = _parse_qs(qs, keep_blank_values=True)
                rid = (q.get("rid") or q.get("run_id") or q.get("runId") or [""])[0]
                name = (q.get("name") or q.get("path") or q.get("file") or [""])[0]
                name = (name or "").strip()

                # normalize summary variants
                if name in ("reports/SUMMARY.txt", "reports/SHA256SUMS.txt", "reports/summary.txt", "SUMMARY.txt", "SHA256SUMS.txt", "summary.txt"):
                    run_dir = self._resolve_run_dir(rid)
                    if run_dir:
                        fp = run_dir / "reports" / "SUMMARY.txt", "SHA256SUMS.txt"
                        if fp.is_file() and fp.stat().st_size > 0:
                            data = fp.read_bytes()
                            headers = [
                                ("Content-Type", "text/plain; charset=utf-8"),
                                ("Content-Length", str(len(data))),
                                ("Cache-Control", "no-store"),
                            ]
                            start_response("200 OK", headers)
                            return [data]
        except Exception:
            pass

        return self.app(environ, start_response)

application = _VspRunFileDirectServeSummaryMW(application)




# === VSP_API_REPORTS_LATEST_BIND_APP_P0_V3 ===
from pathlib import Path
from urllib.parse import quote

def _vsp__find_latest_run_with_file__p0v3(relpath: str) -> str:
    base = Path("/home/test/Data/SECURITY_BUNDLE/out")
    if not base.exists():
        return ""
    runs = sorted(base.glob("RUN_*"), key=lambda x: x.stat().st_mtime, reverse=True)
    for rd in runs[:300]:
        try:
            if (rd / relpath).is_file():
                return rd.name
        except Exception:
            continue
    return ""

def vsp_api_reports_latest__p0v3(name):
    rel = name if name.startswith("reports/") else ("reports/" + name)
    rid = _vsp__find_latest_run_with_file__p0v3(rel)
    if not rid:
        return ("Not Found", 404)
    url = "/api/vsp/run_file?rid=" + quote(rid) + "&name=" + quote(rel)
    return ("", 302, {"Location": url})

def _vsp__bind_reports_latest__p0v3():
    # bind to Flask app (usually global "app"); do NOT use "application" wrapper
    flask_app = globals().get("app")
    if not (hasattr(flask_app, "add_url_rule") and hasattr(flask_app, "url_map")):
        # fallback scan
        flask_app = None
        for v in globals().values():
            if hasattr(v, "add_url_rule") and hasattr(v, "url_map") and hasattr(v, "route"):
                flask_app = v
                break
    if not flask_app:
        print("[WARN] cannot locate Flask app to bind /api/reports")
        return False
    try:
        flask_app.add_url_rule(
            "/api/reports/<path:name>",
            endpoint="vsp_api_reports_latest",
            view_func=vsp_api_reports_latest__p0v3,
            methods=["GET","HEAD"]
        )
    except Exception:
        # already bound / endpoint exists
        pass
    return True

_vsp__bind_reports_latest__p0v3()


# VSP_P1_ALLOW_SHA256SUMS_GLOBAL_V1

# VSP_P1_ALLOW_SHA256SUMS_NOT_ALLOWED_V1

# VSP_P1_GW_BYPASS_SHA256SUMS_V1

# VSP_P1_GW_RUNFILE_ANCHOR_ALLOW_SHA_V3

# VSP_P1_FIX_SHA256SUMS_COMPAT_V2

# VSP_P1_ALLOW_SHA256SUMS_V5

# VSP_P1_FIX_RUNS_AND_SHA256SUMS_V1


# === VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1 ===
def _vsp_proxy_run_file_summary_to_run_file2_wsgi(app):
    """
    If legacy /api/vsp/run_file can't serve reports/SUMMARY.txt (or SHA256SUMS),
    transparently route it to /api/vsp/run_file2 (same rid/name contract).
    """
    from urllib.parse import parse_qs, urlencode

    def wsgi(environ, start_response):
        try:
            path = (environ.get("PATH_INFO","") or "")
            method = (environ.get("REQUEST_METHOD","GET") or "GET").upper()
            if path == "/api/vsp/run_file" and method in ("GET","HEAD"):
                qs = parse_qs(environ.get("QUERY_STRING","") or "")
                name = (qs.get("name") or [""])[0] or ""
                # only intercept the problematic ones (minimal risk)
                if name in ("reports/SUMMARY.txt","reports/SHA256SUMS.txt"):
                    environ = dict(environ)
                    environ["PATH_INFO"] = "/api/vsp/run_file2"
                    # keep same query
                    environ["QUERY_STRING"] = urlencode([(k, v2) for k, vv in qs.items() for v2 in vv])
        except Exception:
            pass
        return app(environ, start_response)
    return wsgi
# === /VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1 ===


# === VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1_APPLY ===
try:
    if "application" in globals():
        application = _vsp_proxy_run_file_summary_to_run_file2_wsgi(application)
    elif "app" in globals():
        application = _vsp_proxy_run_file_summary_to_run_file2_wsgi(app)
except Exception:
    pass
# === /VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1_APPLY ===

# VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1

# VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V2


# === VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1 ===
def _vsp_direct_serve_summary_sha_wsgi(app):
    """
    Commercial-safe: ensure legacy /api/vsp/run_file can serve:
      - reports/SUMMARY.txt
      - reports/SHA256SUMS.txt
    for both GET and HEAD, by reading files directly from OUT_ROOT.
    """
    import os
    from pathlib import Path
    from urllib.parse import parse_qs

    OUT_ROOT = Path("/home/test/Data/SECURITY_BUNDLE/out")

    def _send(start_response, code, headers, body=b""):
        start_response(code, headers)
        return [body] if body else [b""]

    def wsgi(environ, start_response):
        try:
            path = (environ.get("PATH_INFO","") or "")
            method = (environ.get("REQUEST_METHOD","GET") or "GET").upper()
            if path == "/api/vsp/run_file" and method in ("GET","HEAD"):
                qs = parse_qs(environ.get("QUERY_STRING","") or "")
                rid = (qs.get("rid") or [""])[0].strip()
                name = (qs.get("name") or [""])[0].strip()
                if rid and name in ("reports/SUMMARY.txt","reports/SHA256SUMS.txt"):
                    fp = (OUT_ROOT / rid / name).resolve()
                    rd = (OUT_ROOT / rid).resolve()
                    if str(fp).find(str(rd)) != 0:
                        return _send(start_response, "400 BAD REQUEST", [
                            ("Content-Type","application/json; charset=utf-8"),
                            ("X-VSP-DirectServe", MARK),
                        ], b'{"ok":false,"err":"path traversal"}')
                    if fp.exists() and fp.is_file():
                        try:
                            st = fp.stat()
                            clen = str(int(st.st_size))
                        except Exception:
                            clen = None
                        headers = [
                            ("Content-Type","text/plain; charset=utf-8"),
                            ("Content-Disposition", f'attachment; filename={os.path.basename(name)}'),
                            ("Cache-Control","no-cache"),
                            ("X-VSP-DirectServe", MARK),
                        ]
                        if clen:
                            headers.append(("Content-Length", clen))
                        if method == "HEAD":
                            return _send(start_response, "200 OK", headers, b"")
                        body = fp.read_bytes()
                        return _send(start_response, "200 OK", headers, body)
        except Exception:
            pass
        return app(environ, start_response)

    return wsgi
# === /VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1 ===


# === VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1_APPLY ===
try:
    if "application" in globals():
        application = _vsp_direct_serve_summary_sha_wsgi(application)
    elif "app" in globals():
        application = _vsp_direct_serve_summary_sha_wsgi(app)
except Exception:
    pass
# === /VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1_APPLY ===

# VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1

# ---- VSP_P1_HTML_NETGUARD_P1_V7B (commercial polish: stop /vsp5 poll spam) ----
try:
    import re as _re
    from flask import request as _request
except Exception:
    _re = None
    _request = None

_VSP_P1_NETGUARD_HTML_V7B = r"""
<!-- VSP_P1_NETGUARD_GLOBAL_V7B -->
<script id="VSP_P1_NETGUARD_GLOBAL_V7B">
(()=> {
  if (window.__vsp_p1_netguard_global_v7b) return;
  window.__vsp_p1_netguard_global_v7b = true;

  const HOLD_MS = 15000;
  let holdUntil = Date.now() + 2500; // grace on first load/restart

  // drop only noisy poll logs (do NOT hide real errors)
  const DROP = [
    /\[VSP\]\s*poll down; backoff/i,
    /poll down; backoff/i,
    /runs fetch guard\/backoff enabled/i,
    /VSP_ROUTE_GUARD_RUNS_ONLY_/i
  ];
  function _dropArgs(args){
    try{
      if (!args || !args.length) return false;
      const a0 = (typeof args[0] === "string") ? args[0] : "";
      return DROP.some(rx => rx.test(a0));
    }catch(_){ return false; }
  }
  if (!window.__vsp_console_filtered_v7b){
    window.__vsp_console_filtered_v7b = true;
    for (const k of ["log","info","warn","error"]){
      const orig = console[k].bind(console);
      console[k] = (...args)=>{ if (_dropArgs(args)) return; return orig(...args); };
    }
  }

  function _isApiVsp(u){ return !!u && u.includes("/api/vsp/"); }
  function _isPlaceholder(u){ return !!u && (u === "<URL>" || u.includes("<URL>")); }

  function _cacheKey(u){
    try{
      const uu = new URL(u, location.origin);
      return "vsp_api_cache_v7b::" + uu.pathname + uu.search;
    }catch(_){
      return "vsp_api_cache_v7b::" + String(u);
    }
  }
  function _load(u){
    try{
      const raw = localStorage.getItem(_cacheKey(u));
      return raw ? JSON.parse(raw) : null;
    }catch(_){ return null; }
  }
  function _save(u,obj){
    try{ localStorage.setItem(_cacheKey(u), JSON.stringify(obj)); }catch(_){}
  }
  function _resp(obj,hdr){
    const h = new Headers({"Content-Type":"application/json; charset=utf-8"});
    try{ if (hdr) for (const [k,v] of Object.entries(hdr)) h.set(k, String(v)); }catch(_){}
    return new Response(JSON.stringify(obj), {status:200, headers:h});
  }

  // fetch wrapper
  if (window.fetch && !window.__vsp_fetch_wrapped_v7b){
    window.__vsp_fetch_wrapped_v7b = true;
    const orig = window.fetch.bind(window);
    window.fetch = async (input, init)=>{
      let u="";
      try{ u = (typeof input==="string") ? input : (input && input.url) ? input.url : ""; }catch(_){}
      if (_isPlaceholder(u)){
        return _resp({ok:false, note:"intercepted <URL>", marker:"V7B"}, {"X-VSP-Intercept":"1"});
      }
      if (_isApiVsp(u)){
        const now = Date.now();
        if (now < holdUntil){
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1"});
        }
        try{
          const r = await orig(input, init);
          if (r && r.ok){
            try{
              const j = await r.clone().json();
              if (j && typeof j==="object") _save(u, j);
            }catch(_){}
            return r;
          }
          holdUntil = Date.now() + HOLD_MS;
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1","X-VSP-Non200": r ? r.status : "NA"});
        }catch(_e){
          holdUntil = Date.now() + HOLD_MS;
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1","X-VSP-NetFail":"1"});
        }
      }
      return orig(input, init);
    };
  }

  // XHR wrapper (stop DevTools spam during restart)
  if (window.XMLHttpRequest && !window.__vsp_xhr_wrapped_v7b){
    window.__vsp_xhr_wrapped_v7b = true;
    const _open = XMLHttpRequest.prototype.open;
    const _send = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(method, url){
      try{ this.__vsp_url = String(url || ""); }catch(_){}
      return _open.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function(body){
      const u = (this && this.__vsp_url) ? String(this.__vsp_url) : "";
      if (_isPlaceholder(u) || _isApiVsp(u)){
        const now = Date.now();
        if (_isPlaceholder(u) || (now < holdUntil && _isApiVsp(u))){
          const cached = _isPlaceholder(u) ? {ok:false, note:"intercepted <URL>", marker:"V7B"} : (_load(u) || {ok:false, note:"degraded-cache-empty"});
          const txt = JSON.stringify(cached);
          try{
            Object.defineProperty(this, "status", { get: ()=>200, configurable:true });
            Object.defineProperty(this, "responseText", { get: ()=>txt, configurable:true });
            Object.defineProperty(this, "response", { get: ()=>txt, configurable:true });
          }catch(_){}
          const self=this;
          setTimeout(()=>{
            try{ if (typeof self.onreadystatechange==="function") self.onreadystatechange(); }catch(_){}
            try{ if (typeof self.onload==="function") self.onload(); }catch(_){}
            try{ self.dispatchEvent && self.dispatchEvent(new Event("load")); }catch(_){}
          },0);
          return; // NO NETWORK => no DevTools spam
        }
      }
      return _send.apply(this, arguments);
    };
  }
})();
</script>
"""

def _vsp_p1_inject_head_v7b(html: str) -> str:
    if _re is None:
        return html
    m = _re.search(r"<head[^>]*>", html, flags=_re.I)
    if not m:
        return html
    ins = m.end()
    return html[:ins] + "\n" + _VSP_P1_NETGUARD_HTML_V7B + "\n" + html[ins:]

try:
    _app = application  # must exist in this gateway
    @_app.after_request
    def _vsp_p1_html_netguard_v7b(resp):
        try:
            if _request is None or _re is None:
                return resp
            if _request.path not in ("/vsp5", "/vsp5/"):
                return resp
            ct = (resp.headers.get("Content-Type","") or "")
            if "text/html" not in ct:
                return resp
            html = resp.get_data(as_text=True)
            if "VSP_P1_NETGUARD_GLOBAL_V7B" in html:
                return resp
            html2 = _vsp_p1_inject_head_v7b(html)
            if html2 != html:
                resp.set_data(html2)
                resp.headers["Content-Length"] = str(len(resp.get_data()))
            return resp
        except Exception:
            return resp
except Exception:
    pass
# ---- end VSP_P1_HTML_NETGUARD_P1_V7B ----

# VSP_P1_HTML_NETGUARD_P1_V7C_MW
# ---- VSP_P1_HTML_NETGUARD_P1_V7C_MW (wrap WSGI application; always inject on /vsp5) ----
try:
    import re as _re
except Exception:
    _re = None

_VSP_P1_NETGUARD_HTML_V7C = r"""
<!-- VSP_P1_NETGUARD_GLOBAL_V7C -->
<script id="VSP_P1_NETGUARD_GLOBAL_V7C">
(()=> {
  if (window.__vsp_p1_netguard_global_v7c) return;
  window.__vsp_p1_netguard_global_v7c = true;

  

  // VSP_P1_LOAD_FILLREAL_FROM_NETGUARD_P1_V2
  try{
    if (!window.__vsp_fillreal_loader_from_netguard_p1_v2){
      window.__vsp_fillreal_loader_from_netguard_p1_v2 = true;
      var _s=document.createElement("script");
      _s.src="/static/js/vsp_fill_real_data_5tabs_p1_v1.js";
      _s.defer=true;
      (document.head||document.documentElement).appendChild(_s);
    }
  }catch(_){}
const HOLD_MS = 15000;
  let holdUntil = Date.now() + 2500;

  const DROP = [
    /\[VSP\]\s*poll down; backoff/i,
    /poll down; backoff/i,
    /runs fetch guard\/backoff enabled/i,
    /VSP_ROUTE_GUARD_RUNS_ONLY_/i
  ];
  function _dropArgs(args){
    try{
      if (!args || !args.length) return false;
      const a0 = (typeof args[0] === "string") ? args[0] : "";
      return DROP.some(rx => rx.test(a0));
    }catch(_){ return false; }
  }
  if (!window.__vsp_console_filtered_v7c){
    window.__vsp_console_filtered_v7c = true;
    for (const k of ["log","info","warn","error"]){
      const orig = console[k].bind(console);
      console[k] = (...args)=>{ if (_dropArgs(args)) return; return orig(...args); };
    }
  }

  function _isApiVsp(u){ return !!u && u.includes("/api/vsp/"); }
  function _isPlaceholder(u){ return !!u && (u === "<URL>" || u.includes("<URL>")); }

  function _cacheKey(u){
    try{
      const uu = new URL(u, location.origin);
      return "vsp_api_cache_v7c::" + uu.pathname + uu.search;
    }catch(_){
      return "vsp_api_cache_v7c::" + String(u);
    }
  }
  function _load(u){ try{ const raw=localStorage.getItem(_cacheKey(u)); return raw?JSON.parse(raw):null; }catch(_){ return null; } }
  function _save(u,obj){ try{ localStorage.setItem(_cacheKey(u), JSON.stringify(obj)); }catch(_){ } }
  function _resp(obj,hdr){
    const h = new Headers({"Content-Type":"application/json; charset=utf-8"});
    try{ if (hdr) for (const [k,v] of Object.entries(hdr)) h.set(k, String(v)); }catch(_){}
    return new Response(JSON.stringify(obj), {status:200, headers:h});
  }

  if (window.fetch && !window.__vsp_fetch_wrapped_v7c){
    window.__vsp_fetch_wrapped_v7c = true;
    const orig = window.fetch.bind(window);
    window.fetch = async (input, init)=>{
      let u="";
      try{ u = (typeof input==="string") ? input : (input && input.url) ? input.url : ""; }catch(_){}
      if (_isPlaceholder(u)) return _resp({ok:false, note:"intercepted <URL>", marker:"V7C"}, {"X-VSP-Intercept":"1"});
      if (_isApiVsp(u)){
        const now = Date.now();
        if (now < holdUntil){
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1"});
        }
        try{
          const r = await orig(input, init);
          if (r && r.ok){
            try{ const j = await r.clone().json(); if (j && typeof j==="object") _save(u,j); }catch(_){}
            return r;
          }
          holdUntil = Date.now() + HOLD_MS;
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1","X-VSP-Non200": r ? r.status : "NA"});
        }catch(_e){
          holdUntil = Date.now() + HOLD_MS;
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1","X-VSP-NetFail":"1"});
        }
      }
      return orig(input, init);
    };
  }

  if (window.XMLHttpRequest && !window.__vsp_xhr_wrapped_v7c){
    window.__vsp_xhr_wrapped_v7c = true;
    const _open = XMLHttpRequest.prototype.open;
    const _send = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(method, url){
      try{ this.__vsp_url = String(url || ""); }catch(_){}
      return _open.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function(body){
      const u = (this && this.__vsp_url) ? String(this.__vsp_url) : "";
      if (_isPlaceholder(u) || _isApiVsp(u)){
        const now = Date.now();
        if (_isPlaceholder(u) || (now < holdUntil && _isApiVsp(u))){
          const cached = _isPlaceholder(u) ? {ok:false, note:"intercepted <URL>", marker:"V7C"} : (_load(u) || {ok:false, note:"degraded-cache-empty"});
          const txt = JSON.stringify(cached);
          try{
            Object.defineProperty(this, "status", { get: ()=>200, configurable:true });
            Object.defineProperty(this, "responseText", { get: ()=>txt, configurable:true });
            Object.defineProperty(this, "response", { get: ()=>txt, configurable:true });
          }catch(_){}
          const self=this;
          setTimeout(()=>{
            try{ if (typeof self.onreadystatechange==="function") self.onreadystatechange(); }catch(_){}
            try{ if (typeof self.onload==="function") self.onload(); }catch(_){}
            try{ self.dispatchEvent && self.dispatchEvent(new Event("load")); }catch(_){}
          },0);
          return;
        }
      }
      return _send.apply(this, arguments);
    };
  }
})();
</script>
"""

def _vsp_p1_inject_head_v7c(body_bytes: bytes) -> bytes:
    if _re is None:
        return body_bytes
    try:
        html = body_bytes.decode("utf-8", errors="replace")
    except Exception:
        return body_bytes
    if "VSP_P1_NETGUARD_GLOBAL_V7C" in html:
        return body_bytes
    m = _re.search(r"<head[^>]*>", html, flags=_re.I)
    if not m:
        return body_bytes
    ins = m.end()
    html2 = html[:ins] + "\n" + _VSP_P1_NETGUARD_HTML_V7C + "\n" + html[ins:]
    return html2.encode("utf-8", errors="replace")

class _VSP_HTML_Injector_V7C:
    __vsp_wrapped_v7c__ = True
    def __init__(self, app):
        self.app = app
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path not in ("/vsp5", "/vsp5/"):
            return self.app(environ, start_response)

        captured = {}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            captured["exc_info"] = exc_info
            # delay calling real start_response until body possibly modified
            return None

        result = self.app(environ, _sr)
        try:
            body = b"".join(result) if result is not None else b""
        finally:
            try:
                if hasattr(result, "close"):
                    result.close()
            except Exception:
                pass

        status = captured.get("status", "200 OK")
        headers = captured.get("headers", [])

        # check content-type
        ct = ""
        for k, v in headers:
            if str(k).lower() == "content-type":
                ct = str(v)
                break

        if "text/html" in (ct or ""):
            body2 = _vsp_p1_inject_head_v7c(body)
            if body2 != body:
                body = body2
                # fix content-length
                new_headers = []
                for k, v in headers:
                    if str(k).lower() == "content-length":
                        continue
                    new_headers.append((k, v))
                new_headers.append(("Content-Length", str(len(body))))
                headers = new_headers

        start_response(status, headers, captured.get("exc_info"))
        return [body]

try:
    if not getattr(application, "__vsp_wrapped_v7c__", False):
        application = _VSP_HTML_Injector_V7C(application)
except Exception:
    pass
# ---- end VSP_P1_HTML_NETGUARD_P1_V7C_MW ----



# VSP_P1_ROOT_AND_DATASOURCE_ROUTES_V1
# P1: ensure Dashboard (/) and Data Source (/data_source) pages are reachable on UI gateway.
try:
    from flask import render_template
except Exception:
    render_template = None

try:
    app  # noqa
except Exception:
    app = None

if app is not None and render_template is not None:
    @app.get("/")
    def vsp_root_dashboard_p1():
        return render_template("vsp_dashboard_2025.html")

    @app.get("/data_source")
    def vsp_data_source_p1():
        return render_template("vsp_data_source_v1.html")


# VSP_P1_ROOT_AND_DATASOURCE_ROUTES_V2
# P1: ensure Dashboard (/) and Data Source (/data_source) reachable on UI gateway.
try:
    from flask import render_template
except Exception:
    render_template = None

_candidates = []
for _name in ("application", "app"):
    try:
        _obj = globals().get(_name, None)
        if _obj is not None:
            _candidates.append(_obj)
    except Exception:
        pass

def _p1_rt_dashboard():
    return render_template("vsp_dashboard_2025.html")

def _p1_rt_data_source():
    return render_template("vsp_data_source_v1.html")

if render_template is not None:
    for _a in _candidates:
        try:
            # only add if not already present
            _a.add_url_rule("/", endpoint="vsp_p1_root_dashboard_v2", view_func=_p1_rt_dashboard, methods=["GET"])
        except Exception:
            pass
        try:
            _a.add_url_rule("/data_source", endpoint="vsp_p1_data_source_v2", view_func=_p1_rt_data_source, methods=["GET"])
        except Exception:
            pass


# VSP_P1_SETTINGS_BOOT_INJECT_MW_V1
# P1: /settings page is served by custom HTML; inject boot script tag if missing.
try:
    from flask import request
except Exception:
    request = None

def _vsp_p1_inject_boot(resp):
    try:
        if request is None:
            return resp
        if not request.path.startswith("/settings"):
            return resp
        ct = (resp.headers.get("Content-Type","") or "").lower()
        if "text/html" not in ct:
            return resp

        data = resp.get_data(as_text=True)
        if "vsp_p1_page_boot_v1.js" in data:
            return resp

        tag = '<script src="/static/js/vsp_p1_page_boot_v1.js?v=VSP_P1_PAGE_BOOT_V1"></script>'
        if "</body>" in data.lower():
            # insert before </body> (case-insensitive)
            idx = data.lower().rfind("</body>")
            data = data[:idx] + "\n" + tag + "\n" + data[idx:]
        else:
            data = data + "\n" + tag + "\n"

        resp.set_data(data)
        # length may change
        try:
            resp.headers.pop("Content-Length", None)
        except Exception:
            pass
        return resp
    except Exception:
        return resp

for _name in ("application","app"):
    try:
        _a = globals().get(_name)
        if _a is not None:
            try:
                _a.after_request(_vsp_p1_inject_boot)
            except Exception:
                pass
    except Exception:
        pass


# VSP_P1_FORCE_ROOT_200_OVERRIDE_REDIRECT_V4
# Ensure '/' returns 200 HTML (dashboard) even if existing route redirects to /vsp4
try:
    from flask import render_template, redirect
except Exception:
    render_template = None
    redirect = None

def _vsp_p1_root_200_v4():
    # Prefer dashboard template if exists; fallback to redirect /vsp5
    if render_template is not None:
        try:
            return render_template("vsp_dashboard_2025.html")
        except Exception:
            pass
        try:
            return render_template("vsp_5tabs_enterprise_v2.html")
        except Exception:
            pass
    if redirect is not None:
        return redirect("/vsp5")
    return ("OK", 200)

for _name in ("application","app"):
    try:
        _a = globals().get(_name)
        if _a is None:
            continue
        # Override any existing endpoint mapped to '/'
        try:
            _over = 0
            for _r in list(_a.url_map.iter_rules()):
                if getattr(_r, "rule", None) == "/" and getattr(_r, "endpoint", "") != "static":
                    try:
                        _a.view_functions[_r.endpoint] = _vsp_p1_root_200_v4
                        _over += 1
                    except Exception:
                        pass
            if _over == 0:
                try:
                    _a.add_url_rule("/", endpoint="vsp_p1_root_200_v4", view_func=_vsp_p1_root_200_v4, methods=["GET"])
                except Exception:
                    pass
        except Exception:
            pass
    except Exception:
        pass


# === VSP_GATEWAY_INJECT_FILLREAL_ALLHTML_P1_V1 ===
try:
    _vsp_app = app  # Flask app name commonly "app"
except Exception:
    _vsp_app = None

if _vsp_app is not None:
    @_vsp_app.after_request
    def _vsp_p1_inject_fillreal_all_html(resp):
        try:
            ct = (resp.headers.get("Content-Type") or "").lower()
            if "text/html" not in ct:
                return resp
            # avoid streaming / passthrough
            if getattr(resp, "direct_passthrough", False):
                return resp

            b = resp.get_data()
            if not b:
                return resp
            html = b.decode("utf-8", errors="replace")

            # already injected?
            if "vsp_fill_real_data_5tabs_p1_v1.js" in html or "VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY" in html:
                return resp

            tag = (
                "\n<!-- VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                "<script src='/static/js/vsp_fill_real_data_5tabs_p1_v1.js'></script>\n"
                "<!-- /VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
            )

            if "</body>" in html:
                html = html.replace("</body>", tag + "</body>")
            elif "</html>" in html:
                html = html.replace("</html>", tag + "</html>")
            else:
                html = html + tag

            resp.set_data(html.encode("utf-8"))
            # Content-Length must be recalculated
            try:
                resp.headers.pop("Content-Length", None)
            except Exception:
                pass
            return resp
        except Exception:
            return resp
# === /VSP_GATEWAY_INJECT_FILLREAL_ALLHTML_P1_V1 ===



# === VSP_GATEWAY_WRAP_APPLICATION_WITH_FILLREAL_P1_V3 ===
try:
    _vsp_inner = globals().get("application") or globals().get("app")
    if _vsp_inner is not None and not isinstance(_vsp_inner, _VspHtmlInjectMw):
        application = _VspHtmlInjectMw(_vsp_inner)
except Exception:
    pass
# === /VSP_GATEWAY_WRAP_APPLICATION_WITH_FILLREAL_P1_V3 ===



# === VSP_GATEWAY_FORCE_FILLREAL_TAIL_P1_V4 ===
try:
    # FORCE LAST WRAP: must be after all other `application = ...` wrappers
    application = _VspHtmlInjectMw(application)
except Exception:
    pass
# === /VSP_GATEWAY_FORCE_FILLREAL_TAIL_P1_V4 ===




# === VSP_GATEWAY_FILLREAL_PROBE_HEADER_P1_V5 ===
import re as _re

class _VspFillRealProbeMWP1V5:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        captured = {"status": None, "headers": None, "exc": None}

        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers) if headers else []
            captured["exc"] = exc_info
            # return write callable
            def _write(_data): return None
            return _write

        app_iter = self.app(environ, _sr)

        try:
            chunks=[]
            for c in app_iter:
                if c:
                    chunks.append(c)
            body = b"".join(chunks)
        finally:
            try:
                close=getattr(app_iter,"close",None)
                if callable(close): close()
            except Exception:
                pass

        headers = captured["headers"] or []
        # always add probe header
        headers = [(k,v) for (k,v) in headers if str(k).lower() != "x-vsp-fillreal"]
        headers.append(("X-VSP-FILLREAL", "P1_V5"))

        # sniff headers
        ct = ""
        ce = ""
        for (k,v) in headers:
            lk = str(k).lower()
            if lk == "content-type": ct = str(v).lower()
            if lk == "content-encoding": ce = str(v).lower()

        # only inject into plain html (skip gzip/br)
        if "text/html" in ct and body and (not ce or ("gzip" not in ce and "br" not in ce)):
            try:
                html = body.decode("utf-8", errors="replace")
                if ("vsp_fill_real_data_5tabs_p1_v1.js" not in html) and ("VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY" not in html):
                    tag = (
                        "\n<!-- VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                        "<script src='/static/js/vsp_fill_real_data_5tabs_p1_v1.js'></script>\n"
                        "<!-- /VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                    )
                    # case-insensitive insert before </body> or </html>
                    if _re.search(r"</body\s*>", html, flags=_re.I):
                        html = _re.sub(r"</body\s*>", tag + "</body>", html, count=1, flags=_re.I)
                    elif _re.search(r"</html\s*>", html, flags=_re.I):
                        html = _re.sub(r"</html\s*>", tag + "</html>", html, count=1, flags=_re.I)
                    else:
                        html = html + tag
                    body = html.encode("utf-8")

                    # fix content-length
                    headers = [(k,v) for (k,v) in headers if str(k).lower() != "content-length"]
                    headers.append(("Content-Length", str(len(body))))
            except Exception:
                pass

        start_response(captured["status"] or "200 OK", headers, captured["exc"])
        return [body]
# === /VSP_GATEWAY_FILLREAL_PROBE_HEADER_P1_V5 ===

# force last wrap
try:
    application = _VspFillRealProbeMWP1V5(application)
except Exception:
    pass




# === VSP_P1_FORCE_DEFAULT_VSP5_P1_V1 ===
def _vsp_force_default_to_vsp5(environ, start_response, app=application):
    try:
        path = (environ.get("PATH_INFO") or "")
        if path == "/" or path == "":
            start_response("302 FOUND", [("Location","/vsp5")])
            return [b""]
    except Exception:
        pass
    return app(environ, start_response)

try:
    application = _vsp_force_default_to_vsp5
except Exception:
    pass
# === /VSP_P1_FORCE_DEFAULT_VSP5_P1_V1 ===




# === VSP_P1_RUNS_503_FALLBACK_MW_P1_V1 ===
import json as _json
from pathlib import Path as _Path
import time as _time
import urllib.parse as _urlparse

class _VspRuns503FallbackMWP1V1:
    def __init__(self, app):
        self.app = app

    def _scan_runs(self, limit=20):
        roots = [
            _Path("/home/test/Data/SECURITY_BUNDLE/out"),
            _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
            _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        ]
        dirs=[]
        for r in roots:
            try:
                if not r.exists(): 
                    continue
                for d in r.iterdir():
                    if not d.is_dir(): 
                        continue
                    name=d.name
                    if "RUN_" not in name:
                        continue
                    try:
                        mt = d.stat().st_mtime
                    except Exception:
                        mt = 0
                    dirs.append((mt, name))
            except Exception:
                pass
        dirs.sort(reverse=True)
        items=[]
        for mt, name in dirs[:max(1,int(limit))]:
            items.append({
                "run_id": name,
                "mtime": mt,
                "has": {"csv": False, "html": False, "json": False, "sarif": False, "summary": False}
            })
        return items

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/runs"):
            return self.app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers) if headers else []
            captured["exc"] = exc_info
            def _write(_data): return None
            return _write

        try:
            it = self.app(environ, _sr)
            chunks=[]
            try:
                for c in it:
                    if c: chunks.append(c)
            finally:
                try:
                    close=getattr(it,"close",None)
                    if callable(close): close()
                except Exception:
                    pass
            body = b"".join(chunks)
            code = 200
            try:
                code = int((captured["status"] or "200").split()[0])
            except Exception:
                code = 200

            # if downstream OK -> return as-is
            if code < 500:
                start_response(captured["status"] or "200 OK", captured["headers"] or [], captured["exc"])
                return [body]

        except Exception:
            code = 503

        # FALLBACK JSON 200
        try:
            qs = (environ.get("QUERY_STRING") or "")
            q = _urlparse.parse_qs(qs)
            limit = int((q.get("limit") or [20])[0])
        except Exception:
            limit = 20

        items = self._scan_runs(limit=limit)
        payload = {
            "ok": True,
            "fallback": True,
            "items": items,
            "limit": limit,
            "error": "downstream /api/vsp/runs failed (>=500), served fallback list"
        }
        out = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
        hdrs = [("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(out))),
                ("Cache-Control","no-cache"),
                ("X-VSP-RUNS-FALLBACK","1")]
        start_response("200 OK", hdrs)
        return [out]

# wrap last
# VSP_P1_RUNS_CACHE_MW_V2
import json as _json, os as _os, time as _time, re as _re
from pathlib import Path as _Path

class _VspRunsCacheMW:
    def __init__(self, app):
        self.app = app
        self.ttl = float(_os.environ.get("VSP_RUNS_CACHE_TTL", "3"))
        self.limit_cap = int(_os.environ.get("VSP_RUNS_LIMIT_CAP", "10"))
        self.scan_cap = int(_os.environ.get("VSP_RUNS_SCAN_CAP", "500"))
        self._cache = {"ts": 0.0, "key": "", "payload": None}
        self._run_re = _re.compile(_os.environ.get("VSP_RUNS_DIR_REGEX", r"^(RUN_|AATE_|VSP_|btl).*"))

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path != "/api/vsp/runs":
            return self.app(environ, start_response)

        qs = (environ.get("QUERY_STRING") or "")
        limit = 5
        for part in qs.split("&"):
            if part.startswith("limit="):
                try: limit = int(part.split("=",1)[1] or "5")
                except Exception: limit = 5
        if limit <= 0: limit = 5
        if limit > self.limit_cap: limit = self.limit_cap

        roots = [
            _Path(_os.environ.get("VSP_RUNS_ROOT","") or "").expanduser(),
            _Path("/home/test/Data/SECURITY_BUNDLE/out"),
            _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        ]
        roots = [r for r in roots if str(r).strip() and r.is_dir()]

        key = "|".join(map(str,roots)) + f"|limit={limit}"
        now = _time.time()
        c = self._cache

        if c["payload"] is not None and c["key"] == key and (now - c["ts"]) < self.ttl:
            payload = c["payload"]
        else:
            items, seen, scanned = [], set(), 0
            for base in roots:
                for d in base.iterdir():
                    if scanned >= self.scan_cap: break
                    scanned += 1
                    if not d.is_dir(): continue
                    rid = d.name
                    if rid in seen: continue
                    if not self._run_re.match(rid): continue
                    seen.add(rid)

                    reports = d / "reports"
                    item = {
                        "run_id": rid,
                        "run_dir_resolved": str(d),
                        "has": {
                            "html": (reports/"index.html").is_file(),
                            "summary": (reports/"run_gate_summary.json").is_file(),
                            "json": (reports/"findings_unified.json").is_file(),
                            "csv": (reports/"findings_unified.csv").is_file(),
                            "sarif": False,
                        }
                    }
                    try: item["_mtime"] = d.stat().st_mtime
                    except Exception: item["_mtime"] = 0
                    items.append(item)

            items.sort(key=lambda x: x.get("_mtime",0), reverse=True)
            for it in items: it.pop("_mtime", None)
            payload = {"ok": True, "limit": limit, "_scanned": scanned, "items": items[:limit]}
            c["ts"], c["key"], c["payload"] = now, key, payload

        body = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
        start_response("200 OK", [
            ("Content-Type","application/json; charset=utf-8"),
            ("Content-Length", str(len(body))),
            ("Cache-Control","no-store"),
        ])
        return [body]
# /VSP_P1_RUNS_CACHE_MW_V2

_VSP_APP_INNER = _VspRuns503FallbackMWP1V1(application)
application = _VspRunsCacheMW(_VSP_APP_INNER)

try:  # VSP_AUTOFIX_ORPHAN_EXCEPT
    pass
except Exception:
    pass
# === /VSP_P1_RUNS_503_FALLBACK_MW_P1_V1 ===


# ==== VSP_P1_RUNS_CONTRACT_EOF_V6B ====
# P1 commercial: guarantee /api/vsp/runs contains contract fields + at least 1 RID (fallback scan).
def _vsp_runs_contract_after_request_v6b(resp):
    try:
        from flask import request as _req
        if (_req.path or "") != "/api/vsp/runs":
            return resp

        mt = (getattr(resp, "mimetype", "") or "")
        if "json" not in mt:
            return resp

        try:
            resp.direct_passthrough = False
        except Exception:
            pass

        import json as _json, os as _os
        from pathlib import Path as _P

        raw = resp.get_data()
        txt = raw.decode("utf-8", "replace") if isinstance(raw, (bytes, bytearray)) else str(raw)
        data = _json.loads(txt) if txt.strip() else {}
        if not isinstance(data, dict) or data.get("ok") is not True:
            return resp

        items = data.get("items") or []
        if not isinstance(items, list):
            items = []
            data["items"] = items

        # effective limit = requested (cap)
        try:
            lim_req = int((_req.args.get("limit") or "50").strip())
        except Exception:
            lim_req = 50
        hard_cap = 120
        lim_eff = max(1, min(lim_req, hard_cap))
        data["limit"] = lim_eff

        # roots used (prefer env; else known defaults)
        roots = []
        env_roots = (_os.environ.get("VSP_RUNS_ROOTS") or "").strip()
        if env_roots:
            roots = [x.strip() for x in env_roots.split(":") if x.strip()]
        else:
            roots = ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci"]
        data["roots_used"] = roots

        # If items empty: fallback scan to populate recent runs (lightweight)
        if not items:
            runs = []
            for r in roots:
                rp = _P(r)
                if not rp.exists():
                    continue
                for pat in ("RUN_*", "*_RUN_*"):
                    for d in rp.glob(pat):
                        if d.is_dir():
                            try:
                                runs.append((d.stat().st_mtime, d))
                            except Exception:
                                pass
            runs.sort(key=lambda x: x[0], reverse=True)
            take = min(len(runs), lim_eff)
            if take > 0:
                new_items = []
                for _, d in runs[:take]:
                    rid = d.name
                    rep = d / "reports"
                    has = {
                        "csv": (rep / "findings_unified.csv").exists(),
                        "html": (rep / "checkmarx_like.html").exists(),
                        "json": (rep / "findings_unified.json").exists() or (d / "findings_unified.json").exists(),
                        "sarif": (rep / "findings_unified.sarif").exists() or (d / "findings_unified.sarif").exists(),
                        "summary": (rep / "run_gate_summary.json").exists() or (d / "run_gate_summary.json").exists(),
                    }
                    new_items.append({"run_id": rid, "has": has})
                data["items"] = new_items
                items = new_items

        # rid_latest
        rid_latest = ""
        if items:
            try:
                rid_latest = (items[0].get("run_id") or items[0].get("rid") or "").strip()
            except Exception:
                rid_latest = ""
        data["rid_latest"] = rid_latest

        # cache ttl
        try:
            data["cache_ttl"] = int(_os.environ.get("VSP_RUNS_CACHE_TTL", "2"))
        except Exception:
            data["cache_ttl"] = 2

        # scan cap hit (from _scanned)
        try:
            scanned = int(data.get("_scanned") or 0)
        except Exception:
            scanned = 0
        scan_cap = int(_os.environ.get("VSP_RUNS_SCAN_CAP", "500"))
        data["scan_cap"] = scan_cap
        data["scan_cap_hit"] = bool(scanned >= scan_cap)

        out = _json.dumps(data, ensure_ascii=False)
        resp.set_data(out.encode("utf-8"))
        resp.headers["Content-Length"] = str(len(resp.get_data()))
        resp.headers["X-VSP-RUNS-CONTRACT"] = "P1_V6B"
        return resp
    except Exception:
        return resp

try:
    application.after_request(_vsp_runs_contract_after_request_v6b)
except Exception:
    pass
# ==== /VSP_P1_RUNS_CONTRACT_EOF_V6B ====


# ==== VSP_P1_RUNS_CONTRACT_WSGIMW_V2 ====
# P1 commercial: WSGI middleware that rewrites /api/vsp/runs response at the LAST layer.
def _vsp__parse_qs_limit(environ, default=50, hard_cap=120):
    try:
        qs = environ.get("QUERY_STRING") or ""
        for part in qs.split("&"):
            if part.startswith("limit="):
                v = part.split("=",1)[1]
                n = int(v.strip() or default)
                return max(1, min(n, hard_cap))
    except Exception:
        pass
    return max(1, min(default, hard_cap))

def _vsp__list_latest_runs_cached(roots, limit, ttl=2):
    import time, os
    from pathlib import Path as _P
    now = time.time()
    cache = getattr(_vsp__list_latest_runs_cached, "_cache", None) or {}
    key = "|".join(roots) + ":" + str(limit)
    ent = cache.get(key)
    if ent and (now - ent["ts"] <= ttl):
        return ent["items"]

    runs = []
    for r in roots:
        try:
            rp = _P(r)
            if not rp.exists():
                continue
            with os.scandir(rp) as it:
                for de in it:
                    if not de.is_dir():
                        continue
                    nm = de.name
                    if nm.startswith("RUN_") or "_RUN_" in nm:
                        try:
                            st = de.stat()
                            runs.append((st.st_mtime, _P(de.path)))
                        except Exception:
                            pass
        except Exception:
            continue

    runs.sort(key=lambda x: x[0], reverse=True)
    take = min(len(runs), limit)
    items=[]
    for _, d in runs[:take]:
        rid = d.name
        rep = d / "reports"
        has = {
            "csv": (rep / "findings_unified.csv").exists(),
            "html": (rep / "checkmarx_like.html").exists(),
            "json": (rep / "findings_unified.json").exists() or (d / "findings_unified.json").exists(),
            "sarif": (rep / "findings_unified.sarif").exists() or (d / "findings_unified.sarif").exists(),
            "summary": (rep / "run_gate_summary.json").exists() or (d / "run_gate_summary.json").exists(),
        }
        items.append({"run_id": rid, "has": has})
    cache[key] = {"ts": now, "items": items}
    setattr(_vsp__list_latest_runs_cached, "_cache", cache)
    return items

class _VSPRunsContractWSGIMW:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO") or ""
        if path != "/api/vsp/runs":
            return self.app(environ, start_response)

        captured = {"status": None, "headers": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            return None

        body_iter = self.app(environ, _sr)
        try:
            body = b"".join(body_iter)
        except Exception:
            return self.app(environ, start_response)

        status = captured["status"] or "200 OK"
        headers = captured["headers"] or []

        try:
            code = int(status.split()[0])
        except Exception:
            code = 200

        ct = ""
        for k,v in headers:
            if k.lower() == "content-type":
                ct = v
                break

        if code != 200 or ("json" not in (ct or "")):
            start_response(status, headers)
            return [body]

        try:
            import json, os
            data = json.loads(body.decode("utf-8","replace"))
            if not (isinstance(data, dict) and data.get("ok") is True and isinstance(data.get("items"), list)):
                start_response(status, headers)
                return [body]

            lim_eff = _vsp__parse_qs_limit(environ, default=int(data.get("limit") or 50))
            data["limit"] = lim_eff

            env_roots = (os.environ.get("VSP_RUNS_ROOTS") or "").strip()
            if env_roots:
                roots = [x.strip() for x in env_roots.split(":") if x.strip()]
            else:
                roots = ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci"]
            data["roots_used"] = roots

            items = data.get("items") or []
            if not items:
                items = _vsp__list_latest_runs_cached(roots, lim_eff, ttl=int(os.environ.get("VSP_RUNS_CACHE_TTL","2")))
                data["items"] = items

            rid_latest = ""
            if items:
                try:
                    rid_latest = (items[0].get("run_id") or items[0].get("rid") or "").strip()
                except Exception:
                    rid_latest = ""
            data["rid_latest"] = rid_latest

            try:
                data["cache_ttl"] = int(os.environ.get("VSP_RUNS_CACHE_TTL","2"))
            except Exception:
                data["cache_ttl"] = 2

            try:
                scanned = int(data.get("_scanned") or 0)
            except Exception:
                scanned = 0
            scan_cap = int(os.environ.get("VSP_RUNS_SCAN_CAP","500"))
            data["scan_cap"] = scan_cap
            data["scan_cap_hit"] = bool(scanned >= scan_cap)

            out = json.dumps(data, ensure_ascii=False).encode("utf-8")

            new_headers=[]
            for k,v in headers:
                if k.lower() == "content-length":
                    continue
                new_headers.append((k,v))
            new_headers.append(("Content-Length", str(len(out))))
            new_headers.append(("X-VSP-RUNS-CONTRACT", "P1_WSGI_V2"))

            start_response(status, new_headers)
            return [out]
        except Exception:
            start_response(status, headers)
            return [body]

try:
    if "application" in globals() and not getattr(application, "__vsp_runs_contract_wrapped__", False):
        application = _VSPRunsContractWSGIMW(application)
        try:
            application.__vsp_runs_contract_wrapped__ = True
        except Exception:
            pass
except Exception:
    pass
# ==== /VSP_P1_RUNS_CONTRACT_WSGIMW_V2 ====


# ==== VSP_P1_SHA256_FALLBACK_V1 ====
def _vsp__sha256_hex(path):
    import hashlib
    h=hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _vsp__qs_get(environ, key):
    qs = environ.get("QUERY_STRING") or ""
    for part in qs.split("&"):
        if part.startswith(key + "="):
            return part.split("=",1)[1]
    return ""

def _vsp__safe_unquote(s):
    try:
        from urllib.parse import unquote_plus
        return unquote_plus(s)
    except Exception:
        return s

class _VSPSha256FallbackWSGIMW:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO") or ""
        if path != "/api/vsp/sha256":
            return self.app(environ, start_response)

        # Let downstream handler try first; if it returns 404, we attempt fallback.
        captured = {"status": None, "headers": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            return None

        body_iter = self.app(environ, _sr)
        try:
            body = b"".join(body_iter)
        except Exception:
            return self.app(environ, start_response)

        status = captured["status"] or "200 OK"
        headers = captured["headers"] or []
        try:
            code = int(status.split()[0])
        except Exception:
            code = 200

        if code != 404:
            start_response(status, headers)
            return [body]

        # fallback compute sha256 if possible
        import os
        from pathlib import Path as _P

        rid = _vsp__safe_unquote(_vsp__qs_get(environ, "rid"))
        name = _vsp__safe_unquote(_vsp__qs_get(environ, "name"))

        # basic guard
        if not rid or not name:
            start_response(status, headers)
            return [body]

        # candidate names
        cands = [name]
        # common fallbacks: reports/x -> x
        if name.startswith("reports/"):
            cands.append(name[len("reports/"):])

        # try to resolve within known roots used by runs listing
        roots = []
        env_roots = (os.environ.get("VSP_RUNS_ROOTS") or "").strip()
        if env_roots:
            roots = [x.strip() for x in env_roots.split(":") if x.strip()]
        else:
            roots = ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci"]

        found = None
        found_rel = None
        for r in roots:
            base = _P(r) / rid
            if not base.exists():
                continue
            for rel in cands:
                fp = base / rel
                if fp.exists() and fp.is_file():
                    found = fp
                    found_rel = rel
                    break
            if found:
                break

        if not found:
            start_response(status, headers)
            return [body]

        try:
            digest = _vsp__sha256_hex(str(found))
            import json
            out = json.dumps({"ok": True, "rid": rid, "name": name, "resolved": found_rel, "sha256": digest}, ensure_ascii=False).encode("utf-8")
            new_headers=[]
            for k,v in headers:
                if k.lower() in ("content-length","content-type"):
                    continue
                new_headers.append((k,v))
            new_headers.append(("Content-Type","application/json; charset=utf-8"))
            new_headers.append(("Content-Length", str(len(out))))
            new_headers.append(("X-VSP-SHA256-FALLBACK", found_rel or ""))
            start_response("200 OK", new_headers)
            return [out]
        except Exception:
            start_response(status, headers)
            return [body]

try:
    if "application" in globals() and not getattr(application, "__vsp_sha256_fallback_wrapped__", False):
        application = _VSPSha256FallbackWSGIMW(application)
        try:
            application.__vsp_sha256_fallback_wrapped__ = True
        except Exception:
            pass
except Exception:
    pass
# ==== /VSP_P1_SHA256_FALLBACK_V1 ====


# ==== VSP_P1_SHA256_ALWAYS200_WSGIMW_V2 ====
def _vsp__sha256_hex(path):
    import hashlib
    h=hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _vsp__qs_get(environ, key):
    qs = environ.get("QUERY_STRING") or ""
    for part in qs.split("&"):
        if part.startswith(key + "="):
            return part.split("=",1)[1]
    return ""

def _vsp__unq(s):
    try:
        from urllib.parse import unquote_plus
        return unquote_plus(s)
    except Exception:
        return s

def _vsp__is_safe_rel(rel):
    # prevent path traversal
    if not rel or rel.startswith("/") or rel.startswith("\\"):
        return False
    if ".." in rel.replace("\\","/").split("/"):
        return False
    return True

class _VSPSha256Always200WSGIMW:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO") or ""
        if path not in ("/api/vsp/sha256", "/api/vsp/sha256/"):
            return self.app(environ, start_response)

        import os, json
        from pathlib import Path as _P

        rid  = _vsp__unq(_vsp__qs_get(environ, "rid"))
        name = _vsp__unq(_vsp__qs_get(environ, "name"))

        # default response (degraded)
        resp = {"ok": False, "rid": rid, "name": name, "missing": True, "resolved": None, "sha256": None}

        # resolve roots
        env_roots = (os.environ.get("VSP_RUNS_ROOTS") or "").strip()
        roots = [x.strip() for x in env_roots.split(":") if x.strip()] if env_roots else [
            "/home/test/Data/SECURITY_BUNDLE/out",
            "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        ]

        # candidate relative paths (fallbacks)
        cands = []
        if name and _vsp__is_safe_rel(name):
            cands.append(name)
            if name.startswith("reports/"):
                alt = name[len("reports/"):]
                if _vsp__is_safe_rel(alt):
                    cands.append(alt)

        found = None
        found_rel = None
        if rid and cands:
            for r in roots:
                base = _P(r) / rid
                if not base.exists():
                    continue
                for rel in cands:
                    fp = base / rel
                    if fp.exists() and fp.is_file():
                        found = fp
                        found_rel = rel
                        break
                if found:
                    break

        if found:
            try:
                resp["ok"] = True
                resp["missing"] = False
                resp["resolved"] = found_rel
                resp["sha256"] = _vsp__sha256_hex(str(found))
            except Exception:
                resp["ok"] = False
                resp["missing"] = True

        out = json.dumps(resp, ensure_ascii=False).encode("utf-8")
        headers = [
            ("Content-Type","application/json; charset=utf-8"),
            ("Content-Length", str(len(out))),
            ("X-VSP-SHA256", "P1_WSGI_V2"),
        ]
        if resp.get("missing"):
            headers.append(("X-VSP-DEGRADED", "sha256_missing_artifact"))
        else:
            headers.append(("X-VSP-SHA256-RESOLVED", resp.get("resolved") or ""))

        start_response("200 OK", headers)
        return [out]

try:
    if "application" in globals() and not getattr(application, "__vsp_sha256_always200_wrapped__", False):
        application = _VSPSha256Always200WSGIMW(application)
        try:
            application.__vsp_sha256_always200_wrapped__ = True
        except Exception:
            pass
except Exception:
    pass
# ==== /VSP_P1_SHA256_ALWAYS200_WSGIMW_V2 ====

