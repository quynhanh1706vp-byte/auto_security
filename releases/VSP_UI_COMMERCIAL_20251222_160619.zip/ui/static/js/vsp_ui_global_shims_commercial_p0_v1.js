// VSP_SAFE_DRILLDOWN_HARDEN_P0_V6
/* VSP_FORCE_ASSET_VERSION_P0_V2
 * Force cache-bust for dynamically injected /static/js/*.js scripts.
 */
(function(){
  'use strict';
  if (window.__VSP_FORCE_ASSET_VERSION_P0_V2) return;
  window.__VSP_FORCE_ASSET_VERSION_P0_V2=1;

  function ver(){
    return (window.__VSP_ASSET_V || window.VSP_ASSET_V || '20251217_142944');
  }
  function rewrite(u){
    try {
      if(!u) return u;
      if(u.indexOf('/static/js/') === -1) return u;
      // remove any existing v= param
      u = u.replace(/[?&]v=[^&]+/g, '');
      u = u.replace(/[?&]$/, '');
      var sep = (u.indexOf('?') >= 0) ? '&' : '?';
      return u + sep + 'v=' + encodeURIComponent(ver());
    } catch(_e) {
      return u;
    }
  }

  var _append = Element.prototype.appendChild;
  Element.prototype.appendChild = function(node){
    try {
      if(node && node.tagName === 'SCRIPT' && node.src) node.src = rewrite(node.src);
    } catch(_e) {}
    return _append.call(this, node);
  };

  var _setAttr = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function(name, value){
    try {
      if(this && this.tagName === 'SCRIPT' && (name === 'src' || name === 'SRC') && typeof value === 'string') {
        value = rewrite(value);
      }
    } catch(_e) {}
    return _setAttr.call(this, name, value);
  };
})();

/* VSP_UI_GLOBAL_SHIMS_COMMERCIAL_P0_V1
 * 목적: UI 안정화(P0)
 *  - Fix: __VSP_DD_ART_CALL__(VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2, ...) is not a function
 *  - Fetch fallback: run_status_v2 -> run_status_v1 (+ /v1/<rid>)
 *  - Soft-degrade for missing endpoints (never throw to console)
 */
(function(){
  'use strict';
  



/* VSP_FIX_DRILLDOWN_CALLSITE_P0_V5: safe-call drilldown artifacts (function OR object.open) */
function __VSP_DD_ART_CALL__(h, ...args) {
  try {
    if (typeof h === 'function') return h(...args);
    if (h && typeof h.open === 'function') return h.open(...args);
  } catch(e) { try{console.warn('[VSP][DD_SAFE]', e);} catch(_e){} }
  return null;
}

/* VSP_FIX_DRILLDOWN_CALLSITE_P0_V3: safe-call for drilldown artifacts (function OR object.open) */
function __VSP_DD_ART_CALL__(h, ...args) {
  try {
    if (typeof h === 'function') return h(...args);
    if (h && typeof h.open === 'function') return h.open(...args);
  } catch (e) {
    try { console.warn('[VSP][DD_SAFE] call failed', e); } catch (_e) {}
  }
  return null;
}

if (window.__VSP_UI_GLOBAL_SHIMS_COMMERCIAL_P0_V1) return;
  window.__VSP_UI_GLOBAL_SHIMS_COMMERCIAL_P0_V1 = 1;

  // ---- (A) normalize drilldown artifacts callable BEFORE anyone uses it ----
  function normalizeCallable(v){
    if (typeof v === 'function') return v;
    if (v && typeof v.open === 'function') {
      const obj = v;
      const fn = function(arg){
        try { return obj.open(arg); } catch(e){ try{ console.warn('[VSP][DD] open failed', e);} catch(_){} return null; }
      };
      fn.__wrapped_from_object = true;
      return fn;
    }
    const noop = function(_arg){ return null; };
    noop.__noop = true;
    return noop;
  }

  try{
    let _val = window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
    Object.defineProperty(window, 'VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2', {
      configurable: true, enumerable: true,
      get: function(){ return _val; },
      set: function(v){ _val = normalizeCallable(v); }
    });
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = _val;
  } catch(e){
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = normalizeCallable(window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2);
  }

  // ---- (B) fetch fallback (targeted) ----
  const _fetch = window.fetch ? window.fetch.bind(window) : null;

  // VSP_THROTTLE_DASHBOARD_EXTRAS_P0_V2: throttle + cache + cooldown for dashboard extras to avoid spam ERR_NETWORK_CHANGED
  let __vsp_extras_cache_text = '';
  let __vsp_extras_cache_ts = 0;
  let __vsp_extras_last_try = 0;
  let __vsp_extras_last_fail = 0;
  let __vsp_extras_inflight = null;

  function __vsp_resp_json(text, status=200){
    try {
      return new Response(text || '{}', {
        status: status,
        headers: {'content-type':'application/json; charset=utf-8'}
      });
    } catch(_e) {
      // older browsers fallback
      return new Response(text || '{}');
    }
  }

  async function __vsp_fetch_extras_with_cache(url, init){
    const now = Date.now();
    const THROTTLE_MS = 10_000;   // 1 req / 10s
    const COOLDOWN_MS = 30_000;   // after fail, skip 30s
    const CACHE_OK_MS = 120_000;  // serve cache up to 2 min

    // if hidden -> prefer cache (avoid background spam)
    if (document.hidden && (now - __vsp_extras_cache_ts) < CACHE_OK_MS && __vsp_extras_cache_text) {
      return __vsp_resp_json(__vsp_extras_cache_text, 200);
    }

    // cooldown after fail
    if ((now - __vsp_extras_last_fail) < COOLDOWN_MS) {
      if (__vsp_extras_cache_text) return __vsp_resp_json(__vsp_extras_cache_text, 200);
      return __vsp_resp_json('{}', 200);
    }

    // throttle
    if ((now - __vsp_extras_last_try) < THROTTLE_MS) {
      if (__vsp_extras_cache_text) return __vsp_resp_json(__vsp_extras_cache_text, 200);
      return __vsp_resp_json('{}', 200);
    }

    __vsp_extras_last_try = now;

    // de-dup inflight
    if (__vsp_extras_inflight) {
      const t = await __vsp_extras_inflight;
      return __vsp_resp_json(t, 200);
    }

    __vsp_extras_inflight = (async () => {
      try {
        const r = await _fetch(url, init);
        const t = await r.text();
        if (r && r.ok) {
          __vsp_extras_cache_text = t || '{}';
          __vsp_extras_cache_ts = Date.now();
        }
        return (t || '{}');
      } catch(_e) {
        __vsp_extras_last_fail = Date.now();
        return (__vsp_extras_cache_text || '{}');
      } finally {
        __vsp_extras_inflight = null;
      }
    })();

    const txt = await __vsp_extras_inflight;
    return __vsp_resp_json(txt, 200);
  }
  if (_fetch) {
    function parseRidFromUrl(u){
      try{
        const url = new URL(u, window.location.origin);
        return url.searchParams.get('rid') || '';
      } catch(_){ return ''; }
    }
    function swapEndpoint(u, from, to){
      try { return u.replace(from, to); } catch(_) { return u; }
    }
    async function tryFetch(u, init){
      try { return await _fetch(u, init); } catch(_) { return null; }
    }

    window.fetch = async function(input, init){
      const url = (typeof input === 'string') ? input : (input && input.url ? input.url : '');

      // VSP_THROTTLE_DASHBOARD_EXTRAS_P0_V2: intercept dashboard extras first (avoid repeated failed XHR spam)
      if (url && url.includes('/api/vsp/dashboard_v3_extras_v1')) {
        return await __vsp_fetch_extras_with_cache(url, init);
      }
      let res = null;

      // first attempt
      res = await tryFetch(input, init);

      // if ok => return
      if (res && res.ok) return res;

      // targeted fallbacks
      if (url.includes('/api/vsp/run_status_v2')) {
        const rid = parseRidFromUrl(url);
        // 1) v2 -> v1 (same query)
        let u1 = swapEndpoint(url, '/api/vsp/run_status_v2', '/api/vsp/run_status_v1');
        let r1 = await tryFetch(u1, init);
        if (r1 && r1.ok) return r1;

        // 2) path form /run_status_v1/<rid>
        if (rid) {
          let u2 = '/api/vsp/run_status_v1/' + encodeURIComponent(rid);
          let r2 = await tryFetch(u2, init);
          if (r2 && r2.ok) return r2;
        }
        return res || r1 || null;
      }

      if (url.includes('/api/vsp/findings_effective_v1')) {
        const rid = parseRidFromUrl(url);
        // try path form /findings_effective_v1/<rid>
        if (rid) {
          let u2 = '/api/vsp/findings_effective_v1/' + encodeURIComponent(rid);
          let r2 = await tryFetch(u2, init);
          if (r2 && r2.ok) return r2;
        }
        // no hard fallback => return original (avoid throwing)
        return res;
      }

      // default: return original result (even if null)
      return res;
    };
  }
})();

/* __VSP_FIX_DD_ALIAS_P0_V1: make drilldown handler callable even if it is an object (.open) */
(function(){
  'use strict';
  if (window.__VSP_FIX_DD_ALIAS_P0_V1) return;
  window.__VSP_FIX_DD_ALIAS_P0_V1 = 1;

  // Safe call: function OR {open: fn}
  window.__VSP_DD_ART_CALL__ = window.__VSP_DD_ART_CALL__ || function(h){
    try{
      var args = Array.prototype.slice.call(arguments, 1);
      if (typeof h === 'function') return h.apply(null, args);
      if (h && typeof h.open === 'function') return h.open.apply(h, args);
    } catch(e){
      try{ console.warn('[VSP][DD_SAFE]', e); } catch(_){}
    }
    return null;
  };

  // If VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 is NOT a function but exists, wrap it
  try{
    var h = window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
    if (h && typeof h !== 'function'){
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
        return window.__VSP_DD_ART_CALL__.apply(null, [h].concat([].slice.call(arguments)));
      };
      try{ console.log('[VSP][P0] drilldown alias wrapped (obj->fn)'); } catch(_){}
    }
    // If missing entirely, provide a harmless no-op function (avoid hard crash)
    if (!window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2){
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
        try{ console.warn('[VSP][P0] drilldown handler missing; noop'); } catch(_){}
        return null;
      };
    }
  } catch(e){
    try{ console.warn('[VSP][P0] drilldown alias init failed', e); } catch(_){}
  }
})();

