
// VSP_RULE_OVERRIDES_TAB_V3_P1
(function(){
  const API = {
    runs:  "/api/ui/runs_v3?limit=200&offset=0",
    get:   "/api/ui/rule_overrides_v2",
    save:  "/api/ui/rule_overrides_v2_save_v2",
    apply: "/api/ui/rule_overrides_v2_apply_v2",
  };

  function $(sel, root=document){ return root.querySelector(sel); }
  function toast(msg, ok=true){
    let el = $("#vsp_toast");
    if(!el){
      el = document.createElement("div");
      el.id="vsp_toast";
      el.style.position="fixed";
      el.style.right="16px";
      el.style.bottom="16px";
      el.style.padding="10px 12px";
      el.style.borderRadius="10px";
      el.style.fontSize="13px";
      el.style.background="rgba(20,24,30,.92)";
      el.style.border="1px solid rgba(255,255,255,.12)";
      el.style.color="#e6eef7";
      el.style.zIndex="99999";
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.style.opacity="1";
    setTimeout(()=>{ el.style.opacity="0"; }, ok?1800:2600);
  }

  async function jget(url){
    const r = await fetch(url, {cache:"no-store"});
    const t = await r.text();
    let j=null; try{ j=JSON.parse(t); }catch(e){}
    if(!r.ok) throw new Error(`HTTP_${r.status}: ${t.slice(0,220)}`);
    return j||{};
  }
  async function jpost(url, obj){
    const r = await fetch(url, {
      method:"POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(obj||{})
    });
    const t = await r.text();
    let j=null; try{ j=JSON.parse(t); }catch(e){}
    if(!r.ok) throw new Error(`HTTP_${r.status}: ${t.slice(0,220)}`);
    return j||{};
  }

  function render(root){
    root.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
        <div style="font-size:18px;font-weight:700">Rule Overrides</div>
        <div style="opacity:.65;font-size:12px">/api/ui/rule_overrides_v2</div>
        <div style="flex:1"></div>

        <select id="sel_rid" class="vsp_select" style="min-width:340px">
          <option value="">(loading runs...)</option>
        </select>

        <button id="btn_apply" class="vsp_btn">Apply to RID</button>
        <button id="btn_reload" class="vsp_btn">Reload</button>
        <button id="btn_save" class="vsp_btn vsp_btn_primary">Save</button>
      </div>

      <div id="path_line" style="opacity:.7;font-size:12px;margin-bottom:8px"></div>
      <div style="opacity:.65;font-size:12px;margin-bottom:8px">
        schema: {"rules":[{"tool":"semgrep","rule_id":"...","action":"ignore|downgrade|upgrade","severity":"LOW|...","reason":"..."}]}
      </div>

      <textarea id="ta" spellcheck="false" style="width:100%;height:320px;resize:vertical;background:#0b1220;color:#dbe8ff;border:1px solid rgba(255,255,255,.10);border-radius:12px;padding:10px;font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;font-size:12px;line-height:1.35"></textarea>

      <div id="status" style="margin-top:8px;font-size:12px;opacity:.75">Loading...</div>
    `;

    const ta = $("#ta", root);
    const st = $("#status", root);
    const pathLine = $("#path_line", root);
    const sel = $("#sel_rid", root);

    async function loadRuns(){
      try{
        const j = await jget(API.runs);
        const items = (j.items||[]);
        sel.innerHTML = "";
        if(!items.length){
          sel.innerHTML = `<option value="">(no runs)</option>`;
          return;
        }
        for(const it of items){
          const rid = it.rid || "";
          const opt = document.createElement("option");
          opt.value = rid;
          opt.textContent = rid;
          sel.appendChild(opt);
        }
      }catch(e){
        sel.innerHTML = `<option value="">(runs API failed)</option>`;
        toast("Runs load failed: " + e.message, false);
      }
    }

    async function loadRules(){
      st.textContent="Loading...";
      try{
        const j = await jget(API.get);
        pathLine.textContent = `path: ${j.path||""}`;
        ta.value = JSON.stringify((j.data||{"rules":[]}), null, 2);
        st.textContent="OK";
      }catch(e){
        st.textContent="ERROR: " + e.message;
        toast("Rule overrides load failed", false);
      }
    }

    $("#btn_reload", root).onclick = async ()=>{
      await loadRuns();
      await loadRules();
    };

    $("#btn_save", root).onclick = async ()=>{
      try{
        const obj = JSON.parse(ta.value||"{}");
        const j = await jpost(API.save, {data: obj});
        toast("Saved rule overrides");
        st.textContent="OK";
        if(j && j.path) pathLine.textContent = `path: ${j.path}`;
      }catch(e){
        toast("Save failed: " + e.message, false);
        st.textContent="ERROR: " + e.message;
      }
    };

    $("#btn_apply", root).onclick = async ()=>{
      const rid = (sel.value||"").trim();
      if(!rid){ toast("Pick RID first", false); return; }
      try{
        const obj = JSON.parse(ta.value||"{}");
        const url = API.apply + `?rid=${encodeURIComponent(rid)}`;
        const j = await jpost(url, {data: obj});
        toast(`Applied to ${rid}`);
        st.textContent="OK";
      }catch(e){
        toast("Apply failed: " + e.message, false);
        st.textContent="ERROR: " + e.message;
      }
    };

    (async ()=>{
      await loadRuns();
      await loadRules();
    })();
  }

  function boot(){
    const root = document.getElementById("vsp_tab_root");
    if(!root) return;
    render(root);
  }

  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", boot);
  }else boot();
})();
