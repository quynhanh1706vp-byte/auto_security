/* VSP_DASHBOARD_KPI_TOOLSTRIP_V1 */
(() => {
  if (window.__vsp_dashboard_kpi_toolstrip_v1) return;
  window.__vsp_dashboard_kpi_toolstrip_v1 = true;

  const TOOL_ORDER = ["BANDIT","SEMGREP","GITLEAKS","KICS","TRIVY","SYFT","GRYPE","CODEQL"];
  const SEV_ORDER  = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];

  const $ = (sel, root=document) => root.querySelector(sel);

  function pillClass(v){
    const x = String(v||"").toUpperCase();
    if (x.includes("GREEN") || x==="OK" || x==="PASS") return "ok";
    if (x.includes("AMBER") || x==="WARN") return "warn";
    if (x.includes("RED") || x==="FAIL" || x==="BLOCK") return "bad";
    return "muted";
  }

  async function getJson(url, timeoutMs=9000){
    const c = new AbortController();
    const t = setTimeout(() => c.abort(), timeoutMs);
    try{
      const r = await fetch(url, {signal:c.signal, credentials:"same-origin"});
      if (!r.ok) throw new Error("HTTP "+r.status);
      return await r.json();
    } finally { clearTimeout(t); }
  }

  function ensureStyles(){
    if ($("#vspDashKpiStyle")) return;
    const st = document.createElement("style");
    st.id = "vspDashKpiStyle";
    st.textContent = `
      .vsp-dash-wrap{ padding: 14px; }
      .vsp-grid{ display:grid; gap:12px; }
      .vsp-grid.kpi{ grid-template-columns: repeat(6, minmax(120px, 1fr)); }
      .vsp-card{
        border:1px solid rgba(255,255,255,0.10);
        background: rgba(255,255,255,0.03);
        border-radius: 14px;
        padding: 12px 12px;
      }
      .vsp-kpi-title{ font-size:12px; opacity:0.85; letter-spacing:0.2px; }
      .vsp-kpi-val{ font-size:22px; font-weight:700; margin-top:6px; }
      .vsp-row{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
      .vsp-tool{ display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius: 12px;
        border:1px solid rgba(255,255,255,0.10); background: rgba(255,255,255,0.02);
        font-size:12px;
      }
      .vsp-pill{ padding:2px 10px; border-radius:999px; border:1px solid rgba(255,255,255,0.14);
        background: rgba(255,255,255,0.04); font-size:12px; }
      .vsp-pill.ok{ border-color: rgba(40,200,120,0.55); }
      .vsp-pill.warn{ border-color: rgba(240,180,40,0.65); }
      .vsp-pill.bad{ border-color: rgba(240,80,80,0.65); }
      .vsp-pill.muted{ opacity:0.75; }
      .vsp-title{ font-size:14px; font-weight:700; letter-spacing:0.2px; }
      .vsp-sub{ font-size:12px; opacity:0.8; margin-top:4px; }
      .vsp-two{ display:grid; gap:12px; grid-template-columns: 1.3fr 1fr; }
      @media (max-width: 1100px){
        .vsp-grid.kpi{ grid-template-columns: repeat(3, minmax(120px, 1fr)); }
        .vsp-two{ grid-template-columns: 1fr; }
      }
    `;
    document.head.appendChild(st);
  }

  function mountContainer(){
    // only on /vsp5
    if (!String(location.pathname).includes("/vsp5")) return null;
    ensureStyles();

    // prefer insert after topbar if present
    const topbar = $(".vsp-topbar");
    const host = document.createElement("div");
    host.id = "vspDashKpiRoot";
    host.className = "vsp-dash-wrap";

    if (topbar && topbar.parentNode){
      topbar.parentNode.insertBefore(host, topbar.nextSibling);
    } else {
      document.body.insertBefore(host, document.body.firstChild);
    }
    return host;
  }

  function renderSkeleton(host){
    host.innerHTML = `
      <div class="vsp-two">
        <div class="vsp-card">
          <div class="vsp-title">Gate summary</div>
          <div class="vsp-sub">Loading latest RID + summary…</div>
          <div style="height:8px"></div>
          <div class="vsp-row">
            <span class="vsp-pill muted" id="vspDashVerdict">…</span>
            <span class="vsp-pill muted" id="vspDashRid">RID: …</span>
            <span class="vsp-pill muted" id="vspDashTs">TS: …</span>
          </div>
        </div>

        <div class="vsp-card">
          <div class="vsp-title">Tools</div>
          <div class="vsp-sub">8-tool strip (missing shows N/A)</div>
          <div style="height:8px"></div>
          <div class="vsp-row" id="vspToolStrip"></div>
        </div>
      </div>

      <div style="height:12px"></div>

      <div class="vsp-card">
        <div class="vsp-title">Findings KPI</div>
        <div class="vsp-sub">From reports/run_gate_summary.json → counts_total</div>
        <div style="height:10px"></div>
        <div class="vsp-grid kpi" id="vspKpiGrid"></div>
      </div>
    `;

    // tool strip skeleton
    const strip = $("#vspToolStrip", host);
    strip.innerHTML = TOOL_ORDER.map(t => `
      <div class="vsp-tool">
        <span class="vsp-pill muted">${t}</span>
        <span class="vsp-pill muted">N/A</span>
      </div>
    `).join("");

    // KPI skeleton
    const grid = $("#vspKpiGrid", host);
    grid.innerHTML = SEV_ORDER.map(s => `
      <div class="vsp-card" style="padding:12px">
        <div class="vsp-kpi-title">${s}</div>
        <div class="vsp-kpi-val">…</div>
      </div>
    `).join("");
  }

  function setText(host, sel, v){
    const el = $(sel, host);
    if (el) el.textContent = v;
  }
  function setPill(host, sel, text, klass){
    const el = $(sel, host);
    if (!el) return;
    el.textContent = text;
    el.classList.remove("ok","warn","bad","muted");
    el.classList.add(klass || "muted");
  }

  function render(host, rid, summary){
    const overall = String(summary?.overall || "UNKNOWN").toUpperCase();
    setPill(host, "#vspDashVerdict", overall, pillClass(overall));
    setText(host, "#vspDashRid", `RID: ${rid || "N/A"}`);
    setText(host, "#vspDashTs", `TS: ${(summary && summary.ts) ? summary.ts : "N/A"}`);

    // KPI
    const counts = summary?.counts_total || {};
    const grid = $("#vspKpiGrid", host);
    grid.innerHTML = SEV_ORDER.map(sev => {
      const val = (counts && (sev in counts)) ? counts[sev] : 0;
      return `
        <div class="vsp-card" style="padding:12px">
          <div class="vsp-kpi-title">${sev}</div>
          <div class="vsp-kpi-val">${Number(val||0)}</div>
        </div>
      `;
    }).join("");

    // Tool strip
    const byTool = summary?.by_tool || {};
    const strip = $("#vspToolStrip", host);
    strip.innerHTML = TOOL_ORDER.map(t => {
      const o = byTool?.[t] || null;
      const verdict = o?.verdict ? String(o.verdict).toUpperCase() : "N/A";
      const klass = verdict === "N/A" ? "muted" : pillClass(verdict);
      const tot = (o && typeof o.total !== "undefined") ? `total:${o.total}` : "";
      return `
        <div class="vsp-tool">
          <span class="vsp-pill muted">${t}</span>
          <span class="vsp-pill ${klass}">${verdict}</span>
          <span style="opacity:0.75" class="vsp-mono">${tot}</span>
        </div>
      `;
    }).join("");
  }

  async function main(){
    const host = mountContainer();
    if (!host) return;
    renderSkeleton(host);

    let rid = null;
    try{
      const runs = await getJson("/api/vsp/runs?limit=1", 9000);
      rid = runs?.items?.[0]?.run_id || null;
    }catch(_){}

    if (!rid){
      setPill(host, "#vspDashVerdict", "UNKNOWN", "muted");
      setText(host, "#vspDashRid", "RID: N/A");
      return;
    }

    try{
      const summary = await getJson(`/api/vsp/run_file?rid=${encodeURIComponent(rid)}&name=${encodeURIComponent("reports/run_gate_summary.json")}`, 12000);
      render(host, rid, summary);
    }catch(_){
      setPill(host, "#vspDashVerdict", "UNKNOWN", "muted");
      setText(host, "#vspDashRid", `RID: ${rid}`);
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", main);
  else main();
})();
