(function(){

  // VSP_ROUTE_GUARD_RUNS_ONLY_V1
  function __vsp_is_runs_only_v1(){
    try {
      const h = (location.hash||"").toLowerCase();
      return h.startsWith("#runs") || h.includes("#runs/");
    } catch(_) { return false; }
  }
  if(!__vsp_is_runs_only_v1()){
    try{ console.info("[VSP_ROUTE_GUARD_RUNS_ONLY_V1] skip", "vsp_runs_trigger_scan_ui_v3.js", "hash=", location.hash); } catch(_){}
    return;
  }
/*VSP_DISABLE_LEGACY_RUNSCAN_V1*/return;})();
(function(){/*VSP_DISABLE_DUP_SCAN_V1*/return;})();
(function(){
  if (window.__VSP_RUNSCAN_UI_V3__) return;
  window.__VSP_RUNSCAN_UI_V3__ = true;

  function $(sel, root){ return (root||document).querySelector(sel); }
  function el(tag, attrs, children){
    var n = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function(k){
      if (k === "class") n.className = attrs[k];
      else if (k === "html") n.innerHTML = attrs[k];
      else n.setAttribute(k, attrs[k]);
    });
    (children||[]).forEach(function(c){
      if (c == null) return;
      if (typeof c === "string") n.appendChild(document.createTextNode(c));
      else n.appendChild(c);
    });
    return n;
  }

  function fmtJson(o){
    try { return JSON.stringify(o, null, 2); } catch(e){ return String(o); }
  }

  function mount(){
    var runsPane = document.getElementById("vsp-runs-main");
    if (!runsPane) return false;

    // tránh mount trùng
    if (document.getElementById("vsp-runscan-panel-v3")) return true;

    // panel container
    var panel = el("div", { id: "vsp-runscan-panel-v3", class: "vsp-card", style:
      "margin:12px 0; padding:14px; border:1px solid rgba(255,255,255,.08); background:rgba(255,255,255,.03); border-radius:14px;"
    });

    var titleRow = el("div", {style:"display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap;"}, [
      el("div", {style:"font-weight:700; letter-spacing:.2px;"}, ["Run Scan Now (LOCAL/CI)"]),
      el("div", {style:"opacity:.75; font-size:12px;"}, ["POST /api/vsp/run  →  poll /api/vsp/run_status/<REQ_ID>"])
    ]);

    var row = el("div", {style:"display:flex; gap:10px; flex-wrap:wrap; margin-top:10px; align-items:flex-end;"});

    var modeSel = el("select", {class:"vsp-select", id:"vsp-runscan-mode", style:"min-width:160px;"}, [
      el("option", {value:"local"}, ["local (UI)"]),
      el("option", {value:"ci"}, ["ci (future)"])
    ]);

    var profileSel = el("select", {class:"vsp-select", id:"vsp-runscan-profile", style:"min-width:170px;"}, [
      el("option", {value:"FULL_EXT"}, ["FULL_EXT"]),
      el("option", {value:"FULL"}, ["FULL"]),
      el("option", {value:"EXT"}, ["EXT"])
    ]);

    var targetTypeSel = el("select", {class:"vsp-select", id:"vsp-runscan-target-type", style:"min-width:160px;"}, [
      el("option", {value:"path"}, ["path"])
    ]);

    var targetInput = el("input", {
      class:"vsp-input",
      id:"vsp-runscan-target",
      placeholder:"/home/test/Data/SECURITY-10-10-v4",
      value:"/home/test/Data/SECURITY-10-10-v4",
      style:"min-width:420px;"
    });

    var btn = el("button", {class:"vsp-btn vsp-btn-primary", id:"vsp-runscan-btn", style:"min-width:160px;"}, ["Run Scan Now"]);
    var btn2 = el("button", {class:"vsp-btn", id:"vsp-runscan-refresh", style:"min-width:160px;"}, ["Refresh Status"]);

    row.appendChild(el("div", {}, [el("div",{style:"font-size:12px;opacity:.7;margin-bottom:4px;"} ,["Mode"]), modeSel]));
    row.appendChild(el("div", {}, [el("div",{style:"font-size:12px;opacity:.7;margin-bottom:4px;"} ,["Profile"]), profileSel]));
    row.appendChild(el("div", {}, [el("div",{style:"font-size:12px;opacity:.7;margin-bottom:4px;"} ,["Target type"]), targetTypeSel]));
    row.appendChild(el("div", {style:"flex:1; min-width:320px;"}, [el("div",{style:"font-size:12px;opacity:.7;margin-bottom:4px;"} ,["Target"]), targetInput]));
    row.appendChild(btn);
    row.appendChild(btn2);

    var statusBox = el("pre", {
      id:"vsp-runscan-status",
      style:"margin-top:10px; padding:10px; border-radius:12px; border:1px solid rgba(255,255,255,.08); background:rgba(0,0,0,.25); max-height:240px; overflow:auto; font-size:12px;"
    }, ["(idle)"]);

    var hint = el("div",{style:"margin-top:8px; font-size:12px; opacity:.75;"}, [
      "Tip: Bạn có thể copy REQ_ID từ log UI triggers và gọi: /api/vsp/run_status/<REQ_ID>."
    ]);

    panel.appendChild(titleRow);
    panel.appendChild(row);
    panel.appendChild(statusBox);
    panel.appendChild(hint);

    // chèn panel lên đầu Runs pane (trước KPI cards)
    runsPane.insertBefore(panel, runsPane.firstChild);

    // state
    var currentReq = null;
    var pollTimer = null;

    function setStatus(objOrText){
      if (typeof objOrText === "string") statusBox.textContent = objOrText;
      else statusBox.textContent = fmtJson(objOrText);
    }

    async function apiRun(){
      btn.disabled = true;
      try{
        setStatus("Submitting /api/vsp/run ...");
        var payload = {
          mode: modeSel.value,
          profile: profileSel.value,
          target_type: targetTypeSel.value,
          target: targetInput.value || "/home/test/Data/SECURITY-10-10-v4"
        };

        var r = await fetch("/api/vsp/run", {
          method: "POST",
          headers: {"Content-Type":"application/json"},
          body: JSON.stringify(payload)
        });

        var txt = await r.text();
        var data;
        try { data = JSON.parse(txt); } catch(e){ data = {raw: txt}; }

        if (!r.ok) {
          setStatus({ok:false, http:r.status, response:data});
          return;
        }

        currentReq = data.request_id || null;
        setStatus(data);

        if (currentReq) startPoll(currentReq);
      } catch(e){
        setStatus({ok:false, error:String(e)});
      } finally{
        btn.disabled = false;
      }
    }

    async function apiStatus(req){
      try{
        var r = await fetch("/api/vsp/run_status/" + encodeURIComponent(req));
        var txt = await r.text();
        var data;
        try { data = JSON.parse(txt); } catch(e){ data = {raw: txt}; }

        if (!r.ok){
          setStatus({ok:false, http:r.status, response:data});
          return null;
        }
        setStatus(data);
        return data;
      } catch(e){
        setStatus({ok:false, error:String(e)});
        return null;
      }
    }

    function startPoll(req){
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = setInterval(async function(){
        var data = await apiStatus(req);
        if (!data) return;

        // dừng poll khi xong
        var st = (data.status || "").toUpperCase();
        if (st === "DONE" || st === "FAILED" || st === "PASS" || st === "FAIL") {
          clearInterval(pollTimer);
          pollTimer = null;
        }
      }, 1500);
    }

    btn.addEventListener("click", apiRun);
    btn2.addEventListener("click", function(){
      if (currentReq) apiStatus(currentReq);
      else setStatus("No REQ_ID yet. Click Run Scan Now first.");
    });

    // auto mount: nếu hash đang ở runs thì ok; còn không thì vẫn mount trong DOM runs pane
    console.log("[VSP_RUNSCAN_UI_V3] mounted into #vsp-runs-main");
    return true;
  }

  // retry mount vài lần vì router load pane chậm

  // Expose mount for hook re-mounting
  window.VSP_RUNSCAN_MOUNT = mount;

  var n=0, it=setInterval(function(){
    n++;
    if (mount()) { clearInterval(it); return; }
    if (n>80) clearInterval(it);
  }, 200);

})();
