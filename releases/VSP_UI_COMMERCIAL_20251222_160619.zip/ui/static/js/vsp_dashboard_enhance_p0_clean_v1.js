// VSP_SAFE_DRILLDOWN_HARDEN_P0_V6
/* VSP_DASHBOARD_ENHANCE_P0_CLEAN_V1
 * P0 goal: NO red console errors, no drilldown symbol usage, safe degrade.
 */
(function(){
  'use strict';

  





/* VSP_FIX_DRILLDOWN_CALLSITE_P0_V5: safe-call drilldown artifacts (function OR object.open) */
function __VSP_DD_ART_CALL__(h, ...args) {
  try {
    if (typeof h === 'function') return h(...args);
    if (h && typeof h.open === 'function') return h.open(...args);
  } catch(e) { try{console.warn('[VSP][DD_SAFE]', e);} catch(_e){} }
  return null;
}

/* VSP_FIX_DRILLDOWN_CALLSITE_P0_V3: safe-call for drilldown artifacts (function OR object.open) */
function __VSP_DD_ART_CALL__(h, ...args) {
  try {
    if (typeof h === 'function') return h(...args);
    if (h && typeof h.open === 'function') return h.open(...args);
  } catch (e) {
    try { console.warn('[VSP][DD_SAFE] call failed', e); } catch (_e) {}
  }
  return null;
}

/* VSP_FIX_DRILLDOWN_ARTIFACTS_NOT_FUNCTION_P0_V2
 * Fix: TypeError __VSP_DD_ART_CALL__(VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2, ...) is not a function
 * Normalize BEFORE first use:
 *   - if function: keep
 *   - if object with .open(): wrap as function(arg)->obj.open(arg)
 *   - else: no-op (never throw)
 */
(function(){
  'use strict';
  if (window.__VSP_FIX_DRILLDOWN_ARTIFACTS_NOT_FUNCTION_P0_V2) return;
  window.__VSP_FIX_DRILLDOWN_ARTIFACTS_NOT_FUNCTION_P0_V2 = 1;

  function normalize(v){
    if (typeof v === 'function') return v;
    if (v && typeof v.open === 'function') {
      const obj = v;
      const fn = function(arg){ try { return obj.open(arg); } catch(e){ console.warn('[VSP][DD_FIX] open() failed', e); return null; } };
      fn.__wrapped_from_object = true;
      return fn;
    }
    const noop = function(_arg){ return null; };
    noop.__noop = true;
    return noop;
  }

  try {
    // trap future assignments
    let _val = window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
    Object.defineProperty(window, 'VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2', {
      configurable: true, enumerable: true,
      get: function(){ return _val; },
      set: function(v){ _val = normalize(v); }
    });
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = _val;
  } catch(e) {
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = normalize(window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2);
  }
})();

const TAG = '[VSP_DASH_P0_CLEAN]';

  function $(sel, root){ try{ return (root||document).querySelector(sel); } catch(_){ return null; } }
  function $all(sel, root){ try{ return Array.from((root||document).querySelectorAll(sel)); } catch(_){ return []; } }

  async function fetchJSON(url, opts){
    try{
      const r = await fetch(url, Object.assign({cache:'no-store'}, opts||{}));
      if(!r.ok) throw new Error('HTTP '+r.status);
      return await r.json();
    } catch(e){
      console.warn(TAG, 'fetch failed', url, e);
      return null;
    }
  }

  function setText(id, txt){
    const el = document.getElementById(id);
    if(!el) return;
    el.textContent = (txt==null?'':String(txt));
  }

  function safeInit(){
    // Do NOT reference VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 at all.
    // Only do harmless hydration.
    console.log(TAG, 'loaded');

    // 1) Try read dashboard data (best effort)
    fetchJSON('/api/vsp/dashboard_v3').then(d=>{
      if(!d){ return; }
      try{
        // If your template has any of these ids, fill them. If not, no-op.
        if (d.by_severity && typeof d.by_severity === 'object'){
          setText('kpi-total', d.by_severity.TOTAL ?? d.total ?? '');
          setText('kpi-critical', d.by_severity.CRITICAL ?? '');
          setText('kpi-high', d.by_severity.HIGH ?? '');
          setText('kpi-medium', d.by_severity.MEDIUM ?? '');
          setText('kpi-low', d.by_severity.LOW ?? '');
          setText('kpi-info', d.by_severity.INFO ?? '');
          setText('kpi-trace', d.by_severity.TRACE ?? '');
        }
      } catch(e){
        console.warn(TAG, 'render kpi failed', e);
      }
    });

    // 2) Gate: keep whatever other modules do; we just avoid crashing.
    // If you want, we can add canonical gate wiring later.

    // 3) Charts: do nothing here. Avoid bootstrap retry spam.
  }

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', safeInit, {once:true});
  }else{
    safeInit();
  }
})();
