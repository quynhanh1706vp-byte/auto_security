// === VSP RUNS & REPORTS – FIX V3 ===

function loadRuns() {
  fetch("/api/vsp/runs_index_v3")
    .then(r => r.json())
    .then(json => {
      if (!json.ok) return;
      const tbody = $("#runs-table-body");
      tbody.empty();

      json.items.forEach(run => {
        const tr = $(`
          <tr class="run-row">
            <td>${run.run_id}</td>
            <td>${run.timestamp}</td>
            <td>${run.tool_count}</td>
            <td>${run.total_findings}</td>
            <td>
              <button class="btn-export" data-id="${run.run_id}">
                Export
              </button>
            </td>
          </tr>
        `);
        tbody.append(tr);
      });
    })
    .catch(err => console.error("[RUNS] Error:", err));
}

// Export RUN
$(document).on("click",".btn-export",function(){
  const id = $(this).data("id");
  window.location.href = `/api/vsp/run_export_html?run_id=${id}`;
});

document.addEventListener("DOMContentLoaded", loadRuns);
