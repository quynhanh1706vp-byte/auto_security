/* VSP_UI_SHELL_V1 - topbar + toast + helpers */
(()=> {
  



/* VSP_NOISE_PANEL_ALLTABS_V1
   Alt+N: toggle panel
   Alt+Shift+N: clear log
*/
(()=> {
  try {
    if (window.__vsp_noise_panel_alltabs_v1) return;
    window.__vsp_noise_panel_alltabs_v1 = true;

    const KEY = "vsp_noise_log_v1";
    const MAX = 300;

    function now(){ return new Date().toISOString(); }
    function load(){
      try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch(e){ return []; }
    }
    function save(arr){
      try { localStorage.setItem(KEY, JSON.stringify(arr.slice(-MAX))); } catch(e){}
    }
    function push(item){
      const arr = load();
      arr.push(item);
      save(arr);
    }
    function clear(){
      try { localStorage.removeItem(KEY); } catch(e){}
    }

    function record(kind, data){
      push({
        t: now(),
        tab: location.pathname,
        kind,
        ...data
      });
    }

    // fetch hook
    const _fetch = window.fetch ? window.fetch.bind(window) : null;
    if (_fetch){
      window.fetch = async function(input, init){
        const url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
        try{
          const res = await _fetch(input, init);
          if (!res.ok){
            record("fetch", {status: res.status, url});
          }
          return res;
        }catch(e){
          record("fetch_exc", {status: 0, url, err: String(e && e.message || e)});
          throw e;
        }
      };
    }

    // XHR hook
    const XHR = window.XMLHttpRequest;
    if (XHR && XHR.prototype && XHR.prototype.open){
      const _open = XHR.prototype.open;
      const _send = XHR.prototype.send;
      XHR.prototype.open = function(method, url){
        this.__vsp_url = (typeof url === "string") ? url : "";
        return _open.apply(this, arguments);
      };
      XHR.prototype.send = function(){
        try{
          this.addEventListener("loadend", ()=>{
            try{
              const st = this.status || 0;
              if (st >= 400 || st === 0){
                record("xhr", {status: st, url: this.__vsp_url || ""});
              }
            }catch(e){}
          });
        }catch(e){}
        return _send.apply(this, arguments);
      };
    }

    // JS errors
    window.addEventListener("error", (ev)=>{
      try{
        record("js_error", {msg: String(ev.message||""), src: String(ev.filename||""), line: ev.lineno||0, col: ev.colno||0});
      }catch(e){}
    });

    window.addEventListener("unhandledrejection", (ev)=>{
      try{
        record("promise_rej", {msg: String(ev.reason && (ev.reason.message||ev.reason) || "unhandled")});
      }catch(e){}
    });

    // Panel UI
    function ensurePanel(){
      if (document.getElementById("vspNoisePanelV1")) return;
      const d = document.createElement("div");
      d.id = "vspNoisePanelV1";
      d.style.cssText = "position:fixed;right:12px;bottom:12px;z-index:999999;background:rgba(0,0,0,.85);color:#d6e0ff;border:1px solid rgba(255,255,255,.15);border-radius:12px;width:520px;max-height:60vh;overflow:auto;font:12px/1.4 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;box-shadow:0 12px 30px rgba(0,0,0,.35);display:none;";
      d.innerHTML = `
        <div style="padding:10px 10px 6px;display:flex;gap:8px;align-items:center;position:sticky;top:0;background:rgba(0,0,0,.9);">
          <div style="font-weight:700">VSP Noise</div>
          <div style="opacity:.7">Alt+N toggle • Alt+Shift+N clear</div>
          <div style="margin-left:auto;display:flex;gap:6px">
            <button id="vspNoiseRefreshV1" style="all:unset;cursor:pointer;padding:4px 8px;border:1px solid rgba(255,255,255,.2);border-radius:8px;">Refresh</button>
            <button id="vspNoiseClearV1" style="all:unset;cursor:pointer;padding:4px 8px;border:1px solid rgba(255,255,255,.2);border-radius:8px;">Clear</button>
          </div>
        </div>
        <div id="vspNoiseBodyV1" style="padding:8px 10px 10px;"></div>
      `;
      document.body.appendChild(d);
      document.getElementById("vspNoiseRefreshV1").onclick = render;
      document.getElementById("vspNoiseClearV1").onclick = ()=>{ clear(); render(); };
      render();
    }

    function render(){
      ensurePanel();
      const body = document.getElementById("vspNoiseBodyV1");
      const arr = load().slice().reverse();
      if (!arr.length){
        body.innerHTML = `<div style="opacity:.7">No noise 🎉</div>`;
        return;
      }
      body.innerHTML = arr.map(x=>{
        const u = (x.url||"").replace(location.origin,"");
        return `<div style="padding:6px 0;border-bottom:1px dashed rgba(255,255,255,.12)">
          <div><b>${x.kind}</b> <span style="opacity:.7">${x.t}</span> <span style="opacity:.7">(${x.tab})</span></div>
          ${x.status!==undefined?`<div>status: <b>${x.status}</b></div>`:""}
          ${u?`<div style="word-break:break-all">url: ${u}</div>`:""}
          ${x.msg?`<div style="word-break:break-word">msg: ${String(x.msg).slice(0,200)}</div>`:""}
        </div>`;
      }).join("");
    }

    function toggle(){
      ensurePanel();
      const el = document.getElementById("vspNoisePanelV1");
      el.style.display = (el.style.display === "none") ? "block" : "none";
      if (el.style.display === "block") render();
    }

    window.__vsp_noise = {render, toggle, clear};

    window.addEventListener("keydown", (ev)=>{
      if (ev.altKey && !ev.shiftKey && (ev.key==="n" || ev.key==="N")) { ev.preventDefault(); toggle(); }
      if (ev.altKey && ev.shiftKey && (ev.key==="n" || ev.key==="N")) { ev.preventDefault(); clear(); render(); }
    }, {passive:false});

  } catch(e) {}
})();

/* VSP_RUNFILEALLOW_FETCH_GUARD_V3C
   - prevent 404 spam when rid missing/invalid
   - auto add default path when missing
   - covers fetch + XMLHttpRequest
*/
(()=> {
  try {
    if (window.__vsp_runfileallow_fetch_guard_v3c) return;
    window.__vsp_runfileallow_fetch_guard_v3c = true;

    function _isLikelyRid(rid){
      if(!rid || typeof rid !== "string") return false;
      if(rid.length < 6) return false;
      if(rid.includes("{") || rid.includes("}")) return false;
      return /^[A-Za-z0-9_\-]+$/.test(rid);
    }

    function _fix(url0){
      try{
        if(!url0 || typeof url0 !== "string") return {action:"pass"};
        if(!url0.includes("/api/vsp/run_file_allow")) return {action:"pass"};
        const u = new URL(url0, window.location.origin);
        const rid = u.searchParams.get("rid") || "";
        const path = u.searchParams.get("path") || "";
        if(!_isLikelyRid(rid)) return {action:"skip"};
        if(!path){
          u.searchParams.set("path","run_gate_summary.json");
          return {action:"rewrite", url: u.toString().replace(window.location.origin,"")};
        }
        return {action:"pass"};
      }catch(e){
        return {action:"pass"};
      }
    }

    // fetch
    const _origFetch = window.fetch ? window.fetch.bind(window) : null;
    if (_origFetch){
      window.fetch = function(input, init){
        try{
          const url0 = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
          const fx = _fix(url0);
          if (fx.action === "skip"){
            const body = JSON.stringify({ok:false, skipped:true, reason:"no rid"});
            return Promise.resolve(new Response(body, {status:200, headers:{"Content-Type":"application/json; charset=utf-8"}}));
          }
          if (fx.action === "rewrite"){
            if (typeof input === "string") input = fx.url;
            else input = new Request(fx.url, input);
          }
        }catch(e){}
        return _origFetch(input, init);
      };
    }

    // XHR
    const XHR = window.XMLHttpRequest;
    if (XHR && XHR.prototype && XHR.prototype.open){
      const _open = XHR.prototype.open;
      XHR.prototype.open = function(method, url, async, user, password){
        try{
          const url0 = (typeof url === "string") ? url : "";
          const fx = _fix(url0);
          if (fx.action === "skip"){
            const body = encodeURIComponent(JSON.stringify({ok:false, skipped:true, reason:"no rid"}));
            url = "data:application/json;charset=utf-8," + body;
          } else if (fx.action === "rewrite"){
            url = fx.url;
          }
        }catch(e){}
        return _open.call(this, method, url, async, user, password);
      };
    }
  } catch(e) {}
})();

if (window.__vsp_ui_shell_v1) return;
  window.__vsp_ui_shell_v1 = true;

  const page = location.pathname || "/";
  const base = "";

  function el(tag, attrs={}, children=[]){
    const e=document.createElement(tag);
    for(const [k,v] of Object.entries(attrs||{})){
      if(k==="class") e.className=v;
      else if(k==="html") e.innerHTML=v;
      else e.setAttribute(k, v);
    }
    for(const c of (children||[])){
      if(typeof c==="string") e.appendChild(document.createTextNode(c));
      else if(c) e.appendChild(c);
    }
    return e;
  }

  function toast(kind, title, msg){
    let host=document.querySelector(".vsp-toast");
    if(!host){
      host=el("div",{class:"vsp-toast"});
      document.body.appendChild(host);
    }
    const t=el("div",{class:"t"});
    t.innerHTML = `<b>${title}</b><div style="opacity:.78;margin-top:4px">${msg||""}</div>`;
    if(kind==="good") t.style.borderColor="rgba(47,227,154,.45)";
    if(kind==="warn") t.style.borderColor="rgba(255,204,102,.45)";
    if(kind==="bad")  t.style.borderColor="rgba(255,92,122,.45)";
    host.prepend(t);
    setTimeout(()=>{ try{t.remove();}catch(e){} }, 6500);
  }

  async function getJSON(url){
    const r=await fetch(url, {method:"GET"});
    const ct=(r.headers.get("content-type")||"");
    let data=null;
    try{ data = ct.includes("application/json") ? await r.json() : await r.text(); }
    catch(e){ data = await r.text().catch(()=> ""); }
    return {ok:r.ok, status:r.status, data};
  }

  function addTopbar(){
    if(document.querySelector(".vsp-topbar")) return;
    document.body.classList.add("vsp-shell-pad");

    const left = el("div",{class:"vsp-brand"},[
      el("div",{class:"vsp-dot"}),
      el("div",{},[
        el("div",{class:"vsp-title"},["VSP • Commercial UI"]),
        el("div",{class:"vsp-sub"},[page])
      ])
    ]);

    const stat = el("div",{class:"vsp-pill", id:"vspShellLastRun"},[
      el("span",{class:"vsp-muted"},["Last run:"]),
      el("b",{id:"vspShellLastRunId"},["—"]),
      el("span",{id:"vspShellLastRunBadge", class:"vsp-badge info", style:"margin-left:6px;"},["LIVE"])
    ]);

    const btnRuns = el("button",{class:"vsp-btn vsp-btn-primary", type:"button"},["Runs"]);
    btnRuns.onclick=()=> location.href="/runs";
    const btnData = el("button",{class:"vsp-btn", type:"button"},["Data Source"]);
    btnData.onclick=()=> location.href="/data_source";
    const btnRules = el("button",{class:"vsp-btn", type:"button"},["Rule Overrides"]);
    btnRules.onclick=()=> location.href="/rule_overrides";
    const btnSet = el("button",{class:"vsp-btn", type:"button"},["Settings"]);
    btnSet.onclick=()=> location.href="/settings";

    const btnReload = el("button",{class:"vsp-btn", type:"button"},["Reload"]);
    btnReload.onclick=()=> location.reload();

    const right = el("div",{class:"vsp-actions"},[stat, btnRuns, btnData, btnRules, btnSet, btnReload]);

    const bar = el("div",{class:"vsp-topbar"},[left, right]);
    document.body.appendChild(bar);

    // quick last-run probe
    (async ()=>{
      const r=await getJSON("/api/vsp/runs?limit=1");
      if(r.ok && r.data && r.data.items && r.data.items[0]){
        const it=r.data.items[0];
        const rid = it.rid || it.run_id || it.id || "—";
        const overall=(it.overall || it.overall_status || "UNKNOWN").toString().toUpperCase();
        document.getElementById("vspShellLastRunId").textContent = rid;
        const b=document.getElementById("vspShellLastRunBadge");
        b.textContent = overall;
        b.className = "vsp-badge " + (overall==="GREEN"||overall==="OK"?"good":(overall==="RED"||overall==="FAIL"?"bad":(overall==="AMBER"||overall==="WARN"?"warn":"info")));
      }
    })().catch(()=>{});
  }

  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", addTopbar);
  else addTopbar();

  window.VSP_UI = { toast, getJSON };
})();
