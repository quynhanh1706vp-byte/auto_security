/* VSP_DATASOURCE_EXPLORER_V1 - client-side filter bar (safe) */
(()=> {
  if (window.__vsp_ds_explorer_v1) return;
  window.__vsp_ds_explorer_v1 = true;

  function el(tag, cls){ const e=document.createElement(tag); if(cls) e.className=cls; return e; }
  function qs(sel){ return document.querySelector(sel); }
  function qsa(sel){ return Array.from(document.querySelectorAll(sel)); }

  function injectBar(){
    if(document.getElementById("vspDsBar")) return;
    const bar = el("div","vsp-card");
    bar.id="vspDsBar";
    bar.style.margin="12px 0";
    bar.innerHTML = `
      <div class="vsp-card-h">
        <div class="vsp-h1">Findings Explorer</div>
        <div class="vsp-muted" style="font-size:12px;margin-top:4px;">Quick filter/search on the current table (safe overlay).</div>
      </div>
      <div class="vsp-card-b" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
        <input id="vspDsQ" placeholder="search text (rule_id, file, title...)" class="vsp-code"
               style="flex:1; min-width:260px; padding:10px 12px; border-radius:12px; border:1px solid rgba(255,255,255,.12); background:rgba(0,0,0,.18); color:inherit;">
        <select id="vspDsSev" class="vsp-code" style="padding:10px 12px; border-radius:12px; border:1px solid rgba(255,255,255,.12); background:rgba(0,0,0,.18); color:inherit;">
          <option value="">severity: ALL</option>
          <option>CRITICAL</option><option>HIGH</option><option>MEDIUM</option><option>LOW</option><option>INFO</option><option>TRACE</option>
        </select>
        <button class="vsp-btn" id="vspDsReset" type="button">Reset</button>
        <span class="vsp-badge info" id="vspDsCount">—</span>
      </div>
    `;
    const host = document.body;
    host.insertBefore(bar, host.firstChild.nextSibling);

    function apply(){
      const q=(document.getElementById("vspDsQ").value||"").toLowerCase().trim();
      const sev=(document.getElementById("vspDsSev").value||"").toUpperCase().trim();
      const rows = qsa("table tbody tr");
      let shown=0;
      rows.forEach(tr=>{
        const txt=(tr.innerText||"").toLowerCase();
        const okq = !q || txt.includes(q);
        const oksev = !sev || txt.includes(sev.toLowerCase());
        const ok = okq && oksev;
        tr.style.display = ok ? "" : "none";
        if(ok) shown++;
      });
      document.getElementById("vspDsCount").textContent = `rows: ${shown}`;
    }

    document.getElementById("vspDsQ").addEventListener("input", ()=> apply());
    document.getElementById("vspDsSev").addEventListener("change", ()=> apply());
    document.getElementById("vspDsReset").onclick=()=>{
      document.getElementById("vspDsQ").value="";
      document.getElementById("vspDsSev").value="";
      apply();
    };

    setTimeout(apply, 800);
  }

  if(location.pathname==="/data_source"){
    if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", injectBar);
    else injectBar();
  }
})();
