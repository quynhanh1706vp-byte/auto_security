/* vsp_dashboard_charts_pretty_v3.js
 * CLEAN REBUILD (no Chart.js dependency)
 * - Exports: window.VSP_CHARTS_ENGINE_V3.initAll(dash)
 * - Auto-creates canvases inside placeholders:
 *     #vsp-chart-severity, #vsp-chart-trend, #vsp-chart-bytool, #vsp-chart-topcwe
 * - Dispatches: window event "vsp:charts-ready"
 */
(function () {
  "use strict";
  console.log("[VSP_CHARTS_V3] pretty charts loaded (CLEAN REBUILD v1)");

  if (window.__VSP_CHARTS_V3_REBUILD_LOADED) return;
  window.__VSP_CHARTS_V3_REBUILD_LOADED = true;

  var HOLDERS = {
    severity: "vsp-chart-severity",
    trend: "vsp-chart-trend",
    bytool: "vsp-chart-bytool",
    topcwe: "vsp-chart-topcwe"
  };

  function $(id) { return document.getElementById(id); }

  function ensureCanvasIn(holderId, canvasId) {
    var holder = $(holderId);
    if (!holder) return null;

    // if holder itself is a canvas
    if (holder.tagName && holder.tagName.toLowerCase() === "canvas") return holder;

    // existing canvas?
    var existing = holder.querySelector ? holder.querySelector("canvas") : null;
    if (existing) return existing;

    var c = document.createElement("canvas");
    c.id = canvasId;
    c.style.width = "100%";
    c.style.height = "100%";
    c.width = Math.max(480, holder.clientWidth || 480);
    c.height = Math.max(220, holder.clientHeight || 220);
    holder.appendChild(c);
    return c;
  }

  function resizeCanvasToHolder(canvas, holderId) {
    try {
      var holder = $(holderId);
      if (!holder || !canvas) return;
      var w = Math.max(480, holder.clientWidth || 480);
      var h = Math.max(220, holder.clientHeight || 220);
      if (canvas.width !== w) canvas.width = w;
      if (canvas.height !== h) canvas.height = h;
    } catch (e) {}
  }

  function clear(ctx) {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  }

  function drawText(ctx, text) {
    clear(ctx);
    ctx.save();
    ctx.fillStyle = "#cbd5e1";
    ctx.font = "14px Inter, system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(text, ctx.canvas.width / 2, ctx.canvas.height / 2);
    ctx.restore();
  }

  function drawDonut(ctx, items) {
    // items: [{label, value}]
    clear(ctx);
    var W = ctx.canvas.width, H = ctx.canvas.height;
    var cx = W * 0.35, cy = H * 0.5;
    var rOuter = Math.min(W, H) * 0.28;
    var rInner = rOuter * 0.58;

    var sum = 0;
    for (var i=0;i<items.length;i++) sum += Math.max(0, +items[i].value || 0);
    if (!sum) return drawText(ctx, "No data");

    // palette (no hard theme dependency)
    var palette = ["#ef4444","#f97316","#f59e0b","#22c55e","#60a5fa","#a78bfa","#94a3b8"];
    var start = -Math.PI / 2;

    for (var j=0;j<items.length;j++) {
      var v = Math.max(0, +items[j].value || 0);
      var ang = (v / sum) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, rOuter, start, start + ang, false);
      ctx.closePath();
      ctx.fillStyle = palette[j % palette.length];
      ctx.globalAlpha = 0.85;
      ctx.fill();
      start += ang;
    }
    ctx.globalAlpha = 1;

    // hole
    ctx.beginPath();
    ctx.arc(cx, cy, rInner, 0, Math.PI * 2);
    ctx.fillStyle = "#0b1020";
    ctx.fill();

    // total
    ctx.save();
    ctx.fillStyle = "#e5e7eb";
    ctx.font = "700 18px Inter, system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(sum), cx, cy - 2);
    ctx.font = "12px Inter, system-ui, sans-serif";
    ctx.fillStyle = "#94a3b8";
    ctx.fillText("total", cx, cy + 18);
    ctx.restore();

    // legend
    var lx = W * 0.62, ly = H * 0.22;
    ctx.save();
    ctx.font = "12px Inter, system-ui, sans-serif";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    for (var k=0;k<items.length;k++) {
      var y = ly + k * 18;
      ctx.fillStyle = palette[k % palette.length];
      ctx.globalAlpha = 0.85;
      ctx.fillRect(lx, y - 6, 10, 10);
      ctx.globalAlpha = 1;
      ctx.fillStyle = "#cbd5e1";
      ctx.fillText(items[k].label + ": " + (items[k].value || 0), lx + 14, y);
    }
    ctx.restore();
  }

  function drawBar(ctx, items, title) {
    clear(ctx);
    var W = ctx.canvas.width, H = ctx.canvas.height;
    if (!items || !items.length) return drawText(ctx, "No data");

    var max = 0;
    for (var i=0;i<items.length;i++) max = Math.max(max, +items[i].value || 0);
    if (!max) return drawText(ctx, "No data");

    var padL=48, padR=16, padT=28, padB=28;
    var plotW = W - padL - padR;
    var plotH = H - padT - padB;

    ctx.save();
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px Inter, system-ui, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(title || "Bar", padL, 18);
    ctx.restore();

    // axes
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.beginPath();
    ctx.moveTo(padL, padT);
    ctx.lineTo(padL, padT + plotH);
    ctx.lineTo(padL + plotW, padT + plotH);
    ctx.stroke();
    ctx.restore();

    var n = items.length;
    var gap = Math.max(6, plotW * 0.02);
    var bw = (plotW - gap * (n - 1)) / n;

    for (var j=0;j<n;j++) {
      var v = +items[j].value || 0;
      var h = (v / max) * plotH;
      var x = padL + j * (bw + gap);
      var y = padT + (plotH - h);

      ctx.fillStyle = "rgba(96,165,250,0.75)";
      ctx.fillRect(x, y, bw, h);

      ctx.save();
      ctx.fillStyle = "#cbd5e1";
      ctx.font = "11px Inter, system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      var lab = items[j].label;
      if (lab && lab.length > 10) lab = lab.slice(0, 9) + "…";
      ctx.fillText(lab || "", x + bw/2, padT + plotH + 6);
      ctx.restore();
    }
  }

  function drawLine(ctx, series, title) {
    clear(ctx);
    var W = ctx.canvas.width, H = ctx.canvas.height;
    if (!series || series.length < 2) return drawText(ctx, "No trend data");

    var padL=48, padR=16, padT=28, padB=28;
    var plotW = W - padL - padR;
    var plotH = H - padT - padB;

    var min=Infinity, max=-Infinity;
    for (var i=0;i<series.length;i++) {
      var v = +series[i].value || 0;
      min = Math.min(min, v);
      max = Math.max(max, v);
    }
    if (max === min) { max = min + 1; }

    ctx.save();
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px Inter, system-ui, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(title || "Trend", padL, 18);
    ctx.restore();

    // axes
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.beginPath();
    ctx.moveTo(padL, padT);
    ctx.lineTo(padL, padT + plotH);
    ctx.lineTo(padL + plotW, padT + plotH);
    ctx.stroke();
    ctx.restore();

    function px(i) {
      return padL + (i / (series.length - 1)) * plotW;
    }
    function py(v) {
      return padT + (1 - (v - min) / (max - min)) * plotH;
    }

    ctx.save();
    ctx.strokeStyle = "rgba(34,197,94,0.85)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(px(0), py(series[0].value));
    for (var j=1;j<series.length;j++) {
      ctx.lineTo(px(j), py(series[j].value));
    }
    ctx.stroke();

    // points
    ctx.fillStyle = "rgba(34,197,94,0.9)";
    for (var k=0;k<series.length;k++) {
      ctx.beginPath();
      ctx.arc(px(k), py(series[k].value), 3, 0, Math.PI*2);
      ctx.fill();
    }
    ctx.restore();
  }

  function normalizeSeverity(dash) {
    var s = (dash && dash.by_severity) ? dash.by_severity : {};
    // accept either VSP levels or generic
    var keys = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];
    var out = [];
    for (var i=0;i<keys.length;i++) {
      var k = keys[i];
      var v = 0;
      if (typeof s[k] === "number") v = s[k];
      else if (s[k] && typeof s[k].count === "number") v = s[k].count;
      out.push({ label: k, value: v });
    }
    return out;
  }

  function normalizeByTool(dash) {
    var bt = (dash && dash.by_tool) ? dash.by_tool : {};
    var items = [];
    // bt could be {tool:count} or {tool:{total}} etc.
    for (var k in bt) {
      if (!Object.prototype.hasOwnProperty.call(bt, k)) continue;
      var v = bt[k];
      var n = (typeof v === "number") ? v :
              (v && typeof v.total === "number") ? v.total :
              (v && typeof v.count === "number") ? v.count : 0;
      items.push({ label: k, value: n });
    }
    items.sort(function(a,b){ return (b.value||0) - (a.value||0); });
    return items.slice(0, 6);
  }

  function normalizeTopCWE(dash) {
    var list = (dash && dash.top_cwe_list) ? dash.top_cwe_list : [];
    var items = [];
    for (var i=0;i<list.length;i++) {
      var x = list[i] || {};
      var lab = x.cwe || x.id || x.name || ("CWE-" + (i+1));
      var v = x.count || x.n || x.total || 0;
      items.push({ label: String(lab), value: +v || 0 });
    }
    items.sort(function(a,b){ return (b.value||0)-(a.value||0); });
    return items.slice(0, 6);
  }

  function normalizeTrend(dash) {
    // If no historical series, create a tiny synthetic series from totals
    var total = (dash && dash.total_findings) ? +dash.total_findings :
                (dash && dash.summary_all && dash.summary_all.total_findings) ? +dash.summary_all.total_findings :
                (dash && dash.totals && dash.totals.total) ? +dash.totals.total : 0;
    if (!total) total = 0;
    return [
      { label: "t-3", value: Math.max(0, Math.round(total*0.55)) },
      { label: "t-2", value: Math.max(0, Math.round(total*0.72)) },
      { label: "t-1", value: Math.max(0, Math.round(total*0.88)) },
      { label: "now", value: total }
    ];
  }

  function dispatchReady(detail) {
    try {
      window.dispatchEvent(new CustomEvent("vsp:charts-ready", { detail: detail || { engine:"V3", ts: Date.now() } }));
    } catch (e) {
      try {
        var ev = document.createEvent("Event");
        ev.initEvent("vsp:charts-ready", true, true);
        window.dispatchEvent(ev);
      } catch (_) {}
    }
  }

  window.VSP_CHARTS_ENGINE_V3 = {
    initAll: function (dash) {
      try {
        // create canvases and render
        var cSev = ensureCanvasIn(HOLDERS.severity, "vsp-severity-canvas");
        var cTr  = ensureCanvasIn(HOLDERS.trend, "vsp-trend-canvas");
        var cBt  = ensureCanvasIn(HOLDERS.bytool, "vsp-bytool-canvas");
        var cCwe = ensureCanvasIn(HOLDERS.topcwe, "vsp-topcwe-canvas");

        if (cSev) resizeCanvasToHolder(cSev, HOLDERS.severity);
        if (cTr)  resizeCanvasToHolder(cTr,  HOLDERS.trend);
        if (cBt)  resizeCanvasToHolder(cBt,  HOLDERS.bytool);
        if (cCwe) resizeCanvasToHolder(cCwe, HOLDERS.topcwe);

        if (cSev) drawDonut(cSev.getContext("2d"), normalizeSeverity(dash));
        if (cTr)  drawLine(cTr.getContext("2d"), normalizeTrend(dash), "Findings trend (synthetic)");
        if (cBt)  drawBar(cBt.getContext("2d"), normalizeByTool(dash), "Top tools");
        if (cCwe) drawBar(cCwe.getContext("2d"), normalizeTopCWE(dash), "Top CWE");

        console.log("[VSP_CHARTS_V3] initAll OK");
        return true;
      } catch (e) {
        console.warn("[VSP_CHARTS_V3] initAll failed", e);
        return false;
      }
    }
  };

  // Auto-init if dashboard already stored data
  try {
    if (window.__VSP_DASH_LAST_DATA_V3) {
      window.VSP_CHARTS_ENGINE_V3.initAll(window.__VSP_DASH_LAST_DATA_V3);
    }
  } catch (e) {}

  // Inform other modules (dashboard enhance) that charts engine is ready
  dispatchReady({ engine: "V3", ts: Date.now() });

  // Re-render on resize (lightweight)
  window.addEventListener("resize", function () {
    try {
      if (window.__VSP_DASH_LAST_DATA_V3) {
        window.VSP_CHARTS_ENGINE_V3.initAll(window.__VSP_DASH_LAST_DATA_V3);
      }
    } catch (e) {}
  });

})();

// === VSP_CHARTS_READY_EVENT_V1 ===

(function(){
  try{
    if (window.__VSP_CHARTS_READY_EVENT_V1) return;
    window.__VSP_CHARTS_READY_EVENT_V1 = true;
    window.dispatchEvent(new CustomEvent('vsp:charts-ready', { detail: { engine: 'V3' } }));
    console.log('[VSP_CHARTS] vsp:charts-ready dispatched (V3).');
  } catch(e){}
})();

