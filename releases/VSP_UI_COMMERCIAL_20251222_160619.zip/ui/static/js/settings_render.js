"use strict";

// Bản TEST: chỉ để xem JS này có chạy không
(function () {
  alert("VSP SETTINGS TEST v2 – JS đã load!");

  if (!window.VSP) window.VSP = {};

  window.VSP.initSettings = async function () {
    console.log("[VSP][DEBUG] initSettings() từ bản TEST.");
    // tạm thời không render gì, chỉ log
  };
})();
