/* VSP_P1_DATA_SOURCE_PAGINATION_V1 (limit/offset; avoid rendering 100k findings) */
(()=> {
  try{
    if (window.__vsp_p1_data_source_pagination_v1) return;
    window.__vsp_p1_data_source_pagination_v1 = true;

    const API_BASE = "/api/ui/findings_v3";
    const DEF_LIMIT = 200;

    function qs(k){
      try{ return new URLSearchParams(location.search).get(k) || ""; }catch(_){ return ""; }
    }
    function esc(s){
      return String(s??"").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    }
    function pickTotal(d){
      return (d && (d.total ?? d.TOTAL ?? d.count ?? d.total_count ?? d.items_total)) ?? null;
    }
    function pickItems(d){
      const items = d && (d.items ?? d.findings ?? d.data ?? d.rows);
      return Array.isArray(items) ? items : [];
    }

    function pickRid(){
      const qrid = qs("rid");
      if (qrid) return qrid;

      const el = document.querySelector("[data-rid]") || document.querySelector("#rid")
              || document.querySelector("input[name='rid']") || document.querySelector("select[name='rid']");
      if (el){
        const v = el.getAttribute("data-rid") || el.value || el.textContent || "";
        return String(v||"").trim();
      }

      const m = (document.body && document.body.textContent) ? document.body.textContent.match(/RUN_\d{8}_\d{6}/) : null;
      return m ? m[0] : "";
    }

    function ensureHost(){
      const host = document.querySelector("#data_source, [data-page='data_source'], [data-tab='data_source'], main, .main, body") || document.body;

      let box = document.getElementById("VSP_P1_DS_PAGER");
      if (!box){
        box = document.createElement("div");
        box.id = "VSP_P1_DS_PAGER";
        box.style.cssText = "margin:10px 0 14px 0; padding:10px; border:1px solid rgba(255,255,255,.10); border-radius:12px; background:rgba(255,255,255,.04);";
        box.innerHTML = `
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:space-between;">
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
              <span style="opacity:.85;font-size:12px;">Data Source</span>
              <span style="font-size:12px;opacity:.85;">RID:</span>
              <input id="VSP_DS_RID" style="min-width:260px; padding:6px 10px; border-radius:10px; border:1px solid rgba(255,255,255,.12); background:rgba(0,0,0,.20); color:#eaeaea" placeholder="RUN_YYYYmmdd_HHMMSS" />
              <span style="font-size:12px;opacity:.85;">Page size:</span>
              <select id="VSP_DS_LIMIT" style="padding:6px 10px; border-radius:10px; border:1px solid rgba(255,255,255,.12); background:rgba(0,0,0,.20); color:#eaeaea">
                <option>100</option><option selected>200</option><option>500</option><option>1000</option>
              </select>
              <button id="VSP_DS_PREV" style="padding:6px 12px; border-radius:10px; border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.06); color:#eaeaea; cursor:pointer;">Prev</button>
              <button id="VSP_DS_NEXT" style="padding:6px 12px; border-radius:10px; border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.06); color:#eaeaea; cursor:pointer;">Next</button>
              <button id="VSP_DS_LOAD" style="padding:6px 12px; border-radius:10px; border:1px solid rgba(120,200,255,.25); background:rgba(120,200,255,.10); color:#eaeaea; cursor:pointer;">Load</button>
            </div>
            <div id="VSP_DS_STAT" style="font-size:12px;opacity:.85;">offset=0 limit=${DEF_LIMIT} total=?</div>
          </div>
          <div style="height:10px"></div>
          <div style="overflow:auto; border-radius:12px; border:1px solid rgba(255,255,255,.08);">
            <table style="width:100%; border-collapse:collapse; font-size:12px;">
              <thead>
                <tr style="background:rgba(255,255,255,.04); text-align:left;">
                  <th style="padding:8px 10px; white-space:nowrap;">Severity</th>
                  <th style="padding:8px 10px; white-space:nowrap;">Tool</th>
                  <th style="padding:8px 10px; white-space:nowrap;">Rule</th>
                  <th style="padding:8px 10px;">File</th>
                  <th style="padding:8px 10px; white-space:nowrap;">Line</th>
                  <th style="padding:8px 10px;">Message</th>
                </tr>
              </thead>
              <tbody id="VSP_DS_TBODY"></tbody>
            </table>
          </div>
        `;
        host.insertBefore(box, host.firstChild);
      }
      return box;
    }

    function render(items){
      const tb = document.getElementById("VSP_DS_TBODY");
      if (!tb) return;
      tb.innerHTML = "";
      for (const it of items){
        const sev = (it.severity ?? it.sev ?? it.level ?? it.norm_severity ?? it.severity_norm ?? "").toString();
        const tool = (it.tool ?? it.engine ?? it.scanner ?? "").toString();
        const rule = (it.rule_id ?? it.rule ?? it.check_id ?? it.id ?? it.cwe ?? "").toString();
        const file = (it.file ?? it.path ?? it.file_path ?? it.location?.path ?? it.artifact?.uri ?? "").toString();
        const line = (it.line ?? it.location?.line ?? it.start_line ?? it.region?.startLine ?? "").toString();
        const msg = (it.message ?? it.title ?? it.name ?? it.desc ?? it.description ?? it.snippet ?? "").toString();
        const tr = document.createElement("tr");
        tr.style.cssText = "border-top:1px solid rgba(255,255,255,.06);";
        tr.innerHTML = `
          <td style="padding:7px 10px; white-space:nowrap;">${esc(sev)}</td>
          <td style="padding:7px 10px; white-space:nowrap; opacity:.9;">${esc(tool)}</td>
          <td style="padding:7px 10px; white-space:nowrap; opacity:.9;">${esc(rule)}</td>
          <td style="padding:7px 10px; opacity:.9;">${esc(file)}</td>
          <td style="padding:7px 10px; white-space:nowrap; opacity:.9;">${esc(line)}</td>
          <td style="padding:7px 10px;">${esc(msg)}</td>
        `;
        tb.appendChild(tr);
      }
    }

    async function loadPage(offset){
      ensureHost();
      const ridEl = document.getElementById("VSP_DS_RID");
      const limEl = document.getElementById("VSP_DS_LIMIT");
      const stat = document.getElementById("VSP_DS_STAT");

      const rid = String((ridEl && ridEl.value) ? ridEl.value : pickRid()).trim();
      const limit = parseInt((limEl && limEl.value) ? limEl.value : DEF_LIMIT, 10) || DEF_LIMIT;

      if (ridEl && !ridEl.value) ridEl.value = rid;

      if (!rid){
        if (stat) stat.textContent = "RID missing (add ?rid=RUN_... or paste into RID box)";
        return;
      }

      const url = `${API_BASE}?rid=${encodeURIComponent(rid)}&limit=${encodeURIComponent(limit)}&offset=${encodeURIComponent(offset)}`;
      if (stat) stat.textContent = `loading... rid=${rid} offset=${offset} limit=${limit}`;

      const resp = await fetch(url, { credentials: "same-origin" });
      if (!resp.ok){
        if (stat) stat.textContent = `HTTP ${resp.status} when GET ${url}`;
        return;
      }
      const d = await resp.json().catch(()=> ({}));
      const total = pickTotal(d);
      const items = pickItems(d);

      render(items);

      const totalTxt = (total===null || typeof total==="undefined") ? "?" : String(total);
      if (stat) stat.textContent = `rid=${rid} offset=${offset} limit=${limit} total=${totalTxt} showing=${items.length}`;

      window.__vsp_ds_page_v1 = { rid, offset, limit, total };
    }

    function wire(){
      ensureHost();
      const ridEl = document.getElementById("VSP_DS_RID");
      const limEl = document.getElementById("VSP_DS_LIMIT");
      const prev = document.getElementById("VSP_DS_PREV");
      const next = document.getElementById("VSP_DS_NEXT");
      const load = document.getElementById("VSP_DS_LOAD");

      if (ridEl){
        const rid = pickRid();
        if (rid) ridEl.value = rid;
      }

      const cur = ()=> window.__vsp_ds_page_v1 || { offset: 0, limit: DEF_LIMIT };

      prev && prev.addEventListener("click", ()=> {
        const c = cur();
        const off = Math.max(0, (c.offset||0) - (c.limit||DEF_LIMIT));
        loadPage(off);
      });
      next && next.addEventListener("click", ()=> {
        const c = cur();
        const off = (c.offset||0) + (c.limit||DEF_LIMIT);
        loadPage(off);
      });
      load && load.addEventListener("click", ()=> loadPage((cur().offset||0)));

      limEl && limEl.addEventListener("change", ()=> loadPage(0));
      ridEl && ridEl.addEventListener("keydown", (e)=> {
        if (e.key === "Enter") loadPage(0);
      });

      loadPage(0);
    }

    if (document.readyState === "loading"){
      document.addEventListener("DOMContentLoaded", wire);
    } else {
      wire();
    }
  }catch(e){
    console && console.warn && console.warn("VSP_P1_DATA_SOURCE_PAGINATION_V1 failed:", e);
  }
})();


/* VSP_P1_DS_LISTEN_RULE_APPLY_V1 (listen apply event + expose reload) */
(()=> {
  try{
    const EVT = "vsp:rule_overrides_applied";
    // Expose reload hook used by bundle
    window.__vsp_ds_reload_v1 = ()=>{
      try{
        // prefer reset to 0 so user sees new counts quickly
        const st = window.__vsp_ds_page_v1 || { offset: 0, limit: 200 };
        const off = 0;
        // try call internal loadPage if we can find it (we can't directly), so just click Load after setting offset=0
        // easiest: trigger the Load button if present
        const btn = document.getElementById("VSP_DS_LOAD");
        if (btn){ btn.click(); return; }
        // fallback: hard reload if needed
        if (location && /\/data_source\b/i.test(location.pathname||"")) location.reload();
      }catch(_){}
    };

    window.addEventListener(EVT, ()=> {
      try{
        if (location && /\/data_source\b/i.test(location.pathname||"")){
          // reset offset to 0 by reloading (fast + safe)
          location.reload();
        }
      }catch(_){}
    });
  }catch(_){}
})();

