/* VSP_P0_DASH_ONLY_KILL_SWITCH_V1 */
(()=> {
  if (window.__vsp_p0_dash_only_kill_v1) return;
  window.__vsp_p0_dash_only_kill_v1 = true;

  // Dashboard-only mode (set by /vsp5 HTML middleware)
  const dashOnly = !!(window.__VSP_DASH_ONLY || window.__VSP_DASHBOARD_ONLY);
  if (!dashOnly) return;

  window.__VSP_DISABLE_AUTOFRESH = true;
  window.__VSP_DISABLE_RUNS_META = true;
  window.__VSP_DISABLE_LEGACY    = true;

  // Block legacy intervals that cause "nhảy về"
  const _setInterval = window.setInterval ? window.setInterval.bind(window) : null;
  if (_setInterval) {
    window.setInterval = (fn, ms, ...rest) => {
      try{
        const src = (typeof fn === 'function') ? (fn.name || fn.toString()) : String(fn);
        if (/AutoRefresh|runs_meta|rid_autofix|DashV6|legacy|V6C|V6D|V6E|GateStory/i.test(src)) {
          console.warn("[VSP][DASH_ONLY] blocked interval", ms);
          return 0;
        }
      }catch(_){}
      return _setInterval(fn, ms, ...rest);
    };
  }

  // Block runs list calls (Dashboard-only)
  const _fetch = window.fetch ? window.fetch.bind(window) : null;
  if (_fetch) {
    window.fetch = (url, opts) => {
      try{
        const u = String(url||"");
        if (window.__VSP_DISABLE_RUNS_META && /\/api\/vsp\/runs\b/.test(u)) {
          console.warn("[VSP][DASH_ONLY] blocked fetch", u);
          return Promise.reject(new Error("blocked /api/vsp/runs in dash-only"));
        }
      }catch(_){}
      return _fetch(url, opts);
    };
  }

  // Prevent double render patterns (best-effort guard)
  window.__VSP_DASH_RENDER_ONCE = true;
  if (!window.__VSP_DASH_RENDERED) window.__VSP_DASH_RENDERED = 0;

  // If any module calls global render twice, it should check this flag (we enforce here too)
  const _raf = window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : null;
  if (_raf) {
    window.requestAnimationFrame = (cb) => _raf(() => {
      try{
        // prune accidental duplicate dashboard blocks (heuristic)
        const roots = document.querySelectorAll("#vsp5_root .vsp-card, #vsp5_root .vsp_panel, #vsp5_root .vsp-panel");
        if (roots && roots.length > 3000) { /* ignore */ }
      }catch(_){}
      cb && cb();
    });
  }

  console.log("[VSP][DASH_ONLY] kill-switch enabled");
})();


/* VSP_P0_DASH_STOP_JUMP_SINGLE_RENDERER_V1
 * - Block legacy V6 polling intervals that cause layout flip/jump
 * - Clear old RID pins to avoid snapping back to RUN_*
 */
(()=> {
  try{
    if (window.__vsp_p0_stop_jump_single_renderer_v1) return;
    window.__vsp_p0_stop_jump_single_renderer_v1 = true;

    // Clear RID pins that often force jump back to old RUN_*
    try{
      const keys = ["vsp.rid","VSP_RID","rid","vsp_rid","vsp.rid.pinned","vsp_rid_pinned","vsp:last_rid"];
      keys.forEach(k => { try{ localStorage.removeItem(k); }catch(e){} });
    }catch(e){}

    // Block ONLY legacy V6 interval callbacks (string contains V6C/V6D/V6E markers)
    const _si = window.setInterval;
    window.setInterval = function(fn, t, ...args){
      try{
        const src = String(fn || "");
        if (
          src.includes("legacy disabled (V6") ||
          src.includes("V6C") || src.includes("V6D") || src.includes("V6E")
        ){
          try{ console.debug("[VSP][PATCH] blocked legacy V6 interval"); }catch(e){}
          return 0;
        }
      }catch(e){}
      return _si(fn, t, ...args);
    };
  }catch(e){}
})();


/* VSP_P1_BLOCK_RUNFILEALLOW_SARIF_PROBE_AND_MUTE_LEGACY_LOGS_V1
 * Goal: Step-2 commercial clean.
 * - Block any *auto-probe* calls to /api/vsp/run_file_allow that target SARIF (causing 403 allowlist noise)
 * - Mute legacy V6 spam logs (cosmetic, for demo cleanliness)
 */
(()=>{ try{
  // --- mute legacy spam logs (cosmetic)
  const _mk = (fn)=>function(...a){
    try{
      const msg = String(a && a[0] !== undefined ? a[0] : "");
      if (msg.includes("legacy disabled (V6")) return;
      if (msg.includes("[VSP][DASH] legacy disabled")) return;
      if (msg.includes("containers/rid missing")) return;
    }catch(_){}
    return fn.apply(this,a);
  };
  if (console && console.log)  console.log  = _mk(console.log);
  if (console && console.warn) console.warn = _mk(console.warn);

  const isSarifProbe = (url)=>{
    url = String(url||"");
    if (!url.includes("/api/vsp/run_file_allow")) return false;
    const u = url.toLowerCase();
    // block any sarif / sarif-disabled probes
    return u.includes(".sarif") || u.includes("sarif__disabled__") || u.includes("findings_unified.sarif");
  };

  // --- block fetch probes
  const ofetch = window.fetch;
  if (typeof ofetch === "function") {
    window.fetch = function(input, init){
      try{
        const url = (typeof input === "string") ? input : (input && input.url) || "";
        if (isSarifProbe(url)) {
          const body = JSON.stringify({ok:false, err:"sarif probe disabled (Step-2)"});
          return Promise.resolve(new Response(body, {status:200, headers:{"Content-Type":"application/json"}}));
        }
      }catch(_){}
      return ofetch.apply(this, arguments);
    };
  }

  // --- block XHR probes (some legacy code uses XMLHttpRequest)
  const X = window.XMLHttpRequest;
  if (X && X.prototype) {
    const oopen = X.prototype.open;
    const osend = X.prototype.send;
    X.prototype.open = function(method, url){
      try{ this.__vsp_url__ = url; }catch(_){}
      return oopen.apply(this, arguments);
    };
    X.prototype.send = function(body){
      try{
        const url = this.__vsp_url__ || "";
        if (isSarifProbe(url)) {
          // emulate success without network
          try { this.readyState = 4; } catch(_){}
          try { this.status = 200; } catch(_){}
          try { this.responseText = '{"ok":false,"err":"sarif probe disabled (Step-2)"}'; } catch(_){}
          try { if (typeof this.onreadystatechange === "function") this.onreadystatechange(); } catch(_){}
          try { if (typeof this.onload === "function") this.onload(); } catch(_){}
          return;
        }
      }catch(_){}
      return osend.apply(this, arguments);
    };
  }
}catch(_){}})();

/* VSP_P1_HARD_KILL_LEGACY_V6_AND_SARIF_PROBE_V1
 * Hard-disable legacy V6C/V6D/V6E runners + block SARIF probe.
 */

/* VSP_P1_CLEAN_STEP2_CONTRACT_V1
 * Lock commercial flags early (non-writable) + disable SARIF probe.
 */
(()=>{try{
  const lock=(k,v)=>{ try{ Object.defineProperty(window,k,{value:v,writable:false,configurable:false}); }catch(_){ window[k]=v; } };
  lock("__vsp_disable_legacy_dash_v1", true);
  lock("__vsp_disable_interceptors_v1", true);
  lock("__vsp_disable_fetch_shim_v1", true);
  lock("__vsp_disable_probe_sarif_v1", true);
  lock("__vsp_latest_rid_url_v1", "/api/vsp/rid_latest_gate_root");
}catch(_){}})();


/* VSP_P1_CONTRACT_SINGLE_RID_V2
 * Lock commercial flags early (must run before any legacy code).
 * - force rid source: /api/vsp/rid_latest_gate_root_gate_root
 * - disable legacy dash + interceptors + fetch shim
 * - disable SARIF probing (dashboard step2 doesn't need it)
 * - clear pinned RID keys (RUN_* noise)
 */
(()=>{try{
  const lock=(k,v)=>{try{Object.defineProperty(window,k,{value:v,writable:false,configurable:false});}catch(_){window[k]=v;}}
  lock("__vsp_disable_legacy_dash_v1", true);
  lock("__vsp_disable_interceptors_v1", true);
  lock("__vsp_disable_fetch_shim_v1", true);
  lock("__vsp_disable_probe_sarif_v1", true);
  lock("__vsp_latest_rid_url_v1", "/api/vsp/rid_latest_gate_root_gate_root");

  // Clear typical RID pin keys (best-effort)
  const keys=["vsp.rid","VSP_RID","VSP_RID_PIN","vsp_rid","rid_pin","vsp_last_rid","vsp.latest.rid","vsp.latestRid"];
  for (const k of keys){ try{ localStorage.removeItem(k); }catch(_){ } }
}catch(_){}})();


/* VSP_P1_KILL_FETCH_SHIM_AND_FIX_PATHS_V1
 * - Ensure any fetch shim is effectively disabled
 * - Clear pinned RID keys (avoid old RUN_* taking over)
 * - Keep commercial contract: rid_latest_gate_root + run_gate_summary only
 */
(()=> {
  try {
    window.__vsp_disable_interceptors_v1 = true;
    window.__vsp_disable_fetch_shim_v1 = true;
    window.__vsp_disable_legacy_dash_v1 = true;

    // Clear common RID pin keys (best-effort; safe if absent)
    const keys = [
      "vsp.rid","VSP_RID","VSP_RID_PIN","vsp_rid","rid_pin",
      "vsp_last_rid","vsp.latest.rid","vsp.latestRid"
    ];
    for (const k of keys) { try { localStorage.removeItem(k); } catch(_){} }
  } catch(_){}
})();


/* VSP_P1_DISABLE_LEGACY_DASH_MODULES_V1
 * Commercial contract: keep ONLY gate_root + run_gate_summary.
 * Disable legacy dashboard modules (V6C/V6D/V6E) and fetch_shim which cause:
 *  - rid pinning to old RUN_*
 *  - noisy "check ids"
 *  - 404 vsp_p0_fetch_shim_v1.js
 */
try { window.__vsp_disable_legacy_dash_v1 = true; } catch(_){}


/* ===================== VSP_P1_XHR_RUNGATE_NORMALIZE_V1 =====================
   Normalize run_gate_summary.json / run_gate.json for BOTH fetch + XMLHttpRequest.
   Fixes KPI stuck at "—" when UI expects ok:true / counts_by_severity.
============================================================================= */

/* VSP_P1_DASH_CONTRACT_ENFORCE_V1
 * Dashboard contract: ONLY
 *  - /api/vsp/rid_latest_gate_root_gate_root
 *  - /api/vsp/run_file_allow?rid=<RID>&path=run_gate_summary.json
 * Disable legacy latest_rid + noisy id-check logs.
 */
try { window.__vsp_dash_contract_only_summary_v1 = true; } catch(_){}
try { window.__vsp_latest_rid_url_v1 = "/api/vsp/rid_latest_gate_root_gate_root"; } catch(_){}

/* VSP_P1_DISABLE_INTERCEPTORS_V1
 * Commercial clean: disable fetch/XHR interceptors/normalize/rewrite in this bundle.
 * Dashboard contract must be direct: rid_latest_gate_root + run_gate_summary.json (no hooks).
 */
try { window.__vsp_disable_interceptors_v1 = true; } catch(_){}

(()=> {
  try {
    if (window.__vsp_p1_xhr_rungate_norm_v1) return;
    window.__vsp_p1_xhr_rungate_norm_v1 = true;

    const SEV = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];
    const ZERO = ()=>({CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0,TRACE:0});
    const addCounts = (dst, src) => {
      if (!src || typeof src !== "object") return dst;
      for (const k of SEV) dst[k] += Number(src[k]||0) || 0;
      return dst;
    };
    const tryExtractCounts = (j) => {
      if (j && typeof j.counts_total === "object") {
        const c = ZERO(); addCounts(c, j.counts_total);
        if (SEV.reduce((a,k)=>a+c[k],0) > 0) return c;
      }
      if (j && typeof j.counts_by_severity === "object") {
        const c = ZERO(); addCounts(c, j.counts_by_severity);
        if (SEV.reduce((a,k)=>a+c[k],0) > 0) return c;
      }
      if (j && j.by_tool && typeof j.by_tool === "object") {
        const c = ZERO();
        for (const tk of Object.keys(j.by_tool)) {
          const t = j.by_tool[tk];
          if (!t || typeof t !== "object") continue;
          if (t.counts_by_severity) addCounts(c, t.counts_by_severity);
          else if (t.counts) addCounts(c, t.counts);
          else if (t.severity) addCounts(c, t.severity);
        }
        if (SEV.reduce((a,k)=>a+c[k],0) > 0) return c;
      }
      return null;
    };

    const isTarget = (u) => {
      if (!u) return false;
      const s = String(u);
      return s.includes("/api/vsp/run_file_allow")
        && (s.includes("path=run_gate_summary.json") || s.includes("path=run_gate.json"));
    };
    const getRid = (u) => {
      try { return (new URL(u, location.origin)).searchParams.get("rid") || ""; }
      catch(_) { return ""; }
    };

    const normalize = (j, url) => {
      if (!j || typeof j !== "object") return j;
      if (!("ok" in j)) j.ok = true;

      const rid = getRid(url);
      if (rid) {
        if (!("rid" in j)) j.rid = rid;
        if (!("run_id" in j)) j.run_id = rid;
      }

      const c = tryExtractCounts(j);
      if (c) {
        j.meta = (j.meta && typeof j.meta === "object") ? j.meta : {};
        if (!j.meta.counts_by_severity) j.meta.counts_by_severity = c;
        if (!j.counts_by_severity) j.counts_by_severity = c;
      }

      window.__vsp_last_gate_summary = j;
      return j;
    };

    // ---- fetch path (keep, but stronger: ignore content-type)
    if (window.fetch && !window.__vsp_p1_fetch_rungate_norm_v1) {
      window.__vsp_p1_fetch_rungate_norm_v1 = true;
      const prevFetch = window.fetch.bind(window);
      if (!window.__vsp_disable_interceptors_v1) window.fetch = async (input, init) => {
        const url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
        const resp = await prevFetch(input, init);
        if (!isTarget(url)) return resp;
        try {
          const txt = await resp.clone().text();
          let j; try { j = JSON.parse(txt); } catch(_) { return resp; }
          j = normalize(j, url);
          const h = new Headers(resp.headers || {});
          h.set("content-type","application/json");
          console.warn("[VSP][norm] fetch normalized:", url);
          return new Response(JSON.stringify(j), {status: resp.status, headers: h});
        } catch(_) { return resp; }
      };
    }

    // ---- XHR path (axios)
    if (window.XMLHttpRequest && !window.__vsp_p1_xhr_hooked_v1) {
      window.__vsp_p1_xhr_hooked_v1 = true;
      const XHR = window.XMLHttpRequest;
      const _open = XHR.prototype.open;
      const _send = XHR.prototype.send;

      XHR.prototype.open = function(method, url) {
        try { this.__vsp_url = url; } catch(_) {}
        return _open.apply(this, arguments);
      };

      XHR.prototype.send = function() {
        try {
          const xhr = this;
          const url = xhr.__vsp_url || "";
          if (isTarget(url)) {
            xhr.addEventListener("readystatechange", function() {
              try {
                if (xhr.readyState !== 4) return;
                if (xhr.status !== 200) return;
                const txt = xhr.responseText;
                let j; try { j = JSON.parse(txt); } catch(_) { return; }
                j = normalize(j, url);
                const patched = JSON.stringify(j);

                // override responseText/response with patched payload if possible
                try {
                  Object.defineProperty(xhr, "responseText", { get: ()=>patched });
                } catch(_) {}
                try {
                  Object.defineProperty(xhr, "response", { get: ()=>patched });
                } catch(_) {}

                console.warn("[VSP][norm] XHR normalized:", url);
              } catch(_) {}
            }, false);
          }
        } catch(_) {}
        return _send.apply(this, arguments);
      };
    }

    console.log("[VSP] rungate normalize DISABLED (commercial clean)");
  } catch(e) {
    try { console.warn("[VSP] rungate normalize init error:", e); } catch(_){}
  }
})();
/* ===================== /VSP_P1_XHR_RUNGATE_NORMALIZE_V1 ===================== */


/* ===================== VSP_P1_RUN_GATE_SUMMARY_OK_NORMALIZE_V2 =====================
   Strong normalize for run_gate_summary.json / run_gate.json:
   - Parse JSON regardless of content-type (some gateways send text/plain)
   - Inject ok:true, rid/run_id
   - Inject meta.counts_by_severity (for KPI) if missing by aggregating known shapes
===================================================================================== */
(()=> {
  try {
    if (window.__vsp_p1_rungate_ok_norm_v2) return;
    window.__vsp_p1_rungate_ok_norm_v2 = true;

    const SEV = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];
    const ZERO = ()=>({CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0,TRACE:0});

    const addCounts = (dst, src) => {
      if (!src || typeof src !== "object") return dst;
      SEV.forEach(k => { const v = Number(src[k]||0); if (!Number.isNaN(v)) dst[k] += v; });
      return dst;
    };

    const tryExtractCounts = (j) => {
      // 1) counts_total already a dict by severity?
      if (j && typeof j.counts_total === "object") {
        const c = ZERO();
        addCounts(c, j.counts_total);
        const sum = SEV.reduce((a,k)=>a+c[k],0);
        if (sum > 0) return c;
      }
      // 2) top-level counts_by_severity?
      if (j && typeof j.counts_by_severity === "object") {
        const c = ZERO();
        addCounts(c, j.counts_by_severity);
        const sum = SEV.reduce((a,k)=>a+c[k],0);
        if (sum > 0) return c;
      }
      // 3) by_tool aggregation (common shape)
      if (j && j.by_tool && typeof j.by_tool === "object") {
        const c = ZERO();
        for (const k of Object.keys(j.by_tool)) {
          const t = j.by_tool[k];
          if (!t || typeof t !== "object") continue;
          if (t.counts_by_severity && typeof t.counts_by_severity === "object") addCounts(c, t.counts_by_severity);
          else if (t.counts && typeof t.counts === "object") addCounts(c, t.counts);
          else if (t.severity && typeof t.severity === "object") addCounts(c, t.severity);
        }
        const sum = SEV.reduce((a,k)=>a+c[k],0);
        if (sum > 0) return c;
      }
      return null;
    };

    const isTarget = (u) => {
      if (!u) return false;
      const s = String(u);
      if (!s.includes("/api/vsp/run_file_allow")) return false;
      if (s.includes("path=run_gate_summary.json")) return true;
      if (s.includes("path=run_gate.json")) return true;
      return false;
    };

    const getRid = (u) => {
      try { return (new URL(u, window.location.origin)).searchParams.get("rid") || ""; }
      catch(_) { return ""; }
    };

    const prevFetch = window.fetch ? window.fetch.bind(window) : null;
    if (!prevFetch) return;

    if (!window.__vsp_disable_interceptors_v1) window.fetch = async (input, init) => {
      const url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
      const resp = await prevFetch(input, init);
      if (!isTarget(url)) return resp;

      try {
        const txt = await resp.clone().text();
        let j = null;
        try { j = JSON.parse(txt); } catch(_e) { return resp; }
        if (!j || typeof j !== "object") return resp;

        if (!("ok" in j)) j.ok = true;

        const rid = getRid(url);
        if (rid) {
          if (!("rid" in j)) j.rid = rid;
          if (!("run_id" in j)) j.run_id = rid;
        }

        // ensure KPI-friendly counts
        const c = tryExtractCounts(j);
        if (c) {
          j.meta = (j.meta && typeof j.meta === "object") ? j.meta : {};
          if (!j.meta.counts_by_severity) j.meta.counts_by_severity = c;
          if (!j.counts_by_severity) j.counts_by_severity = c;
        }

        // debug hook
        window.__vsp_last_gate_summary = j;

        const h = new Headers(resp.headers || {});
        h.set("content-type", "application/json");
        return new Response(JSON.stringify(j), { status: resp.status, headers: h });
      } catch (e) {
        try { console.warn("[VSP][rungate_ok_norm_v2] error:", e); } catch(_){}
        return resp;
      }
    };

    try { console.log("[VSP] run_gate_summary ok-normalize v2 enabled"); } catch(_){}
  } catch(_e) {}
})();
/* ===================== /VSP_P1_RUN_GATE_SUMMARY_OK_NORMALIZE_V2 ===================== */


/* ===================== VSP_P1_RUN_GATE_SUMMARY_OK_NORMALIZE_V1 =====================
   Normalize /api/vsp/run_file_allow?path=run_gate_summary.json (and run_gate.json):
   - If JSON lacks 'ok', inject ok:true
   - Also inject rid/run_id from query if missing
===================================================================================== */
(()=> {
  try {
    if (window.__vsp_p1_rungate_ok_norm_v1) return;
    window.__vsp_p1_rungate_ok_norm_v1 = true;

    const prevFetch = window.fetch ? window.fetch.bind(window) : null;
    if (!prevFetch) return;

    const isGateSummaryUrl = (u) => {
      if (!u) return false;
      const s = String(u);
      if (!s.includes("/api/vsp/run_file_allow")) return false;
      if (s.includes("path=run_gate_summary.json")) return true;
      if (s.includes("path=run_gate.json")) return true;
      return false;
    };

    const getRidFromUrl = (u) => {
      try {
        const url = new URL(u, window.location.origin);
        return url.searchParams.get("rid") || "";
      } catch(_) { return ""; }
    };

    if (!window.__vsp_disable_interceptors_v1) window.fetch = async (input, init) => {
      const url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
      const resp = await prevFetch(input, init);

      if (!isGateSummaryUrl(url)) return resp;

      try {
        const ct = (resp.headers && resp.headers.get) ? (resp.headers.get("content-type") || "") : "";
        if (!ct.includes("application/json")) return resp;

        const txt = await resp.clone().text();
        let j = null;
        try { j = JSON.parse(txt); } catch(_e) { return resp; }
        if (!j || typeof j !== "object") return resp;

        // inject ok if missing (this is the critical fix)
        if (!("ok" in j)) j.ok = true;

        // inject rid/run_id if missing
        const rid = getRidFromUrl(url);
        if (rid) {
          if (!("rid" in j)) j.rid = rid;
          if (!("run_id" in j)) j.run_id = rid;
        }

        const h = new Headers(resp.headers || {});
        h.set("content-type", "application/json");

        const body = JSON.stringify(j);
        return new Response(body, { status: resp.status, headers: h });
      } catch (e) {
        try { console.warn("[VSP][rungate_ok_norm] error:", e); } catch(_){}
        return resp;
      }
    };

    try { console.log("[VSP] run_gate_summary ok-normalize enabled"); } catch(_){}
  } catch(_e) {}
})();
/* ===================== /VSP_P1_RUN_GATE_SUMMARY_OK_NORMALIZE_V1 ===================== */


/* ===================== VSP_P1_LAZY_BIG_FINDINGS_FETCH_V1 =====================
   Goal: prevent auto-load of big findings_unified.json on dashboard load/polling.
   Allow big fetch only after user gesture (click/keydown/pointer) within a short window,
   or when explicitly enabled via window.__vsp_enable_big_findings_once().
========================================================================== */
(()=> {
  try {
    if (window.__vsp_p1_lazy_big_findings_fetch_v1) return;
    window.__vsp_p1_lazy_big_findings_fetch_v1 = true;

    let __lastGesture = 0;
    const mark = () => { __lastGesture = Date.now(); };
    ["click","keydown","pointerdown","touchstart","mousedown"].forEach(ev=>{
      window.addEventListener(ev, mark, true);
    });

    const ZERO_COUNTS = {CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0,TRACE:0};
    const shouldGate = (url) => {
      const onDataSource = ((location && location.pathname) ? location.pathname : "").includes("data_source");
      if (onDataSource) return false;
      if (!url) return false;
      const u = String(url);
      // gate the big one(s)
      if (u.includes("/api/vsp/run_file_allow") && u.includes("path=findings_unified.json")) return true;
      // optional: also gate other large exports if they ever get auto-loaded
      if (u.includes("/api/vsp/run_file_allow") && u.includes("path=findings_unified.") && !u.includes("run_gate")) return true;
      return false;
    };

    window.__vsp_enable_big_findings_once = () => {
      window.__vsp_allow_big_findings = true;
      setTimeout(()=>{ try{ window.__vsp_allow_big_findings = false; }catch(_){ } }, 8000);
      return true;
    };

    const realFetch = window.fetch ? window.fetch.bind(window) : null;
    if (!realFetch) return;

    if (!window.__vsp_disable_interceptors_v1) window.fetch = async (input, init) => {
      const url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
      if (shouldGate(url)) {
        const now = Date.now();
        const allow =
          (window.__vsp_allow_big_findings === true) ||
          ((now - __lastGesture) >= 0 && (now - __lastGesture) < 12000);

        if (!allow) {
          // Return a safe empty payload (ok:true) so UI won't hang on skeleton.
          const body = JSON.stringify({
            ok: true,
            meta: { counts_by_severity: ZERO_COUNTS, note: "lazy_skip_big_findings" },
            findings: []
          });
          try { console.warn("[VSP][lazy] skip big auto-fetch:", url); } catch(_){}
          return new Response(body, { status: 200, headers: {"Content-Type":"application/json"} });
        }
      }
      return realFetch(input, init);
    };
  } catch (e) {
    try { console.warn("[VSP][lazy] init error:", e); } catch(_){}
  }
})();
/* ===================== /VSP_P1_LAZY_BIG_FINDINGS_FETCH_V1 ===================== */

/* VSP_P0_RUNFILEALLOW_RETRY_V1 (alias rid_latest + retry run_file_allow with rid/gate_root variants) */
(()=> {
  if (window.__vsp_p0_runfileallow_retry_v1) return;
  window.__vsp_p0_runfileallow_retry_v1 = true;

  const _origFetch = window.fetch ? window.fetch.bind(window) : null;
  if (!_origFetch) return;

  const _latestMetaCache = { t: 0, v: null };

  function _now(){ return Date.now(); }
  function _sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

  async function _getLatestMeta(){
    const age = _now() - (_latestMetaCache.t || 0);
    if (_latestMetaCache.v && age < 1500) return _latestMetaCache.v; // cache ~1.5s
    const urls = [
      "/api/vsp/rid_latest_gate_root_gate_root",
      "/api/vsp/rid_latest_gate_root_gate_root"
    ];
    for (const u of urls){
      try{
        const r = await _origFetch(u, { cache: "no-store" });
        const ct = (r.headers.get("content-type") || "").toLowerCase();
        if (!r.ok) continue;
        const txt = await r.text();
        const t = txt.trim();
        if (!(t.startsWith("{") || t.startsWith("["))) continue;
        const j = JSON.parse(t);
        if (j && (j.ok === true) && (j.rid || j.run_id || j.gate_root || j.gate_root_id)){
          _latestMetaCache.t = _now();
          _latestMetaCache.v = j;
          return j;
        }
      }catch(e){}
    }
    return null;
  }

  function _normRid(rid){
    if (!rid) return rid;
    let r = String(rid).trim();
    // common variants seen in your env
    r = r.replace("VSP_CI_RUN_", "VSP_CI_");
    r = r.replace("_CI_RUN_", "_CI_");
    r = r.replace("_RUN_", "_");
    return r;
  }

  function _buildRunFileAllowCandidates(urlStr, meta){
    const u = new URL(urlStr, location.origin);
    const path = u.searchParams.get("path") || "";
    const rid0 = u.searchParams.get("rid") || "";
    const cand = [];

    function addRid(v){
      if (!v) return;
      const uu = new URL(u.toString());
      uu.searchParams.set("rid", v);
      cand.push(uu.toString());
    }

    addRid(rid0);
    addRid(_normRid(rid0));

    if (meta){
      const ridm = meta.rid || meta.run_id || "";
      const gr   = meta.gate_root || meta.gate_root_id || meta.gate_rootId || "";
      addRid(ridm);
      addRid(_normRid(ridm));
      addRid(gr);
      // sometimes UI shows gate_root without prefix; try also prefixed
      if (gr && !String(gr).startsWith("gate_root_")) addRid("gate_root_" + gr);
      // sometimes rid is actually gate_root-like
      if (ridm && String(ridm).startsWith("gate_root_")) addRid(String(ridm).replace(/^gate_root_/, ""));
    }

    // de-dupe
    const out = [];
    const seen = new Set();
    for (const x of cand){
      if (!seen.has(x)){
        seen.add(x);
        out.push(x);
      }
    }

    // last resort: if we have meta.gate_root_id but original url path missing -> keep it anyway
    return { path, urls: out };
  }

  async function _fetchPreferJson(urls, init){
    let lastResp = null;
    for (const u of urls){
      try{
        const r = await _origFetch(u, init);
        lastResp = r;
        const ct = (r.headers.get("content-type") || "").toLowerCase();
        if (r.ok && (ct.includes("application/json") || ct.includes("+json"))) return r;

        // header may be wrong; peek body
        const t = (await r.clone().text()).trim();
        if (r.ok && (t.startsWith("{") || t.startsWith("["))){
          return new Response(t, { status: 200, headers: { "content-type": "application/json" } });
        }
      }catch(e){
        continue;
      }
    }
    return lastResp || _origFetch(urls[0], init);
  }

  if (!window.__vsp_disable_interceptors_v1) window.fetch = async function(input, init){
    try{
      const url = (typeof input === "string") ? input : (input && input.url ? input.url : "");
      if (!url) return _origFetch(input, init);

      // alias: never rely on degraded demoapp rid_latest
      if (url.includes("/api/vsp/rid_latest_gate_root_gate_root") && !url.includes("rid_latest_gate_root")){
        const u = url.replace("/api/vsp/rid_latest_gate_root_gate_root", "/api/vsp/rid_latest_gate_root_gate_root");
        return _origFetch(u, init);
      }

      // retry resolver for run_file_allow
      if (url.includes("/api/vsp/run_file_allow")){
        const meta = await _getLatestMeta();
        const built = _buildRunFileAllowCandidates(url, meta);
        if (built.urls.length > 1){
          return _fetchPreferJson(built.urls, init);
        }
        return _origFetch(input, init);
      }

      return _origFetch(input, init);
    }catch(e){
      return _origFetch(input, init);
    }
  };
})();

/* VSP_P0_BUNDLE_RID_NORMALIZE_V1
 * Normalize RID variants: VSP_CI_RUN_YYYYmmdd_HHMMSS -> VSP_CI_YYYYmmdd_HHMMSS
 * Also normalize gate_root_* accordingly.
 */
(()=> {
  if (window.__vsp_p0_bundle_rid_normalize_v1) return;
  window.__vsp_p0_bundle_rid_normalize_v1 = true;

  const _fetch = window.fetch ? window.fetch.bind(window) : null;
  if (!_fetch) return;

  function normRidStr(x){
    try{
      let t = String(x||"");
      t = t.replace("VSP_CI_RUN_", "VSP_CI_").replace("_RUN_", "_");
      t = t.replace("gate_root_VSP_CI_RUN_", "gate_root_VSP_CI_");
      t = t.replace("gate_root_VSP_CI_", "gate_root_VSP_CI_"); // idempotent
      return t;
    }catch(e){ return x; }
  }

  function rewriteUrl(u){
    try{
      const url = String(u||"");
      // normalize any embedded rid/gate_root text in URL
      return normRidStr(url);
    }catch(e){
      return u;
    }
  }

  if (!window.__vsp_disable_interceptors_v1) window.fetch = function(input, init){
    if (typeof input === "string") {
      return _fetch(rewriteUrl(input), init);
    }
    if (input && typeof input === "object" && input.url) {
      try {
        const nu = rewriteUrl(input.url);
        if (nu !== input.url) input = new Request(nu, input);
      } catch (e) {}
    }
    return _fetch(input, init);
  };
})();

/* VSP_P0_BUNDLE_FETCH_ALIAS_RIDLATEST_V1 */
(()=> {
  if (window.__vsp_p0_bundle_fetch_alias_ridlatest_v1) return;
  window.__vsp_p0_bundle_fetch_alias_ridlatest_v1 = true;
  const _fetch = window.fetch ? window.fetch.bind(window) : null;
  if (!_fetch) return;

  function rw(u){
    const url = String(u||"");
    if (/\/api\/vsp\/rid_latest(\?|$)/.test(url) || /\/api\/vsp\/latest_rid(\?|$)/.test(url)) {
      return url.replace(/\/api\/vsp\/(rid_latest|latest_rid)(\?|$)/, "/api/vsp/rid_latest_gate_root_gate_root$2");
    }
    if (url.includes("/api/vsp/rid_latest_gate_root_gate_root")) {
      return url.replace("/api/vsp/rid_latest_gate_root_gate_root", "/api/vsp/rid_latest_gate_root_gate_root");
    }
    return url;
  }

  if (!window.__vsp_disable_interceptors_v1) window.fetch = function(input, init){
    if (typeof input === "string") return _fetch(rw(input), init);
    if (input && typeof input === "object" && input.url) {
      try { const nu = rw(input.url); if (nu !== input.url) input = new Request(nu, input); } catch(e){}
    }
    return _fetch(input, init);
  };
})();


/* VSP_P0_BUNDLE_BOOT_FETCH_REWRITE_V3
   IMPORTANT: do NOT rewrite /api/vsp/rid_latest_gate_root_gate_root (it returns KPI counts_total payload).
   - Bootstrap RID+gate_root from /api/vsp/rid_latest_gate_root_gate_root
   - Rewrite ONLY /api/vsp/rid_latest_gate_root_gate_root* (fetch + XHR) -> /api/vsp/rid_latest_gate_root_gate_root
*/
(()=> {
  try{
    if (window.__vsp_p0_bundle_boot_fetch_rewrite_v3) return;
    window.__vsp_p0_bundle_boot_fetch_rewrite_v3 = true;

    const CANON = "/api/vsp/rid_latest_gate_root_gate_root";
    const REWRITE_PAT = /\/api\/vsp\/latest_rid\b|\/api\/vsp\/latest_rid_/i; // NOT rid_latest

    const toCanon = (url) => {
      try{
        const u = new URL(url, location.origin);
        u.pathname = CANON;
        u.search = "";
        return u.toString();
      }catch(e){
        return CANON;
      }
    };

    // fetch hook
    const _fetch = window.fetch ? window.fetch.bind(window) : null;
    if (_fetch){
      if (!window.__vsp_disable_interceptors_v1) window.fetch = async (input, init) => {
        try{
          const url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
          if (url && REWRITE_PAT.test(url)) return _fetch(toCanon(url), init);
        }catch(e){}
        return _fetch(input, init);
      };
    }

    // XHR hook (axios / old code)
    const _open = XMLHttpRequest && XMLHttpRequest.prototype && XMLHttpRequest.prototype.open;
    if (_open){
      if (!window.__vsp_disable_interceptors_v1) XMLHttpRequest.prototype.open = function(method, url){
        try{
          if (url && typeof url === "string" && REWRITE_PAT.test(url)) {
            url = toCanon(url);
          }
        }catch(e){}
        return _open.apply(this, [method, url, ...[].slice.call(arguments, 2)]);
      };
    }

    async function bootstrap(){
      if (!_fetch) return;
      try{
        const r = await _fetch(CANON, {cache:"no-store"});
        if (!r.ok) return;
        const j = await r.json().catch(()=>null);
        const rid = j && (j.rid || j.run_id) ? (j.rid || j.run_id) : "";
        const gate_root = j && j.gate_root ? j.gate_root : "";
        if (!rid) return;

        const keys = [
          "vsp_rid","vsp_last_rid","vsp_last_good_rid_v1",
          "vsp5_rid","vsp5.rid","VSP_RID","VSP_LAST_RID",
        ];
        try{ keys.forEach(k=>localStorage.setItem(k, rid)); }catch(e){}
        if (gate_root){
          const gkeys = ["vsp_gate_root","vsp5_gate_root","VSP_GATE_ROOT"];
          try{ gkeys.forEach(k=>localStorage.setItem(k, gate_root)); }catch(e){}
        }

        window.__vsp_rid = rid;
        window.__vsp_gate_root = gate_root || null;

        try{ window.dispatchEvent(new CustomEvent("vsp:rid", {detail:{rid, gate_root}})); }catch(e){}
        try{ window.dispatchEvent(new CustomEvent("vsp:gate_root", {detail:{rid, gate_root}})); }catch(e){}

        console.log("[VSP][P0] boot rid=", rid, "gate_root=", gate_root || "(none)");
      }catch(e){}
    }

    bootstrap();
    setTimeout(bootstrap, 800);
  }catch(e){}
})();


/* VSP_P0_RID_AUTOFIX_LOADER_V1 */
(()=> {
/* ===================== VSP_P1_CLIENT_RUNFILEALLOW_FALLBACK_V1 =====================
   Commercial UX: fallback reports/<file> <-> <file> for run_file_allow; no console spam.
================================================================================== */
window.__vsp_runfileallow_fetch_v1 = window.__vsp_runfileallow_fetch_v1 || (async function(opts){
  // opts: { base, rid, path, acceptJson=true }
  const base = (opts && opts.base) || "";
  const rid  = (opts && opts.rid)  || "";
  const path = (opts && opts.path) || "";
  const acceptJson = (opts && opts.acceptJson) !== false;

  const norm = (x)=> (x||"").replace(/\\/g,"/").replace(/^\/+/,"");
  const p0 = norm(path);

  // Build fallback candidates:
  // - if reports/... then try root
  // - else try reports/...
  const cands = [p0];
  if (p0.startsWith("reports/")) cands.push(p0.slice("reports/".length));
  else cands.push("reports/" + p0);

  // de-dupe
  const uniq = [];
  for (const c of cands) if (c && !uniq.includes(c)) uniq.push(c);

  const mk = (pp)=> `${base}/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=${encodeURIComponent(pp)}`;

  let lastErr = null;
  for (const pp of uniq){
    try{
      const r = await fetch(mk(pp), { credentials:"same-origin" });
      if (!r.ok) { lastErr = new Error(`HTTP ${r.status} for ${pp}`); continue; }
      if (!acceptJson) return { ok:true, path:pp, resp:r, data:null };
      const ct = (r.headers.get("content-type")||"").toLowerCase();
      if (ct.includes("application/json")) return { ok:true, path:pp, resp:r, data: await r.json() };
      // if server returns json-as-text, try parse
      const tx = await r.text();
      try { return { ok:true, path:pp, resp:r, data: JSON.parse(tx) }; } catch(e){ return { ok:true, path:pp, resp:r, data: tx }; }
    }catch(e){
      lastErr = e;
    }
  }
  return { ok:false, err: (lastErr && (lastErr.message||String(lastErr))) || "fetch failed", tried: uniq };
});

window.__vsp_badge_degraded_v1 = window.__vsp_badge_degraded_v1 || (function(msg){
  try{
    const id = "vsp_degraded_badge_v1";
    let el = document.getElementById(id);
    if (!el){
      el = document.createElement("div");
      el.id = id;
      el.style.cssText = "position:fixed;right:12px;bottom:12px;z-index:9999;background:#2a0f12;border:1px solid #7a2a33;color:#ffb3bd;padding:8px 10px;border-radius:10px;font:12px/1.3 system-ui,Segoe UI,Arial;box-shadow:0 10px 30px rgba(0,0,0,.35);max-width:360px";
      document.body.appendChild(el);
    }
    el.textContent = msg || "DEGRADED: missing artifact";
    clearTimeout(window.__vsp_degraded_badge_t);
    window.__vsp_degraded_badge_t = setTimeout(()=>{ try{ el.remove(); }catch(e){} }, 6500);
  }catch(e){}
});

/* Soft-wrap fetch calls to run_file_allow for core artifacts */
window.__vsp_runfileallow_softwrap_v1 = window.__vsp_runfileallow_softwrap_v1 || (function(){
  if (window.__vsp_runfileallow_softwrap_v1_done) return;
  window.__vsp_runfileallow_softwrap_v1_done = true;

  const origFetch = window.fetch;
  if (!window.__vsp_disable_interceptors_v1) window.fetch = async function(input, init){
    try{
      const url = (typeof input === "string") ? input : (input && input.url) || "";
      if (url.includes("/api/vsp/run_file_allow?") && url.includes("path=")){
        // Only apply to the 4 files we care about most (avoid breaking other exports)
        const u = new URL(url, window.location.origin);
        const rid = u.searchParams.get("rid") || "";
        const path = u.searchParams.get("path") || "";
        const p = (path||"").replace(/\\/g,"/").replace(/^\/+/,"");

        const core = new Set([
          "run_gate_summary.json","reports/run_gate_summary.json",
          "run_gate.json","reports/run_gate.json",
        ]);

        if (core.has(p)){
          const res = await window.__vsp_runfileallow_fetch_v1({ base:"", rid, path:p, acceptJson:false });
          if (res && res.ok && res.resp) return res.resp;
          // degrade silently, return original fetch result (may be 403/404) but without throwing
          try{ window.__vsp_badge_degraded_v1(`DEGRADED: cannot load ${p} (${(res&&res.err)||"err"})`); }catch(e){}
          return origFetch.apply(this, arguments);
        }
      }
    }catch(e){
      // no spam
    }
    return origFetch.apply(this, arguments);
  };
})();
  try{
    if (window.__vsp_p0_rid_autofix_loader_v1) return;
    window.__vsp_p0_rid_autofix_loader_v1 = true;

    // already loaded?
    if (document.querySelector('script[src*="vsp_rid_autofix_v1.js"]')) return;

    // reuse asset_v from current bundle query (?v=...)
    let v = "";
    try{
      const srcs = Array.from(document.scripts).map(x=>x && x.src ? x.src : "");
      const me = srcs.find(u => u.includes("vsp_bundle_commercial_v2.js"));
      const m = me && me.match(/[?&]v=([^&]+)/);
      v = (m && m[1]) ? m[1] : "";
    }catch(e){}

    if (!v) v = String(Date.now());

    const sc = document.createElement("script");
    sc.src = "/static/js/vsp_rid_autofix_v1.js?v=" + encodeURIComponent(v);
    sc.defer = true;
    document.head.appendChild(sc);
  }catch(e){}
})();

/* VSP_P1_GATE_FETCH_FORCE_GATE_ROOT_V2
 * Force gate fetch to use rid_latest_gate_root and path=run_gate_summary.json.
 * Hooks BOTH fetch + XMLHttpRequest.
 */
(()=> {
  if (window.__vsp_gate_fetch_force_gate_root_v2) return;
  window.__vsp_gate_fetch_force_gate_root_v2 = true;

  const LS_GATE_ROOT = 'vsp_rid_latest_gate_root_v1';
  const LS_LATEST    = 'vsp_rid_latest_v1';

  function _log(){ try{ console.log.apply(console, arguments); }catch(_){ } }

  async function getGateRootRid(){
    try{
      if (window.vsp_rid_latest_gate_root && String(window.vsp_rid_latest_gate_root).trim()){
        return String(window.vsp_rid_latest_gate_root).trim();
      }
      const ls = localStorage.getItem(LS_GATE_ROOT);
try{ if (typeof rid==="string" && rid.startsWith("RUN_")) rid=""; }catch(_){ }
      if (ls && String(ls).trim()){
        window.vsp_rid_latest_gate_root = String(ls).trim();
        return window.vsp_rid_latest_gate_root;
      }
      const r = await fetch('/api/vsp/runs?limit=5', {cache:'no-store'});
      const j = await r.json().catch(()=>null);
      const rid = (j && (j.rid_latest_gate_root || j.rid_latest_gate || j.rid_latest)) ? String(j.rid_latest_gate_root || j.rid_latest_gate || j.rid_latest).trim() : '';
      if (rid){
/* HARD_DISABLED_V6D */
return; // hard-disabled

/* HARD_DISABLED_V6C */
return; // hard-disabled

/* HARD_DISABLED_V6E */
return; // hard-disabled

if (window.__vsp_disable_legacy_dash_v1) { /* disabled: DASH_V6E */ return; }

        window.vsp_rid_latest_gate_root = rid;
        try{ localStorage.setItem(LS_GATE_ROOT, rid); }catch(_){}
        try{ localStorage.setItem(LS_LATEST, rid); }catch(_){}
      }
      return rid || '';
    }catch(_){
      return '';
    }
  }

  function isGatePath(path){
    path = (path||"").trim();
    return (
      path === 'run_gate.json' ||
      path === 'run_gate_summary.json' ||
      path === 'reports/run_gate.json' ||
      path === 'reports/run_gate_summary.json'
    );
  }

  function rewriteUrl(u, rid){
    try{
      const url = new URL(u, window.location.origin);
      if (!url.pathname.includes('/api/vsp/run_file_allow')) return u;
      const path = (url.searchParams.get('path')||'').trim();
      if (!isGatePath(path)) return u;

      url.searchParams.set('path', 'run_gate_summary.json');
      if (rid && rid.trim()) url.searchParams.set('rid', rid.trim());
      return url.toString();
    }catch(_){
      return u;
    }
  }

  // ---- hook fetch ----
  const _origFetch = window.fetch ? window.fetch.bind(window) : null;
  if (_origFetch){
    if (!window.__vsp_disable_interceptors_v1) window.fetch = async function(input, init){
      try{
        const u = (typeof input === 'string') ? input : (input && input.url ? input.url : '');
        if (u && u.includes('/api/vsp/run_file_allow') && u.includes('path=')){
          const rid = await getGateRootRid();
          const u2 = rewriteUrl(u, rid);
          if (u2 !== u){
            _log("[GateStoryV1][%s] fetch rewrite => %s", "VSP_P1_GATE_FETCH_FORCE_GATE_ROOT_V2", u2);
            if (typeof input === 'string') input = u2;
            else input = new Request(u2, input);
          }
        }
      }catch(_){}
      return _origFetch(input, init);
    };
  }

  // ---- hook XHR ----
  try{
    const _open = XMLHttpRequest.prototype.open;
    if (!window.__vsp_disable_interceptors_v1) XMLHttpRequest.prototype.open = function(method, url){
      try{
        if (url && String(url).includes('/api/vsp/run_file_allow') && String(url).includes('path=')){
          const u = String(url);
          let rid = '';
          try{ rid = (window.vsp_rid_latest_gate_root || localStorage.getItem(LS_GATE_ROOT) || '').trim(); }catch(_){}
          const u2 = rewriteUrl(u, rid || '');
          if (u2 !== u){
            _log("[GateStoryV1][%s] xhr rewrite => %s", "VSP_P1_GATE_FETCH_FORCE_GATE_ROOT_V2", u2);
            url = u2;
          }
        }
      }catch(_){}
      return _open.apply(this, arguments);
    };
  }catch(_){}

  _log("[GateStoryV1][%s] installed", "VSP_P1_GATE_FETCH_FORCE_GATE_ROOT_V2");
})();

/* VSP_P0_FIX_BUNDLE_V2_UNEXPECTED_STRING_V1 */
/* VSP_DISABLE_LEGACY_DASH_ON_VSP5_V1 */
try{ if (String(location.pathname||"").includes("/vsp5")) { /* no legacy dash on vsp5 */ } }catch(_){ }

/* VSP_FETCH_DESCRIPTOR_SAFE_P0_V1 */
(function(){
  try{
    if (window.__vsp_fetch_descriptor_safe_p0_v1) return;
    window.__vsp_fetch_descriptor_safe_p0_v1 = true;

    function canOverrideFetch(){
      try{
        const d = Object.getOwnPropertyDescriptor(window, "fetch");
        if (!d) return true;
        // if accessor exists, allow (setter may exist)
        if (d.get || d.set) return true;
        // data descriptor: must be writable OR configurable to redefine
        if (d.writable) return true;
        if (d.configurable) return true;
        return false;
      }catch(_){ return false; }
    }

    // Provide a helper for other wrappers to use
    window.__vsp_can_override_fetch = canOverrideFetch;

    // If someone already wrapped fetch and locked it, don't crash future code.
    // We DO NOT wrap here; we only prevent TypeError by advising wrappers to check __vsp_can_override_fetch().
  }catch(_){}
})();




// VSP_P1_DASH_RENDER_V6C_IN_BUNDLE
(function(){
  if (window.__VSP_DASH_RENDER_V6C) return;
  window.__VSP_DASH_RENDER_V6C = true;

  function ensureCanvas(holderId){
    var el = document.getElementById(holderId);
    if (!el) return null;
    var tag = (el.tagName||"").toLowerCase();
    if (tag === "canvas") return el;
    var c = el.querySelector && el.querySelector("canvas");
    if (!c){
      c = document.createElement("canvas");
      c.style.width="100%";
      c.style.height="260px";
      el.innerHTML="";     // clear placeholder
      el.appendChild(c);
    }
    return c;
  }

  async function getRid(){
    try{
      var u = new URL(window.location.href);
      var rid = u.searchParams.get("rid");
      if (rid) return rid;
    }catch(e){}
    try{
      var r = await fetch("/api/vsp/runs?limit=1", {cache:"no-store"});
      var j = await r.json();
      
/* VSP_P1_PREFER_GATE_ROOT_V1 */
try{
  if (j && j.rid_latest_gate_root){
    j.__vsp_prefer_gate_root = true;
    j.__vsp_gate_root = j.rid_latest_gate_root;
    // Force pickers that prefer last_good/latest to land on CI gate_root
    j.rid_last_good = j.rid_latest_gate_root;
    j.rid_latest = j.rid_latest_gate_root;
    console.log("[VSP][GateStory] prefer gate_root:", j.rid_latest_gate_root);
  }
}catch(e){
  console.warn("[VSP][GateStory] prefer gate_root inject err", e);
}
if (j && j.items && j.items[0] && j.items[0].run_id) return j.items[0].run_id;
    }catch(e){}
    return "";
  }

  function parseDonut(j){
    if (j?.charts?.severity?.donut) return j.charts.severity.donut;
    if (j?.donut?.labels && j?.donut?.values) return j.donut;
    if (Array.isArray(j?.severity_distribution))
      return { labels: j.severity_distribution.map(x=>x.sev), values: j.severity_distribution.map(x=>x.count) };
    return null;
  }
  function parseTrend(j){
    if (j?.charts?.trend?.series) return j.charts.trend.series;
    if (j?.trend?.labels && j?.trend?.values) return j.trend;
    if (Array.isArray(j?.findings_trend))
      return { labels: j.findings_trend.map(x=>x.rid), values: j.findings_trend.map(x=>x.total) };
    return null;
  }
  function parseBarCritHigh(j){
    if (j?.charts?.crit_high_by_tool?.bar) return j.charts.crit_high_by_tool.bar;
    if (j?.bar_crit_high?.labels) return j.bar_crit_high;
    if (Array.isArray(j?.critical_high_by_tool)){
      var labels = j.critical_high_by_tool.map(x=>x.tool);
      var crit = j.critical_high_by_tool.map(x=>x.critical||0);
      var high = j.critical_high_by_tool.map(x=>x.high||0);
      return { labels: labels, series: [{name:"CRITICAL",data:crit},{name:"HIGH",data:high}] };
    }
    return null;
  }
  function parseTopCwe(j){
    if (j?.charts?.top_cwe?.series) return j.charts.top_cwe.series;
    if (j?.top_cwe?.labels && j?.top_cwe?.values) return j.top_cwe;
    if (Array.isArray(j?.top_cwe_exposure))
      return { labels: j.top_cwe_exposure.map(x=>x.cwe), values: j.top_cwe_exposure.map(x=>x.count) };
    return { labels: [], values: [] };
  }

  function destroyKey(k){ try{ window[k]?.destroy?.(); }catch(e){} window[k]=null; }

  async function renderOnce(){
    if (!window.Chart) return false;

    var a=document.getElementById("vsp-chart-severity");
    var b=document.getElementById("vsp-chart-trend");
    var c=document.getElementById("vsp-chart-bytool");
    var d=document.getElementById("vsp-chart-topcwe");
    if (!a || !b || !c || !d) return false;

    var rid = await getRid();
    if (!rid) return false;

    var resp = await fetch("/api/vsp/dash_charts?rid="+encodeURIComponent(rid), {cache:"no-store"});
    var j = await resp.json();

    var donut=parseDonut(j), trend=parseTrend(j), bar=parseBarCritHigh(j), top=parseTopCwe(j);

    var c1=ensureCanvas("vsp-chart-severity");
    if (c1 && donut){
      destroyKey("__VSP_DONUT_V6C");
      window.__VSP_DONUT_V6C = new Chart(c1, {type:"doughnut",
        data:{labels:donut.labels,datasets:[{data:donut.values}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}}}
      });
    }

    var c2=ensureCanvas("vsp-chart-trend");
    if (c2 && trend){
      destroyKey("__VSP_TREND_V6C");
      window.__VSP_TREND_V6C = new Chart(c2, {type:"line",
        data:{labels:trend.labels,datasets:[{data:trend.values}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}}}
      });
    }

    var c3=ensureCanvas("vsp-chart-bytool");
    if (c3 && bar){
      destroyKey("__VSP_BYTOOL_V6C");
      var s0=bar.series?.[0]?.data||[], s1=bar.series?.[1]?.data||[];
      window.__VSP_BYTOOL_V6C = new Chart(c3, {type:"bar",
        data:{labels:bar.labels,datasets:[{label:"CRITICAL",data:s0},{label:"HIGH",data:s1}]},
        options:{responsive:true,maintainAspectRatio:false}
      });
    }

    var c4=ensureCanvas("vsp-chart-topcwe");
    if (c4 && top){
      destroyKey("__VSP_TOPCWE_V6C");
      window.__VSP_TOPCWE_V6C = new Chart(c4, {type:"bar",
        data:{labels:top.labels,datasets:[{data:top.values}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}}}
      });
    }

    console.log("[VSP][DASH][V6C] rendered rid=", rid);
    return true;
  }

  var tries=0;
  var t=setInterval(function(){
    tries++;
    renderOnce().then(function(ok){
      if (ok || tries>=20){
        clearInterval(t);
        if (!ok) console.warn("[VSP][DASH] legacy disabled (V6C) (Chart/container missing)");
      }
    }).catch(function(e){
      if (tries>=20){ clearInterval(t); console.warn("[VSP][DASH][V6C] error", e); }
    });
  }, 500);
})();




// VSP_P1_DASH_CANVAS_FALLBACK_V6D
(function(){
  if (window.__VSP_DASH_RENDER_V6D) return;
  window.__VSP_DASH_RENDER_V6D = true;

  function ensureCanvas(holderId){
    var el = document.getElementById(holderId);
    if (!el) return null;
    var tag = (el.tagName||"").toLowerCase();
    if (tag === "canvas") return el;

    var c = el.querySelector && el.querySelector("canvas");
    if (!c){
      c = document.createElement("canvas");
      c.width = 900; c.height = 300;
      c.style.width="100%";
      c.style.height="260px";
      el.innerHTML=""; // clear placeholder
      el.appendChild(c);
    }
    return c;
  }

  async function getRid(){
    try{
      var u = new URL(window.location.href);
      var rid = u.searchParams.get("rid");
      if (rid) return rid;
    }catch(e){}
    try{
      var r = await fetch("/api/vsp/runs?limit=1", {cache:"no-store"});
      var j = await r.json();
      if (j && j.items && j.items[0] && j.items[0].run_id) return j.items[0].run_id;
    }catch(e){}
    return "";
  }

  function parseDonut(j){
    if (j?.charts?.severity?.donut) return j.charts.severity.donut;
    if (j?.donut?.labels && j?.donut?.values) return j.donut;
    if (Array.isArray(j?.severity_distribution))
      return { labels: j.severity_distribution.map(x=>x.sev), values: j.severity_distribution.map(x=>x.count) };
    return null;
  }
  function parseTrend(j){
    if (j?.charts?.trend?.series) return j.charts.trend.series;
    if (j?.trend?.labels && j?.trend?.values) return j.trend;
    if (Array.isArray(j?.findings_trend))
      return { labels: j.findings_trend.map(x=>x.rid), values: j.findings_trend.map(x=>x.total) };
    return null;
  }
  function parseBarCritHigh(j){
    if (j?.charts?.crit_high_by_tool?.bar) return j.charts.crit_high_by_tool.bar;
    if (j?.bar_crit_high?.labels) return j.bar_crit_high;
    if (Array.isArray(j?.critical_high_by_tool)){
      var labels = j.critical_high_by_tool.map(x=>x.tool);
      var crit = j.critical_high_by_tool.map(x=>x.critical||0);
      var high = j.critical_high_by_tool.map(x=>x.high||0);
      return { labels: labels, series: [{name:"CRITICAL",data:crit},{name:"HIGH",data:high}] };
    }
    return null;
  }
  function parseTopCwe(j){
    if (j?.charts?.top_cwe?.series) return j.charts.top_cwe.series;
    if (j?.top_cwe?.labels && j?.top_cwe?.values) return j.top_cwe;
    if (Array.isArray(j?.top_cwe_exposure))
      return { labels: j.top_cwe_exposure.map(x=>x.cwe), values: j.top_cwe_exposure.map(x=>x.count) };
    return { labels: [], values: [] };
  }

  // ---- Canvas drawing helpers (no Chart.js) ----
  function ctx2d(canvas){
    var ctx = canvas.getContext("2d");
    var w = canvas.width, h = canvas.height;
    // handle hiDPI
    var dpr = window.devicePixelRatio || 1;
    var cssW = canvas.clientWidth || w;
    var cssH = canvas.clientHeight || h;
    canvas.width = Math.max(300, Math.floor(cssW * dpr));
    canvas.height = Math.max(200, Math.floor(cssH * dpr));
    ctx.setTransform(dpr,0,0,dpr,0,0);
    return ctx;
  }

  function clear(ctx, w, h){
    ctx.clearRect(0,0,w,h);
    // subtle grid bg
    ctx.globalAlpha = 0.08;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0,0,w,h);
    ctx.globalAlpha = 1;
  }

  function textCenter(ctx, w, h, msg){
    ctx.save();
    ctx.fillStyle = "rgba(255,255,255,0.75)";
    ctx.font = "12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(msg, w/2, h/2);
    ctx.restore();
  }

  function drawDonut(canvas, labels, values){
    var ctx = ctx2d(canvas);
    var w = canvas.clientWidth || 900, h = canvas.clientHeight || 260;
    clear(ctx, w, h);
    var total = values.reduce((a,b)=>a+(+b||0),0);
    if (!total){ textCenter(ctx,w,h,"No data"); return; }

    var cx=w/2, cy=h/2, r=Math.min(w,h)*0.32, rIn=r*0.55;
    var ang=-Math.PI/2;

    var palette=["#ef4444","#f59e0b","#3b82f6","#22c55e","#a855f7","#94a3b8"];
    for (var i=0;i<values.length;i++){
      var v=+values[i]||0;
      var a=(v/total)*Math.PI*2;
      ctx.beginPath();
      ctx.moveTo(cx,cy);
      ctx.fillStyle=palette[i%palette.length];
      ctx.globalAlpha=0.85;
      ctx.arc(cx,cy,r,ang,ang+a);
      ctx.closePath();
      ctx.fill();
      ang+=a;
    }
    // hole
    ctx.globalAlpha=1;
    ctx.beginPath();
    ctx.fillStyle="rgba(0,0,0,0.55)";
    ctx.arc(cx,cy,rIn,0,Math.PI*2);
    ctx.fill();

    // center text
    ctx.fillStyle="rgba(255,255,255,0.85)";
    ctx.font="bold 16px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.textAlign="center"; ctx.textBaseline="middle";
    ctx.fillText(String(total), cx, cy-2);
    ctx.font="12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.fillStyle="rgba(255,255,255,0.7)";
    ctx.fillText("total", cx, cy+16);
  }

  function drawLine(canvas, labels, values){
    var ctx = ctx2d(canvas);
    var w = canvas.clientWidth || 900, h = canvas.clientHeight || 260;
    clear(ctx, w, h);
    if (!values || !values.length){ textCenter(ctx,w,h,"No data"); return; }

    var padL=46, padR=14, padT=14, padB=30;
    var plotW=w-padL-padR, plotH=h-padT-padB;

    var maxV=Math.max.apply(null, values.map(v=>+v||0));
    var minV=Math.min.apply(null, values.map(v=>+v||0));
    if (maxV===minV) maxV=minV+1;

    // axes
    ctx.strokeStyle="rgba(255,255,255,0.18)";
    ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(padL,padT);
    ctx.lineTo(padL,padT+plotH);
    ctx.lineTo(padL+plotW,padT+plotH);
    ctx.stroke();

    // line
    ctx.strokeStyle="rgba(59,130,246,0.9)";
    ctx.lineWidth=2;
    ctx.beginPath();
    for (var i=0;i<values.length;i++){
      var x = padL + (i/(Math.max(1,values.length-1)))*plotW;
      var y = padT + (1-((+values[i]||0)-minV)/(maxV-minV))*plotH;
      if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    }
    ctx.stroke();

    // points
    ctx.fillStyle="rgba(59,130,246,0.95)";
    for (var i=0;i<values.length;i++){
      var x = padL + (i/(Math.max(1,values.length-1)))*plotW;
      var y = padT + (1-((+values[i]||0)-minV)/(maxV-minV))*plotH;
      ctx.beginPath(); ctx.arc(x,y,3,0,Math.PI*2); ctx.fill();
    }

    // y labels
    ctx.fillStyle="rgba(255,255,255,0.7)";
    ctx.font="12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.textAlign="right"; ctx.textBaseline="middle";
    ctx.fillText(String(maxV), padL-8, padT);
    ctx.fillText(String(minV), padL-8, padT+plotH);
  }

  function drawBars(canvas, labels, s0, s1){
    var ctx = ctx2d(canvas);
    var w = canvas.clientWidth || 900, h = canvas.clientHeight || 260;
    clear(ctx, w, h);
    if (!labels || !labels.length){ textCenter(ctx,w,h,"No data"); return; }

    var padL=46, padR=14, padT=14, padB=30;
    var plotW=w-padL-padR, plotH=h-padT-padB;

    var maxV=0;
    for (var i=0;i<labels.length;i++){
      maxV=Math.max(maxV, (+s0[i]||0)+(+s1[i]||0), (+s0[i]||0), (+s1[i]||0));
    }
    if (!maxV) maxV=1;

    // axes
    ctx.strokeStyle="rgba(255,255,255,0.18)";
    ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(padL,padT);
    ctx.lineTo(padL,padT+plotH);
    ctx.lineTo(padL+plotW,padT+plotH);
    ctx.stroke();

    var n=labels.length;
    var groupW = plotW / n;
    var barW = Math.max(6, groupW*0.28);

    for (var i=0;i<n;i++){
      var x0 = padL + i*groupW + groupW*0.18;
      var v0 = +s0[i]||0;
      var v1 = +s1[i]||0;

      var h0 = (v0/maxV)*plotH;
      var h1 = (v1/maxV)*plotH;

      // critical
      ctx.fillStyle="rgba(239,68,68,0.85)";
      ctx.fillRect(x0, padT+plotH-h0, barW, h0);

      // high (next to)
      ctx.fillStyle="rgba(245,158,11,0.85)";
      ctx.fillRect(x0+barW+4, padT+plotH-h1, barW, h1);
    }
  }

  async function renderOnce(){
    var a=document.getElementById("vsp-chart-severity");
    var b=document.getElementById("vsp-chart-trend");
    var c=document.getElementById("vsp-chart-bytool");
    var d=document.getElementById("vsp-chart-topcwe");
    if (!a || !b || !c || !d) return false;

    var rid = await getRid();
    if (!rid) return false;

    var resp = await fetch("/api/vsp/dash_charts?rid="+encodeURIComponent(rid), {cache:"no-store"});
    var j = await resp.json();

    var donut=parseDonut(j);
    var trend=parseTrend(j);
    var bar=parseBarCritHigh(j);
    var top=parseTopCwe(j);

    // DONUT
    var c1=ensureCanvas("vsp-chart-severity");
    if (c1 && donut) drawDonut(c1, donut.labels||[], donut.values||[]);

    // TREND
    var c2=ensureCanvas("vsp-chart-trend");
    if (c2 && trend) drawLine(c2, trend.labels||[], trend.values||[]);

    // BYTOOL
    var c3=ensureCanvas("vsp-chart-bytool");
    if (c3 && bar){
      var s0 = bar.series?.[0]?.data || [];
      var s1 = bar.series?.[1]?.data || [];
      drawBars(c3, bar.labels||[], s0, s1);
    }

    // TOPCWE (single series)
    var c4=ensureCanvas("vsp-chart-topcwe");
    if (c4 && top){
      drawBars(c4, top.labels||[], top.values||[], new Array((top.labels||[]).length).fill(0));
    }

    console.log("[VSP][DASH][V6D] canvas-rendered rid=", rid, "ChartJS=", !!window.Chart);
    return true;
  }

  var tries=0;
  var t=setInterval(function(){
    tries++;
    renderOnce().then(function(ok){
      if (ok || tries>=20){
        clearInterval(t);
        if (!ok) console.warn("[VSP][DASH] legacy disabled (V6D): containers/rid missing");
      }
    }).catch(function(e){
      if (tries>=20){ clearInterval(t); console.warn("[VSP][DASH][V6D] error", e); }
    });
  }, 500);
})();




// VSP_P1_DASH_RID_RESOLVER_CANVAS_V6E
(function(){
  if (window.__VSP_DASH_V6E) return;
  window.__VSP_DASH_V6E = true;

  function qs(id){ return document.getElementById(id); }

  function ensureCanvas(holderId){
    var el = qs(holderId);
    if (!el) return null;
    if ((el.tagName||"").toLowerCase()==="canvas") return el;
    var c = el.querySelector && el.querySelector("canvas");
    if (!c){
      c=document.createElement("canvas");
      c.style.width="100%";
      c.style.height="260px";
      el.innerHTML="";
      el.appendChild(c);
    }
    return c;
  }

  function setupCtx(canvas){
    var ctx=canvas.getContext("2d");
    var dpr=window.devicePixelRatio||1;
    var w=Math.max(320, canvas.clientWidth||900);
    var h=Math.max(220, canvas.clientHeight||260);
    canvas.width=Math.floor(w*dpr);
    canvas.height=Math.floor(h*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    return {ctx,w,h};
  }

  function clearBg(ctx,w,h){
    ctx.clearRect(0,0,w,h);
    ctx.fillStyle="rgba(255,255,255,0.03)";
    ctx.fillRect(0,0,w,h);
  }

  function drawText(ctx,w,h,msg){
    ctx.fillStyle="rgba(255,255,255,0.75)";
    ctx.font="12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.textAlign="center"; ctx.textBaseline="middle";
    ctx.fillText(msg, w/2, h/2);
  }

  function drawDonut(canvas, labels, values){
    var o=setupCtx(canvas), ctx=o.ctx, w=o.w, h=o.h;
    clearBg(ctx,w,h);
    var total=(values||[]).reduce((a,b)=>a+(+b||0),0);
    if (!total){ drawText(ctx,w,h,"No data"); return; }
    var cx=w/2, cy=h/2, r=Math.min(w,h)*0.32, rIn=r*0.55;
    var ang=-Math.PI/2;
    var pal=["#ef4444","#f59e0b","#3b82f6","#22c55e","#a855f7","#94a3b8"];
    for (var i=0;i<values.length;i++){
      var v=+values[i]||0, a=(v/total)*Math.PI*2;
      ctx.beginPath(); ctx.moveTo(cx,cy);
      ctx.fillStyle=pal[i%pal.length];
      ctx.globalAlpha=0.85;
      ctx.arc(cx,cy,r,ang,ang+a);
      ctx.closePath(); ctx.fill();
      ang+=a;
    }
    ctx.globalAlpha=1;
    ctx.beginPath(); ctx.fillStyle="rgba(0,0,0,0.55)";
    ctx.arc(cx,cy,rIn,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="rgba(255,255,255,0.85)";
    ctx.font="bold 16px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.textAlign="center"; ctx.textBaseline="middle";
    ctx.fillText(String(total), cx, cy-2);
    ctx.font="12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.fillStyle="rgba(255,255,255,0.65)";
    ctx.fillText("total", cx, cy+16);
  }

  function drawLine(canvas, labels, values){
    var o=setupCtx(canvas), ctx=o.ctx, w=o.w, h=o.h;
    clearBg(ctx,w,h);
    if (!values || !values.length){ drawText(ctx,w,h,"No data"); return; }
    var padL=46,padR=14,padT=14,padB=30;
    var pw=w-padL-padR, ph=h-padT-padB;
    var maxV=Math.max.apply(null, values.map(v=>+v||0));
    var minV=Math.min.apply(null, values.map(v=>+v||0));
    if (maxV===minV) maxV=minV+1;

    ctx.strokeStyle="rgba(255,255,255,0.18)";
    ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(padL,padT);
    ctx.lineTo(padL,padT+ph);
    ctx.lineTo(padL+pw,padT+ph);
    ctx.stroke();

    ctx.strokeStyle="rgba(59,130,246,0.9)";
    ctx.lineWidth=2;
    ctx.beginPath();
    for (var i=0;i<values.length;i++){
      var x=padL+(i/(Math.max(1,values.length-1)))*pw;
      var y=padT+(1-((+values[i]||0)-minV)/(maxV-minV))*ph;
      if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    }
    ctx.stroke();
  }

  function drawBars(canvas, labels, a0, a1){
    var o=setupCtx(canvas), ctx=o.ctx, w=o.w, h=o.h;
    clearBg(ctx,w,h);
    if (!labels || !labels.length){ drawText(ctx,w,h,"No data"); return; }
    var padL=46,padR=14,padT=14,padB=30;
    var pw=w-padL-padR, ph=h-padT-padB;
    var maxV=1;
    for (var i=0;i<labels.length;i++){
      maxV=Math.max(maxV, (+a0[i]||0), (+a1[i]||0), (+a0[i]||0)+(+a1[i]||0));
    }

    ctx.strokeStyle="rgba(255,255,255,0.18)";
    ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(padL,padT);
    ctx.lineTo(padL,padT+ph);
    ctx.lineTo(padL+pw,padT+ph);
    ctx.stroke();

    var n=labels.length;
    var gw=pw/n;
    var bw=Math.max(6, gw*0.28);
    for (var i=0;i<n;i++){
      var x0=padL+i*gw+gw*0.18;
      var v0=+a0[i]||0, v1=+a1[i]||0;
      var h0=(v0/maxV)*ph, h1=(v1/maxV)*ph;
      ctx.fillStyle="rgba(239,68,68,0.85)";
      ctx.fillRect(x0, padT+ph-h0, bw, h0);
      ctx.fillStyle="rgba(245,158,11,0.85)";
      ctx.fillRect(x0+bw+4, padT+ph-h1, bw, h1);
    }
  }

  function parse(j){
    var donut=null, trend=null, bar=null, top=null;

    if (Array.isArray(j?.severity_distribution))
      donut={labels:j.severity_distribution.map(x=>x.sev), values:j.severity_distribution.map(x=>x.count)};

    if (Array.isArray(j?.findings_trend))
      trend={labels:j.findings_trend.map(x=>x.rid), values:j.findings_trend.map(x=>x.total)};

    if (Array.isArray(j?.critical_high_by_tool)){
      bar={labels:j.critical_high_by_tool.map(x=>x.tool),
           s0:j.critical_high_by_tool.map(x=>x.critical||0),
           s1:j.critical_high_by_tool.map(x=>x.high||0)};
    }

    if (Array.isArray(j?.top_cwe_exposure))
      top={labels:j.top_cwe_exposure.map(x=>x.cwe), values:j.top_cwe_exposure.map(x=>x.count)};

    return {donut,trend,bar,top};
  }

  function ridFromText(){
    try{
      var t=(document.body && (document.body.innerText||document.body.textContent)||"");
      var m=t.match(/rid_latest\s*=\s*([A-Za-z0-9_\-\.]+)/i) || t.match(/rid_latest\s*:\s*([A-Za-z0-9_\-\.]+)/i);
      return m ? (m[1]||"") : "";
    }catch(e){ return ""; }
  }

  async function resolveRid(){
    // 1) URL param
    try{
      var u=new URL(window.location.href);
      var rid=u.searchParams.get("rid");
      if (rid) return rid;
    }catch(e){}

    // 2) hidden input / element
    var el=qs("vsp_live_rid");
    if (el){
      var v = (el.value!=null ? el.value : "") || (el.textContent||"").trim();
      if (v) return v;
    }

    // 3) text regex (your “OK rid_latest=...”)
    var r3 = ridFromText();
    if (r3) return r3;

    // 4) API fallback
    try{
      var r=await fetch("/api/vsp/runs?limit=1", {cache:"no-store"});
      var j=await r.json();
      var rid2=j?.items?.[0]?.run_id || "";
      return rid2;
    }catch(e){
      return "";
    }
  }

  async function render(){
    // only on /vsp5
    if (!(location.pathname||"").includes("/vsp5")) return false;

    var ids=["vsp-chart-severity","vsp-chart-trend","vsp-chart-bytool","vsp-chart-topcwe"];
    var okIds = ids.every(id=>!!qs(id));
    var rid = await resolveRid();

    console.log("[VSP][DASH] legacy disabled (V6E)=", okIds, "rid=", rid);

    if (!okIds || !rid) return false;

    // fetch charts once
    var resp=await fetch("/api/vsp/dash_charts?rid="+encodeURIComponent(rid), {cache:"no-store"});
    var j=await resp.json();
    var o=parse(j);

    var c1=ensureCanvas("vsp-chart-severity"); if (c1 && o.donut) drawDonut(c1, o.donut.labels, o.donut.values);
    var c2=ensureCanvas("vsp-chart-trend"); if (c2 && o.trend) drawLine(c2, o.trend.labels, o.trend.values);
    var c3=ensureCanvas("vsp-chart-bytool"); if (c3 && o.bar) drawBars(c3, o.bar.labels, o.bar.s0, o.bar.s1);
    var c4=ensureCanvas("vsp-chart-topcwe"); if (c4 && o.top) drawBars(c4, o.top.labels, o.top.values, new Array(o.top.labels.length).fill(0));

    console.log("[VSP][DASH][V6E] rendered rid=", rid);
    return true;
  }

  function start(){
    var tries=0;
    var t=setInterval(function(){
      tries++;
      render().then(function(ok){
        if (ok || tries>=60){ // 30s
          clearInterval(t);
          if (!ok) console.warn("[VSP][DASH][V6E] gave up (rid/ids still missing)");
        }
      }).catch(function(e){
        if (tries>=60){ clearInterval(t); console.warn("[VSP][DASH][V6E] error", e); }
      });
    }, 500);
  }

  if (document.readyState==="complete") start();
  else window.addEventListener("load", start);
})();




// VSP_P1_DASH_RID_WAIT_CANVAS_V6F
(function(){
  if (window.__VSP_DASH_V6F) return;
  window.__VSP_DASH_V6F = true;

  function id(x){ return document.getElementById(x); }

  function extractRidFromText(t){
    if (!t) return "";
    // accept rid_latest: XXX or rid_latest=XXX or FORCE rid=XXX
    var m = String(t).match(/rid_latest\s*[:=]\s*([A-Za-z0-9_\-\.]+)/i) ||
            String(t).match(/FORCE\s*rid\s*=\s*([A-Za-z0-9_\-\.]+)/i);
    return m ? (m[1]||"") : "";
  }

  function isGoodRid(r){
    if (!r) return false;
    if (r === "N/A" || r === "..." || r === "NA") return false;
    if (r.indexOf("rid_latest")>=0) return false;
    if (r.indexOf(":")>=0 || r.indexOf(" ")>=0) return false;
    return true;
  }

  async function resolveRidStrong(){
    // 1) URL param
    try{
      var u=new URL(location.href);
      var rid=u.searchParams.get("rid");
      if (isGoodRid(rid)) return rid;
    }catch(e){}

    // 2) #vsp_live_rid text (it will become: "rid_latest: REAL_RID")
    var el=id("vsp_live_rid");
    if (el){
      var t=(el.value!=null ? el.value : "") || (el.textContent||"");
      var r2 = extractRidFromText(t) || String(t).trim();
      if (isGoodRid(r2)) return r2;
    }

    // 3) badge (if exists)
    var b=id("vsp_rid_latest_badge");
    if (b){
      var r3=extractRidFromText(b.textContent||"");
      if (isGoodRid(r3)) return r3;
    }

    // 4) /api/vsp/runs (best fallback)
    try{
      var r=await fetch("/api/vsp/runs?limit=1", {cache:"no-store"});
      var j=await r.json();
      var ridLatest = j && j.rid_latest ? j.rid_latest : "";
      if (isGoodRid(ridLatest)) return ridLatest;
      var rid0 = j?.items?.[0]?.run_id || "";
      if (isGoodRid(rid0)) return rid0;
    }catch(e){}

    return "";
  }

  function ensureCanvas(holderId){
    var el=id(holderId);
    if (!el) return null;
    if ((el.tagName||"").toLowerCase()==="canvas") return el;
    var c = el.querySelector && el.querySelector("canvas");
    if (!c){
      c=document.createElement("canvas");
      c.style.width="100%";
      c.style.height="260px";
      el.innerHTML="";
      el.appendChild(c);
    }
    return c;
  }

  function setupCtx(canvas){
    var ctx=canvas.getContext("2d");
    var dpr=window.devicePixelRatio||1;
    var w=Math.max(320, canvas.clientWidth||900);
    var h=Math.max(220, canvas.clientHeight||260);
    canvas.width=Math.floor(w*dpr);
    canvas.height=Math.floor(h*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    return {ctx,w,h};
  }
  function clearBg(ctx,w,h){
    ctx.clearRect(0,0,w,h);
    ctx.fillStyle="rgba(255,255,255,0.03)";
    ctx.fillRect(0,0,w,h);
  }
  function textCenter(ctx,w,h,msg){
    ctx.fillStyle="rgba(255,255,255,0.75)";
    ctx.font="12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.textAlign="center"; ctx.textBaseline="middle";
    ctx.fillText(msg, w/2, h/2);
  }
  function drawDonut(canvas, labels, values){
    var o=setupCtx(canvas), ctx=o.ctx, w=o.w, h=o.h;
    clearBg(ctx,w,h);
    var total=(values||[]).reduce((a,b)=>a+(+b||0),0);
    if (!total){ textCenter(ctx,w,h,"No data"); return; }
    var cx=w/2, cy=h/2, r=Math.min(w,h)*0.32, rIn=r*0.55;
    var ang=-Math.PI/2;
    var pal=["#ef4444","#f59e0b","#3b82f6","#22c55e","#a855f7","#94a3b8"];
    for (var i=0;i<values.length;i++){
      var v=+values[i]||0, a=(v/total)*Math.PI*2;
      ctx.beginPath(); ctx.moveTo(cx,cy);
      ctx.fillStyle=pal[i%pal.length];
      ctx.globalAlpha=0.85;
      ctx.arc(cx,cy,r,ang,ang+a);
      ctx.closePath(); ctx.fill();
      ang+=a;
    }
    ctx.globalAlpha=1;
    ctx.beginPath(); ctx.fillStyle="rgba(0,0,0,0.55)";
    ctx.arc(cx,cy,rIn,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="rgba(255,255,255,0.85)";
    ctx.font="bold 16px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.textAlign="center"; ctx.textBaseline="middle";
    ctx.fillText(String(total), cx, cy-2);
    ctx.font="12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    ctx.fillStyle="rgba(255,255,255,0.65)";
    ctx.fillText("total", cx, cy+16);
  }
  function drawLine(canvas, labels, values){
    var o=setupCtx(canvas), ctx=o.ctx, w=o.w, h=o.h;
    clearBg(ctx,w,h);
    if (!values || !values.length){ textCenter(ctx,w,h,"No data"); return; }
    var padL=46,padR=14,padT=14,padB=30;
    var pw=w-padL-padR, ph=h-padT-padB;
    var maxV=Math.max.apply(null, values.map(v=>+v||0));
    var minV=Math.min.apply(null, values.map(v=>+v||0));
    if (maxV===minV) maxV=minV+1;
    ctx.strokeStyle="rgba(255,255,255,0.18)";
    ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(padL,padT); ctx.lineTo(padL,padT+ph); ctx.lineTo(padL+pw,padT+ph);
    ctx.stroke();
    ctx.strokeStyle="rgba(59,130,246,0.9)";
    ctx.lineWidth=2;
    ctx.beginPath();
    for (var i=0;i<values.length;i++){
      var x=padL+(i/(Math.max(1,values.length-1)))*pw;
      var y=padT+(1-((+values[i]||0)-minV)/(maxV-minV))*ph;
      if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    }
    ctx.stroke();
  }
  function drawBars(canvas, labels, a0, a1){
    var o=setupCtx(canvas), ctx=o.ctx, w=o.w, h=o.h;
    clearBg(ctx,w,h);
    if (!labels || !labels.length){ textCenter(ctx,w,h,"No data"); return; }
    var padL=46,padR=14,padT=14,padB=30;
    var pw=w-padL-padR, ph=h-padT-padB;
    var maxV=1;
    for (var i=0;i<labels.length;i++){
      maxV=Math.max(maxV, (+a0[i]||0), (+a1[i]||0), (+a0[i]||0)+(+a1[i]||0));
    }
    ctx.strokeStyle="rgba(255,255,255,0.18)";
    ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(padL,padT); ctx.lineTo(padL,padT+ph); ctx.lineTo(padL+pw,padT+ph);
    ctx.stroke();
    var n=labels.length, gw=pw/n, bw=Math.max(6, gw*0.28);
    for (var i=0;i<n;i++){
      var x0=padL+i*gw+gw*0.18;
      var v0=+a0[i]||0, v1=+a1[i]||0;
      var h0=(v0/maxV)*ph, h1=(v1/maxV)*ph;
      ctx.fillStyle="rgba(239,68,68,0.85)";
      ctx.fillRect(x0, padT+ph-h0, bw, h0);
      ctx.fillStyle="rgba(245,158,11,0.85)";
      ctx.fillRect(x0+bw+4, padT+ph-h1, bw, h1);
    }
  }

  function parseCharts(j){
    var donut=null, trend=null, bar=null, top=null;
    if (Array.isArray(j?.severity_distribution))
      donut={labels:j.severity_distribution.map(x=>x.sev), values:j.severity_distribution.map(x=>x.count)};
    if (Array.isArray(j?.findings_trend))
      trend={labels:j.findings_trend.map(x=>x.rid), values:j.findings_trend.map(x=>x.total)};
    if (Array.isArray(j?.critical_high_by_tool))
      bar={labels:j.critical_high_by_tool.map(x=>x.tool),
           a0:j.critical_high_by_tool.map(x=>x.critical||0),
           a1:j.critical_high_by_tool.map(x=>x.high||0)};
    if (Array.isArray(j?.top_cwe_exposure))
      top={labels:j.top_cwe_exposure.map(x=>x.cwe), values:j.top_cwe_exposure.map(x=>x.count)};
    return {donut,trend,bar,top};
  }

  async function renderOnce(){
    if (!(location.pathname||"").includes("/vsp5")) return false;

    var ids=["vsp-chart-severity","vsp-chart-trend","vsp-chart-bytool","vsp-chart-topcwe"];
    var okIds=ids.every(x=>!!id(x));
    var rid=await resolveRidStrong();

    /* [VSP][DASH][V6F] suppressed by VSP_P1_DASH_CONTRACT_ENFORCE_V1 */

    if (!okIds || !isGoodRid(rid)) return false;

    var resp=await fetch("/api/vsp/dash_charts?rid="+encodeURIComponent(rid), {cache:"no-store"});
    if (!resp.ok){
      console.warn("[VSP][DASH][V6F] dash_charts HTTP", resp.status);
      return false;
    }
    var j=await resp.json();
    var o=parseCharts(j);

    var c1=ensureCanvas("vsp-chart-severity"); if (c1 && o.donut) drawDonut(c1, o.donut.labels, o.donut.values);
    var c2=ensureCanvas("vsp-chart-trend");    if (c2 && o.trend) drawLine(c2, o.trend.labels, o.trend.values);
    var c3=ensureCanvas("vsp-chart-bytool");   if (c3 && o.bar)   drawBars(c3, o.bar.labels, o.bar.a0, o.bar.a1);
    var c4=ensureCanvas("vsp-chart-topcwe");   if (c4 && o.top)   drawBars(c4, o.top.labels, o.top.values, new Array(o.top.labels.length).fill(0));

    /* [VSP][DASH][V6F] suppressed by VSP_P1_DASH_CONTRACT_ENFORCE_V1 */
    return true;
  }

  function start(){
    var tries=0;
    var t=setInterval(function(){
      tries++;
      renderOnce().then(function(ok){
        if (ok || tries>=80){
          clearInterval(t);
          if (!ok) console.warn("[VSP][DASH][V6F] gave up (rid still not ready)");
        }
      }).catch(function(e){
        if (tries>=80){ clearInterval(t); console.warn("[VSP][DASH][V6F] error", e); }
      });
    }, 500);
  }

  if (document.readyState==="complete") start();
  else window.addEventListener("load", start);
})();


/* ===== VSP_P1_DASH_RENDER_STABLE_V1 (NO Chart.js) ===== */
(function(){
  const LOGP = "[VSP][DASH][STABLE_V1]";
  const $ = (id)=>document.getElementById(id);
  const sleep = (ms)=>new Promise(r=>setTimeout(r,ms));
  const now = ()=>Date.now();

  function onReady(fn){
    if (document.readyState === "complete" || document.readyState === "interactive") return fn();
    document.addEventListener("DOMContentLoaded", fn, {once:true});
  }

  async function fetchJSON(url){
    const u = url + (url.includes("?") ? "&" : "?") + "_=" + now();
    const r = await fetch(u, {cache:"no-store", credentials:"same-origin"});
    const t = await r.text();
    try { return JSON.parse(t); } catch(e){
      console.warn(LOGP, "bad json from", u, "len=", (t||"").length);
      throw e;
    }
  }

  function fitCanvas(canvas, w, h){
    const dpr = window.devicePixelRatio || 1;
    canvas.width  = Math.max(10, Math.floor(w * dpr));
    canvas.height = Math.max(10, Math.floor(h * dpr));
    canvas.style.width  = Math.max(10, Math.floor(w)) + "px";
    canvas.style.height = Math.max(10, Math.floor(h)) + "px";
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr,0,0,dpr,0,0);
    return ctx;
  }

  function ensureCanvasIn(containerId, minH){
    const box = $(containerId);
    if (!box) return null;
    box.textContent = ""; // clear placeholder
    const c = document.createElement("canvas");
    c.setAttribute("aria-label", containerId);
    c.style.display = "block";
    c.style.width = "100%";
    c.style.height = (minH||220) + "px";
    box.appendChild(c);

    const w = box.clientWidth || 800;
    const h = Math.max(minH||220, box.clientHeight || 0, 200);
    const ctx = fitCanvas(c, w, h);
    return {box, canvas:c, ctx, w, h};
  }

  function drawTextCenter(ctx, w, h, txt){
    ctx.clearRect(0,0,w,h);
    ctx.globalAlpha = 1;
    ctx.font = "13px sans-serif";
    ctx.fillStyle = "rgba(220,230,255,0.75)";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(txt, w/2, h/2);
  }

  function drawDonut(ctx, w, h, items){
    // items: [{sev,count}]
    const total = items.reduce((a,x)=>a+(+x.count||0),0) || 1;
    const cx=w/2, cy=h/2, r=Math.min(w,h)*0.32;
    const r2=r*0.62;
    let a0 = -Math.PI/2;

    ctx.clearRect(0,0,w,h);
    ctx.lineWidth = 18;
    const palette = [
      "rgba(255,80,80,0.85)",   // CRITICAL
      "rgba(255,160,80,0.85)",  // HIGH
      "rgba(255,220,80,0.85)",  // MEDIUM
      "rgba(160,220,120,0.85)", // LOW
      "rgba(120,180,255,0.85)", // INFO
      "rgba(180,180,200,0.65)"  // TRACE
    ];
    items.forEach((it, i)=>{
      const v = (+it.count||0);
      const a1 = a0 + (v/total)*Math.PI*2;
      ctx.beginPath();
      ctx.strokeStyle = palette[i % palette.length];
      ctx.arc(cx,cy,r,a0,a1,false);
      ctx.stroke();
      a0 = a1;
    });

    // hole
    ctx.globalCompositeOperation = "destination-out";
    ctx.beginPath();
    ctx.arc(cx,cy,r2,0,Math.PI*2);
    ctx.fill();
    ctx.globalCompositeOperation = "source-over";

    // center text
    ctx.font="12px sans-serif";
    ctx.fillStyle="rgba(220,230,255,0.85)";
    ctx.textAlign="center";
    ctx.textBaseline="middle";
    ctx.fillText("TOTAL", cx, cy-8);
    ctx.font="14px sans-serif";
    ctx.fillText(String(total), cx, cy+10);
  }

  function drawBars(ctx, w, h, rows, keyA, keyB){
    // rows: [{tool, critical, high}] -> stacked bar
    ctx.clearRect(0,0,w,h);
    const pad=18, left=80, top=14, bottom=24;
    const innerW = w-left-pad, innerH = h-top-bottom;

    const maxV = Math.max(1, ...rows.map(r=>(+r[keyA]||0)+(+r[keyB]||0)));
    ctx.font="12px sans-serif";
    ctx.textBaseline="middle";

    rows.slice(0,8).forEach((r, idx)=>{
      const y = top + idx*(innerH/8) + (innerH/8)/2;
      const total = (+r[keyA]||0)+(+r[keyB]||0);
      const bw = (total/maxV)*innerW;

      // label
      ctx.fillStyle="rgba(220,230,255,0.75)";
      ctx.textAlign="right";
      ctx.fillText(String(r.tool||"").slice(0,10), left-8, y);

      // bar
      ctx.fillStyle="rgba(255,120,120,0.75)";
      ctx.fillRect(left, y-7, Math.max(2,bw), 14);

      // value
      ctx.textAlign="left";
      ctx.fillStyle="rgba(220,230,255,0.65)";
      ctx.fillText(String(total), left + Math.max(2,bw) + 6, y);
    });
  }

  function drawTopCWE(ctx, w, h, rows){
    // rows: [{cwe,count}]
    ctx.clearRect(0,0,w,h);
    const pad=18, left=90, top=14, bottom=22;
    const innerW=w-left-pad, innerH=h-top-bottom;

    const maxV = Math.max(1, ...rows.map(r=>(+r.count||0)));
    ctx.font="12px sans-serif";
    rows.slice(0,8).forEach((r, idx)=>{
      const y = top + idx*(innerH/8) + 6;
      const bw = ((+r.count||0)/maxV)*innerW;

      ctx.fillStyle="rgba(220,230,255,0.75)";
      ctx.textAlign="right";
      ctx.fillText(String(r.cwe||"").slice(0,14), left-8, y+6);

      ctx.fillStyle="rgba(120,180,255,0.65)";
      ctx.fillRect(left, y, Math.max(2,bw), 12);

      ctx.textAlign="left";
      ctx.fillStyle="rgba(220,230,255,0.6)";
      ctx.fillText(String(+r.count||0), left + Math.max(2,bw) + 6, y+6);
    });
  }

  function drawTrend(ctx, w, h, points){
    // points: [{rid,total_findings}] (càng mới càng phải)
    ctx.clearRect(0,0,w,h);
    const pad=18, left=40, top=14, bottom=28;
    const innerW=w-left-pad, innerH=h-top-bottom;

    const ys = points.map(p=>(+p.total_findings||0));
    const maxY = Math.max(1, ...ys);
    const minY = Math.min(...ys, 0);

    // axes
    ctx.strokeStyle="rgba(220,230,255,0.18)";
    ctx.beginPath();
    ctx.moveTo(left, top);
    ctx.lineTo(left, top+innerH);
    ctx.lineTo(left+innerW, top+innerH);
    ctx.stroke();

    if(points.length < 2){
      drawTextCenter(ctx,w,h,"trend: not enough points");
      return;
    }

    // line
    ctx.strokeStyle="rgba(160,220,120,0.85)";
    ctx.lineWidth=2;
    ctx.beginPath();
    points.forEach((p,i)=>{
      const x = left + (i/(points.length-1))*innerW;
      const yv = (+p.total_findings||0);
      const y = top + innerH - ((yv-minY)/(maxY-minY||1))*innerH;
      if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    });
    ctx.stroke();
  }

  function setText(id, val){
    const el=$(id);
    if(!el) return;
    el.textContent = (val===null || val===undefined) ? "N/A" : String(val);
  }

  function setGate(id, overall){
    const el=$(id);
    if(!el) return;
    const s = String(overall||"").toUpperCase();
    el.textContent = (s || "N/A") + (s==="RED" ? " • Blocking pipeline" : "");
    el.classList.remove("vsp-gate-red","vsp-gate-amber","vsp-gate-green");
    if(s==="RED") el.classList.add("vsp-gate-red");
    else if(s==="AMBER") el.classList.add("vsp-gate-amber");
    else if(s==="GREEN") el.classList.add("vsp-gate-green");
  }

  async function resolveRidLatest(){
    const j = await fetchJSON("/api/vsp/runs?limit=1");
    return (j && (j.rid_latest_gate_root || (j.items && j.items[0] && j.items[0].run_id))) || null;
  }

  async function runOnce(){
    // đảm bảo containers có mặt
    const ids = ["vsp-chart-severity","vsp-chart-trend","vsp-chart-bytool","vsp-chart-topcwe"];
    const miss = ids.filter(x=>!$(x));
    if(miss.length){
      console.warn(LOGP, "missing containers:", miss.join(","));
      return;
    }

    const rid = await resolveRidLatest();
    setText("vsp-header-run-id", rid || "N/A");
    setText("vsp_live_rid", "rid_latest: " + (rid||"N/A"));

    if(!rid){
      console.warn(LOGP, "rid_latest N/A");
      return;
    }

    const kpis = await fetchJSON("/api/vsp/dash_kpis?rid=" + encodeURIComponent(rid));
    const charts = await fetchJSON("/api/vsp/dash_charts?rid=" + encodeURIComponent(rid));

    // KPI mapping
    setText("vsp-kpi-total-findings", kpis.total_findings);
    setText("vsp-kpi-critical", (kpis.counts_total && kpis.counts_total.CRITICAL));
    setText("vsp-kpi-high",     (kpis.counts_total && kpis.counts_total.HIGH));
    setText("vsp-kpi-medium",   (kpis.counts_total && kpis.counts_total.MEDIUM));
    setText("vsp-kpi-low",      (kpis.counts_total && kpis.counts_total.LOW));
    setText("vsp-kpi-score",    kpis.security_score);
    setText("vsp-kpi-top-tool", kpis.top_risky_tool);
    setText("vsp-kpi-top-cwe",  kpis.top_impacted_cwe);
    setText("vsp-kpi-top-module", kpis.top_vulnerable_module);
    setGate("vsp-kpi-ci-gate", kpis.overall);

    // charts
    const sevBox = ensureCanvasIn("vsp-chart-severity", 220);
    if(sevBox) drawDonut(sevBox.ctx, sevBox.w, sevBox.h, (charts.severity_distribution||[]));

    const trBox = ensureCanvasIn("vsp-chart-trend", 220);
    if(trBox) drawTrend(trBox.ctx, trBox.w, trBox.h, (charts.findings_trend||[]));

    const btBox = ensureCanvasIn("vsp-chart-bytool", 220);
    if(btBox) drawBars(btBox.ctx, btBox.w, btBox.h, (charts.critical_high_by_tool||[]), "critical", "high");

    const cweBox = ensureCanvasIn("vsp-chart-topcwe", 220);
    if(cweBox) drawTopCWE(cweBox.ctx, cweBox.w, cweBox.h, (charts.top_cwe_exposure||[]));

    console.log(LOGP, "rendered OK rid=", rid);
  }

  async function runWithRetry(){
    // Retry vài lần vì bundle có thể chạy trước khi DOM layout ổn định
    for(let i=0;i<8;i++){
      try{
        await runOnce();
        return;
      }catch(e){
        console.warn(LOGP, "retry", i, e && e.message ? e.message : e);
        await sleep(250);
      }
    }
    console.warn(LOGP, "gave up after retries");
  }

  onReady(()=>{ setTimeout(runWithRetry, 0); });
})();



/* =======================
   VSP_P1_TABS3_UI_V1
   Data Source + Settings + Rule Overrides
   ======================= */
(() => {
  if (window.__vsp_p1_tabs3_ui_v1) return;
  window.__vsp_p1_tabs3_ui_v1 = true;

  const $ = (sel, root=document) => root.querySelector(sel);
  const esc = (s) => (s==null?'':String(s)).replace(/[&<>"']/g, (c)=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  const sleep = (ms)=>new Promise(r=>setTimeout(r,ms));

  function ensureStyle(){
    if (document.getElementById("vsp_tabs3_style_v1")) return;
    const st = document.createElement("style");
    st.id = "vsp_tabs3_style_v1";
    st.textContent = `
      .vsp-card{background:#0f1b2d;border:1px solid rgba(148,163,184,.18);border-radius:14px;padding:14px}
      .vsp-row{display:flex;gap:12px;flex-wrap:wrap}
      .vsp-kpi{min-width:180px}
      .vsp-muted{color:#94a3b8}
      .vsp-btn{background:#111c30;border:1px solid rgba(148,163,184,.22);color:#e5e7eb;border-radius:10px;padding:8px 10px;cursor:pointer}
      .vsp-btn:hover{border-color:rgba(148,163,184,.45)}
      .vsp-in{background:#0b1324;border:1px solid rgba(148,163,184,.22);color:#e5e7eb;border-radius:10px;padding:8px 10px;outline:none}
      .vsp-in:focus{border-color:rgba(59,130,246,.55)}
      table.vsp-t{width:100%;border-collapse:separate;border-spacing:0 8px}
      table.vsp-t th{font-weight:600;text-align:left;color:#cbd5e1;font-size:12px;padding:0 10px}
      table.vsp-t td{background:#0b1324;border-top:1px solid rgba(148,163,184,.18);border-bottom:1px solid rgba(148,163,184,.18);padding:10px;font-size:13px;vertical-align:top}
      table.vsp-t tr td:first-child{border-left:1px solid rgba(148,163,184,.18);border-top-left-radius:12px;border-bottom-left-radius:12px}
      table.vsp-t tr td:last-child{border-right:1px solid rgba(148,163,184,.18);border-top-right-radius:12px;border-bottom-right-radius:12px}
      .vsp-badge{display:inline-block;padding:2px 8px;border-radius:999px;border:1px solid rgba(148,163,184,.22);font-size:12px}
      .vsp-pager{display:flex;gap:10px;align-items:center;justify-content:flex-end;margin-top:10px}
      .vsp-code{width:100%;min-height:280px;resize:vertical;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;background:#0b1324;border:1px solid rgba(148,163,184,.22);color:#e5e7eb;border-radius:12px;padding:12px}
      .vsp-ok{color:#86efac}
      .vsp-err{color:#fca5a5}
    `;
    document.head.appendChild(st);
  }

  async function apiJson(url, opt){
    const r = await fetch(url, opt);
    const t = await r.text();
    let j = null;
    try{ j = JSON.parse(t); }catch(_e){ j = { ok:false, err:"non-json", raw:t.slice(0,800) }; }
    if (!r.ok) throw Object.assign(new Error("HTTP "+r.status), {status:r.status, body:j});
    return j;
  }

  function mount(){
    return $("#vsp_tab_root") || document.body;
  }
  function tabName(){
    return (window.__vsp_tab || ($("#vsp_tab_root")?.getAttribute("data-vsp-tab")) || "").trim();
  }

  // ---------------- Data Source ----------------
  function renderCounts(counts){
    const keys = ["TOTAL","CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];
    return keys.map(k=>{
      const v = counts?.[k] ?? 0;
      return `<div class="vsp-card vsp-kpi"><div class="vsp-muted" style="font-size:12px">${k}</div><div style="font-size:22px;font-weight:700;margin-top:6px">${v}</div></div>`;
    }).join("");
  }

  async function renderDataSource(){
    ensureStyle();
    const root = mount();
    root.innerHTML = `
      <div class="vsp-row" style="justify-content:space-between;align-items:center;margin-bottom:12px">
        <div>
          <div style="font-size:18px;font-weight:800">Data Source</div>
          <div class="vsp-muted" style="font-size:12px;margin-top:2px">Table view of findings_unified.json (latest run) with filters & paging</div>
        </div>
        <div class="vsp-row" style="gap:8px">
          <button class="vsp-btn" id="ds_refresh">Refresh</button>
          <button class="vsp-btn" id="ds_dl_json">Download JSON</button>
        </div>
      </div>

      <div class="vsp-row" id="ds_kpis" style="margin-bottom:12px"></div>

      <div class="vsp-card" style="margin-bottom:12px">
        <div class="vsp-row" style="align-items:center">
          <input class="vsp-in" id="ds_q" placeholder="search (tool, rule_id, message, file, cwe)..." style="min-width:260px;flex:1"/>
          <select class="vsp-in" id="ds_sev">
            <option value="">All severities</option>
            <option>CRITICAL</option><option>HIGH</option><option>MEDIUM</option><option>LOW</option><option>INFO</option><option>TRACE</option>
          </select>
          <input class="vsp-in" id="ds_tool" placeholder="tool (exact, e.g. semgrep)" style="min-width:200px"/>
          <select class="vsp-in" id="ds_limit">
            <option value="10">10 / page</option>
            <option value="20" selected>20 / page</option>
            <option value="50">50 / page</option>
          </select>
        </div>
        <div class="vsp-muted" id="ds_meta" style="margin-top:10px;font-size:12px"></div>
      </div>

      <div class="vsp-card">
        <table class="vsp-t">
          <thead>
            <tr>
              <th>Severity</th><th>Tool</th><th>Rule</th><th>File</th><th>Line</th><th>Message</th>
            </tr>
          </thead>
          <tbody id="ds_tbody"></tbody>
        </table>
        <div class="vsp-pager">
          <button class="vsp-btn" id="ds_prev">Prev</button>
          <div class="vsp-muted" id="ds_page">Page 1/1</div>
          <button class="vsp-btn" id="ds_next">Next</button>
        </div>
      </div>
    `;

    let state = { offset:0, limit:20, total:0, last:null };

    const qEl = $("#ds_q"), sevEl=$("#ds_sev"), toolEl=$("#ds_tool"), limEl=$("#ds_limit");
    const kpis = $("#ds_kpis"), tbody=$("#ds_tbody"), meta=$("#ds_meta"), page=$("#ds_page");

    async function load(){
      const q = (qEl.value||"").trim();
      const severity = (sevEl.value||"").trim();
      const tool = (toolEl.value||"").trim();
      const limit = parseInt(limEl.value||"20",10) || 20;
      state.limit = limit;

      const url = `/api/vsp/findings_v1?limit=${encodeURIComponent(limit)}&offset=${encodeURIComponent(state.offset)}&q=${encodeURIComponent(q)}&severity=${encodeURIComponent(severity)}&tool=${encodeURIComponent(tool.toLowerCase())}`;
      const j = await apiJson(url);
      state.total = j.total||0;
      state.last = j;
      kpis.innerHTML = renderCounts(j.counts||{});
      meta.innerHTML = `run_dir: <span class="vsp-muted">${esc(j.run_dir||"")}</span> · total_filtered: <b>${esc(j.total||0)}</b> · limit=${esc(j.limit)} offset=${esc(j.offset)}`;

      const items = j.items||[];
      tbody.innerHTML = items.map(it=>{
        const sev = esc(it.severity||"");
        const tool = esc(it.tool||"");
        const rule = esc(it.rule_id||"");
        const file = esc(it.file||"");
        const line = esc(it.line||"");
        const msg  = esc(it.message||"");
        return `<tr>
          <td><span class="vsp-badge">${sev}</span></td>
          <td>${tool}</td>
          <td>${rule}</td>
          <td style="max-width:360px;word-break:break-word">${file}</td>
          <td>${line}</td>
          <td style="max-width:520px;word-break:break-word">${msg}</td>
        </tr>`;
      }).join("");

      const pages = Math.max(1, Math.ceil((state.total||0)/state.limit));
      const cur = Math.min(pages, Math.floor((state.offset||0)/state.limit)+1);
      page.textContent = `Page ${cur}/${pages}`;
      $("#ds_prev").disabled = (state.offset<=0);
      $("#ds_next").disabled = (state.offset + state.limit >= state.total);
    }

    function debounce(fn, ms=250){
      let t=null;
      return ()=>{ clearTimeout(t); t=setTimeout(fn, ms); };
    }
    const reloadDebounced = debounce(()=>{ state.offset=0; load().catch(e=>console.error(e)); }, 250);

    qEl.addEventListener("input", reloadDebounced);
    sevEl.addEventListener("change", ()=>{ state.offset=0; load().catch(console.error); });
    toolEl.addEventListener("input", reloadDebounced);
    limEl.addEventListener("change", ()=>{ state.offset=0; load().catch(console.error); });

    $("#ds_refresh").onclick = ()=>{ load().catch(console.error); };
    $("#ds_prev").onclick = ()=>{ state.offset = Math.max(0, state.offset - state.limit); load().catch(console.error); };
    $("#ds_next").onclick = ()=>{ state.offset = state.offset + state.limit; load().catch(console.error); };

    $("#ds_dl_json").onclick = ()=>{
      const data = state.last || {};
      const blob = new Blob([JSON.stringify(data, null, 2)], {type:"application/json"});
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "vsp_findings_v1.json";
      a.click();
      setTimeout(()=>URL.revokeObjectURL(a.href), 1200);
    };

    await load();
  }

  // ---------------- Settings ----------------
  async function renderSettings(){
    ensureStyle();
    const root = mount();
    root.innerHTML = `
      <div class="vsp-row" style="justify-content:space-between;align-items:center;margin-bottom:12px">
        <div>
          <div style="font-size:18px;font-weight:800">Settings</div>
          <div class="vsp-muted" style="font-size:12px;margin-top:2px">Commercial-friendly config JSON (GET/POST)</div>
        </div>
        <div class="vsp-row" style="gap:8px">
          <button class="vsp-btn" id="st_reload">Reload</button>
          <button class="vsp-btn" id="st_save">Save</button>
          <button class="vsp-btn" id="st_dl">Download</button>
        </div>
      </div>

      <div class="vsp-row" style="margin-bottom:12px">
        <div class="vsp-card" style="flex:1;min-width:320px">
          <div class="vsp-muted" style="font-size:12px">Environment</div>
          <pre id="st_env" style="white-space:pre-wrap;margin:10px 0 0 0;font-size:12px;color:#cbd5e1"></pre>
        </div>
        <div class="vsp-card" style="flex:1;min-width:320px">
          <div class="vsp-muted" style="font-size:12px">Storage</div>
          <div id="st_path" class="vsp-muted" style="margin-top:10px;font-size:12px"></div>
          <div id="st_msg" style="margin-top:10px;font-size:12px"></div>
        </div>
      </div>

      <div class="vsp-card">
        <div class="vsp-muted" style="font-size:12px;margin-bottom:8px">settings.json</div>
        <textarea id="st_text" class="vsp-code" spellcheck="false"></textarea>
      </div>
    `;

    const envEl = $("#st_env"), pathEl=$("#st_path"), msgEl=$("#st_msg"), txt=$("#st_text");

    async function load(){
      msgEl.innerHTML = `<span class="vsp-muted">Loading...</span>`;
      const j = await apiJson("/api/vsp/settings_v1");
      envEl.textContent = JSON.stringify(j.env||{}, null, 2);
      pathEl.textContent = `path: ${j.path||""}`;
      txt.value = JSON.stringify(j.settings||{}, null, 2);
      msgEl.innerHTML = `<span class="vsp-ok">OK</span> · ts=${esc(j.ts||"")}`;
      return j;
    }

    async function save(){
      let obj = {};
      try { obj = JSON.parse(txt.value||"{}"); }
      catch(e){ msgEl.innerHTML = `<span class="vsp-err">Invalid JSON:</span> ${esc(e.message||String(e))}`; return; }
      msgEl.innerHTML = `<span class="vsp-muted">Saving...</span>`;
      const j = await apiJson("/api/vsp/settings_v1", {
        method:"POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({settings: obj})
      });
      msgEl.innerHTML = `<span class="vsp-ok">Saved</span> · ${esc(j.path||"")}`;
      return j;
    }

    $("#st_reload").onclick = ()=>load().catch(e=>{ msgEl.innerHTML=`<span class="vsp-err">${esc(e.message||e)}</span>`; });
    $("#st_save").onclick = ()=>save().catch(e=>{ msgEl.innerHTML=`<span class="vsp-err">${esc(e.message||e)}</span>`; });
    $("#st_dl").onclick = ()=>{
      const blob = new Blob([txt.value||"{}"], {type:"application/json"});
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "vsp_settings.json";
      a.click();
      setTimeout(()=>URL.revokeObjectURL(a.href), 1200);
    };

    await load();
  }

  // ---------------- Rule Overrides ----------------
  async function renderRuleOverrides(){
    ensureStyle();
    const root = mount();
    root.innerHTML = `
      <div class="vsp-row" style="justify-content:space-between;align-items:center;margin-bottom:12px">
        <div>
          <div style="font-size:18px;font-weight:800">Rule Overrides</div>
          <div class="vsp-muted" style="font-size:12px;margin-top:2px">Manage custom overrides (GET/POST) · stored under ui/out_ci/rule_overrides_v1/rules.json</div>
        </div>
        <div class="vsp-row" style="gap:8px">
          <button class="vsp-btn" id="ro_reload">Reload</button>
          <button class="vsp-btn" id="ro_validate">Validate</button>
          <button class="vsp-btn" id="ro_save">Save</button>
          <button class="vsp-btn" id="ro_dl">Download</button>
        </div>
      </div>

      <div class="vsp-row" style="margin-bottom:12px">
        <div class="vsp-card" style="flex:1;min-width:320px">
          <div class="vsp-muted" style="font-size:12px">Quick Schema</div>
          <div class="vsp-muted" style="font-size:12px;margin-top:8px;line-height:1.5">
            Each rule: {"id","tool","rule_id","action","severity","reason","expires"}<br/>
            action examples: "ignore" | "downgrade" | "upgrade"<br/>
            severity override: CRITICAL/HIGH/MEDIUM/LOW/INFO/TRACE
          </div>
        </div>
        <div class="vsp-card" style="flex:1;min-width:320px">
          <div class="vsp-muted" style="font-size:12px">Status</div>
          <div id="ro_path" class="vsp-muted" style="margin-top:10px;font-size:12px"></div>
          <div id="ro_msg" style="margin-top:10px;font-size:12px"></div>
        </div>
      </div>

      <div class="vsp-card">
        <div class="vsp-muted" style="font-size:12px;margin-bottom:8px">rules.json</div>
        <textarea id="ro_text" class="vsp-code" spellcheck="false"></textarea>
      </div>
    `;

    const pathEl=$("#ro_path"), msgEl=$("#ro_msg"), txt=$("#ro_text");

    function normalize(obj){
      // accept list or {rules:[...]}
      if (Array.isArray(obj)) obj = {rules: obj};
      if (!obj || typeof obj !== "object") throw new Error("Root must be object or array");
      if (!Array.isArray(obj.rules)) obj.rules = [];
      // ensure objects
      obj.rules = obj.rules.filter(x=>x && typeof x==="object" && !Array.isArray(x));
      return obj;
    }

    async function load(){
      msgEl.innerHTML = `<span class="vsp-muted">Loading...</span>`;
      const j = await apiJson("/api/vsp/rule_overrides_v1");
      pathEl.textContent = `path: ${j.path||""}`;
      const data = j.data || {rules:[]};
      txt.value = JSON.stringify(data, null, 2);
      msgEl.innerHTML = `<span class="vsp-ok">OK</span> · rules=${esc((data.rules||[]).length)} · ts=${esc(j.ts||"")}`;
    }

    function validate(){
      let obj;
      try { obj = JSON.parse(txt.value||"{}"); obj = normalize(obj); }
      catch(e){ msgEl.innerHTML = `<span class="vsp-err">Invalid:</span> ${esc(e.message||String(e))}`; return null; }
      // light validation
      for (const r of obj.rules){
        if (!("tool" in r) || !("rule_id" in r)){
          msgEl.innerHTML = `<span class="vsp-err">Invalid rule:</span> each rule needs tool + rule_id`; return null;
        }
      }
      msgEl.innerHTML = `<span class="vsp-ok">Valid</span> · rules=${esc(obj.rules.length)}`;
      return obj;
    }

    async function save(){
      const obj = validate();
      if (!obj) return;
      msgEl.innerHTML = `<span class="vsp-muted">Saving...</span>`;
      const j = await apiJson("/api/vsp/rule_overrides_v1", {
        method:"POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({data: obj})
      });
      msgEl.innerHTML = `<span class="vsp-ok">Saved</span> · rules_n=${esc(j.rules_n||"")} · ts=${esc(j.ts||"")}`;
      await sleep(150);
      await load();
    }

    $("#ro_reload").onclick = ()=>load().catch(e=>{ msgEl.innerHTML=`<span class="vsp-err">${esc(e.message||e)}</span>`; });
    $("#ro_validate").onclick = ()=>validate();
    $("#ro_save").onclick = ()=>save().catch(e=>{ msgEl.innerHTML=`<span class="vsp-err">${esc(e.message||e)}</span>`; });
    $("#ro_dl").onclick = ()=>{
      const blob = new Blob([txt.value||"{}"], {type:"application/json"});
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "vsp_rule_overrides.json";
      a.click();
      setTimeout(()=>URL.revokeObjectURL(a.href), 1200);
    };

    await load();
  }

  // --------------- Router ---------------
  async function boot(){
    const t = tabName() || location.pathname.replace(/^\//,'');
    try{
      if (t.includes("data_source")) return await renderDataSource();
      if (t.includes("settings")) return await renderSettings();
      if (t.includes("rule_overrides")) return await renderRuleOverrides();
    }catch(e){
      console.error(e);
      const root = mount();
      root.innerHTML = `<div class="vsp-card"><div style="font-weight:800">Tab render failed</div><pre style="white-space:pre-wrap;margin-top:10px" class="vsp-muted">${esc(e.message||String(e))}</pre></div>`;
    }
  }

  document.addEventListener("DOMContentLoaded", boot);
})();



/* VSP_P1_DASH_LIVE_KPI_V1 (safe: poll /api/vsp/runs; fetch run_gate.json only for latest; no bulk probing) */
(()=> {
  if (window.__vsp_p1_dash_live_kpi_v1) return;
  window.__vsp_p1_dash_live_kpi_v1 = true;

  function onDash(){
    try {
      const p = (location && location.pathname) ? location.pathname : "";
      // support /vsp5 and /dashboard routes
      return (p === "/vsp5" || p === "/dashboard" || /\/vsp5\/?$/.test(p) || /\/dashboard\/?$/.test(p));
    } catch(e){ return false; }
  }
  if (!onDash()) return;

  const S = { live:true, delay:8000, timer:null, lastRid:"", running:false };

  const now=()=>Date.now();
  const qs=(o)=>Object.keys(o).map(k=>encodeURIComponent(k)+"="+encodeURIComponent(o[k])).join("&");

  function mount(){
    if (document.getElementById("vsp_dash_live_kpi_v1")) return;

    const host =
      document.querySelector("#vsp_tab_dashboard") ||
      document.querySelector("[data-tab='dashboard']") ||
      document.querySelector("main") ||
      document.body;

    const wrap=document.createElement("div");
    wrap.id="vsp_dash_live_kpi_v1";
    wrap.style.cssText=[
      "margin:10px 0 12px 0",
      "padding:10px 12px",
      "border-radius:14px",
      "border:1px solid rgba(255,255,255,0.08)",
      "background:rgba(255,255,255,0.03)",
      "display:flex",
      "gap:10px",
      "align-items:center",
      "flex-wrap:wrap"
    ].join(";");

    wrap.innerHTML = `
      <span style="opacity:.9;font-weight:600">Dashboard Live</span>
      <button id="vsp_dash_live_toggle_v1" style="padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,0.10);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Live: ON</button>
      <span id="vsp_dash_live_status_v1" style="opacity:.8;font-size:12px">Last: --</span>
      <span style="opacity:.55">|</span>
      <span id="vsp_dash_live_counts_v1" style="opacity:.92">runs: --</span>
      <span style="opacity:.55">|</span>
      <span id="vsp_dash_live_latest_v1" style="opacity:.92">latest: --</span>
      <button id="vsp_dash_open_gate_json_v1" style="padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,0.10);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Open gate JSON</button>
      <button id="vsp_dash_open_html_v1" style="padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,0.10);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Open HTML</button>
    `;

    host.insertAdjacentElement("afterbegin", wrap);

    const tgl = document.getElementById("vsp_dash_live_toggle_v1");
    tgl.addEventListener("click", ()=>{
      S.live = !S.live;
      tgl.textContent = S.live ? "Live: ON" : "Live: OFF";
      if (S.live) kick();
    });

    document.getElementById("vsp_dash_open_gate_json_v1").addEventListener("click", ()=>{
      if (!S.lastRid) return;
      window.open(`/api/vsp/run_file_allow?${qs({rid:S.lastRid, path:"run_gate.json"})}`, "_blank");
    });
    document.getElementById("vsp_dash_open_html_v1").addEventListener("click", ()=>{
      if (!S.lastRid) return;
      window.open(`/api/vsp/run_file_allow?${qs({rid:S.lastRid, path:"reports/findings_unified.html"})}`, "_blank");
    });
  }

  function setText(id, t){
    const el=document.getElementById(id);
    if (el) el.textContent=t;
  }

  async function getRuns(){
    const url = `/api/vsp/runs?limit=30&offset=0&_=${now()}`;
    const r = await fetch(url, { cache:"no-store", credentials:"same-origin" });
    if (!r.ok) throw new Error("runs "+r.status);
    return await r.json();
  }

  async function getGate(rid){
    const url = `/api/vsp/run_file_allow?${qs({rid, path:"run_gate.json", _: now()})}`;
    const r = await fetch(url, { cache:"no-store", credentials:"same-origin" });
    if (!r.ok) return null;
    try { return await r.json(); } catch(e){ return null; }
  }

  function normOverall(x){
    const s=(x||"").toString().toUpperCase();
    if (!s) return "UNKNOWN";
    if (["GREEN","PASS","OK"].includes(s)) return "GREEN";
    if (["AMBER","WARN"].includes(s)) return "AMBER";
    if (["RED","FAIL","BLOCK"].includes(s)) return "RED";
    if (["DEGRADED"].includes(s)) return "DEGRADED";
    return s;
  }

  function schedule(ms){
    clearTimeout(S.timer);
    S.timer=setTimeout(()=>tick(), ms);
  }
  function kick(){ schedule(400); }

  async function tick(){
    if (!S.live) return schedule(S.delay);
    if (document.hidden) return schedule(S.delay);
    if (S.running) return schedule(600);
    S.running=true;
    try{
      mount();
      const j = await getRuns();
      const items = (j && j.items) ? j.items : [];
      const total = (typeof j.total === "number") ? j.total : items.length;

      const first = items[0] || null;
      const rid = (first && (first.rid || first.run_id || first.id)) ? (first.rid || first.run_id || first.id).toString() : "";
      if (rid) S.lastRid = rid;

      // counts: prefer item.overall/overall_status if present; else UNKNOWN
      const cnt = {GREEN:0, AMBER:0, RED:0, DEGRADED:0, UNKNOWN:0};
      for (const it of items){
        const ov = normOverall(it.overall || it.overall_status || it.status || "");
        if (cnt[ov] === undefined) cnt.UNKNOWN++;
        else cnt[ov]++;
      }

      // try to get "real" overall for latest via run_gate.json (only 1 file)
      let latestOverall = "UNKNOWN";
      if (rid){
        const gate = await getGate(rid);
        if (gate){
          latestOverall = normOverall(gate.overall || gate.overall_status || "");
        }
      }

      const ts = new Date().toLocaleTimeString();
      setText("vsp_dash_live_status_v1", `Last: ${ts}`);
      setText("vsp_dash_live_counts_v1", `runs: ${total} | G:${cnt.GREEN} A:${cnt.AMBER} R:${cnt.RED} D:${cnt.DEGRADED} U:${cnt.UNKNOWN}`);
      setText("vsp_dash_live_latest_v1", `latest: ${rid || "--"} | overall: ${latestOverall}`);

      schedule(S.delay);
    }catch(e){
      const ts = new Date().toLocaleTimeString();
      setText("vsp_dash_live_status_v1", `Last: ${ts} • err`);
      schedule(Math.min(60000, S.delay*2));
    }finally{
      S.running=false;
    }
  }

  document.addEventListener("visibilitychange", ()=>{ if (!document.hidden && S.live) kick(); });
  kick();
})();


/* VSP_P1_DASH_REAL_KPI_LIVE_V6
   - poll /api/vsp/runs?limit=1 (light)
   - fetch gate via /api/vsp/run_file_allow?rid=RID&path=run_gate.json (fallback summary handled by backend)
   - render KPI strip + by-tool mini table
   - pause when hidden + backoff on errors
*/
(()=> {
  if (window.__vsp_p1_dash_real_kpi_live_v6) return;
  window.__vsp_p1_dash_real_kpi_live_v6 = true;

  function isDash(){
    try{
      const p = (location && location.pathname) ? location.pathname : "";
      return (p === "/vsp5" || p === "/dashboard" || /\/vsp5\/?$/.test(p) || /\/dashboard\/?$/.test(p));
    }catch(e){ return false; }
  }
  if (!isDash()) return;

  const S = {
    live: true,
    baseDelay: 8000,
    delay: 8000,
    maxDelay: 60000,
    backoffN: 0,
    rid: "",
    gate: null,
    running: false,
    timer: null
  };

  const now = ()=> Date.now();
  const qs = (o)=>Object.keys(o).map(k=>encodeURIComponent(k)+"="+encodeURIComponent(o[k])).join("&");

  function el(id){ return document.getElementById(id); }
  function setTxt(id, t){ const e=el(id); if (e) e.textContent = t; }

  function badge(ov){
    const s = (ov||"UNKNOWN").toString().toUpperCase();
    let bg="rgba(255,255,255,0.06)", bd="rgba(255,255,255,0.10)", fg="rgba(255,255,255,0.92)";
    if (s==="GREEN" || s==="OK" || s==="PASS"){ bg="rgba(46, 204, 113, 0.12)"; bd="rgba(46, 204, 113, 0.25)"; }
    else if (s==="AMBER" || s==="WARN"){ bg="rgba(241, 196, 15, 0.12)"; bd="rgba(241, 196, 15, 0.25)"; }
    else if (s==="RED" || s==="FAIL" || s==="BLOCK"){ bg="rgba(231, 76, 60, 0.12)"; bd="rgba(231, 76, 60, 0.25)"; }
    else if (s==="DEGRADED"){ bg="rgba(155, 89, 182, 0.12)"; bd="rgba(155, 89, 182, 0.25)"; }
    return {s, bg, bd, fg};
  }

  function ensureUI(){
    if (el("vsp_dash_kpi_strip_v6")) return;

    const host =
      document.querySelector("#vsp_tab_dashboard") ||
      document.querySelector("[data-tab='dashboard']") ||
      document.querySelector("main") ||
      document.body;

    const wrap = document.createElement("div");
    wrap.id = "vsp_dash_kpi_strip_v6";
    wrap.style.cssText = [
      "margin:12px 0 14px 0",
      "padding:12px 12px",
      "border-radius:16px",
      "border:1px solid rgba(255,255,255,0.10)",
      "background:rgba(255,255,255,0.03)",
      "box-shadow:0 10px 30px rgba(0,0,0,0.20)"
    ].join(";");

    wrap.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <span style="font-weight:700;opacity:.92">Dashboard</span>
          <span id="vsp_dash_overall_badge_v6" style="padding:4px 10px;border-radius:999px;border:1px solid rgba(255,255,255,0.10);background:rgba(255,255,255,0.06);font-size:12px;opacity:.95">OVERALL: --</span>
          <span id="vsp_dash_rid_v6" style="font-size:12px;opacity:.82">RID: --</span>
          <span id="vsp_dash_ts_v6" style="font-size:12px;opacity:.72">TS: --</span>
          <span id="vsp_dash_last_v6" style="font-size:12px;opacity:.72">Last: --</span>
        </div>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <button id="vsp_dash_live_toggle_v6" style="padding:6px 10px;border-radius:12px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Live: ON</button>
          <button id="vsp_dash_refresh_v6" style="padding:6px 10px;border-radius:12px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Refresh</button>
          <button id="vsp_dash_open_gate_v6" style="padding:6px 10px;border-radius:12px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Open gate JSON</button>
          <button id="vsp_dash_open_html_v6" style="padding:6px 10px;border-radius:12px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Open HTML</button>
        </div>
      </div>

      <div style="margin-top:10px;display:grid;grid-template-columns:repeat(6,minmax(120px,1fr));gap:10px">
        ${["TOTAL","HIGH","MEDIUM","LOW","INFO","CRITICAL"].map(k=>`
          <div style="padding:10px 10px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.02)">
            <div style="font-size:11px;opacity:.68">${k}</div>
            <div id="vsp_dash_cnt_${k}_v6" style="font-size:20px;font-weight:800;letter-spacing:.2px;margin-top:2px">--</div>
          </div>
        `).join("")}
      </div>

      <div style="margin-top:12px;display:flex;gap:12px;flex-wrap:wrap">
        <div style="flex:1;min-width:300px;padding:10px 10px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.02)">
          <div style="font-size:12px;font-weight:700;opacity:.85;margin-bottom:6px">By tool</div>
          <div id="vsp_dash_bytool_v6" style="font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;font-size:12px;opacity:.92">--</div>
        </div>
        <div style="flex:1;min-width:300px;padding:10px 10px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.02)">
          <div style="font-size:12px;font-weight:700;opacity:.85;margin-bottom:6px">Notes</div>
          <div id="vsp_dash_notes_v6" style="font-size:12px;opacity:.85;line-height:1.4">
            • Click-only: no bulk probing<br/>
            • Source: run_gate.json (fallback summary)<br/>
            • Severity normalized: CRITICAL/HIGH/MEDIUM/LOW/INFO/TRACE
          </div>
        </div>
      </div>
    `;

    host.insertAdjacentElement("afterbegin", wrap);

    el("vsp_dash_live_toggle_v6").addEventListener("click", ()=>{
      S.live = !S.live;
      el("vsp_dash_live_toggle_v6").textContent = S.live ? "Live: ON" : "Live: OFF";
      if (S.live) kick("toggle_on");
    });
    el("vsp_dash_refresh_v6").addEventListener("click", ()=> kick("manual"));

    el("vsp_dash_open_gate_v6").addEventListener("click", ()=>{
      if (!S.rid) return;
      window.open(`/api/vsp/run_file_allow?${qs({rid:S.rid, path:"run_gate.json"})}`, "_blank");
    });
    el("vsp_dash_open_html_v6").addEventListener("click", ()=>{
      if (!S.rid) return;
      window.open(`/api/vsp/run_file_allow?${qs({rid:S.rid, path:"reports/findings_unified.html"})}`, "_blank");
    });
  }

  async function fetchLatestRid(){
    const url = `/api/vsp/runs?limit=1&offset=0&_=${now()}`;
    const r = await fetch(url, { cache:"no-store", credentials:"same-origin" });
    if (!r.ok) throw new Error("runs "+r.status);
    const j = await r.json();
    const it = (j && j.items && j.items[0]) ? j.items[0] : null;
    if (!it) return "";
    return (it.rid || it.run_id || it.id || "").toString();
  }

  async function fetchGate(rid){
    const url = `/api/vsp/run_file_allow?${qs({rid, path:"run_gate.json", _: now()})}`;
    const r = await fetch(url, { cache:"no-store", credentials:"same-origin" });
    if (!r.ok) return null;
    try { return await r.json(); } catch(e){ return null; }
  }

  function render(g){
    ensureUI();

    const rid = S.rid || "--";
    const ts = (g && (g.ts || g.time || g.generated_at)) ? (g.ts || g.time || g.generated_at) : "--";
    const ov = (g && (g.overall || g.overall_status)) ? (g.overall || g.overall_status) : "UNKNOWN";

    const b = badge(ov);
    const ob = el("vsp_dash_overall_badge_v6");
    if (ob){
      ob.textContent = `OVERALL: ${b.s}`;
      ob.style.background = b.bg;
      ob.style.borderColor = b.bd;
      ob.style.color = b.fg;
    }

    setTxt("vsp_dash_rid_v6", `RID: ${rid}`);
    setTxt("vsp_dash_ts_v6", `TS: ${ts}`);

    const ct = (g && (g.counts_total || g.counts || g.totals)) ? (g.counts_total || g.counts || g.totals) : {};
    const total = (ct.HIGH||0)+(ct.MEDIUM||0)+(ct.LOW||0)+(ct.INFO||0)+(ct.CRITICAL||0)+(ct.TRACE||0);

    setTxt("vsp_dash_cnt_TOTAL_v6", total.toString());
    setTxt("vsp_dash_cnt_HIGH_v6", (ct.HIGH??"--").toString());
    setTxt("vsp_dash_cnt_MEDIUM_v6", (ct.MEDIUM??"--").toString());
    setTxt("vsp_dash_cnt_LOW_v6", (ct.LOW??"--").toString());
    setTxt("vsp_dash_cnt_INFO_v6", (ct.INFO??"--").toString());
    setTxt("vsp_dash_cnt_CRITICAL_v6", (ct.CRITICAL??"--").toString());

    // By-tool mini table (top 10 by HIGH+MEDIUM)
    const bt = (g && g.by_tool) ? g.by_tool : {};
    const rows = Object.keys(bt).map(k=>{
      const x = bt[k] || {};
      const c = x.counts_total || x.counts || {};
      const hi = c.HIGH||0, me=c.MEDIUM||0, lo=c.LOW||0, inf=c.INFO||0, cr=c.CRITICAL||0;
      return {k, hi, me, lo, inf, cr, score: (hi*1000 + me*100 + lo*10 + inf)};
    }).sort((a,b)=>b.score-a.score).slice(0,10);

    const lines = rows.length ? rows.map(r=>{
      const k = (r.k||"").padEnd(10, " ").slice(0,10);
      return `${k}  C:${r.cr}  H:${r.hi}  M:${r.me}  L:${r.lo}  I:${r.inf}`;
    }).join("\n") : "--";

    const btEl = el("vsp_dash_bytool_v6");
    if (btEl){
      btEl.textContent = lines;
      btEl.style.whiteSpace = "pre";
    }
  }

  function schedule(ms){
    clearTimeout(S.timer);
    S.timer = setTimeout(()=>tick("timer"), ms);
  }
  function kick(reason){ schedule(250); }

  async function tick(reason){
    if (!S.live && reason !== "manual") return schedule(S.baseDelay);
    if (document.hidden) return schedule(S.baseDelay);
    if (S.running) return schedule(600);

    S.running = true;
    try{
      ensureUI();

      const rid = await fetchLatestRid();
      const changed = rid && rid !== S.rid;
      if (rid) S.rid = rid;

      let g = S.gate;
      if (changed || !g || reason === "manual"){
        g = await fetchGate(S.rid);
        S.gate = g;
      }

      const last = new Date().toLocaleTimeString();
      setTxt("vsp_dash_last_v6", `Last: ${last}${changed ? " • new RID" : ""}`);

      if (g) render(g);
      try{ if (g && window.__vsp_dash_bind_native_cards_v7_apply) window.__vsp_dash_bind_native_cards_v7_apply(g); }catch(e){}
      /* VSP_P1_DASH_V6_CALL_BIND_V7 */
S.backoffN = 0;
      S.delay = S.baseDelay;
      schedule(S.delay);
    } catch(e){
      S.backoffN += 1;
      S.delay = Math.min(S.maxDelay, Math.max(S.baseDelay, S.baseDelay * (2 ** Math.min(5, S.backoffN))));
      const last = new Date().toLocaleTimeString();
      setTxt("vsp_dash_last_v6", `Last: ${last} • err • backoff ${Math.round(S.delay/1000)}s`);
      schedule(S.delay);
    } finally {
      S.running = false;
    }
  }

  document.addEventListener("visibilitychange", ()=>{ if (!document.hidden && S.live) kick("visible"); });

  // boot
  ensureUI();
  schedule(800);
})();


/* VSP_P1_DASH_BIND_NATIVE_CARDS_V7
   - non-invasive: try to locate existing KPI cards by label text and update values/colors
   - if not found: do nothing (overlay KPI strip remains)
*/
(()=> {
  if (window.__vsp_p1_dash_bind_native_cards_v7) return;
  window.__vsp_p1_dash_bind_native_cards_v7 = true;

  function isDash(){
    try{
      const p = (location && location.pathname) ? location.pathname : "";
      return (p === "/vsp5" || p === "/dashboard" || /\/vsp5\/?$/.test(p) || /\/dashboard\/?$/.test(p));
    }catch(e){ return false; }
  }
  if (!isDash()) return;

  function norm(s){ return (s||"").toString().trim().toUpperCase(); }

  function badgeColors(ov){
    const s = norm(ov) || "UNKNOWN";
    let bg="rgba(255,255,255,0.06)", bd="rgba(255,255,255,0.10)";
    if (s==="GREEN"||s==="OK"||s==="PASS"){ bg="rgba(46,204,113,0.12)"; bd="rgba(46,204,113,0.25)"; }
    else if (s==="AMBER"||s==="WARN"){ bg="rgba(241,196,15,0.12)"; bd="rgba(241,196,15,0.25)"; }
    else if (s==="RED"||s==="FAIL"||s==="BLOCK"){ bg="rgba(231,76,60,0.12)"; bd="rgba(231,76,60,0.25)"; }
    else if (s==="DEGRADED"){ bg="rgba(155,89,182,0.12)"; bd="rgba(155,89,182,0.25)"; }
    return {bg, bd, s};
  }

  // Find a KPI "card" that contains a label text (e.g., HIGH) and has a number element
  function findCardByLabel(label){
    label = norm(label);
    const all = Array.from(document.querySelectorAll("div,section,article"));
    // prefer smaller cards: limit by text length
    for (const el of all){
      const t = norm(el.textContent || "");
      if (!t) continue;
      if (!t.includes(label)) continue;
      // heuristics: must be relatively short and contain digits placeholder
      if (t.length > 120) continue;
      // look for a big-number element inside
      const candidates = Array.from(el.querySelectorAll("div,span,p,h1,h2,h3"))
        .filter(x => /\d|--/.test((x.textContent||"").trim()) && (x.textContent||"").trim().length <= 10);
      if (candidates.length){
        return {card: el, valueEl: candidates.sort((a,b)=> (b.clientHeight||0)-(a.clientHeight||0))[0]};
      }
    }
    return null;
  }

  function setCard(label, val){
    const hit = findCardByLabel(label);
    if (!hit) return false;
    hit.valueEl.textContent = (val===undefined || val===null) ? "--" : String(val);
    return true;
  }

  function setOverall(ov){
    // try badge element first
    const b = badgeColors(ov);
    const nodes = Array.from(document.querySelectorAll("span,div"))
      .filter(x => /OVERALL/i.test(x.textContent||"") && (x.textContent||"").length < 40);
    if (nodes.length){
      const n = nodes[0];
      n.textContent = `OVERALL: ${b.s}`;
      n.style.background = b.bg;
      n.style.border = `1px solid ${b.bd}`;
      n.style.borderRadius = "999px";
      n.style.padding = "4px 10px";
      return true;
    }
    // fallback: overall card
    const hit = findCardByLabel("OVERALL");
    if (hit){
      hit.valueEl.textContent = b.s;
      hit.card.style.background = b.bg;
      hit.card.style.borderColor = b.bd;
      return true;
    }
    return false;
  }

  // Expose binder for the live module (V6) to call if present
  window.__vsp_dash_bind_native_cards_v7_apply = (gate)=>{
    try{
      const ct = (gate && (gate.counts_total || gate.counts || gate.totals)) ? (gate.counts_total || gate.counts || gate.totals) : {};
      const total = (ct.HIGH||0)+(ct.MEDIUM||0)+(ct.LOW||0)+(ct.INFO||0)+(ct.CRITICAL||0)+(ct.TRACE||0);

      // attempt set numbers
      setCard("TOTAL", total);
      setCard("HIGH", ct.HIGH);
      setCard("MEDIUM", ct.MEDIUM);
      setCard("LOW", ct.LOW);
      setCard("INFO", ct.INFO);
      setCard("CRITICAL", ct.CRITICAL);

      setOverall(gate && (gate.overall || gate.overall_status));

      return true;
    }catch(e){
      return false;
    }
  };
})();


/* VSP_P1_DASH_STRIP_FORCE_V6C
   - robust mount: attach near Gate Story, re-attach if DOM replaced
   - live: poll /api/vsp/runs?limit=1 then fetch /api/vsp/run_file_allow rid + run_gate.json (fallback handled)
*/
(()=> {
  if (window.__vsp_p1_dash_strip_force_v6c) return;
  window.__vsp_p1_dash_strip_force_v6c = true;

  function isDash(){
    try{
      const p = (location && location.pathname) ? location.pathname : "";
      return (p === "/vsp5" || p === "/dashboard" || /\/vsp5\/?$/.test(p) || /\/dashboard\/?$/.test(p));
    }catch(e){ return false; }
  }
  if (!isDash()) return;

  const S = { live:true, rid:"", gate:null, running:false, base:8000, delay:8000, max:60000, backoff:0, t:null };

  const now = ()=>Date.now();
  const qs = (o)=>Object.keys(o).map(k=>encodeURIComponent(k)+"="+encodeURIComponent(o[k])).join("&");

  function findGateStoryAnchor(){
    // Try find element that contains "Gate Story"
    const nodes = Array.from(document.querySelectorAll("div,section,header,main"));
    for (const n of nodes){
      const txt = (n.textContent||"").trim();
      if (!txt) continue;
      if (txt.includes("Gate Story")){
        // choose a stable container: go up a bit
        let cur = n;
        for (let i=0;i<4 && cur && cur.parentElement; i++){
          if ((cur.className||"").toString().includes("container")) break;
          cur = cur.parentElement;
        }
        return cur || n;
      }
    }
    // fallback
    return document.querySelector("main") || document.body;
  }

  function ensureStrip(){
    let strip = document.getElementById("vsp_dash_strip_v6c");
    if (strip) return strip;

    const anchor = findGateStoryAnchor();
    strip = document.createElement("div");
    strip.id = "vsp_dash_strip_v6c";
    strip.style.cssText = [
      "margin:12px 0 14px 0",
      "padding:10px 12px",
      "border-radius:16px",
      "border:1px solid rgba(255,255,255,0.10)",
      "background:rgba(255,255,255,0.03)",
      "box-shadow:0 10px 30px rgba(0,0,0,0.20)"
    ].join(";");

    strip.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <span style="font-weight:800;opacity:.92">KPI</span>
          <span id="vsp_dash_strip_overall_v6c" style="padding:4px 10px;border-radius:999px;border:1px solid rgba(255,255,255,0.10);background:rgba(255,255,255,0.06);font-size:12px">OVERALL: --</span>
          <span id="vsp_dash_strip_rid_v6c" style="font-size:12px;opacity:.82">RID: --</span>
          <span id="vsp_dash_strip_last_v6c" style="font-size:12px;opacity:.72">Last: --</span>
        </div>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <button id="vsp_dash_strip_live_v6c" style="padding:6px 10px;border-radius:12px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Live: ON</button>
          <button id="vsp_dash_strip_refresh_v6c" style="padding:6px 10px;border-radius:12px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Refresh</button>
          <button id="vsp_dash_strip_open_v6c" style="padding:6px 10px;border-radius:12px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:inherit;cursor:pointer">Open gate JSON</button>
        </div>
      </div>

      <div style="margin-top:10px;display:grid;grid-template-columns:repeat(6,minmax(110px,1fr));gap:10px">
        ${["TOTAL","HIGH","MEDIUM","LOW","INFO","CRITICAL"].map(k=>`
          <div style="padding:10px 10px;border-radius:14px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.02)">
            <div style="font-size:11px;opacity:.68">${k}</div>
            <div id="vsp_dash_strip_${k}_v6c" style="font-size:18px;font-weight:900;margin-top:2px">--</div>
          </div>
        `).join("")}
      </div>
    `;

    // insert: right BEFORE anchor if possible, else top of body
    try{
      if (anchor && anchor.parentElement){
        anchor.insertAdjacentElement("beforebegin", strip);
      } else {
        (document.body || document.documentElement).insertAdjacentElement("afterbegin", strip);
      }
    } catch(e){
      (document.body || document.documentElement).insertAdjacentElement("afterbegin", strip);
    }

    // events
    document.getElementById("vsp_dash_strip_live_v6c")?.addEventListener("click", ()=>{
      S.live = !S.live;
      document.getElementById("vsp_dash_strip_live_v6c").textContent = S.live ? "Live: ON" : "Live: OFF";
      if (S.live) kick("toggle_on");
    });
    document.getElementById("vsp_dash_strip_refresh_v6c")?.addEventListener("click", ()=>kick("manual"));
    document.getElementById("vsp_dash_strip_open_v6c")?.addEventListener("click", ()=>{
      if (!S.rid) return;
      window.open(`/api/vsp/run_file_allow?${qs({rid:S.rid, path:"run_gate.json"})}`, "_blank");
    });

    return strip;
  }

  function setTxt(id, t){ const e=document.getElementById(id); if(e) e.textContent=t; }

  function styleOverall(ov){
    const s = (ov||"UNKNOWN").toString().toUpperCase();
    const b = document.getElementById("vsp_dash_strip_overall_v6c");
    if (!b) return;
    let bg="rgba(255,255,255,0.06)", bd="rgba(255,255,255,0.10)";
    if (s==="GREEN"||s==="OK"||s==="PASS"){ bg="rgba(46,204,113,0.12)"; bd="rgba(46,204,113,0.25)"; }
    else if (s==="AMBER"||s==="WARN"){ bg="rgba(241,196,15,0.12)"; bd="rgba(241,196,15,0.25)"; }
    else if (s==="RED"||s==="FAIL"||s==="BLOCK"){ bg="rgba(231,76,60,0.12)"; bd="rgba(231,76,60,0.25)"; }
    else if (s==="DEGRADED"){ bg="rgba(155,89,182,0.12)"; bd="rgba(155,89,182,0.25)"; }
    b.textContent = `OVERALL: ${s}`;
    b.style.background = bg;
    b.style.borderColor = bd;
  }

  async function fetchLatestRid(){
    const r = await fetch(`/api/vsp/runs?limit=1&offset=0&_=${now()}`, {cache:"no-store", credentials:"same-origin"});
    if (!r.ok) throw new Error("runs "+r.status);
    const j = await r.json();
    const it = (j && j.items && j.items[0]) ? j.items[0] : null;
    return it ? String(it.rid || it.run_id || "") : "";
  }

  async function fetchGate(rid){
    const r = await fetch(`/api/vsp/run_file_allow?${qs({rid, path:"run_gate.json", _:now()})}`, {cache:"no-store", credentials:"same-origin"});
    if (!r.ok) return null;
    try{ return await r.json(); }catch(e){ return null; }
  }

  function render(g){
    ensureStrip();
    const ct = (g && (g.counts_total||g.counts||g.totals)) ? (g.counts_total||g.counts||g.totals) : {};
    const total = (ct.HIGH||0)+(ct.MEDIUM||0)+(ct.LOW||0)+(ct.INFO||0)+(ct.CRITICAL||0)+(ct.TRACE||0);
    setTxt("vsp_dash_strip_TOTAL_v6c", String(total));
    setTxt("vsp_dash_strip_HIGH_v6c", String(ct.HIGH??"--"));
    setTxt("vsp_dash_strip_MEDIUM_v6c", String(ct.MEDIUM??"--"));
    setTxt("vsp_dash_strip_LOW_v6c", String(ct.LOW??"--"));
    setTxt("vsp_dash_strip_INFO_v6c", String(ct.INFO??"--"));
    setTxt("vsp_dash_strip_CRITICAL_v6c", String(ct.CRITICAL??"--"));
    styleOverall(g && (g.overall||g.overall_status));
  }

  function schedule(ms){ clearTimeout(S.t); S.t=setTimeout(()=>tick("timer"), ms); }
  function kick(){ schedule(200); }

  async function tick(reason){
    ensureStrip(); // also re-attach if missing
    if (!S.live && reason!=="manual") return schedule(S.base);
    if (document.hidden) return schedule(S.base);
    if (S.running) return schedule(600);

    S.running = true;
    try{
      const rid = await fetchLatestRid();
      const changed = rid && rid !== S.rid;
      if (rid) S.rid = rid;
      setTxt("vsp_dash_strip_rid_v6c", `RID: ${S.rid||"--"}`);

      if (changed || !S.gate || reason==="manual"){
        S.gate = await fetchGate(S.rid);
      }
      if (S.gate) render(S.gate);

      setTxt("vsp_dash_strip_last_v6c", `Last: ${new Date().toLocaleTimeString()}${changed ? " • new" : ""}`);
      S.backoff=0; S.delay=S.base;
      schedule(S.delay);
    } catch(e){
      S.backoff += 1;
      S.delay = Math.min(S.max, Math.max(S.base, S.base * (2 ** Math.min(5, S.backoff))));
      setTxt("vsp_dash_strip_last_v6c", `Last: ${new Date().toLocaleTimeString()} • err • backoff ${Math.round(S.delay/1000)}s`);
      schedule(S.delay);
    } finally {
      S.running = false;
    }
  }

  // Re-attach if GateStory re-renders
  const mo = new MutationObserver(()=>{ if (!document.getElementById("vsp_dash_strip_v6c")) ensureStrip(); });
  try{ mo.observe(document.documentElement, {subtree:true, childList:true}); }catch(e){}

  document.addEventListener("visibilitychange", ()=>{ if (!document.hidden && S.live) kick(); });

  // Boot after DOM ready
  if (document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", ()=>{ ensureStrip(); schedule(800); });
  } else {
    ensureStrip(); schedule(800);
  }
})();


// VSP_P1_ALLOW_GATE_REPORTS_V3


/* VSP_P1_AUTOREFRESH_GATE_ROOT_CHANGE_V1 */
(()=> {
  try{
    if (window.__vsp_p1_autorefresh_gate_root_v1) return;
    window.__vsp_p1_autorefresh_gate_root_v1 = true;

    const POLL_MS = 15000;
    const KEY = "__vsp_last_gate_root_seen_v1";
    const KEY_RELOADED = "__vsp_last_gate_root_reloaded_v1";

    async function fetchRunsMeta(){
      const url = "/api/vsp/runs?_ts=" + Date.now();
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) throw new Error("runs meta http " + res.status);
      return await res.json();
    }

    function pickGateRoot(j){
      return (j && (j.rid_latest_gate_root || j.rid_latest || j.rid_last_good || j.rid_latest_findings)) || "";
    }

    async function tick(){
      // chỉ poll khi tab đang active để nhẹ + tránh reload lúc user không xem
      if (document.visibilityState && document.visibilityState !== "visible") return;

      let j;
      try{
        j = await fetchRunsMeta();
      }catch(e){
        console.warn("[VSP][AutoRefresh] runs meta fetch failed", e);
        return;
      }

      const gateRoot = pickGateRoot(j);
      if (!gateRoot) return;

      const lastSeen = sessionStorage.getItem(KEY) || "";
      if (!lastSeen){
        sessionStorage.setItem(KEY, gateRoot);
        console.log("[VSP][AutoRefresh] init gate_root =", gateRoot);
        return;
      }

      if (gateRoot !== lastSeen){
        sessionStorage.setItem(KEY, gateRoot);
        const lastReloaded = sessionStorage.getItem(KEY_RELOADED) || "";
        console.log("[VSP][AutoRefresh] gate_root changed:", lastSeen, "=>", gateRoot);

        // chống loop: chỉ reload 1 lần cho mỗi gateRoot mới
        if (lastReloaded !== gateRoot){
          sessionStorage.setItem(KEY_RELOADED, gateRoot);
          console.log("[VSP][AutoRefresh] reloading to show newest gate_root =", gateRoot);
          setTimeout(()=> { location.reload(); }, 250);
        }
      }
    }

    setInterval(tick, POLL_MS);
    // tick sớm để bắt thay đổi nhanh sau khi run xong
    setTimeout(tick, 1200);
  }catch(e){
    console.warn("[VSP][AutoRefresh] init failed", e);
  }
})();


/* VSP_P1_DASHBOARD_KPI_RENDER_V1 */
(()=> {
  try{
    if (window.__vsp_p1_dashboard_kpi_v1) return;
    window.__vsp_p1_dashboard_kpi_v1 = true;

    const $ = (id)=> document.getElementById(id);
    function setText(id, v){ const el=$(id); if(el) el.textContent = (v==null? "—": String(v)); }
    function safeInt(x){ const n = Number(x); return Number.isFinite(n) ? n : 0; }

    async function fetchJSON(url){
      const res = await fetch(url, { cache:"no-store" });
      if(!res.ok) throw new Error("http " + res.status + " for " + url);
      return await res.json();
    }

    function pickGateRoot(meta){
      return (meta && (meta.rid_latest_gate_root || meta.rid_latest || meta.rid_last_good || meta.rid_latest_findings)) || "";
    }

    function normalizeCounts(j){
      // best-effort across variants
      const out = {CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0,TRACE:0};
      const candidates = [
        j?.counts_by_severity,
        j?.by_severity,
        j?.severity_counts,
        j?.severity,
        j?.summary?.counts_by_severity,
        j?.summary?.by_severity,
      ];
      for (const c of candidates){
        if (!c || typeof c !== "object") continue;
        for (const k of Object.keys(out)){
          if (c[k] != null) out[k] = safeInt(c[k]);
        }
      }
      // sometimes nested like {critical:..} lowercase
      const lc = j?.counts || j?.by_sev || j?.sev || null;
      if (lc && typeof lc === "object"){
        const map = {critical:"CRITICAL", high:"HIGH", medium:"MEDIUM", low:"LOW", info:"INFO", trace:"TRACE"};
        for (const kk of Object.keys(map)){
          if (lc[kk] != null) out[map[kk]] = safeInt(lc[kk]);
        }
      }
      return out;
    }

    function normalizeOverall(j){
      // prefer explicit overall_status / overall
      const x = (j?.overall_status || j?.overall || j?.status || "").toString().toUpperCase();
      if (["RED","AMBER","GREEN"].includes(x)) return x;
      // sometimes PASS/FAIL
      if (x.includes("FAIL")) return "RED";
      if (x.includes("WARN") || x.includes("AMBER")) return "AMBER";
      if (x.includes("PASS") || x.includes("GREEN")) return "GREEN";
      return x || "—";
    }

    function normalizeDegraded(j){
      // accept different shapes
      const d = j?.degraded;
      if (typeof d === "number") return d;
      if (typeof d === "string" && d.match(/^\d+\/\d+$/)) return d;
      const by = j?.by_tool || j?.tools || j?.by_type || null;
      if (by && typeof by === "object"){
        let total=0, deg=0;
        for (const k of Object.keys(by)){
          total++;
          const v = by[k];
          if (v && (v.degraded === true || v.status === "DEGRADED")) deg++;
        }
        if (total>0) return `${deg}/${total}`;
      }
      return "—";
    }

    function renderBar(counts){
      const el = $("vsp_dash_sev_bar");
      if (!el) return;
      el.innerHTML = "";
      const order = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];
      const max = Math.max(1, ...order.map(k=>counts[k]||0));
      for (const k of order){
        const v = counts[k]||0;
        const h = Math.round((v/max)*38) + 6; // 6..44
        const col = document.createElement("div");
        col.style.flex = "1";
        col.style.minWidth = "34px";
        col.style.display = "flex";
        col.style.flexDirection = "column";
        col.style.alignItems = "center";
        const bar = document.createElement("div");
        bar.style.width = "100%";
        bar.style.height = h + "px";
        bar.style.borderRadius = "10px";
        bar.style.border = "1px solid rgba(255,255,255,.10)";
        bar.style.background = "rgba(255,255,255,.06)";
        const lab = document.createElement("div");
        lab.style.marginTop = "6px";
        lab.style.fontSize = "11px";
        lab.style.opacity = ".78";
        lab.textContent = `${k.replace("MEDIUM","MED")}:${v}`;
        col.appendChild(bar);
        col.appendChild(lab);
        el.appendChild(col);
      }
    }

    function paintOverall(overall){
      const el = $("vsp_dash_overall");
      if (!el) return;
      el.textContent = overall || "—";
      el.style.padding = "4px 10px";
      el.style.borderRadius = "999px";
      el.style.display = "inline-block";
      el.style.border = "1px solid rgba(255,255,255,.12)";
      let bg = "rgba(255,255,255,.05)";
      if (overall === "RED") bg = "rgba(255, 72, 72, .18)";
      if (overall === "AMBER") bg = "rgba(255, 190, 64, .18)";
      if (overall === "GREEN") bg = "rgba(80, 220, 140, .16)";
      el.style.background = bg;
    }

    function wireExports(rid){
      const aZip = $("vsp_dash_export_zip");
      const aPdf = $("vsp_dash_export_pdf");
      if (aZip) aZip.href = `/api/vsp/run_export_zip?rid=${encodeURIComponent(rid)}`;
      if (aPdf) aPdf.href = `/api/vsp/run_export_pdf?rid=${encodeURIComponent(rid)}`;
    }

    async function main(){
      // Only if dashboard shell exists
      if (!$("vsp_dash_p1_wrap")) return;

      const meta = await fetchJSON("/api/vsp/runs?_ts=" + Date.now());
      const gateRoot = pickGateRoot(meta);
      if (!gateRoot){
        console.warn("[VSP][DashKPI] no gate_root from /api/vsp/runs");
        return;
      }

      setText("vsp_dash_gate_root", gateRoot);
      setText("vsp_dash_rid_short", gateRoot.slice(0, 24));
      setText("vsp_dash_updated_at", new Date().toLocaleString());
      wireExports(gateRoot);

      // Prefer run_gate_summary.json (fast & normalized); fallback to run_gate.json
      let sum = null;
      try{
        sum = await fetchJSON(`/api/vsp/run_file_allow?rid=${encodeURIComponent(gateRoot)}&path=run_gate_summary.json&_ts=${Date.now()}`);
      }catch(e1){
        console.warn("[VSP][DashKPI] run_gate_summary fetch failed; fallback run_gate.json", e1);
        try{
          sum = await fetchJSON(`/api/vsp/run_file_allow?rid=${encodeURIComponent(gateRoot)}&path=run_gate.json&_ts=${Date.now()}`);
        }catch(e2){
          console.warn("[VSP][DashKPI] run_gate.json fetch failed", e2);
          return;
        }
      }

      const overall = normalizeOverall(sum);
      const degraded = normalizeDegraded(sum);
      const counts = normalizeCounts(sum);

      paintOverall(overall);
      setText("vsp_dash_degraded", degraded);

      setText("vsp_dash_c_critical", `CRIT: ${counts.CRITICAL}`);
      setText("vsp_dash_c_high",     `HIGH: ${counts.HIGH}`);
      setText("vsp_dash_c_medium",   `MED: ${counts.MEDIUM}`);
      setText("vsp_dash_c_low",      `LOW: ${counts.LOW}`);
      setText("vsp_dash_c_info",     `INFO: ${counts.INFO}`);
      setText("vsp_dash_c_trace",    `TRACE: ${counts.TRACE}`);

      renderBar(counts);

      console.log("[VSP][DashKPI] rendered from gate_root:", gateRoot, "overall:", overall, "degraded:", degraded);
    }

    // Run once + refresh lightweight (không reload) để cập nhật timestamp / trạng thái nếu backend update
    main();
    setInterval(()=> {
      if ($("vsp_dash_p1_wrap")) setText("vsp_dash_updated_at", new Date().toLocaleString());
    }, 15000);

  }catch(e){
    console.warn("[VSP][DashKPI] init failed", e);
  }
})();


/* VSP_P1_DASH_AUDIT_ISO_PANEL_V1 */
(()=> {
  try{
    if (window.__vsp_p1_dash_audit_iso_v1) return;
    window.__vsp_p1_dash_audit_iso_v1 = true;

    const $ = (id)=> document.getElementById(id);

    function pill(text, ok){
      const el = document.createElement("span");
      el.className = "vsp_pill";
      el.style.borderColor = ok ? "rgba(80,220,140,.28)" : "rgba(255,72,72,.28)";
      el.style.background = ok ? "rgba(80,220,140,.10)" : "rgba(255,72,72,.10)";
      el.textContent = text;
      return el;
    }

    function badge(text){
      const el = document.createElement("span");
      el.className = "vsp_pill";
      el.style.background = "rgba(255,255,255,.04)";
      el.style.borderColor = "rgba(255,255,255,.10)";
      el.textContent = text;
      return el;
    }

    async function fetchJSON(url){
      const res = await fetch(url, { cache:"no-store" });
      if (!res.ok) throw new Error("http " + res.status + " " + url);
      return await res.json();
    }

    async function probeFile(rid, path){
      const url = `/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=${encodeURIComponent(path)}&_ts=${Date.now()}`;
      try{
        const res = await fetch(url, { cache:"no-store" });
        if (!res.ok) return { ok:false, status:res.status };
        // best-effort: read small text to ensure non-empty
        const txt = await res.text();
        if (!txt || txt.length < 2) return { ok:false, status:200, empty:true };
        return { ok:true, status:200, size:txt.length, text:txt };
      }catch(e){
        return { ok:false, status:0, err:String(e) };
      }
    }

    function ensurePanel(){
      const wrap = $("vsp_dash_p1_wrap");
      if (!wrap) return null;

      // find the KPI grid we already inserted
      const grid = wrap.querySelector("div[style*='grid-template-columns']");
      if (!grid) return null;

      if ($("vsp_dash_audit_card")) return grid;

      const card = document.createElement("div");
      card.id = "vsp_dash_audit_card";
      card.className = "vsp_card";
      card.style.gridColumn = "span 12";
      card.style.minWidth = "320px";

      card.innerHTML = `
        <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center;">
          <div style="opacity:.82;font-size:12px;">Evidence &amp; Audit Readiness</div>
          <div style="opacity:.75;font-size:12px;">
            Status: <span id="vsp_dash_audit_status" class="vsp_pill">—</span>
          </div>
        </div>
        <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;" id="vsp_dash_audit_pills"></div>

        <div style="margin-top:10px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
          <div style="min-width:280px;flex:1;">
            <div style="opacity:.75;font-size:12px;">ISO / DepSecOps hint</div>
            <div style="margin-top:6px;opacity:.9;font-size:12px;line-height:1.4" id="vsp_dash_iso_hint">—</div>
          </div>
          <div style="min-width:280px;flex:1;">
            <div style="opacity:.75;font-size:12px;">Tool lane (8 tools)</div>
            <div style="margin-top:6px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;" id="vsp_dash_tool_lane"></div>
          </div>
        </div>
      `;
      grid.appendChild(card);
      return grid;
    }

    function setAuditStatus(okAll, msg){
      const el = $("vsp_dash_audit_status");
      if (!el) return;
      el.textContent = msg || (okAll ? "AUDIT READY" : "MISSING EVIDENCE");
      el.style.borderColor = okAll ? "rgba(80,220,140,.28)" : "rgba(255,72,72,.28)";
      el.style.background = okAll ? "rgba(80,220,140,.10)" : "rgba(255,72,72,.10)";
    }

    function renderIsoHint(summary){
      const el = $("vsp_dash_iso_hint");
      if (!el) return;

      // best-effort: accept many shapes
      const iso = summary?.iso27001 || summary?.iso_map || summary?.iso || summary?.compliance || null;

      if (iso && typeof iso === "object"){
        const keys = Object.keys(iso);
        const sample = keys.slice(0,6).join(", ");
        el.textContent = `ISO mapping present (${keys.length} keys). Sample: ${sample}`;
      }else{
        // still “commercial”: explain what auditor expects
        el.textContent =
          "ISO mapping not found in run_gate_summary. Recommended: map each rule/tool finding to ISO 27001 controls and keep run_manifest + evidence_index for audit traceability.";
      }
    }

    function renderToolLane(summary){
      const lane = $("vsp_dash_tool_lane");
      if (!lane) return;
      lane.innerHTML = "";

      // try locate tool list
      const byTool = summary?.by_tool || summary?.tools || summary?.tool_status || summary?.summary?.by_tool || null;

      const prefer = ["Bandit","Semgrep","Gitleaks","KICS","Trivy","Syft","Grype","CodeQL"];
      if (byTool && typeof byTool === "object"){
        for (const t of prefer){
          const v = byTool[t] || byTool[t.toLowerCase()] || null;
          const st = (v?.status || v?.state || v || "").toString().toUpperCase();
          const d  = (v?.degraded === true) || (st === "DEGRADED");
          const ok = st ? st : (d ? "DEGRADED" : "OK");
          const b = badge(`${t}:${ok}${d ? "*" : ""}`);
          if (d){
            b.style.borderColor = "rgba(255,190,64,.25)";
            b.style.background = "rgba(255,190,64,.10)";
          }
          lane.appendChild(b);
        }
        return;
      }

      // fallback: show fixed lane (commercial expectation)
      for (const t of prefer){
        lane.appendChild(badge(`${t}:—`));
      }
    }

    async function run(){
      if (!ensurePanel()) return;
      const gateEl = $("vsp_dash_gate_root");
      const rid = gateEl ? (gateEl.textContent || "").trim() : "";
      if (!rid || rid === "—") return;

      // probe evidence files (P0 audit set)
      const req = [
        "run_manifest.json",
        "run_evidence_index.json",
        "run_gate.json",
        "run_gate_summary.json",
        "findings_unified.json",
        "reports/findings_unified.csv",
        "findings_unified.sarif__DISABLED__",
      ];

      const pillsEl = $("vsp_dash_audit_pills");
      if (!pillsEl) return;
      pillsEl.innerHTML = "";

      let okAll = true;
      const results = {};
      for (const f of req){
        const r = await probeFile(rid, f);
        results[f] = r;
        if (!r.ok) okAll = false;
        pillsEl.appendChild(pill(`${f}${r.ok ? "" : " ✗"}`, r.ok));
      }
      setAuditStatus(okAll, okAll ? "AUDIT READY" : "MISSING EVIDENCE");

      // also render ISO/tool info using run_gate_summary (best-effort)
      let summary = null;
      try{
        summary = await fetchJSON(`/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=run_gate_summary.json&_ts=${Date.now()}`);
      }catch(_e){
        try{
          summary = await fetchJSON(`/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=run_gate.json&_ts=${Date.now()}`);
        }catch(__e){
          summary = null;
        }
      }
      renderIsoHint(summary);
      renderToolLane(summary);

      console.log("[VSP][DashAuditISO] rid=", rid, "audit_ready=", okAll);
    }

    // kick once + periodic refresh
    setTimeout(run, 1400);
    setInterval(()=> {
      // only run when dashboard visible
      if (document.visibilityState && document.visibilityState !== "visible") return;
      run();
    }, 30000);

  }catch(e){
    console.warn("[VSP][DashAuditISO] init failed", e);
  }
})();


/* VSP_P0_DASH_FORCE_INJECT_AND_GATE_ROOT_HOOK_V1
   Purpose:
   1) Global fetch hook: any /api/vsp/runs json will be mutated to prefer rid_latest_gate_root
      by forcing rid_last_good/rid_latest => rid_latest_gate_root. This fixes GateStory picking last_good.
   2) Force inject Dashboard shell on /vsp5 even if backend serves minimal HTML (gate-only).
   3) Render KPI + Audit evidence probes from gate_root.
*/
(()=> {
  try{
    if (window.__vsp_p0_dash_force_inject_v1) return;
    window.__vsp_p0_dash_force_inject_v1 = true;

    // ---------- (1) Global fetch hook for /api/vsp/runs ----------
    const _fetch = window.fetch ? window.fetch.bind(window) : null;
    if (_fetch && !window.__vsp_p0_runs_fetch_hooked_v1){
      window.__vsp_p0_runs_fetch_hooked_v1 = true;
      if (!window.__vsp_disable_interceptors_v1) window.fetch = async (input, init) => {
        const res = await _fetch(input, init);
        try{
          const url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
          if (url && url.indexOf("/api/vsp/runs") !== -1 && res && res.ok && typeof res.json === "function"){
            const _json = res.json.bind(res);
            res.json = async () => {
              const j = await _json();
              try{
                if (j && j.rid_latest_gate_root){
                  j.__vsp_prefer_gate_root = true;
                  j.__vsp_gate_root = j.rid_latest_gate_root;
                  // force any picker that uses last_good/latest to land on gate_root
                  j.rid_last_good = j.rid_latest_gate_root;
                  j.rid_latest    = j.rid_latest_gate_root;
                  console.log("[VSP][runs_hook] prefer gate_root:", j.rid_latest_gate_root);
                }
              }catch(e){
                console.warn("[VSP][runs_hook] mutate err", e);
              }
              return j;
            };
          }
        }catch(e){
          // ignore
        }
        return res;
      };
      console.log("[VSP][runs_hook] installed");
    }

    // ---------- Helpers ----------
    const $ = (id)=> document.getElementById(id);
    const setText = (id, v)=> { const el=$(id); if(el) el.textContent = (v==null? "—": String(v)); };

    async function fetchJSON(url){
      const r = await fetch(url, { cache:"no-store" });
      if (!r.ok) throw new Error("http "+r.status+" "+url);
      return await r.json();
    }
    async function probeText(url){

/* VSP_DISABLE_PROBE_SARIF_V1 */
try{
  if (window.__vsp_disable_probe_sarif_v1) {
    const _p = (typeof path!=="undefined" ? path : (arguments.length>1 ? arguments[1] : "")) || "";
    if (/\.sarif(\?|$)/i.test(_p) || /findings_unified\.sarif/i.test(_p)) {
      return Promise.resolve(false);
    }
  }
}catch(_){}


/* VSP_DISABLE_PROBE_SARIF */

if (window.__vsp_disable_probe_sarif_v1) {
  try {
    const _p = (typeof path!=="undefined" ? path : (arguments.length>1 ? arguments[1] : "")) || "";
    if (/\.sarif(\?|$)/i.test(_p) || /findings_unified\.sarif/i.test(_p)) {
      return Promise.resolve(false);
    }
  } catch(_){}
}

      const r = await fetch(url, { cache:"no-store" });
      if (!r.ok) return { ok:false, status:r.status, size:0 };
      const t = await r.text();
      return { ok: !!t && t.length>1, status:200, size:(t||"").length, text:t||"" };
    }

    function isDash(){
      const p = (location && location.pathname) ? location.pathname : "";
      return (p === "/vsp5" || p === "/vsp5/" || p.indexOf("/vsp5") === 0);
    }

    function ensureDashShell(){
      if (!isDash()) return false;
      if ($("vsp_dash_p1_wrap")) return true;

      const wrap = document.createElement("div");
      wrap.id = "vsp_dash_p1_wrap";
      wrap.style.padding = "14px 14px 10px 14px";

      wrap.innerHTML = `
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
          <div style="min-width:260px;">
            <div style="font-size:18px;font-weight:700;letter-spacing:.2px;">VSP • Dashboard</div>
            <div style="opacity:.78;font-size:12px;margin-top:4px;">
              Tool truth (gate_root): <span id="vsp_dash_gate_root" style="font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;">—</span>
              • Updated: <span id="vsp_dash_updated_at">—</span>
            </div>
          </div>

          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:flex-end;">
            <a class="vsp_btn" href="/runs" style="text-decoration:none;">Runs &amp; Reports</a>
            <a class="vsp_btn" href="/data_source" style="text-decoration:none;">Data Source</a>
            <a class="vsp_btn" href="/settings" style="text-decoration:none;">Settings</a>
            <a class="vsp_btn" href="/rule_overrides" style="text-decoration:none;">Rule Overrides</a>
            <span style="width:1px;height:22px;background:rgba(255,255,255,.10);display:inline-block;"></span>
            <a class="vsp_btn" id="vsp_dash_export_zip" href="#" style="text-decoration:none;">Export ZIP</a>
            <a class="vsp_btn" id="vsp_dash_export_pdf" href="#" style="text-decoration:none;">Export PDF</a>
          </div>
        </div>

        <div id="vsp_dash_grid" style="display:grid;grid-template-columns:repeat(12, 1fr);gap:10px;margin-top:12px;">
          <div style="grid-column:span 3;min-width:220px;" class="vsp_card">
            <div style="opacity:.75;font-size:12px;">Overall</div>
            <div id="vsp_dash_overall" style="margin-top:6px;font-size:20px;font-weight:800;">—</div>
            <div style="margin-top:6px;opacity:.75;font-size:12px;">Degraded: <span id="vsp_dash_degraded">—</span></div>
          </div>

          <div style="grid-column:span 3;min-width:220px;" class="vsp_card">
            <div style="opacity:.75;font-size:12px;">Findings (counts)</div>
            <div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:8px;">
              <span class="vsp_pill" id="vsp_dash_c_critical">CRIT: —</span>
              <span class="vsp_pill" id="vsp_dash_c_high">HIGH: —</span>
              <span class="vsp_pill" id="vsp_dash_c_medium">MED: —</span>
              <span class="vsp_pill" id="vsp_dash_c_low">LOW: —</span>
            </div>
            <div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:8px;">
              <span class="vsp_pill" id="vsp_dash_c_info">INFO: —</span>
              <span class="vsp_pill" id="vsp_dash_c_trace">TRACE: —</span>
            </div>
          </div>

          <div style="grid-column:span 6;min-width:320px;" class="vsp_card">
            <div style="opacity:.75;font-size:12px;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;">
              <span>Severity bar</span>
              <span style="opacity:.75">RID: <span id="vsp_dash_rid_short" style="font-family:ui-monospace, monospace;">—</span></span>
            </div>
            <div id="vsp_dash_sev_bar" style="margin-top:10px;display:flex;gap:8px;align-items:flex-end;min-height:44px;"></div>
            <div style="opacity:.7;font-size:12px;margin-top:8px;">Dashboard auto-reloads when gate_root changes (tool truth).</div>
          </div>

          <div id="vsp_dash_audit_card" style="grid-column:span 12;min-width:320px;" class="vsp_card">
            <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center;">
              <div style="opacity:.82;font-size:12px;">Evidence &amp; Audit Readiness</div>
              <div style="opacity:.75;font-size:12px;">Status: <span id="vsp_dash_audit_status" class="vsp_pill">—</span></div>
            </div>
            <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;" id="vsp_dash_audit_pills"></div>
            <div style="margin-top:10px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
              <div style="min-width:280px;flex:1;">
                <div style="opacity:.75;font-size:12px;">ISO / DepSecOps hint</div>
                <div style="margin-top:6px;opacity:.9;font-size:12px;line-height:1.4" id="vsp_dash_iso_hint">—</div>
              </div>
              <div style="min-width:280px;flex:1;">
                <div style="opacity:.75;font-size:12px;">Tool lane (8 tools)</div>
                <div style="margin-top:6px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;" id="vsp_dash_tool_lane"></div>
              </div>
            </div>
          </div>
        </div>

        <style>
          .vsp_card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:12px;box-shadow:0 8px 24px rgba(0,0,0,.35);}
          .vsp_btn{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.10);padding:8px 10px;border-radius:12px;font-size:12px;opacity:.9}
          .vsp_btn:hover{opacity:1;filter:brightness(1.08)}
          .vsp_pill{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.10);padding:6px 8px;border-radius:999px;font-size:12px}
        </style>
      `;

      // Insert right after the first block (usually Gate Story bar exists above)
      const b = document.body;
      if (!b) return false;
      if (b.children && b.children.length > 0) b.insertBefore(wrap, b.children[1] || null);
      else b.appendChild(wrap);

      return true;
    }

    function paintOverall(overall){
      const el = $("vsp_dash_overall");
      if (!el) return;
      el.textContent = overall || "—";
      el.style.padding = "4px 10px";
      el.style.borderRadius = "999px";
      el.style.display = "inline-block";
      el.style.border = "1px solid rgba(255,255,255,.12)";
      let bg = "rgba(255,255,255,.05)";
      if (overall === "RED") bg = "rgba(255, 72, 72, .18)";
      if (overall === "AMBER") bg = "rgba(255, 190, 64, .18)";
      if (overall === "GREEN") bg = "rgba(80, 220, 140, .16)";
      el.style.background = bg;
    }

    function normalizeCounts(j){
      const out = {CRITICAL:0,HIGH:0,MEDIUM:0,LOW:0,INFO:0,TRACE:0};
      const c = j?.counts_by_severity || j?.by_severity || j?.severity_counts || j?.summary?.counts_by_severity || null;
      if (c && typeof c === "object"){
        for (const k of Object.keys(out)) if (c[k] != null) out[k] = Number(c[k])||0;
      }
      return out;
    }

    function renderBar(counts){
      const el = $("vsp_dash_sev_bar");
      if (!el) return;
      el.innerHTML = "";
      const order = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];
      const max = Math.max(1, ...order.map(k=>counts[k]||0));
      for (const k of order){
        const v = counts[k]||0;
        const h = Math.round((v/max)*38)+6;
        const col = document.createElement("div");
        col.style.flex="1"; col.style.minWidth="34px";
        col.style.display="flex"; col.style.flexDirection="column"; col.style.alignItems="center";
        const bar = document.createElement("div");
        bar.style.width="100%"; bar.style.height=h+"px";
        bar.style.borderRadius="10px";
        bar.style.border="1px solid rgba(255,255,255,.10)";
        bar.style.background="rgba(255,255,255,.06)";
        const lab = document.createElement("div");
        lab.style.marginTop="6px"; lab.style.fontSize="11px"; lab.style.opacity=".78";
        lab.textContent = `${k.replace("MEDIUM","MED")}:${v}`;
        col.appendChild(bar); col.appendChild(lab);
        el.appendChild(col);
      }
    }

    function pill(text, ok){
      const el = document.createElement("span");
      el.className = "vsp_pill";
      el.style.borderColor = ok ? "rgba(80,220,140,.28)" : "rgba(255,72,72,.28)";
      el.style.background = ok ? "rgba(80,220,140,.10)" : "rgba(255,72,72,.10)";
      el.textContent = text;
      return el;
    }
    function badge(text){
      const el = document.createElement("span");
      el.className = "vsp_pill";
      el.style.background="rgba(255,255,255,.04)";
      el.style.borderColor="rgba(255,255,255,.10)";
      el.textContent=text;
      return el;
    }

    async function renderDash(){
      if (!ensureDashShell()) return;

      // meta -> gate_root
      const meta = await fetchJSON("/api/vsp/runs?_ts=" + Date.now());
      const gateRoot = meta?.rid_latest_gate_root || meta?.rid_latest || meta?.rid_last_good || meta?.rid_latest_findings || "";
      if (!gateRoot) return;

      setText("vsp_dash_gate_root", gateRoot);
      setText("vsp_dash_rid_short", gateRoot.slice(0, 24));
      setText("vsp_dash_updated_at", new Date().toLocaleString());
      const aZip = $("vsp_dash_export_zip"), aPdf = $("vsp_dash_export_pdf");
      if (aZip) aZip.href = `/api/vsp/run_export_zip?rid=${encodeURIComponent(gateRoot)}`;
      if (aPdf) aPdf.href = `/api/vsp/run_export_pdf?rid=${encodeURIComponent(gateRoot)}`;

      // summary: prefer run_gate_summary
      let sum = null;
      try{
        sum = await fetchJSON(`/api/vsp/run_file_allow?rid=${encodeURIComponent(gateRoot)}&path=run_gate_summary.json&_ts=${Date.now()}`);
      }catch(e1){
        sum = await fetchJSON(`/api/vsp/run_file_allow?rid=${encodeURIComponent(gateRoot)}&path=run_gate.json&_ts=${Date.now()}`);
      }

      const overall = (sum?.overall_status || sum?.overall || sum?.status || "—").toString().toUpperCase();
      paintOverall(["RED","AMBER","GREEN"].includes(overall) ? overall : overall || "—");
      setText("vsp_dash_degraded", (sum?.degraded!=null)? sum.degraded : "—");

      const counts = normalizeCounts(sum);
      setText("vsp_dash_c_critical", `CRIT: ${counts.CRITICAL}`);
      setText("vsp_dash_c_high",     `HIGH: ${counts.HIGH}`);
      setText("vsp_dash_c_medium",   `MED: ${counts.MEDIUM}`);
      setText("vsp_dash_c_low",      `LOW: ${counts.LOW}`);
      setText("vsp_dash_c_info",     `INFO: ${counts.INFO}`);
      setText("vsp_dash_c_trace",    `TRACE: ${counts.TRACE}`);
      renderBar(counts);

      // audit probes
      const req = [
        "run_manifest.json",
        "run_evidence_index.json",
        "run_gate.json",
        "run_gate_summary.json",
        "findings_unified.json",
        "reports/findings_unified.csv",
        "findings_unified.sarif__DISABLED__",
      ];
      const pillsEl = $("vsp_dash_audit_pills");
      if (pillsEl) pillsEl.innerHTML = "";
      let okAll = true;

      for (const f of req){
        const u = `/api/vsp/run_file_allow?rid=${encodeURIComponent(gateRoot)}&path=${encodeURIComponent(f)}&_ts=${Date.now()}`;
        const r = await probeText(u);
        if (!r.ok) okAll = false;
        if (pillsEl) pillsEl.appendChild(pill(`${f}${r.ok?"":" ✗"}`, r.ok));
      }
      const st = $("vsp_dash_audit_status");
      if (st){
        st.textContent = okAll ? "AUDIT READY" : "MISSING EVIDENCE";
        st.style.borderColor = okAll ? "rgba(80,220,140,.28)" : "rgba(255,72,72,.28)";
        st.style.background  = okAll ? "rgba(80,220,140,.10)" : "rgba(255,72,72,.10)";
      }

      // ISO hint + tool lane
      const isoEl = $("vsp_dash_iso_hint");
      if (isoEl){
        const iso = sum?.iso27001 || sum?.iso_map || sum?.iso || sum?.compliance || null;
        if (iso && typeof iso === "object"){
          const keys = Object.keys(iso);
          isoEl.textContent = `ISO mapping present (${keys.length} keys).`;
        } else {
          isoEl.textContent = "ISO mapping not found in gate summary. (P0) Recommend mapping findings to ISO 27001 controls and keep manifest + evidence_index for audit traceability.";
        }
      }
      const lane = $("vsp_dash_tool_lane");
      if (lane){
        lane.innerHTML = "";
        const byTool = sum?.by_tool || sum?.tools || sum?.tool_status || sum?.summary?.by_tool || null;
        const prefer = ["Bandit","Semgrep","Gitleaks","KICS","Trivy","Syft","Grype","CodeQL"];
        if (byTool && typeof byTool === "object"){
          for (const t of prefer){
            const v = byTool[t] || byTool[t.toLowerCase()] || null;
            const st = (v?.status || v?.state || v || "—").toString().toUpperCase();
            lane.appendChild(badge(`${t}:${st||"—"}`));
          }
        } else {
          for (const t of prefer) lane.appendChild(badge(`${t}:—`));
        }
      }

      console.log("[VSP][DashForce] rendered dashboard from gate_root:", gateRoot);
    }

    // Run after DOM ready
    const kick = ()=> { renderDash().catch(e=>console.warn("[VSP][DashForce] render err", e)); };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ()=> setTimeout(kick, 200));
    else setTimeout(kick, 200);

    // refresh timestamp / light update
    setInterval(()=> {
      if (!isDash()) return;
      if (document.visibilityState && document.visibilityState !== "visible") return;
      setText("vsp_dash_updated_at", new Date().toLocaleString());
    }, 15000);

  }catch(e){
    console.warn("[VSP][DashForce] init failed", e);
  }
})();


/* ===================== VSP_P1_DASHBOARD_LOADER_HOOK_V1 =====================
   Commercial rule: vsp_bundle_commercial_v2.js acts as LOADER/HOOK only.
   Dashboard logic lives in: /static/js/vsp_dashboard_commercial_v1.js
*/
(()=> {
  try{
    if (window.__vsp_p1_dashboard_loader_hook_v1) return;
    window.__vsp_p1_dashboard_loader_hook_v1 = true;

    const path = (location && location.pathname) ? location.pathname : "";
    const isDash = (path === "/vsp5" || path === "/dashboard" || path === "/") ||
                   document.querySelector('meta[name="vsp-page"][content="dashboard"]') ||
                   document.getElementById("vsp_dashboard") ||
                   document.getElementById("dashboard");

    if (!isDash) return;

    // Prevent "double nav" feeling: we will render DashCommercialV1 into mount,
    // and we DO NOT require Gate Story JS on dashboard.
    const id = "VSP_DASH_COMMERCIAL_V1_JS";
    if (document.getElementById(id)) return;

    const sc = document.createElement("script");
    sc.id = id;
    sc.defer = true;
    sc.src = "/static/js/vsp_dashboard_commercial_v1.js?v=" + (window.__VSP_ASSET_V__ || Date.now());
    document.head.appendChild(sc);

    console.log("[VSP][Bundle] loader hooked -> DashCommercialV1");
  }catch(e){
    console.warn("[VSP][Bundle] loader hook failed:", e);
  }
})();
/* ===================== /VSP_P1_DASHBOARD_LOADER_HOOK_V1 ===================== */




/* VSP_P0_DASH_RID_TOOLBAR_AUTOSYNC_V1 */
(()=> {
  if (window.__vsp_p0_dash_rid_toolbar_autosync_v1) return;
  window.__vsp_p0_dash_rid_toolbar_autosync_v1 = true;

  const isDash = ()=> {
    try{
      const p = (location.pathname||"");
      return p === "/vsp5" || p.startsWith("/vsp5/");
    }catch(e){ return false; }
  };

  const LS_RID = "vsp_selected_rid";
  const LS_AUTO = "vsp_dash_auto_latest"; // "1" or "0"

  function getPinnedRid(){
    try{ return (localStorage.getItem(LS_RID)||"").trim(); }catch(e){ return ""; }
  }
  function setPinnedRid(rid){
    try{ localStorage.setItem(LS_RID, String(rid||"").trim()); }catch(e){}
  }

  function setRidGlobal(rid, why){
    const r = String(rid||"").trim();
    if (!r) return;
    try{ window.__VSP_SELECTED_RID = r; }catch(e){}
    setPinnedRid(r);
    try{
      window.dispatchEvent(new CustomEvent("vsp:rid", {detail:{rid:r, why: why||"setRidGlobal"}}));
    }catch(e){}
  }

  async function getLatestRid(){
    try{
      const r = await fetch("/api/vsp/rid_latest_gate_root_gate_root", {credentials:"same-origin"});
      if (!r.ok) return null;
      const j = await r.json();
      if (j && j.ok && j.rid) return j;
    }catch(e){}
    return null;
  }

  function el(tag, attrs, html){
    const x = document.createElement(tag);
    if (attrs){
      for (const k of Object.keys(attrs)){
        if (k === "class") x.className = attrs[k];
        else if (k === "style") x.setAttribute("style", attrs[k]);
        else x.setAttribute(k, attrs[k]);
      }
    }
    if (html != null) x.innerHTML = html;
    return x;
  }

  function css(){
    return `
#vspRidBar{
  position: sticky; top: 0; z-index: 9999;
  margin: 10px 0 0 0;
  padding: 10px 12px;
  border-radius: 12px;
  background: rgba(10, 16, 28, 0.85);
  border: 1px solid rgba(255,255,255,0.08);
  backdrop-filter: blur(8px);
}
#vspRidBar .row{display:flex; align-items:center; gap:10px; flex-wrap:wrap;}
#vspRidBar .pill{
  padding: 6px 10px; border-radius: 999px;
  border: 1px solid rgba(255,255,255,0.10);
  background: rgba(255,255,255,0.04);
  font-size: 12px;
}
#vspRidBar input{
  min-width: 360px;
  padding: 8px 10px;
  border-radius: 10px;
  border: 1px solid rgba(255,255,255,0.10);
  background: rgba(0,0,0,0.25);
  color: #e9eefc;
  outline: none;
}
#vspRidBar button{
  padding: 8px 10px;
  border-radius: 10px;
  border: 1px solid rgba(255,255,255,0.10);
  background: rgba(255,255,255,0.04);
  color: #e9eefc;
  cursor: pointer;
}
#vspRidBar button:hover{ background: rgba(255,255,255,0.07); }
#vspRidBar .muted{opacity:0.75; font-size:12px;}
#vspRidBar .ok{color:#90ee90;}
#vspRidBar .warn{color:#ffd27d;}
`;
  }

  function installBar(){
    const host = document.querySelector(".vsp5-shell, body") || document.body;
    if (!host || document.getElementById("vspRidBar")) return;

    const style = el("style", null, css());
    document.head.appendChild(style);

    const bar = el("div", {id:"vspRidBar"});
    bar.innerHTML = `
      <div class="row">
        <span class="pill">RID</span>
        <input id="vspRidInput" spellcheck="false" placeholder="VSP_CI_YYYYmmdd_HHMMSS" />
        <button id="vspRidUse">Use RID</button>
        <button id="vspRidLatest">Sync latest</button>
        <button id="vspRidCopy">Copy</button>
        <label class="pill" style="display:flex; gap:8px; align-items:center;">
          <input id="vspRidAuto" type="checkbox" style="min-width:auto; width:16px; height:16px;" />
          Auto latest (30s)
        </label>
        <span id="vspRidStatus" class="muted">…</span>
      </div>
      <div class="row" style="margin-top:8px;">
        <span class="muted">Tip:</span>
        <span class="muted">Pin RID in localStorage + broadcast <code>vsp:rid</code> so GateStory/Panels refresh together.</span>
      </div>
    `;

    // Insert near top of body content (after tabs if present)
    const first = document.body.firstElementChild;
    if (first) first.insertAdjacentElement("afterend", bar);
    else document.body.prepend(bar);

    const $rid = bar.querySelector("#vspRidInput");
    const $use = bar.querySelector("#vspRidUse");
    const $latest = bar.querySelector("#vspRidLatest");
    const $copy = bar.querySelector("#vspRidCopy");
    const $auto = bar.querySelector("#vspRidAuto");
    const $st = bar.querySelector("#vspRidStatus");

    const pinned = getPinnedRid() || String(window.__VSP_SELECTED_RID||"").trim();
    if (pinned) $rid.value = pinned;

    const autoOn = (()=>{ try{return (localStorage.getItem(LS_AUTO)||"1")==="1";}catch(e){return true;} })();
    $auto.checked = autoOn;

    function setStatus(msg, cls){
      $st.textContent = msg;
      $st.className = "muted " + (cls||"");
    }

    $use.addEventListener("click", ()=> {
      const r = ($rid.value||"").trim();
      if (!r) return setStatus("RID empty", "warn");
      setRidGlobal(r, "toolbar_use");
      setStatus("Pinned RID = " + r, "ok");
    });

    $latest.addEventListener("click", async ()=> {
      setStatus("Syncing latest…");
      const j = await getLatestRid();
      if (!j) return setStatus("latest_rid not available", "warn");
      $rid.value = j.rid;
      setRidGlobal(j.rid, "toolbar_latest");
      setStatus("Latest RID = " + j.rid, "ok");
    });

    $copy.addEventListener("click", async ()=> {
      const r = ($rid.value||"").trim();
      try{
        await navigator.clipboard.writeText(r);
        setStatus("Copied", "ok");
      }catch(e){
        setStatus("Copy failed", "warn");
      }
    });

    $auto.addEventListener("change", ()=> {
      try{ localStorage.setItem(LS_AUTO, $auto.checked ? "1" : "0"); }catch(e){}
      setStatus("Auto latest = " + ($auto.checked ? "ON" : "OFF"));
    });

    // keep input in sync when something else sets rid
    window.addEventListener("vsp:rid", (e)=> {
      try{
        const r = String(e && e.detail && e.detail.rid ? e.detail.rid : "").trim();
        if (!r) return;
        $rid.value = r;
        setStatus("RID event: " + r, "ok");
      }catch(_){}
    });

    setStatus("Ready", "ok");
  }

  async function autoLoop(){
    // commercial: always follow latest run if enabled
    for(;;){
      await new Promise(r=> setTimeout(r, 30000));
      if (!isDash()) continue;
      let autoOn = true;
      try{ autoOn = (localStorage.getItem(LS_AUTO)||"1")==="1"; }catch(e){}
      if (!autoOn) continue;

      const j = await getLatestRid();
      if (!j || !j.rid) continue;

      const cur = String(window.__VSP_SELECTED_RID||"").trim() || getPinnedRid();
      if (cur !== j.rid){
        setRidGlobal(j.rid, "auto_latest");
      }
    }
  }

  function boot(){
    if (!isDash()) return;
    installBar();
    // initial: if nothing pinned -> sync latest once
    (async ()=>{
      const cur = String(window.__VSP_SELECTED_RID||"").trim() || getPinnedRid();
      if (!cur){
        const j = await getLatestRid();
        if (j && j.rid) setRidGlobal(j.rid, "boot_latest");
      }
    })();
    autoLoop();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();




/* VSP_P0_DASH_ENHANCER_TREND_BADGES_EXPORTS_V1 */
(()=> {
  if (window.__vsp_p0_dash_enh_v1) return;
  window.__vsp_p0_dash_enh_v1 = true;

  const isDash = ()=> {
    try{ return (location.pathname||"") === "/vsp5"; }catch(e){ return false; }
  };

  const TOOL_ORDER = ["Bandit","Semgrep","Gitleaks","KICS","Trivy","Syft","Grype","CodeQL"];

  function el(tag, attrs, html){
    const x = document.createElement(tag);
    if (attrs){
      for (const k of Object.keys(attrs)){
        if (k==="class") x.className = attrs[k];
        else if (k==="style") x.setAttribute("style", attrs[k]);
        else x.setAttribute(k, attrs[k]);
      }
    }
    if (html != null) x.innerHTML = html;
    return x;
  }

  function css(){
    return `
#vspDashEnh{
  margin-top: 12px;
  display: grid;
  grid-template-columns: 1.2fr 1fr;
  gap: 12px;
}
@media (max-width: 1100px){
  #vspDashEnh{ grid-template-columns: 1fr; }
}
.vspCard{
  border-radius: 14px;
  border: 1px solid rgba(255,255,255,0.08);
  background: rgba(255,255,255,0.03);
  padding: 12px;
}
.vspCard h3{
  margin: 0 0 8px 0;
  font-size: 13px;
  opacity: 0.9;
  letter-spacing: 0.2px;
}
.vspRow{display:flex; gap:10px; flex-wrap:wrap; align-items:center;}
.vspPill{
  padding: 6px 10px;
  border-radius: 999px;
  border: 1px solid rgba(255,255,255,0.10);
  background: rgba(0,0,0,0.18);
  font-size: 12px;
  cursor: default;
}
.vspPill.ok{border-color: rgba(144,238,144,0.35);}
.vspPill.warn{border-color: rgba(255,210,125,0.35);}
.vspPill.bad{border-color: rgba(255,120,120,0.35);}
.vspMini{
  font-size: 12px; opacity: 0.8;
}
#vspTrendSvg{ width: 100%; height: 56px; display:block; }
.vspBtn{
  padding: 8px 10px;
  border-radius: 10px;
  border: 1px solid rgba(255,255,255,0.10);
  background: rgba(255,255,255,0.04);
  color: #e9eefc;
  cursor: pointer;
  font-size: 12px;
}
.vspBtn:hover{ background: rgba(255,255,255,0.07); }
code{opacity:0.9;}
`;
  }

  async function fetchJSON(url){
    const r = await fetch(url, {credentials:"same-origin"});
    if (!r.ok) throw new Error("HTTP "+r.status);
    return await r.json();
  }

  function pickRid(){
    try{
      const r = String(window.__VSP_SELECTED_RID||"").trim();
      if (r) return r;
    }catch(e){}
    try{
      const ls = (localStorage.getItem("vsp_selected_rid")||"").trim();
      if (ls) return ls;
    }catch(e){}
    return "";
  }

  function ensureMount(){
    if (document.getElementById("vspDashEnh")) return;
    const st = el("style", null, css());
    document.head.appendChild(st);

    // try place under existing "Commercial Panels" area; else after RID bar; else top of body
    const after = document.querySelector("#vspRidBar") || document.querySelector(".vsp5-shell") || document.body;
    const mount = el("div", {id:"vspDashEnh"});
    mount.appendChild(el("div", {class:"vspCard", id:"vspDashTrendCard"}, `
      <h3>Run Trend (last 30)</h3>
      <div class="vspRow" id="vspTrendStats"></div>
      <svg id="vspTrendSvg" viewBox="0 0 600 56" preserveAspectRatio="none"></svg>
      <div class="vspMini" id="vspTrendHint">Auto updates on RID change.</div>
    `));
    mount.appendChild(el("div", {class:"vspCard", id:"vspDashActionsCard"}, `
      <h3>Quick Actions</h3>
      <div class="vspRow" id="vspToolBadges"></div>
      <div style="height:10px"></div>
      <div class="vspRow" id="vspExportBtns"></div>
      <div class="vspMini" id="vspActionHint"></div>
    `));

    // insert after RID bar if possible
    if (after && after.insertAdjacentElement){
      after.insertAdjacentElement("afterend", mount);
    }else{
      document.body.prepend(mount);
    }
  }

  function drawSpark(svg, ys){
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    const W=600, H=56;
    if (!ys || ys.length < 2) return;
    const max = Math.max(...ys.map(x=> Number(x)||0), 1);
    const min = Math.min(...ys.map(x=> Number(x)||0), 0);
    const span = Math.max(1, max - min);
    const n = ys.length;

    const pts = ys.map((v,i)=>{
      const x = (i/(n-1))*W;
      const y = H - ((Number(v)-min)/span)*H;
      return [x,y];
    });

    const path = document.createElementNS("http://www.w3.org/2000/svg","path");
    const d = pts.map((p,i)=> (i===0?`M ${p[0].toFixed(2)} ${p[1].toFixed(2)}`:`L ${p[0].toFixed(2)} ${p[1].toFixed(2)}`)).join(" ");
    path.setAttribute("d", d);
    path.setAttribute("fill", "none");
    path.setAttribute("stroke-width", "2");
    path.setAttribute("stroke", "currentColor");
    path.setAttribute("opacity", "0.9");
    svg.appendChild(path);
  }

  function pill(text, cls){
    const x = el("span", {class:"vspPill "+(cls||"")}, text);
    return x;
  }

  async function loadTrend(){
    const stats = document.getElementById("vspTrendStats");
    const svg = document.getElementById("vspTrendSvg");
    if (!stats || !svg) return;

    stats.innerHTML = "";
    stats.appendChild(pill("loading…"));

    try{
      const j = await fetchJSON("/api/vsp/runs?limit=30");
      const runs = (j && j.runs) ? j.runs : (Array.isArray(j)? j : []);
      // For each run, try to infer overall/total from fields if present; fallback just count.
      const totals = [];
      let red=0, amber=0, green=0;

      for (const r of runs){
        const overall = String(r.overall || r.status || "").toUpperCase();
        if (overall==="RED") red++;
        else if (overall==="AMBER" || overall==="YELLOW") amber++;
        else if (overall==="GREEN") green++;

        const t = (r.total_findings ?? r.total ?? r.count_total ?? r.counts_total ?? null);
        if (typeof t === "number") totals.push(t);
        else totals.push(0);
      }

      stats.innerHTML = "";
      stats.appendChild(pill("runs: "+runs.length, "ok"));
      stats.appendChild(pill("GREEN: "+green, "ok"));
      stats.appendChild(pill("AMBER: "+amber, "warn"));
      stats.appendChild(pill("RED: "+red, "bad"));

      drawSpark(svg, totals.reverse());
    }catch(e){
      stats.innerHTML = "";
      stats.appendChild(pill("trend unavailable", "warn"));
    }
  }

  async function loadBadgesAndExports(){
    const rid = pickRid();
    const badges = document.getElementById("vspToolBadges");
    const btns = document.getElementById("vspExportBtns");
    const hint = document.getElementById("vspActionHint");
    if (!badges || !btns || !hint) return;

    badges.innerHTML = "";
    btns.innerHTML = "";
    hint.textContent = "";

    if (!rid){
      badges.appendChild(pill("RID not set", "warn"));
      return;
    }

    // Tool badges (from run_gate_summary.json if exists)
    try{
      const sum = await fetchJSON(`/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=run_gate_summary.json`);
      const by_tool = sum && sum.by_tool ? sum.by_tool : null;

      for (const name of TOOL_ORDER){
        let cls = "ok";
        let txt = name;
        try{
          const t = by_tool ? (by_tool[name] || by_tool[name.toLowerCase()] || null) : null;
          const degraded = !!(t && (t.degraded || t.timeout || t.missing));
          if (degraded) cls = "warn";
          if (t && t.missing) cls = "bad";
          if (t && t.timeout) cls = "warn";
          if (t && t.status) txt = `${name}: ${String(t.status).toUpperCase()}`;
        }catch(e){}
        badges.appendChild(pill(txt, cls));
      }
    }catch(e){
      // fallback: show only RID
      badges.appendChild(pill("RID: "+rid, "ok"));
      badges.appendChild(pill("tool summary unavailable", "warn"));
    }

    // Export buttons (best-effort; open in new tab)
    const mk = (label, path)=> {
      const b = el("button", {class:"vspBtn", type:"button"}, label);
      b.addEventListener("click", ()=> {
        const url = `/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=${encodeURIComponent(path)}`;
        window.open(url, "_blank", "noopener");
      });
      return b;
    };

    btns.appendChild(mk("Download CSV", "reports/findings_unified.csv"));
    btns.appendChild(mk("Download SARIF", "findings_unified.sarif__DISABLED__"));
    btns.appendChild(mk("Download JSON", "findings_unified.json"));
/* VSP_P1_EXPORT_BTNS_PDF_ZIP_V1
 * Add PDF/ZIP export via run_file_allow allowlist (no /api/vsp/export).
 * ZIP/PDF are best-effort: server may return ok:false if missing (commercial).
 */
try{
  btns.appendChild(mk("Download PDF", "reports/findings_unified.pdf"));
  // common alternates (open-first strategy; allowlist may 200-ok:false)
  const zipCandidates = [
    "reports/report_bundle.zip",
    "reports/findings_unified.zip",
    "report_bundle.zip",
    "report_artifacts.zip"
  ];
  const zipBtn = document.createElement("button");
  zipBtn.className = "vsp-btn vsp-btn-ghost";
  zipBtn.textContent = "Download ZIP";
  zipBtn.onclick = ()=> {
    const rid = (S && (S.rid || S.lastRid)) || "";
    const c0 = zipCandidates[0];
    window.open(`/api/vsp/run_file_allow?${qs({rid, path:c0})}`, "_blank");
  };
  btns.appendChild(zipBtn);
}catch(_){}
/* /VSP_P1_EXPORT_BTNS_PDF_ZIP_V1 */

    btns.appendChild(mk("Gate Summary", "run_gate_summary.json"));

    // Optional: HTML report
    const bHtml = el("button", {class:"vspBtn", type:"button"}, "Open HTML Report");
    bHtml.addEventListener("click", ()=> {
      const candidates = [
        "reports/findings_unified.html",
        "reports/report.html",
        "reports/checkmarx_like.html",
      ];
      // open first candidate (server may 404; acceptable)
      const url = `/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=${encodeURIComponent(candidates[0])}`;
      window.open(url, "_blank", "noopener");
    });
    btns.appendChild(bHtml);

    hint.textContent = `RID=${rid} • Exports are allowlisted; if a file is missing you'll see 404.`;
  }

  function boot(){
    if (!isDash()) return;
    ensureMount();
    loadTrend();
    loadBadgesAndExports();
    // refresh on rid change
    window.addEventListener("vsp:rid", ()=> {
      loadBadgesAndExports();
    });
    // refresh trend every 60s (light)
    setInterval(()=> { if (isDash()) loadTrend(); }, 60000);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();



/* ===================== VSP_P0_RUNFILEALLOW_ENSURE_PATH_V1 =====================
   Fix 403 spam: some callers hit /api/vsp/run_file_allow without ?path=...
   We default path=run_gate_summary.json (safe “dashboard truth” file) for GET only.
*/
(()=> {
  if (window.__vsp_p0_runfileallow_ensure_path_v1) return;
  window.__vsp_p0_runfileallow_ensure_path_v1 = true;

  const origFetch = window.fetch ? window.fetch.bind(window) : null;
  if (!origFetch) return;

  if (!window.__vsp_disable_interceptors_v1) window.fetch = async function(input, init){
    try{
      let url = "";
      let method = "GET";
      if (typeof input === "string") {
        url = input;
      } else if (input && typeof input.url === "string") {
        url = input.url;
        method = (input.method || "GET").toUpperCase();
      }
      if (url && url.includes("/api/vsp/run_file_allow") && method === "GET") {
        const u = new URL(url, window.location.origin);
        const path = u.searchParams.get("path");
        if (!path) {
          u.searchParams.set("path", "run_gate_summary.json");
          const fixed = u.toString();
          // keep request shape minimal
          input = (typeof input === "string") ? fixed : fixed;
          try { console.debug("[VSP][P0] run_file_allow add default path =>", fixed); } catch(_){}
        }
      }
    } catch(_){}
    return origFetch(input, init);
  };
})();
/* ===================== /VSP_P0_RUNFILEALLOW_ENSURE_PATH_V1 ===================== */



/* ===================== VSP_P0_DASHBOARD_CLEANUP_TOOLLANE_AUDIT_V1 ===================== */
(()=> {
  if (window.__vsp_p0_dash_cleanup_toollane_audit_v1) return;
  window.__vsp_p0_dash_cleanup_toollane_audit_v1 = true;

  const TOOLS = ["Semgrep","Gitleaks","KICS","Trivy","Syft","Grype","Bandit","CodeQL"];

  const onVsp5 = () => (location.pathname === "/vsp5" || document.querySelector("meta[name='vsp-page'][content='vsp5']"));
  if (!onVsp5()) return;

  const safeText = (x)=> (x==null?"":String(x));
  const $ = (q, el=document) => el.querySelector(q);
  const $all = (q, el=document) => Array.from(el.querySelectorAll(q));

  // ---- (1) Collapse legacy/duplicate sections (heuristic; zero template edits)
  function collapseLegacy(){
    try{
      const roots = [];
      const main = $("#vsp5_root") || $("#app") || $("main") || document.body;
      roots.push(main);

      // Hide obvious legacy blocks by headings/text
      const legacyHints = [/dashboard\s+live/i, /legacy/i, /old\s+dashboard/i, /gate\s*story/i];
      const blocks = $all("section,div").filter(el=>{
        const t = (el.innerText||"").slice(0,300);
        if (t.length < 40) return false;
        return legacyHints.some(rx=>rx.test(t));
      });

      // Keep first “main” dashboard, collapse the rest
      let kept = 0;
      blocks.forEach(el=>{
        // do not hide if it contains KPI cards / the first big dashboard area
        const t = (el.innerText||"").slice(0,120);
        if (kept === 0 && /dashboard/i.test(t)) { kept++; return; }
        el.style.display = "none";
        el.setAttribute("data-vsp-collapsed-legacy","1");
      });

      // If page is very long, also hide everything below the first large dashboard container
      const big = $all("section,div").find(el=> (el.querySelectorAll("canvas,svg,table").length>=1) && (el.innerText||"").includes("Overall"));
      if (big){
        const after = [];
        let seen=false;
        for (const child of Array.from(document.body.children)){
          if (child===big) { seen=true; continue; }
          if (seen) after.push(child);
        }
        // hide only clearly duplicated dashboard parts
        after.forEach(el=>{
          if ((el.innerText||"").match(/Top Findings|Tool Lane|Evidence|Audit/i)){
            el.style.display="none";
            el.setAttribute("data-vsp-collapsed-legacy","1");
          }
        });
      }
    }catch(e){ /* no throw */ }
  }

  // ---- helpers: fetch JSON from run_file_allow
  async function fetchRunJson(rid, path){
    const url = `/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=${encodeURIComponent(path)}`;
    const r = await fetch(url, {cache:"no-store"});
    if (!r.ok) throw new Error(`${path} http=${r.status}`);
    const ct = (r.headers.get("content-type")||"").toLowerCase();
    if (ct.includes("application/json")) return await r.json();
    const txt = await r.text();
    try{ return JSON.parse(txt); }catch{ return {__raw:txt}; }
  }

  async function latestRid(){
    const r = await fetch("/api/vsp/rid_latest_gate_root_gate_root", {cache:"no-store"});
    if (!r.ok) throw new Error("latest_rid failed");
    const j = await r.json();
    return j.rid;
  }

  function toolStatusFromGateSummary(gs){
    // prefer: gs.by_tool[tool].status + degraded flags; fallback heuristics
    const out = {};
    const by = (gs && (gs.by_tool || gs.byTool)) || {};
    TOOLS.forEach(t=>{
      const k = Object.keys(by).find(x=>x.toLowerCase()===t.toLowerCase()) || null;
      const it = k ? by[k] : null;
      const degraded = !!(it && (it.degraded || it.timeout || it.is_degraded));
      const missing  = !(it && (it.present || it.ok || it.has_output || it.has_artifact)) && !it;
      let st = "MISSING";
      if (degraded) st = "DEGRADED";
      else if (!missing) st = "OK";
      out[t]=st;
    });
    return out;
  }

  function mountLane(){
    const host = $("#vsp_tool_lane") || $("[data-vsp-tool-lane]") || $("#vsp_dashboard_body") || $("main") || document.body;
    let box = $("#vsp_p0_tool_lane_box");
    if (!box){
      box = document.createElement("div");
      box.id="vsp_p0_tool_lane_box";
      box.style.cssText="margin:12px 0;padding:12px;border:1px solid rgba(255,255,255,.08);border-radius:14px;background:rgba(255,255,255,.02)";
      box.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px">
        <div style="font-weight:700">Tool Lane (8 tools)</div>
        <div id="vsp_p0_tool_lane_meta" style="opacity:.75;font-size:12px"></div>
      </div>
      <div id="vsp_p0_tool_lane_grid" style="margin-top:10px;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px"></div>`;
      host.prepend(box);
    }
    return box;
  }

  function renderLane(statusMap){
    const grid = $("#vsp_p0_tool_lane_grid");
    if (!grid) return;
    grid.innerHTML = "";
    TOOLS.forEach(t=>{
      const st = statusMap[t] || "UNKNOWN";
      const chip = document.createElement("div");
      chip.style.cssText="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.18)";
      chip.innerHTML = `<div style="font-weight:650">${t}</div><div style="margin-top:4px;font-size:12px;opacity:.85">${st}</div>`;
      grid.appendChild(chip);
    });
  }

  function mountAudit(){
    const host = $("#vsp_audit_ready") || $("[data-vsp-audit]") || $("#vsp_dashboard_body") || $("main") || document.body;
    let box = $("#vsp_p0_audit_box");
    if (!box){
      box = document.createElement("div");
      box.id="vsp_p0_audit_box";
      box.style.cssText="margin:12px 0;padding:12px;border:1px solid rgba(255,255,255,.08);border-radius:14px;background:rgba(255,255,255,.02)";
      box.innerHTML = `<div style="font-weight:700">Evidence & Audit Readiness</div>
        <div id="vsp_p0_audit_line" style="margin-top:8px;opacity:.85"></div>
        <div id="vsp_p0_audit_missing" style="margin-top:6px;font-size:12px;opacity:.8"></div>`;
      host.appendChild(box);
    }
    return box;
  }

  function setAudit(ok, missing, rid){
    const line = $("#vsp_p0_audit_line");
    const miss = $("#vsp_p0_audit_missing");
    if (!line || !miss) return;
    if (ok){
      line.innerHTML = `AUDIT READY • <a href="/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=${encodeURIComponent("run_evidence_index.json")}" target="_blank" rel="noreferrer">run_evidence_index.json</a> • <a href="/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=${encodeURIComponent("run_manifest.json")}" target="_blank" rel="noreferrer">run_manifest.json</a>`;
      miss.textContent = "";
    }else{
      line.textContent = "MISSING EVIDENCE";
      miss.textContent = `missing: [${missing.join(", ")}]`;
    }
  }

  async function main(){
    collapseLegacy();

    const rid = await latestRid();
    const gs = await fetchRunJson(rid, "run_gate_summary.json");
    const stMap = toolStatusFromGateSummary(gs);
    mountLane();
    renderLane(stMap);
    const meta = $("#vsp_p0_tool_lane_meta");
    if (meta) meta.textContent = `RID=${rid}`;

    // audit: require manifest + evidence_index readable
    const missing = [];
    try{ await fetchRunJson(rid, "run_manifest.json"); }catch{ missing.push("run_manifest.json"); }
    try{ await fetchRunJson(rid, "run_evidence_index.json"); }catch{ missing.push("run_evidence_index.json"); }
    mountAudit();
    setAudit(missing.length===0, missing, rid);
  }

  main().catch(()=>{ /* do not spam console */ });
})();
 /* ===================== /VSP_P0_DASHBOARD_CLEANUP_TOOLLANE_AUDIT_V1 ===================== */

;(()=> {
  try{
    // ===================== VSP_P2_CLIENT_AUTOREFRESH_LATEST_RUN_15S_V1_SAFEAPPEND =====================
    if (window.__vsp_autorefresh_latest_run_v1_safe) return;
    window.__vsp_autorefresh_latest_run_v1_safe = true;

    const POLL_MS = 15000;

    async function pollOnce(){
      try{
        const r = await fetch("/api/vsp/runs?limit=1", { credentials:"same-origin" });
        if (!r.ok) return;
        const j = await r.json();
        const item = (j && j.items && j.items[0]) || null;
        const rid = (item && (item.run_id || item.rid)) || (j && j.latest_rid) || null;
        if (!rid) return;

        const prev = window.__vsp_latest_rid || null;
        window.__vsp_latest_rid = rid;

        if (prev && prev !== rid){
          try{
            window.dispatchEvent(new CustomEvent("vsp:latest_run_changed", { detail:{ prev, rid } }));
          }catch(e){}

          // Prefer hook-based refresh if bundle defines them
          try{
            if (typeof window.__vsp_refresh_dashboard === "function") { window.__vsp_refresh_dashboard(rid); return; }
            if (typeof window.__vsp_refresh_runs === "function") { window.__vsp_refresh_runs(rid); return; }
          }catch(e){}

          // Minimal safe: reload only on /vsp5 or dashboard-like paths
          try{
            const pth = (location.pathname || "");
            if (pth !== "/vsp5" && !pth.includes("dashboard")) location.reload();
          }catch(e){}
        }
      }catch(e){
        // no console spam
      }
    }

    const start = ()=> {
      pollOnce();
      setInterval(pollOnce, POLL_MS);
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once:true });
    else start();
  }catch(e){}
})();
;(()=> {
  try{
    // ===================== VSP_P2_CLIENT_REFRESH_HOOKS_V1_SAFEAPPEND =====================
    // Goal: refresh dashboard/runs without full page reload (enterprise feel).

    const sleep = (ms)=> new Promise(r=> setTimeout(r, ms));

    function isVisible(el){
      try{
        if (!el) return false;
        const r = el.getBoundingClientRect();
        return !!(r.width && r.height) && getComputedStyle(el).visibility !== "hidden";
      }catch(e){ return false; }
    }

    function clickTabSoft(tabName){
      try{
        const t = (tabName||"").trim();
        if (!t) return false;

        const cand = [
          `button[data-vsp-tab="${t}"]`,
          `a[data-vsp-tab="${t}"]`,
          `#tab_${t}`, `#vsp_tab_${t}`,
          `button[data-tab="${t}"]`,
          `a[href*="${t}"]`,
          `button[id*="${t}"]`,
        ];

        for (const sel of cand){
          const el = document.querySelector(sel);
          if (el && isVisible(el)){
            el.click();
            return true;
          }
        }
      }catch(e){}
      return false;
    }

    async function refreshGateIntoCards(rid){
      try{
        if (!rid) return false;

        // Prefer reports/ then fallback root (your P1 helper already does this safely)
        let gate = null;

        if (window.__vsp_runfileallow_fetch_v1){
          const g = await window.__vsp_runfileallow_fetch_v1({ base:"", rid, path:"reports/run_gate_summary.json", acceptJson:true });
          if (g && g.ok) gate = g.data;
        } else {
          // fallback: direct fetch (still ok because backend now aliases)
          const r = await fetch(`/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=${encodeURIComponent("reports/run_gate_summary.json")}`, { credentials:"same-origin" });
          if (r.ok) gate = await r.json();
        }

        if (gate && typeof window.__vsp_dash_bind_native_cards_v7_apply === "function"){
          try{ window.__vsp_dash_bind_native_cards_v7_apply(gate); }catch(e){}
          return true;
        }
      }catch(e){}
      return false;
    }

    // ---- Public hooks used by autorefresh poller ----
    window.__vsp_refresh_dashboard = async function(rid){
      try{
        window.__vsp_latest_rid = rid || window.__vsp_latest_rid;

        // Try apply gate into native cards (fast, no flicker)
        const ok = await refreshGateIntoCards(window.__vsp_latest_rid);

        // Optional tiny badge (non-spam)
        try{
          if (ok && window.__vsp_badge_degraded_v1){
            // re-use badge style but different message; auto-disappears
            window.__vsp_badge_degraded_v1(`UPDATED: ${window.__vsp_latest_rid}`);
          }
        }catch(e){}

        return ok;
      }catch(e){ return false; }
    };

    window.__vsp_refresh_runs = async function(rid){
      try{
        window.__vsp_latest_rid = rid || window.__vsp_latest_rid;

        // Soft refresh: re-click current tab so existing renderOnce() runs again
        let cur = "";
        try{ cur = (typeof window.__vsp_tab === "function" ? window.__vsp_tab() : "") || ""; }catch(e){}
        if (cur) {
          if (clickTabSoft(cur)) return true;
        }

        // fallback: try common tab names
        if (clickTabSoft("runs")) return true;
        if (clickTabSoft("runs_reports")) return true;

        // last resort: do nothing (autorefresh poller will reload only if it can't call hooks)
        await sleep(0);
        return false;
      }catch(e){ return false; }
    };

  }catch(e){}
})();
;(()=> {
  try{
    // ===================== VSP_P1_RUNS_RELEASE_CARD_V1_SAFEAPPEND =====================
    // Runs & Reports only: show Current Release from /out_ci/release_latest.json (no Dashboard touch).
    const isRunsPage = ()=>{
      try{
        const p = (location.pathname||"");
        if (p.includes("vsp5") || p.includes("dashboard")) return false;
        return (p.includes("/runs") || p.includes("runs_reports"));
      }catch(e){ return false; }
    };

    function ensureHost(){
      // Try common containers; otherwise create a safe top panel.
      const sels = [
        "#vsp_runs_root", "#runs_root", "#vsp_tab_root",
        "main", ".container", "body"
      ];
      for (const sel of sels){
        const el = document.querySelector(sel);
        if (el) return el;
      }
      return document.body;
    }

    function upsertCard(html){
      const id = "vsp_current_release_card_v1";
      let box = document.getElementById(id);
      if (!box){
        box = document.createElement("div");
        box.id = id;
        box.style.cssText = [
          "border:1px solid rgba(255,255,255,.12)",
          "background:rgba(10,18,32,.72)",
          "border-radius:14px",
          "padding:12px 14px",
          "margin:10px 0",
          "box-shadow:0 10px 30px rgba(0,0,0,.35)",
          "backdrop-filter: blur(6px)"
        ].join(";");
        const host = ensureHost();
        // If host is body, make it a fixed non-intrusive corner panel
        if (host === document.body){
          box.style.margin = "0";
          box.style.position = "fixed";
          box.style.right = "16px";
          box.style.bottom = "16px";
          box.style.maxWidth = "520px";
          box.style.zIndex = "9999";
          document.body.appendChild(box);
        } else {
          host.insertBefore(box, host.firstChild);
        }
      }
      box.innerHTML = html;
    }

    async function loadRelease(){
      try{
        const r = await fetch("/out_ci/release_latest.json", { credentials:"same-origin", cache:"no-store" });
        if (!r.ok) throw new Error("http_"+r.status);
        const j = await r.json();
        if (!j || !j.package) throw new Error("bad_json");
        const pkg = j.package;
        const sha = j.sha256_file || "";
        const man = j.manifest || "";
        const ts  = j.ts || "";

        const row = (label, val)=> `<div style="display:flex;gap:10px;align-items:baseline;line-height:1.35">
          <div style="min-width:120px;opacity:.78">${label}</div>
          <div style="font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size:12.5px; word-break:break-all">${val}</div>
        </div>`;

        upsertCard(`
          <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px">
            <div style="font-weight:700;letter-spacing:.2px">Current Release</div>
            <div style="opacity:.7;font-size:12px">${ts}</div>
          </div>
          ${row("PACKAGE", `<a href="/${pkg}" style="color:#9ad7ff;text-decoration:none">${pkg}</a>`)}
          ${sha ? row("SHA256", `<a href="/${sha}" style="color:#9ad7ff;text-decoration:none">${sha}</a>`) : ""}
          ${man ? row("MANIFEST", `<a href="/${man}" style="color:#9ad7ff;text-decoration:none">${man}</a>`) : ""}
        `);
      }catch(e){
        // silent (commercial): only show a tiny note if already created
        try{
          upsertCard(`<div style="opacity:.8">Current Release: <span style="opacity:.7">not available</span></div>`);
        }catch(_){}
      }
    }

    const boot = ()=>{
      if (!isRunsPage()) return;
      if (window.__vsp_runs_release_card_v1) return;
      window.__vsp_runs_release_card_v1 = true;
      loadRelease();
      // refresh occasionally (no spam)
      setInterval(()=>{ try{ if (isRunsPage()) loadRelease(); }catch(e){} }, 60000);
    };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();
    // ===================== /VSP_P1_RUNS_RELEASE_CARD_V1_SAFEAPPEND =====================
  }catch(e){}
})();
;(()=> {
  try{
    // ===================== VSP_P1_RUNS_RELEASE_CARD_V2_FIXED_BODY_V1 =====================
    const isRuns = ()=>{
      try{
        const p = (location.pathname||"");
        if (p.includes("vsp5") || p.includes("dashboard")) return false;
        return (p === "/runs" || p.includes("/runs") || p.includes("runs_reports"));
      }catch(e){ return false; }
    };

    function ensureBox(){
      const id="vsp_current_release_card_v2";
      let box=document.getElementById(id);
      if (box) return box;
      box=document.createElement("div");
      box.id=id;
      box.style.cssText=[
        "position:fixed","right:16px","bottom:16px","z-index:99999",
        "max-width:560px","min-width:360px",
        "border:1px solid rgba(255,255,255,.14)",
        "background:rgba(10,18,32,.78)",
        "border-radius:16px","padding:12px 14px",
        "box-shadow:0 12px 34px rgba(0,0,0,.45)",
        "backdrop-filter:blur(8px)"
      ].join(";");
      document.body.appendChild(box);
      return box;
    }

    function row(label, val){
      return `<div style="display:flex;gap:10px;align-items:baseline;line-height:1.35;margin:4px 0">
        <div style="min-width:110px;opacity:.78">${label}</div>
        <div style="font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size:12.5px; word-break:break-all">${val}</div>
      </div>`;
    }

    async function fetchJson(url){
      const r = await fetch(url, {credentials:"same-origin", cache:"no-store"});
      if (!r.ok) throw new Error("http_"+r.status);
      return await r.json();
    }

    async function load(){
      if (!isRuns()) return;
      const box=ensureBox();
      try{
        // Prefer API; fallback to static (best-effort)
        let j=null;
        try{ j = await fetchJson("/api/vsp/release_latest"); }catch(e){ j = await fetchJson("/out_ci/release_latest.json"); }
        if (!j || !j.package) throw new Error("no_package");
        const pkg=j.package, sha=j.sha256_file||"", man=j.manifest||"", ts=j.ts||"";
        box.innerHTML = `
          <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px">
            <div style="font-weight:800;letter-spacing:.2px">Current Release</div>
            <div style="opacity:.7;font-size:12px">${ts}</div>
          </div>
          ${row("PACKAGE", `<a href="/${pkg}" style="color:#9ad7ff;text-decoration:none">${pkg}</a>`)}
          ${sha ? row("SHA256", `<a href="/${sha}" style="color:#9ad7ff;text-decoration:none">${sha}</a>`) : ""}
          ${man ? row("MANIFEST", `<a href="/${man}" style="color:#9ad7ff;text-decoration:none">${man}</a>`) : ""}
          <div style="opacity:.55;font-size:11.5px;margin-top:8px">Auto-refresh: 60s • Runs-only • Safe overlay</div>
        `;
      }catch(e){
        box.innerHTML = `<div style="font-weight:700">Current Release</div>
          <div style="opacity:.75;margin-top:6px">not available</div>
          <div style="opacity:.55;font-size:11.5px;margin-top:8px">(${String(e&&e.message||e)})</div>`;
      }
    }

    function boot(){
      if (!isRuns()) return;
      if (window.__vsp_runs_release_card_v2_fixed) return;
      window.__vsp_runs_release_card_v2_fixed = true;
      load();
      setInterval(()=>{ try{ load(); }catch(e){} }, 60000);
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();
    // ===================== /VSP_P1_RUNS_RELEASE_CARD_V2_FIXED_BODY_V1 =====================
  }catch(e){}
})();


/* ===================== VSP_P1_RELEASE_FETCH_NORMALIZE_V1 ===================== */
(()=> {
  if (window.__vsp_p1_release_fetch_norm_v1) return;
  window.__vsp_p1_release_fetch_norm_v1 = true;

  const _fetch = window.fetch;
  if (typeof _fetch !== "function") return;

  function isReleaseLatest(url){
    try{
      const u = String(url||"");
      return u.indexOf("/api/vsp/release_latest") !== -1;
    }catch(e){ return false; }
  }

  window.fetch = async function(input, init){
    const url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
    const res = await _fetch.apply(this, arguments);
    try{
      if (!isReleaseLatest(url)) return res;

      // clone + parse json
      const clone = res.clone();
      const j = await clone.json().catch(()=>null);
      if (!j || typeof j !== "object") return res;

      const st = String(j.release_status||"").toUpperCase();
      const ex = (j.release_pkg_exists === true);
      const pkg = (j.release_pkg || j.package || "").toString();

      // Normalize for older UI that expects `package` truthy to show OK
      if ((st === "OK" || ex) && pkg){
        j.ok = true;
        if (!j.package) j.package = pkg;
      }
      // If stale: keep package empty so UI shows STALE/NO PKG
      if (!(st === "OK" || ex)){
        // leave as-is; but ensure ok remains true (endpoint always ok)
        if (typeof j.ok !== "boolean") j.ok = true;
      }

      const body = JSON.stringify(j);
      return new Response(body, {
        status: res.status,
        statusText: res.statusText,
        headers: res.headers
      });
    }catch(e){
      return res;
    }
  };
})();
/* ===================== /VSP_P1_RELEASE_FETCH_NORMALIZE_V1 ===================== */


/* ===================== VSP_P1_RELEASE_XHR_FETCH_NORMALIZE_V2 ===================== */
(()=> {
  if (window.__vsp_p1_release_xhr_fetch_norm_v2) return;
  window.__vsp_p1_release_xhr_fetch_norm_v2 = true;

  function isRel(u){
    try { return String(u||"").indexOf("/api/vsp/release_latest") !== -1; }
    catch(e){ return false; }
  }
  function normalize(j){
    try{
      if (!j || typeof j !== "object") return j;
      const st = String(j.release_status||"").toUpperCase();
      const ex = (j.release_pkg_exists === true);
      const pkg = (j.release_pkg || j.package || "").toString();
      if ((st === "OK" || ex) && pkg){
        j.ok = true;
        if (!j.package) j.package = pkg;
      }
      if (typeof j.ok !== "boolean") j.ok = true;
      return j;
    }catch(e){ return j; }
  }

  // fetch normalize (in case some parts use fetch)
  const _fetch = window.fetch;
  if (typeof _fetch === "function"){
    window.fetch = async function(input, init){
      const url = (typeof input === "string") ? input : (input && input.url) ? input.url : "";
      const res = await _fetch.apply(this, arguments);
      try{
        if (!isRel(url)) return res;
        const clone = res.clone();
        const j = await clone.json().catch(()=>null);
        if (!j) return res;
        const body = JSON.stringify(normalize(j));
        return new Response(body, { status: res.status, statusText: res.statusText, headers: res.headers });
      }catch(e){
        return res;
      }
    };
  }

  // XHR normalize (covers axios/jquery/etc using XHR under the hood)
  const XHR = window.XMLHttpRequest;
  if (typeof XHR === "function" && XHR.prototype){
    const _open = XHR.prototype.open;
    const _send = XHR.prototype.send;

    XHR.prototype.open = function(method, url){
      try { this.__vsp_rel_url = url; } catch(e){}
      return _open.apply(this, arguments);
    };

    XHR.prototype.send = function(){
      try{
        this.addEventListener("readystatechange", function(){
          try{
            if (this.readyState !== 4) return;
            const url = this.__vsp_rel_url || "";
            if (!isRel(url)) return;

            // only if JSON-ish response
            const ct = (this.getResponseHeader && this.getResponseHeader("content-type")) ? this.getResponseHeader("content-type") : "";
            if (ct && ct.indexOf("application/json") === -1 && ct.indexOf("text/json") === -1 && ct.indexOf("json") === -1) return;

            // responseText is read-only; we patch by defining getter returning normalized text
            const raw = this.responseText;
            let j = null;
            try { j = JSON.parse(raw); } catch(e){ return; }
            const norm = JSON.stringify(normalize(j));

            // override responseText/response with getters
            Object.defineProperty(this, "responseText", { get: ()=> norm });
            Object.defineProperty(this, "response", { get: ()=> norm });
          }catch(e){}
        }, false);
      }catch(e){}
      return _send.apply(this, arguments);
    };
  }
})();
/* ===================== /VSP_P1_RELEASE_XHR_FETCH_NORMALIZE_V2 ===================== */


/* ===================== VSP_P1_RELEASE_CARD_DOM_FORCE_FIX_V3 ===================== */
(()=> {
  if (window.__vsp_p1_relcard_domfix_v3) return;
  window.__vsp_p1_relcard_domfix_v3 = true;

  const qsa = (sel, root)=>{ try { return Array.from((root||document).querySelectorAll(sel)); } catch(e){ return []; } };
  const qs  = (sel, root)=>{ try { return (root||document).querySelector(sel); } catch(e){ return null; } };
  const txt = (el)=> (el && el.textContent ? el.textContent.trim() : "");

  function findReleaseCard(){
    // heuristic: card contains title "Current Release"
    const nodes = qsa("*");
    for (const n of nodes){
      const t = txt(n);
      if (t === "Current Release") {
        // climb to a container "card"
        let c = n;
        for (let i=0;i<8;i++){
          if (!c) break;
          const buttons = qsa("button", c);
          if (buttons.some(b => txt(b).toLowerCase() === "refresh")) return c;
          c = c.parentElement;
        }
      }
    }
    return null;
  }

  function setBadge(card, status){
    // find badge element near header (often a small pill "NO PKG")
    const pills = qsa("span,div", card).filter(x=>{
      const t = txt(x).toUpperCase();
      return (t === "NO PKG" || t === "STALE" || t === "OK");
    });
    if (pills.length){
      const b = pills[0];
      b.textContent = status;
      // lightweight styling without relying on css classes
      if (status === "OK") {
        b.style.background = "rgba(34,197,94,0.15)";
        b.style.border = "1px solid rgba(34,197,94,0.35)";
        b.style.color = "#86efac";
      } else {
        b.style.background = "rgba(245,158,11,0.12)";
        b.style.border = "1px solid rgba(245,158,11,0.35)";
        b.style.color = "#fcd34d";
      }
      b.style.padding = "2px 8px";
      b.style.borderRadius = "999px";
    }
  }

  function setKV(card, keyLabel, value){
    // card shows rows like: ts / package / sha (left label + right value)
    const rows = qsa("div,span", card);
    for (const r of rows){
      const t = txt(r).toLowerCase();
      if (t === keyLabel){
        // value is usually next sibling
        const v = r.nextElementSibling;
        if (v) v.textContent = value || "-";
      }
    }
  }

  async function refreshCard(card){
    try{
      const res = await fetch("/api/vsp/release_latest", {cache:"no-store"});
      const j = await res.json();
      const ok = (String(j.release_status||"").toUpperCase()==="OK" || j.release_pkg_exists===true);
      const status = ok ? "OK" : "STALE";
      setBadge(card, status);
      setKV(card, "ts", String(j.release_ts||"-"));
      setKV(card, "package", String(j.release_pkg||"-"));
      const sha = String(j.release_sha||"");
      setKV(card, "sha", sha ? sha.slice(0,12) : "-");
    }catch(e){}
  }

  function install(){
    const card = findReleaseCard();
    if (!card) return false;

    // run once now
    refreshCard(card);

    // hook the Refresh button in the card
    const btns = qsa("button", card);
    const rbtn = btns.find(b => txt(b).toLowerCase() === "refresh");
    if (rbtn && !rbtn.__vsp_rel_hooked){
      rbtn.__vsp_rel_hooked = true;
      rbtn.addEventListener("click", ()=> setTimeout(()=> refreshCard(card), 50), true);
    }
    return true;
  }

  // try for a while since card opens as overlay
  let tries = 0;
  const t = setInterval(()=>{
    tries++;
    const ok = install();
    if (ok || tries>=40) clearInterval(t);
  }, 500);

  // observe DOM changes (overlay open/close)
  try{
    const mo = new MutationObserver(()=> { try{ install(); }catch(e){} });
    mo.observe(document.documentElement, {childList:true, subtree:true});
  }catch(e){}
})();
/* ===================== /VSP_P1_RELEASE_CARD_DOM_FORCE_FIX_V3 ===================== */

