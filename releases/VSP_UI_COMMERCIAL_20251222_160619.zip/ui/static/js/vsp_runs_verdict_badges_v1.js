/* VSP_RUNS_VERDICT_BADGES_V2 (batch + gate_policy_v3) */
(function () {

  // VSP_ROUTE_GUARD_RUNS_ONLY_V1
  function __vsp_is_runs_only_v1(){
    try {
      const h = (location.hash||"").toLowerCase();
      return h.startsWith("#runs") || h.includes("#runs/");
    } catch(_) { return false; }
  }
  if(!__vsp_is_runs_only_v1()){
    try{ console.info("[VSP_ROUTE_GUARD_RUNS_ONLY_V1] skip", "vsp_runs_verdict_badges_v1.js", "hash=", location.hash); } catch(_){}
    return;
  }

  const RID_RE = /(RUN_[A-Za-z0-9_]+_\d{8}_\d{6}|VSP_CI_\d{8}_\d{6}|VSP_[A-Z0-9]+_\d{8}_\d{6}|REQ_[A-Za-z0-9_\-]{6,})/;

  function el(tag, props = {}, children = []) {
    const e = document.createElement(tag);
    Object.assign(e, props);
    children.forEach(c => e.appendChild(typeof c === "string" ? document.createTextNode(c) : c));
    return e;
  }

  function ensureModal() {
    let m = document.getElementById("vsp-gate-modal-v1");
    if (m) return m;

    const overlay = el("div", { id: "vsp-gate-modal-v1" });
    overlay.style.position = "fixed";
    overlay.style.inset = "0";
    overlay.style.zIndex = "99999";
    overlay.style.background = "rgba(0,0,0,0.55)";
    overlay.style.display = "none";
    overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.style.display = "none"; });

    const card = el("div");
    card.style.position = "absolute";
    card.style.top = "10%";
    card.style.left = "50%";
    card.style.transform = "translateX(-50%)";
    card.style.width = "min(900px, 92vw)";
    card.style.maxHeight = "80vh";
    card.style.overflow = "auto";
    card.style.borderRadius = "16px";
    card.style.border = "1px solid rgba(255,255,255,0.16)";
    card.style.background = "rgba(2,6,23,0.96)";
    card.style.padding = "14px 14px";
    card.style.color = "rgba(255,255,255,0.92)";
    card.style.boxShadow = "0 18px 60px rgba(0,0,0,0.45)";

    const header = el("div");
    header.style.display = "flex";
    header.style.alignItems = "center";
    header.style.justifyContent = "space-between";
    header.style.gap = "10px";

    const title = el("div", { id: "vsp-gate-modal-title-v1" });
    title.style.fontWeight = "800";
    title.style.fontSize = "14px";

    const close = el("button", { innerText: "Close" });
    close.style.cursor = "pointer";
    close.style.padding = "6px 10px";
    close.style.borderRadius = "999px";
    close.style.border = "1px solid rgba(255,255,255,0.16)";
    close.style.background = "rgba(15,23,42,0.6)";
    close.style.color = "rgba(255,255,255,0.92)";
    close.addEventListener("click", () => overlay.style.display = "none");

    header.appendChild(title);
    header.appendChild(close);

    const body = el("div", { id: "vsp-gate-modal-body-v1" });
    body.style.marginTop = "10px";
    body.style.fontSize = "12px";
    body.style.lineHeight = "1.5";
    body.style.whiteSpace = "pre-wrap";

    card.appendChild(header);
    card.appendChild(body);
    overlay.appendChild(card);
    document.body.appendChild(overlay);
    return overlay;
  }

  function badgeStyle(verdict) {
    const v = (verdict || "UNKNOWN").toUpperCase();
    const base = {
      display: "inline-flex",
      alignItems: "center",
      gap: "8px",
      fontSize: "11px",
      fontWeight: "800",
      padding: "4px 10px",
      borderRadius: "999px",
      border: "1px solid rgba(255,255,255,0.16)",
      background: "rgba(15,23,42,0.65)",
      cursor: "pointer",
      userSelect: "none",
      whiteSpace: "nowrap",
    };
    if (v.includes("RED") || v.includes("FAIL")) base.boxShadow = "0 0 0 1px rgba(239,68,68,0.25) inset";
    else if (v.includes("AMBER") || v.includes("WARN")) base.boxShadow = "0 0 0 1px rgba(245,158,11,0.25) inset";
    else if (v.includes("GREEN") || v.includes("PASS")) base.boxShadow = "0 0 0 1px rgba(34,197,94,0.25) inset";
    else base.boxShadow = "0 0 0 1px rgba(148,163,184,0.25) inset";
    return base;
  }

  function attachBadge(target, rid, gp) {
    if (!target || !rid || !gp) return;
    if (target.querySelector?.(`[data-vsp-gate-badge="1"][data-rid="${rid}"]`)) return;

    const verdict = (gp.verdict || "UNKNOWN").toUpperCase();
    const degN = Number(gp.degraded_n || 0);

    const b = el("span");
    b.dataset.vspGateBadge = "1";
    b.dataset.rid = rid;
    b.innerText = `VERDICT: ${verdict}${degN ? ` · DEG:${degN}` : ""}`;
    Object.assign(b.style, badgeStyle(verdict));

    b.addEventListener("click", () => {
      const overlay = ensureModal();
      const title = document.getElementById("vsp-gate-modal-title-v1");
      const body = document.getElementById("vsp-gate-modal-body-v1");
      title.textContent = `Run: ${rid} · Verdict: ${verdict}${degN ? ` · DEG:${degN}` : ""}`;

      const reasons = Array.isArray(gp.reasons) ? gp.reasons : (gp.reasons ? [String(gp.reasons)] : []);
      const degItems = Array.isArray(gp.degraded_items) ? gp.degraded_items : [];

      const lines = [];
      lines.push(`Source: ${gp.source || "unknown"}`);
      lines.push("");
      lines.push("Reasons:");
      if (reasons.length) reasons.forEach((x) => lines.push(`- ${x}`));
      else lines.push("- (none)");
      lines.push("");
      lines.push("Degraded:");
      if (degItems.length) degItems.forEach((x) => lines.push(`- ${x}`));
      else lines.push("- (none)");

      body.textContent = lines.join("\n");
      overlay.style.display = "block";
    });

    target.appendChild(document.createTextNode(" "));
    target.appendChild(b);
  }

  function extractRidFromNode(node) {
    const txt = (node?.innerText || node?.textContent || "").trim();
    const m1 = txt.match(RID_RE);
    if (m1) return m1[1];
    const a = node?.querySelector?.("a[href]") || null;
    if (a) {
      const m2 = a.getAttribute("href").match(RID_RE);
      if (m2) return m2[1];
    }
    return null;
  }

  async function loadRunsIndexMap() {
    try {
      const r = await fetch("/api/vsp/runs_index_v3_fs_resolved?limit=80&hide_empty=0&filter=1");
      if (!r.ok) return new Map();
      const j = await r.json();
      const items = j?.items || [];
      const m = new Map();
      items.forEach((it) => {
        const rid = it.run_id || it.id || it.rid;
        const ci = it.ci_run_dir || it.ci || it.run_dir;
        if (rid && ci) m.set(String(rid), String(ci));
      });
      return m;
    } catch {
      return new Map();
    }
  }

  async function fetchBatch(ridToCi) {
    const items = Array.from(ridToCi.entries()).map(([rid, ci_run_dir]) => ({ rid, ci_run_dir }));
    const r = await fetch("/api/vsp/gate_policy_batch_v1", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items })
    });
    if (!r.ok) return [];
    const j = await r.json();
    return j?.items || [];
  }

  async function patchDashboardHeader() {
    const anchor =
      document.querySelector(".vsp-page-title") ||
      document.querySelector("h1") ||
      document.querySelector(".dashboard-title") ||
      null;
    if (!anchor) return;

    try {
      const dRes = await fetch("/api/vsp/dashboard_v3");
      if (!dRes.ok) return;
      const d = await dRes.json();
      const rid = d?.run_id || d?.latest_run_id || d?.current_run_id;
      if (!rid) return;

      // resolve ci_run_dir via run_status_v2 (cheap, 1 call)
      const sRes = await fetch(`/api/vsp/run_status_v2/${encodeURIComponent(rid)}`);
      const st = sRes.ok ? await sRes.json() : {};
      const ci = st?.ci_run_dir || null;

      const u = `/api/vsp/gate_policy_v3/${encodeURIComponent(rid)}${ci ? `?ci_run_dir=${encodeURIComponent(ci)}` : ""}`;
      const gRes = await fetch(u);
      if (!gRes.ok) return;
      const gp = await gRes.json();
      if (!gp || gp.ok === false) return;

      attachBadge(anchor.parentElement || anchor, rid, gp);
    } catch {}
  }

  async function patchRunsTable() {
    const roots = Array.from(document.querySelectorAll("table, .vsp-table, .runs-table, .vsp-runs, #tab-runs, [data-tab='runs']"));
    const scope = roots.length ? roots : [document.body];

    const ridToTargets = new Map();
    scope.forEach((root) => {
      const rows = root.querySelectorAll("tr, .row, .vsp-row, li, .vsp-run-item");
      rows.forEach((row) => {
        const rid = extractRidFromNode(row);
        if (!rid) return;
        if (!ridToTargets.has(rid)) ridToTargets.set(rid, []);
        ridToTargets.get(rid).push(row);
      });
    });

    const rids = Array.from(ridToTargets.keys()).slice(0, 50);
    if (!rids.length) return;

    const idx = await loadRunsIndexMap();
    const ridToCi = new Map();
    rids.forEach((rid) => {
      const ci = idx.get(rid) || idx.get(rid.replace(/^RUN_/, "")) || null;
      ridToCi.set(rid, ci);
    });

    const items = await fetchBatch(ridToCi);
    const byRid = new Map();
    items.forEach((it) => byRid.set(it.run_id, it));

    rids.forEach((rid) => {
      const gp = byRid.get(rid) || null;
      if (!gp) return;
      (ridToTargets.get(rid) || []).forEach((row) => {
        const place = row.querySelector("td") || row.querySelector(".title") || row.querySelector("a") || row;
        attachBadge(place, rid, gp);
      });
    });
  }

  window.addEventListener("DOMContentLoaded", () => {
    patchDashboardHeader();
    setTimeout(patchRunsTable, 600);
    setTimeout(patchRunsTable, 1600);
  });
})();
