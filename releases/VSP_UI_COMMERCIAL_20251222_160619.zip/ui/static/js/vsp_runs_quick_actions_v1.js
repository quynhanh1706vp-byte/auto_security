/* ===================== VSP_P1_RELEASE_CARD_RUNS_V2_INTERCEPTOR_V1 =====================
   Goal: stop old noisy release card from spamming /api/vsp/release_latest.json 404 + poller.
   Safe: only intercept that exact endpoint + block intervals whose fn source mentions release_latest/ReleaseCard.
===================================================================================== */
(()=> {
/* ===================== VSP_P1_RUNS_AUDITPACK_V2_HARDINJECT =====================
   Guarantees Audit Pack buttons appear even if template changes.
   - Injects buttons into each run card/row action area post-render.
   - Robust RID resolver: data-rid, data-run-id, closest JSON blob, window.__vsp_runs cache.
   - Safe download via <a> click; simple toast.
============================================================================= */
const __vsp_auditpack_v2 = {installed:true};

function vspToast(msg){
  try{
    let t=document.getElementById('vsp_toast_v2');
    if(!t){
      t=document.createElement('div');
      t.id='vsp_toast_v2';
      t.style.cssText='position:fixed;right:16px;bottom:16px;z-index:99999;padding:10px 12px;border-radius:10px;background:#0b1220;color:#cfe3ff;border:1px solid rgba(120,160,255,.25);box-shadow:0 10px 30px rgba(0,0,0,.45);font:13px/1.3 system-ui;opacity:.0;transition:opacity .15s ease';
      document.body.appendChild(t);
    }
    t.textContent=msg;
    t.style.opacity='1';
    clearTimeout(t.__tm);
    t.__tm=setTimeout(()=>{t.style.opacity='0';}, 1400);
  }catch(e){}
}

function vspDownload(url){
  try{
    const a=document.createElement('a');
    a.href=url; a.target='_blank'; a.rel='noopener';
    a.style.display='none';
    document.body.appendChild(a);
    a.click();
    setTimeout(()=>a.remove(), 250);
  }catch(e){
    try{ window.open(url, '_blank', 'noopener'); }catch(_){}
  }
}

function vspAuditPackLiteUrl(rid){ return `/api/vsp/audit_pack_download?rid=${encodeURIComponent(rid)}&lite=1`; }
function vspAuditPackFullUrl(rid){ return `/api/vsp/audit_pack_download?rid=${encodeURIComponent(rid)}`; }

function vspResolveRidFromNode(node){
  if(!node) return '';
  // 1) dataset attrs
  let el=node.closest('[data-rid]') || node.closest('[data-run-id]') || node;
  if(el && el.getAttribute){
    const r = el.getAttribute('data-rid') || el.getAttribute('data-run-id');
    if(r) return r;
  }
  // 2) look for any element with rid attribute nearby
  let p=node;
  for(let i=0;i<5 && p; i++){
    if(p.getAttribute){
      const rr = p.getAttribute('data-rid') || p.getAttribute('data-run-id');
      if(rr) return rr;
    }
    p = p.parentElement;
  }
  // 3) try parse embedded JSON (if any)
  try{
    const jn = node.closest('[data-run]') || node.closest('[data-json]');
    if(jn){
      const raw = jn.getAttribute('data-run') || jn.getAttribute('data-json');
      if(raw && raw.trim().startsWith('{')){
        const obj = JSON.parse(raw);
        return obj.rid || obj.run_id || obj.id || '';
      }
    }
  }catch(e){}
  // 4) fallback: if global runs cache exists
  try{
    if(window.__vsp_runs_last && Array.isArray(window.__vsp_runs_last) && window.__vsp_runs_last.length){
      const one = window.__vsp_runs_last[0];
      return (one && (one.rid || one.run_id)) || '';
    }
  }catch(e){}
  return '';
}

function vspMakeAuditBtns(rid){
  const wrap=document.createElement('span');
  wrap.className='vsp-auditpack-wrap';
  wrap.style.cssText='display:inline-flex;gap:6px;align-items:center;margin-left:6px;';
  const mk=(label, act)=>{
    const b=document.createElement('button');
    b.type='button';
    b.className='vsp-btn vsp-btn-sm';
    b.setAttribute('data-act', act);
    b.setAttribute('data-rid', rid);
    b.textContent=label;
    b.title=(act==='audit_lite')?'Audit evidence pack (lite)':'Audit evidence pack (full)';
    return b;
  };
  wrap.appendChild(mk('Audit Lite','audit_lite'));
  wrap.appendChild(mk('Audit Full','audit_full'));
  return wrap;
}

function vspInjectAuditButtons(){
  // Find likely action containers in runs page
  const containers = []
    .concat(Array.from(document.querySelectorAll('.vsp-actions')))
    .concat(Array.from(document.querySelectorAll('[data-actions]')))
    .concat(Array.from(document.querySelectorAll('.actions')))
    .concat(Array.from(document.querySelectorAll('td:last-child')))
    .filter(Boolean);

  let injected=0;
  containers.forEach(c=>{
    // avoid injecting into header/footer
    if(!c || c.closest('thead')) return;
    if(c.querySelector && c.querySelector('.vsp-auditpack-wrap')) return;

    // resolve rid using closest run row/card
    const rid = vspResolveRidFromNode(c);
    if(!rid) return;

    // Insert at end of container
    try{
      c.appendChild(vspMakeAuditBtns(rid));
      injected++;
    }catch(e){}
  });

  if(injected>0){
    // console hint only once
    if(!window.__vsp_auditpack_v2_injected_once){
      window.__vsp_auditpack_v2_injected_once=true;
      console.log('[VSP][Runs] AuditPack v2 injected:', injected);
    }
  }
}

function vspAuditPackInitObserver(){
  // Observe DOM changes for runs list re-render/pagination
  try{
    const root = document.body;
    const obs = new MutationObserver(()=>{
      if(window.__vsp_auditpack_v2_t) return;
      window.__vsp_auditpack_v2_t = setTimeout(()=>{
        window.__vsp_auditpack_v2_t = null;
        vspInjectAuditButtons();
      }, 120);
    });
    obs.observe(root, {childList:true, subtree:true});
    // initial
    setTimeout(vspInjectAuditButtons, 200);
    setTimeout(vspInjectAuditButtons, 900);
  }catch(e){}
}

// Click delegation (robust)
document.addEventListener('click', (ev)=>{
  const t = ev.target;
  if(!t || !t.getAttribute) return;
  const act = t.getAttribute('data-act');
  if(act !== 'audit_lite' && act !== 'audit_full') return;

  const rid = t.getAttribute('data-rid') || vspResolveRidFromNode(t);
  if(!rid){
    vspToast('AuditPack: missing RID');
    return;
  }

  ev.preventDefault(); ev.stopPropagation();

  // prevent rapid double click
  if(t.__busy) return;
  t.__busy = true;
  t.disabled = true;
  vspToast('Downloading audit pack…');

  const url = (act === 'audit_lite') ? vspAuditPackLiteUrl(rid) : vspAuditPackFullUrl(rid);
  vspDownload(url);

  setTimeout(()=>{ t.__busy=false; t.disabled=false; }, 1200);
}, true);

// Start observer when /runs page loaded
setTimeout(vspAuditPackInitObserver, 80);


/* ===================== VSP_P1_RUNS_ADD_AUDITPACK_BTNS_V1 (template_inject_fallback) =====================
   Add Audit Pack (Lite/Full) buttons per run row
   - Lite: /api/vsp/audit_pack_download?rid=RID&lite=1
   - Full: /api/vsp/audit_pack_download?rid=RID
   Must NOT auto-probe (only on click)
============================================================================= */
function vspDownload(url){
  try{
    const a=document.createElement('a');
    a.href=url; a.target='_blank';
    a.rel='noopener';
    a.style.display='none';
    document.body.appendChild(a);
    a.click();
    setTimeout(()=>a.remove(), 250);
  }catch(e){
    try{ window.open(url, '_blank', 'noopener'); }catch(_){}
  }
}
function vspAuditPackLiteUrl(rid){ return `/api/vsp/audit_pack_download?rid=${encodeURIComponent(rid)}&lite=1`; }
function vspAuditPackFullUrl(rid){ return `/api/vsp/audit_pack_download?rid=${encodeURIComponent(rid)}`; }


  try {
    if (window.__vsp_relcard_interceptor_v1) return;
    window.__vsp_relcard_interceptor_v1 = true;

    const _fetch = window.fetch ? window.fetch.bind(window) : null;
    if (_fetch) {
      window.fetch = async function(resource, init){
        try{
          const url = (typeof resource === 'string') ? resource : (resource && resource.url) ? resource.url : '';
          if (url && url.includes('/api/vsp/release_latest.json')) {
            // prefer static release file (no backend dependency)
            try {
              const r = await _fetch('/out_ci/releases/release_latest.json', init);
              if (r && r.ok) return r;
            } catch(e) {}
            try {
              const r2 = await _fetch('/out/releases/release_latest.json', init);
              if (r2 && r2.ok) return r2;
            } catch(e) {}
            return new Response(JSON.stringify({ok:false, err:'RELEASE_LATEST_NOT_FOUND', source:'interceptor_v1'}), {
              status: 200, headers: {'Content-Type':'application/json'}
            });
          }
        } catch(e) {}
        return _fetch(resource, init);
      };
    }

    const _si = window.setInterval ? window.setInterval.bind(window) : null;
    if (_si) {
      window.setInterval = function(fn, ms, ...args){
        try{
          const src = fn && fn.toString ? String(fn.toString()) : '';
          if (src && (src.includes('release_latest') || src.includes('ReleaseCard')) && ms >= 5000 && ms <= 120000) {
            return 0; // block noisy pollers only
          }
        } catch(e) {}
        return _si(fn, ms, ...args);
      };
    }
  } catch(e) {}
})();

/* VSP_P1_RUNS_QUICK_ACTIONS_V1H (KPI + Pagination; NO auto probe run_file => no 404 spam) */
(()=> {
  if (window.__vsp_p1_runs_quick_actions_v1h) return;
  window.__vsp_p1_runs_quick_actions_v1h = true;

  const log = (...a)=>console.log("[RunsQuickV1H]", ...a);

  const API = {
    runs: "/api/vsp/runs",
    exportCsv: "/api/vsp/export_csv",
    exportTgz: "/api/vsp/export_tgz",
    runFile: "/api/vsp/run_file_allow",       // might not exist; we DO NOT auto-probe
    openFolder: "/api/vsp/open_folder", // optional
  };

  const qs=(s,r=document)=>r.querySelector(s);
  const el=(t,attrs={},kids=[])=>{
    const n=document.createElement(t);
    for(const [k,v] of Object.entries(attrs||{})){
      if(k==="class") n.className=v;
      else if(k==="html") n.innerHTML=v;
      else if(k.startsWith("on") && typeof v==="function") n.addEventListener(k.slice(2),v);
      else if(v===null || v===undefined) {}
      else n.setAttribute(k,String(v));
    }
    for(const c of kids||[]) n.appendChild(typeof c==="string"?document.createTextNode(c):c);
    return n;
  };

  function injectStyles(){
    const css = `
      .vsp-runsqa-wrap{padding:12px 0 0 0}
      .vsp-runsqa-toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:10px 0 12px 0}
      .vsp-runsqa-toolbar input,.vsp-runsqa-toolbar select{background:#0f172a;color:#e5e7eb;border:1px solid #24314f;border-radius:10px;padding:8px 10px;outline:none}
      .vsp-runsqa-btn{background:#111827;color:#e5e7eb;border:1px solid #24314f;border-radius:10px;padding:7px 10px;cursor:pointer}
      .vsp-runsqa-btn:hover{filter:brightness(1.08)}
      .vsp-runsqa-btn[disabled]{opacity:.45;cursor:not-allowed}
      .vsp-runsqa-mini{font-size:12px;opacity:.85}
      .vsp-runsqa-table{width:100%;border-collapse:separate;border-spacing:0 8px}
      .vsp-runsqa-row{background:#0b1220;border:1px solid #1f2a44}
      .vsp-runsqa-row td{padding:10px 10px;border-top:1px solid #1f2a44;border-bottom:1px solid #1f2a44;vertical-align:middle}
      .vsp-runsqa-row td:first-child{border-left:1px solid #1f2a44;border-top-left-radius:12px;border-bottom-left-radius:12px}
      .vsp-runsqa-row td:last-child{border-right:1px solid #1f2a44;border-top-right-radius:12px;border-bottom-right-radius:12px}
      .vsp-badge{display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;border:1px solid #24314f;font-size:12px;white-space:nowrap}
      .vsp-badge.ok{background:#06281b}
      .vsp-badge.amber{background:#2a1c06}
      .vsp-badge.bad{background:#2a0b0b}
      .vsp-badge.dim{opacity:.85}
      .vsp-actions{display:flex;flex-wrap:wrap;gap:6px}
      .vsp-toast{position:fixed;right:16px;bottom:16px;background:#0b1220;border:1px solid #24314f;color:#e5e7eb;padding:10px 12px;border-radius:12px;max-width:560px;box-shadow:0 8px 28px rgba(0,0,0,.35);z-index:99999}
      .vsp-linkbtn{background:transparent;border:0;color:#93c5fd;text-decoration:underline;cursor:pointer;padding:0;margin-left:8px;font-size:12px;opacity:.9}
      .vsp-linkbtn:hover{opacity:1}
      .vsp-legacy-hidden{display:none !important}

      .vsp-kpis{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:6px 0 10px 0}
      .vsp-kpi{display:flex;gap:8px;align-items:center;border:1px solid #24314f;border-radius:14px;background:#0b1220;padding:8px 10px}
      .vsp-kpi .k{font-size:12px;opacity:.85}
      .vsp-kpi .v{font-size:14px;font-weight:700}
      .vsp-pager{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:6px 0 10px 0}
      .vsp-pager input{width:84px}
      .vsp-cap{opacity:.85}
    `;
    const st=el("style"); st.textContent=css; document.head.appendChild(st);
  }
  function toast(msg,ms=2200){ const t=el("div",{class:"vsp-toast"},[msg]); document.body.appendChild(t); setTimeout(()=>t.remove(),ms); }

  function pickRid(run){
    return run.run_id || run.rid || run.req_id || run.request_id || run.id || run.RID || run.name || "";
  }
  function deepFindString(obj, re, depth=0){
    if (obj == null || depth > 5) return "";
    if (typeof obj === "string"){ const m=obj.match(re); return m?m[0]:""; }
    if (typeof obj === "number" || typeof obj === "boolean") return "";
    if (Array.isArray(obj)){ for (const it of obj){ const v=deepFindString(it,re,depth+1); if(v) return v; } return ""; }
    if (typeof obj === "object"){ for (const k of Object.keys(obj)){ const v=deepFindString(obj[k],re,depth+1); if(v) return v; } }
    return "";
  }
  function normOverall(x){
    const s = String(x||"").toUpperCase();
    const m = s.match(/(GREEN|AMBER|RED|PASS|FAIL|OK|ERROR|WARN(ING)?)/);
    if (!m) return s || "UNKNOWN";
    const t=m[1];
    if (t==="WARN") return "AMBER";
    if (t==="OK") return "GREEN";
    if (t==="ERROR") return "RED";
    return t;
  }
  function pickOverall(run){
    const direct = (run.overall || run.overall_status || run.status || run.result || run.verdict || "");
    if (direct) return normOverall(direct);
    const found = deepFindString(run, /(GREEN|AMBER|RED|PASS|FAIL|OK|ERROR|WARN(ING)?)/i);
    return normOverall(found);
  }
  function pickDegraded(run){
    const keys = ["degraded","any_degraded","tools_degraded","degraded_tools","is_degraded"];
    for (const k of keys){
      if (typeof run[k] === "boolean") return run[k];
    }
    return false;
  }
  function parseTs(run){
    const raw = run.ts || run.created_at || run.started_at || run.time || run.date || "";
    if (raw){ const d=new Date(raw); if(!isNaN(d.getTime())) return d; }
    const rid=pickRid(run);
    const m=String(rid).match(/(\d{8})_(\d{6})/);
    if(m){
      const y=m[1].slice(0,4), mo=m[1].slice(4,6), da=m[1].slice(6,8);
      const hh=m[2].slice(0,2), mm=m[2].slice(2,4), ss=m[2].slice(4,6);
      const d=new Date(`${y}-${mo}-${da}T${hh}:${mm}:${ss}`); if(!isNaN(d.getTime())) return d;
    }
    return null;
  }
  const pad=n=>String(n).padStart(2,"0");
  function fmtDate(d){ return d?`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`:""; }

  async function fetchRuns(limit=300){
    const r=await fetch(`${API.runs}?limit=${encodeURIComponent(String(limit))}`,{cache:"no-store"});
    if(!r.ok) throw new Error(`runs http ${r.status}`);
    const data=await r.json();
    if(Array.isArray(data)) return data;
    if(Array.isArray(data.items)) return data.items;
    if(Array.isArray(data.runs)) return data.runs;
    return [];
  }
  async function tryPing(u){
    try{
      const r = await fetch(u, {method:"GET", cache:"no-store"});
      return r.ok ? "OK" : `HTTP ${r.status}`;
    }catch(e){ return "ERR"; }
  }
  function openUrl(u){ window.open(u,"_blank","noopener"); }
  function ridParam(rid){ return encodeURIComponent(String(rid||"")); }
  function urlCsv(rid){ return `${API.exportCsv}?rid=${ridParam(rid)}`; }
  function urlTgz(rid){ return `${API.exportTgz}?rid=${ridParam(rid)}`; }

  // legacy hide
  function hideLegacyExcept(anchor){
    const hidden = [];
    const rx = /(VSP\s*Runs\s*&\s*Reports|Runs\s*&\s*Reports)/i;
    function hideNode(n){
      if (!n || n===document.body) return;
      if (anchor && anchor.contains(n)) return;
      if (n.getAttribute("data-vsp-legacy-hidden")==="1") return;
      n.classList.add("vsp-legacy-hidden");
      n.setAttribute("data-vsp-legacy-hidden","1");
      hidden.push(n);
    }
    const nodes = Array.from(document.querySelectorAll("h1,h2,h3,h4,div,section,main"))
      .filter(n => n && n.textContent && rx.test(n.textContent.trim()))
      .slice(0, 8);
    for (const h of nodes){
      let cur=h;
      for (let i=0;i<10;i++){
        if (!cur || cur===document.body) break;
        if (cur.querySelector && cur.querySelector("table")) { hideNode(cur); break; }
        cur=cur.parentElement;
      }
    }
    window.__vsp_runs_legacy_hidden_nodes = hidden;
    return hidden;
  }
  function toggleLegacy(show){
    const nodes = window.__vsp_runs_legacy_hidden_nodes || [];
    for (const n of nodes){
      if (!n) continue;
      if (show) n.classList.remove("vsp-legacy-hidden");
      else n.classList.add("vsp-legacy-hidden");
    }
  }

  function badgeForOverall(overall){
    const o=String(overall||"UNKNOWN").toUpperCase();
    if (o.includes("GREEN") || o==="OK" || o==="PASS") return el("span",{class:"vsp-badge ok"},[o==="OK"?"GREEN":o]);
    if (o.includes("AMBER") || o.includes("WARN")) return el("span",{class:"vsp-badge amber"},[o.includes("WARN")?"AMBER":o]);
    if (o.includes("RED") || o.includes("FAIL") || o.includes("ERROR")) return el("span",{class:"vsp-badge bad"},[o.includes("ERROR")?"RED":o]);
    return el("span",{class:"vsp-badge dim"},[o||"UNKNOWN"]);
  }

  function mount(){
    injectStyles();
    const anchor = qs("#vspRunsQuickActionsV1") || (()=>{ const d=el("div",{id:"vspRunsQuickActionsV1"}); document.body.insertBefore(d, document.body.firstChild); return d; })();
    hideLegacyExcept(anchor);

    let legacyShown=false;

    const ridIn=el("input",{type:"text",placeholder:"Search RID…",style:"min-width:240px"});
    const overallSel=el("select",{},[
      el("option",{value:""},["Overall: ALL"]),
      el("option",{value:"GREEN"},["GREEN"]),
      el("option",{value:"AMBER"},["AMBER"]),
      el("option",{value:"RED"},["RED"]),
      el("option",{value:"UNKNOWN"},["UNKNOWN"]),
    ]);
    const degrSel=el("select",{},[
      el("option",{value:""},["Degraded: ALL"]),
      el("option",{value:"true"},["Degraded: YES"]),
      el("option",{value:"false"},["Degraded: NO"]),
    ]);
    const fromIn=el("input",{type:"date"});
    const toIn=el("input",{type:"date"});

    const pageSizeSel=el("select",{},[
      el("option",{value:"10"},["10/page"]),
      el("option",{value:"20", selected:"selected"},["20/page"]),
      el("option",{value:"50"},["50/page"]),
      el("option",{value:"100"},["100/page"]),
    ]);
    const prevBtn=el("button",{class:"vsp-runsqa-btn"},["Prev"]);
    const nextBtn=el("button",{class:"vsp-runsqa-btn"},["Next"]);
    const pageIn=el("input",{type:"number", min:"1", value:"1"});
    const pageInfo=el("span",{class:"vsp-runsqa-mini"},["1/1"]);

    const refreshBtn=el("button",{class:"vsp-runsqa-btn"},["Refresh"]);
    const legacyBtn=el("button",{class:"vsp-runsqa-btn"},["Show legacy"]);
    const clearBtn=el("button",{class:"vsp-runsqa-btn"},["Clear"]);
    const stat=el("span",{class:"vsp-runsqa-mini"},["…"]);
    const cap=el("span",{class:"vsp-cap vsp-runsqa-mini"},["run_file: OFF (no auto probe)"]);

    const checkBtn=el("button",{class:"vsp-runsqa-btn"},["Check run_file"]);
    checkBtn.addEventListener("click", async ()=>{
      // This is optional manual check. It may 404 depending on backend.
      // We keep it manual so demo stays clean.
      const rid0 = (window.__vsp_runs_latest_rid||"");
      if (!rid0) return toast("No RID to probe");
      const u = `${API.runFile}?rid=${ridParam(rid0)}&path=${encodeURIComponent("run_manifest.json")}`;
      const st = await tryPing(u);
      cap.textContent = (st==="OK") ? "run_file: YES (path param)" : `run_file: NO (${st})`;
      toast(cap.textContent);
    });

    legacyBtn.addEventListener("click", ()=>{
      legacyShown=!legacyShown;
      toggleLegacy(legacyShown);
      legacyBtn.textContent = legacyShown ? "Hide legacy" : "Show legacy";
    });

    // KPI
    const mkK = (name)=>({name, v: el("span",{class:"v"},["0"])});
    const kTotal=mkK("Total"), kG=mkK("GREEN"), kA=mkK("AMBER"), kR=mkK("RED"), kU=mkK("UNKNOWN"), kD=mkK("DEGRADED");
    const kpis = el("div",{class:"vsp-kpis"},[
      el("div",{class:"vsp-kpi"},[el("span",{class:"k"},[kTotal.name]), kTotal.v]),
      el("div",{class:"vsp-kpi"},[el("span",{class:"k"},[kG.name]), kG.v]),
      el("div",{class:"vsp-kpi"},[el("span",{class:"k"},[kA.name]), kA.v]),
      el("div",{class:"vsp-kpi"},[el("span",{class:"k"},[kR.name]), kR.v]),
      el("div",{class:"vsp-kpi"},[el("span",{class:"k"},[kU.name]), kU.v]),
      el("div",{class:"vsp-kpi"},[el("span",{class:"k"},[kD.name]), kD.v]),
      el("div",{class:"vsp-kpi"},[el("span",{class:"k"},["Capabilities"]), cap]),
    ]);

    const pager = el("div",{class:"vsp-pager"},[
      el("span",{class:"vsp-runsqa-mini"},["Page size"]), pageSizeSel,
      prevBtn, nextBtn,
      el("span",{class:"vsp-runsqa-mini"},["Page"]), pageIn,
      pageInfo,
    ]);

    const wrap=el("div",{class:"vsp-runsqa-wrap"},[
      el("div",{class:"vsp-runsqa-mini"},["Runs & Reports Quick Actions V1H: KPI + pagination. Không auto-probe run_file => không có 404 spam. (Nếu muốn kiểm tra run_file thì bấm Check run_file)."]),
      kpis,
      el("div",{class:"vsp-runsqa-toolbar"},[
        ridIn, overallSel, degrSel,
        el("span",{class:"vsp-runsqa-mini"},["From"]), fromIn,
        el("span",{class:"vsp-runsqa-mini"},["To"]), toIn,
        refreshBtn, checkBtn, legacyBtn, clearBtn, stat
      ]),
      pager
    ]);

    const table=el("table",{class:"vsp-runsqa-table"},[
      el("thead",{},[el("tr",{},[
        el("th",{},["RID"]),
        el("th",{},["Date"]),
        el("th",{},["Overall"]),
        el("th",{},["Degraded"]),
        el("th",{},["Actions"]),
      ])]),
      el("tbody",{})
    ]);
    const tbody=table.querySelector("tbody");
    wrap.appendChild(table);
    anchor.appendChild(wrap);

    let runsCache=[];
    let page=1;

    function recomputeKpi(allItems){
      let g=0,a=0,r=0,u=0,d=0;
      for (const run of allItems){
        const ov = String(pickOverall(run)||"UNKNOWN").toUpperCase();
        if (ov.includes("GREEN") || ov==="OK" || ov==="PASS") g++;
        else if (ov.includes("AMBER") || ov.includes("WARN")) a++;
        else if (ov.includes("RED") || ov.includes("FAIL") || ov.includes("ERROR")) r++;
        else u++;
        if (pickDegraded(run)) d++;
      }
      kTotal.v.textContent = String(allItems.length);
      kG.v.textContent = String(g);
      kA.v.textContent = String(a);
      kR.v.textContent = String(r);
      kU.v.textContent = String(u);
      kD.v.textContent = String(d);
    }

    function passes(run){
      const rid=pickRid(run);
      const overall=pickOverall(run);
      const degraded=pickDegraded(run);
      const ts=parseTs(run);

      const q=ridIn.value.trim().toLowerCase();
      if(q && !String(rid).toLowerCase().includes(q)) return false;

      const o=overallSel.value.trim().toUpperCase();
      if(o){
        const ov = String(overall||"").toUpperCase();
        if(o==="GREEN" && !ov.includes("GREEN")) return false;
        if(o==="AMBER" && !ov.includes("AMBER")) return false;
        if(o==="RED" && !ov.includes("RED")) return false;
        if(o==="UNKNOWN" && ov!=="UNKNOWN") return false;
      }

      const dsel=degrSel.value;
      if(dsel==="true" && !degraded) return false;
      if(dsel==="false" && degraded) return false;

      const from=fromIn.value ? new Date(fromIn.value+"T00:00:00") : null;
      const to=toIn.value ? new Date(toIn.value+"T23:59:59") : null;
      if((from||to) && ts){
        if(from && ts<from) return false;
        if(to && ts>to) return false;
      }
      return true;
    }

    function getFilteredSorted(){
      return runsCache
        .filter(passes)
        .sort((a,b)=>{
          const ta=parseTs(a), tb=parseTs(b);
          if(ta && tb) return tb.getTime()-ta.getTime();
          if(ta && !tb) return -1;
          if(!ta && tb) return 1;
          return 0;
        });
    }

    function clampPage(p, totalPages){
      if (p < 1) return 1;
      if (p > totalPages) return totalPages;
      return p;
    }

    function render(){
      const itemsAll = getFilteredSorted();
      recomputeKpi(itemsAll);

      const pageSize = parseInt(pageSizeSel.value || "20", 10);
      const totalPages = Math.max(1, Math.ceil(itemsAll.length / pageSize));
      page = clampPage(page, totalPages);
      pageIn.value = String(page);
      pageInfo.textContent = `${page}/${totalPages}`;

      const start = (page-1)*pageSize;
      const items = itemsAll.slice(start, start + pageSize);

      tbody.innerHTML="";
      for(const run of items){
        const rid=pickRid(run);
        const overall=pickOverall(run);
        const degraded=pickDegraded(run);
        const ts=parseTs(run);

        const actions = el("div",{class:"vsp-actions"},[
          el("button",{class:"vsp-runsqa-btn", onclick: async ()=>openUrl(urlCsv(rid))},["CSV"]),
          el("button",{class:"vsp-runsqa-btn", onclick: async ()=>openUrl(urlTgz(rid))},["TGZ"]),
          el("button",{class:"vsp-runsqa-btn", onclick: async ()=>toast("Open JSON/HTML cần backend hỗ trợ /api/vsp/run_file_allow")},["Open JSON"]),
          el("button",{class:"vsp-runsqa-btn", onclick: async ()=>toast("Open JSON/HTML cần backend hỗ trợ /api/vsp/run_file_allow")},["Open HTML"]),
        ]);

        const tr = el("tr",{class:"vsp-runsqa-row"},[
          el("td",{},[
            el("div",{},[String(rid||"(no rid)")]),
            el("div",{class:"vsp-runsqa-mini"},[
              el("button",{class:"vsp-runsqa-btn", onclick: async ()=>{
                try{ await navigator.clipboard.writeText(String(rid||"")); toast("Copied RID"); } catch(e){ toast("Copy failed"); }
              }},["Copy RID"]),
              " ",
              el("button",{class:"vsp-runsqa-btn", onclick: async ()=>{
                const u = `${API.openFolder}?rid=${ridParam(rid)}`;
                const st = await tryPing(u);
                if (st !== "OK") return toast(`Open folder: backend chưa hỗ trợ (${st})`);
                toast("Open folder: OK");
              }},["Open folder"]),
            ])
          ]),
          el("td",{},[fmtDate(ts)||"-"]),
          el("td",{},[badgeForOverall(overall)]),
          el("td",{},[degraded ? el("span",{class:"vsp-badge amber"},["DEGRADED"]) : el("span",{class:"vsp-badge ok"},["OK"])]),
          el("td",{},[actions]),
        ]);
        tbody.appendChild(tr);
      }

      stat.textContent = `Showing ${items.length}/${itemsAll.length} (runs=${runsCache.length})`;
      prevBtn.disabled = (page<=1);
      nextBtn.disabled = (page>=totalPages);
    }

    prevBtn.addEventListener("click", ()=>{ page=Math.max(1,page-1); render(); });
    nextBtn.addEventListener("click", ()=>{ page=page+1; render(); });
    pageIn.addEventListener("change", ()=>{
      const v=parseInt(pageIn.value||"1",10);
      page=isNaN(v)?1:v;
      render();
    });
    pageSizeSel.addEventListener("change", ()=>{ page=1; render(); });

    async function load(){
      stat.textContent="Loading…";
      runsCache = await fetchRuns(1200);
      page=1;
      window.__vsp_runs_latest_rid = pickRid((runsCache && runsCache[0]) || {});
      render();
      log("loaded + running, runs=", runsCache.length);
    }

    [ridIn,overallSel,degrSel,fromIn,toIn].forEach(x=>x.addEventListener("input", ()=>{ page=1; render(); }));
    refreshBtn.addEventListener("click", load);
    clearBtn.addEventListener("click", ()=>{ ridIn.value=""; overallSel.value=""; degrSel.value=""; fromIn.value=""; toIn.value=""; page=1; render(); });

    load();
  }

  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();


/* VSP_P1_RUNS_LIVE_POLLING_V1 (safe: poll /api/vsp/runs?limit=1 only; triggers existing Refresh; pauses when hidden) */
(()=> {
  if (window.__vsp_p1_runs_live_polling_v1) return;
  window.__vsp_p1_runs_live_polling_v1 = true;

  try {
    if (!location || !location.pathname || !/\/runs(?:\/)?$/.test(location.pathname)) return;
  } catch (e) { return; }

  const S = {
    live: true,
    baseDelayMs: 7000,
    maxDelayMs: 60000,
    delayMs: 7000,
    lastRid: "",
    lastOkTs: 0,
    timer: null,
    running: false,
    backoffN: 0,
  };

  const now = ()=> Date.now();

  function findBtnByText(rxList){
    const btns = Array.from(document.querySelectorAll("button"));
    for (const b of btns){
      const t = (b.textContent||"").trim();
      if (!t) continue;
      for (const rx of rxList){
        if (rx.test(t)) return b;
      }
    }
    return null;
  }

  function ensureLiveUi(){
    if (document.getElementById("vsp_live_toggle_v1")) return;

    // find a reasonable toolbar parent: prefer the row that contains Refresh
    const refreshBtn = findBtnByText([/^\s*refresh\s*$/i, /^\s*làm\s*mới\s*$/i]);
    let host = refreshBtn ? refreshBtn.parentElement : null;
    if (!host) host = document.querySelector(".toolbar") || document.querySelector(".controls") || document.body;

    const wrap = document.createElement("span");
    wrap.style.display = "inline-flex";
    wrap.style.gap = "8px";
    wrap.style.alignItems = "center";
    wrap.style.marginLeft = "10px";

    const tgl = document.createElement("button");
    tgl.id = "vsp_live_toggle_v1";
    tgl.className = (refreshBtn && refreshBtn.className) ? refreshBtn.className : "btn";
    tgl.style.minWidth = "92px";
    tgl.title = "Live polling: ON/OFF (poll /api/vsp/runs?limit=1; auto refresh when RID changes)";
    tgl.textContent = "Live: ON";

    const st = document.createElement("span");
    st.id = "vsp_live_status_v1";
    st.style.opacity = "0.85";
    st.style.fontSize = "12px";
    st.textContent = "Last: --";

    tgl.addEventListener("click", ()=> {
      S.live = !S.live;
      tgl.textContent = S.live ? "Live: ON" : "Live: OFF";
      if (S.live) kick("toggle_on");
    });

    wrap.appendChild(tgl);
    wrap.appendChild(st);

    // place right after Refresh if possible, else append
    if (refreshBtn && refreshBtn.parentElement === host){
      refreshBtn.insertAdjacentElement("afterend", wrap);
    } else {
      host.appendChild(wrap);
    }
  }

  function setStatus(msg){
    const el = document.getElementById("vsp_live_status_v1");
    if (el) el.textContent = msg;
  }

  async function fetchLatestRid(){
    const url = `/api/vsp/runs?limit=1&offset=0&_=${now()}`;
    const r = await fetch(url, { cache: "no-store", credentials: "same-origin" });
    if (!r.ok) throw new Error(`runs status ${r.status}`);
    const j = await r.json();
    const it = (j && j.items && j.items[0]) ? j.items[0] : null;
    if (!it) return "";
    return (it.rid || it.run_id || it.id || "").toString();
  }

  function triggerRefresh(){
    const refreshBtn = findBtnByText([/^\s*refresh\s*$/i, /^\s*làm\s*mới\s*$/i]);
    if (refreshBtn && !refreshBtn.disabled){
      refreshBtn.click();
      return true;
    }
    return false;
  }

  function schedule(ms){
    clearTimeout(S.timer);
    S.timer = setTimeout(()=> tick("timer"), ms);
  }

  function kick(reason){
    if (!S.live) return;
    if (document.hidden) return;
    schedule(250);
  }

  async function tick(reason){
    if (!S.live) return;
    if (document.hidden) { schedule(S.baseDelayMs); return; }
    if (S.running) { schedule(500); return; }

    S.running = true;
    try {
      ensureLiveUi();

      const rid = await fetchLatestRid();
      const changed = (rid && rid !== S.lastRid);
      if (rid) S.lastRid = rid;

      S.lastOkTs = now();
      S.backoffN = 0;
      S.delayMs = S.baseDelayMs;

      const ts = new Date().toLocaleTimeString();
      setStatus(`Last: ${ts}${changed ? " • new RID" : ""}`);

      if (changed){
        // IMPORTANT: do NOT probe run_file here. Just refresh the list via existing button.
        triggerRefresh();
      }

      schedule(S.delayMs);
    } catch (e){
      S.backoffN += 1;
      S.delayMs = Math.min(S.maxDelayMs, Math.max(S.baseDelayMs, S.baseDelayMs * (2 ** Math.min(5, S.backoffN))));
      const ts = new Date().toLocaleTimeString();
      setStatus(`Last: ${ts} • err • backoff ${Math.round(S.delayMs/1000)}s`);
      schedule(S.delayMs);
    } finally {
      S.running = false;
    }
  }

  document.addEventListener("visibilitychange", ()=> {
    if (!document.hidden && S.live) kick("visible");
  });

  // boot
  ensureLiveUi();
  schedule(800);
})();
;(()=> {
  try{
    // ===================== VSP_P1_RUNS_RELEASE_CARD_PATCH_REAL_RUNS_JS_V1 =====================
    const isRuns = ()=>{
      try{
        const p = (location.pathname||"");
        return (p === "/runs" || p.includes("/runs") || p.includes("runs_reports"));
      }catch(e){ return false; }
    };

    function ensureBox(){
      const id="vsp_current_release_card_runs_v1";
      let box=document.getElementById(id);
      if (box) return box;
      box=document.createElement("div");
      box.id=id;
      box.style.cssText=[
        "position:fixed","right:16px","bottom:16px","z-index:99999",
        "max-width:560px","min-width:360px",
        "border:1px solid rgba(255,255,255,.14)",
        "background:rgba(10,18,32,.78)",
        "border-radius:16px","padding:12px 14px",
        "box-shadow:0 12px 34px rgba(0,0,0,.45)",
        "backdrop-filter:blur(8px)"
      ].join(";");
      document.body.appendChild(box);
      return box;
    }

    const row=(k,v)=>`<div style="display:flex;gap:10px;align-items:baseline;line-height:1.35;margin:4px 0">
      <div style="min-width:110px;opacity:.78">${k}</div>
      <div style="font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size:12.5px; word-break:break-all">${v}</div>
    </div>`;

    async function load(){
      if (!isRuns()) return;
      const box=ensureBox();
      try{
        const r = await fetch("/api/vsp/release_latest", {credentials:"same-origin", cache:"no-store"});
        if (!r.ok) throw new Error("http_"+r.status);
        const j = await r.json();
        if (!j || !j.package) throw new Error("no_package");

        const pkg=j.package, sha=j.sha256_file||"", man=j.manifest||"", ts=j.ts||"";
        box.innerHTML = `
          <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px">
            <div style="font-weight:800;letter-spacing:.2px">Current Release</div>
            <div style="opacity:.7;font-size:12px">${ts}</div>
          </div>
          ${row("PACKAGE", `<a href="/${pkg}" style="color:#9ad7ff;text-decoration:none">${pkg}</a>`)}
          ${sha ? row("SHA256", `<a href="/${sha}" style="color:#9ad7ff;text-decoration:none">${sha}</a>`) : ""}
          ${man ? row("MANIFEST", `<a href="/${man}" style="color:#9ad7ff;text-decoration:none">${man}</a>`) : ""}
          <div style="opacity:.55;font-size:11.5px;margin-top:8px">Auto-refresh: 60s • Runs-only</div>
        `;
        try{ console.log("[ReleaseCardRunsV1] shown:", pkg); }catch(e){}

try{
  const relPath = (j && (j.release_pkg || j.package)) ? (j.release_pkg || j.package) : "";
  const ex = await __vspRelPkgExistsV1(relPath);
  if (ex && ex.exists){
    // if badge text element exists, flip to OK
    try{
      if (badgeEl) { badgeEl.textContent = "OK"; badgeEl.classList && badgeEl.classList.add("ok"); }
    }catch(e){}
    try{
      if (msgEl && /cannot verify/i.test(msgEl.textContent||"")) msgEl.textContent = "";
    }catch(e){}
  }
}catch(e){}
      }catch(e){
        box.innerHTML = `<div style="font-weight:700">Current Release</div>
          <div style="opacity:.75;margin-top:6px">not available</div>
          <div style="opacity:.55;font-size:11.5px;margin-top:8px">(${String(e&&e.message||e)})</div>`;
      }
    }

    function boot(){
      if (!isRuns()) return;
      if (window.__vsp_runs_release_card_realjs_v1) return;
      window.__vsp_runs_release_card_realjs_v1 = true;
      load();
      setInterval(()=>{ try{ load(); }catch(e){} }, 60000);
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
    else boot();
    // ===================== /VSP_P1_RUNS_RELEASE_CARD_PATCH_REAL_RUNS_JS_V1 =====================
  }catch(e){}
})();

/* ===================== VSP_P1_RELEASE_CARD_V2C_RUNS_ONLY_V1 =====================
   - runs-only (never touches Dashboard)
   - less noise: prefer /api/vsp/release_latest first; no multi-404 probing spam
   - STALE (amber) if release points to missing package (404)
   - package existence check is cached: recheck only when pkg/sha changes or manual Refresh
   - if STALE(404) => pause auto-check until Refresh (no repeated 404 in console)
   - fixed overlay independent of rerender
   - buttons: Copy package link / Copy sha
================================================= */
(() => {
  if (window.__vsp_p1_release_card_v2c_runs_only_v1) return;
  window.__vsp_p1_release_card_v2c_runs_only_v1 = true;

  const CFG = {
    refreshMs: 120000,
    headTimeoutMs: 6000,
    // reorder to reduce 404 spam seen in your screenshot
    jsonUrls: [
      "/api/vsp/release_latest",
      "/api/vsp/release_latest.json",
      "/release_latest.json",
      "/static/release_latest.json",
    ],
  };

  const nowIso = () => new Date().toISOString().replace("T"," ").replace("Z","Z");

  function isRunsLikePage(){
    const p = (location.pathname || "").toLowerCase();
    if (p.includes("dashboard") || p === "/vsp5" || p === "/") return false;
    if (p.includes("runs") || p.includes("reports")) return true;
    return !!document.querySelector(
      "#vsp_runs_root,#vsp_runs_reports_root,[data-vsp-page='runs'],[data-vsp-page='runs_reports'],.vsp-runs-root"
    );
  }
  if (!isRunsLikePage()) return;

  function ensureStyle(){
    if (document.getElementById("vsp_release_card_v2_style")) return;
    const st = document.createElement("style");
    st.id = "vsp_release_card_v2_style";
    st.textContent = `
#vsp_release_card_v2{
  position:fixed; right:16px; bottom:16px; z-index:999999;
  width:360px; max-width:calc(100vw - 28px);
  background:rgba(8,14,26,.92);
  border:1px solid rgba(255,255,255,.10);
  box-shadow:0 14px 40px rgba(0,0,0,.55);
  border-radius:14px; overflow:hidden;
  font: 13px/1.35 ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;
  color:rgba(255,255,255,.88);
  backdrop-filter: blur(8px);
}
#vsp_release_card_v2 .h{
  display:flex; align-items:center; justify-content:space-between;
  padding:10px 12px; background:rgba(255,255,255,.03);
  border-bottom:1px solid rgba(255,255,255,.08);
}
#vsp_release_card_v2 .t{ font-weight:700; letter-spacing:.2px; color:rgba(255,255,255,.92); }
#vsp_release_card_v2 .badge{
  display:inline-flex; align-items:center; gap:6px;
  border-radius:999px; padding:3px 9px; font-weight:700;
  border:1px solid rgba(255,255,255,.10);
}
#vsp_release_card_v2 .dot{ width:8px; height:8px; border-radius:999px; background:rgba(255,255,255,.5); }
#vsp_release_card_v2 .b-ok{ background:rgba(0,255,170,.08); color:rgba(140,255,220,.96); border-color:rgba(0,255,170,.20); }
#vsp_release_card_v2 .b-amber{ background:rgba(255,200,0,.08); color:rgba(255,216,106,.96); border-color:rgba(255,200,0,.22); }
#vsp_release_card_v2 .b-red{ background:rgba(255,80,80,.08); color:rgba(255,160,160,.96); border-color:rgba(255,80,80,.22); }
#vsp_release_card_v2 .c{ padding:10px 12px 12px; }
#vsp_release_card_v2 .row{ display:flex; justify-content:space-between; gap:10px; padding:4px 0; }
#vsp_release_card_v2 .k{ color:rgba(255,255,255,.60); }
#vsp_release_card_v2 .v{ color:rgba(255,255,255,.90); text-align:right; word-break:break-word; }
#vsp_release_card_v2 a{ color:rgba(140,205,255,.95); text-decoration:none; }
#vsp_release_card_v2 a:hover{ text-decoration:underline; }
#vsp_release_card_v2 .btns{ display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; }
#vsp_release_card_v2 button{
  border:1px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.04);
  color:rgba(255,255,255,.88);
  border-radius:10px; padding:7px 10px;
  cursor:pointer; font-weight:700;
}
#vsp_release_card_v2 button:hover{ background:rgba(255,255,255,.07); }
#vsp_release_card_v2 .mini{ font-size:12px; color:rgba(255,255,255,.55); margin-top:8px; }
#vsp_release_card_v2 .toast{
  position:absolute; left:12px; bottom:10px;
  font-size:12px; color:rgba(255,255,255,.75);
  opacity:0; transform:translateY(6px);
  transition:opacity .18s ease, transform .18s ease;
}
#vsp_release_card_v2.showtoast .toast{ opacity:1; transform:translateY(0); }
`;
    document.head.appendChild(st);
  }

  function ensureCard(){
    let card = document.getElementById("vsp_release_card_v2");
    if (card) return card;
    card = document.createElement("div");
    card.id = "vsp_release_card_v2";
    card.innerHTML = `
      <div class="h">
        <div class="t">Current Release</div>
        <div class="badge"><span class="dot"></span><span class="lbl">…</span></div>
      </div>
      <div class="c">
        <div class="row"><div class="k">ts</div><div class="v" data-k="ts">-</div></div>
        <div class="row"><div class="k">package</div><div class="v" data-k="pkg">-</div></div>
        <div class="row"><div class="k">sha</div><div class="v" data-k="sha">-</div></div>
        <div class="btns">
          <button type="button" data-act="copy_pkg">Copy package link</button>
          <button type="button" data-act="copy_sha">Copy sha</button>
          <button type="button" data-act="refresh">Refresh</button>
          <button type="button" data-act="hide">Hide</button>
        </div>
        <div class="mini" data-k="hint">updated: -</div>
      </div>
      <div class="toast" data-k="toast">copied</div>
    `;
    document.body.appendChild(card);
    return card;
  }

  function setBadge(card, kind, text){
    const b = card.querySelector(".badge");
    const lbl = card.querySelector(".badge .lbl");
    b.classList.remove("b-ok","b-amber","b-red");
    if (kind === "ok") b.classList.add("b-ok");
    else if (kind === "amber") b.classList.add("b-amber");
    else if (kind === "red") b.classList.add("b-red");
    lbl.textContent = text;
  }

  function toast(card, msg){
    const t = card.querySelector('[data-k="toast"]');
    t.textContent = msg;
    card.classList.add("showtoast");
    setTimeout(() => card.classList.remove("showtoast"), 900);
  }

  async function copyText(card, text){
    try{
      if (navigator.clipboard && navigator.clipboard.writeText){
        await navigator.clipboard.writeText(text);
        toast(card, "Copied");
        return true;
      }
    }catch(_){}
    try{
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.left = "-1000px";
      ta.style.top = "-1000px";
      document.body.appendChild(ta);
      ta.focus(); ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      toast(card, ok ? "Copied" : "Copy failed");
      return ok;
    }catch(_){}
    toast(card, "Copy failed");
    return false;
  }

  async function fetchJsonTry(urls){
    for (const u of urls){
      try{
        const r = await fetch(u, { cache: "no-store", credentials: "same-origin" });
        if (!r.ok) continue;
        const j = await r.json();
        if (j && typeof j === "object") return { ok:true, url:u, json:j };
      }catch(_){}
    }
    return { ok:false };
  }

  function pickFirst(obj, keys){
    for (const k of keys){
      if (!obj) continue;
      if (obj[k] != null && String(obj[k]).trim() !== "") return obj[k];
      // also try case-insensitive (your release json may use PACKAGE/SHA256)
      const kk = Object.keys(obj).find(x => String(x).toLowerCase() == String(k).toLowerCase());
      if (kk && obj[kk] != null && String(obj[kk]).trim() !== "") return obj[kk];
    }
    return null;
  }

  function normalizeRelease(j){
    const ts = pickFirst(j, ["ts","timestamp","built_at","created_at","time","release_ts"]);
    const sha = pickFirst(j, ["sha","sha256","SHA256","git_sha","commit","commit_sha","hash"]);
    const pkg = pickFirst(j, ["pkg_url","package_url","download_url","url","href","pkg","package","path","pkg_path","package_path","tgz","tgz_path","PACKAGE"]);
    const name = pickFirst(j, ["pkg_name","package_name","name","filename"]);
    let pkgUrl = null;

    if (pkg){
      const raw = String(pkg).trim();
      if (/^https?:\/\//i.test(raw)) {
        pkgUrl = raw;
      } else if (raw.startsWith("/")) {
        try{ pkgUrl = new URL(raw, location.origin).toString(); }catch(_){ pkgUrl = raw; }
      } else {
        // relative path -> treat as hosted under origin (/ + path)
        try{ pkgUrl = new URL("/" + raw, location.origin).toString(); }catch(_){ pkgUrl = "/" + raw; }
      }
    }

    const pkgName =
      name ? String(name) :
      (pkgUrl ? decodeURIComponent((String(pkgUrl).split("/").pop() || "package")) : "package");

    return { ts: ts ? String(ts) : null, sha: sha ? String(sha) : null, pkgUrl, pkgName, raw:j };
  }

  async function existsCheck(url, timeoutMs){
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), timeoutMs);
    try{
      const r = await fetch(url, { method: "HEAD", cache:"no-store", credentials:"same-origin", signal: ac.signal });
      clearTimeout(t);
      if (r.ok) return { ok:true, exists:true, status:r.status, via:"HEAD" };
      if (r.status === 404) return { ok:true, exists:false, status:404, via:"HEAD" };
      return { ok:true, exists:null, status:r.status, via:"HEAD" };
    }catch(_){
      clearTimeout(t);
    }

    const ac2 = new AbortController();
    const t2 = setTimeout(() => ac2.abort(), timeoutMs);
    try{
      const r2 = await fetch(url, {
        method: "GET",
        headers: { "Range": "bytes=0-0" },
        cache:"no-store",
        credentials:"same-origin",
        signal: ac2.signal
      });
      clearTimeout(t2);
      if (r2.ok || r2.status === 206) return { ok:true, exists:true, status:r2.status, via:"RANGE" };
      if (r2.status === 404) return { ok:true, exists:false, status:404, via:"RANGE" };
      return { ok:true, exists:null, status:r2.status, via:"RANGE" };
    }catch(_){
      clearTimeout(t2);
      return { ok:false, exists:null, status:null, via:"ERR" };
    }
  }

  function shortSha(sha){
    if (!sha) return "-";
    const s = String(sha).trim();
    return s.length > 12 ? (s.slice(0,12) + "…") : s;
  }

  let last = { pkgUrl:null, sha:null, exists:null, lastCheckAt:0, paused:false, lastStatus:null };

  async function tick(force){
    ensureStyle();
    const card = ensureCard();
    if (!document.body.contains(card)) document.body.appendChild(card);

    setBadge(card, "", "LOADING");
    card.querySelector('[data-k="hint"]').textContent = "updated: " + nowIso();

    const res = await fetchJsonTry(CFG.jsonUrls);
    if (!res.ok){
      setBadge(card, "red", "NO DATA");
      card.querySelector('[data-k="ts"]').textContent = "-";
      card.querySelector('[data-k="pkg"]').innerHTML = "-";
      card.querySelector('[data-k="sha"]').textContent = "-";
      card.querySelector('[data-k="hint"]').textContent = "updated: " + nowIso() + " • release_latest not reachable";
      last = { pkgUrl:null, sha:null, exists:null, lastCheckAt:0, paused:false, lastStatus:null };
      return;
    }

    const rel = normalizeRelease(res.json);
    const ts = rel.ts || "-";
    const sha = rel.sha || null;
    const pkgUrl = rel.pkgUrl || null;

    card.querySelector('[data-k="ts"]').textContent = ts;
    card.querySelector('[data-k="sha"]').textContent = sha ? shortSha(sha) : "-";

    if (pkgUrl){
      const safeName = rel.pkgName || "package";
      card.querySelector('[data-k="pkg"]').innerHTML = `<a href="${pkgUrl}" target="_blank" rel="noreferrer">${safeName}</a>`;
    }else{
      card.querySelector('[data-k="pkg"]').innerHTML = "-";
    }

    // decide whether to re-check package existence
    const signatureChanged = (pkgUrl !== last.pkgUrl) || (String(sha||"") !== String(last.sha||""));
    if (force) last.paused = false; // manual refresh unpauses

    if (!pkgUrl){
      setBadge(card, "amber", "NO PKG");
      card.querySelector('[data-k="hint"]').textContent = `updated: ${nowIso()} • release has no package url • ${res.url}`;
      last = { pkgUrl:null, sha:sha, exists:null, lastCheckAt:0, paused:false, lastStatus:"NO_PKG" };
      return;
    }

    if (last.paused && !force){
      // keep last status without generating new HEAD 404s
      const st = last.lastStatus || "STALE";
      setBadge(card, st === "OK" ? "ok" : "amber", st);
      card.querySelector('[data-k="hint"]').textContent =
        `updated: ${nowIso()} • auto-check paused (STALE) • click Refresh to recheck`;
    } else if (!signatureChanged && last.exists != null && !force){
      // cached
      if (last.exists === false){
        setBadge(card, "amber", "STALE");
        card.querySelector('[data-k="hint"]').textContent =
          `updated: ${nowIso()} • cached: package missing (404) • paused`;
        last.paused = true;
        last.lastStatus = "STALE";
      } else if (last.exists === true){
        setBadge(card, "ok", "OK");
        card.querySelector('[data-k="hint"]').textContent =
          `updated: ${nowIso()} • cached OK • ${res.url}`;
        last.lastStatus = "OK";
      } else {
        setBadge(card, "amber", "CHECK");
        card.querySelector('[data-k="hint"]').textContent =
          `updated: ${nowIso()} • cached unknown • ${res.url}`;
        last.lastStatus = "CHECK";
      }
    } else {
      // do an existence check
      const ex = await (window.__vsp_release_exists_check ? window.__vsp_release_exists_check(pkgUrl, CFG.headTimeoutMs) : existsCheck(pkgUrl, CFG.headTimeoutMs));
      if (ex.ok && ex.exists === false){
        setBadge(card, "amber", "STALE");
        card.querySelector('[data-k="hint"]').textContent =
          `updated: ${nowIso()} • package missing (404) • via ${ex.via} • paused`;
        last.exists = false;
        last.paused = true;          // pause auto rechecks
        last.lastStatus = "STALE";
      }else if (ex.ok && ex.exists === true){
        setBadge(card, "ok", "OK");
        card.querySelector('[data-k="hint"]').textContent =
          `updated: ${nowIso()} • ${res.url}`;
        last.exists = true;
        last.paused = false;
        last.lastStatus = "OK";
      }else{
        setBadge(card, "amber", "CHECK");
        card.querySelector('[data-k="hint"]').textContent =
          `updated: ${nowIso()} • verify package: pending • ${res.url}`;
        last.exists = null;
        last.paused = false;
        last.lastStatus = "CHECK";
      }
    }

    last.pkgUrl = pkgUrl;
    last.sha = sha;

    // wire actions (once)
    if (!card.__vsp_release_v2c_bound){
      card.__vsp_release_v2c_bound = true;
      card.addEventListener("click", async (ev) => {
        const btn = ev.target && ev.target.closest("button[data-act]");
        if (!btn) return;
        const act = btn.getAttribute("data-act");
        if (act === "copy_pkg"){
          if (!last.pkgUrl) return toast(card, "No package link");
          await copyText(card, last.pkgUrl);
        } else if (act === "copy_sha"){
          if (!last.sha) return toast(card, "No sha");
          await copyText(card, String(last.sha));
        } else if (act === "refresh"){
          await tick(true);
        } else if (act === "hide"){
          card.remove();
        }
      });
    }
  }

  function start(){
    tick(false);
    setInterval(() => {
      if (!isRunsLikePage()) return;
      tick(false);
    }, CFG.refreshMs);
  }

  if (document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", start, { once:true });
  } else {
    start();
  }
})();

/* ===================== VSP_P1_RELEASE_CARD_USE_PROBE_NO404_V2 =====================
   - Use backend probe (always 200) to avoid console red 404 when DevTools logs XHR
   - Backend: /api/vsp/release_probe?path=out_ci/releases/...
================================================================================== */
(() => {
  if (window.__vsp_release_probe_no404_v2) return;
  window.__vsp_release_probe_no404_v2 = true;

  window.__vsp_release_exists_check = async (pkgUrl, timeoutMs) => {
    try{
      if (!pkgUrl) return { ok:true, exists:null, status:200, via:"PROBE" };

      let path = "";
      try{
        const u = new URL(String(pkgUrl), location.origin);
        path = (u.pathname || "");
      }catch(_){
        path = String(pkgUrl || "");
      }
      if (path.startsWith("/")) path = path.slice(1);

      const r = await fetch("/api/vsp/release_probe?path=" + encodeURIComponent(path), {
        cache:"no-store",
        credentials:"same-origin"
      });
      const j = await r.json().catch(()=>null);

      if (j && j.ok === true && j.allowed === true){
        if (j.exists === true)  return { ok:true, exists:true,  status:200, via:"PROBE" };
        if (j.exists === false) return { ok:true, exists:false, status:200, via:"PROBE" };
        return { ok:true, exists:null, status:200, via:"PROBE" };
      }
      return { ok:true, exists:null, status:200, via:"PROBE" };
    }catch(e){
      return { ok:false, exists:null, status:null, via:"PROBE_ERR" };
    }
  };
})();

/* ===================== VSP_P1_RELEASE_CARD_RUNS_V2 =====================
   Runs-only release card (no spam):
   - Copy package link / Copy sha
   - STALE if release_latest.json points to missing package
   - Fixed overlay; independent from rerender
========================================================================= */
(()=> {
  if (window.__vsp_release_card_runs_v2) return;
  window.__vsp_release_card_runs_v2 = true;

  const $ = (sel, root=document) => root.querySelector(sel);

  function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }

  function el(tag, attrs={}, children=[]){
    const n = document.createElement(tag);
    for (const [k,v] of Object.entries(attrs||{})){
      if (k === "class") n.className = v;
      else if (k === "style") n.setAttribute("style", v);
      else if (k.startsWith("on") && typeof v === "function") n.addEventListener(k.slice(2), v);
      else if (v !== undefined && v !== null) n.setAttribute(k, String(v));
    }
    for (const c of (children||[])){
      if (c === null || c === undefined) continue;
      n.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return n;
  }

  function normPkgUrl(pkg){
    if (!pkg) return "";
    let x = String(pkg).trim();
    if (!x) return "";
    if (x.startsWith("http://") || x.startsWith("https://")) return x;
    x = x.replace(/^\.\//,'');
    if (x.startsWith("/")) return x;
    // allow "out_ci/..." style
    if (x.startsWith("out_ci/") || x.startsWith("out/")) return "/" + x;
    // fallback: assume releases folder
    return "/out_ci/releases/" + x;
  }

  async function fetchJson(url, timeoutMs=8000){
    const ctrl = new AbortController();
    const t = setTimeout(()=>ctrl.abort(), timeoutMs);
    try{
      const r = await fetch(url, {signal: ctrl.signal, cache:"no-store"});
      if (!r.ok) return {ok:false, _http:r.status, _url:url};
      const j = await r.json();
      return {ok:true, j, _url:url};
    }catch(e){
      return {ok:false, _err:String(e||"ERR"), _url:url};
    }finally{
      clearTimeout(t);
    }
  }

  async function headExists(url, timeoutMs=6000){
    const ctrl = new AbortController();
    const t = setTimeout(()=>ctrl.abort(), timeoutMs);
    try{
      const r = await fetch(url, {method:"HEAD", signal: ctrl.signal, cache:"no-store"});
      return {ok:true, status:r.status, exists: r.status>=200 && r.status<400};
    }catch(e){
      // if HEAD blocked, try GET small
      try{
        const r2 = await fetch(url, {method:"GET", signal: ctrl.signal, cache:"no-store"});
        return {ok:true, status:r2.status, exists: r2.status>=200 && r2.status<400};
      }catch(e2){
        return {ok:false, status:0, exists:false, err:String(e2||e||"ERR")};
      }
    }finally{
      clearTimeout(t);
    }
  }

  function pill(status){
    const map = {
      "OK":      {bg:"#0f2a1b", bd:"#1f6f4a", fg:"#86f3b3"},
      "STALE":   {bg:"#2a1f0f", bd:"#9b6a1b", fg:"#ffd08a"},
      "NO PKG":  {bg:"#1b1b1b", bd:"#666",   fg:"#ddd"},
      "CHECK":   {bg:"#0f1b2a", bd:"#1b4f9b", fg:"#9fd0ff"},
      "ERR":     {bg:"#2a0f14", bd:"#9b1b2c", fg:"#ff9fb0"},
    };
    const s = map[status] || map["NO PKG"];
    return el("span", {style:`display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;border:1px solid ${s.bd};background:${s.bg};color:${s.fg};font-size:12px;letter-spacing:.2px;`}, [status]);
  }

  async function copyText(txt){
    try{
      await navigator.clipboard.writeText(txt);
      return true;
    }catch(e){
      try{
        const ta = el("textarea",{style:"position:fixed;left:-9999px;top:-9999px;opacity:0;"},[txt]);
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        ta.remove();
        return true;
      }catch(e2){ return false; }
    }
  }

  const css = el("style", {}, [`
    .vsp-relcardv2{position:fixed;right:18px;bottom:18px;z-index:99999;width:340px;
      background:rgba(10,14,20,.92);border:1px solid rgba(255,255,255,.08);border-radius:14px;
      box-shadow:0 10px 30px rgba(0,0,0,.45);backdrop-filter: blur(8px); color:#e9eef7;
      font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial;
    }
    .vsp-relcardv2 .hd{display:flex;align-items:center;justify-content:space-between;padding:10px 12px 6px 12px;}
    .vsp-relcardv2 .ttl{font-weight:700;font-size:13px;opacity:.95}
    .vsp-relcardv2 .bd{padding:6px 12px 12px 12px;}
    .vsp-relcardv2 .row{display:flex;gap:10px;align-items:flex-start;margin:6px 0;}
    .vsp-relcardv2 .k{width:72px;opacity:.7;font-size:12px}
    .vsp-relcardv2 .v{flex:1;word-break:break-all;font-size:12px;opacity:.95}
    .vsp-relcardv2 .btns{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
    .vsp-relcardv2 button{cursor:pointer;border-radius:10px;border:1px solid rgba(255,255,255,.10);
      background:rgba(255,255,255,.06);color:#e9eef7;padding:6px 10px;font-size:12px}
    .vsp-relcardv2 button:hover{background:rgba(255,255,255,.10)}
    .vsp-relcardv2 button:disabled{opacity:.45;cursor:not-allowed}
    .vsp-relcardv2 .ft{margin-top:8px;font-size:11px;opacity:.6}
  `]);

  function ensure(){
    if ($("#vsp_release_card_v2")) return $("#vsp_release_card_v2");
    document.head.appendChild(css);

    const state = {status:"CHECK", ts:"", pkg:"", sha:"", note:"", checkedAt:0, exists:null};

    const statusSlot = el("span", {}, [pill("CHECK")]);

    const card = el("div", {id:"vsp_release_card_v2", class:"vsp-relcardv2"}, [
      el("div", {class:"hd"}, [
        el("div", {class:"ttl"}, ["Current Release"]),
        el("div", {}, [statusSlot])
      ]),
      el("div", {class:"bd"}, [
        el("div", {class:"row"}, [el("div",{class:"k"},["ts"]),  el("div",{class:"v", id:"vsp_rel_ts"},["-"])]),
        el("div", {class:"row"}, [el("div",{class:"k"},["package"]), el("div",{class:"v", id:"vsp_rel_pkg"},["-"])]),
        el("div", {class:"row"}, [el("div",{class:"k"},["sha"]), el("div",{class:"v", id:"vsp_rel_sha"},["-"])]),
        el("div", {class:"btns"}, [
          el("button", {id:"vsp_rel_copy_pkg"}, ["Copy package link"]),
          el("button", {id:"vsp_rel_copy_sha"}, ["Copy sha"]),
          el("button", {id:"vsp_rel_refresh"}, ["Refresh"]),
          el("button", {id:"vsp_rel_hide"}, ["Hide"]),
        ]),
        el("div",{class:"ft", id:"vsp_rel_ft"},["loading..."])
      ])
    ]);

    function setStatus(x){
      state.status = x;
      statusSlot.replaceChildren(pill(x));
    }

    function setText(id, v){
      const n = $("#"+id);
      if (n) n.textContent = (v && String(v).trim()) ? String(v) : "-";
    }

    async function run(force=false){
      const now = Date.now();
      if (!force && (now - state.checkedAt) < 30000) return; // cache 30s
      state.checkedAt = now;

      setStatus("CHECK");
      $("#vsp_rel_ft").textContent = "checking release_latest.json ...";

      // try in order: out_ci -> out -> backend (if any)
      const sources = [
        "/out_ci/releases/release_latest.json",
        "/out/releases/release_latest.json",
        "/api/vsp/release_latest",
      ];

      let meta = null, srcOk = null;
      for (const u of sources){
        const r = await fetchJson(u, 7000);
        if (r.ok && r.j && (typeof r.j === "object")){
          meta = r.j; srcOk = u; break;
        }
        await sleep(120);
      }

      if (!meta){
        setStatus("NO PKG");
        setText("vsp_rel_ts","-");
        setText("vsp_rel_pkg","-");
        setText("vsp_rel_sha","-");
        $("#vsp_rel_ft").textContent = "release_latest.json not found (no spam).";
        $("#vsp_rel_copy_pkg").disabled = true;
        $("#vsp_rel_copy_sha").disabled = true;
        return;
      }

      const ts = meta.ts || meta.timestamp || "";
      const sha = meta.sha || meta.sha256 || "";
      const pkg = meta.package || meta.pkg || meta.file || meta.path || "";

      const pkgUrl = normPkgUrl(pkg);

      setText("vsp_rel_ts", ts || "-");
      setText("vsp_rel_pkg", pkgUrl || "-");
      setText("vsp_rel_sha", sha || "-");

      $("#vsp_rel_copy_pkg").disabled = !pkgUrl;
      $("#vsp_rel_copy_sha").disabled = !sha;

      $("#vsp_rel_ft").textContent = `source=${srcOk || "?"}`;

      if (!pkgUrl){
        setStatus("NO PKG");
        $("#vsp_rel_ft").textContent = `source=${srcOk || "?"} • missing package field`;
        return;
      }

      // probe file existence
      $("#vsp_rel_ft").textContent = `source=${srcOk || "?"} • probing package...`;
      const probe = await headExists(pkgUrl, 6000);
      if (probe.ok && probe.exists){
        setStatus("OK");
        $("#vsp_rel_ft").textContent = `OK • source=${srcOk || "?"}`;
      } else {
        setStatus("STALE");
        const st = probe.status ? `http=${probe.status}` : "net-err";
        $("#vsp_rel_ft").textContent = `STALE • ${st} • source=${srcOk || "?"}`;
      }
    }

    card.addEventListener("click", async (e)=>{
      const t = e.target;
      if (!t) return;

      if (t.id === "vsp_rel_hide"){
        card.remove();
        return;
      }
      if (t.id === "vsp_rel_refresh"){
        await run(true);
        return;
      }
      if (t.id === "vsp_rel_copy_pkg"){
        const pkg = $("#vsp_rel_pkg")?.textContent || "";
        if (pkg && pkg !== "-"){
          const full = pkg.startsWith("http") ? pkg : (location.origin + pkg);
          const ok = await copyText(full);
          $("#vsp_rel_ft").textContent = ok ? "copied package link" : "copy failed";
        }
        return;
      }
      if (t.id === "vsp_rel_copy_sha"){
        const sha = $("#vsp_rel_sha")?.textContent || "";
        if (sha && sha !== "-"){
          const ok = await copyText(sha);
          $("#vsp_rel_ft").textContent = ok ? "copied sha" : "copy failed";
        }
        return;
      }
    });

    document.body.appendChild(card);
    run(true);
    return card;
  }

  function boot(){
    try{ ensure(); } catch(e){}
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();


/* ===================== VSP_P1_RUNS_AUDIT_PACK_BTN_V1 ===================== */
(function(){
  if (window.__vsp_p1_runs_audit_pack_btn_v1) return;
  window.__vsp_p1_runs_audit_pack_btn_v1 = true;

  function qs(sel, root){ try { return (root||document).querySelector(sel); } catch(e){ return null; } }
  function qsa(sel, root){ try { return Array.from((root||document).querySelectorAll(sel)); } catch(e){ return []; } }

  function ridFromHref(href){
    if (!href) return "";
    try {
      // match ?rid=... or &rid=...
      const m = href.match(/[?&]rid=([^&]+)/i);
      if (m && m[1]) return decodeURIComponent(m[1]);
    } catch(e){}
    return "";
  }

  function makeBtn(rid){
    const a = document.createElement("a");
    a.className = "vsp-btn vsp-btn-mini vsp-btn-ghost";
    a.textContent = "Audit Pack";
    a.href = "/api/vsp/audit_pack?rid=" + encodeURIComponent(rid);
    a.target = "_blank";
    a.rel = "noopener";
    a.style.marginLeft = "8px";
    a.title = "Download audit evidence pack for RID=" + rid;
    return a;
  }

  function alreadyHasAudit(container, rid){
    const links = qsa('a[href*="/api/vsp/audit_pack?rid="]', container);
    for (const x of links){
      const r = ridFromHref(x.getAttribute("href")||"");
      if (r === rid) return true;
    }
    return false;
  }

  function attachAuditButtons(){
    // Strategy: find existing export links and attach next to them
    const exportLinks = qsa('a[href*="/api/vsp/export_tgz?rid="],a[href*="/api/vsp/export_csv?rid="],a[href*="/api/vsp/export_html?rid="]');
    for (const a of exportLinks){
      const href = a.getAttribute("href") || "";
      const rid = ridFromHref(href);
      if (!rid) continue;

      const parent = a.parentElement || a.closest("td") || a.closest("div") || document.body;
      if (!parent) continue;
      if (alreadyHasAudit(parent, rid)) continue;

      // attach after the tgz link if possible
      parent.appendChild(makeBtn(rid));
    }
  }

  // run now + re-run a few times (table may render async)
  let tries = 0;
  const timer = setInterval(()=>{
    tries++;
    try { attachAuditButtons(); } catch(e){}
    if (tries >= 15) clearInterval(timer);
  }, 600);

  // also rerun on user clicks in runs area (pagination/filter)
  document.addEventListener("click", (ev)=>{
    const t = ev.target;
    if (!t) return;
    const root = t.closest ? (t.closest("#runs") || t.closest("[data-tab='runs']") || t.closest("main") ) : null;
    if (root) { setTimeout(()=>{ try{ attachAuditButtons(); }catch(e){} }, 250); }
  }, true);
})();
 /* ===================== /VSP_P1_RUNS_AUDIT_PACK_BTN_V1 ===================== */


/* ===================== VSP_P1_RUNS_AUDIT_PACK_BTN_V2 ===================== */
(()=> {
  if (window.__vsp_p1_runs_audit_pack_btn_v2) return;
  window.__vsp_p1_runs_audit_pack_btn_v2 = true;

  const qsa = (sel, root)=>{ try { return Array.from((root||document).querySelectorAll(sel)); } catch(e){ return []; } };
  const txt = (el)=> (el && el.textContent ? el.textContent.trim() : "");

  function btnByText(root, label){
    const bs = qsa("button,a", root);
    label = (label||"").toLowerCase();
    for (const b of bs){
      const t = txt(b).toLowerCase();
      if (t === label) return b;
    }
    return null;
  }

  function hasAuditBtn(root){
    const bs = qsa("button,a", root);
    for (const b of bs){
      if (txt(b).toLowerCase() === "audit pack") return true;
    }
    return false;
  }

  function extractRidFromText(s){
    if (!s) return "";
    // patterns seen in your UI:
    // dmpw_linux_install_v8_RUN_20251217_124437_699896
    // RUN_VSP_KICS_TEST_20251211_161546
    // VSP_CI_20251218_114312
    const patterns = [
      /([A-Za-z0-9_-]+_RUN_\d{8}_\d{6,}(?:_\d+)*)/,
      /(RUN_[A-Za-z0-9_]+_\d{8}_\d{6,}(?:_\d+)*)/,
      /(VSP_CI_RUN_\d{8}_\d{6,})/,
      /(VSP_CI_\d{8}_\d{6,})/,
      /(RUN_\d{8}_\d{6,}(?:_\d+)*)/,
    ];
    for (const re of patterns){
      const m = s.match(re);
      if (m && m[1]) return m[1].trim();
    }
    return "";
  }

  function findRowContainerFromCopyBtn(copyBtn){
    // climb a few levels until container also contains TGZ/CSV buttons
    let cur = copyBtn;
    for (let i=0; i<8; i++){
      if (!cur) break;
      const tgz = btnByText(cur, "TGZ");
      const csv = btnByText(cur, "CSV");
      if (tgz && csv) return cur;
      cur = cur.parentElement;
    }
    return null;
  }

  function ensureAuditOnRow(row){
    if (!row || hasAuditBtn(row)) return;

    const tgzBtn = btnByText(row, "TGZ");
    if (!tgzBtn) return;

    const rid = (
      row.getAttribute("data-rid") ||
      row.getAttribute("data-run-id") ||
      row.getAttribute("data-runid") ||
      extractRidFromText(txt(row))
    ).trim();

    if (!rid) return;

    // action container: try parent of TGZ
    const actionBox = tgzBtn.parentElement || row;
    if (hasAuditBtn(actionBox)) return;

    const b = document.createElement("button");
    b.textContent = "Audit Pack";
    b.className = tgzBtn.className || "btn";
    b.style.marginLeft = "8px";
    b.title = "Download audit evidence pack";
    b.addEventListener("click", (ev)=>{
      ev.preventDefault();
      ev.stopPropagation();
      const url = "/api/vsp/audit_pack?rid=" + encodeURIComponent(rid);
      window.open(url, "_blank", "noopener");
    });

    actionBox.appendChild(b);
  }

  function scan(){
    // anchor: Copy RID button exists per row
    const copyBtns = qsa("button,a").filter(x => txt(x).toLowerCase() === "copy rid");
    for (const cb of copyBtns){
      const row = findRowContainerFromCopyBtn(cb);
      if (row) ensureAuditOnRow(row);
    }
  }

  // run now and retry (async render/pagination)
  let tries = 0;
  const t = setInterval(()=> {
    tries++;
    try { scan(); } catch(e){}
    if (tries >= 20) clearInterval(t);
  }, 500);

  // mutation observer for dynamic rerender
  try {
    const mo = new MutationObserver(()=> { try { scan(); } catch(e){} });
    mo.observe(document.documentElement, { childList:true, subtree:true });
  } catch(e){}
})();
 /* ===================== /VSP_P1_RUNS_AUDIT_PACK_BTN_V2 ===================== */


/* ===================== VSP_P1_RELEASE_CARD_VERIFY_PKG_V1 ===================== */
async function __vspRelPkgExistsV1(relPath){
  try{
    if(!relPath) return {ok:false, exists:false};
    const u = "/api/vsp/release_pkg_exists?path=" + encodeURIComponent(relPath);
    const r = await fetch(u, {cache:"no-store"});
    const j = await r.json().catch(()=>null);
    return j || {ok:false, exists:false};
  }catch(e){
    return {ok:false, exists:false};
  }
}
/* ===================== /VSP_P1_RELEASE_CARD_VERIFY_PKG_V1 ===================== */


/* ===================== VSP_P1_RELEASE_CARD_DOM_VERIFY_LINK_V4 ===================== */
(()=> {
  if (window.__vsp_rel_dom_v4) return;
  window.__vsp_rel_dom_v4 = true;

  const qsa = (sel, root)=>{ try { return Array.from((root||document).querySelectorAll(sel)); } catch(e){ return []; } };
  const txt = (el)=> (el && el.textContent ? el.textContent.trim() : "");

  function findCard(){
    const nodes = qsa("*");
    for (const n of nodes){
      if (txt(n) === "Current Release"){
        let c = n;
        for (let i=0;i<10;i++){
          if (!c) break;
          const btns = qsa("button", c);
          if (btns.some(b => txt(b).toLowerCase() === "refresh") &&
              btns.some(b => txt(b).toLowerCase().includes("copy package")) ) return c;
          c = c.parentElement;
        }
      }
    }
    return null;
  }

  function setBadge(card, t){
    const cand = qsa("span,div", card).find(x=>{
      const v = txt(x).toUpperCase();
      return ["NO PKG","STALE","CHECK","OK"].includes(v);
    });
    if (!cand) return;
    cand.textContent = t;
  }

  function setMsg(card, msg){
    // find footer message line contains '/api/vsp/release_latest' or 'verify package'
    const divs = qsa("div,span", card);
    const m = divs.find(x => {
      const v = txt(x).toLowerCase();
      return v.includes("/api/vsp/release_latest") || v.includes("verify package") || v.includes("cannot verify");
    });
    if (m) m.textContent = msg;
  }

  async function refresh(card){
    try{
      const r = await fetch("/api/vsp/release_latest", {cache:"no-store"});
      const j = await r.json();

      const relPath = (j.release_pkg || j.package || "");
      const pkgUrl  = (j.package_url || "");

      // verify exists via endpoint
      let ex = null;
      if (relPath && relPath.startsWith("out_ci/releases/")){
        const u = "/api/vsp/release_pkg_exists?path=" + encodeURIComponent(relPath);
        const rr = await fetch(u, {cache:"no-store"});
        ex = await rr.json().catch(()=>null);
      }

      if (ex && ex.exists){
        setBadge(card, "OK");
        setMsg(card, "updated: " + (j.ts || j.updated || "") + " • pkg verified");
      } else {
        setBadge(card, "CHECK");
        setMsg(card, "updated: " + (j.ts || j.updated || "") + " • verify package: pending");
      }

      // override "Copy package link" to use package_url (download endpoint), not raw /out_ci/... path
      if (pkgUrl){
        const btn = qsa("button", card).find(b => txt(b).toLowerCase().includes("copy package"));
        if (btn && !btn.__vsp_rel_copy_v4){
          btn.__vsp_rel_copy_v4 = true;
          btn.addEventListener("click", async (ev)=>{
            try{
              ev.preventDefault(); ev.stopPropagation();
              await navigator.clipboard.writeText(pkgUrl);
              setMsg(card, "copied package_url: " + pkgUrl);
            }catch(e){}
          }, true);
        }
      }
    }catch(e){}
  }

  function install(){
    const card = findCard();
    if (!card) return false;
    refresh(card);
    const rbtn = qsa("button", card).find(b => txt(b).toLowerCase() === "refresh");
    if (rbtn && !rbtn.__vsp_rel_refresh_v4){
      rbtn.__vsp_rel_refresh_v4 = true;
      rbtn.addEventListener("click", ()=> setTimeout(()=> refresh(card), 50), true);
    }
    return true;
  }

  let tries = 0;
  const t = setInterval(()=>{ tries++; if (install() || tries>40) clearInterval(t); }, 500);

  try{
    const mo = new MutationObserver(()=>{ try{ install(); }catch(e){} });
    mo.observe(document.documentElement, {childList:true, subtree:true});
  }catch(e){}
})();
/* ===================== /VSP_P1_RELEASE_CARD_DOM_VERIFY_LINK_V4 ===================== */



/* VSP_P1_RELEASE_CARD_FORCE_DOWNLOAD_LINK_V1 */
(()=> {
  if (window.__vsp_p1_rel_pkgdl_v1) return;
  window.__vsp_p1_rel_pkgdl_v1 = true;

  const dlUrl = (relPkg) => {
    if (!relPkg) return "";
    const base = location.origin;
    return base + "/api/vsp/release_pkg_download?path=" + encodeURIComponent(String(relPkg));
  };

  async function fetchReleaseLatest(){
    try{
      const r = await fetch("/api/vsp/release_latest", {cache:"no-store"});
      const j = await r.json();
      return j || {};
    }catch(e){
      return {};
    }
  }

  async function copyText(txt){
    try{
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(txt);
        return true;
      }
    }catch(e){}
    try{
      const ta = document.createElement("textarea");
      ta.value = txt; ta.style.position="fixed"; ta.style.left="-9999px";
      document.body.appendChild(ta); ta.focus(); ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return !!ok;
    }catch(e){}
    return false;
  }

  function hookOnce(btn){
    if (!btn || btn.dataset.vspRelPkgdlV1 === "1") return;
    btn.dataset.vspRelPkgdlV1 = "1";
    btn.addEventListener("click", async (ev) => {
      try{
        ev.preventDefault(); ev.stopPropagation();
      }catch(e){}
      const meta = await fetchReleaseLatest();
      const relPkg = meta.release_pkg || meta.release_pkg_path || "";
      const url = dlUrl(relPkg);
      if (!url){
        console.warn("[RelPkgDL] no release_pkg in release_latest");
        return;
      }
      const ok = await copyText(url);
      console.log("[RelPkgDL] copy", ok ? "OK" : "FAIL", url);
    }, true);
  }

  function hookPkgLine(root){
    // nếu package line là <a> hoặc element có text giống file tgz => biến nó thành link download
    try{
      const metaPromise = fetchReleaseLatest();
      metaPromise.then(meta=>{
        const relPkg = meta.release_pkg || meta.release_pkg_path || "";
        const url = dlUrl(relPkg);
        if (!url) return;

        const nodes = root.querySelectorAll("a, code, div, span");
        for (const el of nodes){
          const t = (el.textContent || "").trim();
          if (!t) continue;
          if (t.includes("VSP_RELEASE_") && t.endsWith(".tgz")){
            if (el.tagName === "A"){
              el.href = url;
              el.target = "_blank";
            }else{
              el.style.cursor = "pointer";
              if (el.dataset.vspRelPkgNavV1 === "1") continue;
              el.dataset.vspRelPkgNavV1 = "1";
              el.addEventListener("click", (e)=>{
                try{ e.preventDefault(); e.stopPropagation(); }catch(_){}
                window.open(url, "_blank");
              }, true);
            }
            // chỉ cần xử lý 1 chỗ là đủ
            break;
          }
        }
      });
    }catch(e){}
  }

  function scan(){
    // tìm đúng nút theo label
    const btns = Array.from(document.querySelectorAll("button"));
    for (const b of btns){
      const t = (b.textContent || "").trim().toLowerCase();
      if (t === "copy package link" || t.includes("copy package link")){
        hookOnce(b);
      }
    }
    // cố gắng tìm release card container để hook package line
    const cards = Array.from(document.querySelectorAll("div"));
    for (const c of cards){
      const t = (c.textContent || "");
      if (t.includes("Current Release") && t.includes("package")){
        hookPkgLine(c);
      }
    }
  }

  // observer để chịu re-render
  const mo = new MutationObserver(()=> scan());
  mo.observe(document.documentElement, {subtree:true, childList:true});
  setTimeout(scan, 50);
  setTimeout(scan, 500);
  setTimeout(scan, 1500);

  console.log("[RelPkgDL] installed: copy/open package uses /api/vsp/release_pkg_download");
})();

/* VSP_P1_RELEASE_OUTCI_CLICK_REWRITE_V1
 * Rewrite any click to /out_ci/releases/*.tgz -> /api/vsp/release_pkg_download?path=out_ci/releases/*.tgz
 */
(()=> {
  try {
    if (window.__vsp_release_outci_click_rewrite_v1) return;
    window.__vsp_release_outci_click_rewrite_v1 = true;

    function toDlUrl(href){
      try{
        const u = new URL(href, location.origin);
        const path = u.pathname || "";
        const m = path.match(/\/out_ci\/releases\/([^\/]+\.tgz)$/i);
        if (!m) return null;
        const rel = "out_ci/releases/" + m[1];
        return location.origin + "/api/vsp/release_pkg_download?path=" + encodeURIComponent(rel);
      }catch(e){ return null; }
    }

    document.addEventListener("click", (ev) => {
      const a = ev.target && ev.target.closest ? ev.target.closest("a") : null;
      if (!a) return;
      const href = a.getAttribute("href") || "";
      if (!href) return;
      const dl = toDlUrl(href);
      if (!dl) return;
      ev.preventDefault();
      ev.stopPropagation();
      window.open(dl, "_blank", "noopener");
      console.log("[ReleaseOutCIRewriteV1] redirected to download endpoint:", dl);
    }, true);

    console.log("[ReleaseOutCIRewriteV1] installed");
  } catch(e) {
    // no-op
  }
})();



// Audit Pack click delegation
document.addEventListener('click', (ev)=>{
  const t = ev.target;
  if(!t || !t.getAttribute) return;
  const act = t.getAttribute('data-act');
  if(act !== 'audit_lite' && act !== 'audit_full') return;
  const row = t.closest('[data-rid]') || t.closest('[data-run-id]') || t.closest('tr') || document;
  const rid = (row && row.getAttribute && (row.getAttribute('data-rid') || row.getAttribute('data-run-id'))) || t.getAttribute('data-rid') || '';
  if(!rid) { console.warn('[AuditPack] missing rid for click', t); return; }
  ev.preventDefault();
  ev.stopPropagation();
  const url = (act === 'audit_lite') ? vspAuditPackLiteUrl(rid) : vspAuditPackFullUrl(rid);
  vspDownload(url);
}, true);



/* ===================== VSP_P1_RUNS_WIRE_AUDITPACK_BTN_V3 =====================
   Wire existing "Audit Pack" button to audit_pack_download endpoint.
   - default: Lite pack (lite=1)
   - Shift/Alt: Full pack
   - robust RID resolution
============================================================================= */
(function(){
  if (window.__vsp_audit_wire_v3) return;
  window.__vsp_audit_wire_v3 = true;

  function vspToastV3(msg){
    try{
      let t=document.getElementById('vsp_toast_v3');
      if(!t){
        t=document.createElement('div');
        t.id='vsp_toast_v3';
        t.style.cssText='position:fixed;right:16px;bottom:16px;z-index:99999;padding:10px 12px;border-radius:10px;background:#0b1220;color:#cfe3ff;border:1px solid rgba(120,160,255,.25);box-shadow:0 10px 30px rgba(0,0,0,.45);font:13px/1.3 system-ui;opacity:.0;transition:opacity .15s ease';
        document.body.appendChild(t);
      }
      t.textContent=msg;
      t.style.opacity='1';
      clearTimeout(t.__tm);
      t.__tm=setTimeout(()=>{t.style.opacity='0';}, 1400);
    }catch(e){}
  }

  function vspDownloadV3(url){
    try{
      const a=document.createElement('a');
      a.href=url; a.target='_blank'; a.rel='noopener';
      a.style.display='none';
      document.body.appendChild(a);
      a.click();
      setTimeout(()=>a.remove(), 250);
    }catch(e){
      try{ window.open(url, '_blank', 'noopener'); }catch(_){}
    }
  }

  function auditLiteUrl(rid){ return `/api/vsp/audit_pack_download?rid=${encodeURIComponent(rid)}&lite=1`; }
  function auditFullUrl(rid){ return `/api/vsp/audit_pack_download?rid=${encodeURIComponent(rid)}`; }

  function resolveRid(node){
    if(!node) return '';
    // direct attrs
    let el = node.closest && (node.closest('[data-rid]') || node.closest('[data-run-id]'));
    if(el && el.getAttribute){
      const r = el.getAttribute('data-rid') || el.getAttribute('data-run-id');
      if(r) return r;
    }
    // scan up a bit
    let p=node;
    for(let i=0;i<6 && p; i++){
      if(p.getAttribute){
        const r = p.getAttribute('data-rid') || p.getAttribute('data-run-id');
        if(r) return r;
      }
      p = p.parentElement;
    }
    // fallback: try find RID text in same row first cell
    try{
      const tr = node.closest && node.closest('tr');
      if(tr){
        const a = tr.querySelector('a,button,span,div');
        // but safer: look for something like VSP_ or RUN_
        const txt = tr.innerText || '';
        const m = txt.match(/\b([A-Za-z]+_[A-Za-z0-9]+_[0-9]{8}_[0-9]{6,})\b/);
        if(m && m[1]) return m[1];
      }
    }catch(e){}
    return '';
  }

  function isAuditBtn(t){
    if(!t || !t.getAttribute) return false;
    const act = (t.getAttribute('data-act')||'').toLowerCase();
    if(act === 'audit_pack' || act === 'audit_lite' || act === 'audit_full') return true;
    const tx = (t.textContent||'').trim().toLowerCase();
    return tx === 'audit pack' || tx === 'audit' || tx === 'auditpack';
  }

  document.addEventListener('click', (ev)=>{
    const t = ev.target;
    if(!t) return;
    const btn = (t.closest && t.closest('button')) || t;
    if(!isAuditBtn(btn)) return;

    const rid = btn.getAttribute('data-rid') || resolveRid(btn);
    if(!rid){
      vspToastV3('AuditPack: missing RID');
      return;
    }
    ev.preventDefault();
    ev.stopPropagation();

    const full = !!(ev.shiftKey || ev.altKey);
    const url = full ? auditFullUrl(rid) : auditLiteUrl(rid);

    // UX
    vspToastV3(full ? 'Downloading Audit Pack (FULL)…' : 'Downloading Audit Pack (LITE)…');
    vspDownloadV3(url);
  }, true);

  // Optional: rename visible label to hint shortcut
  try{
    const all = Array.from(document.querySelectorAll('button'));
    all.forEach(b=>{
      const tx=(b.textContent||'').trim().toLowerCase();
      if(tx==='audit pack'){
        b.title = 'Click: Lite pack | Shift/Alt+Click: Full pack';
      }
    });
  }catch(e){}

  console.log('[VSP][Runs] AuditPack wire v3 installed');
})();


/* ===================== VSP_P1_RELEASE_CARD_AUDITPACK_LATEST_V1 =====================
   Add "Audit Pack (Latest)" into Current Release panel (Runs page).
   Uses /api/vsp/runs?limit=1 to resolve latest RID.
   Click => lite, Shift/Alt+Click => full.
============================================================================= */
(function(){
  if (window.__vsp_release_audit_latest_v1) return;
  window.__vsp_release_audit_latest_v1 = true;

  async function getLatestRid(){
    try{
      const r = await fetch('/api/vsp/runs?limit=1', {cache:'no-store'});
      const j = await r.json();
      const one = (j.runs && j.runs[0]) || {};
      return one.rid || one.run_id || '';
    }catch(e){ return ''; }
  }

  function auditLiteUrl(rid){ return `/api/vsp/audit_pack_download?rid=${encodeURIComponent(rid)}&lite=1`; }
  function auditFullUrl(rid){ return `/api/vsp/audit_pack_download?rid=${encodeURIComponent(rid)}`; }

  function dl(url){
    try{
      const a=document.createElement('a');
      a.href=url; a.target='_blank'; a.rel='noopener';
      a.style.display='none'; document.body.appendChild(a);
      a.click(); setTimeout(()=>a.remove(),250);
    }catch(e){}
  }

  function findReleasePanel(){
    // heuristics: look for a box containing "Current Release"
    const nodes = Array.from(document.querySelectorAll('*'));
    for(const n of nodes){
      const tx = (n.textContent||'').trim();
      if(tx === 'Current Release' || tx.includes('Current Release')){
        // pick container: nearest card-like div
        return n.closest('div') || n.parentElement || null;
      }
    }
    return null;
  }

  function injectBtn(panel, rid){
    if(!panel || !rid) return;
    if(panel.querySelector && panel.querySelector('[data-rel-audit-latest="1"]')) return;

    const wrap=document.createElement('div');
    wrap.style.cssText='margin-top:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;';
    const b=document.createElement('button');
    b.type='button';
    b.className='vsp-btn vsp-btn-sm';
    b.textContent='Audit Pack (Latest)';
    b.title='Click: Lite | Shift/Alt+Click: Full';
    b.setAttribute('data-rel-audit-latest','1');

    b.addEventListener('click', (ev)=>{
      ev.preventDefault(); ev.stopPropagation();
      const full = !!(ev.shiftKey || ev.altKey);
      dl(full ? auditFullUrl(rid) : auditLiteUrl(rid));
    });

    const meta=document.createElement('span');
    meta.style.cssText='opacity:.85;font-size:12px;';
    meta.textContent=`RID: ${rid}`;

    wrap.appendChild(b);
    wrap.appendChild(meta);

    panel.appendChild(wrap);
  }

  async function boot(){
    const rid = await getLatestRid();
    if(!rid) return;
    const panel = findReleasePanel();
    if(!panel) return;
    injectBtn(panel, rid);
  }

  setTimeout(boot, 450);
})();


/* ===================== VSP_P1_RUNS_AUDIT_BADGE_V1 =====================
   Show Audit manifest badge per row using /api/vsp/audit_pack_manifest
   - Badge: ✓inc / ✗miss / ⚠err
   - Lite-only fetch (fast): lite=1
   - Tooltip: show first few error paths
============================================================================= */
(function(){
  if (window.__vsp_audit_badge_v1) return;
  window.__vsp_audit_badge_v1 = true;

  const cache = new Map(); // rid -> manifest json
  const inflight = new Map();

  function mkBadge(j){
    const inc = j.included_count ?? 0;
    const miss = j.missing_count ?? 0;
    const err = j.errors_count ?? 0;

    const b = document.createElement('span');
    b.className = 'vsp-audit-badge-v1';
    b.style.cssText = [
      'display:inline-flex','align-items:center','gap:6px',
      'margin-left:8px','padding:2px 8px','border-radius:999px',
      'font-size:12px','line-height:18px',
      'border:1px solid rgba(120,160,255,.25)',
      'background:rgba(8,14,28,.55)','color:#cfe3ff'
    ].join(';');

    b.textContent = `Audit ✓${inc} ✗${miss} ⚠${err}`;

    // tooltip
    try{
      const errs = (j.errors || []).slice(0,4).map(x=>x.path).filter(Boolean);
      const missp = (j.missing || []).slice(0,4).map(x=>x.path).filter(Boolean);
      let tip = `Audit manifest (lite)\n✓ included: ${inc}\n✗ missing: ${miss}\n⚠ errors: ${err}`;
      if (errs.length) tip += `\n\nErrors:\n- ` + errs.join('\n- ');
      if (missp.length) tip += `\n\nMissing:\n- ` + missp.join('\n- ');
      b.title = tip;
    }catch(e){}
    return b;
  }

  async function fetchManifest(rid){
    if(cache.has(rid)) return cache.get(rid);
    if(inflight.has(rid)) return inflight.get(rid);

    const p = (async ()=>{
      try{
        const u = `/api/vsp/audit_pack_manifest?rid=${encodeURIComponent(rid)}&lite=1`;
        const r = await fetch(u, {cache:'no-store'});
        const j = await r.json();
        cache.set(rid, j);
        return j;
      }catch(e){
        const j = {ok:false, err:String(e), included_count:0, missing_count:0, errors_count:0};
        cache.set(rid, j);
        return j;
      }finally{
        inflight.delete(rid);
      }
    })();

    inflight.set(rid, p);
    return p;
  }

  function resolveRid(node){
    if(!node) return '';
    const el = node.closest && (node.closest('[data-rid]') || node.closest('[data-run-id]'));
    if(el && el.getAttribute){
      return el.getAttribute('data-rid') || el.getAttribute('data-run-id') || '';
    }
    // fallback: scan up
    let p=node;
    for(let i=0;i<6 && p; i++){
      if(p.getAttribute){
        const r = p.getAttribute('data-rid') || p.getAttribute('data-run-id');
        if(r) return r;
      }
      p = p.parentElement;
    }
    // try find rid text
    try{
      const tr = node.closest && node.closest('tr');
      if(tr){
        const txt = tr.innerText || '';
        const m = txt.match(/\b([A-Za-z]+_[A-Za-z0-9]+_[0-9]{8}_[0-9]{6,})\b/);
        if(m && m[1]) return m[1];
      }
    }catch(e){}
    return '';
  }

  function placeBadgeNearAuditButton(btn, badge){
    // Put badge right after the button group
    try{
      const parent = btn.parentElement || btn;
      if(parent.querySelector && parent.querySelector('.vsp-audit-badge-v1')) return;
      parent.appendChild(badge);
    }catch(e){}
  }

  async function scanAndAttach(){
    const buttons = Array.from(document.querySelectorAll('button'))
      .filter(b => ((b.textContent||'').trim().toLowerCase() === 'audit pack') || (b.getAttribute('data-act')||'').toLowerCase().includes('audit'));

    let attached = 0;
    for(const btn of buttons){
      if(btn.__vsp_badge_done) continue;
      const rid = btn.getAttribute('data-rid') || resolveRid(btn);
      if(!rid) continue;

      btn.__vsp_badge_done = true;
      const j = await fetchManifest(rid);
      const badge = mkBadge(j);
      placeBadgeNearAuditButton(btn, badge);
      attached++;
    }
    if(attached>0 && !window.__vsp_audit_badge_log_once){
      window.__vsp_audit_badge_log_once = true;
      console.log('[VSP][Runs] audit badge attached:', attached);
    }
  }

  // Observe rerenders/pagination
  try{
    const obs = new MutationObserver(()=>{
      if(window.__vsp_audit_badge_t) return;
      window.__vsp_audit_badge_t = setTimeout(()=>{
        window.__vsp_audit_badge_t = null;
        scanAndAttach();
      }, 180);
    });
    obs.observe(document.body, {childList:true, subtree:true});
  }catch(e){}

  setTimeout(scanAndAttach, 400);
  setTimeout(scanAndAttach, 1200);
})();
