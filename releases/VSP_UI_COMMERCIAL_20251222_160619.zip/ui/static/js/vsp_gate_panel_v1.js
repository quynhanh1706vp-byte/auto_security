/* VSP_GATE_PANEL_V1 (P0 canonical): stable RID resolve + canonical gate summary + no N/A */
(function(){
  'use strict';

  const LS_KEYS = [
    "vsp_rid_selected_v2",
    "vsp_rid_selected",
    "vsp_last_rid"
  ];

  const SELS = [
    "#vsp_gate_panel",
    "#vsp-gate-panel",
    "#gate_panel",
    "#gate-panel",
    ".vsp-gate-panel",
    "[data-vsp-gate-panel]"
  ];

  let _inited = false;
  let _warned_no_mount = false;
  let _warned_no_runs = false;

  function nowISO(){
    try { return new Date().toISOString(); } catch(_) { return ""; }
  }

  function safeText(x){
    if (x === null || x === undefined) return "";
    if (typeof x === "string") return x;
    try { return JSON.stringify(x); } catch(_) { return String(x); }
  }

  function pickMount(){
    for (const s of SELS){
      const el = document.querySelector(s);
      if (el) return el;
    }
    return null;
  }

  function setHTML(el, html){
    if (!el) return;
    el.innerHTML = html;
  }

  function badge(status){
    const s = (status || "").toUpperCase();
    const cls =
      s === "OK" ? "vsp-bdg-ok" :
      (s === "FAIL" || s === "RED") ? "vsp-bdg-fail" :
      (s === "DEGRADED" || s === "AMBER") ? "vsp-bdg-deg" :
      "vsp-bdg-unk";
    return `<span class="vsp-bdg ${cls}">${escapeHtml(s || "UNKNOWN")}</span>`;
  }

  function escapeHtml(str){
    return String(str)
      .replaceAll("&","&amp;")
      .replaceAll("<","&lt;")
      .replaceAll(">","&gt;")
      .replaceAll('"',"&quot;")
      .replaceAll("'","&#039;");
  }

  function normalizeOverall(v){
    // accept many shapes: {overall:{status}} or {verdict:{overall}} or {status}
    if (!v) return { status: "DEGRADED", reasons: ["missing gate summary"], degraded: ["gate_summary_missing"], ts: nowISO() };

    // status candidates
    let status =
      (v.overall && (v.overall.status || v.overall.verdict)) ||
      (v.verdict && (v.verdict.overall || v.verdict.status)) ||
      v.status ||
      v.overall_status ||
      v.overall;

    status = String(status || "").toUpperCase();

    // map common verdict words
    if (status === "GREEN") status = "OK";
    if (status === "AMBER") status = "DEGRADED";
    if (status === "RED") status = "FAIL";
    if (!status) status = "DEGRADED";

    // reasons/degraded lists
    const reasons = []
      .concat((v.overall && v.overall.reasons) || [])
      .concat((v.reasons) || [])
      .concat((v.overall && v.overall.reason) ? [v.overall.reason] : [])
      .concat((v.reason) ? [v.reason] : [])
      .filter(Boolean)
      .map(safeText);

    const degraded = []
      .concat((v.overall && v.overall.degraded) || [])
      .concat(v.degraded || [])
      .concat(v.degraded_list || [])
      .filter(Boolean)
      .map(safeText);

    const ts =
      (v.overall && (v.overall.ts || v.overall.timestamp)) ||
      v.ts || v.timestamp || nowISO();

    return { status, reasons, degraded, ts: safeText(ts) };
  }

  async function fetchJSON(url){
    const r = await fetch(url, { credentials: "same-origin" });
    if (!r.ok) {
      const t = await r.text().catch(()=> "");
      const e = new Error(`HTTP ${r.status} ${r.statusText} for ${url}`);
      e._body = t;
      e._status = r.status;
      throw e;
    }
    return await r.json();
  }

  function getRIDFromLocalStorage(){
    for (const k of LS_KEYS){
      try {
        const v = localStorage.getItem(k);
        if (v && String(v).trim()) return String(v).trim();
      } catch(_){}
    }
    return "";
  }

  function setRIDToLocalStorage(rid){
    try { localStorage.setItem("vsp_rid_selected_v2", String(rid||"")); } catch(_){}
    try { localStorage.setItem("vsp_last_rid", String(rid||"")); } catch(_){}
  }

  async function resolveRID(){
    // 1) localStorage (canonical P0)
    const lsRid = getRIDFromLocalStorage();
    if (lsRid) return lsRid;

    // 2) dashboard_v3 (often has current run_id)
    try{
      const d = await fetchJSON("/api/vsp/dashboard_v3");
      const rid = d && (d.run_id || d.rid || (d.current && (d.current.run_id || d.current.rid)));
      if (rid) return String(rid);
    } catch(_){}

    // 3) runs_index latest (fallback)
    try{
      const idx = await fetchJSON("/api/vsp/runs_index_v3_fs_resolved?limit=1&hide_empty=0&filter=1");
      const items = (idx && idx.items) ? idx.items : [];
      const rid = items.length ? (items[0].run_id || items[0].rid || items[0].id) : "";
      if (rid) return String(rid);
      if (!_warned_no_runs){
        _warned_no_runs = true;
        console.warn("[VSP_GATE] no runs from runs_index_v3_fs_resolved (degraded)");
      }
    } catch(e){
      if (!_warned_no_runs){
        _warned_no_runs = true;
        console.warn("[VSP_GATE] runs_index_v3_fs_resolved fetch failed (degraded)", e);
      }
    }

    return "";
  }

  async function fetchGateSummaryByRID(rid){
    // try canonical endpoints (order matters)
    const candidates = [
      `/api/vsp/run_gate_summary_v1/${encodeURIComponent(rid)}`,
      `/api/vsp/run_gate_summary_v2/${encodeURIComponent(rid)}`,
      `/api/vsp/run_gate_summary/${encodeURIComponent(rid)}`,
      `/api/vsp/run_gate_summary_v1?rid=${encodeURIComponent(rid)}`,
      `/api/vsp/run_gate_summary_v2?rid=${encodeURIComponent(rid)}`
    ];

    let lastErr = null;
    for (const url of candidates){
      try{
        const j = await fetchJSON(url);
        return { ok:true, url, data:j };
      } catch(e){
        lastErr = e;
        // continue
      }
    }
    return { ok:false, url:(candidates[candidates.length-1]||""), err:lastErr };
  }

  function renderGate(el, model){
    const status = (model && model.status) ? model.status : "DEGRADED";
    const reasons = (model && model.reasons && model.reasons.length) ? model.reasons : [];
    const degraded = (model && model.degraded && model.degraded.length) ? model.degraded : [];
    const ts = (model && model.ts) ? model.ts : nowISO();

    const reasonsHtml = reasons.length
      ? `<ul class="vsp-gate-list">${reasons.map(x=>`<li>${escapeHtml(x)}</li>`).join("")}</ul>`
      : `<div class="vsp-gate-muted">No reasons</div>`;

    const degradedHtml = degraded.length
      ? `<ul class="vsp-gate-list">${degraded.map(x=>`<li>${escapeHtml(x)}</li>`).join("")}</ul>`
      : `<div class="vsp-gate-muted">No degraded items</div>`;

    const html = `
      <div class="vsp-gate-wrap">
        <div class="vsp-gate-hd">
          <div class="vsp-gate-title">OVERALL VERDICT</div>
          <div class="vsp-gate-badge">${badge(status)}</div>
        </div>
        <div class="vsp-gate-sub">
          <div><span class="vsp-gate-k">Updated:</span> <span class="vsp-gate-v">${escapeHtml(ts)}</span></div>
          ${model && model._rid ? `<div><span class="vsp-gate-k">RID:</span> <span class="vsp-gate-v">${escapeHtml(model._rid)}</span></div>` : ""}
          ${model && model._src ? `<div><span class="vsp-gate-k">Source:</span> <span class="vsp-gate-v">${escapeHtml(model._src)}</span></div>` : ""}
        </div>

        <div class="vsp-gate-cols">
          <div class="vsp-gate-col">
            <div class="vsp-gate-col-title">Reasons</div>
            ${reasonsHtml}
          </div>
          <div class="vsp-gate-col">
            <div class="vsp-gate-col-title">Degraded</div>
            ${degradedHtml}
          </div>
        </div>
      </div>
    `;

    setHTML(el, html);

    // inject minimal styles once
    if (!document.getElementById("vsp-gate-style-v1")){
      const st = document.createElement("style");
      st.id = "vsp-gate-style-v1";
      st.textContent = `
        .vsp-gate-wrap{border-radius:14px;padding:14px 14px 10px;border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.03)}
        .vsp-gate-hd{display:flex;align-items:center;justify-content:space-between;gap:10px}
        .vsp-gate-title{font-weight:700;letter-spacing:.2px}
        .vsp-gate-sub{margin-top:8px;display:grid;gap:4px;font-size:12px;opacity:.9}
        .vsp-gate-k{opacity:.7}
        .vsp-gate-cols{margin-top:10px;display:grid;grid-template-columns:1fr 1fr;gap:12px}
        .vsp-gate-col-title{font-size:12px;font-weight:700;opacity:.85;margin-bottom:6px}
        .vsp-gate-list{margin:0;padding-left:16px;font-size:12px;opacity:.9}
        .vsp-gate-muted{font-size:12px;opacity:.6}
        .vsp-bdg{display:inline-flex;align-items:center;justify-content:center;padding:5px 10px;border-radius:999px;font-size:12px;font-weight:800;letter-spacing:.3px;border:1px solid rgba(255,255,255,.12)}
        .vsp-bdg-ok{background:rgba(0,255,140,.12)}
        .vsp-bdg-deg{background:rgba(255,190,0,.14)}
        .vsp-bdg-fail{background:rgba(255,70,70,.14)}
        .vsp-bdg-unk{background:rgba(160,160,160,.14)}
        @media (max-width: 900px){ .vsp-gate-cols{grid-template-columns:1fr} }
      `;
      document.head.appendChild(st);
    }
  }

  async function loadAndRender(){
    const mount = pickMount();
    if (!mount){
      if (!_warned_no_mount){
        _warned_no_mount = true;
        console.warn("[VSP_GATE] mount element not found (degraded)");
      }
      return;
    }

    // skeleton immediately
    renderGate(mount, { status:"DEGRADED", reasons:["waiting for run id"], degraded:["rid_pending"], ts:nowISO(), _src:"bootstrap" });

    const rid = await resolveRID();
    if (!rid){
      renderGate(mount, {
        status:"DEGRADED",
        reasons:["missing RID (no localStorage, no dashboard_v3 run_id, no runs_index)"],
        degraded:["rid_missing"],
        ts: nowISO(),
        _src:"resolveRID"
      });
      return;
    }

    setRIDToLocalStorage(rid);

    const gs = await fetchGateSummaryByRID(rid);
    if (!gs.ok){
      const msg = gs.err ? (gs.err.message || safeText(gs.err)) : "unknown error";
      renderGate(mount, {
        status:"DEGRADED",
        reasons:[`missing gate summary for RID=${rid}`, msg],
        degraded:["gate_summary_missing"],
        ts: nowISO(),
        _rid: rid,
        _src:"canonical_endpoints"
      });
      return;
    }

    const model = normalizeOverall(gs.data);
    model._rid = rid;
    model._src = gs.url;
    renderGate(mount, model);
  }

  function init(){
    if (_inited) return;
    _inited = true;

    // run once on DOM ready
    const run = () => { loadAndRender().catch(e=>console.warn("[VSP_GATE] loadAndRender failed", e)); };
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", run, { once:true });
    } else {
      run();
    }

    // optional: refresh on custom events if other tabs update RID
    window.addEventListener("vsp:rid_changed", run);
  }

  // expose minimal API (safe)
  window.VSP_GATE_PANEL_V1 = {
    init,
    refresh: () => loadAndRender()
  };

  init();
})();
