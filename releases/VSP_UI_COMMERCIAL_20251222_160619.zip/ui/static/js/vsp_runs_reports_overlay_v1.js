/* VSP Runs & Reports Overlay V1
 * - Safe: independent renderer for /runs
 * - Uses: /api/ui/runs_kpi_v2 + /api/ui/runs_v3?limit=&offset=
 */
(()=> {
  if (window.__vsp_runs_overlay_v1) return;
  window.__vsp_runs_overlay_v1 = true;

  const API_KPI  = "/api/ui/runs_kpi_v2";
  const API_RUNS = "/api/ui/runs_v3";

  const $ = (sel, root=document)=> root.querySelector(sel);
  const el = (tag, attrs={}, kids=[])=>{
    const n=document.createElement(tag);
    for (const [k,v] of Object.entries(attrs||{})){
      if (k==="class") n.className=v;
      else if (k==="style") n.setAttribute("style", v);
      else if (k.startsWith("on") && typeof v==="function") n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v);
    }
    for (const k of (kids||[])){
      if (k==null) continue;
      if (typeof k==="string") n.appendChild(document.createTextNode(k));
      else n.appendChild(k);
    }
    return n;
  };

  async function api(url){
    const r = await fetch(url, {cache:"no-store"});
    const t = await r.text();
    let j=null;
    try{ j = JSON.parse(t); } catch(_){
      throw new Error("bad_json: " + url + " body=" + t.slice(0,200));
    }
    if (!r.ok || !j || j.ok !== true){
      throw new Error("api_err: " + url + " status=" + r.status + " body=" + t.slice(0,200));
    }
    return j;
  }

  function pill(txt, cls){
    return el("span",{class:"pill "+(cls||"")},[txt]);
  }

  function overallClass(x){
    x = (x||"UNKNOWN").toUpperCase();
    if (x==="GREEN") return "ok";
    if (x==="AMBER") return "warn";
    if (x==="RED") return "bad";
    return "unk";
  }

  function fmtTime(sec){
    if (!sec) return "-";
    const d = new Date(sec*1000);
    return d.toISOString().replace("T"," ").replace(".000Z","Z");
  }

  function ensureHost(){
    // /runs template của bạn có .wrap; nếu không có thì fallback body
    return $(".wrap") || document.body;
  }

  function injectStyles(){
    if ($("#VSP_RUNS_OVERLAY_STYLE_V1")) return;
    const css = `
#vspRunsOverlayV1{margin-top:12px}
#vspRunsOverlayV1 .row{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin:10px 0}
#vspRunsOverlayV1 .kpis{display:flex;gap:10px;flex-wrap:wrap}
#vspRunsOverlayV1 .kpi{min-width:160px;border:1px solid rgba(27,42,85,.75);border-radius:14px;background:rgba(10,16,32,.55);padding:10px}
#vspRunsOverlayV1 .kpi .t{color:var(--muted);font-size:12px}
#vspRunsOverlayV1 .kpi .v{font-size:20px;font-weight:800;margin-top:4px}
#vspRunsOverlayV1 .controls{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
#vspRunsOverlayV1 select{padding:8px 10px;border:1px solid var(--line);border-radius:10px;background:rgba(10,16,32,.6);color:var(--txt)}
#vspRunsOverlayV1 .mini{color:var(--muted);font-size:12px}
#vspRunsOverlayV1 .pill{display:inline-block;padding:3px 8px;border-radius:999px;background:var(--chip);border:1px solid rgba(27,42,85,.65);margin-right:6px}
#vspRunsOverlayV1 .ok{color:var(--ok)} .bad{color:var(--bad)} .warn{color:var(--warn)} .unk{color:var(--muted)}
#vspRunsOverlayV1 table{width:100%;border-collapse:separate;border-spacing:0;margin-top:10px;overflow:hidden;border-radius:12px}
#vspRunsOverlayV1 thead th{position:sticky;top:0;background:rgba(14,22,48,.9);backdrop-filter:blur(6px);
  color:var(--muted);font-weight:600;text-align:left;padding:10px;border-bottom:1px solid var(--line)}
#vspRunsOverlayV1 tbody td{padding:10px;border-bottom:1px solid rgba(27,42,85,.45);vertical-align:middle}
#vspRunsOverlayV1 tbody tr:hover{background:rgba(15,27,61,.25)}
#vspRunsOverlayV1 .btn{padding:8px 12px;border:1px solid var(--line);border-radius:10px;background:rgba(10,16,32,.6);cursor:pointer}
#vspRunsOverlayV1 .btn:hover{filter:brightness(1.08)}
#vspRunsOverlayV1 .err{margin-top:10px;color:#FFD0D6;white-space:pre-wrap}
`;
    const st = el("style",{id:"VSP_RUNS_OVERLAY_STYLE_V1"},[css]);
    document.head.appendChild(st);
  }

  function mountUI(){
    injectStyles();
    const host = ensureHost();
    if ($("#vspRunsOverlayV1")) return $("#vspRunsOverlayV1");

    const root = el("div",{id:"vspRunsOverlayV1", class:"panel"},[]);
    const topRow = el("div",{class:"row"},[]);
    const kpis = el("div",{class:"kpis"},[]);
    const controls = el("div",{class:"controls"},[]);

    const q = el("input",{placeholder:"search rid / path ...", style:"min-width:320px"},[]);
    const pageSize = el("select",{},[
      el("option",{value:"10"},["10/page"]),
      el("option",{value:"20", selected:"selected"},["20/page"]),
      el("option",{value:"50"},["50/page"]),
      el("option",{value:"100"},["100/page"]),
    ]);
    const prevBtn = el("button",{class:"btn"},["Prev"]);
    const nextBtn = el("button",{class:"btn"},["Next"]);
    const pageInfo = el("span",{class:"mini"},["offset=0"]);

    controls.appendChild(q);
    controls.appendChild(pageSize);
    controls.appendChild(prevBtn);
    controls.appendChild(nextBtn);
    controls.appendChild(pageInfo);

    topRow.appendChild(kpis);
    topRow.appendChild(controls);

    const table = el("table",{},[
      el("thead",{},[
        el("tr",{},[
          el("th",{},["RID"]),
          el("th",{},["Overall"]),
          el("th",{},["Findings"]),
          el("th",{},["Updated"]),
          el("th",{},["Notes"]),
        ])
      ]),
      el("tbody",{},[])
    ]);

    const errBox = el("div",{class:"err", style:"display:none"},[""]);
    root.appendChild(topRow);
    root.appendChild(table);
    root.appendChild(errBox);

    host.appendChild(root);

    return {root, kpis, q, pageSize, prevBtn, nextBtn, pageInfo, tbody: $("tbody", table), errBox};
  }

  function setErr(ui, msg){
    ui.errBox.style.display = msg ? "block" : "none";
    ui.errBox.textContent = msg || "";
  }

  function kpiCard(title, value, cls){
    return el("div",{class:"kpi"},[
      el("div",{class:"t"},[title]),
      el("div",{class:"v "+(cls||"")},[String(value)]),
    ]);
  }

  let offset = 0;
  let total = 0;
  let lastItems = [];

  function renderTable(ui, items){
    ui.tbody.innerHTML = "";
    const term = (ui.q.value||"").trim().toLowerCase();

    const filtered = !term ? items : items.filter(x=>{
      const s = (x.rid||"") + " " + (x.run_dir||"") + " " + (x.findings_path||"");
      return s.toLowerCase().includes(term);
    });

    for (const it of filtered){
      const rid = it.rid || "-";
      const ov  = (it.overall || "UNKNOWN").toUpperCase();
      const ft  = (it.findings_total ?? it.total ?? 0);
      const notes = [
        it.has_findings ? "has_findings" : "no_findings",
        it.has_gate ? "has_gate" : "no_gate",
      ].join(", ");

      const tr = el("tr",{},[
        el("td",{},[rid]),
        el("td",{},[pill(ov, overallClass(ov))]),
        el("td",{},[String(ft)]),
        el("td",{},[fmtTime(it.mtime)]),
        el("td",{},[notes]),
      ]);
      ui.tbody.appendChild(tr);
    }

    ui.pageInfo.textContent = `offset=${offset} / total=${total} / showing=${filtered.length}`;
  }

  async function loadKPI(ui){
    const j = await api(API_KPI);
    ui.kpis.innerHTML = "";
    ui.kpis.appendChild(kpiCard("Total runs", j.total_runs ?? "-", ""));
    const by = j.by_overall || {};
    ui.kpis.appendChild(kpiCard("GREEN",  by.GREEN  ?? 0, "ok"));
    ui.kpis.appendChild(kpiCard("AMBER",  by.AMBER  ?? 0, "warn"));
    ui.kpis.appendChild(kpiCard("RED",    by.RED    ?? 0, "bad"));
    ui.kpis.appendChild(kpiCard("UNKNOWN",by.UNKNOWN?? 0, "unk"));
  }

  async function loadRuns(ui){
    const lim = parseInt(ui.pageSize.value || "20", 10);
    const j = await api(`${API_RUNS}?limit=${encodeURIComponent(lim)}&offset=${encodeURIComponent(offset)}`);
    total = j.total ?? 0;
    lastItems = j.items || [];
    renderTable(ui, lastItems);
  }

  function wire(ui){
    ui.q.addEventListener("input", ()=> renderTable(ui, lastItems));
    ui.pageSize.addEventListener("change", async ()=>{
      offset = 0;
      try{ setErr(ui,""); await loadRuns(ui); } catch(e){ setErr(ui, String(e)); }
    });
    ui.prevBtn.addEventListener("click", async ()=>{
      const lim = parseInt(ui.pageSize.value || "20", 10);
      offset = Math.max(0, offset - lim);
      try{ setErr(ui,""); await loadRuns(ui); } catch(e){ setErr(ui, String(e)); }
    });
    ui.nextBtn.addEventListener("click", async ()=>{
      const lim = parseInt(ui.pageSize.value || "20", 10);
      offset = Math.min(Math.max(0, total - 1), offset + lim);
      try{ setErr(ui,""); await loadRuns(ui); } catch(e){ setErr(ui, String(e)); }
    });
  }

  async function boot(){
    // only run on /runs
    if (!location.pathname || !location.pathname.startsWith("/runs")) return;
    const ui = mountUI();
    wire(ui);
    try{
      setErr(ui,"");
      await loadKPI(ui);
      await loadRuns(ui);
    } catch(e){
      setErr(ui, String(e));
    }
  }

  window.addEventListener("DOMContentLoaded", boot);
})();


/* VSP_P1_RUNS_OVERALL_BADGE_V1 (badge colors + inferred fallback; hide UNKNOWN on /runs) */
(()=> {
  try{
    if (window.__vsp_p1_runs_overall_badge_v1) return;
    window.__vsp_p1_runs_overall_badge_v1 = true;

    // Scope: only affect /runs-like pages to avoid side effects
    const path = (location && location.pathname) ? String(location.pathname) : "";
    if (!/\/runs\b/i.test(path) && !/runs/i.test(path)){
      // still allow if the runs table is embedded somewhere else
      // (no hard return) – but keep effects minimal via DOM selectors below
    }

    function pickOverall(it){
      const src = (it && it.overall_source) ? String(it.overall_source) : "";
      let ov = (it && it.overall) ? String(it.overall) : "";
      const inf = (it && it.overall_inferred) ? String(it.overall_inferred) : "";

      const bad = (!ov || ov === "UNKNOWN" || ov === "unknown");
      const inferredSrc = (src === "inferred_counts" || src === "inferred" || src === "inferred_count");

      if ((bad || inferredSrc) && inf && inf !== "UNKNOWN" && inf !== "unknown"){
        ov = inf;
      }
      if (!ov) ov = "UNKNOWN";
      return ov.toUpperCase();
    }

    function overallClass(ov){
      ov = String(ov||"UNKNOWN").toUpperCase();
      if (ov === "RED") return "vsp-badge vsp-badge-red";
      if (ov === "AMBER") return "vsp-badge vsp-badge-amber";
      if (ov === "GREEN") return "vsp-badge vsp-badge-green";
      return "vsp-badge vsp-badge-gray";
    }

    // CSS injected once
    const styleId = "VSP_P1_RUNS_OVERALL_BADGE_V1_CSS";
    if (!document.getElementById(styleId)){
      const css = `
      .vsp-badge{display:inline-flex;align-items:center;gap:.35em;padding:.15em .55em;border-radius:999px;
        font-size:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:#d7d7d7;line-height:1.4;}
      .vsp-badge-red{background:rgba(255,60,60,.12);border-color:rgba(255,60,60,.25);color:#ffb8b8;}
      .vsp-badge-amber{background:rgba(255,170,0,.12);border-color:rgba(255,170,0,.25);color:#ffe2a6;}
      .vsp-badge-green{background:rgba(0,220,120,.12);border-color:rgba(0,220,120,.25);color:#b7ffd7;}
      .vsp-badge-gray{background:rgba(160,160,160,.10);border-color:rgba(160,160,160,.20);color:#e7e7e7;}
      `;
      const st = document.createElement("style");
      st.id = styleId;
      st.textContent = css;
      document.head.appendChild(st);
    }

    // Cache latest runs list (keyed by rid) from /api/ui/runs_v3
    const origFetch = window.fetch;
    if (typeof origFetch === "function" && !origFetch.__vsp_p1_runs_overall_badge_v1){
      window.fetch = async function(input, init){
        const url = (typeof input === "string") ? input : (input && input.url) || "";
        const resp = await origFetch(input, init);
        try{
          if (url && url.includes("/api/ui/runs_v3")){
            const clone = resp.clone();
            const j = await clone.json();
            const items = Array.isArray(j && j.items) ? j.items : [];
            window.__vsp_runs_cache_v1 = window.__vsp_runs_cache_v1 || {};
            for (const it of items){
              if (it && it.rid) window.__vsp_runs_cache_v1[it.rid] = it;
            }
            setTimeout(fixDom, 0);
          }
        }catch(_){}
        return resp;
      };
      window.fetch.__vsp_p1_runs_overall_badge_v1 = true;
      window.fetch.__vsp_p1_runs_overall_badge_v1 = true;
    }

    function fixCell(td, it){
      const ov = it ? pickOverall(it) : String((td.textContent||"").trim() || "UNKNOWN").toUpperCase();
      const cls = overallClass(ov);
      td.innerHTML = `<span class="${cls}">${ov}</span>`;
    }

    function findRidFromRow(row){
      if (!row) return "";
      return row.getAttribute("data-rid")
          || row.getAttribute("data-id")
          || row.getAttribute("data-run-id")
          || row.getAttribute("rid")
          || "";
    }

    function fixDom(){
      try{
        // Only operate if a runs table likely exists
        const root = document.querySelector("#runs, #runs_tab, .runs, [data-tab='runs'], [data-page='runs'], body") || document.body;
        if (!root) return;

        // cells likely containing "overall"
        const cells = root.querySelectorAll(
          "[data-field='overall'], td.overall, .col-overall, .overall, td[data-col='overall'], td[data-key='overall']"
        );
        if (!cells || !cells.length) return;

        for (const td of cells){
          const row = td.closest("tr");
          const rid = findRidFromRow(row);
          const it = (rid && window.__vsp_runs_cache_v1 && window.__vsp_runs_cache_v1[rid]) ? window.__vsp_runs_cache_v1[rid] : null;

          // If UI already showing badge, skip
          if (td.querySelector && td.querySelector(".vsp-badge")) continue;

          // if text is UNKNOWN but we can infer => replace
          const txt = String((td.textContent||"").trim() || "");
          if (it){
            fixCell(td, it)
          } else if (txt){
            // still render as badge (keeps consistent visuals)
            fixCell(td, null)
          }
        }
      }catch(_){}
    }

    // periodic re-apply (in case table rerenders)
    const boot = () => {
      fixDom();
      setInterval(fixDom, 1200);
    };
    if (document.readyState === "loading"){
      document.addEventListener("DOMContentLoaded", boot);
    } else {
      boot();
    }
  }catch(_){}
})();



/* ===================== VSP_P2_RUNS_KPI_JS_V1 ===================== */
(function(){
  function $id(x){ return document.getElementById(x); }
  function fmtSec(v){
    if(v===null || v===undefined || isNaN(v)) return "—";
    const s = Math.round(Number(v));
    if(s < 60) return s+"s";
    const m = Math.floor(s/60), r = s%60;
    if(m < 60) return m+"m "+r+"s";
    const h = Math.floor(m/60), mm = m%60;
    return h+"h "+mm+"m";
  }
  function fmtPct(v){
    if(v===null || v===undefined || isNaN(v)) return "—";
    return Math.round(Number(v)*1000)/10 + "%";
  }

  function drawStackedBars(canvas, labels, series){
  if(!canvas) return;
  const safeLabels = Array.isArray(labels) ? labels : [];
  const ctx = canvas.getContext("2d");
  const dpr = (window.devicePixelRatio||1);

  const w = canvas.width = Math.max(10, (canvas.clientWidth||600)) * dpr;
  const hh = canvas.getAttribute("height") ? Number(canvas.getAttribute("height")) : 120;
  const h = canvas.height = Math.max(40, hh) * dpr;
  ctx.clearRect(0,0,w,h);

  if(safeLabels.length === 0){
    ctx.globalAlpha = 0.75;
    ctx.fillStyle = "#9fb0c7";
    ctx.font = `${12*dpr}px sans-serif`;
    ctx.fillText("No trend data (0 day)", 12*dpr, 20*dpr);
    ctx.globalAlpha = 1;
    return;
  }

  const padL = 28*dpr, padR = 8*dpr, padT = 10*dpr, padB = 22*dpr;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  const n = safeLabels.length;
  const gap = 2*dpr;
  const barW = Math.max(2*dpr, Math.floor(plotW / n) - gap);

  const totals = safeLabels.map((_,i)=> (series||[]).reduce((a,s)=> a + (Number(s?.values?.[i]||0)), 0));
  const maxT = Math.max(1, ...totals);

  ctx.globalAlpha = 0.5;
  ctx.fillStyle = "#9fb0c7";
  ctx.fillRect(padL, padT+plotH, plotW, 1*dpr);
  ctx.globalAlpha = 1;

  for(let i=0;i<n;i++){
    const x = padL + i*(barW+gap);
    let y = padT + plotH;

    for(const ss of (series||[])){
      const v = Number(ss?.values?.[i]||0);
      if(v<=0) continue;
      const bh = Math.max(1, Math.round((v/maxT)*plotH));
      y -= bh;
      ctx.globalAlpha = ss.alpha || 0.25;
      ctx.fillStyle = "#9fb0c7";
      ctx.fillRect(x, y, barW, bh);
    }
    ctx.globalAlpha = 1;

    if(i===0 || i===n-1 || n<=14 || (i%Math.ceil(n/6)===0)){
      ctx.globalAlpha = 0.7;
      ctx.fillStyle = "#9fb0c7";
      ctx.font = `${10*dpr}px sans-serif`;
      const raw = safeLabels[i];
      const t0 = (typeof raw === "string") ? raw : String(raw||"");
      const t = t0.length >= 10 ? t0.slice(5) : t0; // MM-DD when YYYY-MM-DD
      ctx.fillText(t, x, padT+plotH + 14*dpr);
      ctx.globalAlpha = 1;
    }
  }
}

function drawLine(canvas, labels, v1, v2){
  if(!canvas) return;
  const safeLabels = Array.isArray(labels) ? labels : [];
  const ctx = canvas.getContext("2d");
  const dpr = (window.devicePixelRatio||1);

  const w = canvas.width = Math.max(10, (canvas.clientWidth||600)) * dpr;
  const hh = canvas.getAttribute("height") ? Number(canvas.getAttribute("height")) : 120;
  const h = canvas.height = Math.max(40, hh) * dpr;
  ctx.clearRect(0,0,w,h);

  if(safeLabels.length === 0){
    ctx.globalAlpha = 0.75;
    ctx.fillStyle = "#9fb0c7";
    ctx.font = `${12*dpr}px sans-serif`;
    ctx.fillText("No severity trend data", 12*dpr, 20*dpr);
    ctx.globalAlpha = 1;
    return;
  }

  const padL = 28*dpr, padR = 8*dpr, padT = 10*dpr, padB = 22*dpr;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  const xs = safeLabels.map((_,i)=> padL + (safeLabels.length<=1?0:(i/(safeLabels.length-1))*plotW));

  const all = [];
  for(const v of (v1||[])) if(v!==null && v!==undefined) all.push(Number(v)||0);
  for(const v of (v2||[])) if(v!==null && v!==undefined) all.push(Number(v)||0);
  const maxV = Math.max(1, ...all);

  function yOf(v){
    const vv = Number(v)||0;
    return padT + plotH - (vv/maxV)*plotH;
  }

  ctx.globalAlpha = 0.5;
  ctx.fillStyle = "#9fb0c7";
  ctx.fillRect(padL, padT+plotH, plotW, 1*dpr);
  ctx.globalAlpha = 1;

  function drawOne(vals, alpha){
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = "#9fb0c7";
    ctx.lineWidth = 2*dpr;
    ctx.beginPath();
    let started=false;
    for(let i=0;i<(vals||[]).length;i++){
      const v = vals[i];
      if(v===null || v===undefined) continue;
      const x = xs[i] ?? xs[xs.length-1];
      const y = yOf(v);
      if(!started){ ctx.moveTo(x,y); started=true; }
      else ctx.lineTo(x,y);
    }
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  drawOne(v1||[], 0.55);
  drawOne(v2||[], 0.25);

  for(let i=0;i<safeLabels.length;i++){
    if(i===0 || i===safeLabels.length-1 || safeLabels.length<=14 || (i%Math.ceil(safeLabels.length/6)===0)){
      ctx.globalAlpha = 0.7;
      ctx.fillStyle = "#9fb0c7";
      ctx.font = `${10*dpr}px sans-serif`;
      const raw = safeLabels[i];
      const t0 = (typeof raw === "string") ? raw : String(raw||"");
      const t = t0.length >= 10 ? t0.slice(5) : t0;
      ctx.fillText(t, xs[i], padT+plotH + 14*dpr);
      ctx.globalAlpha = 1;
    }
  }
}

async function loadRunsKpi(
){


// ===================== VSP_P2_DISABLE_OVERLAY_KPI_V1 =====================
// Compact KPI script handles KPI; disable overlay KPI to prevent v3/500 and heavy canvas/layout.
try {
  if (window.__vsp_runs_kpi_compact_v3) return;
  if (window.__VSP_DISABLE_OVERLAY_KPI === true) return;
} catch(e) {}
// ===================== /VSP_P2_DISABLE_OVERLAY_KPI_V1 =====================

/* VSP_P2_SILENCE_RUNS_KPI_V1_LEGACY */
try{
  // If KPI v2 exists or v1 panel nodes are missing => skip legacy updater to avoid null.textContent crashes.
  if (window.__vsp_runs_kpi_bind_v2 || document.getElementById("vsp_runs_kpi_panel_v2")) return;
  // legacy v1 panel markers (adjust if you renamed ids)
  const must1 = document.getElementById("vsp_runs_kpi_status") || document.getElementById("vsp_runs_kpi_status_v1");
  if (!must1) return;
}catch(_){ return; }

    const daysSel = $id("vsp_runs_kpi_days");
    const days = daysSel ? (daysSel.value||"30") : "30";
    const url = `/api/ui/runs_kpi_v2?days=${encodeURIComponent(days)}`;
    try{
      const r = await fetch(url, {cache:"no-store"});
      const j = await r.json();
      if(!j || !j.ok) throw new Error((j&&j.err)||"kpi failed");

      $id("kpi_runs_window").textContent = j.total_days ?? "—";
      $id("kpi_runs_all").textContent = j.total_all ?? "—";

      const st = j.status_days || {};
      $id("kpi_green").textContent = st.GREEN ?? 0;
      $id("kpi_amber").textContent = st.AMBER ?? 0;
      $id("kpi_red").textContent = st.RED ?? 0;
      $id("kpi_unknown").textContent = st.UNKNOWN ?? 0;

      $id("kpi_degraded_count").textContent = j.degraded_days ?? 0;
      $id("kpi_degraded_rate").textContent = fmtPct(j.degraded_rate_days);

      $id("kpi_avg_dur").textContent = fmtSec(j.avg_duration_sec_days);
      $id("kpi_p95_dur").textContent = fmtSec(j.p95_duration_sec_days);

      const bn = j.bottleneck_tool || {};
      $id("kpi_bottleneck").textContent = bn.tool || "—";
      $id("kpi_bottleneck_hint").textContent = bn.hint || "—";

      const dr = j.degraded_reasons_top || [];
      $id("kpi_degraded_reasons").innerHTML = dr.length
        ? dr.map(x=>`<div style="display:flex;justify-content:space-between;gap:10px;"><span style="opacity:.9;">${(x.reason||"").replace(/</g,"&lt;")}</span><span style="opacity:.7;">${x.count||0}</span></div>`).join("")
        : "—";

      // Trend
      const tr = j.trend_days || [];
      const labels = tr.map(x=>x.day);
      const vUnknown = tr.map(x=>x.UNKNOWN||0);
      const vRed = tr.map(x=>x.RED||0);
      const vAmber = tr.map(x=>x.AMBER||0);
      const vGreen = tr.map(x=>x.GREEN||0);

      // draw stacked (use alpha as "layers")
      drawStackedBars(
        $id("vsp_runs_trend_canvas"),
        labels,
        [
          {name:"UNKNOWN", values:vUnknown, alpha:0.14},
          {name:"RED", values:vRed, alpha:0.40},
          {name:"AMBER", values:vAmber, alpha:0.28},
          {name:"GREEN", values:vGreen, alpha:0.18},
        ]
      );

      // Severity trend (best effort)
      const vC = tr.map(x=> (x.CRITICAL===null||x.CRITICAL===undefined) ? null : Number(x.CRITICAL));
      const vH = tr.map(x=> (x.HIGH===null||x.HIGH===undefined) ? null : Number(x.HIGH));
      drawLine($id("vsp_runs_sev_canvas"), labels, vC, vH);

    }catch(e){
      console.warn("[RUNS_KPI] failed:", e);
      const p = $id("vsp_runs_kpi_panel");
      if(p){
        const msg = document.createElement("div");
        msg.style.marginTop = "10px";
        msg.style.opacity = "0.8";
        msg.style.fontSize = "12px";
        msg.textContent = "KPI load failed (safe API). Check server patch / restart.";
        p.appendChild(msg);
      }
    }
  }

  function hookRunsKpi(){
    const btn = $id("vsp_runs_kpi_reload");
    if(btn && !btn.__vsp_hooked){
      btn.__vsp_hooked = true;
      btn.addEventListener("click", loadRunsKpi);
    }
    const sel = $id("vsp_runs_kpi_days");
    if(sel && !sel.__vsp_hooked){
      sel.__vsp_hooked = true;
      sel.addEventListener("change", loadRunsKpi);
    }
    // first load after small delay (let page render)
    setTimeout(loadRunsKpi, 120);
    window.addEventListener("resize", ()=> setTimeout(loadRunsKpi, 120));
  }

  // Try hook when DOM ready
  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", hookRunsKpi);
  } else {
    hookRunsKpi();
  }
})();
/* ===================== /VSP_P2_RUNS_KPI_JS_V1 ===================== */



/* VSP_P2_RUNS_KPI_BIND_V2 (schema adapter for /api/ui/runs_kpi_v2; sets KPI numbers even when trend absent) */
(()=> {
  if (window.__vsp_runs_kpi_bind_v2) return;
  window.__vsp_runs_kpi_bind_v2 = true;

  const $id = (id)=> document.getElementById(id);

  function set(id, v){
    const el = $id(id);
    if(el) el.textContent = (v===undefined || v===null) ? "—" : String(v);
  }

  async function fetchKpi(days){
    const url = `/api/ui/runs_kpi_v2?days=${encodeURIComponent(days||30)}`;
    const r = await fetch(url, {cache:"no-store"});
    const j = await r.json();
    if(!j || j.ok !== true) throw new Error(j?.err || "kpi api failed");
    return j;
  }

  async function reload(){
    const sel = $id("vsp_runs_kpi_days_v2");
    const days = sel ? (sel.value||"30") : "30";
    const st = $id("vsp_runs_kpi_status_v2");
    if(st) st.textContent = "Loading…";

    try{
      const j = await fetchKpi(days);
      const bo = j.by_overall || {};
      set("vsp_kpi_total_v2", j.total_runs ?? 0);
      set("vsp_kpi_green_v2", bo.GREEN ?? 0);
      set("vsp_kpi_amber_v2", bo.AMBER ?? 0);
      set("vsp_kpi_red_v2", bo.RED ?? 0);
      set("vsp_kpi_unknown_v2", bo.UNKNOWN ?? 0);
      set("vsp_kpi_has_findings_v2", j.has_findings ?? 0);
      set("vsp_kpi_latest_rid_v2", j.latest_rid ?? "—");

      if(st){
        st.textContent = `Window=${days}d • total=${j.total_runs ?? 0} • has_gate=${j.has_gate ?? "?"} • ts=${j.ts ?? ""}`.trim();
      }
    }catch(e){
      console.warn("[RUNS_KPI_BIND_V2] failed:", e);
      if(st) st.textContent = "KPI load failed (check /api/ui/runs_kpi_v2)";
    }
  }

  function hook(){
    const btn = $id("vsp_runs_kpi_reload_v2");
    if(btn && !btn.__hooked){
      btn.__hooked = true;
      btn.addEventListener("click", reload);
    }
    const sel = $id("vsp_runs_kpi_days_v2");
    if(sel && !sel.__hooked){
      sel.__hooked = true;
      sel.addEventListener("change", reload);
    }
    setTimeout(reload, 150);
  }

  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", hook);
  else hook();
})();




/* VSP_P2_RUNS_KPI_PREF_V2_FALLBACK_V1 */
window.__vsp_runs_kpi_fetch_v2pref = async (days)=>{
  const q = encodeURIComponent(String(days||30));
  const tryUrls = [`/api/ui/runs_kpi_v2?days=${q}`, `/api/ui/runs_kpi_v1?days=${q}`];
  let lastErr = null;
  for (const url of tryUrls){
    try{
      const r = await fetch(url, {cache:"no-store"});
      const j = await r.json();
      if (j && j.ok) return j;
      lastErr = new Error(j?.err || "kpi api not ok");
    }catch(e){ lastErr = e; }
  }
  throw lastErr || new Error("kpi api failed");
};

