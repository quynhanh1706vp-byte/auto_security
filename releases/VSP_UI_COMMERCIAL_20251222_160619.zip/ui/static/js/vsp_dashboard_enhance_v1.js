// VSP_SAFE_DRILLDOWN_HARDEN_P0_V6
/* P0_DRILLDOWN_NUKE_V8 */

/* __VSP_DD_HANDLER_WRAP_P0_FINAL: normalize VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 to callable */
(function(){
  'use strict';

/* VSP_DD_ART_CALL_V1: commercial stable wrapper (fn OR {open:fn}) */
(function(){
  'use strict';
  if (window.VSP_DD_ART_CALL_V1) return;
  window.VSP_DD_ART_CALL_V1 = function(){
    var h = window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
    var args = Array.prototype.slice.call(arguments);
    try{
      if (typeof h === 'function') return h.apply(null, args);
      if (h && typeof h.open === 'function') return h.open.apply(h, args);
    } catch(e){
      try{ console.warn('[VSP][DD_CALL_V1]', e); } catch(_){}
    }
    return null;
  };
})();


  try{
    var h = window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
    if (h && typeof h !== 'function'){
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
        return (window.__VSP_DD_SAFE_CALL__ || function(x){
          try{
            var a=[].slice.call(arguments,1);
            if (typeof x==='function') return x.apply(null,a);
            if (x && typeof x.open==='function') return x.open.apply(x,a);
          } catch(_){}
          return null;
        }).apply(null, [h].concat([].slice.call(arguments)));
      };
      try{ console.log('[VSP][P0] drilldown handler wrapped (obj->fn)'); } catch(_){}
    }
  } catch(e){}
})();

(function(){
  try{
    if (typeof window === "undefined") return;


/* VSP_FIX_DRILLDOWN_ARTIFACTS_NOT_FUNCTION_P0_V2
 * Fix: TypeError __VSP_DD_ART_CALL__(VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2, ...) is not a function
 * Normalize BEFORE first use:
 *   - if function: keep
 *   - if object with .open(): wrap as function(arg)->obj.open(arg)
 *   - else: no-op (never throw)
 */
(function(){
  'use strict';
  



/* VSP_FIX_DRILLDOWN_CALLSITE_P0_V5: safe-call drilldown artifacts (function OR object.open) */
function __VSP_DD_ART_CALL__(h, ...args) {
  try {
    if (typeof h === 'function') return h(...args);
    if (h && typeof h.open === 'function') return h.open(...args);
  } catch(e) { try{console.warn('[VSP][DD_SAFE]', e);} catch(_e){} }
  return null;
}

/* VSP_FIX_DRILLDOWN_CALLSITE_P0_V3: safe-call for drilldown artifacts (function OR object.open) */
function __VSP_DD_ART_CALL__(h, ...args) {
  try {
    if (typeof h === 'function') return h(...args);
    if (h && typeof h.open === 'function') return h.open(...args);
  } catch (e) {
    try { console.warn('[VSP][DD_SAFE] call failed', e); } catch (_e) {}
  }
  return null;
}

if (window.__VSP_FIX_DRILLDOWN_ARTIFACTS_NOT_FUNCTION_P0_V2) return;
  window.__VSP_FIX_DRILLDOWN_ARTIFACTS_NOT_FUNCTION_P0_V2 = 1;

  function normalize(v){
    if (typeof v === 'function') return v;
    if (v && typeof v.open === 'function') {
      const obj = v;
      const fn = function(arg){ try { return obj.open(arg); } catch(e){ console.warn('[VSP][DD_FIX] open() failed', e); return null; } };
      fn.__wrapped_from_object = true;
      return fn;
    }
    const noop = function(_arg){ return null; };
    noop.__noop = true;
    return noop;
  }

  try {
    // trap future assignments
    let _val = window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
    Object.defineProperty(window, 'VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2', {
      configurable: true, enumerable: true,
      get: function(){ return _val; },
      set: function(v){ _val = normalize(v); }
    });
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = _val;
  } catch(e) {
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = normalize(window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2);
  }
})();

    if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
        try{ console.info("[VSP][P0] drilldown window stub called"); } catch(_){}
        return {open(){},show(){},close(){},destroy(){}};
      };
    }
  } catch(_){}
})();

/* P0_DRILLDOWN_STUB_V6 */
(function(){
  try{
    if (typeof window === "undefined") return;
    if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
        try{ console.info("[VSP_DASH][P0] drilldown window stub called"); } catch(_){}
        return {open(){},show(){},close(){},destroy(){}};
      };
    }
  } catch(_){}
})();

/* P0_DRILLDOWN_CALL_V3 */
(function(){
  try{
    if (typeof window === "undefined") return;

    // Stub always returns an object with safe methods
    window.__VSP_P0_DRILLDOWN_STUB = window.__VSP_P0_DRILLDOWN_STUB || function(){
      try{ console.info("[VSP_DASH][P0] drilldown stub called"); } catch(_){}
      return { open(){}, show(){}, close(){}, destroy(){} };
    };

    // Ensure window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 is callable
    if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = window.__VSP_P0_DRILLDOWN_STUB;
      try{ console.info("[VSP_DASH][P0] drilldown forced stub (window)"); } catch(_){}
    }

    // Stable call entry (never throws)
    window.__VSP_P0_DRILLDOWN_CALL = window.__VSP_P0_DRILLDOWN_CALL || function(){
      try{
        const fn = window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
        if (typeof fn === "function") return fn.apply(window, arguments);
      } catch(_){}
      try{
        return window.__VSP_P0_DRILLDOWN_STUB.apply(window, arguments);
      } catch(_){}
      return { open(){}, show(){}, close(){}, destroy(){} };
    };
  } catch(_){}
})();

/* VSP_P0_DRILLDOWN_CALL_V2: prevent red console when drilldown is missing */
(function(){
  try{
    if (typeof window === "undefined") return;

    // ensure window function exists early (before any local capture)
    if (typeof window.__VSP_P0_DRILLDOWN_STUB !== "function") {
      window.__VSP_P0_DRILLDOWN_STUB = function(){
        try{ console.info("[VSP_DASH][P0] drilldown stub called"); } catch(_){}
        return { open(){}, show(){}, close(){}, destroy(){} };
      };
    }
    if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = window.__VSP_P0_DRILLDOWN_STUB;
      try{ console.info("[VSP_DASH][P0] drilldown forced stub (window)"); } catch(_){}
    }

    // stable caller: always a function
    if (typeof window.__VSP_P0_DRILLDOWN_CALL_V2 !== "function") {
      window.__VSP_P0_DRILLDOWN_CALL_V2 = function(){
        try{
          var fn = window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
          if (typeof fn === "function") return fn.apply(window, arguments);
        } catch(_){}
        try{
          var stub = window.__VSP_P0_DRILLDOWN_STUB;
          if (typeof stub === "function") return stub.apply(window, arguments);
        } catch(_){}
        return { open(){}, show(){}, close(){}, destroy(){} };
      };
    }
  } catch(_){}
})();

/* P0_GUARD_GLOBAL_V1 */
// Define global guard so any callsite can see it (prevents ReferenceError)
(function(){
  try{
    if (typeof window === "undefined") return;

    window.VSP_DASH_IS_ACTIVE_P0 = window.VSP_DASH_IS_ACTIVE_P0 || function(){
      try{
        const h = (location.hash || "").toLowerCase();
        if (!h || h === "#" || h === "#dashboard") return true;
        return false;
      } catch(_){ return false; }
    };

    window.VSP_DASH_P0_GUARD = window.VSP_DASH_P0_GUARD || function(reason){
      try{
        if (!window.VSP_DASH_IS_ACTIVE_P0()){
          try{ console.info("[VSP_DASH][P0] skip:", reason, "hash=", location.hash); } catch(_){}
          return false;
        }
        return true;
      } catch(_){ return true; }
    };

    // Also provide plain global function names (some code calls them directly)
    if (typeof window.VSP_DASH_P0_GUARD === "function") {
      window.VSP_DASH_P0_GUARD_NAME = "ok";
    }
  } catch(_){}
})();

// Plain-name wrappers (avoid ReferenceError even if code calls VSP_DASH_P0_GUARD directly)
function VSP_DASH_IS_ACTIVE_P0(){ try{ return (window && window.VSP_DASH_IS_ACTIVE_P0) ? window.VSP_DASH_IS_ACTIVE_P0() : true; } catch(_){ return true; } }
function VSP_DASH_P0_GUARD(reason){ try{ return (window && window.VSP_DASH_P0_GUARD) ? window.VSP_DASH_P0_GUARD(reason) : true; } catch(_){ return true; } }

// === VSP_CHARTS_ENGINE_SHIM_V1 ===
(function(){
  // Always provide a safe resolver so dashboard never crashes on missing symbol names.
  function _findChartsEngineShim(){
    return (
      window.VSP_CHARTS_ENGINE_V3 ||
      window.VSP_CHARTS_V3 ||
      window.VSP_CHARTS_PRETTY_V3 ||
      window.VSP_DASH_CHARTS_V3 ||
      window.VSP_CHARTS_ENGINE_V2 ||
      window.VSP_CHARTS_V2 ||
      window.VSP_CHARTS_ENGINE ||
      window.VSP_CHARTS ||
      null
    );
  }
  if (typeof window.findChartsEngine !== 'function') {
    window.findChartsEngine = _findChartsEngineShim;
  }
})();

// === VSP_FIND_CHARTS_ENGINE_FALLBACK_V1 ===
if (typeof window.findChartsEngine !== 'function') {
  window.findChartsEngine = function () {
    try {
      // Prefer explicit exported engines
      if (window.VSP_DASH_CHARTS_ENGINE) return window.VSP_DASH_CHARTS_ENGINE;
      if (window.VSP_DASH_CHARTS_V3) return window.VSP_DASH_CHARTS_V3;
      if (window.VSP_DASH_CHARTS_V2) return window.VSP_DASH_CHARTS_V2;

      // Heuristic: look for known globals from pretty charts scripts
      var cand = [
        window.vsp_dashboard_charts_v3,
        window.vsp_dashboard_charts_v2,
        window.VSP_CHARTS_V3,
        window.VSP_CHARTS_V2
      ].filter(Boolean)[0];

      return cand || null;
    } catch (e) { return null; }
  };
}
// === END VSP_FIND_CHARTS_ENGINE_FALLBACK_V1 ===
(function () {
  // VSP 2025 – Dashboard enhance V4 (clean, no patch lỗi)
  console.log('[VSP_DASH] vsp_dashboard_enhance_v1.js (V4 clean) loaded');

  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function safeText(id, value) {
    var el = document.getElementById(id);
    if (!el) return;
    el.textContent = value;
  }

  function fetchDashboard() {
    return fetch('/api/vsp/dashboard_v3', {
      credentials: 'same-origin'
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

  function fillKpis(data) {
    if (!data || typeof data !== 'object') return;
    var bySeverity = data.by_severity || {};
    var total = data.total_findings != null
      ? data.total_findings
      : (bySeverity.CRITICAL || 0) + (bySeverity.HIGH || 0) +
        (bySeverity.MEDIUM || 0) + (bySeverity.LOW || 0) +
        (bySeverity.INFO || 0) + (bySeverity.TRACE || 0);

    safeText('vsp-kpi-total-findings', total);
    safeText('vsp-kpi-critical', bySeverity.CRITICAL != null ? bySeverity.CRITICAL : 0);
    safeText('vsp-kpi-high',     bySeverity.HIGH     != null ? bySeverity.HIGH     : 0);
    safeText('vsp-kpi-medium',   bySeverity.MEDIUM   != null ? bySeverity.MEDIUM   : 0);
    safeText('vsp-kpi-low',      bySeverity.LOW      != null ? bySeverity.LOW      : 0);
    safeText('vsp-kpi-info',     bySeverity.INFO     != null ? bySeverity.INFO     : 0);
    safeText('vsp-kpi-trace',    bySeverity.TRACE    != null ? bySeverity.TRACE    : 0);

    if (data.security_posture_score != null) {
      safeText('vsp-kpi-security-score', data.security_posture_score);
    }

    safeText('vsp-kpi-top-tool',   data.top_risky_tool       || 'N/A');
    safeText('vsp-kpi-top-cwe',    data.top_impacted_cwe     || data.top_cwe || 'N/A');
    safeText('vsp-kpi-top-module', data.top_vulnerable_module || 'N/A');

    var gate = data.ci_gate_status || data.ci_gate || {};
    var gateLabel = gate.label || gate.status || 'N/A';
    var gateDesc  = gate.description || 'Gate dựa trên CRITICAL/HIGH, score & coverage.';
    safeText('vsp-kpi-ci-gate-status',      gateLabel);
    safeText('vsp-kpi-ci-gate-status-desc', gateDesc);
  }

  function hydrateDashboard(data) {
    try {
      fillKpis(data);

      if (window.VSP_CHARTS_V3 && typeof window.VSP_CHARTS_V3.updateFromDashboard === 'function') {
        window.VSP_CHARTS_V3.updateFromDashboard(data);
      } else if (window.VSP_CHARTS_V2 && typeof window.VSP_CHARTS_V2.updateFromDashboard === 'function') {
        window.VSP_CHARTS_V2.updateFromDashboard(data);
      } else {
        console.debug('[VSP_DASH] No charts engine V2/V3 found – only KPIs filled. (will retry)');
      }

      console.log('[VSP_DASH] Dashboard hydrated OK (V4 clean).');
    } catch (e) {
      console.error('[VSP_DASH] Error hydrating dashboard:', e);
    }
  }

  window.hydrateDashboard = hydrateDashboard;

  onReady(function () {
    var pane = document.getElementById('vsp-dashboard-main');
    if (!pane) {
      console.log('[VSP_DASH] No dashboard pane found, skip auto fetch.');
      return;
    }
    console.log('[VSP_DASH] Hydrating dashboard (auto fetch)…');
  if (!VSP_DASH_P0_GUARD("hydrate")) { return; }
    fetchDashboard()
      .then(function (data) {
        console.log('[VSP_DASH] dashboard_v3 data =', data);
        hydrateDashboard(data);
      })
      .catch(function (err) {
        console.error('[VSP_DASH] Failed to load /api/vsp/dashboard_v3:', err);
      });
  });

})();


// === VSP_DASH_CHARTS_RETRY_V1 ===
(function(){
  try{
    let tries = 0;
    function tryHydrate(){
      tries++;
      const eng = window.VSP_CHARTS_V3 || window.VSP_CHARTS_PRETTY_V3 || window.VSP_CHARTS_ENGINE_V3;
      if (eng && typeof eng.hydrate === 'function' && window.__VSP_LAST_DASH_DATA__){
        eng.hydrate(window.__VSP_LAST_DASH_DATA__);
        console.log('[VSP_DASH] charts hydrated via retry');
        return;
      }
      if (tries < 8) setTimeout(tryHydrate, 300);
    }
    setTimeout(tryHydrate, 300);
  } catch(e){}
})();
// === END VSP_DASH_CHARTS_RETRY_V1 ===


// === VSP_DASH_CHARTS_RETRY_V2 ===
(function(){
  try{
    let tries = 0;
    function tick(){
      tries++;
      const eng = findChartsEngine();
      if (eng && window.__VSP_LAST_DASH_DATA__){
        try{
          eng.hydrate(window.__VSP_LAST_DASH_DATA__);
          console.log('[VSP_DASH] charts hydrated via retry v2');
          return;
        } catch(e){}
      }
      if (tries < 8) setTimeout(tick, 350);
    }
    setTimeout(tick, 350);
  } catch(e){}
})();
// === END VSP_DASH_CHARTS_RETRY_V2 ===


// === VSP_DASH_USE_DASH_V3_AND_INIT_CHARTS_V1 ===
(function(){
  try {
    if (window.__VSP_DASH_INIT_CHARTS_V1) return;
    window.__VSP_DASH_INIT_CHARTS_V1 = true;

    function _vspGetChartsEngine() {
      return window.VSP_CHARTS_ENGINE_V3 || window.VSP_CHARTS_ENGINE_V2 || null;
    }

    window.__VSP_DASH_TRY_INIT_CHARTS_V1 = function(dash, reason) {
      try {
        if (dash) window.__VSP_DASH_LAST_DATA_V3 = dash;
        var eng = _vspGetChartsEngine();
        if (!eng || !eng.initAll) return false;
        var d = dash || window.__VSP_DASH_LAST_DATA_V3;
        if (!d) return false;
        var ok = eng.initAll(d);
        console.log("[VSP_DASH] charts initAll via", reason || "unknown", "=>", ok);
        return !!ok;
      } catch (e) {
        console.warn("[VSP_DASH] charts init failed", e);
        return false;
      }
    };

    // Listen for charts-ready (late engine load)
    window.addEventListener("vsp:charts-ready", function(ev){
      setTimeout(function(){
        window.__VSP_DASH_TRY_INIT_CHARTS_V1(null, "charts-ready");
      }, 0);
    });
  } catch(e) {
    console.warn("[VSP_DASH] init-charts patch failed", e);
  }
})();

// === VSP_ENHANCE_WAIT_CHARTS_READY_V1 ===

(function(){
  try{
    if (window.__VSP_ENHANCE_WAIT_CHARTS_READY_V1) return;
    window.__VSP_ENHANCE_WAIT_CHARTS_READY_V1 = true;

    function pickEngine(){
      return window.VSP_CHARTS_ENGINE_V3 || window.VSP_CHARTS_ENGINE_V2 || window.VSP_CHARTS_ENGINE || null;
    }

    function tryInit(){
      var eng = pickEngine();
      var d = window.__VSP_DASH_LAST_DATA_V3 || window.__VSP_DASH_LAST_DATA || window.__VSP_DASH_LAST_DATA_ANY || null;
      if (!eng || !eng.initAll || !d) return false;
      try{
        eng.initAll(d);
        return true;
      } catch(e){
        return false;
      }
    }

    window.addEventListener('vsp:charts-ready', function(){
      // chỉ init khi đã có data (dashboard fetch xong)
      tryInit();
    });

    // nếu engine đã có sẵn thì thử init luôn (không warn)
    tryInit();
  } catch(e){}
})();



// === VSP_UI_KPI_DRILLDOWN_V1 ===
(function(){
  const KEY = "vsp_ds_drill_url_v1";

  async function loadDashLatest(){
    try{
      const r = await fetch("/api/vsp/dashboard_latest_v1", {credentials:"same-origin"});
      const j = await r.json();
      window.__VSP_DASH_LATEST_V1 = j;
      return j;
    } catch(e){
      console.warn("[KPI_DRILLDOWN] loadDashLatest failed", e);
      return null;
    }
  }

  function _setDrillUrl(url){
    try{ sessionStorage.setItem(KEY, url); } catch(e){}
  }

  function openDrill(url){
    if(!url) return;
    _setDrillUrl(url);

    // best-effort: switch tab by hash
    try{
      if(!String(location.hash||"").toLowerCase().includes("datasource")){
        location.hash = "#datasource";
        // kick router if it listens
        setTimeout(()=>{ try{ window.dispatchEvent(new Event("hashchange")); } catch(e){} }, 50);
      }
    } catch(e){}

    // if Data Source JS installed hook -> use it
    if(typeof window.VSP_DS_APPLY_DRILL_URL_V1 === "function"){
      try{ window.VSP_DS_APPLY_DRILL_URL_V1(url); return; } catch(e){}
    }

    // fallback: open API in new tab (always works)
    try{ window.open(url, "_blank"); } catch(e){}
  }

  function bindClicks(dash){
    if(!dash || !dash.links) return;

    const sevLinks = (dash.links.severity || {});
    const allUrl   = dash.links.all;

    const nodes = Array.from(document.querySelectorAll("a,button,div,section,article,span"))
      .filter(el=>{
        const txt = (el.innerText||"").trim();
        return txt && txt.length > 0 && txt.length < 160;
      });

    function attachByKeyword(keywordUpper, url, title){
      if(!url) return;
      for(const el of nodes){
        const txt = (el.innerText||"").toUpperCase();
        if(!txt.includes(keywordUpper)) continue;
        if(el.__vsp_drill_attached) continue;
        el.__vsp_drill_attached = true;
        el.style.cursor = "pointer";
        el.title = title;
        el.addEventListener("click", (ev)=>{
          // allow user open normally with ctrl/cmd
          if(ev && (ev.ctrlKey || ev.metaKey || ev.shiftKey)) return;
          try{ ev.preventDefault(); } catch(e){}
          openDrill(url);
        });
      }
    }

    // severity KPI cards (by keyword)
    ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"].forEach(sev=>{
      attachByKeyword(sev, sevLinks[sev], `Drilldown → ${sev}`);
    });

    // total findings KPI (heuristic)
    if(allUrl){
      for(const el of nodes){
        const txt = (el.innerText||"").toUpperCase();
        const hit = (txt.includes("TOTAL") && (txt.includes("FIND") || txt.includes("FINDINGS"))) || txt.includes("TOTAL FINDINGS");
        if(!hit) continue;
        if(el.__vsp_drill_total) continue;
        el.__vsp_drill_total = true;
        el.style.cursor = "pointer";
        el.title = "Drilldown → ALL findings";
        el.addEventListener("click", (ev)=>{
          if(ev && (ev.ctrlKey || ev.metaKey || ev.shiftKey)) return;
          try{ ev.preventDefault(); } catch(e){}
          openDrill(allUrl);
        });
      }
    }

    // expose helper for manual use
    window.VSP_DASH_OPEN_DRILL_V1 = openDrill;
    console.log("[KPI_DRILLDOWN] bound", {rid: dash.rid, hasLinks: !!dash.links});
  }

  window.addEventListener("load", async ()=>{
    const dash = await loadDashLatest();
    // wait a bit so DOM cards exist
    setTimeout(()=>bindClicks(dash), 600);
  });
})();



// === VSP_UI_DRILL_PANEL_V1 ===
(function(){
  const KEY = "vsp_ds_drill_url_v1";

  function setDrillUrl(url){
    try{ sessionStorage.setItem(KEY, url); } catch(e){}
  }
  function gotoDatasource(){
    const h = String(location.hash||"");
    if(h.startsWith("#vsp4-")) location.hash = "#vsp4-datasource";
    else location.hash = "#datasource";
    try{ window.dispatchEvent(new Event("hashchange")); } catch(e){}
  }
  async function dashLatest(){
    const r = await fetch("/api/vsp/dashboard_latest_v1", {credentials:"same-origin"});
    return await r.json();
  }

  function ensurePanel(d){
    const id="vsp_drill_panel_v1";
    if(document.getElementById(id)) return;

    const wrap=document.createElement("div");
    wrap.id=id;
    wrap.style.position="fixed";
    wrap.style.right="18px";
    wrap.style.bottom="18px";
    wrap.style.zIndex="9999";
    wrap.style.padding="10px";
    wrap.style.borderRadius="14px";
    wrap.style.border="1px solid rgba(255,255,255,.10)";
    wrap.style.background="rgba(2,6,23,.78)";
    wrap.style.backdropFilter="blur(10px)";
    wrap.style.boxShadow="0 10px 30px rgba(0,0,0,.35)";
    wrap.style.fontSize="12px";
    wrap.style.color="rgba(255,255,255,.85)";
    wrap.innerHTML = `
      <div style="font-weight:700;margin-bottom:6px;">Drilldown</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button id="vsp_drill_total" style="padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:#fff;cursor:pointer;">TOTAL</button>
        <button id="vsp_drill_critical" style="padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:#fff;cursor:pointer;">CRITICAL</button>
        <button id="vsp_drill_high" style="padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:#fff;cursor:pointer;">HIGH</button>
      </div>
      <div style="opacity:.65;margin-top:6px;">(opens Data Source)</div>
    `;
    document.body.appendChild(wrap);

    const links = (d && d.links) ? d.links : {};
    const sev = (links.severity)||{};
    function bind(btnId, url){
      const b=document.getElementById(btnId);
      if(!b) return;
      b.onclick = ()=>{
        if(!url){ console.warn("[DRILL] missing url for", btnId); return; }
        setDrillUrl(url);
        gotoDatasource();
        if(typeof window.VSP_DS_APPLY_DRILL_URL_V1==="function"){
          try{ window.VSP_DS_APPLY_DRILL_URL_V1(url); } catch(e){}
        }
        console.log("[DRILL] open", url);
      };
    }
    bind("vsp_drill_total", links.all);
    bind("vsp_drill_critical", sev.CRITICAL);
    bind("vsp_drill_high", sev.HIGH);
  }

  window.addEventListener("load", async ()=>{
    try{
      const d = await dashLatest();
      window.__VSP_DASH_LATEST_V1 = d;
      ensurePanel(d);
    } catch(e){
      console.warn("[DRILL_PANEL] failed", e);
    }
  });
})();

// === VSP_P2_DRILL_ROUTER_V1 ===
// Drill router: click elements with data-drill -> switch tab datasource + apply filters
(function(){
  function parseHashParams(){
    let h = (location.hash || "").replace(/^#\/?/,"");
    if (!h) return {};
    const out = {};
    for (const part of h.split("&")){
      if (!part) continue;
      const [k,v] = part.split("=",2);
      if (!k) continue;
      out[decodeURIComponent(k)] = decodeURIComponent(v||"");
    }
    return out;
  }

  function buildHash(tab, filters){
    const sp = new URLSearchParams();
    sp.set("tab", tab || "datasource");
    for (const [k,v] of Object.entries(filters||{})){
      if (v === undefined || v === null) continue;
      const sv = String(v).trim();
      if (!sv) continue;
      sp.set(k, sv);
    }
    return "#" + sp.toString();
  }

  function switchToDatasourceTab(){
    // Try click datasource tab button if exists
    const btn = document.querySelector("#tab-datasource, [data-tab-btn='datasource'], a[href*='datasource']");
    if (btn && btn.click) btn.click();
  }

  function applyDatasource(filters){
    // Set hash first (so reload preserves)
    const h = buildHash("datasource", filters||{});
    if (location.hash !== h) location.hash = h;

    // then call sink if available
    const sink = window.VSP_DATASOURCE_APPLY_FILTERS_V1;
    if (typeof sink === "function"){
      try{ sink(filters||{}, {noHashSync:true}); } catch(e){}
    }
  }

  function handleDrillClick(e){
    const a = e.target.closest("[data-drill]");
    if (!a) return;
    e.preventDefault();
    let val = a.getAttribute("data-drill") || "";
    // accept JSON {"sev":"HIGH"} or query "sev=HIGH&tool=semgrep"
    let filters = {};
    try{
      if (val.trim().startsWith("{")) filters = JSON.parse(val);
      else{
        const sp = new URLSearchParams(val.replace(/^#\/?/,""));
        sp.forEach((v,k)=>{ filters[k]=v; });
      }
    } catch(_){
      filters = {};
    }
    switchToDatasourceTab();
    applyDatasource(filters);
  }

  function onHashChange(){
    const hp = parseHashParams();
    if ((hp.tab||"") !== "datasource") return;
    const f = Object.assign({}, hp);
    delete f.tab;
    const sink = window.VSP_DATASOURCE_APPLY_FILTERS_V1;
    if (typeof sink === "function"){
      sink(f, {noHashSync:true});
    }
  }

  function bind(){
    // delegate click drill
    if (!document.body._vspDrillBound){
      document.body._vspDrillBound = true;
      document.body.addEventListener("click", handleDrillClick);
    }
    window.addEventListener("hashchange", onHashChange);
    // initial
    onHashChange();
  }

  if (document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", bind);
  }else{
    bind();
  }
})();

// === VSP_P2_AUTOBIND_KPI_DRILL_V1 ===
// Auto bind drilldown for KPI cards (clickable commercial)
// - Uses dashboard_latest_v1.links if present
// - Fallback binds severity labels CRITICAL/HIGH/MEDIUM/LOW/INFO/TRACE
(function(){
  const SEVS = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];

  function qs(sel, root){ return (root||document).querySelector(sel); }
  function qsa(sel, root){ return Array.from((root||document).querySelectorAll(sel)); }

  function norm(s){ return String(s||"").trim().toUpperCase(); }

  function parseDrillToQuery(drill){
    // drill may be absolute/relative url to datasource, or a query-like string
    if (!drill) return "";
    let s = String(drill).trim();
    // if full URL, take hash or query
    try{
      if (s.startsWith("http")){
        const u = new URL(s);
        if (u.hash && u.hash.length > 1) return u.hash.replace(/^#\/?/,"");
        if (u.search && u.search.length > 1) return u.search.replace(/^\?/,"");
      }
    } catch(_){}
    // if starts with #...
    s = s.replace(/^#\/?/,"");
    // remove leading vsp4 path fragments
    s = s.replace(/^\/?vsp4\??/,"").replace(/^\?/,"");
    return s;
  }

  async function fetchDash(){
    const r = await fetch("/api/vsp/dashboard_latest_v1", {cache:"no-store"});
    return await r.json();
  }

  function bindEl(el, query){
    if (!el || !query) return;
    // do not double bind
    if (el.getAttribute("data-drill")) return;
    el.setAttribute("data-drill", query);
    el.style.cursor = "pointer";
    el.title = el.title || "Click to drilldown";
  }

  function findKpiCandidates(){
    // broad selectors; harmless if none
    const sels = [
      ".vsp-kpi-card", ".kpi-card", ".kpi", ".vsp-card",
      "[data-kpi]", "[data-kpi-card]", "[data-role='kpi']"
    ];
    const out = [];
    for (const s of sels){
      qsa(s).forEach(x=>out.push(x));
    }
    // fallback: any card-like divs in dashboard area
    const dash = qs("#vsp-dashboard-main") || qs("#tab-dashboard") || document.body;
    qsa("div", dash).forEach(d=>{
      const txt = norm(d.innerText||"");
      if (SEVS.some(s=>txt.includes(s)) && (d.offsetWidth>80 && d.offsetHeight>40)){
        out.push(d);
      }
    });
    // unique
    return Array.from(new Set(out));
  }

  function bestEffortBindFromLinks(links){
    // expected shapes:
    // links: { severity: {HIGH:"tab=datasource&sev=HIGH"...}, all:"...", suppressed:"..." }
    if (!links || typeof links !== "object") return false;
    const kpis = findKpiCandidates();
    let bound = 0;

    // bind severity-based
    for (const sev of SEVS){
      const drill = links?.severity?.[sev] || links?.["severity."+sev] || links?.[sev] || null;
      if (!drill) continue;
      const q = parseDrillToQuery(drill);
      if (!q) continue;
      for (const el of kpis){
        const txt = norm(el.innerText||"");
        if (txt.includes(sev)){
          bindEl(el, q);
          bound++;
        }
      }
    }

    // bind "all" if present
    if (links.all){
      const q = parseDrillToQuery(links.all);
      if (q){
        for (const el of kpis){
          const txt = norm(el.innerText||"");
          if (txt.includes("TOTAL") || txt.includes("ALL") || txt.includes("FINDINGS")){
            bindEl(el, q);
            bound++;
          }
        }
      }
    }
    return bound > 0;
  }

  function fallbackBindSev(){
    const kpis = findKpiCandidates();
    let bound = 0;
    for (const sev of SEVS){
      const q = "tab=datasource&sev=" + encodeURIComponent(sev) + "&limit=200";
      for (const el of kpis){
        const txt = norm(el.innerText||"");
        if (txt.includes(sev)){
          bindEl(el, q);
          bound++;
        }
      }
    }
    return bound>0;
  }

  async function init(){
    try{
      const j = await fetchDash();
      const links = j?.links || j?.drilldown || j?.drill || null;
      const ok = bestEffortBindFromLinks(links);
      if (!ok) fallbackBindSev();
    } catch(e){
      fallbackBindSev();
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();



// === VSP_P2_FORCE_8TOOLS_V1 ===
// Force Gate Summary to show 8 tools (commercial). Missing tool => NOT_RUN/0.
// Also capture latest /api/vsp/run_status_v2 JSON via fetch clone.
(function(){
  try{
    if (window.__VSP_P2_FORCE_8TOOLS_V1_INSTALLED) return;
    window.__VSP_P2_FORCE_8TOOLS_V1_INSTALLED = true;

    const TOOL_ORDER = ["BANDIT","CODEQL","GITLEAKS","GRYPE","KICS","SEMGREP","SYFT","TRIVY"];
    window.__VSP_TOOL_ORDER = TOOL_ORDER;

    const origFetch = window.fetch;
    window.fetch = async function(){
      const resp = await origFetch.apply(this, arguments);
      try{
        const u = (typeof arguments[0] === "string") ? arguments[0] : (arguments[0] && arguments[0].url) || "";
        if (u.includes("/api/vsp/run_status_v2")) {
          resp.clone().json().then(j => {
            window.__VSP_LAST_STATUS_V2 = j;
            try { window.__VSP_RENDER_GATE_8TOOLS(); } catch(e){}
          }).catch(()=>{});
        }
      } catch(e){}
      return resp;
    };

    function pickToolObj(st, T){
      if (!st || typeof st !== "object") return null;
      const k = T.toLowerCase();
      return st[k + "_summary"] || st[k] || (st.tools && (st.tools[T] || st.tools[k])) || null;
    }

    function normVerdict(v){
      v = String(v || "").toUpperCase();
      if (!v) return "NOT_RUN";
      return v;
    }

    window.__VSP_RENDER_GATE_8TOOLS = function(){
      const st = window.__VSP_LAST_STATUS_V2;
      // find a plausible gate summary container
      const box =
        document.querySelector("#vsp-gate-summary") ||
        document.querySelector("#gate-summary") ||
        document.querySelector("[data-vsp-gate-summary]") ||
        document.querySelector(".vsp-gate-summary") ||
        document.querySelector("section#vsp-pane-dashboard .vsp-card .vsp-gate") ||
        null;
      if (!box) return;

      // create or find list container
      let list = box.querySelector(".vsp-gate-list");
      if (!list) {
        list = document.createElement("div");
        list.className = "vsp-gate-list";
        box.appendChild(list);
      }

      const rows = TOOL_ORDER.map(T => {
        const o = pickToolObj(st, T) || {};
        const verdict = normVerdict(o.verdict || o.status || o.result || (st && st[(T.toLowerCase()) + "_verdict"]) || "");
        const total = (o.total != null) ? Number(o.total) : Number((st && st[(T.toLowerCase()) + "_total"]) || 0) || 0;
        const pillCls = "vsp-pill vsp-pill-" + verdict.toLowerCase();

        return `
          <div class="vsp-gate-row" style="display:flex;align-items:center;justify-content:space-between;padding:6px 0;border-top:1px solid rgba(255,255,255,.06)">
            <div style="font-weight:650;letter-spacing:.2px">${T}</div>
            <div style="display:flex;gap:10px;align-items:center">
              <span class="${pillCls}">${verdict}</span>
              <span style="opacity:.75">total: ${total}</span>
            </div>
          </div>`;
      }).join("");

      list.innerHTML = rows;
    };

    // attempt render once later (in case status fetched before patch)
    setTimeout(()=>{ try{ window.__VSP_RENDER_GATE_8TOOLS(); } catch(e){} }, 1200);
  } catch(e){}
})();
 // === /VSP_P2_FORCE_8TOOLS_V1 ===




// === VSP_UI_DRILLDOWN_AND_EXPORTPROBE_V1 ===
(function(){
  'use strict';

  
  
  
  
  
  
  


/* VSP_DRILLDOWN_ARTIFACTS_NORMALIZE_P0_V1
 * Fix: Uncaught TypeError: __VSP_DD_ART_CALL__(VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2, ...) is not a function
 * Normalize window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2:
 *  - if function: keep
 *  - if object with .open(): wrap to function
 *  - if missing: provide no-op function (never throw)
 */
(function(){
  'use strict';
  if (window.__VSP_DRILLDOWN_ARTIFACTS_NORMALIZE_P0_V1) return;
  window.__VSP_DRILLDOWN_ARTIFACTS_NORMALIZE_P0_V1 = 1;

  function normalize(v){
    if (typeof v === 'function') return v;
    if (v && typeof v.open === 'function'){
      const obj = v;
      const fn = function(arg){
        try { return obj.open(arg); } catch(_e){ return null; }
      };
      fn.__wrapped_from_object = true;
      return fn;
    }
    // missing/unknown => no-op (never throw)
    const noop = function(_arg){ return null; };
    noop.__noop = true;
    return noop;
  }

  try{
    // Use defineProperty to normalize future assignments too (robust).
    let _val = window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
    Object.defineProperty(window, 'VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2', {
      configurable: true,
      enumerable: true,
      get: function(){ return _val; },
      set: function(v){ _val = normalize(v); }
    });
    // trigger normalization on current value
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = _val;
  } catch(_e){
    // fallback if defineProperty is blocked
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = normalize(window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2);
  }
})();

/* P0_DRILLDOWN_LOCAL_V4 */
  // P0: force local symbol to be FUNCTION (prevents "is not a function" even with shadowing)
  try{
    var __vsp_stub = function(){
      try{ console.info("[VSP_DASH][P0] drilldown stub called"); } catch(_){}
      return { open:function(){}, show:function(){}, close:function(){}, destroy:function(){} };
    };

    // local symbol (works even if calls are bare identifier)
    if (typeof VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
      var VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = __vsp_stub; // var is function-scoped in IIFE
      try{ console.info("[VSP_DASH][P0] drilldown local stub armed"); } catch(_){}
    }

    // window symbol too (for other modules)
    if (typeof window !== "undefined" && typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2;
      try{ console.info("[VSP_DASH][P0] drilldown window stub armed"); } catch(_){}
    }
  } catch(_){}

  // P0 FIX (final2): ensure drilldown helper exists on window (function)
  try{
    if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
        try{ 
console.warn("[VSP_DASH] drilldown forced stub (window)");   // P0_DRILLDOWN_STUB: guarantee callable function
  if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
      try{ console.warn("[VSP_DASH][P0] drilldown stub used (no-op)"); } catch(_){}
      return { open:function(){}, show:function(){}, destroy:function(){} };
    };
  }
} catch(_){}
        return false;
      };
    }
  } catch(_){}
// P0 FIX (final): drilldown dispatcher (avoid shadowed non-function symbols)
  function __vsp_call_drilldown_artifacts(){
    try{
      const fn = (window && typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 === "function")
        ? window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2
        : function(){ try{ console.warn("[VSP_DASH] drilldown skipped (no function on window)"); } catch(_){ } return false; };
      return fn.apply(null, arguments);
    } catch(_){
      try{ console.warn("[VSP_DASH] drilldown dispatcher failed -> skipped"); } catch(__){}
      return false;
    }
  }
// P0 FIX (final): force drilldown helper onto window and call window.* to avoid shadowed const/object
  try{
    if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
        try{ console.warn("[VSP_DASH] drilldown forced stub (window)"); } catch(_){}
        return false;
      };
    }
  } catch(_){}
// P0 FIX (hard): ALL drilldown helpers must never crash dashboard
  function __vsp_stub_drill(name){
    try{
      const fn = function(){
        try{ console.warn("[VSP_DASH] drilldown helper forced stub:", name); } catch(_){}
        return false;
      };
      // local symbol if exists
      try{
        if (typeof eval(name) !== "function") { /* ignore */ }
      } catch(_){}
      // window symbol
      try{
        if (typeof window[name] !== "function") window[name] = fn;
      } catch(_){}
    } catch(_){}
  }
  try{
    __vsp_stub_drill("VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2");
    __vsp_stub_drill("VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2");
  } catch(_){}
// P0 FIX (hard): drilldown must never crash dashboard
  try{
    // local symbol (if exists / if not declared -> catch)
    if (typeof VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
        try{ console.warn("[VSP_DASH] drilldown helper not a function -> forced stub"); } catch(_){}
        return false;
      };
    }
  } catch(_){}
  try{
    if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== "function") {
      window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
        try{ console.warn("[VSP_DASH] drilldown helper missing -> forced stub"); } catch(_){}
        return false;
      };
    }
  } catch(_){}
// P0 FIX: avoid ReferenceError if drilldown artifacts helper is missing
  if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== 'function') {
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
      try{ console.warn("[VSP_DASH] drilldown helper missing -> skipped"); } catch(_){}
      return false;
    };
  }
// P0 FIX: avoid ReferenceError if drilldown artifacts helper is missing
  if (typeof window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 !== 'function') {
    window.VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2 = function(){
      try{ console.warn("[VSP_DASH] drilldown helper missing -> skipped"); } catch(_){}
      return false;
    };
  }
// === VSP_DASH_KPI_FROM_EXTRAS_P1_V4 ===
  (function(){
    if(window.__VSP_DASH_KPI_FROM_EXTRAS_P1_V4) return;
    window.__VSP_DASH_KPI_FROM_EXTRAS_P1_V4 = 1;

    function normRid(x){
      try{
        x = String(x || "").trim();
        x = x.replace(/^RUN[_\-\s]+/i, "");
        x = x.replace(/^RID[:\s]+/i, "");
        const m = x.match(/(VSP_CI_\d{8}_\d{6})/i);
        if(m && m[1]) return m[1];
        return x.replace(/\s+/g, "_");
      } catch(_){ return ""; }
    }

    function getRidBestEffort(){
      // 1) global state (if any)
      try{
        const st = window.__VSP_RID_STATE__ || window.__VSP_RID_STATE || window.VSP_RID_STATE || window.__vsp_rid_state;
        if(st){
          if(st.rid || st.run_id) return normRid(st.rid || st.run_id);
          if(st.state && (st.state.rid || st.state.run_id)) return normRid(st.state.rid || st.state.run_id);
          if(typeof st.get === "function"){
            const v = st.get();
            if(v && (v.rid || v.run_id)) return normRid(v.rid || v.run_id);
          }
        }
      } catch(_){}

      // 2) header text contains "RID:"
      try{
        const body = document.body ? (document.body.innerText || "") : "";
        const m = body.match(/RID:\s*(VSP_CI_\d{8}_\d{6})/i);
        if(m && m[1]) return normRid(m[1]);
      } catch(_){}

      return "";
    }

    function setText(id, v){
      const el = document.getElementById(id);
      if(!el) return false;
      el.textContent = (v===0) ? "0" : (v ? String(v) : "—");
      return true;
    }

    function fmtBySev(bySev){
      if(!bySev) return "";
      const order = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];
      const out = [];
      for(const k of order){
        if(bySev[k] !== undefined) out.push(k + ":" + bySev[k]);
      }
      return out.join(" ");
    }

    function pickTool(byTool, want){
      if(!byTool) return null;
      if(byTool[want] !== undefined) return byTool[want];
      const key = Object.keys(byTool).find(k => String(k||"").toUpperCase() === want.toUpperCase());
      return key ? byTool[key] : null;
    }

    function applyExtras(rid, kpi){
      if(!kpi) return;
      const total = kpi.total ?? 0;
      const eff = kpi.effective ?? 0;
      const degr = kpi.degraded ?? 0;
      const unk = kpi.unknown_count ?? 0;
      const score = (kpi.score === undefined || kpi.score === null) ? "" : kpi.score;

      const status = (degr > 0) ? "DEGRADED" : (total > 0 ? "OK" : "EMPTY");

      // commercial 4tabs KPI ids (exist in template)
      setText("kpi-overall", score !== "" ? (score + "/100") : status);
      setText("kpi-overall-sub", `total ${total} | eff ${eff} | degr ${degr} | unk ${unk}`);

      setText("kpi-gate", status);
      setText("kpi-gate-sub", fmtBySev(kpi.by_sev));

      const gtl = pickTool(kpi.by_tool, "GITLEAKS");
      setText("kpi-gitleaks", (gtl === null) ? "NOT_RUN" : gtl);
      setText("kpi-gitleaks-sub", "GITLEAKS");

      const cql = pickTool(kpi.by_tool, "CODEQL");
      setText("kpi-codeql", (cql === null) ? "NOT_RUN" : cql);
      setText("kpi-codeql-sub", "CODEQL");

      // if dashboard_2025 ids exist, also fill
      setText("kpi-total", total);
      setText("kpi-effective", eff);
      setText("kpi-degraded", degr);
      setText("kpi-score", score);
    }

    function fetchExtras(rid){
      const u = "/api/vsp/dashboard_v3_extras_v1?rid=" + encodeURIComponent(rid || "");
      return fetch(u, {cache:"no-store"})
        .then(r => r.ok ? r.json() : null)
        .then(j => (j && j.ok && j.kpi) ? j.kpi : null)
        .catch(_ => null);
    }

    let lastRid = "";
    function hydrate(force){
      const rid = getRidBestEffort();
      if(!rid) return;
      if(!force && rid === lastRid) return;
      lastRid = rid;
      fetchExtras(rid).then(kpi => { if(kpi) applyExtras(rid, kpi); });
    }

    // run on navigation + periodic
    window.addEventListener("hashchange", () => setTimeout(() => hydrate(true), 120));
    setTimeout(() => hydrate(true), 300);
    setInterval(() => hydrate(false), 1500);
    setInterval(() => hydrate(true), 15000);
  })();
  // === /VSP_DASH_KPI_FROM_EXTRAS_P1_V4 ===


  // === VSP_DASHBOARD_KPI_WIRE_EXTRAS_P1_V2 ===
  (function(){
    if(window.__VSP_KPI_EXTRAS_WIRED_P1_V2) return;
    window.__VSP_KPI_EXTRAS_WIRED_P1_V2 = 1;

    function _ridFromState(){
      try{
        const candidates = [
          window.__vsp_rid_state,
          window.VSP_RID_STATE,
          window.VSP_RID_STATE_V1,
          window.__VSP_RID_STATE
        ].filter(Boolean);

        for(const st of candidates){
          if(typeof st.get === "function"){
            const r = st.get();
            if(r && (r.rid || r.run_id)) return (r.rid || r.run_id);
          }
          if(st && (st.rid || st.run_id)) return (st.rid || st.run_id);
          if(st && st.state && (st.state.rid || st.state.run_id)) return (st.state.rid || st.state.run_id);
        }
      } catch(_){}
      return "";
    }

    function getRidBestEffort(){
      const r0 = _ridFromState();
      if(r0) return String(r0).trim();

      // try DOM (some headers render RID: XXX)
      try{
        const body = document.body ? (document.body.innerText || "") : "";
        const m = body.match(/RID:\s*(VSP_[A-Z0-9_]+)/);
        if(m && m[1]) return m[1];
      } catch(_){}
      return "";
    }

    function setText(id, val){
      const el = document.getElementById(id);
      if(!el) return;
      el.textContent = (val===undefined || val===null || val==="") ? "—" : String(val);
    }

    function setSub(id, val){
      const el = document.getElementById(id);
      if(!el) return;
      el.textContent = (val===undefined || val===null) ? "" : String(val);
    }

    function fmtSev(bySev){
      if(!bySev) return "";
      const order = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];
      const parts = [];
      for(const k of order){
        if(bySev[k]!==undefined && bySev[k]!==null) parts.push(k+":"+bySev[k]);
      }
      return parts.join(" ");
    }

    function pickTool(byTool, want){
      if(!byTool) return null;
      if(byTool[want]!==undefined) return byTool[want];
      try{
        const key = Object.keys(byTool).find(k => String(k||"").toUpperCase() === String(want).toUpperCase());
        if(key) return byTool[key];
      } catch(_){}
      return null;
    }

    function applyExtras(rid, kpi){
      if(!kpi) return;

      const total = kpi.total || 0;
      const eff = kpi.effective || 0;
      const degr = kpi.degraded || 0;
      const unk  = (kpi.unknown_count===undefined || kpi.unknown_count===null) ? "" : kpi.unknown_count;
      const score = (kpi.score===undefined || kpi.score===null) ? "" : kpi.score;

      const status = (degr>0) ? "DEGRADED" : (total>0 ? "OK" : "EMPTY");

      // These KPI ids are used by vsp_5tabs_enterprise_v2.html (commercial panel)
      setText("kpi-overall", score!=="" ? (score + "/100") : status);
      setSub ("kpi-overall-sub", "total " + total + " | eff " + eff + " | degr " + degr + (unk!=="" ? (" | unk "+unk) : ""));

      setText("kpi-gate", status);
      setSub ("kpi-gate-sub", fmtSev(kpi.by_sev));

      const gtl = pickTool(kpi.by_tool, "GITLEAKS");
      setText("kpi-gitleaks", (gtl===null || gtl===undefined) ? "NOT_RUN" : gtl);
      setSub ("kpi-gitleaks-sub", (gtl===null || gtl===undefined) ? "tool=GITLEAKS missing" : ("tool=GITLEAKS | rid=" + rid));

      const cql = pickTool(kpi.by_tool, "CODEQL");
      setText("kpi-codeql", (cql===null || cql===undefined) ? "NOT_RUN" : cql);
      setSub ("kpi-codeql-sub", (cql===null || cql===undefined) ? "tool=CODEQL missing" : ("tool=CODEQL | rid=" + rid));
    }

    function fetchExtras(rid){
      const u = "/api/vsp/dashboard_v3_extras_v1?rid=" + encodeURIComponent(rid||"");
      return fetch(u, {cache:"no-store"})
        .then(r => r.ok ? r.json() : null)
        .then(j => (j && j.ok && j.kpi) ? j.kpi : null)
        .catch(_ => null);
    }

    let lastRid = "";
    function tick(force){
      const rid = getRidBestEffort();
      if(!rid) return;
      if(!force && rid === lastRid) return;
      lastRid = rid;

      fetchExtras(rid).then(kpi => {
        if(kpi) applyExtras(rid, kpi);
      });
    }

    window.addEventListener("hashchange", function(){ setTimeout(function(){ tick(true); }, 150); });
    document.addEventListener("visibilitychange", function(){ if(!document.hidden) setTimeout(function(){ tick(true); }, 150); });

    // first paint + periodic refresh
    setTimeout(function(){ tick(true); }, 300);
    setInterval(function(){ tick(false); }, 1500);
    setInterval(function(){ tick(true); }, 15000);
  })();


  // === VSP_DASHBOARD_USE_EXTRAS_P1_V2 ===
  function fetchDashboardExtras(rid){
    const u = `/api/vsp/dashboard_v3_extras_v1?rid=${encodeURIComponent(rid||"")}`;
    return fetch(u, {cache:"no-store"})
      .then(r => r.ok ? r.json() : null)
      .then(j => (j && j.ok && j.kpi) ? j.kpi : null)
      .catch(_ => null);
  }

  function setTextSafe(id, val){
    try{
      const el = document.getElementById(id);
      if(!el) return false;
      el.textContent = (val===null || val===undefined) ? "N/A" : String(val);
      return true;
    } catch(_){ return false; }
  }

  function applyKpiExtrasToDom(kpi){
    if(!kpi) return;
    // try common ids (non-breaking if missing)
    setTextSafe("kpi-total", kpi.total);
    setTextSafe("kpi-score", kpi.score);
    setTextSafe("kpi-effective", kpi.effective);
    setTextSafe("kpi-degraded", kpi.degraded);

    // also try a few other likely ids used in your UI patches
    setTextSafe("kpi-total-findings", kpi.total);
    setTextSafe("kpi-effective-findings", kpi.effective);
    setTextSafe("kpi-degraded-findings", kpi.degraded);
  }
  // === /VSP_DASHBOARD_USE_EXTRAS_P1_V2 ===


  // --- tiny utils ---
  const LOG_ONCE = new Set();
  function logOnce(k, ...a){ if(LOG_ONCE.has(k)) return; LOG_ONCE.add(k); console.log(...a); }
  function nowMs(){ try { return Date.now(); } catch(_){ return 0; } }

  function ridFromPage(){
    // best-effort: try globals, DOM attrs, URL params
    try {
      if (window.VSP_RID) return String(window.VSP_RID);
      if (window.__VSP_RID__) return String(window.__VSP_RID__);
    } catch(_){}
    try {
      const u = new URL(location.href);
      const rid = u.searchParams.get("rid") || u.searchParams.get("run_id") || u.searchParams.get("id");
    fetchDashboardExtras(rid).then(applyKpiExtrasToDom);
      if (rid) return String(rid);
    } catch(_){}
    try {
      const el = document.querySelector("[data-rid],[data-run-id],[data-runid]");
      const v = el && (el.getAttribute("data-rid") || el.getAttribute("data-run-id") || el.getAttribute("data-runid"));
      if (v) return String(v);
    } catch(_){}
    return null;
  }

  function openTab(tabId){
    // expects your 4-tabs router to exist; best-effort click
    try {
      // common patterns: button#tab-datasource / a[href='#datasource']
      const btn = document.querySelector("#tab-" + tabId + ", [data-tab='"+tabId+"'], a[href='#"+tabId+"']");
      if (btn) { btn.click(); return true; }
    } catch(_){}
    // fallback: try call existing router func if you have one
    try {
      if (typeof window.VSP_SWITCH_TAB === "function") { window.VSP_SWITCH_TAB(tabId); return true; }
      if (typeof window.vspSwitchTab === "function") { window.vspSwitchTab(tabId); return true; }
    } catch(_){}
    return false;
  }

  // --- datasource filter bus (localStorage + CustomEvent) ---
  const LS_KEY = "vsp_ds_filters_v1";

  function pushDatasourceFilters(filters, opts){
    opts = opts || {};
    const payload = {
      v: 1,
      ts: nowMs(),
      rid: opts.rid || ridFromPage(),
      filters: filters || {}
    };
    try { localStorage.setItem(LS_KEY, JSON.stringify(payload)); } catch(_){}
    try {
      window.dispatchEvent(new CustomEvent("vsp:datasource:setFilters", { detail: payload }));
    } catch(_){}
  }

  // public API for drilldown
  window.VSP_DRILL_TO_DATASOURCE = function(filters, opts){
    try {
      pushDatasourceFilters(filters || {}, opts || {});
      openTab("datasource");
    } catch(e) {
      console.warn("[VSP][DRILL] failed", e);
    }
  };

  // --- export probe: make it quiet + stop after first success ---
  async function probeExportOnce(url){
    // HEAD is often blocked/noisy in browser setups; fallback to GET safely.
    try {
      const r = await fetch(url, { method: "HEAD", cache: "no-store", credentials: "same-origin" });
      if (r && r.ok) return { ok:true, via:"HEAD", status:r.status, headers:r.headers };
    } catch(_){}
    try {
      const r = await fetch(url + (url.includes("?") ? "&" : "?") + "_probe=1", { method: "GET", cache: "no-store", credentials: "same-origin" });
      if (r && r.ok) return { ok:true, via:"GET", status:r.status, headers:r.headers };
      return { ok:false, via:"GET", status: (r && r.status) || 0, headers: r && r.headers };
    } catch(e){
      return { ok:false, via:"ERR", status:0, err:String(e) };
    }
  }

  async function commercialExportProbeQuiet(){
    // only run on pages that show export controls
    const rid = ridFromPage();
    if (!rid) return;

    // build canonical export URL once (commercial behavior)
    const base = (window.VSP_RUN_EXPORT_BASE || "/api/vsp/run_export_v3").replace(/\/+$/,"");
    const pdfUrl = base + "/" + encodeURIComponent(rid) + "?fmt=pdf";

    const key = "export-probe-" + rid;
    if (window.__VSP_EXPORT_PROBED__ && window.__VSP_EXPORT_PROBED__[rid]) return;
    window.__VSP_EXPORT_PROBED__ = window.__VSP_EXPORT_PROBED__ || {};
    window.__VSP_EXPORT_PROBED__[rid] = true;

    const res = await probeExportOnce(pdfUrl);
    // treat failures as non-fatal; do NOT spam console
    if (!res.ok){
      logOnce(key+"-fail", "[VSP][EXPORT][PROBE] pdf probe not OK (non-fatal)", { rid, url: pdfUrl, via: res.via, status: res.status });
      window.VSP_EXPORT_AVAILABLE = window.VSP_EXPORT_AVAILABLE || {};
      window.VSP_EXPORT_AVAILABLE.pdf = 0;
      return;
    }

    // success: set availability and stop further probes
    window.VSP_EXPORT_AVAILABLE = window.VSP_EXPORT_AVAILABLE || {};
    window.VSP_EXPORT_AVAILABLE.pdf = 1;
    logOnce(key+"-ok", "[VSP][EXPORT][PROBE] pdf available", { rid, via: res.via, status: res.status });

    // if you have UI pills/badges, update them quietly
    try {
      const pill = document.querySelector("[data-export='pdf'], #pill-export-pdf, #pill-pdf");
      if (pill) { pill.classList.add("is-ok"); pill.classList.remove("is-bad"); }
    } catch(_){}
  }

  // run once after DOM ready
  function onReady(fn){
    if (document.readyState === "complete" || document.readyState === "interactive") return setTimeout(fn, 0);
    document.addEventListener("DOMContentLoaded", fn, { once: true });
  }

  // --- attach drilldown click helpers (best-effort, non-breaking) ---
  function wireDrilldownClicks(){
    // opt-in attributes (recommended): data-vsp-drill-tool / data-vsp-drill-sev / data-vsp-drill-cwe
    const els = document.querySelectorAll("[data-vsp-drill-tool],[data-vsp-drill-sev],[data-vsp-drill-cwe]");
    els.forEach(el=>{
      if (el.__vsp_drilled__) return;
      el.__vsp_drilled__ = true;
      el.style.cursor = "pointer";
      el.addEventListener("click", ()=>{
        const tool = el.getAttribute("data-vsp-drill-tool");
        const sev  = el.getAttribute("data-vsp-drill-sev");
        const cwe  = el.getAttribute("data-vsp-drill-cwe");
        const filters = {};
        if (tool) filters.tool = tool;
        if (sev)  filters.severity = sev;
        if (cwe)  filters.cwe = cwe;
        window.VSP_DRILL_TO_DATASOURCE(filters);
      });
    });

    // fallback: gate summary pills often include tool/sev text
    const pills = document.querySelectorAll(".vsp-pill,[data-pill]");
    pills.forEach(p=>{
      if (p.__vsp_drilled__) return;
      const t = (p.textContent || "").trim();
      // simple patterns: "GITLEAKS", "SEMGREP", "CRITICAL", "HIGH", "CWE-79"
      // (intentionally empty; handled by wireFallbackPills)
    });
  }

  // NOTE: avoid python-style in JS; keep safe fallback only
  function wireFallbackPills(){
    const pills = document.querySelectorAll(".vsp-pill,[data-pill]");
    pills.forEach(p=>{
      if (p.__vsp_drilled__) return;
      const txt = (p.textContent || "").trim();
      if (!txt) return;

      const up = txt.toUpperCase();
      const filters = {};
      const toolSet = new Set(["GITLEAKS","SEMGREP","TRIVY","CODEQL","KICS","GRYPE","SYFT","BANDIT"]);
      const sevSet  = new Set(["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"]);
      if (toolSet.has(up)) filters.tool = up;
      if (sevSet.has(up))  filters.severity = up;
      if (/^CWE-\d+$/i.test(up)) filters.cwe = up;

      if (Object.keys(filters).length === 0) return;

      p.__vsp_drilled__ = true;
      p.style.cursor = "pointer";
      p.title = "Click to drilldown → Data Source";
      p.addEventListener("click", ()=> window.VSP_DRILL_TO_DATASOURCE(filters));
    });
  }

  onReady(()=>{
    try { commercialExportProbeQuiet(); } catch(e){ /* silent */ }
    try { wireDrilldownClicks(); } catch(e){ /* silent */ }
    try { wireFallbackPills(); } catch(e){ /* silent */ }
  });

})();


/* VSP_DASH_BADGES_P1_V1: Dashboard badges for Degraded tools + Rule Overrides delta (live RID) */
(function(){
  'use strict';

  async function _j(url, timeoutMs=6000){
    const ctrl = new AbortController();
    const t = setTimeout(()=>ctrl.abort(), timeoutMs);
    try{
      const r = await fetch(url, {signal: ctrl.signal, headers:{'Accept':'application/json'}});
      const ct = (r.headers.get('content-type')||'').toLowerCase();
      if(!ct.includes('application/json')) return null;
      return await r.json();
    } catch(e){
      return null;
    }finally{
      clearTimeout(t);
    }
  }

  function _getRidFromLocal(){
    const keys = ["vsp_selected_rid_v2","vsp_selected_rid","vsp_current_rid","VSP_RID","vsp_rid"];
    for(const k of keys){
      try{
        const v = localStorage.getItem(k);
        if(v && v !== "null" && v !== "undefined") return v;
      } catch(e){}
    }
    return null;
  }

  async function _getRid(){
    try{
      if(window.VSP_RID && typeof window.VSP_RID.get === "function"){
        const r = window.VSP_RID.get();
        if(r) return r;
      }
    } catch(e){}
    const l = _getRidFromLocal();
    if(l) return l;

    const x = await _j("/api/vsp/latest_rid_v1");
    if(x && x.ok && x.run_id) return x.run_id;
    return null;
  }

  function _findDashHost(){
    return document.getElementById("vsp4-dashboard")
      || document.querySelector("[data-tab='dashboard']")
      || document.querySelector("#tab-dashboard")
      || document.querySelector(".vsp-dashboard")
      || document.querySelector("main")
      || document.body;
  }

  function _ensureBar(){
    const host = _findDashHost();
    if(!host) return null;

    let bar = document.getElementById("vsp-dash-p1-badges");
    if(bar) return bar;

    bar = document.createElement("div");
    bar.id = "vsp-dash-p1-badges";
    bar.style.cssText = "margin:10px 0 12px 0;padding:10px 12px;border:1px solid rgba(148,163,184,.18);border-radius:14px;background:rgba(2,6,23,.35);display:flex;gap:10px;flex-wrap:wrap;align-items:center;";

    function pill(id, label){
      const a = document.createElement("a");
      a.href="#";
      a.id=id;
      a.style.cssText = "display:inline-flex;gap:8px;align-items:center;padding:7px 10px;border-radius:999px;border:1px solid rgba(148,163,184,.22);text-decoration:none;color:#cbd5e1;font-size:12px;white-space:nowrap;";
      a.innerHTML = `<b style="font-weight:700;color:#e2e8f0">${label}</b><span style="opacity:.9" data-val>loading…</span>`;
      return a;
    }

    bar.appendChild(pill("vsp-pill-degraded","Degraded"));
    bar.appendChild(pill("vsp-pill-overrides","Overrides"));
    bar.appendChild(pill("vsp-pill-rid","RID"));

    host.prepend(bar);
    return bar;
  }

  function _setPill(id, text){
    const a = document.getElementById(id);
    if(!a) return;
    const v = a.querySelector("[data-val]");
    if(v) v.textContent = text;
  }

  function _fmtDegraded(st){
    const arr = (st && st.degraded_tools) ? st.degraded_tools : [];
    if(!arr || !arr.length) return "none";
    const parts = [];
    for(const it of arr.slice(0,4)){
      const tool = it.tool || it.name || "tool";
      const rc = (it.rc !== undefined && it.rc !== null) ? `rc=${it.rc}` : "";
      const v  = it.verdict ? String(it.verdict) : "";
      const why = it.reason || it.error || it.note || "";
      const one = [tool, v, rc].filter(Boolean).join(":") + (why ? ` (${String(why).slice(0,30)})` : "");
      parts.push(one.trim());
    }
    return parts.join(" | ") + (arr.length>4 ? ` (+${arr.length-4})` : "");
  }

  function _fmtOverrides(eff){
    const d = (eff && eff.delta) ? eff.delta : {};
    const matched = d.matched_n ?? 0;
    const applied = d.applied_n ?? 0;
    const sup = d.suppressed_n ?? 0;
    const chg = d.changed_severity_n ?? 0;
    const exp = d.expired_match_n ?? 0;
    return `matched=${matched} applied=${applied} suppressed=${sup} changed=${chg} expired=${exp}`;
  }

  async function refresh(){
    _ensureBar();
    const rid = await _getRid();
    _setPill("vsp-pill-rid", rid || "n/a");
    if(!rid) return;

    const [st, eff] = await Promise.all([
      _j(`/api/vsp/run_status_v2/${encodeURIComponent(rid)}`),
      _j(`/api/vsp/findings_effective_v1/${encodeURIComponent(rid)}?limit=0`)
    ]);

    _setPill("vsp-pill-degraded", _fmtDegraded(st));
    _setPill("vsp-pill-overrides", _fmtOverrides(eff));
  }

  document.addEventListener("click", function(ev){
    const a = ev.target && ev.target.closest && ev.target.closest("#vsp-pill-degraded,#vsp-pill-overrides");
    if(!a) return;
    ev.preventDefault();
    try{
      if(window.VSP_DASH_DRILLDOWN && typeof window.VSP_DASH_DRILLDOWN.open === "function"){
        window.VSP_DASH_DRILLDOWN.open();
      }
    } catch(e){}
  }, true);

  window.addEventListener("vsp:rid_changed", function(){ refresh(); });
  window.addEventListener("hashchange", function(){ setTimeout(refresh, 120); });
  window.addEventListener("load", function(){ setTimeout(refresh, 200); });

  setTimeout(refresh, 250);
})();


/* VSP_DASH_BADGES_P1_V3_FIXEDBAR: ensure badges visible even if dashboard host selector mismatch */
(function(){
  'use strict';

  function _pickHost(){
    // 1) container that holds KPI cards
    const card = document.querySelector(".vsp-card, .dashboard-card, .card");
    if(card && card.parentElement) return card.parentElement;

    // 2) active tab pane (common patterns)
    const active = document.querySelector(".tab-pane.active, .tab-content .active, [role='tabpanel'][aria-hidden='false']");
    if(active) return active;

    // 3) main content region
    return document.querySelector("main") || document.body;
  }

  function _ensureFixedStyle(){
    if(document.getElementById("vsp-dash-fixed-style")) return;
    const st = document.createElement("style");
    st.id="vsp-dash-fixed-style";
    st.textContent = `
      #vsp-dash-p1-badges{ z-index:9999; }
      #vsp-dash-p1-badges.vsp-fixed{
        position: sticky;
        top: 0;
        backdrop-filter: blur(8px);
        background: rgba(2,6,23,.60) !important;
      }
    `;
    document.head.appendChild(st);
  }

  // override ensureBar from V1 (if exists) by recreating bar + sticky class
  function ensureBarV3(){
    _ensureFixedStyle();
    let bar = document.getElementById("vsp-dash-p1-badges");
    if(bar) {
      bar.classList.add("vsp-fixed");
      return bar;
    }
    const host = _pickHost();
    if(!host) return null;

    bar = document.createElement("div");
    bar.id = "vsp-dash-p1-badges";
    bar.className = "vsp-fixed";
    bar.style.cssText = "margin:0 0 12px 0;padding:10px 12px;border:1px solid rgba(148,163,184,.18);border-radius:14px;background:rgba(2,6,23,.35);display:flex;gap:10px;flex-wrap:wrap;align-items:center;";

    function pill(id, label){
      const a = document.createElement("a");
      a.href="#";
      a.id=id;
      a.style.cssText = "display:inline-flex;gap:8px;align-items:center;padding:7px 10px;border-radius:999px;border:1px solid rgba(148,163,184,.22);text-decoration:none;color:#cbd5e1;font-size:12px;white-space:nowrap;";
      a.innerHTML = `<b style="font-weight:700;color:#e2e8f0">${label}</b><span style="opacity:.9" data-val>loading…</span>`;
      return a;
    }

    bar.appendChild(pill("vsp-pill-degraded","Degraded"));
    bar.appendChild(pill("vsp-pill-overrides","Overrides"));
    bar.appendChild(pill("vsp-pill-rid","RID"));

    host.prepend(bar);
    return bar;
  }

  // kick once after load to guarantee visibility
  window.addEventListener("load", function(){
    setTimeout(()=>{ try{ ensureBarV3(); } catch(e){} }, 200);
  });
  window.addEventListener("hashchange", function(){
    setTimeout(()=>{ try{ ensureBarV3(); } catch(e){} }, 120);
  });
  window.addEventListener("vsp:rid_changed", function(){
    setTimeout(()=>{ try{ ensureBarV3(); } catch(e){} }, 50);
  });
})();


/* VSP_DASH_DRILLDOWN_P1_V1: openable drilldown panel for Degraded + Overrides */
(function(){
  'use strict';

  async function _j(url, timeoutMs=8000){
    const ctrl = new AbortController();
    const t = setTimeout(()=>ctrl.abort(), timeoutMs);
    try{
      const r = await fetch(url, {signal: ctrl.signal, headers:{'Accept':'application/json'}});
      const ct = (r.headers.get('content-type')||'').toLowerCase();
      if(!ct.includes('application/json')) return null;
      return await r.json();
    } catch(e){
      return null;
    }finally{
      clearTimeout(t);
    }
  }

  function _getRidFromLocal(){
    const keys = ["vsp_selected_rid_v2","vsp_selected_rid","vsp_current_rid","VSP_RID","vsp_rid"];
    for(const k of keys){
      try{
        const v = localStorage.getItem(k);
        if(v && v !== "null" && v !== "undefined") return v;
      } catch(e){}
    }
    return null;
  }

  async function _getRid(){
    try{
      if(window.VSP_RID && typeof window.VSP_RID.get === "function"){
        const r = window.VSP_RID.get();
        if(r) return r;
      }
    } catch(e){}
    const l = _getRidFromLocal();
    if(l) return l;
    const x = await _j("/api/vsp/latest_rid_v1");
    if(x && x.ok && x.run_id) return x.run_id;
    return null;
  }

  function _ensureUI(){
    if(document.getElementById("vsp-dd-overlay")) return;

    const st = document.createElement("style");
    st.id = "vsp-dd-style";
    st.textContent = `
      #vsp-dd-overlay{position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,.55);display:none;}
      #vsp-dd-panel{position:fixed;top:60px;right:18px;bottom:18px;width:min(820px,calc(100vw - 36px));
        z-index:10001;background:rgba(2,6,23,.96);border:1px solid rgba(148,163,184,.18);border-radius:18px;
        box-shadow:0 20px 80px rgba(0,0,0,.55);display:none;overflow:hidden;}
      #vsp-dd-head{display:flex;align-items:center;justify-content:space-between;padding:14px 14px;border-bottom:1px solid rgba(148,163,184,.14);}
      #vsp-dd-title{font-weight:800;color:#e2e8f0;font-size:14px;letter-spacing:.2px}
      #vsp-dd-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
      .vsp-dd-btn{padding:7px 10px;border-radius:12px;border:1px solid rgba(148,163,184,.22);background:rgba(15,23,42,.55);
        color:#cbd5e1;font-size:12px;cursor:pointer}
      .vsp-dd-btn:hover{filter:brightness(1.08)}
      #vsp-dd-body{padding:14px;overflow:auto;height:calc(100% - 56px);color:#cbd5e1}
      .vsp-dd-card{border:1px solid rgba(148,163,184,.14);border-radius:16px;background:rgba(15,23,42,.35);padding:12px 12px;margin-bottom:12px;}
      .vsp-dd-kv{display:grid;grid-template-columns:160px 1fr;gap:6px 12px;font-size:12px;}
      .vsp-dd-k{opacity:.85}
      .vsp-dd-v{color:#e2e8f0}
      .vsp-dd-table{width:100%;border-collapse:separate;border-spacing:0 8px;font-size:12px;}
      .vsp-dd-table td{padding:8px 10px;border:1px solid rgba(148,163,184,.14);background:rgba(2,6,23,.35);}
      .vsp-dd-table tr td:first-child{border-radius:12px 0 0 12px;}
      .vsp-dd-table tr td:last-child{border-radius:0 12px 12px 0;}
      .vsp-dd-muted{opacity:.75}
      .vsp-dd-link{color:#93c5fd;text-decoration:none}
      .vsp-dd-link:hover{text-decoration:underline}
      code.vsp-dd-code{background:rgba(2,6,23,.6);border:1px solid rgba(148,163,184,.16);padding:2px 6px;border-radius:8px}
    `;
    document.head.appendChild(st);

    const ov = document.createElement("div");
    ov.id="vsp-dd-overlay";
    ov.addEventListener("click", close);
    document.body.appendChild(ov);

    const panel = document.createElement("div");
    panel.id="vsp-dd-panel";
    panel.innerHTML = `
      <div id="vsp-dd-head">
        <div id="vsp-dd-title">Drilldown</div>
        <div id="vsp-dd-actions">
          <button class="vsp-dd-btn" id="vsp-dd-refresh">Refresh</button>
          <button class="vsp-dd-btn" id="vsp-dd-copy">Copy RID</button>
          <button class="vsp-dd-btn" id="vsp-dd-close">Close</button>
        </div>
      </div>
      <div id="vsp-dd-body">
        <div class="vsp-dd-card"><div class="vsp-dd-muted">Loading…</div></div>
      </div>
    `;
    document.body.appendChild(panel);

    document.getElementById("vsp-dd-close").addEventListener("click", close);
    document.getElementById("vsp-dd-refresh").addEventListener("click", render);
    document.getElementById("vsp-dd-copy").addEventListener("click", async ()=>{
      const rid = await _getRid();
      try{ await navigator.clipboard.writeText(rid||""); } catch(e){}
    });

    window.addEventListener("keydown", (e)=>{
      if(e.key === "Escape") close();
    });
  }

  function open(){
    _ensureUI();
    document.getElementById("vsp-dd-overlay").style.display="block";
    document.getElementById("vsp-dd-panel").style.display="block";
    render();
  }

  function close(){
    const ov=document.getElementById("vsp-dd-overlay");
    const pn=document.getElementById("vsp-dd-panel");
    if(ov) ov.style.display="none";
    if(pn) pn.style.display="none";
  }

  function _fmtOverrides(eff){
    const d = (eff && eff.delta) ? eff.delta : {};
    const matched = d.matched_n ?? 0;
    const applied = d.applied_n ?? 0;
    const sup = d.suppressed_n ?? 0;
    const chg = d.changed_severity_n ?? 0;
    const exp = d.expired_match_n ?? 0;
    return {matched, applied, sup, chg, exp, now_utc: d.now_utc || ""};
  }

  function _htmlEscape(x){
    return String(x||"").replace(/[&<>"]/g, c=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;" }[c]));
  }

  async function render(){
    _ensureUI();
    const body = document.getElementById("vsp-dd-body");
    const title = document.getElementById("vsp-dd-title");
    const rid = await _getRid();
    title.textContent = rid ? `Drilldown • ${rid}` : "Drilldown • (no RID)";

    if(!rid){
      body.innerHTML = `<div class="vsp-dd-card"><div class="vsp-dd-muted">No RID selected.</div></div>`;
      return;
    }

    body.innerHTML = `<div class="vsp-dd-card"><div class="vsp-dd-muted">Loading ${_htmlEscape(rid)}…</div></div>`;

    const [st, eff, art] = await Promise.all([
      _j(`/api/vsp/run_status_v2/${encodeURIComponent(rid)}`),
      _j(`/api/vsp/findings_effective_v1/${encodeURIComponent(rid)}?limit=0`),
      _j(`/api/vsp/run_artifacts_index_v1/${encodeURIComponent(rid)}`)
    ]);

    const degraded = (st && st.degraded_tools) ? st.degraded_tools : [];
    const ov = _fmtOverrides(eff);

    let artHtml = `<div class="vsp-dd-muted">Artifacts: n/a</div>`;
    if(art && (art.ok || art.items)){
      const items = art.items || [];
      const links = items.slice(0,10).map(it=>{
        const name = _htmlEscape(it.name || it.file || "artifact");
        const url  = it.url || it.href || it.download_url || "";
        if(url) return `<a class="vsp-dd-link" href="${_htmlEscape(url)}" target="_blank" rel="noopener">${name}</a>`;
        return `<span class="vsp-dd-muted">${name}</span>`;
      });
      artHtml = `<div class="vsp-dd-muted">Artifacts:</div><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:6px;">${links.join(" ") || '<span class="vsp-dd-muted">empty</span>'}</div>`;
    }

    const degradedRows = (degraded||[]).map(it=>{
      const tool=_htmlEscape(it.tool || it.name || "");
      const verdict=_htmlEscape(it.verdict || "");
      const rc=(it.rc!==undefined && it.rc!==null) ? _htmlEscape(it.rc) : "";
      const reason=_htmlEscape(it.reason || it.error || it.note || "");
      return `<tr>
        <td><b>${tool}</b></td>
        <td>${verdict || '<span class="vsp-dd-muted">—</span>'}</td>
        <td>${rc || '<span class="vsp-dd-muted">—</span>'}</td>
        <td>${reason || '<span class="vsp-dd-muted">—</span>'}</td>
      </tr>`;
    }).join("");

    body.innerHTML = `
      <div class="vsp-dd-card">
        <div style="font-weight:800;color:#e2e8f0;margin-bottom:8px;">Overview</div>
        <div class="vsp-dd-kv">
          <div class="vsp-dd-k">RID</div><div class="vsp-dd-v"><code class="vsp-dd-code">${_htmlEscape(rid)}</code></div>
          <div class="vsp-dd-k">Overrides delta</div><div class="vsp-dd-v">matched=${ov.matched} • applied=${ov.applied} • suppressed=${ov.sup} • changed=${ov.chg} • expired=${ov.exp}</div>
          <div class="vsp-dd-k">Delta time</div><div class="vsp-dd-v">${_htmlEscape(ov.now_utc) || '<span class="vsp-dd-muted">—</span>'}</div>
          <div class="vsp-dd-k">Degraded tools</div><div class="vsp-dd-v">${(degraded||[]).length || 0}</div>
        </div>
        <div style="margin-top:10px;">${artHtml}</div>
      </div>

      <div class="vsp-dd-card">
        <div style="font-weight:800;color:#e2e8f0;margin-bottom:8px;">Degraded details</div>
        ${(degraded && degraded.length) ? `
          <table class="vsp-dd-table">
            <tr>
              <td><b>Tool</b></td><td><b>Verdict</b></td><td><b>RC</b></td><td><b>Reason</b></td>
            </tr>
            ${degradedRows}
          </table>
        ` : `<div class="vsp-dd-muted">No degraded tools.</div>`}
      </div>
    `;
  }

  window.VSP_DASH_DRILLDOWN = { open, close, render };
})();

VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2

/* VSP_DASH_DRILLDOWN_ARTIFACTS_P1_V2: pin important artifacts + quick-open buttons */
(function(){
  'use strict';
  if(!window.VSP_DASH_DRILLDOWN || typeof window.VSP_DASH_DRILLDOWN.render !== "function"){
    console.warn("[DRILL_ART_V2] VSP_DASH_DRILLDOWN missing; skip");
    return;
  }

  const PIN = [
    "kics/kics.log",
    "codeql/codeql.log",
    "trivy/trivy.json.err",
    "findings_effective.json",
    "findings_unified.json",
  ];

  function _pinSort(items){
    const byName = new Map((items||[]).map(x=>[x.name, x]));
    const out = [];
    for(const name of PIN){
      if(byName.has(name)) out.push(byName.get(name));
      else out.push({name, url:null, size:null, missing:true});
    }
    // append rest (non-duplicates)
    for(const it of (items||[])){
      if(!PIN.includes(it.name)) out.push(it);
    }
    return out;
  }

  function _qBtn(name, url){
    const disabled = !url;
    return `<a class="vsp-dd-btn" style="text-decoration:none;display:inline-flex;align-items:center;gap:6px;${disabled?'opacity:.55;pointer-events:none;':''}"
      href="${url?String(url).replace(/"/g,'&quot;'):'#'}" target="_blank" rel="noopener">
      Open <b style="color:#e2e8f0">${name}</b>
    </a>`;
  }

  // Monkey patch: wrap the existing render to decorate artifacts area after it renders
  const _origRender = window.VSP_DASH_DRILLDOWN.render;
  window.VSP_DASH_DRILLDOWN.render = async function(){
    await _origRender();

    try{
      const body = document.getElementById("vsp-dd-body");
      if(!body) return;

      // Fetch artifacts again to pin + show quick actions (cheap)
      const title = document.getElementById("vsp-dd-title");
      const rid = (title && title.textContent && title.textContent.includes("•")) ? title.textContent.split("•").pop().trim() : null;
      if(!rid) return;

      const r = await fetch(`/api/vsp/run_artifacts_index_v1/${encodeURIComponent(rid)}`, {headers:{'Accept':'application/json'}});
      const j = await r.json();
      const items = _pinSort((j && j.items) ? j.items : []);

      const quick = items.slice(0,5).map(it=>{
        const nm = it.name.split("/").pop();
        return _qBtn(nm, it.url);
      }).join("");

      // Inject a top "Quick open" strip
      let q = document.getElementById("vsp-dd-quickopen");
      if(!q){
        q = document.createElement("div");
        q.id = "vsp-dd-quickopen";
        q.className="vsp-dd-card";
        q.innerHTML = `<div style="font-weight:800;color:#e2e8f0;margin-bottom:8px;">Quick open</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">${quick}</div>`;
        body.prepend(q);
      } else {
        const _box = q.querySelector("div[style*=\"display:flex\"]");
      if(_box) _box.innerHTML = quick;
      }

      // Replace the artifacts section in Overview card (best-effort)
      const cards = body.querySelectorAll(".vsp-dd-card");
      let overview = null;
      for(const c of cards){
        if((c.textContent||"").includes("Overview")){ overview = c; break; }
      }
      if(overview){
        const links = items.slice(0,10).map(it=>{
          const nm = it.name;
          if(it.url) return `<a class="vsp-dd-link" href="${it.url}" target="_blank" rel="noopener">${nm}</a>`;
          return `<span class="vsp-dd-muted">${nm} (missing)</span>`;
        }).join(" ");
        // find "Artifacts:" label
        const html = overview.innerHTML;
        const rep = `<div class="vsp-dd-muted">Artifacts:</div><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:6px;">${links || '<span class="vsp-dd-muted">empty</span>'}</div>`;
        overview.innerHTML = html.replace(/<div class="vsp-dd-muted">Artifacts:[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/m, rep + "</div></div>")
                                .replace(/<div class="vsp-dd-muted">Artifacts:[\s\S]*?<\/div>/m, rep);
      }
    } catch(e){
      console.warn("[DRILL_ART_V2] err", e);
    }
  };

  console.log("[DRILL_ART_V2] installed");
})();

VSP_DASH_OPEN_REPORT_BTN_V1

/* VSP_DASH_OPEN_REPORT_BTN_V1: open CIO report for live RID */
(function(){
  'use strict';
  function normRid(x){
    if(!x) return "";
    return String(x).trim().replace(/^RID:\s*/i,'').replace(/^RUN_/i,'');
  }
  function getRid(){
    try{
      return normRid(localStorage.getItem("vsp_rid_selected_v2") || localStorage.getItem("vsp_rid_selected") || "");
    } catch(e){ return ""; }
  }

  function inject(){
    // try to attach near badges bar if exists; else top of body
    const host = document.getElementById("vsp-dash-p1-badges") || document.body;
    if(!host) return;

    if(document.getElementById("vsp-open-cio-report-btn")) return;

    const btn = document.createElement("button");
    btn.id = "vsp-open-cio-report-btn";
    btn.textContent = "Open CIO Report";
    btn.style.cssText = "margin-left:10px; padding:8px 10px; border-radius:10px; font-size:12px; border:1px solid rgba(148,163,184,.35); background:rgba(2,6,23,.55); color:#e2e8f0; cursor:pointer;";
    btn.addEventListener("click", function(){
      const rid = getRid();
      if(!rid){ alert("No RID selected"); return; }
      window.open("/vsp/report_cio_v1/" + encodeURIComponent(rid), "_blank", "noopener");
    });

    // put into badges bar if possible
    if(host && host.id === "vsp-dash-p1-badges"){
      host.appendChild(btn);
    }else{
      document.body.insertBefore(btn, document.body.firstChild);
    }
  }

  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", inject);
  else inject();
})();

VSP_DASH_KPI_EFFECTIVE_DEGRADED_P1_V4

/* VSP_DASH_KPI_EFFECTIVE_DEGRADED_P1_V4: show effective/raw + overrides delta + degraded clickable logs */
(function(){
  'use strict';

  function normRid(x){
    if(!x) return "";
    return String(x).trim().replace(/^RID:\s*/i,'').replace(/^RUN_/i,'');
  }
  function getRid(){
    try{
      return normRid(localStorage.getItem("vsp_rid_selected_v2") || localStorage.getItem("vsp_rid_selected") || "");
    } catch(e){ return ""; }
  }
  async function jget(url){
    const r = await fetch(url, {cache:"no-store"});
    const ct = (r.headers.get("content-type")||"");
    if(!r.ok) throw new Error("HTTP "+r.status+" "+url);
    if(ct.includes("application/json")) return await r.json();
    // tolerate non-json
    return {ok:false, _nonjson:true, text: await r.text()};
  }
  function ensureBar(){
    let bar = document.getElementById("vsp-dash-p1-badges");
    if(!bar){
      bar = document.createElement("div");
      bar.id="vsp-dash-p1-badges";
      bar.style.cssText="position:sticky;top:0;z-index:9999;margin:10px 0;padding:10px;border-radius:14px;border:1px solid rgba(148,163,184,.18);background:rgba(2,6,23,.45);backdrop-filter: blur(6px);display:flex;flex-wrap:wrap;gap:10px;align-items:center;";
      document.body.insertBefore(bar, document.body.firstChild);
    }
    return bar;
  }
  function pill(txt, tone){
    const map = {
      ok: "border:1px solid rgba(34,197,94,.35);",
      warn:"border:1px solid rgba(245,158,11,.35);",
      bad: "border:1px solid rgba(239,68,68,.35);",
      info:"border:1px solid rgba(148,163,184,.25);"
    };
    return `<span style="display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;background:rgba(2,6,23,.35);color:#e2e8f0;font-size:12px;${map[tone]||map.info}">${txt}</span>`;
  }
  function linkPill(label, url, tone){
    const map = {
      ok: "border:1px solid rgba(34,197,94,.35);",
      warn:"border:1px solid rgba(245,158,11,.35);",
      bad: "border:1px solid rgba(239,68,68,.35);",
      info:"border:1px solid rgba(148,163,184,.25);"
    };
    return `<a target="_blank" rel="noopener" href="${url}"
      style="display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;background:rgba(2,6,23,.35);color:#e2e8f0;font-size:12px;text-decoration:none;${map[tone]||map.info}">
      ${label}</a>`;
  }

  function pickLogRel(tool){
    const t = String(tool||"").toLowerCase();
    if(t.includes("kics")) return "kics/kics.log";
    if(t.includes("trivy")) return "trivy/trivy.json.err";
    if(t.includes("codeql")) return "codeql/codeql.log";
    if(t.includes("semgrep")) return "semgrep/semgrep.json";
    if(t.includes("gitleaks")) return "gitleaks/gitleaks.json";
    if(t.includes("bandit")) return "bandit/bandit.json";
    if(t.includes("syft")) return "syft/syft.json";
    if(t.includes("grype")) return "grype/grype.json";
    return "";
  }
  function artUrl(rid, rel){
    return "/api/vsp/run_artifact_raw_v1/" + encodeURIComponent(rid) + "?rel=" + encodeURIComponent(rel);
  }

  async function render(){
    const bar = ensureBar();
    const rid = getRid() || (await jget("/api/vsp/latest_rid_v1")).run_id;
    const ridN = normRid(rid||"");
    if(!ridN){
      bar.innerHTML = pill("RID: (none)", "warn") + pill("No RID selected", "warn");
      return;
    }

    let eff=null, st=null;
    try{
      eff = await jget("/api/vsp/findings_effective_v1/" + encodeURIComponent(ridN) + "?limit=0");
    } catch(e){
      eff = {ok:false, error:String(e)};
    }
    try{
      st = await jget("/api/vsp/run_status_v2/" + encodeURIComponent(ridN));
    } catch(e){
      st = {ok:false, error:String(e)};
    }

    const rawTotal = eff && typeof eff.raw_total==="number" ? eff.raw_total : null;
    const effTotal = eff && typeof eff.effective_total==="number" ? eff.effective_total : null;
    const d = (eff && eff.delta) ? eff.delta : {};
    const sup = (d && typeof d.suppressed_n==="number") ? d.suppressed_n : null;
    const chg = (d && typeof d.changed_severity_n==="number") ? d.changed_severity_n : null;
    const match = (d && typeof d.matched_n==="number") ? d.matched_n : null;
    const applied = (d && typeof d.applied_n==="number") ? d.applied_n : null;

    const degraded = (st && st.degraded_tools && Array.isArray(st.degraded_tools)) ? st.degraded_tools : [];
    const degrN = degraded.length;

    let html = "";
    html += pill("RID: "+ridN, "info");
    if(rawTotal!=null && effTotal!=null){
      const tone = (effTotal < rawTotal) ? "ok" : "info";
      html += pill(`Effective ${effTotal} / Raw ${rawTotal}`, tone);
    }else{
      html += pill("Effective/Raw: n/a", "warn");
    }

    if(match!=null) html += pill(`Overrides matched: ${match}`, "info");
    if(applied!=null) html += pill(`Overrides applied: ${applied}`, applied>0 ? "ok" : "info");
    if(sup!=null) html += pill(`Suppressed: ${sup}`, sup>0 ? "ok" : "info");
    if(chg!=null) html += pill(`Severity changed: ${chg}`, chg>0 ? "ok" : "info");

    // degraded clickable
    if(degrN>0){
      html += pill(`Degraded tools: ${degrN}`, "warn");
      degraded.slice(0,8).forEach(t=>{
        const rel = pickLogRel(t);
        if(rel) html += linkPill(`${t} log`, artUrl(ridN, rel), "warn");
        else html += pill(String(t), "warn");
      });
    }else{
      html += pill("Degraded: 0", "ok");
    }

    // quick links
    html += linkPill("CIO Report", "/vsp/report_cio_v1/"+encodeURIComponent(ridN), "info");
    html += linkPill("Unified.json", artUrl(ridN,"findings_unified.json"), "info");
    html += linkPill("Effective.json", artUrl(ridN,"findings_effective.json"), "info");

    bar.innerHTML = html;
  }

  // initial + refresh when RID changes (poll)
  let lastRid="";
  async function tick(){
    const rid=getRid();
    if(rid && rid!==lastRid){
      lastRid=rid;
      await render();
    }
  }

  if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded", ()=>{ render(); setInterval(tick, 1200); });
  }else{
    render(); setInterval(tick, 1200);
  }
})();

/* VSP_DASH_TREND_SPARKLINE_V1_BEGIN */
(function(){
  'use strict';
  if (window.__VSP_DASH_TREND_SPARKLINE_V1_INSTALLED) return;
  window.__VSP_DASH_TREND_SPARKLINE_V1_INSTALLED = true;

  const LOGP = "[VSP_TREND]";
  const API = "/api/vsp/runs_index_v3_fs_resolved?limit=20&hide_empty=0&filter=1";

  function q(sel){ try{return document.querySelector(sel);} catch(e){return null;} }
  function mountPoint(){
    return (
      q("#vsp4-dashboard") ||
      q("#tab-dashboard") ||
      q("[data-tab='dashboard']") ||
      q("#dashboard") ||
      q(".vsp-dashboard") ||
      q("main") ||
      document.body
    );
  }
  function el(tag, attrs, children){
    const n=document.createElement(tag);
    if (attrs){
      for (const k of Object.keys(attrs)){
        if (k === "class") n.className = attrs[k];
        else if (k === "style") n.setAttribute("style", attrs[k]);
        else n.setAttribute(k, attrs[k]);
      }
    }
    (children||[]).forEach(c=>{
      if (c==null) return;
      if (typeof c === "string") n.appendChild(document.createTextNode(c));
      else n.appendChild(c);
    });
    return n;
  }

  function drawSpark(canvas, series){
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0,0,w,h);

    if (!Array.isArray(series) || series.length < 2){
      ctx.globalAlpha = 0.6;
      ctx.fillText("no data", 6, 14);
      ctx.globalAlpha = 1;
      return;
    }
    let min=Infinity, max=-Infinity;
    for (const v of series){
      if (typeof v !== "number" || !isFinite(v)) continue;
      min = Math.min(min, v);
      max = Math.max(max, v);
    }
    if (!isFinite(min) || !isFinite(max)){ min=0; max=1; }
    if (max === min) max = min + 1;

    const pad = 6;
    const xStep = (w - pad*2) / (series.length - 1);
    function y(v){
      const t = (v - min) / (max - min);
      return (h - pad) - t * (h - pad*2);
    }

    // mid grid
    ctx.globalAlpha = 0.18;
    ctx.beginPath();
    ctx.moveTo(pad, Math.round(h/2)+0.5);
    ctx.lineTo(w-pad, Math.round(h/2)+0.5);
    ctx.stroke();
    ctx.globalAlpha = 1;

    // line
    ctx.beginPath();
    for (let i=0;i<series.length;i++){
      const v = (typeof series[i] === "number" && isFinite(series[i])) ? series[i] : 0;
      const xx = pad + i*xStep;
      const yy = y(v);
      if (i===0) ctx.moveTo(xx,yy);
      else ctx.lineTo(xx,yy);
    }
    ctx.lineWidth = 2;
    ctx.stroke();

    // last dot
    const lastV = (typeof series[series.length-1] === "number" && isFinite(series[series.length-1])) ? series[series.length-1] : 0;
    ctx.beginPath();
    ctx.arc(w-pad, y(lastV), 2.6, 0, Math.PI*2);
    ctx.fill();
  }

  function fmtInt(n){ try { return (Number(n)||0).toLocaleString(); } catch(e){ return String(n||0); } }

  async function run(){
    try{
      const res = await fetch(API, {cache:"no-store"});
      if (!res.ok) { console.warn(LOGP, "runs_index not ok", res.status); return; }
      const js = await res.json();
      const items = (js && js.items) ? js.items : [];
      if (!Array.isArray(items) || items.length === 0) return;

      const rows = items.slice().reverse(); // old->new
      const findings = rows.map(it => Number(it.total_findings ?? it.findings_total ?? it.total ?? 0) || 0);
      const degraded = rows.map(it => {
        const any = (it.degraded_any ?? it.is_degraded);
        const dn = Number(it.degraded_n ?? it.degraded_count ?? 0) || 0;
        return (any === true || dn > 0) ? 1 : 0;
      });

      const latest = rows[rows.length-1] || {};
      const latestRid = latest.run_id || latest.id || "";

      const root = mountPoint();
      if (!root) return;
      if (q("#vsp-trend-sparkline-card")) return;

      const card = el("div", {
        id: "vsp-trend-sparkline-card",
        class: "vsp-card vsp-card-trend",
        style: "margin-top:14px;border:1px solid rgba(148,163,184,.16);background:rgba(2,6,23,.72);border-radius:14px;padding:14px 14px 12px;box-shadow:0 10px 30px rgba(0,0,0,.25)"
      });

      const header = el("div", {style:"display:flex;justify-content:space-between;gap:12px;align-items:baseline;flex-wrap:wrap;"}, [
        el("div", null, [
          el("div", {style:"font-weight:700;font-size:14px;letter-spacing:.2px;"}, ["Trend (last 20 runs)"]),
          el("div", {style:"opacity:.75;font-size:12px;margin-top:4px;"}, [
            "Latest: ", latestRid ? latestRid : "(unknown)",
            " • Findings: ", fmtInt(findings[findings.length-1]),
            " • Degraded: ", degraded[degraded.length-1] ? "YES" : "NO"
          ])
        ])
      ]);

      const grid = el("div", {style:"display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px;"});
      function panel(title, id){
        const c = el("canvas", {id, width:"520", height:"88", style:"width:100%;height:88px;border-radius:12px;border:1px solid rgba(148,163,184,.12);background:rgba(15,23,42,.55);"});
        const box = el("div", {style:"padding:10px 10px 8px;border-radius:12px;background:rgba(15,23,42,.35);border:1px solid rgba(148,163,184,.10);"}, [
          el("div", {style:"font-size:12px;opacity:.8;margin-bottom:8px;font-weight:600;"}, [title]),
          c
        ]);
        return {box, c};
      }
      const p1 = panel("Total Findings", "vsp-trend-findings");
      const p2 = panel("Degraded (0/1)", "vsp-trend-degraded");
      grid.appendChild(p1.box); grid.appendChild(p2.box);

      card.appendChild(header);
      card.appendChild(grid);

      const anchor = q("#vsp-kpi-wrap") || q("#vsp-kpi-cards") || q(".vsp-kpi") || null;
      if (anchor && anchor.parentElement) anchor.parentElement.insertBefore(card, anchor.nextSibling);
      else root.appendChild(card);

      try{
        const css = window.getComputedStyle(card);
        [p1.c, p2.c].forEach(cv=>{
          const ctx=cv.getContext("2d");
          ctx.strokeStyle = css.color || "#e5e7eb";
          ctx.fillStyle = css.color || "#e5e7eb";
        });
      } catch(e){}

      drawSpark(p1.c, findings);
      drawSpark(p2.c, degraded);

      p1.c.title = "Total Findings (old→new): " + findings.join(", ");
      p2.c.title = "Degraded (old→new): " + degraded.join(", ");

      console.log(LOGP, "trend rendered", {points: rows.length});
    } catch(e){
      console.warn(LOGP, "trend error", e);
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run);
  else run();
})();
 /* VSP_DASH_TREND_SPARKLINE_V1_END */

/* VSP_DASH_TREND_SPARKLINE_V2_BEGIN */
(function(){
  'use strict';

  function $(sel){ return document.querySelector(sel); }
  function el(tag, cls){ const e=document.createElement(tag); if(cls) e.className=cls; return e; }
  function sstr(x){ return (typeof x === 'string') ? x.trim() : ''; }

  function findKpiMount(){
    // try common containers (robust across templates)
    const cands = [
      '#vsp-kpi-row', '#kpi-row', '#kpi-cards', '.vsp-kpi-row', '.kpi-row',
      '.vsp-kpi-grid', '.kpi-grid', '.dashboard-kpis', '.dashboard-kpi-grid',
      '.vsp-main .vsp-grid', '.vsp-main'
    ];
    for (const sel of cands){
      const n = document.querySelector(sel);
      if (n) return n;
    }
    // fallback: first large section in dashboard pane
    return document.querySelector('#pane-dashboard, #tab-dashboard, main') || document.body;
  }

  async function fetchRuns(){
    try{
      const res = await fetch('/api/vsp/runs_index_v3_fs_resolved?limit=12&hide_empty=0&filter=1', {credentials:'same-origin'});
      if (!res.ok) return [];
      const js = await res.json();
      return js.items || [];
    } catch(_e){
      return [];
    }
  }

  function parseKeyFromRid(rid){
    rid = sstr(rid);
    const m = rid.match(/(\d{8})_(\d{6})/);
    if (!m) return null;
    return m[1] + m[2];
  }

  function buildSeries(items){
    // sort ascending by rid timestamp
    const arr = (items||[]).map(it=>{
      const rid = sstr(it.run_id || it.rid || '');
      const key = parseKeyFromRid(rid) || rid;
      const v = Number(it.total_findings ?? it.findings_total ?? it.total ?? 0) || 0;
      return {rid, key, v};
    }).filter(x=>x.rid && x.key).sort((a,b)=> (a.key>b.key?1:(a.key<b.key?-1:0)));
    // keep last 10
    return arr.slice(Math.max(0, arr.length-10));
  }

  function drawSpark(canvas, series){
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0,0,w,h);

    if (!series || series.length < 2){
      // empty state
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.moveTo(6, h/2);
      ctx.lineTo(w-6, h/2);
      ctx.stroke();
      ctx.globalAlpha = 1;
      return;
    }

    const vals = series.map(x=>x.v);
    let vmin = Math.min.apply(null, vals);
    let vmax = Math.max.apply(null, vals);
    if (vmax === vmin) vmax = vmin + 1;

    const pad = 6;
    const dx = (w - pad*2) / (series.length - 1);

    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i=0;i<series.length;i++){
      const v = series[i].v;
      const x = pad + i*dx;
      const y = pad + (h - pad*2) * (1 - (v - vmin) / (vmax - vmin));
      if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    }
    ctx.stroke();

    // end dot
    const last = series[series.length-1].v;
    const x = pad + (series.length-1)*dx;
    const y = pad + (h - pad*2) * (1 - (last - vmin) / (vmax - vmin));
    ctx.beginPath(); ctx.arc(x,y,3,0,Math.PI*2); ctx.fill();
  }

  function ensureCard(){
    const id = 'vsp-trend-spark-card-v2';
    let card = document.getElementById(id);
    if (card) return card;

    const mount = findKpiMount();

    card = el('div', 'vsp-card dashboard-card');
    card.id = id;
    card.style.maxWidth = '420px';
    card.style.padding = '12px 14px';
    card.style.borderRadius = '14px';
    card.style.margin = '8px 8px 8px 0';

    const h = el('div');
    h.style.display='flex';
    h.style.justifyContent='space-between';
    h.style.alignItems='baseline';
    h.style.gap='10px';

    const title = el('div');
    title.innerHTML = '<div style="font-weight:700;letter-spacing:.2px">Trend (last 10)</div><div style="opacity:.7;font-size:12px">Total findings by run</div>';

    const stat = el('div');
    stat.id = 'vsp-trend-spark-stat-v2';
    stat.style.textAlign='right';
    stat.style.fontWeight='700';

    h.appendChild(title);
    h.appendChild(stat);

    const canvas = el('canvas');
    canvas.id = 'vsp-trend-spark-cv-v2';
    canvas.width = 360;
    canvas.height = 64;
    canvas.style.width = '100%';
    canvas.style.height = '64px';
    canvas.style.marginTop = '10px';
    canvas.style.borderRadius = '10px';

    card.appendChild(h);
    card.appendChild(canvas);

    // prepend so it appears early
    if (mount && mount.firstChild) mount.insertBefore(card, mount.firstChild);
    else (mount || document.body).appendChild(card);

    return card;
  }

  async function render(){
    const card = ensureCard();
    if (!card) return;

    const items = await fetchRuns();
    const series = buildSeries(items);

    const stat = document.getElementById('vsp-trend-spark-stat-v2');
    const cv = document.getElementById('vsp-trend-spark-cv-v2');

    if (stat){
      const n = series.length;
      const last = n ? series[n-1].v : 0;
      const prev = n>1 ? series[n-2].v : 0;
      const delta = (n>1) ? (last - prev) : 0;
      const pct = (n>1 && prev) ? (delta * 100.0 / prev) : 0;
      stat.innerHTML = `<div style="font-size:16px">${last.toLocaleString()}</div><div style="opacity:.75;font-size:12px">${(delta>=0?'+':'')}${delta.toLocaleString()} (${(pct>=0?'+':'')}${pct.toFixed(1)}%)</div>`;
    }
    if (cv && cv.getContext) drawSpark(cv, series);
  }

  // run on dashboard load and also after refresh clicks
  document.addEventListener('DOMContentLoaded', function(){
    setTimeout(render, 650);
    document.addEventListener('click', function(ev){
      const t = ev.target;
      if (!t) return;
      const txt = (t.textContent||'').toLowerCase();
      if (txt.includes('refresh')) setTimeout(render, 400);
    }, true);
  });
})();
 /* VSP_DASH_TREND_SPARKLINE_V2_END */

