// static/js/vsp_dashboard_cleanup_v1.js
// TẠM THỜI VÔ HIỆU – không ẩn gì hết, chỉ log cho dễ debug.

(function () {
  'use strict';
  console.log('[VSP_DASH_CLEANUP] disabled – no legacy block is hidden.');
})();
