/* VSP_P1_DASHBOARD_COMMERCIAL_V1 (Single Renderer; Strict Contract; CIO-level layout)
   Data sources (commercial truth):
   - /api/vsp/rid_latest_gate_root     => latest RID (CI run)
   - /api/vsp/run_file_allow?rid=...&path=run_gate_summary.json
   - /api/vsp/run_file_allow?rid=...&path=findings_unified.json
   NO schema guessing: mismatch => "Data contract mismatch"
*/
(() => {
  if (window.__vsp_dash_commercial_v1_loaded) return;
  window.__vsp_dash_commercial_v1_loaded = true;

  window.__VSP_DASH_VERSION__ = "1.0.0";
  console.log("[VSP][DashCommercialV1] boot v=" + window.__VSP_DASH_VERSION__);

  const TOOL_ORDER = ["Bandit","Semgrep","Gitleaks","KICS","Trivy","Syft","Grype","CodeQL"];
  const SEV_ORDER = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];

  function el(tag, attrs={}, children=[]) {
    const n = document.createElement(tag);
    for (const [k,v] of Object.entries(attrs||{})) {
      if (k === "class") n.className = v;
      else if (k === "html") n.innerHTML = v;
      else if (k.startsWith("on") && typeof v === "function") n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, String(v));
    }
    for (const c of (children||[])) n.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    return n;
  }

  function injectCSSOnce(){
    if (document.getElementById("VSP_P1_DASHBOARD_COMMERCIAL_CSS_V1")) return;
    const css = `
      .vspCioWrap{padding:18px 18px 28px 18px; max-width:1400px; margin:0 auto;}
      .vspRow{display:flex; gap:12px; flex-wrap:wrap;}
      .vspCard{background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:14px; padding:12px 14px;}
      .vspCard h3{margin:0 0 8px 0; font-size:12px; opacity:.85; font-weight:600; letter-spacing:.02em;}
      .vspBig{font-size:22px; font-weight:800; line-height:1.1;}
      .vspSub{opacity:.8; font-size:12px;}
      .vspPills{display:flex; gap:8px; flex-wrap:wrap;}
      .vspPill{display:inline-flex; align-items:center; gap:8px; padding:8px 10px; border-radius:999px;
               border:1px solid rgba(255,255,255,0.10); background:rgba(255,255,255,0.03); cursor:pointer; user-select:none;}
      .vspDot{width:9px; height:9px; border-radius:50%;}
      .vspBadge{padding:6px 10px; border-radius:999px; font-weight:800; font-size:12px; border:1px solid rgba(255,255,255,0.14);}
      .vspBtn{display:inline-flex; gap:8px; align-items:center; padding:8px 10px; border-radius:12px; cursor:pointer;
              border:1px solid rgba(255,255,255,0.14); background:rgba(255,255,255,0.03); text-decoration:none; color:inherit;}
      .vspBtn:hover{background:rgba(255,255,255,0.06);}
      .vspTable{width:100%; border-collapse:collapse; font-size:12px;}
      .vspTable th,.vspTable td{padding:8px 8px; border-bottom:1px solid rgba(255,255,255,0.08); vertical-align:top;}
      .vspTable th{opacity:.8; text-align:left; font-weight:700;}
      .vspMiniBars{display:flex; gap:6px; align-items:flex-end; height:60px; padding:6px 0;}
      .vspBar{flex:1; background:rgba(255,255,255,0.10); border:1px solid rgba(255,255,255,0.10); border-radius:8px;}
      .vspWarn{padding:10px 12px; border-radius:12px; border:1px solid rgba(255,200,0,0.25); background:rgba(255,200,0,0.06); font-size:12px;}
      .vspErr{padding:10px 12px; border-radius:12px; border:1px solid rgba(255,0,0,0.25); background:rgba(255,0,0,0.06); font-size:12px;}
      .vspGrid2{display:grid; grid-template-columns: 1.2fr .8fr; gap:12px;}
      @media (max-width: 980px){ .vspGrid2{grid-template-columns: 1fr;} }
      .vspKpiClick{cursor:pointer;}
      .vspKpiClick:hover{background:rgba(255,255,255,0.06);}
      .vspMuted{opacity:.72;}
      .vspMono{font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;}
    `;
    document.head.appendChild(el("style",{id:"VSP_P1_DASHBOARD_COMMERCIAL_CSS_V1", html:css}));
  }

  async function fetchJSON(url){
    const res = await fetch(url, {credentials:"same-origin"});
    const text = await res.text();
    let j = null;
    try { j = JSON.parse(text); } catch (e) {
      throw new Error("Non-JSON response ("+res.status+")");
    }
    if (!res.ok) throw new Error("HTTP "+res.status);
    return j;
  }

  function pickRID(obj){
    if (!obj || typeof obj !== "object") return null;
    // accept common keys without schema guessing on tool data, only RID lookup
    return obj.rid || obj.run_id || obj.latest_rid || obj.id || null;
  }

  function normStatus(s){
    const v = String(s||"").toUpperCase();
    if (v.includes("PASS") || v==="GREEN") return "GREEN";
    if (v.includes("WARN") || v==="AMBER" || v==="YELLOW") return "AMBER";
    if (v.includes("FAIL") || v==="RED") return "RED";
    if (v.includes("MISSING")) return "MISSING";
    return v || "UNKNOWN";
  }

  function statusDot(status){
    const s = normStatus(status);
    // no hardcoded colors requested; use simple mapping via CSS inline opacity
    // we'll still encode minimal style for readability
    let bg = "rgba(200,200,200,0.8)";
    if (s==="GREEN") bg="rgba(0,220,120,0.85)";
    if (s==="AMBER") bg="rgba(255,200,0,0.85)";
    if (s==="RED") bg="rgba(255,70,70,0.85)";
    if (s==="MISSING") bg="rgba(160,160,160,0.85)";
    return el("span",{class:"vspDot", style:"background:"+bg});
  }

  function overallBadge(status){
    const s = normStatus(status);
    let b = "rgba(200,200,200,0.10)", br="rgba(255,255,255,0.16)";
    if (s==="GREEN"){ b="rgba(0,220,120,0.10)"; br="rgba(0,220,120,0.25)"; }
    if (s==="AMBER"){ b="rgba(255,200,0,0.10)"; br="rgba(255,200,0,0.25)"; }
    if (s==="RED"){ b="rgba(255,70,70,0.10)"; br="rgba(255,70,70,0.25)"; }
    return el("span",{class:"vspBadge", style:`background:${b};border-color:${br}`}, [s]);
  }

  function strictContractOrThrow(gate, findings){
    // Strict contract: findings.meta.counts_by_severity must exist, findings.findings array must exist
    const meta = findings && findings.meta;
    const cbs = meta && meta.counts_by_severity;
    if (!cbs || typeof cbs !== "object") throw new Error("Data contract mismatch: missing findings.meta.counts_by_severity");
    if (!Array.isArray(findings.findings)) throw new Error("Data contract mismatch: missing findings.findings[]");
    // gate summary expected to be object; tolerate missing keys but require object
    if (!gate || typeof gate !== "object") throw new Error("Data contract mismatch: gate summary not object");
  }

  function sumCounts(counts){
    let t = 0;
    for (const k of SEV_ORDER) t += Number(counts[k]||0);
    return t;
  }

  function getCountsBySeverity(findings){
    const c = findings.meta.counts_by_severity || {};
    const out = {};
    for (const k of SEV_ORDER) out[k] = Number(c[k]||0);
    return out;
  }

  function extractToolStatus(gate, toolName){
    // Prefer gate.by_tool[tool], else gate.tools[tool], else gate[tool]
    const bt = gate.by_tool && gate.by_tool[toolName];
    const tt = gate.tools && gate.tools[toolName];
    const raw = bt || tt || gate[toolName] || null;
    if (raw && typeof raw === "object"){
      return {
        status: raw.status || raw.overall || raw.result || raw.state || "UNKNOWN",
        degraded: Boolean(raw.degraded),
        reason: raw.degraded_reason || raw.reason || raw.note || ""
      };
    }
    return {status: raw || "UNKNOWN", degraded:false, reason:""};
  }

  function extractOverall(gate){
    return gate.overall_status || gate.overall || gate.status || "UNKNOWN";
  }

  function extractDegradedCount(gate){
    let d = 0;
    for (const t of TOOL_ORDER){
      const st = extractToolStatus(gate, t);
      if (st.degraded) d++;
      if (normStatus(st.status)==="MISSING") d++; // treat missing as degraded visibility
    }
    if (gate.meta && typeof gate.meta.degraded_tools_count === "number") return gate.meta.degraded_tools_count;
    return d;
  }

  function topReasonsPanel(gate){
    // Explain why RED: derive from gate summary common fields
    const reasons = [];
    const r1 = gate.reasons || gate.top_reasons || gate.fail_reasons;
    if (Array.isArray(r1)) reasons.push(...r1.map(x => (typeof x==="string"? x : (x.reason||x.title||JSON.stringify(x)))));
    // fallback: scan by_tool for RED / degraded reasons
    for (const t of TOOL_ORDER){
      const st = extractToolStatus(gate, t);
      const ns = normStatus(st.status);
      if (ns==="RED" || st.degraded || ns==="MISSING"){
        const msg = `${t}: ${ns}` + (st.reason ? ` — ${st.reason}` : "");
        reasons.push(msg);
      }
    }
    const uniq = [];
    const seen = new Set();
    for (const r of reasons){
      const s = String(r||"").trim();
      if (!s) continue;
      const key = s.slice(0,220);
      if (seen.has(key)) continue;
      seen.add(key);
      uniq.push(s);
      if (uniq.length >= 8) break;
    }
    const box = el("div",{class:"vspCard"},[
      el("h3",{},["Explain why ", el("span",{class:"vspMono"},["RED/Degraded"])]),
      uniq.length ? el("ul",{style:"margin:0; padding-left:18px;"}, uniq.map(x=>el("li",{class:"vspMuted",style:"margin:6px 0;"},[x])))
                  : el("div",{class:"vspSub vspMuted"},["No reasons found in gate summary."])
    ]);
    return box;
  }

  function render(root, ctx){
    const {rid, gate, findings} = ctx;
    const overall = normStatus(extractOverall(gate));
    const counts = getCountsBySeverity(findings);
    const total = sumCounts(counts);
    const degraded = extractDegradedCount(gate);

    // Header strip
    const header = el("div",{class:"vspCard"},[
      el("div",{class:"vspRow", style:"align-items:center; justify-content:space-between;"},[
        el("div",{class:"vspRow", style:"align-items:center;"},[
          el("div",{},[
            el("div",{class:"vspSub vspMono"},["RID: ", rid]),
            el("div",{style:"display:flex; gap:10px; align-items:center; margin-top:6px;"},[
              overallBadge(overall),
              el("span",{class:"vspSub"},["Degraded: ", String(degraded), "/", String(TOOL_ORDER.length)]),
            ])
          ])
        ]),
        el("div",{class:"vspRow", style:"align-items:center;"},[
          el("a",{class:"vspBtn", href:"/runs", title:"Open Runs & Reports"},["Open Runs"]),
          el("a",{class:"vspBtn", href:"/data_source", title:"Open Data Source"},["Open Data Source"]),
          el("a",{class:"vspBtn", href:"/runs?rid="+encodeURIComponent(rid), title:"Exports live in Runs (PDF/ZIP)"},["Export PDF/ZIP"]),
        ])
      ])
    ]);

    // KPI row
    function kpiCard(title, value, sevKey=null){
      const card = el("div",{class:"vspCard vspKpiClick", style:"min-width:180px; flex:1;"},[
        el("h3",{},[title]),
        el("div",{class:"vspBig"},[String(value)]),
        sevKey ? el("div",{class:"vspSub vspMuted"},["Click to filter findings: ", sevKey]) : el("div",{class:"vspSub vspMuted"},[""])
      ]);
      if (sevKey){
        card.addEventListener("click", () => {
          window.__vsp_dash_filter_sev = sevKey;
          const ev = new CustomEvent("VSP_DASH_FILTER_CHANGED", {detail:{sev:sevKey}});
          window.dispatchEvent(ev);
        });
      }
      return card;
    }

    const kpis = el("div",{class:"vspRow"},[
      kpiCard("Total findings", total, null),
      kpiCard("CRITICAL", counts.CRITICAL, "CRITICAL"),
      kpiCard("HIGH", counts.HIGH, "HIGH"),
      kpiCard("MEDIUM", counts.MEDIUM, "MEDIUM"),
      kpiCard("LOW", counts.LOW, "LOW"),
    ]);

    // Tool lane
    const toolLane = el("div",{class:"vspCard"},[
      el("h3",{},["Tool Lane (8 tools)"]),
      el("div",{class:"vspPills"}, TOOL_ORDER.map(t => {
        const st = extractToolStatus(gate, t);
        const ns = normStatus(st.status);
        const pill = el("div",{class:"vspPill", title:(st.reason||"")},[
          statusDot(ns),
          el("span",{class:"vspMono", style:"font-weight:800;"},[t]),
          el("span",{class:"vspSub vspMuted"},[ns + (st.degraded ? " (degraded)" : "")]),
        ]);
        pill.addEventListener("click", () => {
          // safe default: jump to Runs (no assumption about evidence file paths)
          window.location.href = "/runs?rid=" + encodeURIComponent(rid);
        });
        return pill;
      }))
    ]);

    // Trend mini (best effort)
    const trend = el("div",{class:"vspCard"},[
      el("h3",{},["Trend (last 10 runs)"]),
      el("div",{class:"vspSub vspMuted", id:"vspTrendNote"},["Loading runs…"]),
      el("div",{class:"vspMiniBars", id:"vspTrendBars"},[]),
    ]);

    // Top findings table
    const tblWrap = el("div",{class:"vspCard"},[
      el("h3",{},["Top Findings (fix-first)"]),
      el("div",{class:"vspSub vspMuted", id:"vspFilterHint"},["Filter: none"]),
      el("table",{class:"vspTable"},[
        el("thead",{},[
          el("tr",{},[
            el("th",{},["Severity"]),
            el("th",{},["Tool"]),
            el("th",{},["Title"]),
            el("th",{},["Location"]),
          ])
        ]),
        el("tbody",{id:"vspTopFindingsBody"},[])
      ])
    ]);

    // Audit / ISO readiness (lightweight, honest)
    const audit = el("div",{class:"vspCard"},[
      el("h3",{},["Audit / ISO readiness (quick)"]),
      el("div",{class:"vspSub vspMuted"},[
        "Evidence loaded: ",
        "run_gate_summary.json ✅, findings_unified.json ✅. ",
        "Full ISO mapping requires rule_id → control mapping table (phase P1)."
      ]),
      el("div",{class:"vspWarn", style:"margin-top:10px;"},[
        "ISO quick hint (placeholder): A.5 Access control, A.8 Asset mgmt, A.8.9 Config mgmt — cần map thực từ rule_id/tool."
      ])
    ]);

    // Layout grid
    const grid = el("div",{class:"vspGrid2"},[
      el("div",{class:"vspRow", style:"flex-direction:column; gap:12px;"},[
        header,
        kpis,
        toolLane,
        el("div",{class:"vspRow", style:"gap:12px;"},[trend, topReasonsPanel(gate)]),
        tblWrap,
      ]),
      el("div",{class:"vspRow", style:"flex-direction:column; gap:12px;"},[
        audit,
        el("div",{class:"vspCard"},[
          el("h3",{},["Data contract"]),
          el("div",{class:"vspSub vspMono"},["findings.meta.counts_by_severity + findings[] required"]),
          el("div",{class:"vspSub vspMono"},["gate summary object required (overall/by_tool recommended)"]),
        ])
      ])
    ]);

    root.innerHTML = "";
    root.appendChild(el("div",{class:"vspCioWrap"},[grid]));

    // Fill Top Findings
    const tbody = root.querySelector("#vspTopFindingsBody");
    const filterHint = root.querySelector("#vspFilterHint");

    function sevRank(s){
      const v = String(s||"").toUpperCase();
      const i = SEV_ORDER.indexOf(v);
      return i>=0 ? i : 999;
    }

    function normFinding(f){
      const sev = String(f.severity||f.sev||f.level||"").toUpperCase();
      const tool = f.tool || f.source || f.engine || f.detector || "";
      const title = f.title || f.message || f.rule_name || f.rule_id || f.id || "(no title)";
      const loc = (() => {
        const path = f.path || (f.location && f.location.path) || (f.file && f.file.path) || "";
        const line = f.line || (f.location && f.location.line) || (f.start && f.start.line) || "";
        return (path ? path : "(no path)") + (line ? (":" + line) : "");
      })();
      return {sev, tool, title, loc};
    }

    function renderFindings(){
      const want = window.__vsp_dash_filter_sev || null;
      filterHint.textContent = "Filter: " + (want || "none");
      const rows = findings.findings.map(normFinding)
        .filter(x => !want || x.sev === want)
        .sort((a,b)=> sevRank(a.sev)-sevRank(b.sev));
      const top = rows.slice(0, 12);
      tbody.innerHTML = "";
      for (const r of top){
        tbody.appendChild(el("tr",{},[
          el("td",{class:"vspMono"},[r.sev || "UNKNOWN"]),
          el("td",{class:"vspMono"},[String(r.tool||"")]),
          el("td",{},[String(r.title||"")]),
          el("td",{class:"vspMono vspMuted"},[String(r.loc||"")]),
        ]));
      }
      if (!top.length){
        tbody.appendChild(el("tr",{},[
          el("td",{colspan:"4", class:"vspSub vspMuted"},["No findings to display (filtered or empty)."])
        ]));
      }
    }

    window.addEventListener("VSP_DASH_FILTER_CHANGED", renderFindings);
    renderFindings();

    // Trend (best effort): /api/vsp/runs?limit=10
    (async () => {
      const note = root.querySelector("#vspTrendNote");
      const bars = root.querySelector("#vspTrendBars");
      try{
        const runs = await fetchJSON("/api/vsp/runs?limit=10");
        const arr = Array.isArray(runs) ? runs : (runs.runs || runs.items || []);
        if (!Array.isArray(arr) || !arr.length){
          note.textContent = "No runs data (backend returns empty).";
          return;
        }
        // Expect each item to have counts_by_severity or at least overall
        const pts = arr.map(x => {
          const rid2 = x.rid || x.run_id || x.id || "";
          const c = (x.counts_by_severity || (x.meta && x.meta.counts_by_severity)) || null;
          const totalCH = c ? (Number(c.CRITICAL||0) + Number(c.HIGH||0)) : null;
          return {rid:rid2, totalCH};
        }).slice(0,10).reverse();

        const max = Math.max(1, ...pts.map(p => Number(p.totalCH||0)));
        bars.innerHTML = "";
        for (const p of pts){
          const h = p.totalCH==null ? 10 : Math.max(6, Math.round((p.totalCH/max)*60));
          const bar = el("div",{class:"vspBar", title:(p.rid?("RID "+p.rid):"") + (p.totalCH==null ? " (no counts)" : (" C+H="+p.totalCH)), style:"height:"+h+"px"});
          bars.appendChild(bar);
        }
        note.textContent = "Bar = (CRITICAL + HIGH) for last runs (best effort).";
      }catch(e){
        note.textContent = "Trend unavailable: " + String(e.message||e);
      }
    })();
  }

  async function boot(){
    injectCSSOnce();

    // find mount
    let mount = document.getElementById("vsp_dashboard_mount_v1");
    if (!mount){
      // best-effort: reuse existing dashboard container if present
      mount = document.getElementById("vsp_dashboard") || document.getElementById("dashboard") || null;
    }
    if (!mount){
      mount = el("div",{id:"vsp_dashboard_mount_v1"});
      // insert near top of body content
      const main = document.querySelector("main") || document.body;
      main.insertBefore(mount, main.firstChild);
    }

    // Resolve RID (commercial truth)
    let rid = window.__VSP_RID_LATEST_GATE_ROOT__ || window.__vsp_rid_latest_gate_root || null;
    if (!rid){
      try{
        const j = await fetchJSON("/api/vsp/rid_latest_gate_root");
        rid = pickRID(j) || (j && j.data && pickRID(j.data)) || null;
      }catch(e){
        // Do NOT fallback to schema guessing of run data; show error
        mount.innerHTML = "";
        mount.appendChild(el("div",{class:"vspCioWrap"},[
          el("div",{class:"vspErr"},[
            el("div",{style:"font-weight:800;"},["Cannot resolve rid_latest_gate_root"]),
            el("div",{class:"vspSub vspMuted"},["Expected endpoint: /api/vsp/rid_latest_gate_root"]),
          ])
        ]));
        console.error("[VSP][DashCommercialV1] rid_latest_gate_root failed:", e);
        return;
      }
    }

    // Fetch truth files
    const gateUrl = "/api/vsp/run_file_allow?rid="+encodeURIComponent(rid)+"&path=run_gate_summary.json";
    const findUrl = "/api/vsp/run_file_allow?rid="+encodeURIComponent(rid)+"&path=findings_unified.json";
    try{
      const gate = await fetchJSON(gateUrl);
      const findings = await fetchJSON(findUrl);

      // Some APIs wrap {ok:true,data:{...}}; accept wrapper only here (transport), not schema guessing of tool fields
      const gateObj = gate && gate.data ? gate.data : gate;
      const findObj = findings && findings.data ? findings.data : findings;

      strictContractOrThrow(gateObj, findObj);

      console.log("[VSP][DashCommercialV1] ok rid="+rid+" findings="+(findObj.findings?findObj.findings.length:"?"));
      render(mount, {rid, gate:gateObj, findings:findObj});
    }catch(e){
      mount.innerHTML = "";
      mount.appendChild(el("div",{class:"vspCioWrap"},[
        el("div",{class:"vspErr"},[
          el("div",{style:"font-weight:800;"},["Data contract mismatch / load failed"]),
          el("div",{class:"vspSub vspMuted"},[String(e.message||e)]),
          el("div",{class:"vspSub vspMuted"},["Required: findings.meta.counts_by_severity + findings.findings[]"]),
          el("div",{class:"vspSub vspMuted vspMono"},["RID: "+rid]),
        ])
      ]));
      console.error("[VSP][DashCommercialV1] load/render failed:", e);
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();



/* ===================== VSP_P1_SETTINGS_SOFT_REFRESH_LASTRUN_V1 ===================== */
(()=> {
  if (window.__vsp_p1_settings_soft_refresh_lastrun_v1) return;
  window.__vsp_p1_settings_soft_refresh_lastrun_v1 = true;

  function followOn(){
    try { return (localStorage.getItem("vsp_follow_latest") ?? "on") !== "off"; }
    catch(e) { return true; }
  }

  async function jget(u){
    const r = await fetch(u, {credentials:"same-origin"});
    if (!r.ok) throw new Error("HTTP "+r.status);
    return await r.json();
  }

  function setTextAny(selList, txt){
    try {
      for (const sel of selList){
        const el = document.querySelector(sel);
        if (el) el.textContent = txt;
      }
    } catch(e) {}
  }

  function setBadge(sel, clsAdd, clsRemove){
    try {
      const el = document.querySelector(sel);
      if (!el) return;
      if (clsRemove) el.classList.remove(clsRemove);
      if (clsAdd) el.classList.add(clsAdd);
    } catch(e) {}
  }

  async function refreshLastRunExplicit(rid){
    // Update RID labels if any
    setTextAny(["#rid_txt","#rid_val","#rid_text","#rid_label","[data-vsp-rid]"], rid);

    // Pull gate summary (overall + counts)
    try {
      const sum = await jget(`/api/vsp/run_file_allow?rid=${encodeURIComponent(rid)}&path=run_gate_summary.json`);
      if (sum && sum.ok) {
        // Best-effort: fill common fields if exist
        if (sum.overall) setTextAny(["#overall","#overall_txt","#overall_val","[data-vsp-overall]"], String(sum.overall));
        if (sum.counts_total) {
          const ct = sum.counts_total;
          if (ct.CRITICAL != null) setTextAny(["#c_critical","[data-vsp-c-critical]"], String(ct.CRITICAL));
          if (ct.HIGH != null)     setTextAny(["#c_high","[data-vsp-c-high]"], String(ct.HIGH));
          if (ct.MEDIUM != null)   setTextAny(["#c_medium","[data-vsp-c-medium]"], String(ct.MEDIUM));
          if (ct.LOW != null)      setTextAny(["#c_low","[data-vsp-c-low]"], String(ct.LOW));
          if (ct.INFO != null)     setTextAny(["#c_info","[data-vsp-c-info]"], String(ct.INFO));
          if (ct.TRACE != null)    setTextAny(["#c_trace","[data-vsp-c-trace]"], String(ct.TRACE));
        }
      }
    } catch(e) {
      // ignore
    }
  }

  async function doRefresh(rid){
    // If there's an existing refresh function, call it; else do explicit minimal refresh
    try { await normStatus(rid); return; } catch(e) { /* fallback */ }
    await refreshLastRunExplicit(rid);
  }

  window.addEventListener("vsp:rid_changed", (ev)=> {
    try {
      if (!followOn()) return;
      const d = ev && ev.detail ? ev.detail : null;
      const rid = d && d.rid ? d.rid : (window.__vsp_rid_latest||null);
      if (!rid) return;
      Promise.resolve(doRefresh(rid)).catch(()=>{});
    } catch(e) {}
  }, {passive:true});

})();
/* ===================== /VSP_P1_SETTINGS_SOFT_REFRESH_LASTRUN_V1 ===================== */




/* ===================== VSP_P1_RULE_OVERRIDES_SOFT_REFRESH_PREVIEW_V1 ===================== */
(()=> {
  if (window.__vsp_p1_rule_overrides_soft_preview_v1) return;
  window.__vsp_p1_rule_overrides_soft_preview_v1 = true;

  function followOn(){
    try { return (localStorage.getItem("vsp_follow_latest") ?? "on") !== "off"; }
    catch(e) { return true; }
  }

  async function jget(u){
    const r = await fetch(u, {credentials:"same-origin"});
    if (!r.ok) throw new Error("HTTP "+r.status);
    return await r.json();
  }

  function setRidLabel(rid){
    try {
      const el = document.querySelector("#rid_txt,#rid_val,#rid_text,#rid_label,[data-vsp-rid]");
      if (el) el.textContent = rid;
    } catch(e) {}
  }

  async function refreshPreview(rid){
    // If project already has a preview fn, use it.
    try { await refreshLastRunExplicit(rid); return; } catch(e) { /* fallback */ }

    // Minimal best-effort: if there is a preview panel element, at least show RID
    try {
      const box = document.querySelector("#preview,#impact,#preview_box,#impact_box,[data-vsp-preview]");
      if (box) {
        box.setAttribute("data-vsp-rid", rid);
      }
    } catch(e) {}

    // Optional: if your JS already references a preview endpoint, keep it as future extension

  }

  window.addEventListener("vsp:rid_changed", (ev)=> {
    try {
      if (!followOn()) return;
      const d = ev && ev.detail ? ev.detail : null;
      const rid = d && d.rid ? d.rid : (window.__vsp_rid_latest||null);
      if (!rid) return;
      setRidLabel(rid);
      Promise.resolve(refreshPreview(rid)).catch(()=>{});
    } catch(e) {}
  }, {passive:true});
})();
/* ===================== /VSP_P1_RULE_OVERRIDES_SOFT_REFRESH_PREVIEW_V1 ===================== */




/* ===================== VSP_P1_RULE_OVERRIDES_SYNC_DROPDOWN_V1B ===================== */
(()=> {
  if (window.__vsp_p1_rule_overrides_sync_dropdown_v1b) return;
  window.__vsp_p1_rule_overrides_sync_dropdown_v1b = true;

  function followOn(){
    try { return (localStorage.getItem("vsp_follow_latest") ?? "on") !== "off"; }
    catch(e) { return true; }
  }

  function findRuleOverridesRoot(){
    // Try to find the section by heading text "Rule Overrides"
    const nodes = Array.from(document.querySelectorAll("h1,h2,h3,div,section"));
    for (const n of nodes) {
      const t = (n.textContent||"").trim();
      if (t === "Rule Overrides" || t.includes("Rule Overrides")) {
        // prefer a container near it
        return n.closest("section") || n.closest("div") || document.body;
      }
    }
    return document.body;
  }

  function findRunSelect(){
    const root = findRuleOverridesRoot();
    // Prefer select that contains RUN_ options
    const sels = Array.from(root.querySelectorAll("select"));
    for (const sel of sels) {
      const opts = Array.from(sel.options||[]);
      if (opts.some(o => (o.value||"").includes("RUN_") || (o.text||"").includes("RUN_"))) return sel;
    }
    // Fallback: any select on page that looks like runs
    const all = Array.from(document.querySelectorAll("select"));
    for (const sel of all) {
      const opts = Array.from(sel.options||[]);
      if (opts.some(o => (o.value||"").includes("RUN_") || (o.text||"").includes("RUN_"))) return sel;
    }
    return null;
  }

  function ensureOption(sel, rid){
    if (!sel) return false;
    const opts = Array.from(sel.options||[]);
    const hit = opts.find(o => (o.value===rid) || (o.text===rid));
    if (hit) {
      sel.value = hit.value;
      return true;
    }
    // Not found: prepend a new option (so it can be selected without losing existing list)
    try {
      const o = document.createElement("option");
      o.value = rid;
      o.textContent = rid;
      sel.insertBefore(o, sel.firstChild);
      sel.value = rid;
      return true;
    } catch(e) {
      return false;
    }
  }

  function preserveEditor(){
    // best-effort: keep textarea/codemirror content untouched (we won't write into it anyway)
    const ta = document.querySelector("textarea");
    if (!ta) return null;
    return {
      el: ta,
      value: ta.value,
      ss: ta.selectionStart,
      se: ta.selectionEnd
    };
  }

  function restoreEditor(st){
    try {
      if (!st || !st.el) return;
      st.el.value = st.value;
      if (typeof st.ss === "number" && typeof st.se === "number") {
        st.el.selectionStart = st.ss;
        st.el.selectionEnd = st.se;
      }
    } catch(e) {}
  }

  window.addEventListener("vsp:rid_changed", (ev)=> {
    try {
      if (!followOn()) return;
      const d = ev && ev.detail ? ev.detail : null;
      const rid = d && d.rid ? d.rid : (window.__vsp_rid_latest||null);
      if (!rid) return;

      const editorState = preserveEditor();

      const sel = findRunSelect();
      ensureOption(sel, rid);

      // Also update any RID labels on this page
      try {
        const ids = ["rid_txt","rid_val","rid_text","rid_label"];
        for (const id of ids) {
          const el = document.getElementById(id);
          if (el) el.textContent = rid;
        }
      } catch(e) {}

      restoreEditor(editorState);
    } catch(e) {}
  }, {passive:true});
})();
/* ===================== /VSP_P1_RULE_OVERRIDES_SYNC_DROPDOWN_V1B ===================== */




/* ===================== VSP_P2_GLOBAL_RID_PICKER_PIN_COPY_V1B ===================== */
(()=> {
  if (window.__vsp_p2_global_rid_picker_v1b) return;
  window.__vsp_p2_global_rid_picker_v1b = true;

  const LS_PIN = "vsp.rid.pin";
  const LS_FOLLOW = "vsp_follow_latest";

  function followOn(){
    try { return (localStorage.getItem(LS_FOLLOW) ?? "on") !== "off"; }
    catch(e) { return true; }
  }
  function setFollow(on){
    try { localStorage.setItem(LS_FOLLOW, on ? "on" : "off"); } catch(e) {}
    try { window.dispatchEvent(new CustomEvent("vsp:follow_latest_changed", {detail:{value:on?"on":"off"}})); } catch(e) {}
  }

  async function jget(u){
    const r = await fetch(u, {credentials:"same-origin"});
    if (!r.ok) throw new Error("HTTP "+r.status);
    return await r.json();
  }

  async function getLatestRid(){
    try {
      const j = await jget("/api/vsp/rid_latest_gate_root");
      if (j && j.ok && j.rid) return j.rid;
    } catch(e) {}
    return null;
  }

  // Auto-discover: try multiple endpoints that might return run list
  async function getRunsList(){
    const cands = [
      "/api/vsp/runs",
      "/api/vsp/runs_v1",
      "/api/vsp/runs_index",
      "/api/vsp/runs_index_v1",
      "/api/vsp/run_history",
      "/api/vsp/run_history_v1",
      "/api/vsp/runs_reports",
      "/api/vsp/runs_reports_v1",
      "/api/vsp/run_status_v1",
      "/api/vsp/recent_runs",
      "/api/vsp/recent_runs_v1"
    ];
    for (const u of cands){
      try {
        const j = await jget(u);
        let arr = null;
        if (Array.isArray(j)) arr = j;
        else if (j && Array.isArray(j.runs)) arr = j.runs;
        else if (j && Array.isArray(j.items)) arr = j.items;
        else if (j && Array.isArray(j.data)) arr = j.data;
        if (!arr || !arr.length) continue;

        const out = [];
        for (const it of arr){
          if (!it) continue;
          const rid = it.rid || it.run_id || it.id || it.name || it.RUN_ID || it.RID;
          if (!rid || typeof rid !== "string") continue;
          const mt = it.mtime || it.modified || it.updated_at || it.ts || it.time || it.date || null;
          out.push({rid, mtime: mt});
        }
        if (out.length) return out;
      } catch(e) {}
    }
    return [];
  }

  function fmtTime(t){
    if (!t) return "";
    try {
      if (typeof t === "number") {
        const d = new Date(t > 1e12 ? t : (t*1000));
        return d.toISOString().replace("T"," ").slice(0,19);
      }
      if (typeof t === "string") {
        return t.length > 24 ? t.slice(0,24) : t;
      }
    } catch(e) {}
    return "";
  }

  function mount(){
    if (document.getElementById("vsp_rid_picker_v1b")) return;

    const host =
      document.querySelector("header") ||
      document.querySelector(".topbar") ||
      document.querySelector("#topbar") ||
      document.body;

    const wrap = document.createElement("div");
    wrap.id = "vsp_rid_picker_v1b";
    wrap.style.cssText = "display:flex;align-items:center;gap:8px;margin-left:auto";

    const fixed = (host === document.body);
    if (fixed){
      wrap.style.cssText = "position:fixed;z-index:99997;top:10px;right:150px;display:flex;align-items:center;gap:8px;background:rgba(10,18,32,.82);border:1px solid rgba(255,255,255,.10);backdrop-filter: blur(10px);padding:8px 10px;border-radius:12px;font:12px/1.2 system-ui,Segoe UI,Roboto;color:#cfe3ff;box-shadow:0 10px 30px rgba(0,0,0,.35)";
    }

    wrap.innerHTML = `
      <span style="opacity:.9;font-weight:700">RID</span>
      <select id="vsp_rid_sel_v1b" style="max-width:300px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:#d8ecff;border-radius:10px;padding:6px 10px;outline:none"></select>
      <button id="vsp_rid_pin_v1b" style="padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(80,60,20,.35);color:#ffe7b7;cursor:pointer">Pin</button>
      <button id="vsp_rid_copy_v1b" style="padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(30,60,110,.35);color:#d8ecff;cursor:pointer">Copy</button>
    `;

    if (!fixed) host.appendChild(wrap);
    else document.body.appendChild(wrap);

    const sel = document.getElementById("vsp_rid_sel_v1b");
    const btnPin = document.getElementById("vsp_rid_pin_v1b");
    const btnCopy = document.getElementById("vsp_rid_copy_v1b");

    function getPinned(){ try { return localStorage.getItem(LS_PIN); } catch(e) { return null; } }
    function setPinned(rid){ try { localStorage.setItem(LS_PIN, rid); } catch(e) {} }
    function clearPinned(){ try { localStorage.removeItem(LS_PIN); } catch(e) {} }

    function setPinBtn(){
      const pin = getPinned();
      btnPin.textContent = pin ? "Unpin" : "Pin";
      btnPin.style.background = pin ? "rgba(20,80,40,.35)" : "rgba(80,60,20,.35)";
      btnPin.style.color = pin ? "#c9ffe0" : "#ffe7b7";
    }

    async function populate(){
      const pin = getPinned();
      const latest = await getLatestRid();

      const opts = [];
      if (latest) opts.push({rid: latest, label: "Latest • " + latest});
      if (pin && (!latest || pin !== latest)) opts.push({rid: pin, label: "Pinned • " + pin});

      const runs = await getRunsList();
      const seen = new Set(opts.map(o=>o.rid));
      for (const it of runs){
        if (!it || !it.rid) continue;
        if (seen.has(it.rid)) continue;
        seen.add(it.rid);
        const t = fmtTime(it.mtime);
        opts.push({rid: it.rid, label: t ? (it.rid + " • " + t) : it.rid});
        if (opts.length >= 22) break;
      }

      sel.innerHTML = "";
      for (const o of opts){
        const op = document.createElement("option");
        op.value = o.rid;
        op.textContent = o.label;
        sel.appendChild(op);
      }

      const cur = (followOn() && latest) ? latest : (pin || latest || (opts[0]?.rid||""));
      if (cur) sel.value = cur;
      setPinBtn();
    }

    function dispatchRid(rid){
      try {
        const prev = window.__vsp_rid_latest || window.__vsp_rid_prev || null;
        window.__vsp_rid_prev = prev;
        window.__vsp_rid_latest = rid;
        window.dispatchEvent(new CustomEvent("vsp:rid_changed", {detail:{rid, prev}}));
      } catch(e) {}
    }

    sel.addEventListener("change", ()=> {
      const rid = sel.value;
      if (!rid) return;
      setFollow(false); // manual select => follow OFF
      dispatchRid(rid);
    });

    btnPin.addEventListener("click", async ()=> {
      const pin = getPinned();
      if (pin){
        clearPinned();
        setFollow(true);
        const latest = await getLatestRid();
        if (latest) dispatchRid(latest);
      } else {
        const rid = sel.value || await getLatestRid();
        if (!rid) return;
        setPinned(rid);
        setFollow(false);
        dispatchRid(rid);
      }
      await populate();
    });

    btnCopy.addEventListener("click", async ()=> {
      const rid = sel.value || getPinned() || await getLatestRid();
      if (!rid) return;
      try {
        await navigator.clipboard.writeText(rid);
      } catch(e) {
        const ta = document.createElement("textarea");
        ta.value = rid;
        ta.style.cssText="position:fixed;left:-10000px;top:-10000px";
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand("copy"); } catch(_e) {}
        ta.remove();
      }
    });

    window.addEventListener("vsp:follow_latest_changed", ()=> { populate().catch(()=>{}); });
    populate().catch(()=>{});
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();
/* ===================== /VSP_P2_GLOBAL_RID_PICKER_PIN_COPY_V1B ===================== */




/* ===================== VSP_P2_GLOBAL_RID_PICKER_FORCE_VISIBLE_V1C ===================== */
(()=> {
  if (window.__vsp_p2_rid_picker_force_visible_v1c) return;
  window.__vsp_p2_rid_picker_force_visible_v1c = true;

  function ensureVisible(){
    try {
      // if original picker already exists, do nothing
      if (document.getElementById("vsp_rid_picker_v1b")) return;

      // try to call existing mount if exposed
      if (typeof window.__vsp_p2_global_rid_picker_v1b === "function") {
        try { window.__vsp_p2_global_rid_picker_v1b(); } catch(e) {}
      }
      if (document.getElementById("vsp_rid_picker_v1b")) return;

      // fallback: create a minimal fixed wrapper that triggers vsp:rid_changed
      const wrap = document.createElement("div");
      wrap.id = "vsp_rid_picker_v1b";
      wrap.style.cssText =
        "position:fixed;z-index:99997;top:10px;right:12px;" +
        "display:flex;align-items:center;gap:8px;" +
        "background:rgba(10,18,32,.82);border:1px solid rgba(255,255,255,.10);" +
        "backdrop-filter: blur(10px);padding:8px 10px;border-radius:12px;" +
        "font:12px/1.2 system-ui,Segoe UI,Roboto;color:#cfe3ff;box-shadow:0 10px 30px rgba(0,0,0,.35)";
      wrap.innerHTML = `
        <span style="opacity:.9;font-weight:700">RID</span>
        <input id="vsp_rid_manual_v1c" placeholder="paste RID…" style="width:220px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:#d8ecff;border-radius:10px;padding:6px 10px;outline:none"/>
        <button id="vsp_rid_apply_v1c" style="padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(30,60,110,.35);color:#d8ecff;cursor:pointer">Apply</button>
      `;
      document.body.appendChild(wrap);

      const inp = document.getElementById("vsp_rid_manual_v1c");
      const btn = document.getElementById("vsp_rid_apply_v1c");
      function dispatchRid(rid){
        try {
          const prev = window.__vsp_rid_latest || window.__vsp_rid_prev || null;
          window.__vsp_rid_prev = prev;
          window.__vsp_rid_latest = rid;
          window.dispatchEvent(new CustomEvent("vsp:rid_changed", {detail:{rid, prev}}));
        } catch(e) {}
      }
      btn.addEventListener("click", ()=> {
        const rid = (inp.value||"").trim();
        if (!rid) return;
        try { localStorage.setItem("vsp_follow_latest","off"); } catch(e) {}
        dispatchRid(rid);
      });
    } catch(e) {}
  }

  // after load, if picker not shown => force visible fallback
  setTimeout(ensureVisible, 1200);
})();
/* ===================== /VSP_P2_GLOBAL_RID_PICKER_FORCE_VISIBLE_V1C ===================== */




/* ===================== VSP_P1_UI_OK_BADGE_V1 ===================== */
(()=> {
  if (window.__vsp_p1_ui_ok_badge_v1) return;
  window.__vsp_p1_ui_ok_badge_v1 = true;

  async function ping(){
    try{
      const r = await fetch("/api/vsp/rid_latest_gate_root", {credentials:"same-origin"});
      if(!r.ok) return {ok:false, status:r.status};
      const j = await r.json().catch(()=>null);
      return {ok: !!(j && (j.ok || j.rid)), status:200};
    }catch(e){
      return {ok:false, status:0};
    }
  }

  function mount(){
    if (document.getElementById("vsp_ui_ok_badge_v1")) return;

    const host =
      document.querySelector("header") ||
      document.querySelector(".topbar") ||
      document.querySelector("#topbar") ||
      document.body;

    const b = document.createElement("span");
    b.id = "vsp_ui_ok_badge_v1";
    b.textContent = "UI: …";
    b.style.cssText =
      "display:inline-flex;align-items:center;gap:6px;" +
      "padding:4px 10px;border-radius:999px;" +
      "border:1px solid rgba(255,255,255,.12);" +
      "background:rgba(255,255,255,.06);" +
      "color:#d8ecff;font:12px/1.2 system-ui,Segoe UI,Roboto;" +
      "margin-left:10px;";

    // If host is body (fallback), make fixed
    if (host === document.body){
      b.style.cssText += "position:fixed;z-index:99998;top:10px;right:12px;";
      document.body.appendChild(b);
    } else {
      host.appendChild(b);
    }

    async function refresh(){
      const res = await ping();
      if(res.ok){
        b.textContent = "UI: OK";
        b.style.borderColor = "rgba(90,255,170,.35)";
        b.style.background = "rgba(20,80,40,.35)";
        b.style.color = "#c9ffe0";
      } else {
        b.textContent = "UI: DEGRADED";
        b.style.borderColor = "rgba(255,210,120,.35)";
        b.style.background = "rgba(80,60,20,.35)";
        b.style.color = "#ffe7b7";
      }
    }

    refresh();
    setInterval(refresh, 30000);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();
/* ===================== /VSP_P1_UI_OK_BADGE_V1 ===================== */




/* ===================== VSP_P1_UI_OK_BADGE_V2_FORCE_FIXED ===================== */
(()=> {
  if (window.__vsp_p1_ui_ok_badge_v2) return;
  window.__vsp_p1_ui_ok_badge_v2 = true;

  async function ping(){
    try{
      const r = await fetch("/api/vsp/rid_latest_gate_root", {credentials:"same-origin"});
      if(!r.ok) return {ok:false, status:r.status};
      const j = await r.json().catch(()=>null);
      return {ok: !!(j && (j.ok || j.rid)), status:200};
    }catch(e){
      return {ok:false, status:0};
    }
  }

  function mount(){
    let b = document.getElementById("vsp_ui_ok_badge_v2");
    if (!b){
      b = document.createElement("div");
      b.id = "vsp_ui_ok_badge_v2";
      b.style.cssText =
        "position:fixed;z-index:999999;top:10px;right:12px;" +
        "display:inline-flex;align-items:center;gap:8px;" +
        "padding:6px 12px;border-radius:999px;" +
        "border:1px solid rgba(255,255,255,.12);" +
        "background:rgba(10,18,32,.82);" +
        "backdrop-filter: blur(10px);" +
        "color:#d8ecff;font:12px/1.2 system-ui,Segoe UI,Roboto;" +
        "box-shadow:0 10px 30px rgba(0,0,0,.35)";
      b.textContent = "UI: …";
      document.body.appendChild(b);
    }

    async function refresh(){
      const res = await ping();
      if(res.ok){
        b.textContent = "UI: OK";
        b.style.borderColor = "rgba(90,255,170,.35)";
        b.style.background = "rgba(20,80,40,.35)";
        b.style.color = "#c9ffe0";
      } else {
        b.textContent = "UI: DEGRADED";
        b.style.borderColor = "rgba(255,210,120,.35)";
        b.style.background = "rgba(80,60,20,.35)";
        b.style.color = "#ffe7b7";
      }
    }
    refresh();
    setInterval(refresh, 20000);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();
/* ===================== /VSP_P1_UI_OK_BADGE_V2_FORCE_FIXED ===================== */




/* ===================== VSP_P1_UI_OK_BADGE_V2_FORCE_FIXED ===================== */
(()=> {
  if (window.__vsp_p1_ui_ok_badge_v2) return;
  window.__vsp_p1_ui_ok_badge_v2 = true;

  async function ping(){
    try{
      const r = await fetch("/api/vsp/rid_latest_gate_root", {credentials:"same-origin"});
      if(!r.ok) return {ok:false, status:r.status};
      const j = await r.json().catch(()=>null);
      return {ok: !!(j && (j.ok || j.rid)), status:200};
    }catch(e){
      return {ok:false, status:0};
    }
  }

  function mount(){
    let b = document.getElementById("vsp_ui_ok_badge_v2");
    if (!b){
      b = document.createElement("div");
      b.id = "vsp_ui_ok_badge_v2";
      b.style.cssText =
        "position:fixed;z-index:999999;top:10px;right:12px;" +
        "display:inline-flex;align-items:center;gap:8px;" +
        "padding:6px 12px;border-radius:999px;" +
        "border:1px solid rgba(255,255,255,.12);" +
        "background:rgba(10,18,32,.82);" +
        "backdrop-filter: blur(10px);" +
        "color:#d8ecff;font:12px/1.2 system-ui,Segoe UI,Roboto;" +
        "box-shadow:0 10px 30px rgba(0,0,0,.35)";
      b.textContent = "UI: …";
      document.body.appendChild(b);
    }

    async function refresh(){
      const res = await ping();
      if(res.ok){
        b.textContent = "UI: OK";
        b.style.borderColor = "rgba(90,255,170,.35)";
        b.style.background = "rgba(20,80,40,.35)";
        b.style.color = "#c9ffe0";
      } else {
        b.textContent = "UI: DEGRADED";
        b.style.borderColor = "rgba(255,210,120,.35)";
        b.style.background = "rgba(80,60,20,.35)";
        b.style.color = "#ffe7b7";
      }
    }
    refresh();
    setInterval(refresh, 20000);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();
/* ===================== /VSP_P1_UI_OK_BADGE_V2_FORCE_FIXED ===================== */

