
(function () {
  async function fetchJson(url) {
    const r = await fetch(url, { cache: "no-store" });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  }
  function ce(tag, cls) { var e = document.createElement(tag); if (cls) e.className = cls; return e; }
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function ridFromUrl() {
    try { return new URL(location.href).searchParams.get("rid"); } catch (e) { return null; }
  }

  async function pickLatestRidSmart() {
    // take first RID that status_v2 can resolve
    const idx = await fetchJson("/api/vsp/runs_index_v3_fs?limit=10&hide_empty=0");
    const items = Array.isArray(idx.items) ? idx.items : [];
    for (const it of items) {
      const rid = it.req_id || it.request_id || it.run_id;
      if (!rid) continue;
      try {
        const st = await fetchJson("/api/vsp/run_status_v2/" + encodeURIComponent(rid));
        if (st && st.ok) return rid;
      } catch (e) {}
    }
    // fallback
    return (items[0] && (items[0].req_id || items[0].request_id || items[0].run_id)) || null;
  }

  function artifactUrlV2(rid, relPath) {
    return "/api/vsp/run_artifact_v2/" + encodeURIComponent(rid) + "?path=" + encodeURIComponent(relPath);
  }

  function toolLogPath(tool) {
    const t = (tool || "").toLowerCase();
    if (t === "kics") return "kics/kics.log";
    if (t === "semgrep") return "semgrep/semgrep.log";
    if (t === "codeql") return "codeql/codeql.log";
    if (t === "gitleaks") return "gitleaks/gitleaks.log";
    return "runner.log";
  }

  function pill(text, href) {
    var a = ce("a");
    a.textContent = text;
    a.href = href;
    a.target = "_blank";
    a.style.cssText = "opacity:.9; text-decoration:none; border:1px solid rgba(255,255,255,.12); padding:4px 8px; border-radius:10px;";
    return a;
  }

  function render(host, rid, st) {
    host = host || document.body;
    var panel = qs(".vsp-degraded-panel-v3", host);
    if (!panel) {
      panel = ce("div", "vsp-degraded-panel-v3");
      panel.style.cssText = "margin:12px 0; padding:12px; border:1px solid rgba(255,255,255,.08); border-radius:14px; background:rgba(255,255,255,.02)";
      host.prepend(panel);
    }

    const degraded = Array.isArray(st.degraded_tools) ? st.degraded_tools : [];
    const gate = degraded.length ? "AMBER" : (st.ok ? "GREEN" : "RED");

    panel.innerHTML = "";
    var top = ce("div");
    top.style.cssText = "display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:8px; flex-wrap:wrap;";
    var title = ce("div");
    title.innerHTML =
      "<b>Degraded tools</b> <span style='opacity:.7'>(" + gate + ")</span> " +
      "<span style='opacity:.55'>rid=" + (rid || "?") + "</span> " +
      "<span style='opacity:.55'>ci=" + (st.ci_run_dir ? "ok" : "null") + "</span>";
    var actions = ce("div");
    actions.style.cssText = "display:flex; gap:8px; align-items:center;";
    actions.appendChild(pill("degraded_tools.json", artifactUrlV2(rid, "degraded_tools.json")));
    actions.appendChild(pill("artifacts index", "/api/vsp/run_artifacts_index_v1/" + encodeURIComponent(rid)));
actions.appendChild(pill("runner.log", artifactUrlV2(rid, "runner.log")));
    top.appendChild(title);
    top.appendChild(actions);
    panel.appendChild(top);

    if (!st.ok) {
      var err = ce("div");
      err.style.opacity = ".85";
      err.textContent = "Status resolve failed: " + (st.error || "unknown");
      panel.appendChild(err);
      return;
    }

    if (!degraded.length) {
      var ok = ce("div");
      ok.style.opacity = ".8";
      ok.textContent = "No degraded tool detected.";
      panel.appendChild(ok);
      return;
    }

    degraded.forEach(function (d) {
      var row = ce("div");
      row.style.cssText = "display:flex; align-items:center; justify-content:space-between; gap:10px; padding:8px 0; border-top:1px solid rgba(255,255,255,.06)";
      var left = ce("div");
      left.innerHTML =
        "<b>" + (d.tool || "UNKNOWN") + "</b> — " + (d.reason || "degraded") +
        " <span style='opacity:.7'>(rc=" + (d.rc ?? "?") + ", ts=" + (d.ts ?? "?") + ")</span>";
      var right = ce("div");
      right.appendChild(pill("open log", artifactUrlV2(rid, toolLogPath(d.tool))));
      row.appendChild(left);
      row.appendChild(right);
      panel.appendChild(row);
    });
  }

  async function tick() {
    try {
      var rid = ridFromUrl() || await pickLatestRidSmart();
      if (!rid) return;
      var st = await fetchJson("/api/vsp/run_status_v2/" + encodeURIComponent(rid));
      render(document.body, rid, st);
    } catch (e) {}
  }

  window.addEventListener("DOMContentLoaded", function () {
    tick();
    setInterval(tick, 5000);
  });
})();
