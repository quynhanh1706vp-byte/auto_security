# ===================== VSP_P1_RUN_FILE_ALLOW_REPORTS_V1 =====================
# Expand allowed run_file_allow paths for commercial UI (read-only reports)
import re as _re_vsp_allowrep
_VSP_RUN_ALLOW_FILES_V1 = {
    "run_gate.json",
    "run_gate_summary.json",
    "SUMMARY.txt",
    "run_manifest.json",
    "run_evidence_index.json",
    "findings_unified.json",
}
_VSP_RUN_ALLOW_RE_V1 = _re_vsp_allowrep.compile(r"^(reports/findings_unified\.(csv|sarif|html|pdf))$")
def _vsp_run_file_allow_ok_v1(path: str) -> bool:
    try:
        if not path:
            return False
        if path in _VSP_RUN_ALLOW_FILES_V1:
            return True
        return bool(_VSP_RUN_ALLOW_RE_V1.match(path))
    except Exception:
        return False
# ===================== /VSP_P1_RUN_FILE_ALLOW_REPORTS_V1 =====================


# ===================== VSP_P0_SAFE_POLISH_CSS_INJECT_V2 =====================
import socket

# ===================== VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_DUALPATCH_V4 =====================
import os, json, time
from pathlib import Path as _VSPPath
from flask import Response, request, send_file

def _vsp_p0_runs_roots():
    roots = []
    one = os.environ.get("VSP_RUNS_ROOT", "").strip()
    if one:
        roots.append(one)
    many = os.environ.get("VSP_RUNS_ROOTS", "").strip()
    if many:
        for x in many.split(":"):
            x = x.strip()
            if x:
                roots.append(x)

    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
    ]

    out, seen = [], set()
    for r in roots:
        if r not in seen:
            seen.add(r)
            out.append(r)
    return out

def _vsp_p0_try_resolve_gate_root_path(rid, gate_root_name):
    if not rid:
        return None
    if not gate_root_name:
        gate_root_name = f"gate_root_{rid}"

    for base in _vsp_p0_runs_roots():
        try:
            b = _VSPPath(base)
            if not b.is_dir():
                continue

            cand = b / gate_root_name
            if cand.is_dir():
                return str(cand)

            # 1 level
            for d1 in b.iterdir():
                if d1.is_dir():
                    c1 = d1 / gate_root_name
                    if c1.is_dir():
                        return str(c1)

            # 2 levels (bounded)
            for d1 in b.iterdir():
                if not d1.is_dir():
                    continue
                try:
                    for d2 in d1.iterdir():
                        if d2.is_dir():
                            c2 = d2 / gate_root_name
                            if c2.is_dir():
                                return str(c2)
                except Exception:
                    continue
        except Exception:
            continue
    return None

def _vsp_p0_virtual_manifest(rid, gate_root_name, gate_root_path, served_by):
    now = int(time.time())
    return {
        "ok": True,
        "rid": rid,
        "gate_root": gate_root_name,
        "gate_root_path": gate_root_path,
        "generated": True,
        "generated_at": now,
        "degraded": (gate_root_path is None),
        "served_by": served_by,
        "required_paths": [
            "run_gate.json",
            "run_gate_summary.json",
            "findings_unified.json",
            "reports/findings_unified.csv",
            "run_manifest.json",
            "run_evidence_index.json",
        ],
        "optional_paths": [
            "reports/findings_unified.sarif",
            "reports/findings_unified.html",
            "reports/findings_unified.pdf",
        ],
        "hints": {
            "set_env": "Set VSP_RUNS_ROOT or VSP_RUNS_ROOTS (colon-separated) to the parent folder that contains gate_root_<RID> directories.",
            "example": "VSP_RUNS_ROOT=/home/test/Data/SECURITY-10-10-v4/out_ci",
        },
    }

def _vsp_p0_virtual_evidence_index(rid, gate_root_name, gate_root_path, served_by):
    now = int(time.time())
    evidence_files = []
    evidence_dir = None

    if gate_root_path:
        for sub in ("evidence", "artifacts", "out/evidence"):
            ed = _VSPPath(gate_root_path) / sub
            if ed.is_dir():
                evidence_dir = str(ed)
                try:
                    for fp in sorted(ed.rglob("*")):
                        if fp.is_file():
                            evidence_files.append(str(fp.relative_to(ed)))
                except Exception:
                    pass
                break

    return {
        "ok": True,
        "rid": rid,
        "gate_root": gate_root_name,
        "gate_root_path": gate_root_path,
        "generated": True,
        "generated_at": now,
        "degraded": (gate_root_path is None),
        "served_by": served_by,
        "evidence_dir": evidence_dir,
        "files": evidence_files,
        "missing_recommended": [
            "evidence/ui_engine.log",
            "evidence/trace.zip",
            "evidence/last_page.html",
            "evidence/storage_state.json",
            "evidence/net_summary.json",
        ],
    }
# ===================== /VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_DUALPATCH_V4 =====================


# ===================== VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_ALWAYS200_V3 =====================
import os, json, time
from pathlib import Path as _VSPPath
from flask import Response, request, send_file

def _vsp_runs_roots():
    roots = []
    one = os.environ.get("VSP_RUNS_ROOT", "").strip()
    if one:
        roots.append(one)
    many = os.environ.get("VSP_RUNS_ROOTS", "").strip()
    if many:
        for x in many.split(":"):
            x = x.strip()
            if x:
                roots.append(x)

    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
    ]

    out, seen = [], set()
    for r in roots:
        if r not in seen:
            seen.add(r)
            out.append(r)
    return out

def _vsp_try_resolve_gate_root_path(rid, gate_root_name):
    if not rid:
        return None
    if not gate_root_name:
        gate_root_name = f"gate_root_{rid}"

    for base in _vsp_runs_roots():
        try:
            b = _VSPPath(base)
            if not b.is_dir():
                continue

            cand = b / gate_root_name
            if cand.is_dir():
                return str(cand)

            # 1 level
            for d1 in b.iterdir():
                if d1.is_dir():
                    c1 = d1 / gate_root_name
                    if c1.is_dir():
                        return str(c1)

            # 2 levels (bounded)
            for d1 in b.iterdir():
                if not d1.is_dir():
                    continue
                try:
                    for d2 in d1.iterdir():
                        if d2.is_dir():
                            c2 = d2 / gate_root_name
                            if c2.is_dir():
                                return str(c2)
                except Exception:
                    continue
        except Exception:
            continue
    return None

def _vsp_virtual_manifest(rid, gate_root_name, gate_root_path):
    now = int(time.time())
    required = [
        "run_gate.json",
        "run_gate_summary.json",
        "findings_unified.json",
        "reports/findings_unified.csv",
        "run_manifest.json",
        "run_evidence_index.json",
    ]
    optional = [
        "reports/findings_unified.sarif",
        "reports/findings_unified.html",
        "reports/findings_unified.pdf",
    ]
    return {
        "ok": True,
        "rid": rid,
        "gate_root": gate_root_name,
        "gate_root_path": gate_root_path,
        "generated": True,
        "generated_at": now,
        "degraded": (gate_root_path is None),
        "required_paths": required,
        "optional_paths": optional,
        "hints": {
            "set_env": "Set VSP_RUNS_ROOT or VSP_RUNS_ROOTS (colon-separated) to the parent folder that contains gate_root_<RID> directories.",
            "example": "VSP_RUNS_ROOT=/home/test/Data/SECURITY-10-10-v4/out_ci",
        },
    }

def _vsp_virtual_evidence_index(rid, gate_root_name, gate_root_path):
    now = int(time.time())
    evidence_files = []
    evidence_dir = None

    if gate_root_path:
        for sub in ("evidence", "artifacts", "out/evidence"):
            ed = _VSPPath(gate_root_path) / sub
            if ed.is_dir():
                evidence_dir = str(ed)
                try:
                    for fp in sorted(ed.rglob("*")):
                        if fp.is_file():
                            evidence_files.append(str(fp.relative_to(ed)))
                except Exception:
                    pass
                break

    return {
        "ok": True,
        "rid": rid,
        "gate_root": gate_root_name,
        "gate_root_path": gate_root_path,
        "generated": True,
        "generated_at": now,
        "degraded": (gate_root_path is None),
        "evidence_dir": evidence_dir,
        "files": evidence_files,
        "missing_recommended": [
            "evidence/ui_engine.log",
            "evidence/trace.zip",
            "evidence/last_page.html",
            "evidence/storage_state.json",
            "evidence/net_summary.json",
        ],
    }
# ===================== /VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_ALWAYS200_V3 =====================



# ===================== VSP_P0_AUTOGEN_MANIFEST_EVIDENCEINDEX_V1 =====================
def _vsp_p0__scan_run_dir(run_dir: str):
  import os, time, hashlib
  out=[]
  for root, dirs, files in os.walk(run_dir):
    # skip heavy/irrelevant dirs if any
    bn = os.path.basename(root)
    if bn in ("node_modules",".git","__pycache__"):
      continue
    for fn in files:
      fp = os.path.join(root, fn)
      rel = os.path.relpath(fp, run_dir)
      try:
        st=os.stat(fp)
        out.append({
          "path": rel.replace("\\\\","/"),
          "size": int(st.st_size),
          "mtime": int(st.st_mtime),
        })
      except Exception:
        out.append({"path": rel.replace("\\\\","/")})
  out.sort(key=lambda x: x.get("path",""))
  return out

def _vsp_p0__write_json_if_possible(fp: str, obj):
  import os, json
  try:
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    with open(fp, "w", encoding="utf-8") as f:
      json.dump(obj, f, ensure_ascii=False, indent=2)
    return True
  except Exception:
    return False

def _vsp_p0_make_run_manifest(run_dir: str, rid: str):
  import time, os
  files = _vsp_p0__scan_run_dir(run_dir)
  return {
    "rid": rid,
    "generated_at": int(time.time()),
    "run_dir": run_dir,
    "files_total": len(files),
    "files": files,
    "note": "auto-generated (P0) because run_manifest.json was missing",
  }

def _vsp_p0_make_run_evidence_index(run_dir: str, rid: str):
  import time, os
  required = [
    "run_gate.json",
    "run_gate_summary.json",
    "findings_unified.json",
    "run_manifest.json",
    "run_evidence_index.json",
    "reports/findings_unified.csv",
    "reports/findings_unified.sarif",
    "reports/findings_unified.html",
  ]
  present=[]
  missing=[]
  for p in required:
    if os.path.exists(os.path.join(run_dir, p)):
      present.append(p)
    else:
      missing.append(p)
  return {
    "rid": rid,
    "generated_at": int(time.time()),
    "run_dir": run_dir,
    "required": required,
    "present": present,
    "missing": missing,
    "audit_ready": (len(missing)==0),
    "note": "auto-generated (P0) because run_evidence_index.json was missing",
  }
# ===================== /VSP_P0_AUTOGEN_MANIFEST_EVIDENCEINDEX_V1 =====================


# ===================== VSP_P0_DASHBOARD_RUNFILEALLOW_CONTRACT_V1 =====================
# Dashboard minimal whitelist (exact paths; no glob)
_DASHBOARD_ALLOW_EXACT = {
  "run_gate_summary.json",
  "reports/run_gate_summary.json",
  "findings_unified.json",
  "run_gate.json",
  "reports/run_gate.json",
  "run_manifest.json",
  "run_evidence_index.json",
  "reports/findings_unified.csv",
  "reports/findings_unified.sarif",
  "reports/findings_unified.html",
}
def _dash_allow_exact(path: str) -> bool:
  """Exact allow-check for Dashboard run_file_allow contract (no glob)."""
  try:
    p = (path or "").strip()
    if not p:
      return False
    # normalize
    p = p.replace("\\", "/").lstrip("/")
    # basic traversal hard-block
    if ".." in p:
      return False
    return p in _DASHBOARD_ALLOW_EXACT
  except Exception:
    return False


# VSP_P0_DASH_ALLOW_SELFTEST_V1
# self-check (expected True): run_gate_summary.json, reports/run_gate_summary.json
# ===================== /VSP_P0_DASHBOARD_RUNFILEALLOW_CONTRACT_V1 =====================

# coding: utf-8

def _vsp_is_runs_path(environ):
    """Return True if request path is /runs or /runs/... (standalone runs page)."""
    try:
        path = (environ.get("PATH_INFO") or "")
    except Exception:
        path = ""
    return path == "/runs" or path.startswith("/runs/")

# VSP_P0_SKIP_FILLREAL_BY_PATH_V1
"""
FORCE FULL VSP UI GATEWAY
- Make gunicorn serve the real Flask app (vsp_demo_app.app)
- Avoid any exportpdf-only/preempt wrappers hijacking /api/vsp/*
"""

# --- VSP_MARK_FIX_P0_V6 ---
# Fix: make MARK always available (also via builtins to avoid NameError in any scope).
# VSP_P1_FORCEWRAP_ALL_KEEPFLASK_V3
# VSP_P1_FORCEWRAP_MULTILINE_KEEPFLASK_V4
# VSP_P1_ALL_MW_KEEPFLASK_V5
import builtins as _vsp_builtins
if not hasattr(_vsp_builtins, 'MARK'):
    _vsp_builtins.MARK = 'VSP_UI_GATEWAY_MARK_V1'
MARK = getattr(_vsp_builtins, 'MARK', 'VSP_UI_GATEWAY_MARK_V1')
MARK_B = (MARK.encode() if isinstance(MARK, str) else str(MARK).encode())
# --- /VSP_MARK_FIX_P0_V6 ---

# VSP_MARK_DEDUPE_SAFE_P0_V8C: keep legacy alias (do not override MARK)
MARKB = MARK_B  # legacy alias
# /VSP_MARK_DEDUPE_SAFE_P0_V8C





# VSP_MARK_FIX_P0_V3
# (P0_V8C) disabled legacy MARK reassignment
# (P0_V8C) disabled legacy MARKB bytes (use MARKB=MARK_B alias)

# VSP_IMPORT_TIME_P0_V2: required by WSGI wrapper (__call__) and cache-bust logic
import time
import os
# /VSP_IMPORT_TIME_P0_V2

from vsp_demo_app import app as application  # gunicorn entrypoint
app = application





# --- VSP_RUNS_HAS_DETECT_P0_V1 ---
# Commercial: /api/vsp/runs must show accurate artifact presence (csv/json/sarif/html/summary).
from flask import request as _vsp_req, send_from_directory, request, jsonify, make_response
import os as _vsp_os
import json as _vsp_json


# VSP_P1_BASE_WSGI_COERCE_V12
def _vsp_is_flask_app(obj):
    return obj is not None and hasattr(obj, 'after_request') and hasattr(obj, 'route')

def _vsp_base_wsgi(obj):
    # If someone passed a Flask app object, return its ORIGINAL Flask.wsgi_app bound method,
    # not the overwritten instance attribute (prevents recursion).
    if _vsp_is_flask_app(obj):
        try:
            return obj.__class__.wsgi_app.__get__(obj, obj.__class__)
        except Exception:
            return getattr(obj, 'wsgi_app', obj)
    return getattr(obj, 'wsgi_app', obj)

def _vsp_detect_artifacts(run_dir: str) -> dict:
    d = {"csv":False,"json":False,"sarif":False,"summary":False,"html":False,"html_path":None}
    if not run_dir:
        return d

    # common artifact locations (support both run-root and reports/)
    cand = [
        ("json",   ["findings_unified.json", "reports/findings_unified.json"]),
        ("csv",    ["findings_unified.csv",  "reports/findings_unified.csv"]),
        ("sarif",  ["findings_unified.sarif","reports/findings_unified.sarif"]),
        ("summary",["run_gate_summary.json","SUMMARY.txt", "SHA256SUMS.txt","reports/SUMMARY.txt", "reports/SHA256SUMS.txt", "reports/SHA256SUMS.txt","reports/run_gate_summary.json"]),
        # VSP_P0_ALLOW_REPORTS_GATE_LISTONLY_V5
        "reports/run_gate.json",
    ]
    for k, rels in cand:
        for rel in rels:
            if _vsp_os.path.exists(_vsp_os.path.join(run_dir, rel)):
                d[k] = True
                break

    html_cands = [
        "reports/index.html",
        "report/index.html",
        "reports/report.html",
        "reports/findings_unified.html",
        "findings_unified.html",
        "index.html",
    ]
    for rel in html_cands:
        fp = _vsp_os.path.join(run_dir, rel)
        if _vsp_os.path.exists(fp):
            d["html"] = True
            d["html_path"] = fp
            break
    return d

@app.after_request
def _vsp_after_request_runs_has(resp):
    try:
        # only patch the runs listing JSON
        if _vsp_req.path != "/api/vsp/runs":
            return resp
        ctype = (resp.headers.get("Content-Type") or "")
        if "application/json" not in ctype:
            return resp

        data = None
        try:
            data = resp.get_json(silent=True)
        except Exception:
            data = None
        if not isinstance(data, dict):
            return resp

        items = data.get("items")
        if not isinstance(items, list):
            return resp

        for it in items:
            if not isinstance(it, dict):
                continue
            run_dir = it.get("path") or ""
            has = it.get("has")
            if not isinstance(has, dict):
                has = {}
            det = _vsp_detect_artifacts(str(run_dir))
            has.update(det)
            it["has"] = has

        out = _vsp_json.dumps(data, ensure_ascii=False)
        resp.set_data(out.encode("utf-8"))
        resp.headers["Content-Length"] = str(len(resp.get_data()))
        # ==== VSP_P1_RUNS_CONTRACT_FIELDS_V1 ====
        # P1 contract: enrich runs index response with stable fields for UI/commercial
        try:
            from flask import request as _req
            import os as _os
            # effective limit: requested (cap)
            try:
                _lim_req = int((_req.args.get("limit") or "50").strip())
            except Exception:
                _lim_req = 50
            _hard_cap = 120
            _lim_eff = max(1, min(_lim_req, _hard_cap))
            data["limit"] = _lim_eff
        
            items = data.get("items") or []
            rid_latest = ""
            if isinstance(items, list) and items:
                try:
                    rid_latest = (items[0].get("run_id") or items[0].get("rid") or "").strip()
                except Exception:
                    rid_latest = ""
            data["rid_latest"] = rid_latest
        
            # cache TTL hint
            try:
                data["cache_ttl"] = int(_os.environ.get("VSP_RUNS_CACHE_TTL", "2"))
            except Exception:
                data["cache_ttl"] = 2
        
            # roots used (best-effort, don't break if unknown)
            roots_used = []
            try:
                # common names you may have in gateway
                for nm in ("VSP_RUNS_ROOTS", "RUNS_ROOTS", "VSP_DATA_ROOTS"):
                    if nm in globals() and isinstance(globals()[nm], (list, tuple)):
                        roots_used = [str(x) for x in globals()[nm]]
                        break
            except Exception:
                roots_used = []
            data["roots_used"] = roots_used
        
            # scan cap hit
            try:
                scanned = int(data.get("_scanned") or 0)
            except Exception:
                scanned = 0
            scan_cap = int(data.get("_scan_cap") or 500)
            data["scan_cap"] = scan_cap
            data["scan_cap_hit"] = bool(scanned >= scan_cap)
        except Exception:
            pass
        # ==== /VSP_P1_RUNS_CONTRACT_FIELDS_V1 ====
        # ==== VSP_P1_RUNS_CONTRACT_POSTPROCESS_V3 ====
        # Force-buffer response body and rewrite JSON so contract fields definitely appear.
        try:
            import json as _json
            import os as _os
            from flask import request as _req
            if (_req.path or "") == "/api/vsp/runs":
                try:
                    resp.direct_passthrough = False
                except Exception:
                    pass
        
                _raw = resp.get_data()  # this buffers even if response was streamed
                _txt = (_raw.decode("utf-8", "replace") if isinstance(_raw, (bytes, bytearray)) else str(_raw))
                _data = _json.loads(_txt)
                if isinstance(_data, dict) and _data.get("ok") is True and isinstance(_data.get("items"), list):
                    # effective limit: requested (cap)
                    try:
                        _lim_req = int((_req.args.get("limit") or "50").strip())
                    except Exception:
                        _lim_req = 50
                    _hard_cap = 120
                    _lim_eff = max(1, min(_lim_req, _hard_cap))
                    _data["limit"] = _lim_eff
        
                    items = _data.get("items") or []
                    rid_latest = ""
                    if items:
                        try:
                            rid_latest = (items[0].get("run_id") or items[0].get("rid") or "").strip()
                        except Exception:
                            rid_latest = ""
                    _data["rid_latest"] = rid_latest
        
                    try:
                        _data["cache_ttl"] = int(_os.environ.get("VSP_RUNS_CACHE_TTL", "2"))
                    except Exception:
                        _data["cache_ttl"] = 2
        
                    # roots_used best-effort: expose env if exists (helps debug why items is empty)
                    roots_used = []
                    for k in ("VSP_RUNS_ROOTS", "VSP_DATA_ROOTS", "RUNS_ROOTS"):
                        v = _os.environ.get(k, "").strip()
                        if v:
                            roots_used = [x.strip() for x in v.split(":") if x.strip()]
                            break
                    _data["roots_used"] = roots_used
        
                    try:
                        scanned = int(_data.get("_scanned") or 0)
                    except Exception:
                        scanned = 0
                    scan_cap = int(_data.get("_scan_cap") or 500)
                    _data["scan_cap"] = scan_cap
                    _data["scan_cap_hit"] = bool(scanned >= scan_cap)
        
                    _out = _json.dumps(_data, ensure_ascii=False)
                    resp.set_data(_out.encode("utf-8"))
                    resp.headers["Content-Length"] = str(len(resp.get_data()))
                    resp.headers["X-VSP-RUNS-CONTRACT"] = "P1_V3"
        except Exception:
            pass
        # ==== /VSP_P1_RUNS_CONTRACT_POSTPROCESS_V3 ====
        resp.headers["X-VSP-RUNS-HAS"] = "VSP_RUNS_HAS_DETECT_P0_V1"
        return resp
    except Exception:
        return resp

# --- /VSP_RUNS_HAS_DETECT_P0_V1 ---


# --- VSP_RUNS_PAGE_NEVER_500_P0_V1 ---
# Commercial guard: /runs must never return 500 (fallback HTML + link to JSON).
from flask import request, Response
import json as _vsp_json
import html as _vsp_html
import traceback as _vsp_tb

@app.errorhandler(500)
def _vsp_err_500_runs_only(e):
    try:
        if request.path != "/runs":
            # keep normal 500 behavior for other endpoints
            return ("Internal Server Error", 500)
        # Build minimal HTML using the already-working JSON API
        items = []
        try:
            with app.test_client() as c:
                r = c.get("/api/vsp/runs?limit=50")
                if r.status_code == 200:
                    data = r.get_json(silent=True) or {}
                    items = data.get("items") or []
        except Exception:
            items = []

        rows = []
        for it in items[:50]:
            rid = str(it.get("run_id") or "")
            mtime_h = str(it.get("mtime_h") or "")
            path = str(it.get("path") or "")
            # safe link: open run dir (if you later wire /api/vsp/run_file)
            rows.append(
                "<tr>"
                f"<td>{_vsp_html.escape(rid)}</td>"
                f"<td>{_vsp_html.escape(mtime_h)}</td>"
                f"<td style='font-family:monospace'>{_vsp_html.escape(path)}</td>"
                "</tr>"
            )

        body = (
            "<!doctype html><html><head><meta charset='utf-8'>"
            "<title>Runs & Reports</title>"
            "<style>"
            "body{background:#0b1220;color:#e5e7eb;font:14px/1.4 system-ui,Segoe UI,Arial;padding:18px}"
            "a{color:#60a5fa} table{border-collapse:collapse;width:100%;margin-top:10px}"
            "th,td{border:1px solid #1f2937;padding:8px;vertical-align:top}"
            "th{background:#111827;text-align:left}"
            ".muted{color:#9ca3af}"
            "</style></head><body>"
            "<h2>Runs & Reports</h2>"
            "<div class='muted'>Fallback mode: UI template errored. JSON API is OK.</div>"
            "<div style='margin-top:8px'>"
            "<a href='/api/vsp/runs?limit=50'>Open /api/vsp/runs JSON</a>"
            "</div>"
            "<table><thead><tr><th>run_id</th><th>mtime</th><th>path</th></tr></thead><tbody>"
            + "".join(rows) +
            "</tbody></table>"
            "</body></html>"
        )
        return Response(body, status=200, headers={"X-VSP-RUNS-PAGE-FALLBACK": MARK}, mimetype="text/html")
    except Exception:
        # last resort: still avoid 500 on /runs
        tb = _vsp_tb.format_exc()
        body = "<pre>" + _vsp_html.escape(tb[-4000:]) + "</pre>"
        return Response(body, status=200, headers={"X-VSP-RUNS-PAGE-FALLBACK": MARK}, mimetype="text/html")

# --- /VSP_RUNS_PAGE_NEVER_500_P0_V1 ---


# === VSP_WSGI_STATUSV2_ALWAYS8_V3 ===
# Post-process /api/vsp/run_status_v2/* JSON at WSGI layer to always expose 8 tool lanes.
import json

def _vsp_build_tools_always8_v3(out: dict) -> dict:
    CANON = ["SEMGREP","GITLEAKS","TRIVY","CODEQL","KICS","GRYPE","SYFT","BANDIT"]
    ZERO = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0}
    # VSP_P1_GW_RUNFILE_ANCHOR_ALLOW_SHA_V3: allow reports/SHA256SUMS.txt BEFORE any allowlist/proxy
    try:
        from flask import request as _req, send_file as _send_file, jsonify as _jsonify
        _rid = (_req.args.get("rid","") or _req.args.get("run_id","") or _req.args.get("run","") or "").strip()
        _rel = (_req.args.get("name","") or _req.args.get("path","") or _req.args.get("rel","") or "").strip().lstrip("/")
        if _rid and _rel == "reports/SHA256SUMS.txt":
            from pathlib import Path as _P
            for _root in (
                _P("/home/test/Data/SECURITY_BUNDLE/out"),
                _P("/home/test/Data/SECURITY_BUNDLE/out_ci"),
                _P("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
                _P("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            ):
                _fp = _root / _rid / "reports" / "SHA256SUMS.txt"
                if _fp.exists():
                    return _send_file(str(_fp), as_attachment=True)
            return _jsonify({"ok": False, "error": "NO_FILE"}), 404
    except Exception:
        pass


    def norm_counts(c):
        d = dict(ZERO)
        if isinstance(c, dict):
            for k,v in c.items():
                kk = str(k).upper()
                if kk in d:
                    try: d[kk] = int(v)
                    except Exception: d[kk] = 0
        return d

    def mk(tool, has_key=None, total_key=None, verdict_key=None, counts_key=None, reason_missing="missing_fields"):
        hasv = out.get(has_key) if has_key else None
        try: hasv = bool(hasv) if has_key else None
        except Exception: hasv = None

        total = out.get(total_key, 0) if total_key else 0
        verdict = out.get(verdict_key) if verdict_key else None
        counts = norm_counts(out.get(counts_key, {})) if counts_key else dict(ZERO)

        if has_key and hasv is False:
            return {"tool":tool,"status":"NOT_RUN","verdict":"NOT_RUN","total":0,"counts":dict(ZERO),"reason":"has_flag_false"}

        if verdict is None and (not total) and counts == ZERO:
            return {"tool":tool,"status":"NOT_RUN","verdict":"NOT_RUN","total":0,"counts":dict(ZERO),"reason":reason_missing}

        vv = str(verdict).upper() if verdict is not None else "OK"
        try: total_i = int(total)
        except Exception: total_i = 0
        return {"tool":tool,"status":vv,"verdict":vv,"total":total_i,"counts":counts}

    tools = {}
    # your current flat keys in status_v2 response
    tools["CODEQL"]   = mk("CODEQL",   "has_codeql",   "codeql_total",   "codeql_verdict",   None)
    tools["GITLEAKS"] = mk("GITLEAKS", "has_gitleaks", "gitleaks_total", "gitleaks_verdict", "gitleaks_counts")
    tools["SEMGREP"]  = mk("SEMGREP",  "has_semgrep",  "semgrep_total",  "semgrep_verdict",  "semgrep_counts")
    tools["TRIVY"]    = mk("TRIVY",    "has_trivy",    "trivy_total",    "trivy_verdict",    "trivy_counts")

    # no converters yet -> NOT_RUN but lane must exist
    for t in ["KICS","GRYPE","SYFT","BANDIT"]:
        tools[t] = {"tool":t,"status":"NOT_RUN","verdict":"NOT_RUN","total":0,"counts":dict(ZERO),"reason":"no_converter_yet"}

    out["tools"] = tools
    out["tools_order"] = CANON

    gs = out.get("run_gate_summary")
    if not isinstance(gs, dict):
        gs = {}
    for t in CANON:
        if t not in gs:
            gs[t] = {"tool":t,"verdict": tools[t].get("verdict","NOT_RUN"), "total": tools[t].get("total",0)}
    out["run_gate_summary"] = gs
    return out

def _vsp_wrap_statusv2_always8_v3(app):
    def _app(environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if not path.startswith("/api/vsp/run_status_v2/"):
            return app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = headers
            captured["exc"] = exc_info
            return lambda x: None

        res_iter = app(environ, _sr)
        try:
            body = b"".join(res_iter or [])
        finally:
            try:
                close = getattr(res_iter, "close", None)
                if callable(close): close()
            except Exception:
                pass

        headers = captured["headers"] or []
        ctype = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ctype = str(v)
                break

        if "application/json" not in ctype.lower():
            start_response(captured["status"] or "200 OK", headers, captured["exc"])
            return [body]

        try:
            out = json.loads((body.decode("utf-8", errors="ignore") or "{}"))
            if isinstance(out, dict) and (out.get("tools") is None):
                out = _vsp_build_tools_always8_v3(out)
                new_body = json.dumps(out, ensure_ascii=False).encode("utf-8")

                new_headers = []
                for k,v in headers:
                    if str(k).lower() == "content-length":
                        continue
                    new_headers.append((k,v))
                new_headers.append(("Content-Length", str(len(new_body))))

                start_response(captured["status"] or "200 OK", new_headers, captured["exc"])
                return [new_body]
        except Exception:
            pass

        start_response(captured["status"] or "200 OK", headers, captured["exc"])
        return [body]
    return _app

# Wrap if 'application' exists (gunicorn uses wsgi_vsp_ui_gateway:application)
try:
    application.wsgi_app = _vsp_wrap_statusv2_always8_v3(application.wsgi_app)
except Exception:
    pass



# === VSP_RULE_OVERRIDES_FORCE_BIND_V1 BEGIN ===
import json as _json
from pathlib import Path as _Path
from datetime import datetime as _dt, timezone as _tz
import os as _os
import tempfile as _tempfile

_VSP_RULE_OVR_PATH = _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/vsp_rule_overrides_v1.json")

def _vsp_rule_ovr_default_v1():
    return {"meta":{"version":"v1","updated_at":None},"overrides":[]}

def _vsp_rule_ovr_atomic_write_v1(path:_Path, obj:dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = _tempfile.mkstemp(prefix=path.name+".", dir=str(path.parent))
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as f:
            _json.dump(obj, f, ensure_ascii=False, indent=2)
        _os.replace(tmp, str(path))
    finally:
        try:
            _os.unlink(tmp)
        except Exception:
            pass

class VSPRuleOverridesForceBindV1:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/rule_overrides_v1"):
            return self.app(environ, start_response)

        method = (environ.get("REQUEST_METHOD") or "GET").upper()
        try:
            if method == "GET":
                if _VSP_RULE_OVR_PATH.exists():
                    try:
                        data = _json.load(open(_VSP_RULE_OVR_PATH, "r", encoding="utf-8"))
                    except Exception:
                        data = _vsp_rule_ovr_default_v1()
                else:
                    data = _vsp_rule_ovr_default_v1()

                body = _json.dumps(data, ensure_ascii=False).encode("utf-8")
                hdrs = [
                    ("Content-Type","application/json; charset=utf-8"),
                    ("Content-Length", str(len(body))),
                    ("Cache-Control","no-cache"),
                    ("X-VSP-RULE-OVERRIDES-MODE","FORCE_BIND_V1"),
                ]
                start_response("200 OK", hdrs)
                return [body]

            if method == "POST":
                try:
                    n = int(environ.get("CONTENT_LENGTH") or "0")
                except Exception:
                    n = 0
                raw = environ["wsgi.input"].read(n) if n > 0 else b"{}"
                obj = _json.loads(raw.decode("utf-8", errors="replace") or "{}")
                if not isinstance(obj, dict):
                    obj = _vsp_rule_ovr_default_v1()
                obj.setdefault("meta", {})
                obj["meta"]["updated_at"] = _dt.now(_tz.utc).isoformat()
                _vsp_rule_ovr_atomic_write_v1(_VSP_RULE_OVR_PATH, obj)

                out = {"ok": True, "file": str(_VSP_RULE_OVR_PATH), "mode":"FORCE_BIND_V1"}
                body = _json.dumps(out, ensure_ascii=False).encode("utf-8")
                hdrs = [
                    ("Content-Type","application/json; charset=utf-8"),
                    ("Content-Length", str(len(body))),
                    ("Cache-Control","no-cache"),
                    ("X-VSP-RULE-OVERRIDES-MODE","FORCE_BIND_V1"),
                ]
                start_response("200 OK", hdrs)
                return [body]

            body = b'{"ok":false,"error":"METHOD_NOT_ALLOWED"}'
            start_response("405 Method Not Allowed", [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
            ])
            return [body]
        except Exception as e:
            body = _json.dumps({"ok":False,"error":"RULE_OVERRIDES_FORCE_BIND_ERR","detail":str(e)}, ensure_ascii=False).encode("utf-8")
            start_response("500 Internal Server Error", [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
                ("X-VSP-RULE-OVERRIDES-MODE","FORCE_BIND_V1"),
            ])
            return [body]
# === VSP_RULE_OVERRIDES_FORCE_BIND_V1 END ===


# VSP_RULE_OVERRIDES_FORCE_BIND_V1 WRAP

# === VSP_GATEWAY_INJECT_FILLREAL_WSGI_MW_P1_V3 ===
import re as _re

class _VspHtmlInjectMw:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        captured = {"status": None, "headers": None, "exc": None}

        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers) if headers else []
            captured["exc"] = exc_info
            # delay calling real start_response until we possibly rewrite body
            return None

        app_iter = self.app(environ, _sr)

        try:
            body_chunks = []
            for chunk in app_iter:
                if chunk:
                    body_chunks.append(chunk)
            body = b"".join(body_chunks)
        finally:
            try:
                close = getattr(app_iter, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        headers = captured["headers"] or []
        ct = ""
        for (k,v) in headers:
            if str(k).lower() == "content-type":
                ct = str(v).lower()
                break

        # only touch HTML
        if "text/html" in ct and body:
            try:
                html = body.decode("utf-8", errors="replace")
                if ("vsp_fill_real_data_5tabs_p1_v1.js" not in html) and ("VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY" not in html) and ("VSP_RUNS_STANDALONE_HARDFIX_P0_V2" not in html) and ("VSP_RUNS_PAGE_FACTORY_RESET_STATIC_P0_V1" not in html) and (not _vsp_is_runs_path(environ)):  # VSP_P0_SKIP_FILLREAL_ON_RUNS_MARKER_V1
                    tag = (
                        "\n<!-- VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                        "<script src='/static/js/vsp_fill_real_data_5tabs_p1_v1.js'></script>\n"
                        "<!-- /VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                    )
                    if "</body>" in html:
                        html = html.replace("</body>", tag + "</body>")
                    elif "</html>" in html:
                        html = html.replace("</html>", tag + "</html>")
                    else:
                        html = html + tag
                    body = html.encode("utf-8")

                    # drop Content-Length (recomputed)
                    headers = [(k,v) for (k,v) in headers if str(k).lower() != "content-length"]
                    headers.append(("Content-Length", str(len(body))))
            except Exception:
                pass

        # now start response
        start_response(captured["status"] or "200 OK", headers, captured["exc"])
        return [body]
# === /VSP_GATEWAY_INJECT_FILLREAL_WSGI_MW_P1_V3 ===

application.wsgi_app = VSPRuleOverridesForceBindV1(application.wsgi_app)

# === VSP_API_REPORTS_LATEST_COMPAT_P0_V1 ===
def _vsp__find_latest_run_with_file(relpath: str) -> str:
    """
    Return RUN_ID (folder basename) of newest out/RUN_* that contains relpath.
    relpath examples: 'reports/index.html' or 'reports/run_gate_summary.json'
    """
    base = Path("/home/test/Data/SECURITY_BUNDLE/out")
    if not base.exists():
        return ""
    # newest first by mtime
    runs = sorted(base.glob("RUN_*"), key=lambda x: x.stat().st_mtime, reverse=True)
    for rd in runs[:200]:
        try:
            fp = rd / relpath
            if fp.is_file():
                return rd.name
        except Exception:
            continue
    return ""
# [DISABLED] application is WSGI wrapper (no .route). Bound later via app.add_url_rule
def vsp_api_reports_latest(name):
    # compat endpoint: serve latest run's report file via run_file contract
    # /api/reports/run_gate_summary.json  -> reports/run_gate_summary.json
    rel = name
    if not rel.startswith("reports/"):
        rel = "reports/" + rel

    rid = _vsp__find_latest_run_with_file(rel)
    if not rid:
        return ("Not Found", 404)

    # redirect to commercial contract endpoint
    url = "/api/vsp/run_file?rid=" + quote(rid) + "&name=" + quote(rel)
    return ("", 302, {"Location": url})




# === VSP_RUN_STATUS_V2_GUARD_V1 BEGIN ===
import json as _json
from datetime import datetime as _dt, timezone as _tz
import traceback as _tb

class VSPRunStatusV2GuardV1:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/run_status_v2/"):
            return self.app(environ, start_response)

        # normalize rid in PATH_INFO
        try:
            rid = path.split("/api/vsp/run_status_v2/", 1)[1]
        except Exception:
            rid = ""
        rid = (rid or "").strip()
        rid_norm = rid[4:] if rid.startswith("RUN_") else rid

        # rewrite path if needed
        if rid_norm != rid:
            environ = dict(environ)
            environ["PATH_INFO"] = "/api/vsp/run_status_v2/" + rid_norm

        try:
            return self.app(environ, start_response)
        except Exception as e:
            payload = {
                "ok": False,
                "status": "ERROR",
                "final": True,
                "http_code": 500,
                "error": "RUN_STATUS_V2_EXCEPTION_GUARDED",
                "rid": rid,
                "rid_norm": rid_norm,
                "detail": str(e),
                "ts_utc": _dt.now(_tz.utc).isoformat(),
            }
            body = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
            hdrs = [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
                ("Cache-Control","no-cache"),
                ("X-VSP-RUNSTATUSV2-MODE","GUARD_V1"),
            ]
            start_response("200 OK", hdrs)
            return [body]
# === VSP_RUN_STATUS_V2_GUARD_V1 END ===


# VSP_RUN_STATUS_V2_GUARD_V1 WRAP
application.wsgi_app = VSPRunStatusV2GuardV1(application.wsgi_app)


# === VSP_WSGI_STATUS_CONTRACT_MW_P1_V1_BEGIN ===
import os, json, re
from pathlib import Path

# VSP_HARDEN_MARK_P0_V2
# (P0_V8C) disabled legacy MARK reassignment
MARKB = MARKB


# VSP_GLOBAL_MARK_FIX_P0_V1
# (P0_V8C) disabled legacy MARK reassignment
def _vsp_read_json(fp):
    try:
        with open(fp, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _vsp_findings_total(run_dir: str):
    if not run_dir:
        return None
    for fn in ("findings_unified.json","reports/findings_unified.json","findings_unified.sarif","findings_unified.sarif.json"):
        fp=os.path.join(run_dir, fn)
        if os.path.isfile(fp):
            j=_vsp_read_json(fp)
            if isinstance(j, dict):
                if isinstance(j.get("total"), int):
                    return j["total"]
                items=j.get("items")
                if isinstance(items, list):
                    return len(items)
    fp=os.path.join(run_dir,"summary_unified.json")
    j=_vsp_read_json(fp) if os.path.isfile(fp) else None
    if isinstance(j, dict):
        t=j.get("total") or j.get("total_findings")
        if isinstance(t, int):
            return t
    return None

def _vsp_degraded_info(run_dir: str):
    if not run_dir:
        return (None, None)
    # prefer runner.log
    cand = os.path.join(run_dir,"runner.log")
    if not os.path.isfile(cand):
        # fallbacks
        for alt in ("kics/kics.log","codeql/codeql.log","trivy/trivy.log"):
            ap=os.path.join(run_dir,alt)
            if os.path.isfile(ap):
                cand=ap; break
        else:
            return (None, None)
    try:
        txt=Path(cand).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return (None, None)

    tools = ["BANDIT","SEMGREP","GITLEAKS","KICS","TRIVY","SYFT","GRYPE","CODEQL"]
    degraded=set()
    for t in tools:
        pats = [
            fr"VSP_{t}_TIMEOUT_DEGRADE",
            fr"\[{t}\].*DEGRADED",
            fr"{t}.*timeout.*degrad",
            fr"{t}.*missing.*degrad",
        ]
        for pat in pats:
            if re.search(pat, txt, flags=re.I):
                degraded.add(t)
                break
    n=len(degraded)
    return (n, n>0)

class VSPStatusContractMWP1V1:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if not path.startswith("/api/vsp/run_status_v2/"):
            return self.app(environ, start_response)

        captured = {"status":"200 OK","headers":[],"exc":None}

        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = headers or []
            captured["exc"] = exc_info
            # delay calling start_response

        it = self.app(environ, _sr)
        try:
            body = b"".join(it)
        finally:
            try:
                it.close()
            except Exception:
                pass

        headers = captured["headers"]
        ctype = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ctype = str(v)
                break

        # only postprocess JSON
        if "application/json" not in ctype.lower():
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        try:
            obj = json.loads(body.decode("utf-8","ignore"))
        except Exception:
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        if not isinstance(obj, dict):
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        rid = path.rsplit("/",1)[-1]
        obj["run_id"] = obj.get("run_id") or rid

        run_dir = obj.get("ci_run_dir") or obj.get("ci")
        if run_dir and os.path.isdir(run_dir):
            t = _vsp_findings_total(run_dir)
            if isinstance(t, int):
                obj["total_findings"] = t
                obj["has_findings"] = True if t > 0 else False

            dn, da = _vsp_degraded_info(run_dir)
            if isinstance(dn, int):
                obj["degraded_n"] = dn
            if isinstance(da, bool):
                obj["degraded_any"] = da

        obj.setdefault("ok", True)

        out = json.dumps(obj, ensure_ascii=False).encode("utf-8")

        # fix content-length
        new_headers=[]
        for k,v in headers:
            if str(k).lower() == "content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(out))))

        start_response(captured["status"], new_headers, captured["exc"])
        return [out]

# wrap if possible
try:
    application.wsgi_app = VSPStatusContractMWP1V1(application.wsgi_app)
except Exception:
    pass
# === VSP_WSGI_STATUS_CONTRACT_MW_P1_V1_END ===


# === VSP_WSGI_RUNS_INDEX_ENRICH_MW_P1_V1_BEGIN ===
import json
import urllib.parse

class VSPRunsIndexEnrichMWP1V1:
    """
    Post-process /api/vsp/runs_index_v3_fs_resolved JSON items by attaching:
      total_findings, has_findings, degraded_n, degraded_any
    derived deterministically from ci_run_dir (no heuristics).
    """
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if path != "/api/vsp/runs_index_v3_fs_resolved":
            return self.app(environ, start_response)

        captured = {"status":"200 OK","headers":[],"exc":None}
        def _sr(status, headers, exc_info=None):
            captured["status"]=status
            captured["headers"]=headers or []
            captured["exc"]=exc_info

        it = self.app(environ, _sr)
        try:
            body = b"".join(it)
        finally:
            try: it.close()
            except Exception: pass

        headers = captured["headers"]
        ctype=""
        for k,v in headers:
            if str(k).lower()=="content-type":
                ctype=str(v); break
        if "application/json" not in ctype.lower():
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        try:
            obj=json.loads(body.decode("utf-8","ignore"))
        except Exception:
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        if not isinstance(obj, dict):
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        items = obj.get("items")
        if not isinstance(items, list):
            start_response(captured["status"], headers, captured["exc"])
            return [body]

        # cap enrich to avoid heavy IO if someone requests huge limit
        qs = environ.get("QUERY_STRING","") or ""
        q = urllib.parse.parse_qs(qs)
        try:
            limit = int((q.get("limit") or ["50"])[0])
        except Exception:
            limit = 50
        hard_cap = 120
        n = min(len(items), min(limit, hard_cap))

        for i in range(n):
            it0 = items[i]
            if not isinstance(it0, dict):
                continue
            run_dir = it0.get("ci_run_dir") or it0.get("ci") or None
            if not run_dir:
                continue
            try:
                # reuse helpers from status MW (already injected earlier)
                t = _vsp_findings_total(run_dir)
                if isinstance(t, int):
                    it0["total_findings"] = t
                    it0["has_findings"] = True if t>0 else False
                dn, da = _vsp_degraded_info(run_dir)
                if isinstance(dn, int):
                    it0["degraded_n"] = dn
                if isinstance(da, bool):
                    it0["degraded_any"] = da
            except Exception:
                pass

        out=json.dumps(obj, ensure_ascii=False).encode("utf-8")

        new_headers=[]
        for k,v in headers:
            if str(k).lower()=="content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(out))))

        start_response(captured["status"], new_headers, captured["exc"])
        return [out]

try:
    application.wsgi_app = VSPRunsIndexEnrichMWP1V1(application.wsgi_app)
except Exception:
    pass
# === VSP_WSGI_RUNS_INDEX_ENRICH_MW_P1_V1_END ===


# === VSP_WSGI_FINDINGS_UNIFIED_API_P1_V1 (commercial) ===
# Ensure /api/vsp/findings_unified_v1/<rid> is registered on the ACTUAL gunicorn "application"
import os, json, glob
from flask import request, jsonify

VSP_UIREQ_DIR = os.environ.get("VSP_UIREQ_DIR", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")
VSP_CI_OUT_GLOB = os.environ.get("VSP_CI_OUT_GLOB", "/home/test/Data/**/out_ci/VSP_CI_*")

_SEV_W = {"CRITICAL": 50, "HIGH": 40, "MEDIUM": 30, "LOW": 20, "INFO": 10, "TRACE": 0}
def _sev_w(x): return _SEV_W.get((x or "").upper(), -1)

def _read_json(path):
  try:
    with open(path, "r", encoding="utf-8") as f:
      return json.load(f)
  except Exception:
    return None

def _resolve_run_dir_from_rid(rid: str):
  st = _read_json(os.path.join(VSP_UIREQ_DIR, f"{rid}.json")) or {}
  for k in ("ci_run_dir","ci_run_dir_resolved","run_dir","RUN_DIR"):
    v = st.get(k)
    if isinstance(v,str) and v.strip():
      return v.strip(), "uireq_state"
  cands=[]
  for d in glob.glob(VSP_CI_OUT_GLOB, recursive=True):
    if rid in (os.path.basename(d) or "") or rid in d:
      cands.append(d)
  cands = sorted(set(cands), key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)
  if cands: return cands[0], "scan_out_ci"
  return None, "not_found"

def _apply_filters(items, q=None, sev=None, tool=None, cwe=None, fileq=None):
  q=(q or "").strip().lower(); fileq=(fileq or "").strip().lower()
  sev=(sev or "").strip().upper(); tool=(tool or "").strip().lower(); cwe=(cwe or "").strip().upper()
  out=[]
  for it in items or []:
    t=(it.get("title") or "")
    f=(it.get("file") or "")
    sv=(it.get("severity") or "").upper()
    tl=(it.get("tool") or "").lower()
    cw=it.get("cwe")
    c=""
    if isinstance(cw,list) and cw: c=str(cw[0] or "").upper()
    elif isinstance(cw,str): c=cw.upper()
    if sev and sv!=sev: continue
    if tool and tool!=tl: continue
    if cwe and cwe!=c: continue
    if fileq and fileq not in f.lower(): continue
    if q:
      hay=(t+" "+f+" "+(it.get("id") or "")).lower()
      if q not in hay: continue
    out.append(it)
  return out

# avoid double-register if hot reload
try:
  _has = any(getattr(r, "rule", "")=="/api/vsp/findings_unified_v1/<rid>" for r in app.url_map.iter_rules())
except Exception:
  _has = False

if not _has:
  @app.route("/api/vsp/findings_unified_v1/<rid>", methods=["GET"])
  def api_vsp_findings_unified_v1(rid):
    page=int(request.args.get("page","1") or "1")
    limit=int(request.args.get("limit","50") or "50")
    page=1 if page<1 else page
    limit=50 if limit<1 else (500 if limit>500 else limit)

    q=request.args.get("q"); sev=request.args.get("sev"); tool=request.args.get("tool")
    cwe=request.args.get("cwe"); fileq=request.args.get("file")

    run_dir, src = _resolve_run_dir_from_rid(rid)
    if not run_dir:
      return jsonify({"ok":False,"warning":"run_dir_not_found","rid":rid,"resolve_source":src,"total":0,"items":[]}), 200

    fp=os.path.join(run_dir,"findings_unified.json")
    data=_read_json(fp)
    if not data or not isinstance(data,dict):
      return jsonify({"ok":True,"warning":"findings_unified_not_found_or_bad","rid":rid,"resolve_source":src,"run_dir":run_dir,"file":fp,"total":0,"items":[]}), 200

    items=data.get("items") or []
    items=_apply_filters(items,q=q,sev=sev,tool=tool,cwe=cwe,fileq=fileq)


    # === VSP_CWE_SAFE_GRYE_V2 ===
    # Fill item.cwe from item.raw.vulnerability.cwes[*].cwe (GRYPE)
    try:
      for _it in (items or []):
        if _it.get("cwe"):
          continue
        if str(_it.get("tool") or "").upper() != "GRYPE":
          continue
        _raw = _it.get("raw") or {}
        _vuln = _raw.get("vulnerability") or {}
        _cwes = _vuln.get("cwes") or []
        _out = []
        for _c in _cwes:
          _v = _c.get("cwe") if isinstance(_c, dict) else _c
          if not _v:
            continue
          _v = str(_v).strip()
          if not _v:
            continue
          if (not _v.upper().startswith("CWE-")) and _v.isdigit():
            _v = "CWE-" + _v
          _out.append(_v.upper())
        if _out:
          _it["cwe"] = list(dict.fromkeys(_out))
    except Exception:
      pass
    # === /VSP_CWE_SAFE_GRYE_V2 ===

    # === VSP_CWE_ENRICH_FROM_ITEM_RAW_V1 ===
    # Fill item.cwe from item.raw.vulnerability.cwes[*].cwe (GRYPE proven has this)
    try:
      for _it in items or []:
        if _it.get("cwe"):
          continue
        _raw = _it.get("raw") or {}
        _vuln = _raw.get("vulnerability") or {}
        _cwes = _vuln.get("cwes") or []
        _out = []
        for _c in _cwes:
          _v = _c.get("cwe") if isinstance(_c, dict) else _c
          if not _v:
            continue
          _v = str(_v).strip()
          if not _v:
            continue
          if (not _v.upper().startswith("CWE-")) and _v.isdigit():
            _v = "CWE-" + _v
          _out.append(_v.upper())
        if _out:
          _it["cwe"] = list(dict.fromkeys(_out))
    except Exception:
      pass
    # === /VSP_CWE_ENRICH_FROM_ITEM_RAW_V1 ===

    # enrich CWE from GRYPE raw file (safe; unified items may not carry raw)
    grype_map = _build_grype_cwe_map(run_dir)
    if grype_map:
      try:
        items = [_maybe_set_cwe_from_grype(dict(it), grype_map) for it in items]
      except Exception:
        pass

    # VSP_P1_FIX_RUNS_AND_SHA256SUMS_V1 skip meta dirs
    items = [x for x in items if (x.get("run_id")!="A2Z_INDEX")]
    items.sort(key=lambda it: (-_sev_w(it.get("severity")), (it.get("tool") or ""), (it.get("file") or ""), int(it.get("line") or 0)))
    total=len(items)
    start=(page-1)*limit; end=start+limit
    page_items=items[start:end]

    by_sev={}; by_tool={}; by_cwe={}
    for it in items:
      sv=(it.get("severity") or "UNKNOWN").upper()
      tl=(it.get("tool") or "UNKNOWN")
      cws = _vsp_extract_cwe_list(it)
      if cws and not it.get('cwe'):
        it['cwe'] = cws
      c = (str(cws[0]).upper() if cws else 'UNKNOWN')
      by_sev[sv]=by_sev.get(sv,0)+1
      by_tool[tl]=by_tool.get(tl,0)+1
      by_cwe[c]=by_cwe.get(c,0)+1
    unknown_count = by_cwe.get("UNKNOWN", 0)
    top_cwe = sorted([(k,v) for (k,v) in by_cwe.items() if k!="UNKNOWN"], key=lambda kv: kv[1], reverse=True)[:10]

    return jsonify({
      "ok":True,"rid":rid,"run_dir":run_dir,"resolve_source":src,"file":fp,
      "page":page,"limit":limit,"total":total,
      "counts":{"by_sev":by_sev,"by_tool":by_tool,"top_cwe":top_cwe},
      "items":page_items,
      "filters":{"q":q,"sev":sev,"tool":tool,"cwe":cwe,"file":fileq},
    }), 200
# === /VSP_WSGI_FINDINGS_UNIFIED_API_P1_V1 ===


# --- VSP_CWE_ENRICH_FROM_GRYPE_P1_V2 ---
import re as _re

_CVE_RE = _re.compile(r'(CVE-\d{4}-\d+)', _re.I)

def _build_grype_cwe_map(run_dir):
  """Return {CVE-xxxx-yyy: [CWE-79, ...]} from run_dir/grype/grype.json if exists."""
  try:
    fp = os.path.join(run_dir, "grype", "grype.json")
    j = _read_json(fp)
    if not j or not isinstance(j, dict):
      return {}
    out = {}
    for m in (j.get("matches") or []):
      vuln = (m.get("vulnerability") or {})
      vid = (vuln.get("id") or "").strip()
      if not vid:
        continue
      cwes = []
      for c in (vuln.get("cwes") or []):
        cwe = (c.get("cwe") or "").strip()
        if cwe:
          if not cwe.upper().startswith("CWE-") and cwe.isdigit():
            cwe = "CWE-" + cwe
          cwes.append(cwe)
      if cwes:
        out[vid.upper()] = list(dict.fromkeys(cwes))
    return out
  except Exception:
    return {}

def _maybe_set_cwe_from_grype(it, grype_map):
  if it.get("cwe"):
    return it
  tool = (it.get("tool") or "").upper()
  if tool != "GRYPE":
    return it
  cand = (it.get("id") or "").strip()
  if not cand:
    # try parse CVE from title
    t = (it.get("title") or "")
    m = _CVE_RE.search(t or "")
    cand = m.group(1) if m else ""
  cand = (cand or "").upper()
  if cand and cand in grype_map:
    it["cwe"] = grype_map[cand]
  return it
# --- /VSP_CWE_ENRICH_FROM_GRYPE_P1_V2 ---


# --- VSP_CWE_FROM_RAW_ITEMS_P1_V3 ---
def _vsp_norm_cwe(x):
  try:
    x = str(x or "").strip()
    if not x:
      return None
    u = x.upper()
    if u.startswith("CWE-"):
      return u
    if x.isdigit():
      return "CWE-" + x
    return u
  except Exception:
    return None

def _vsp_extract_cwe_list(it):
  """Best-effort CWE extraction from unified item or item.raw.
  Works for GRYPE (raw.vulnerability.cwes) and some SARIF/CodeQL shapes.
  """
  try:
    # 1) already normalized in item.cwe
    cw = it.get("cwe")
    if isinstance(cw, list) and cw:
      out=[]
      for v in cw:
        nv=_vsp_norm_cwe(v)
        if nv: out.append(nv)
      if out: return list(dict.fromkeys(out))
    if isinstance(cw, str) and cw.strip():
      nv=_vsp_norm_cwe(cw)
      return [nv] if nv else None

    raw = it.get("raw") or {}

    # 2) GRYPE: raw.vulnerability.cwes[*].cwe
    vuln = raw.get("vulnerability") or {}
    cwes = vuln.get("cwes") or []
    out=[]
    for c in cwes:
      if isinstance(c, dict):
        nv=_vsp_norm_cwe(c.get("cwe"))
      else:
        nv=_vsp_norm_cwe(c)
      if nv: out.append(nv)
    if out: return list(dict.fromkeys(out))

    # 3) relatedVulnerabilities[*].cwes[*].cwe (some feeds)
    rv = raw.get("relatedVulnerabilities") or []
    out=[]
    for v in rv:
      for c in (v.get("cwes") or []):
        nv=_vsp_norm_cwe((c.get("cwe") if isinstance(c, dict) else c))
        if nv: out.append(nv)
    if out: return list(dict.fromkeys(out))

    # 4) SARIF-ish: raw.rule.properties.cwe or raw.properties.cwe
    for path in [
      ("rule","properties","cwe"),
      ("properties","cwe"),
      ("rule","cwe"),
      ("cwe",),
    ]:
      cur = raw
      ok=True
      for k in path:
        if isinstance(cur, dict) and k in cur:
          cur = cur[k]
        else:
          ok=False; break
      if ok and cur:
        if isinstance(cur, list) and cur:
          nv=_vsp_norm_cwe(cur[0])
          return [nv] if nv else None
        nv=_vsp_norm_cwe(cur)
        return [nv] if nv else None
  except Exception:
    pass
  return None
# --- /VSP_CWE_FROM_RAW_ITEMS_P1_V3 ---


# === VSP_FINDINGS_UNIFIED_V2_ENRICHED_V1 ===
# New endpoint (non-invasive): /api/vsp/findings_unified_v2/<rid>
# Goal: commercial-safe enrichment (CWE from item.raw) + stable counts/top_cwe.
import os, json, glob
from flask import request, jsonify

VSP_UIREQ_DIR = os.environ.get("VSP_UIREQ_DIR", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")
VSP_CI_OUT_GLOB = os.environ.get("VSP_CI_OUT_GLOB", "/home/test/Data/**/out_ci/VSP_CI_*")

_SEV_W = {"CRITICAL": 50, "HIGH": 40, "MEDIUM": 30, "LOW": 20, "INFO": 10, "TRACE": 0}
def _sev_w(x): return _SEV_W.get((x or "").upper(), -1)

def _read_json(path):
  try:
    with open(path, "r", encoding="utf-8") as f:
      return json.load(f)
  except Exception:
    return None

def _resolve_run_dir_from_rid(rid: str):
  st = _read_json(os.path.join(VSP_UIREQ_DIR, f"{rid}.json")) or {}
  for k in ("ci_run_dir","ci_run_dir_resolved","run_dir","RUN_DIR"):
    v = st.get(k)
    if isinstance(v, str) and v.strip():
      return v.strip(), "uireq_state"
  cands=[]
  for d in glob.glob(VSP_CI_OUT_GLOB, recursive=True):
    if rid in (os.path.basename(d) or "") or rid in d:
      cands.append(d)
  cands = sorted(set(cands), key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)
  if cands:
    return cands[0], "scan_out_ci"
  return None, "not_found"

def _norm_cwe(v):
  try:
    v = str(v or "").strip()
    if not v: return None
    u = v.upper()
    if u.startswith("CWE-"): return u
    if v.isdigit(): return "CWE-" + v
    return u
  except Exception:
    return None

def _extract_cwe_list(it):
  # Prefer item.cwe
  cw = it.get("cwe")
  out=[]
  if isinstance(cw, list):
    for x in cw:
      nx = _norm_cwe(x)
      if nx: out.append(nx)
  elif isinstance(cw, str):
    nx=_norm_cwe(cw)
    if nx: out.append(nx)
  if out:
    return list(dict.fromkeys(out))

  # Fallback: item.raw.* (GRYPE proven here)
  raw = it.get("raw") or {}
  vuln = (raw.get("vulnerability") or {})
  cwes = vuln.get("cwes") or []
  out=[]
  for c in cwes:
    v = c.get("cwe") if isinstance(c, dict) else c
    nx=_norm_cwe(v)
    if nx: out.append(nx)
  if out:
    return list(dict.fromkeys(out))

  rv = raw.get("relatedVulnerabilities") or []
  out=[]
  for vv in rv:
    for c in (vv.get("cwes") or []):
      v = c.get("cwe") if isinstance(c, dict) else c
      nx=_norm_cwe(v)
      if nx: out.append(nx)
  if out:
    return list(dict.fromkeys(out))

  # SARIF-ish (best-effort)
  for path in [
    ("rule","properties","cwe"),
    ("properties","cwe"),
    ("rule","cwe"),
    ("cwe",),
  ]:
    cur = raw
    ok=True
    for k in path:
      if isinstance(cur, dict) and k in cur:
        cur = cur[k]
      else:
        ok=False; break
    if ok and cur:
      if isinstance(cur, list) and cur:
        nx=_norm_cwe(cur[0])
        return [nx] if nx else None
      nx=_norm_cwe(cur)
      return [nx] if nx else None

  return None

def _apply_filters(items, q=None, sev=None, tool=None, cwe=None, fileq=None):
  q=(q or "").strip().lower()
  fileq=(fileq or "").strip().lower()
  sev=(sev or "").strip().upper()
  tool=(tool or "").strip().lower()
  cwe=(cwe or "").strip().upper()
  out=[]
  for it in items or []:
    t=(it.get("title") or "")
    f=(it.get("file") or "")
    sv=(it.get("severity") or "").upper()
    tl=(it.get("tool") or "").lower()
    cws = _extract_cwe_list(it) or []
    c0 = (str(cws[0]).upper() if cws else "UNKNOWN")

    if sev and sv != sev: 
      continue
    if tool and tool != tl:
      continue
    if cwe and cwe != c0:
      continue
    if fileq and fileq not in f.lower():
      continue
    if q:
      hay=(t+" "+f+" "+(it.get("id") or "")).lower()
      if q not in hay:
        continue

    # ensure item.cwe filled for UI
    if cws and not it.get("cwe"):
      it["cwe"] = cws
    out.append(it)
  return out

@app.route("/api/vsp/findings_unified_v2/<rid>", methods=["GET"])
def api_vsp_findings_unified_v2(rid):
  page = int(request.args.get("page","1") or "1")
  limit = int(request.args.get("limit","50") or "50")
  page = 1 if page < 1 else page
  limit = 50 if limit < 1 else (500 if limit > 500 else limit)

  q = request.args.get("q")
  sev = request.args.get("sev")
  tool = request.args.get("tool")
  cwe = request.args.get("cwe")
  fileq = request.args.get("file")

  run_dir, src = _resolve_run_dir_from_rid(rid)
  if not run_dir:
    return jsonify({
      "ok": False,
      "warning": "run_dir_not_found",
      "rid": rid,
      "resolve_source": src,
      "total": 0,
      "items": [],
    }), 200

  fp = os.path.join(run_dir, "findings_unified.json")
  data = _read_json(fp)
  if not data or not isinstance(data, dict):
    return jsonify({
      "ok": True,
      "warning": "findings_unified_not_found_or_bad",
      "rid": rid,
      "resolve_source": src,
      "run_dir": run_dir,
      "file": fp,
      "total": 0,
      "items": [],
    }), 200

  items = data.get("items") or []
  items = _apply_filters(items, q=q, sev=sev, tool=tool, cwe=cwe, fileq=fileq)

  items.sort(key=lambda it: (-_sev_w(it.get("severity")), (it.get("tool") or ""), (it.get("file") or ""), int(it.get("line") or 0)))
  total = len(items)
  start = (page-1)*limit
  end = start + limit
  page_items = items[start:end]

  by_sev={}; by_tool={}; by_cwe={}
  for it in items:
    sv=(it.get("severity") or "UNKNOWN").upper()
    tl=(it.get("tool") or "UNKNOWN")
    cws = _extract_cwe_list(it) or []
    c0 = (str(cws[0]).upper() if cws else "UNKNOWN")
    by_sev[sv]=by_sev.get(sv,0)+1
    by_tool[tl]=by_tool.get(tl,0)+1
    by_cwe[c0]=by_cwe.get(c0,0)+1

  unknown_count = by_cwe.get("UNKNOWN", 0)
  top_cwe = sorted([(k,v) for (k,v) in by_cwe.items() if k!="UNKNOWN"], key=lambda kv: kv[1], reverse=True)[:10]

  return jsonify({
    "ok": True,
    "rid": rid,
    "run_dir": run_dir,
    "resolve_source": src,
    "file": fp,
    "page": page,
    "limit": limit,
    "total": total,
    "counts": {
      "by_sev": by_sev,
      "by_tool": by_tool,
      "top_cwe": top_cwe,
      "unknown_count": unknown_count
    },
    "items": page_items,
    "filters": {"q": q, "sev": sev, "tool": tool, "cwe": cwe, "file": fileq},
    "debug": ({"marker":"VSP_FINDINGS_UNIFIED_V2_ENRICHED_V1","flask_var":"app"} if request.args.get("debug")=="1" else None)
  }), 200
# === /VSP_FINDINGS_UNIFIED_V2_ENRICHED_V1 ===


# === VSP_DASHBOARD_V3_EXTRAS_FROM_V2_P1_V1 ===
@app.route("/api/vsp/dashboard_v3_extras_v1", methods=["GET"])
def api_vsp_dashboard_v3_extras_v1():
  rid = (request.args.get("rid") or "").strip()
  if not rid:
    # fallback: take latest from runs_index if exists
    try:
      j = api_vsp_runs_index_v3_fs_resolved()
      rid = (j.json.get("items") or [{}])[0].get("run_id") or ""
    except Exception:
      rid = ""
  rid = str(rid).strip()

  # call V2 handler directly (same process) for counts
  try:
    # simulate request args for V2: limit=1
    args = request.args.to_dict(flat=True)
    args.pop("rid", None)
    args["limit"]="1"
    # Temporarily patch request.args? (avoid): call function and parse JSON through flask response
    resp = api_vsp_findings_unified_v2(rid)
    # resp may be (response, code)
    if isinstance(resp, tuple):
      resp_obj = resp[0]
    else:
      resp_obj = resp
    data = resp_obj.get_json(silent=True) or {}
  except Exception:
    data = {}

  counts = (data.get("counts") or {})
  by_sev = counts.get("by_sev") or {}
  by_tool = counts.get("by_tool") or {}
  top_cwe = counts.get("top_cwe") or []
  unknown_count = int(counts.get("unknown_count") or 0)
  total = int(data.get("total") or 0)

  # score heuristic (commercial-ish): 100 - weighted findings / scale
  w = 0
  for k,v in by_sev.items():
    k = str(k or "").upper()
    v = int(v or 0)
    if k == "CRITICAL": w += v*50
    elif k == "HIGH": w += v*30
    elif k == "MEDIUM": w += v*15
    elif k == "LOW": w += v*5
    elif k == "INFO": w += v*1
  score = max(0, int(100 - (w/ max(1, 200))))  # scale factor 200

  # degraded/effective (P1): degraded = unknown_count, effective = total-unknown
  degraded = unknown_count
  effective = max(0, total - unknown_count)

  return jsonify({
    "ok": True,
    "rid": rid,
    "kpi": {
      "total": total,
      "effective": effective,
      "degraded": degraded,
      "score": score,
      "by_sev": by_sev,
      "by_tool": by_tool,
      "top_cwe": top_cwe,
      "unknown_count": unknown_count
    },
    "sources": {
      "findings_api": "/api/vsp/findings_unified_v2/<rid>",
      "marker": "VSP_DASHBOARD_V3_EXTRAS_FROM_V2_P1_V1"
    }
  }), 200
# === /VSP_DASHBOARD_V3_EXTRAS_FROM_V2_P1_V1 ===


# === VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2 ===
class VSPRunsExportZipBtnMWP0V2:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path != "/runs":
            return self.app(environ, start_response)

        meta = {}
        def sr(status, headers, exc_info=None):
            meta["status"] = status
            meta["headers"] = headers
            meta["exc_info"] = exc_info
            return lambda _x: None

        app_iter = self.app(environ, sr)

        body = b""
        try:
            for chunk in app_iter:
                if chunk:
                    body += chunk
        finally:
            try:
                close = getattr(app_iter, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        headers = meta.get("headers") or []
        ct = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ct = str(v); break

        # only inject into HTML /runs
        if ("text/html" in ct) and (b"/api/vsp/run_file" in body) and (MARKB not in body):
            js = b"""
<script>
/* VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2 */
(function(){
  'use strict';
  function ridFromHref(href){
    try{
      const u=new URL(href, location.origin);
      if(!u.pathname.includes('/api/vsp/run_file')) return null;
      return u.searchParams.get('run_id');
    }catch(e){return null;}
  }
  function addBtn(a, rid){
    try{
      const row=a.closest('tr')||a.parentElement;
      if(!row) return;
      if(row.querySelector('a[data-vsp-export-zip="1"]')) return;
      const b=document.createElement('a');
      b.textContent='Export ZIP';
      b.href='/api/vsp/export_zip?run_id='+encodeURIComponent(rid);
      b.setAttribute('data-vsp-export-zip','1');
      b.style.marginLeft='8px';
      b.style.textDecoration='none';
      b.style.display='inline-block';
      b.style.padding='7px 10px';
      b.style.borderRadius='10px';
      b.style.fontWeight='800';
      b.style.border='1px solid rgba(90,140,255,.35)';
      b.style.background='rgba(90,140,255,.16)';
      b.style.color='inherit';
      a.insertAdjacentElement('afterend', b);
    }catch(_){}
  }
  function patch(){
    const links=[...document.querySelectorAll('a[href*="/api/vsp/run_file"]')];
    const seen=new Set();
    for(const a of links){
      const rid=ridFromHref(a.getAttribute('href')||'');
      if(!rid) continue;
      const key=rid+'::'+(a.closest('tr')?a.closest('tr').rowIndex:'x');
      if(seen.has(key)) continue;
      seen.add(key);
      addBtn(a,rid);
    }
  }
  patch(); setTimeout(patch,600); setTimeout(patch,1400);
})();
</script>
"""
            if b"</body>" in body:
                body = body.replace(b"</body>", js + b"</body>", 1)
            else:
                body = body + js

        # fix Content-Length
        new_headers=[]
        for k,v in headers:
            if str(k).lower() == "content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(body))))

        start_response(meta.get("status","200 OK"), new_headers, meta.get("exc_info"))
        return [body]

try:
    if "application" in globals():
        _a = globals().get("application")
        if _a is not None and not getattr(_a, "__VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2__", False):
            _mw = VSPRunsExportZipBtnMWP0V2(_a)
            setattr(_mw, "__VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2__", True)
            globals()["application"] = _mw
except Exception:
    pass
# === /VSP_RUNS_EXPORT_ZIP_INJECT_MW_P0_V2 ===


# === VSP_RUNS_EXPORT_ZIP_NOJS_MW_P0_V3 ===
class VSPRunsExportZipNoJSMWP0V3:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path != "/runs":
            return self.app(environ, start_response)

        meta = {}
        def sr(status, headers, exc_info=None):
            meta["status"] = status
            meta["headers"] = headers
            meta["exc_info"] = exc_info
            return lambda _x: None

        app_iter = self.app(environ, sr)

        body = b""
        try:
            for chunk in app_iter:
                if chunk:
                    body += chunk
        finally:
            try:
                close = getattr(app_iter, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        headers = meta.get("headers") or []
        ct = ""
        for k,v in headers:
            if str(k).lower() == "content-type":
                ct = str(v); break

        if ("text/html" in ct) and (b"/api/vsp/run_file" in body) and (MARKB not in body):
            try:
                html = body.decode("utf-8", "replace")
            except Exception:
                html = str(body)

            # Insert NO-JS Export button after any run_file link (per anchor)
            # Capture run_id from query string.
            runfile_a_pat = re.compile(
                r'(<a\b[^>]*href="[^"]*/api/vsp/run_file\?[^"]*?\brun_id=([^"&]+)[^"]*"[^>]*>.*?</a>)',
                re.IGNORECASE | re.DOTALL
            )

            def add_btn(m):
                a = m.group(1)
                rid = m.group(2)
                # Avoid duplicating if already inserted
                if "data-vsp-export-zip" in a:
                    return a
                btn = (
                    ' <a data-vsp-export-zip="1" '
                    'href="/api/vsp/export_zip?run_id=' + rid + '" '
                    'style="margin-left:8px;text-decoration:none;display:inline-block;'
                    'padding:7px 10px;border-radius:10px;font-weight:800;'
                    'border:1px solid rgba(90,140,255,.35);background:rgba(90,140,255,.16);color:inherit;">'
                    'Export ZIP</a>'
                )
                return a + btn

            html2, n = runfile_a_pat.subn(add_btn, html)
            if n > 0:
                # Add a marker comment that won't be stripped like <script>
                marker = "\n<!-- " + MARK + " injected=" + str(n) + " -->\n"
                if "</body>" in html2:
                    html2 = html2.replace("</body>", marker + "</body>", 1)
                else:
                    html2 = html2 + marker

                body = html2.encode("utf-8", "replace")

        # fix Content-Length
        new_headers=[]
        for k,v in headers:
            if str(k).lower() == "content-length":
                continue
            new_headers.append((k,v))
        new_headers.append(("Content-Length", str(len(body))))

        start_response(meta.get("status","200 OK"), new_headers, meta.get("exc_info"))
        return [body]

try:
    if "application" in globals():
        _a = globals().get("application")
        if _a is not None and not getattr(_a, "__VSP_RUNS_EXPORT_ZIP_NOJS_MW_P0_V3__", False):
            _mw = VSPRunsExportZipNoJSMWP0V3(_a)
            setattr(_mw, "__VSP_RUNS_EXPORT_ZIP_NOJS_MW_P0_V3__", True)
            globals()["application"] = _mw
except Exception:
    pass
# === /VSP_RUNS_EXPORT_ZIP_NOJS_MW_P0_V3 ===


# === VSP_RUNS_INJECT_EXTZIP_JS_P0_V1 ===
class VSPRunsInjectExtZipJSMWP0V1:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        if (environ.get("PATH_INFO") or "") != "/runs":
            return self.app(environ, start_response)

        meta={}
        def sr(status, headers, exc_info=None):
            meta["status"]=status; meta["headers"]=headers; meta["exc_info"]=exc_info
            return lambda _x: None

        it = self.app(environ, sr)
        body=b""
        try:
            for c in it:
                if c: body += c
        finally:
            try:
                close=getattr(it,"close",None)
                if callable(close): close()
            except Exception:
                pass

        headers = meta.get("headers") or []
        ct=""
        for k,v in headers:
            if str(k).lower()=="content-type":
                ct=str(v); break

        if ("text/html" in ct) and (MARKB not in body):
            ts = str(int(time.time()))
            tag = (f'\n<!-- {MARK} -->\n'
                   f'<script src="/static/js/vsp_runs_export_zip_patch_p0_v4.js?ts={ts}"></script>\n').encode("utf-8","replace")
            if b"</body>" in body:
                body = body.replace(b"</body>", tag + b"</body>", 1)
            else:
                body = body + tag

        newh=[]
        for k,v in headers:
            if str(k).lower()=="content-length": continue
            newh.append((k,v))
        newh.append(("Content-Length", str(len(body))))
        start_response(meta.get("status","200 OK"), newh, meta.get("exc_info"))
        return [body]

try:
    if "application" in globals():
        _a = globals().get("application")
        if _a is not None and not getattr(_a, "__VSP_RUNS_INJECT_EXTZIP_JS_P0_V1__", False):
            _mw = VSPRunsInjectExtZipJSMWP0V1(_a)
            setattr(_mw, "__VSP_RUNS_INJECT_EXTZIP_JS_P0_V1__", True)
            globals()["application"] = _mw
except Exception:
    pass
# === /VSP_RUNS_INJECT_EXTZIP_JS_P0_V1 ===


# === VSP_RUNS_500_FALLBACK_MW_P0_V1 ===
class VSPRuns500FallbackMWP0V1:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path != "/runs":
            return self.app(environ, start_response)

        meta = {}
        def sr(status, headers, exc_info=None):
            meta["status"]=status
            meta["headers"]=headers
            meta["exc_info"]=exc_info
            return lambda _x: None

        it = self.app(environ, sr)
        body=b""
        try:
            for c in it:
                if c: body += c
        finally:
            try:
                close=getattr(it,"close",None)
                if callable(close): close()
            except Exception:
                pass

        status = meta.get("status") or "200 OK"
        code = 0
        try:
            code = int(str(status).split()[0])
        except Exception:
            code = 0

        # if /runs returns 5xx => replace with a safe fallback page (NO <script>)
        if code >= 500:
            html = (
                "<!doctype html><html><head><meta charset='utf-8'>"
                "<title>Runs & Reports (fallback)</title></head>"
                "<body style='font-family:ui-sans-serif,system-ui;max-width:980px;margin:18px auto;"
                "padding:0 14px;color:#ddd;background:#0b0f14;'>"
                "<h2 style='margin:0 0 8px 0;'>Runs & Reports</h2>"
                "<div style='opacity:.85;margin-bottom:14px;'>"
                "UI /runs gặp lỗi 500. Đây là trang fallback để không sập demo.</div>"
                "<div style='display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px;'>"
                "<a href='/vsp5' style='color:#9ab;'>Dashboard</a>"
                "<a href='/data' style='color:#9ab;'>Data Source</a>"
                "<a href='/settings' style='color:#9ab;'>Settings</a>"
                "<a href='/rule_overrides' style='color:#9ab;'>Rule Overrides</a>"
                "</div>"
                "<div style='padding:12px;border:1px solid rgba(255,255,255,.1);border-radius:12px;"
                "background:rgba(255,255,255,.03);'>"
                "<div style='font-weight:800;margin-bottom:8px;'>Quick Links</div>"
                "<ul style='margin:0;padding-left:18px;line-height:1.7;'>"
                "<li><a href='/api/vsp/runs?limit=50' style='color:#9ab;'>/api/vsp/runs?limit=50</a></li>"
                "<li><a href='/api/vsp/selfcheck_p0' style='color:#9ab;'>/api/vsp/selfcheck_p0</a></li>"
                "<li><a href='/findings_unified.json' style='color:#9ab;'>/findings_unified.json</a></li>"
                "</ul>"
                "</div>"
                "<div style='opacity:.65;margin-top:14px;font-size:12px;'>"
                "Marker: VSP_RUNS_500_FALLBACK_MW_P0_V1</div>"
                "</body></html>"
            ).encode("utf-8","replace")

            start_response("200 OK", [
                ("Content-Type","text/html; charset=utf-8"),
                ("Cache-Control","no-store"),
                ("Content-Length", str(len(html)))
            ])
            return [html]

        # normal success
        hdrs = meta.get("headers") or []
        start_response(status, hdrs, meta.get("exc_info"))
        return [body]

try:
    if "application" in globals():
        _a = globals().get("application")
        if _a is not None and not getattr(_a, "__VSP_RUNS_500_FALLBACK_MW_P0_V1__", False):
            _mw = VSPRuns500FallbackMWP0V1(_a)
            setattr(_mw, "__VSP_RUNS_500_FALLBACK_MW_P0_V1__", True)
            globals()["application"] = _mw
except Exception:
    pass
# === /VSP_RUNS_500_FALLBACK_MW_P0_V1 ===


# === VSP_RUNS_500_FALLBACK_MW_P0_V2 ===
class VSPRuns500FallbackMWP0V2:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def _fallback(self, start_response, why=""):
        # VSP_MARK_FIX_P0_V5: safe fallback (no f-string pitfalls, no MARK NameError)
        try:
            marker = MARK
        except Exception:
            marker = 'VSP_UI_GATEWAY_MARK_V1'
        why_s = '' if why is None else str(why)
        html = (
            "<!doctype html><meta charset='utf-8'>"
            "<title>VSP UI fallback</title>"
            "<pre>Marker: " + str(marker) + "\n" + why_s + "</pre>"
        )
        body = html.encode('utf-8', errors='replace')
        start_response('200 OK', [
            ('Content-Type','text/html; charset=utf-8'),
            ('Content-Length', str(len(body))),
            ('Cache-Control','no-store'),
        ])
        return [body]


# =========================
# VSP_RUN_FILE_SAFE_ENDPOINT_P0_V1
# - Serve per-run report/artifacts via whitelist (no absolute FS path leak)
# - Normalize "report/" vs "reports/" vs root file locations
# - Post-process /api/vsp/runs: replace any abs html_path with safe URL
# =========================
from pathlib import Path as _Path
from urllib.parse import quote as _quote
import os as _os
import json as _json
import mimetypes as _mimetypes
import re as _re

try:
    from flask import request as _request, abort as _abort, send_file as _send_file, Response as _Response
except Exception:
    _request = None  # type: ignore

_VSP_RUNFILE_ALLOWED = {
    # virtual_name: candidate real paths under RUN_DIR (first existing wins)
    "reports/index.html": [
        "reports/index.html",
        "report/index.html",
        "reports/report.html",
        "report/report.html",
        "report.html",
    ],
    "reports/findings_unified.json": [
        "reports/findings_unified.json",
        "report/findings_unified.json",
        "findings_unified.json",
        "reports/unified/findings_unified.json",
        "unified/findings_unified.json",
    ],
    "reports/findings_unified.csv": [
        "reports/findings_unified.csv",
        "report/findings_unified.csv",
        "findings_unified.csv",
        "reports/unified/findings_unified.csv",
        "unified/findings_unified.csv",
    ],
    "reports/findings_unified.sarif": [
        "reports/findings_unified.sarif",
        "report/findings_unified.sarif",
        "findings_unified.sarif",
        "reports/unified/findings_unified.sarif",
        "unified/findings_unified.sarif",
    ],
    "reports/run_gate_summary.json": [
        "reports/run_gate_summary.json",
        "report/run_gate_summary.json",
        "run_gate_summary.json",
        "reports/run_gate_summary.json",
        "reports/unified/run_gate_summary.json",
        "unified/run_gate_summary.json",
    ],
}

def _vsp__runs_roots():
    roots = []
    env = _os.environ.get("VSP_RUNS_ROOT", "").strip()
    if env:
        roots.append(_Path(env))
    # sensible defaults for this repo
    roots += [
        _Path("/home/test/Data/SECURITY_BUNDLE/out"),
        _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        _Path("/home/test/Data/SECURITY-10-10-v4/out_ci"),
    ]
    # de-dup, keep existing dirs
    out = []
    seen = set()
    for r in roots:
        rp = str(r)
        if rp in seen:
            continue
        seen.add(rp)
        if r.exists():
            out.append(r)
    return out

def _vsp__is_safe_rid(rid: str) -> bool:
    return bool(rid) and bool(_re.fullmatch(r"[A-Za-z0-9_.:-]{6,128}", rid))

def _vsp__find_run_dir(rid: str):
    # direct hit
    for root in _vsp__runs_roots():
        cand = root / rid
        if cand.is_dir():
            return cand
        cand2 = root / "out" / rid
        if cand2.is_dir():
            return cand2
    # shallow scan (bounded)
    for root in _vsp__runs_roots():
        try:
            for cand in root.glob(f"*{rid}*"):
                if cand.is_dir() and cand.name == rid:
                    return cand
        except Exception:
            pass
    return None

def _vsp__pick_file(run_dir: _Path, virtual_name: str):
    cands = _VSP_RUNFILE_ALLOWED.get(virtual_name)
    if not cands:
        return None
    for rel in cands:
        fp = (run_dir / rel).resolve()
        try:
            # must stay under run_dir
            run_dir_res = run_dir.resolve()
            if not str(fp).startswith(str(run_dir_res) + _os.sep) and fp != run_dir_res:
                continue
            if fp.is_file():
                return fp
        except Exception:
            continue
    return None

def _vsp__safe_url(rid: str, virtual_name: str) -> str:
    return f"/api/vsp/run_file?rid={_quote(rid)}&name={_quote(virtual_name)}"

# ---- Endpoint: serve whitelisted per-run file
try:
    _app_obj = app  # noqa: F821
except Exception:
    _app_obj = None

if _app_obj is not None and getattr(_app_obj, "route", None) is not None:
    @_app_obj.get("/api/vsp/run_file")
    def _api_vsp_run_file():
        rid = (_request.args.get("rid", "") if _request else "").strip()
        name = (_request.args.get("name", "") if _request else "").strip()
        if not _vsp__is_safe_rid(rid):
            return _Response("bad rid", status=400, mimetype="text/plain")
        if name not in _VSP_RUNFILE_ALLOWED:
            # VSP_P1_ALLOW_SHA256SUMS_NOT_ALLOWED_V1: allow reports/SHA256SUMS.txt (commercial audit)
            try:
                _rid = (_rq_compat.args.get('rid','') or _rq_compat.args.get('run_id','') or _rq_compat.args.get('run','') or '').strip()
                _rel = (_rq_compat.args.get('name','') or _rq_compat.args.get('path','') or _rq_compat.args.get('rel','') or '').strip().lstrip('/')
                if _rid and _rel == 'reports/SHA256SUMS.txt':
                    from pathlib import Path as _P
                    _fp = _P('/home/test/Data/SECURITY_BUNDLE/out') / _rid / 'reports' / 'SHA256SUMS.txt'
                    if _fp.exists():
                        return _sf_compat(str(_fp), as_attachment=True)
            except Exception:
                pass
            # VSP_P1_GW_BYPASS_SHA256SUMS_V1: allow reports/SHA256SUMS.txt (commercial audit)
            try:
                _rid = (_rq_compat.args.get('rid','') or _rq_compat.args.get('run_id','') or _rq_compat.args.get('run','') or '').strip()
                _rel = (_rq_compat.args.get('name','') or _rq_compat.args.get('path','') or _rq_compat.args.get('rel','') or '').strip().lstrip('/')
                if _rid and _rel == 'reports/SHA256SUMS.txt':
                    from pathlib import Path as _P
                    from flask import send_file as _send_file, jsonify as _jsonify
                    _fp = _P('/home/test/Data/SECURITY_BUNDLE/out') / _rid / 'reports' / 'SHA256SUMS.txt'
                    if _fp.exists():
                        return _send_file(str(_fp), as_attachment=True)
                    return _jsonify({'ok': False, 'error': 'NO_FILE'}), 404
            except Exception:
                pass
            return _Response("not allowed", status=404, mimetype="text/plain")

        run_dir = _vsp__find_run_dir(rid)
        if not run_dir:
            return _Response("run not found", status=404, mimetype="text/plain")

        fp = _vsp__pick_file(run_dir, name)
        if not fp:
            return _Response("file not found", status=404, mimetype="text/plain")

        ctype, _enc = _mimetypes.guess_type(str(fp))
        ctype = ctype or ("text/html" if str(fp).endswith(".html") else "application/octet-stream")
        # inline for html/json, attachment for others
        as_attachment = not (str(fp).endswith(".html") or str(fp).endswith(".json"))
        return _send_file(fp, mimetype=ctype, as_attachment=as_attachment, download_name=fp.name)

    # learned-safe postprocess: rewrite /api/vsp/runs JSON to avoid absolute paths + add safe urls
    @_app_obj.after_request
    def _vsp__after_request_safe_runs(resp):
        try:
            if not _request or _request.path != "/api/vsp/runs":
                return resp
            if "application/json" not in (resp.headers.get("Content-Type", "") or ""):
                return resp
            data = resp.get_json(silent=True)
            if not isinstance(data, dict):
                return resp
            items = data.get("items") or []
            if not isinstance(items, list):
                return resp

            for it in items:
                if not isinstance(it, dict):
                    continue
                rid = (it.get("run_id") or it.get("rid") or "").strip()
                if not _vsp__is_safe_rid(rid):
                    continue
                has = it.get("has")
                if not isinstance(has, dict):
                    has = {}
                    it["has"] = has

                run_dir = _vsp__find_run_dir(rid)
                if not run_dir:
                    continue

                # normalize: if file exists under any legacy location, mark true + set safe URL
                def mark(vname: str, flag: str, keypath: str):
                    fp = _vsp__pick_file(run_dir, vname)
                    if fp:
                        has[flag] = True
                        has[keypath] = _vsp__safe_url(rid, vname)

                mark("reports/index.html", "html", "html_path")
                mark("reports/findings_unified.json", "json", "json_path")
                mark("reports/findings_unified.csv", "csv", "csv_path")
                mark("reports/findings_unified.sarif", "sarif", "sarif_path")
                mark("reports/run_gate_summary.json", "summary", "summary_path")

                # if legacy code already stuffed abs path into html_path, force rewrite to safe url
                hp = has.get("html_path")
                if isinstance(hp, str) and hp.startswith("/"):
                    # only rewrite if we can actually serve a report
                    if _vsp__pick_file(run_dir, "reports/index.html"):
                        has["html_path"] = _vsp__safe_url(rid, "reports/index.html")

            # re-encode response
            body = _json.dumps(data, ensure_ascii=False)
            resp.set_data(body)
            resp.headers["Content-Length"] = str(len(body.encode("utf-8")))
            return resp
        except Exception:
            return resp

# =========================
# END VSP_RUN_FILE_SAFE_ENDPOINT_P0_V1
# =========================


# =========================
# VSP_RUN_FILE2_SAFE_ENDPOINT_P0_V1
# - New endpoint /api/vsp/run_file2 to avoid collision with existing /api/vsp/run_file
# - Rewrite /api/vsp/runs has.*_path to use run_file2 (safe, no abs path)
# =========================
from pathlib import Path as _P2
from urllib.parse import quote as _q2
import os as _os2
import json as _json2
import mimetypes as _mt2
import re as _re2

try:
    from flask import request as _rq2, send_file as _sf2, Response as _R2
except Exception:
    _rq2 = None  # type: ignore

_VSP_RF2_ALLOWED = {
    "reports/index.html": [
        "reports/index.html","report/index.html","reports/report.html","report/report.html","report.html",
    ],
    "reports/findings_unified.json": [
        "reports/findings_unified.json","report/findings_unified.json","findings_unified.json",
        "reports/unified/findings_unified.json","unified/findings_unified.json",
    ],
    "reports/findings_unified.csv": [
        "reports/findings_unified.csv","report/findings_unified.csv","findings_unified.csv",
        "reports/unified/findings_unified.csv","unified/findings_unified.csv",
    ],
    "reports/findings_unified.sarif": [
        "reports/findings_unified.sarif","report/findings_unified.sarif","findings_unified.sarif",
        "reports/unified/findings_unified.sarif","unified/findings_unified.sarif",
    ],
    "reports/run_gate_summary.json": [
        "reports/run_gate_summary.json","report/run_gate_summary.json","run_gate_summary.json",
        "reports/unified/run_gate_summary.json","unified/run_gate_summary.json",
    ],
}

def _rf2_roots():
    roots=[]
    env=_os2.environ.get("VSP_RUNS_ROOT","").strip()
    if env: roots.append(_P2(env))
    roots += [
        _P2("/home/test/Data/SECURITY_BUNDLE/out"),
        _P2("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        _P2("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        _P2("/home/test/Data/SECURITY-10-10-v4/out_ci"),
    ]
    out=[]; seen=set()
    for r in roots:
        rp=str(r)
        if rp in seen: continue
        seen.add(rp)
        if r.exists(): out.append(r)
    return out

def _rf2_safe_rid(rid:str)->bool:
    return bool(rid) and bool(_re2.fullmatch(r"[A-Za-z0-9_.:-]{6,160}", rid))

def _rf2_find_run_dir(rid:str):
    for root in _rf2_roots():
        for cand in (root/rid, root/"out"/rid):
            if cand.is_dir(): return cand
    return None

def _rf2_pick(run_dir:_P2, vname:str):
    cands=_VSP_RF2_ALLOWED.get(vname)
    if not cands: return None
    rd=run_dir.resolve()
    for rel in cands:
        fp=(run_dir/rel).resolve()
        try:
            if not str(fp).startswith(str(rd)+_os2.sep): 
                continue
            if fp.is_file(): return fp
        except Exception:
            continue
    return None

def _rf2_url(rid:str, vname:str)->str:
    return f"/api/vsp/run_file2?rid={_q2(rid)}&name={_q2(vname)}"

try:
    _app2 = app  # noqa: F821
except Exception:
    _app2 = None

if _app2 is not None and getattr(_app2, "route", None) is not None:
    @_app2.get("/api/vsp/run_file2")
    def _api_vsp_run_file2():
        rid = (_rq2.args.get("rid","") if _rq2 else "").strip()
        name = (_rq2.args.get("name","") if _rq2 else "").strip()
        # allow alias param
        if not name and _rq2:
            name = (_rq2.args.get("path","") or _rq2.args.get("n","") or "").strip()

        if not _rf2_safe_rid(rid):
            return _R2(_json2.dumps({"ok":False,"err":"bad rid"}), status=400, mimetype="application/json")
        if name not in _VSP_RF2_ALLOWED:
            # VSP_P1_ALLOW_SHA256SUMS_NOT_ALLOWED_V1: allow reports/SHA256SUMS.txt (commercial audit)
            try:
                _rid = (_rq_compat.args.get('rid','') or _rq_compat.args.get('run_id','') or _rq_compat.args.get('run','') or '').strip()
                _rel = (_rq_compat.args.get('name','') or _rq_compat.args.get('path','') or _rq_compat.args.get('rel','') or '').strip().lstrip('/')
                if _rid and _rel == 'reports/SHA256SUMS.txt':
                    from pathlib import Path as _P
                    _fp = _P('/home/test/Data/SECURITY_BUNDLE/out') / _rid / 'reports' / 'SHA256SUMS.txt'
                    if _fp.exists():
                        return _sf_compat(str(_fp), as_attachment=True)
            except Exception:
                pass
            return _R2(_json2.dumps({"ok":False,"err":"not allowed"}), status=404, mimetype="application/json")

        run_dir = _rf2_find_run_dir(rid)
        if not run_dir:
            return _R2(_json2.dumps({"ok":False,"err":"run not found"}), status=404, mimetype="application/json")

        fp = _rf2_pick(run_dir, name)
        if not fp:
            return _R2(_json2.dumps({"ok":False,"err":"file not found"}), status=404, mimetype="application/json")

        ctype,_ = _mt2.guess_type(str(fp))
        ctype = ctype or ("text/html" if str(fp).endswith(".html") else "application/octet-stream")
        as_attach = not (str(fp).endswith(".html") or str(fp).endswith(".json"))
        return _sf2(fp, mimetype=ctype, as_attachment=as_attach, download_name=fp.name)

    @_app2.after_request
    def _rf2_after(resp):
        try:
            if not _rq2 or _rq2.path != "/api/vsp/runs":
                return resp
            if "application/json" not in (resp.headers.get("Content-Type","") or ""):
                return resp
            data = resp.get_json(silent=True)
            if not isinstance(data, dict):
                return resp
            items = data.get("items") or []
            if not isinstance(items, list):
                return resp

            for it in items:
                if not isinstance(it, dict): 
                    continue
                rid = (it.get("run_id") or it.get("rid") or "").strip()
                if not _rf2_safe_rid(rid):
                    continue
                has = it.get("has")
                if not isinstance(has, dict):
                    has = {}
                    it["has"] = has

                rd = _rf2_find_run_dir(rid)
                if not rd:
                    continue

                def mark(vname, flag, keypath):
                    fp = _rf2_pick(rd, vname)
                    if fp:
                        has[flag] = True
                        has[keypath] = _rf2_url(rid, vname)

                # always prefer run_file2 urls
                mark("reports/index.html","html","html_path")
                mark("reports/findings_unified.json","json","json_path")
                mark("reports/findings_unified.csv","csv","csv_path")
                mark("reports/findings_unified.sarif","sarif","sarif_path")
                mark("reports/run_gate_summary.json","summary","summary_path")

                # rewrite any old run_file url -> run_file2
                for k in ("html_path","json_path","csv_path","sarif_path","summary_path"):
                    v = has.get(k)
                    if isinstance(v,str) and v.startswith("/api/vsp/run_file?"):
                        has[k] = v.replace("/api/vsp/run_file?","/api/vsp/run_file2?",1)
            # VSP_FORCE_RUNFILE2_PATHS_P0_V2: normalize path fields and fill missing *_path
            for it in items:
                if not isinstance(it, dict):
                    continue
                has = it.get("has") or {}
                if not isinstance(has, dict):
                    continue
                rid = (it.get("run_id") or it.get("rid") or "").strip()
                if not rid:
                    continue

                # rewrite run_file -> run_file2
                for k in ("html_path","json_path","csv_path","sarif_path","summary_path"):
                    v = has.get(k)
                    if isinstance(v, str) and v.startswith("/api/vsp/run_file?"):
                        has[k] = v.replace("/api/vsp/run_file?","/api/vsp/run_file2?",1)

                # fill missing paths if boolean says true
                if has.get("json") is True and not has.get("json_path"):
                    has["json_path"] = _rf2_url(rid, "reports/findings_unified.json")
                if has.get("summary") is True and not has.get("summary_path"):
                    has["summary_path"] = _rf2_url(rid, "reports/run_gate_summary.json")
                if has.get("html") is True and not has.get("html_path"):
                    has["html_path"] = _rf2_url(rid, "reports/index.html")
                if has.get("csv") is True and not has.get("csv_path"):
                    has["csv_path"] = _rf2_url(rid, "reports/findings_unified.csv")
                if has.get("sarif") is True and not has.get("sarif_path"):
                    has["sarif_path"] = _rf2_url(rid, "reports/findings_unified.sarif")

                it["has"] = has

            # VSP_FORCE_RUNFILE2_PATHS_P0_V3: FINAL normalize (override any earlier after_request)
            for it in items:
                if not isinstance(it, dict):
                    continue
                rid = (it.get("run_id") or it.get("rid") or "").strip()
                if not rid:
                    continue
                has = it.get("has") or {}
                if not isinstance(has, dict):
                    continue

                # rewrite any old run_file url -> run_file2
                for k in ("html_path","json_path","csv_path","sarif_path","summary_path"):
                    v = has.get(k)
                    if isinstance(v, str) and v.startswith("/api/vsp/run_file?"):
                        has[k] = v.replace("/api/vsp/run_file?","/api/vsp/run_file2?",1)

                # fill missing *_path if boolean true
                if has.get("json") is True and not has.get("json_path"):
                    has["json_path"] = _rf2_url(rid, "reports/findings_unified.json")
                if has.get("summary") is True and not has.get("summary_path"):
                    has["summary_path"] = _rf2_url(rid, "reports/run_gate_summary.json")
                if has.get("html") is True and not has.get("html_path"):
                    has["html_path"] = _rf2_url(rid, "reports/index.html")

                it["has"] = has


            body = _json2.dumps(data, ensure_ascii=False)
            resp.set_data(body)
            resp.headers["Content-Length"] = str(len(body.encode("utf-8")))
            return resp
        except Exception:
            return resp
# =========================
# END VSP_RUN_FILE2_SAFE_ENDPOINT_P0_V1
# =========================

# VSP_FORCE_RUNFILE2_PATHS_P0_V2

# VSP_FORCE_RUNFILE2_PATHS_P0_V3

# =========================
# VSP_REWRITE_RUN_FILE_TO_RUN_FILE2_P0_V1
# Force rewrite any /api/vsp/run_file? -> /api/vsp/run_file2? inside /api/vsp/runs JSON response.
# =========================
try:
    from flask import request as _rq_last
except Exception:
    _rq_last = None  # type: ignore

try:
    _app_last = app  # noqa: F821
except Exception:
    _app_last = None

if _app_last is not None and getattr(_app_last, "after_request", None) is not None:
    @_app_last.after_request
    def _vsp_after_rewrite_runfile2(resp):
        try:
            if not _rq_last or _rq_last.path != "/api/vsp/runs":
                return resp
            ct = (resp.headers.get("Content-Type","") or "")
            if "application/json" not in ct:
                return resp
            body = resp.get_data(as_text=True) or ""
            if "/api/vsp/run_file?" not in body:
                return resp
            body2 = body.replace("/api/vsp/run_file?","/api/vsp/run_file2?")
            resp.set_data(body2)
            resp.headers["Content-Length"] = str(len(body2.encode("utf-8")))
            return resp
        except Exception:
            return resp
# =========================
# END VSP_REWRITE_RUN_FILE_TO_RUN_FILE2_P0_V1
# =========================

# =========================
# VSP_RUN_FILE_COMPAT_TO_RUN_FILE2_P0_V1
# Make legacy /api/vsp/run_file work by serving via run_file2 whitelist logic.
# This avoids 400 from old handler and makes UI clickable immediately.
# =========================
try:
    from flask import request as _rq_compat, send_file as _sf_compat, Response as _R_compat
except Exception:
    _rq_compat = None  # type: ignore

try:
    _app_compat = app  # noqa: F821
except Exception:
    _app_compat = None

if _app_compat is not None and getattr(_app_compat, "before_request", None) is not None:
    @_app_compat.before_request
    def _vsp_compat_run_file_to_run_file2():
        try:
            if not _rq_compat:
                return None
            if _rq_compat.path != "/api/vsp/run_file":
                return None

            rid = (_rq_compat.args.get("rid","") or "").strip()
            name = (_rq_compat.args.get("name","") or _rq_compat.args.get("path","") or _rq_compat.args.get("n","") or "").strip()

            # Use run_file2 validators if present
            if " _rf2_safe_rid" and callable(globals().get("_rf2_safe_rid")):
                if not globals()["_rf2_safe_rid"](rid):
                    return _R_compat('{"ok":false,"err":"bad rid"}', status=400, mimetype="application/json")
            else:
                # fallback
                import re as _re
                if not rid or not _re.fullmatch(r"[A-Za-z0-9_.:-]{6,160}", rid):
                    return _R_compat('{"ok":false,"err":"bad rid"}', status=400, mimetype="application/json")

            allowed = globals().get("_VSP_RF2_ALLOWED") or globals().get("_VSP_RUNFILE_ALLOWED") or {}
            if name not in allowed:
                # VSP_P1_ALLOW_SHA256SUMS_NOT_ALLOWED_V1: allow reports/SHA256SUMS.txt (commercial audit)
                try:
                    _rid = (_rq_compat.args.get('rid','') or _rq_compat.args.get('run_id','') or _rq_compat.args.get('run','') or '').strip()
                    _rel = (_rq_compat.args.get('name','') or _rq_compat.args.get('path','') or _rq_compat.args.get('rel','') or '').strip().lstrip('/')
                    if _rid and _rel == 'reports/SHA256SUMS.txt':
                        from pathlib import Path as _P
                        _fp = _P('/home/test/Data/SECURITY_BUNDLE/out') / _rid / 'reports' / 'SHA256SUMS.txt'
                        if _fp.exists():
                            return _sf_compat(str(_fp), as_attachment=True)
                except Exception:
                    pass
                return _R_compat('{"ok":false,"err":"not allowed"}', status=404, mimetype="application/json")

            find_dir = globals().get("_rf2_find_run_dir") or globals().get("_vsp__find_run_dir")
            pick_file = globals().get("_rf2_pick") or globals().get("_vsp__pick_file")
            if not callable(find_dir) or not callable(pick_file):
                return _R_compat('{"ok":false,"err":"compat helpers missing"}', status=500, mimetype="application/json")

            run_dir = find_dir(rid)
            if not run_dir:
                return _R_compat('{"ok":false,"err":"run not found"}', status=404, mimetype="application/json")

            fp = pick_file(run_dir, name)
            if not fp:
                return _R_compat('{"ok":false,"err":"file not found"}', status=404, mimetype="application/json")

            import mimetypes as _mt
            ctype,_ = _mt.guess_type(str(fp))
            ctype = ctype or ("text/html" if str(fp).endswith(".html") else "application/octet-stream")
            as_attach = not (str(fp).endswith(".html") or str(fp).endswith(".json"))
            return _sf_compat(fp, mimetype=ctype, as_attachment=as_attach, download_name=fp.name)
        except Exception:
            # let original handler run if something unexpected happens
            return None
# =========================
# END VSP_RUN_FILE_COMPAT_TO_RUN_FILE2_P0_V1
# =========================



# VSP_RUN_FILE_LEGACY_COMPAT_MW_P0_V1
# Accept legacy /api/vsp/run_file?run_id=...&path=... by rewriting to rid/name at WSGI layer.
try:
    from urllib.parse import parse_qs, urlencode
except Exception:
    parse_qs = None
    urlencode = None

class _VspRunFileLegacyCompatMW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        try:
            path = environ.get("PATH_INFO", "") or ""
            if path == "/api/vsp/run_file" and parse_qs and urlencode:
                qs = environ.get("QUERY_STRING", "") or ""
                q = parse_qs(qs, keep_blank_values=True)
                # If legacy keys exist but new keys missing => map
                if (("run_id" in q) or ("path" in q)) and (("rid" not in q) and ("name" not in q)):
                    if "run_id" in q:
                        q["rid"] = q.get("run_id")
                    if "path" in q:
                        q["name"] = q.get("path")
                    # Keep all keys (including run_id/path) to be safe
                    pairs = []
                    for k, vs in q.items():
                        for v in vs:
                            pairs.append((k, v))
                    environ["QUERY_STRING"] = urlencode(pairs, doseq=True)
        except Exception:
            pass
        return self.app(environ, start_response)

# VSP_P1_LEGACYCOMPAT_SAFE_WRAP_V10
try:
    # Ensure application is a Flask app if possible (restore from global 'app' if it exists)
    _flask = application if hasattr(application, 'after_request') else globals().get('app', None)
    if _flask is not None and hasattr(_flask, 'after_request'):
        application = _flask
        application.wsgi_app = _VspRunFileLegacyCompatMW(application.wsgi_app)
except Exception:
    # If we can't safely wrap, skip instead of crashing import/boot.
    pass



# VSP_RUNS_NO_FS_LEAK_MW_P0_V1
# Rewrite /api/vsp/runs payload: never expose filesystem paths; provide /api/vsp/run_file URLs instead.
import json as _json
from urllib.parse import urlencode as _urlencode

class _VspRunsNoFsLeakMW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if path != "/api/vsp/runs":
            return self.app(environ, start_response)

        captured = {"status": None, "headers": None}
        body_chunks = []

        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers)
            # delay sending headers until we possibly rewrite body
            return body_chunks.append

        it = self.app(environ, _sr)

        try:
            for c in it:
                if c:
                    body_chunks.append(c)
        finally:
            try:
                close = getattr(it, "close", None)
                if callable(close): close()
            except Exception:
                pass

        raw = b"".join([c if isinstance(c,(bytes,bytearray)) else str(c).encode("utf-8","replace") for c in body_chunks])
        try:
            obj = _json.loads(raw.decode("utf-8","replace"))
        except Exception:
            # fall back: send original
            headers = captured["headers"] or []
            start_response(captured["status"] or "200 OK", headers)
            return [raw]

        def run_file_url(rid, name):
            qs = _urlencode({"rid": rid, "name": name})
            return "/api/vsp/run_file?" + qs

        items = obj.get("items") if isinstance(obj, dict) else None
        if isinstance(items, list):
            for it in items:
                if not isinstance(it, dict): 
                    continue
                rid = it.get("run_id") or it.get("rid")
                has = it.get("has")
                if not rid or not isinstance(has, dict):
                    continue
                # normalize paths to URLs
                # html
                if has.get("html") is True:
                    has["html_path"] = run_file_url(rid, "reports/index.html")
                elif "html_path" in has and isinstance(has["html_path"], str) and has["html_path"].startswith("/home/"):
                    # if backend leaked FS path, convert to URL and set html true
                    has["html"] = True
                    has["html_path"] = run_file_url(rid, "reports/index.html")
                # json (standardize to reports/findings_unified.json)
                if "json_path" in has:
                    has["json_path"] = run_file_url(rid, "reports/findings_unified.json")
                if has.get("json") is True:
                    has["json_path"] = run_file_url(rid, "reports/findings_unified.json")
                # summary
                if "summary_path" in has:
                    has["summary_path"] = run_file_url(rid, "reports/run_gate_summary.json")
                if has.get("summary") is True:
                    has["summary_path"] = run_file_url(rid, "reports/run_gate_summary.json")

                # Optional: offer txt path in reports (more likely whitelisted)
                has["txt_path"] = run_file_url(rid, "reports/SUMMARY.txt")
                has["sha_path"] = run_file_url(rid, "reports/SHA256SUMS.txt")
        out = _json.dumps(obj, ensure_ascii=False).encode("utf-8")
        headers = [(k,v) for (k,v) in (captured["headers"] or []) if k.lower() != "content-length"]
        headers.append(("Content-Length", str(len(out))))
        start_response(captured["status"] or "200 OK", headers)
        return [out]

application.wsgi_app = _VspRunsNoFsLeakMW(application.wsgi_app)



# VSP_RUN_FILE_DIRECTSERVE_REPORTS_SUMMARY_P0_V1
# Direct-serve ONLY reports/SUMMARY.txt to avoid allowlist/validator blocking.
# This stays commercial-safe: fixed path, fixed filename, strict RID folder under SECURITY_BUNDLE/out or out_ci.
from urllib.parse import parse_qs as _parse_qs
from pathlib import Path as _Path

class _VspRunFileDirectServeSummaryMW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
        self.root = _Path("/home/test/Data/SECURITY_BUNDLE")
    def _resolve_run_dir(self, rid: str):
        rid = (rid or "").strip()
        cands = []
        if rid:
            cands.append(rid)
            if "RUN_" in rid:
                cands.append(rid[rid.find("RUN_"):])
        for cand in cands:
            for base in ("out", "out_ci"):
                d = self.root / base / cand
                if d.is_dir():
                    return d
        return None

    def __call__(self, environ, start_response):
        try:
            if (environ.get("PATH_INFO","") or "") == "/api/vsp/run_file":
                qs = environ.get("QUERY_STRING","") or ""
                q = _parse_qs(qs, keep_blank_values=True)
                rid = (q.get("rid") or q.get("run_id") or q.get("runId") or [""])[0]
                name = (q.get("name") or q.get("path") or q.get("file") or [""])[0]
                name = (name or "").strip()

                # normalize summary variants
                if name in ("reports/SUMMARY.txt", "reports/SHA256SUMS.txt", "reports/summary.txt", "SUMMARY.txt", "SHA256SUMS.txt", "summary.txt"):
                    run_dir = self._resolve_run_dir(rid)
                    if run_dir:
                        fp = run_dir / "reports" / "SUMMARY.txt", "SHA256SUMS.txt"
                        if fp.is_file() and fp.stat().st_size > 0:
                            data = fp.read_bytes()
                            headers = [
                                ("Content-Type", "text/plain; charset=utf-8"),
                                ("Content-Length", str(len(data))),
                                ("Cache-Control", "no-store"),
                            ]
                            start_response("200 OK", headers)
                            return [data]
        except Exception:
            pass

        return self.app(environ, start_response)

application.wsgi_app = _VspRunFileDirectServeSummaryMW(application.wsgi_app)




# === VSP_API_REPORTS_LATEST_BIND_APP_P0_V3 ===
from pathlib import Path
from urllib.parse import quote

def _vsp__find_latest_run_with_file__p0v3(relpath: str) -> str:
    base = Path("/home/test/Data/SECURITY_BUNDLE/out")
    if not base.exists():
        return ""
    runs = sorted(base.glob("RUN_*"), key=lambda x: x.stat().st_mtime, reverse=True)
    for rd in runs[:300]:
        try:
            if (rd / relpath).is_file():
                return rd.name
        except Exception:
            continue
    return ""

def vsp_api_reports_latest__p0v3(name):
    rel = name if name.startswith("reports/") else ("reports/" + name)
    rid = _vsp__find_latest_run_with_file__p0v3(rel)
    if not rid:
        return ("Not Found", 404)
    url = "/api/vsp/run_file?rid=" + quote(rid) + "&name=" + quote(rel)
    return ("", 302, {"Location": url})

def _vsp__bind_reports_latest__p0v3():
    # bind to Flask app (usually global "app"); do NOT use "application" wrapper
    flask_app = globals().get("app")
    if not (hasattr(flask_app, "add_url_rule") and hasattr(flask_app, "url_map")):
        # fallback scan
        flask_app = None
        for v in globals().values():
            if hasattr(v, "add_url_rule") and hasattr(v, "url_map") and hasattr(v, "route"):
                flask_app = v
                break
    if not flask_app:
        print("[WARN] cannot locate Flask app to bind /api/reports")
        return False
    try:
        flask_app.add_url_rule(
            "/api/reports/<path:name>",
            endpoint="vsp_api_reports_latest",
            view_func=vsp_api_reports_latest__p0v3,
            methods=["GET","HEAD"]
        )
    except Exception:
        # already bound / endpoint exists
        pass
    return True

_vsp__bind_reports_latest__p0v3()


# VSP_P1_ALLOW_SHA256SUMS_GLOBAL_V1

# VSP_P1_ALLOW_SHA256SUMS_NOT_ALLOWED_V1

# VSP_P1_GW_BYPASS_SHA256SUMS_V1

# VSP_P1_GW_RUNFILE_ANCHOR_ALLOW_SHA_V3

# VSP_P1_FIX_SHA256SUMS_COMPAT_V2

# VSP_P1_ALLOW_SHA256SUMS_V5

# VSP_P1_FIX_RUNS_AND_SHA256SUMS_V1


# === VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1 ===
def _vsp_proxy_run_file_summary_to_run_file2_wsgi(app):
    """
    If legacy /api/vsp/run_file can't serve reports/SUMMARY.txt (or SHA256SUMS),
    transparently route it to /api/vsp/run_file2 (same rid/name contract).
    """
    from urllib.parse import parse_qs, urlencode

    def wsgi(environ, start_response):
        try:
            path = (environ.get("PATH_INFO","") or "")
            method = (environ.get("REQUEST_METHOD","GET") or "GET").upper()
            if path == "/api/vsp/run_file" and method in ("GET","HEAD"):
                qs = parse_qs(environ.get("QUERY_STRING","") or "")
                name = (qs.get("name") or [""])[0] or ""
                # only intercept the problematic ones (minimal risk)
                if name in ("reports/SUMMARY.txt","reports/SHA256SUMS.txt"):
                    environ = dict(environ)
                    environ["PATH_INFO"] = "/api/vsp/run_file2"
                    # keep same query
                    environ["QUERY_STRING"] = urlencode([(k, v2) for k, vv in qs.items() for v2 in vv])
        except Exception:
            pass
        return app(environ, start_response)
    return wsgi
# === /VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1 ===


# === VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1_APPLY ===
try:
    if "application" in globals():
        application.wsgi_app = _vsp_proxy_run_file_summary_to_run_file2_wsgi(application.wsgi_app)
    elif "app" in globals():
        application.wsgi_app = _vsp_proxy_run_file_summary_to_run_file2_wsgi(application.wsgi_app)
except Exception:
    pass
# === /VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1_APPLY ===

# VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V1

# VSP_P1_PROXY_RUN_FILE_SUMMARY_TO_RUN_FILE2_V2


# === VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1 ===
def _vsp_direct_serve_summary_sha_wsgi(app):
    """
    Commercial-safe: ensure legacy /api/vsp/run_file can serve:
      - reports/SUMMARY.txt
      - reports/SHA256SUMS.txt
    for both GET and HEAD, by reading files directly from OUT_ROOT.
    """
    import os
    from pathlib import Path
    from urllib.parse import parse_qs

    OUT_ROOT = Path("/home/test/Data/SECURITY_BUNDLE/out")

    def _send(start_response, code, headers, body=b""):
        start_response(code, headers)
        return [body] if body else [b""]

    def wsgi(environ, start_response):
        try:
            path = (environ.get("PATH_INFO","") or "")
            method = (environ.get("REQUEST_METHOD","GET") or "GET").upper()
            if path == "/api/vsp/run_file" and method in ("GET","HEAD"):
                qs = parse_qs(environ.get("QUERY_STRING","") or "")
                rid = (qs.get("rid") or [""])[0].strip()
                name = (qs.get("name") or [""])[0].strip()
                if rid and name in ("reports/SUMMARY.txt","reports/SHA256SUMS.txt"):
                    fp = (OUT_ROOT / rid / name).resolve()
                    rd = (OUT_ROOT / rid).resolve()
                    if str(fp).find(str(rd)) != 0:
                        return _send(start_response, "400 BAD REQUEST", [
                            ("Content-Type","application/json; charset=utf-8"),
                            ("X-VSP-DirectServe", MARK),
                        ], b'{"ok":false,"err":"path traversal"}')
                    if fp.exists() and fp.is_file():
                        try:
                            st = fp.stat()
                            clen = str(int(st.st_size))
                        except Exception:
                            clen = None
                        headers = [
                            ("Content-Type","text/plain; charset=utf-8"),
                            ("Content-Disposition", f'attachment; filename={os.path.basename(name)}'),
                            ("Cache-Control","no-cache"),
                            ("X-VSP-DirectServe", MARK),
                        ]
                        if clen:
                            headers.append(("Content-Length", clen))
                        if method == "HEAD":
                            return _send(start_response, "200 OK", headers, b"")
                        body = fp.read_bytes()
                        return _send(start_response, "200 OK", headers, body)
        except Exception:
            pass
        return app(environ, start_response)

    return wsgi
# === /VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1 ===


# === VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1_APPLY ===
try:
    if "application" in globals():
        application.wsgi_app = _vsp_direct_serve_summary_sha_wsgi(application.wsgi_app)
    elif "app" in globals():
        application.wsgi_app = _vsp_direct_serve_summary_sha_wsgi(application.wsgi_app)
except Exception:
    pass
# === /VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1_APPLY ===

# VSP_P1_DIRECT_SERVE_SUMMARY_SHA_V1

# ---- VSP_P1_HTML_commercial_guard_P1_V7B (commercial polish: stop /vsp5 poll spam) ----
try:
    import re as _re
    from flask import request as _request
except Exception:
    _re = None
    _request = None

_VSP_P1_commercial_guard_HTML_V7B = r"""
<!-- VSP_COMMERCIAL_GLOBAL_GUARD_V1 -->
<script id="VSP_COMMERCIAL_GLOBAL_GUARD_V1">
(()=> {
  if (window.__vsp_commercial_global_guard_v1) return;
  window.__vsp_commercial_global_guard_v1 = true;

  const HOLD_MS = 15000;
  let holdUntil = Date.now() + 2500; // grace on first load/restart

  // drop only noisy poll logs (do NOT hide real errors)
  const DROP = [
    /\[VSP\]\s*poll down; backoff/i,
    /poll down; backoff/i,
    /runs fetch guard\/backoff enabled/i,
    /VSP_ROUTE_GUARD_RUNS_ONLY_/i
  ];
  function _dropArgs(args){
    try{
      if (!args || !args.length) return false;
      const a0 = (typeof args[0] === "string") ? args[0] : "";
      return DROP.some(rx => rx.test(a0));
    }catch(_){ return false; }
  }
  if (!window.__vsp_console_filtered_commercial_v1){
    window.__vsp_console_filtered_commercial_v1 = true;
    for (const k of ["log","info","warn","error"]){
      const orig = console[k].bind(console);
      console[k] = (...args)=>{ if (_dropArgs(args)) return; return orig(...args); };
    }
  }

  function _isApiVsp(u){ return !!u && u.includes("/api/vsp/"); }
  function _isPlaceholder(u){ return !!u && (u === "<URL>" || u.includes("<URL>")); }

  function _cacheKey(u){
    try{
      const uu = new URL(u, location.origin);
      return "vsp_api_cache_v7b::" + uu.pathname + uu.search;
    }catch(_){
      return "vsp_api_cache_v7b::" + String(u);
    }
  }
  function _load(u){
    try{
      const raw = localStorage.getItem(_cacheKey(u));
      return raw ? JSON.parse(raw) : null;
    }catch(_){ return null; }
  }
  function _save(u,obj){
    try{ localStorage.setItem(_cacheKey(u), JSON.stringify(obj)); }catch(_){}
  }
  function _resp(obj,hdr){
    const h = new Headers({"Content-Type":"application/json; charset=utf-8"});
    try{ if (hdr) for (const [k,v] of Object.entries(hdr)) h.set(k, String(v)); }catch(_){}
    return new Response(JSON.stringify(obj), {status:200, headers:h});
  }

  // fetch wrapper
  if (window.fetch && !window.__vsp_fetch_wrapped_v7b){
    window.__vsp_fetch_wrapped_v7b = true;
    const orig = window.fetch.bind(window);
    window.fetch = async (input, init)=>{
      let u="";
      try{ u = (typeof input==="string") ? input : (input && input.url) ? input.url : ""; }catch(_){}
      if (_isPlaceholder(u)){
        return _resp({ok:false, note:"intercepted <URL>", marker:"V7B"}, {"X-VSP-Intercept":"1"});
      }
      if (_isApiVsp(u)){
        const now = Date.now();
        if (now < holdUntil){
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1"});
        }
        try{
          const r = await orig(input, init);
          if (r && r.ok){
            try{
              const j = await r.clone().json();
              if (j && typeof j==="object") _save(u, j);
            }catch(_){}
            return r;
          }
          holdUntil = Date.now() + HOLD_MS;
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1","X-VSP-Non200": r ? r.status : "NA"});
        }catch(_e){
          holdUntil = Date.now() + HOLD_MS;
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1","X-VSP-NetFail":"1"});
        }
      }
      return orig(input, init);
    };
  }

  // XHR wrapper (stop DevTools spam during restart)
  if (window.XMLHttpRequest && !window.__vsp_xhr_wrapped_v7b){
    window.__vsp_xhr_wrapped_v7b = true;
    const _open = XMLHttpRequest.prototype.open;
    const _send = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(method, url){
      try{ this.__vsp_url = String(url || ""); }catch(_){}
      return _open.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function(body){
      const u = (this && this.__vsp_url) ? String(this.__vsp_url) : "";
      if (_isPlaceholder(u) || _isApiVsp(u)){
        const now = Date.now();
        if (_isPlaceholder(u) || (now < holdUntil && _isApiVsp(u))){
          const cached = _isPlaceholder(u) ? {ok:false, note:"intercepted <URL>", marker:"V7B"} : (_load(u) || {ok:false, note:"degraded-cache-empty"});
          const txt = JSON.stringify(cached);
          try{
            Object.defineProperty(this, "status", { get: ()=>200, configurable:true });
            Object.defineProperty(this, "responseText", { get: ()=>txt, configurable:true });
            Object.defineProperty(this, "response", { get: ()=>txt, configurable:true });
          }catch(_){}
          const self=this;
          setTimeout(()=>{
            try{ if (typeof self.onreadystatechange==="function") self.onreadystatechange(); }catch(_){}
            try{ if (typeof self.onload==="function") self.onload(); }catch(_){}
            try{ self.dispatchEvent && self.dispatchEvent(new Event("load")); }catch(_){}
          },0);
          return; // NO NETWORK => no DevTools spam
        }
      }
      return _send.apply(this, arguments);
    };
  }
})();
</script>
"""

def _vsp_p1_inject_head_v7b(html: str) -> str:
    if _re is None:
        return html
    m = _re.search(r"<head[^>]*>", html, flags=_re.I)
    if not m:
        return html
    ins = m.end()
    return html[:ins] + "\n" + _VSP_P1_commercial_guard_HTML_V7B + "\n" + html[ins:]

try:
    _app = application  # must exist in this gateway
    @_app.after_request
    def _vsp_p1_html_commercial_guard_v7b(resp):
        try:
            if _request is None or _re is None:
                return resp
            if _request.path not in ("/vsp5", "/vsp5/"):
                return resp
            ct = (resp.headers.get("Content-Type","") or "")
            if "text/html" not in ct:
                return resp
            html = resp.get_data(as_text=True)
            if "VSP_COMMERCIAL_GLOBAL_GUARD_V1" in html:
                return resp
            html2 = _vsp_p1_inject_head_v7b(html)
            if html2 != html:
                resp.set_data(html2)
                resp.headers["Content-Length"] = str(len(resp.get_data()))
            return resp
        except Exception:
            return resp
except Exception:
    pass
# ---- end VSP_P1_HTML_commercial_guard_P1_V7B ----

# VSP_P1_HTML_commercial_guard_P1_V7C_MW
# ---- VSP_P1_HTML_commercial_guard_P1_V7C_MW (wrap WSGI application; always inject on /vsp5) ----
try:
    import re as _re
except Exception:
    _re = None

_VSP_P1_commercial_guard_HTML_V7C = r"""
<!-- VSP_P1_commercial_guard_GLOBAL_V7C -->
<script id="VSP_P1_commercial_guard_GLOBAL_V7C">
(()=> {
  if (window.__vsp_commercial_guard_global_v7c) return;
  window.__vsp_commercial_guard_global_v7c = true;

  

  // VSP_P1_LOAD_FILLREAL_FROM_commercial_guard_P1_V2
  try{
    if (!window.__vsp_fillreal_loader_from_commercial_guard_p1_v2){
      window.__vsp_fillreal_loader_from_commercial_guard_p1_v2 = true;
      var _s=document.createElement("script");
      _s.src="/static/js/vsp_fill_real_data_5tabs_p1_v1.js";
      _s.defer=true;
      (document.head||document.documentElement).appendChild(_s);
    }
  }catch(_){}
const HOLD_MS = 15000;
  let holdUntil = Date.now() + 2500;

  const DROP = [
    /\[VSP\]\s*poll down; backoff/i,
    /poll down; backoff/i,
    /runs fetch guard\/backoff enabled/i,
    /VSP_ROUTE_GUARD_RUNS_ONLY_/i
  ];
  function _dropArgs(args){
    try{
      if (!args || !args.length) return false;
      const a0 = (typeof args[0] === "string") ? args[0] : "";
      return DROP.some(rx => rx.test(a0));
    }catch(_){ return false; }
  }
  if (!window.__vsp_console_filtered_v7c){
    window.__vsp_console_filtered_v7c = true;
    for (const k of ["log","info","warn","error"]){
      const orig = console[k].bind(console);
      console[k] = (...args)=>{ if (_dropArgs(args)) return; return orig(...args); };
    }
  }

  function _isApiVsp(u){ return !!u && u.includes("/api/vsp/"); }
  function _isPlaceholder(u){ return !!u && (u === "<URL>" || u.includes("<URL>")); }

  function _cacheKey(u){
    try{
      const uu = new URL(u, location.origin);
      return "vsp_api_cache_v7c::" + uu.pathname + uu.search;
    }catch(_){
      return "vsp_api_cache_v7c::" + String(u);
    }
  }
  function _load(u){ try{ const raw=localStorage.getItem(_cacheKey(u)); return raw?JSON.parse(raw):null; }catch(_){ return null; } }
  function _save(u,obj){ try{ localStorage.setItem(_cacheKey(u), JSON.stringify(obj)); }catch(_){ } }
  function _resp(obj,hdr){
    const h = new Headers({"Content-Type":"application/json; charset=utf-8"});
    try{ if (hdr) for (const [k,v] of Object.entries(hdr)) h.set(k, String(v)); }catch(_){}
    return new Response(JSON.stringify(obj), {status:200, headers:h});
  }

  if (window.fetch && !window.__vsp_fetch_wrapped_v7c){
    window.__vsp_fetch_wrapped_v7c = true;
    const orig = window.fetch.bind(window);
    window.fetch = async (input, init)=>{
      let u="";
      try{ u = (typeof input==="string") ? input : (input && input.url) ? input.url : ""; }catch(_){}
      if (_isPlaceholder(u)) return _resp({ok:false, note:"intercepted <URL>", marker:"V7C"}, {"X-VSP-Intercept":"1"});
      if (_isApiVsp(u)){
        const now = Date.now();
        if (now < holdUntil){
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1"});
        }
        try{
          const r = await orig(input, init);
          if (r && r.ok){
            try{ const j = await r.clone().json(); if (j && typeof j==="object") _save(u,j); }catch(_){}
            return r;
          }
          holdUntil = Date.now() + HOLD_MS;
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1","X-VSP-Non200": r ? r.status : "NA"});
        }catch(_e){
          holdUntil = Date.now() + HOLD_MS;
          const cached = _load(u) || {ok:false, note:"degraded-cache-empty"};
          return _resp(cached, {"X-VSP-Hold":"1","X-VSP-Cache":"1","X-VSP-NetFail":"1"});
        }
      }
      return orig(input, init);
    };
  }

  if (window.XMLHttpRequest && !window.__vsp_xhr_wrapped_v7c){
    window.__vsp_xhr_wrapped_v7c = true;
    const _open = XMLHttpRequest.prototype.open;
    const _send = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(method, url){
      try{ this.__vsp_url = String(url || ""); }catch(_){}
      return _open.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function(body){
      const u = (this && this.__vsp_url) ? String(this.__vsp_url) : "";
      if (_isPlaceholder(u) || _isApiVsp(u)){
        const now = Date.now();
        if (_isPlaceholder(u) || (now < holdUntil && _isApiVsp(u))){
          const cached = _isPlaceholder(u) ? {ok:false, note:"intercepted <URL>", marker:"V7C"} : (_load(u) || {ok:false, note:"degraded-cache-empty"});
          const txt = JSON.stringify(cached);
          try{
            Object.defineProperty(this, "status", { get: ()=>200, configurable:true });
            Object.defineProperty(this, "responseText", { get: ()=>txt, configurable:true });
            Object.defineProperty(this, "response", { get: ()=>txt, configurable:true });
          }catch(_){}
          const self=this;
          setTimeout(()=>{
            try{ if (typeof self.onreadystatechange==="function") self.onreadystatechange(); }catch(_){}
            try{ if (typeof self.onload==="function") self.onload(); }catch(_){}
            try{ self.dispatchEvent && self.dispatchEvent(new Event("load")); }catch(_){}
          },0);
          return;
        }
      }
      return _send.apply(this, arguments);
    };
  }
})();
</script>
"""

def _vsp_p1_inject_head_v7c(body_bytes: bytes) -> bytes:
    if _re is None:
        return body_bytes
    try:
        html = body_bytes.decode("utf-8", errors="replace")
    except Exception:
        return body_bytes
    if "VSP_P1_commercial_guard_GLOBAL_V7C" in html:
        return body_bytes
    m = _re.search(r"<head[^>]*>", html, flags=_re.I)
    if not m:
        return body_bytes
    ins = m.end()
    html2 = html[:ins] + "\n" + _VSP_P1_commercial_guard_HTML_V7C + "\n" + html[ins:]
    return html2.encode("utf-8", errors="replace")

class _VSP_HTML_Injector_V7C:
    __vsp_wrapped_v7c__ = True
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path not in ("/vsp5", "/vsp5/"):
            return self.app(environ, start_response)

        captured = {}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            captured["exc_info"] = exc_info
            # delay calling real start_response until body possibly modified
            return None

        result = self.app(environ, _sr)
        try:
            body = b"".join(result) if result is not None else b""
        finally:
            try:
                if hasattr(result, "close"):
                    result.close()
            except Exception:
                pass

        status = captured.get("status", "200 OK")
        headers = captured.get("headers", [])

        # check content-type
        ct = ""
        for k, v in headers:
            if str(k).lower() == "content-type":
                ct = str(v)
                break

        if "text/html" in (ct or ""):
            body2 = _vsp_p1_inject_head_v7c(body)
            if body2 != body:
                body = body2
                # fix content-length
                new_headers = []
                for k, v in headers:
                    if str(k).lower() == "content-length":
                        continue
                    new_headers.append((k, v))
                new_headers.append(("Content-Length", str(len(body))))
                headers = new_headers

        start_response(status, headers, captured.get("exc_info"))
        return [body]

try:
    if not getattr(application, "__vsp_wrapped_v7c__", False):
        application.wsgi_app = _VSP_HTML_Injector_V7C(application.wsgi_app)
except Exception:
    pass
# ---- end VSP_P1_HTML_commercial_guard_P1_V7C_MW ----



# VSP_P1_ROOT_AND_DATASOURCE_ROUTES_V1
# P1: ensure Dashboard (/) and Data Source (/data_source) pages are reachable on UI gateway.
try:
    from flask import render_template
except Exception:
    render_template = None

try:
    app  # noqa
except Exception:
    app = None

if app is not None and render_template is not None:
    @app.get("/")
    def vsp_root_dashboard_p1():
        return render_template("vsp_dashboard_2025.html")

    @app.get("/data_source")
    def vsp_data_source_p1():
        return render_template("vsp_data_source_v1.html")


# VSP_P1_ROOT_AND_DATASOURCE_ROUTES_V2
# P1: ensure Dashboard (/) and Data Source (/data_source) reachable on UI gateway.
try:
    from flask import render_template
except Exception:
    render_template = None

_candidates = []
for _name in ("application", "app"):
    try:
        _obj = globals().get(_name, None)
        if _obj is not None:
            _candidates.append(_obj)
    except Exception:
        pass

def _p1_rt_dashboard():
    return render_template("vsp_dashboard_2025.html")

def _p1_rt_data_source():
    return render_template("vsp_data_source_v1.html")

if render_template is not None:
    for _a in _candidates:
        try:
            # only add if not already present
            _a.add_url_rule("/", endpoint="vsp_p1_root_dashboard_v2", view_func=_p1_rt_dashboard, methods=["GET"])
        except Exception:
            pass
        try:
            _a.add_url_rule("/data_source", endpoint="vsp_p1_data_source_v2", view_func=_p1_rt_data_source, methods=["GET"])
        except Exception:
            pass


# VSP_P1_SETTINGS_BOOT_INJECT_MW_V1
# P1: /settings page is served by custom HTML; inject boot script tag if missing.
try:
    from flask import request
except Exception:
    request = None

def _vsp_p1_inject_boot(resp):
    try:
        if request is None:
            return resp
        if not request.path.startswith("/settings"):
            return resp
        ct = (resp.headers.get("Content-Type","") or "").lower()
        if "text/html" not in ct:
            return resp

        data = resp.get_data(as_text=True)
        if "vsp_p1_page_boot_v1.js" in data:
            return resp

        tag = '<script src="/static/js/vsp_p1_page_boot_v1.js?v=VSP_P1_PAGE_BOOT_V1"></script>'
        if "</body>" in data.lower():
            # insert before </body> (case-insensitive)
            idx = data.lower().rfind("</body>")
            data = data[:idx] + "\n" + tag + "\n" + data[idx:]
        else:
            data = data + "\n" + tag + "\n"

        resp.set_data(data)
        # length may change
        try:
            resp.headers.pop("Content-Length", None)
        except Exception:
            pass
        return resp
    except Exception:
        return resp

for _name in ("application","app"):
    try:
        _a = globals().get(_name)
        if _a is not None:
            try:
                _a.after_request(_vsp_p1_inject_boot)
            except Exception:
                pass
    except Exception:
        pass


# VSP_P1_FORCE_ROOT_200_OVERRIDE_REDIRECT_V4
# Ensure '/' returns 200 HTML (dashboard) even if existing route redirects to /vsp4
try:
    from flask import render_template, redirect
except Exception:
    render_template = None
    redirect = None

def _vsp_p1_root_200_v4():
    # Prefer dashboard template if exists; fallback to redirect /vsp5
    if render_template is not None:
        try:
            return render_template("vsp_dashboard_2025.html")
        except Exception:
            pass
        try:
            return render_template("vsp_5tabs_enterprise_v2.html")
        except Exception:
            pass
    if redirect is not None:
        return redirect("/vsp5")
    return ("OK", 200)

for _name in ("application","app"):
    try:
        _a = globals().get(_name)
        if _a is None:
            continue
        # Override any existing endpoint mapped to '/'
        try:
            _over = 0
            for _r in list(_a.url_map.iter_rules()):
                if getattr(_r, "rule", None) == "/" and getattr(_r, "endpoint", "") != "static":
                    try:
                        _a.view_functions[_r.endpoint] = _vsp_p1_root_200_v4
                        _over += 1
                    except Exception:
                        pass
            if _over == 0:
                try:
                    _a.add_url_rule("/", endpoint="vsp_p1_root_200_v4", view_func=_vsp_p1_root_200_v4, methods=["GET"])
                except Exception:
                    pass
        except Exception:
            pass
    except Exception:
        pass


# === VSP_GATEWAY_INJECT_FILLREAL_ALLHTML_P1_V1 ===
try:
    _vsp_app = app  # Flask app name commonly "app"
except Exception:
    _vsp_app = None

if _vsp_app is not None:
    @_vsp_app.after_request
    def _vsp_p1_inject_fillreal_all_html(resp):
        try:
            ct = (resp.headers.get("Content-Type") or "").lower()
            if "text/html" not in ct:
                return resp
            # avoid streaming / passthrough
            if getattr(resp, "direct_passthrough", False):
                return resp

            b = resp.get_data()
            if not b:
                return resp
            html = b.decode("utf-8", errors="replace")

            # already injected?
            if "vsp_fill_real_data_5tabs_p1_v1.js" in html or "VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY" in html:
                return resp

            tag = (
                "\n<!-- VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                "<script src='/static/js/vsp_fill_real_data_5tabs_p1_v1.js'></script>\n"
                "<!-- /VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
            )

            if "</body>" in html:
                html = html.replace("</body>", tag + "</body>")
            elif "</html>" in html:
                html = html.replace("</html>", tag + "</html>")
            else:
                html = html + tag

            resp.set_data(html.encode("utf-8"))
            # Content-Length must be recalculated
            try:
                resp.headers.pop("Content-Length", None)
            except Exception:
                pass
            return resp
        except Exception:
            return resp
# === /VSP_GATEWAY_INJECT_FILLREAL_ALLHTML_P1_V1 ===



# === VSP_GATEWAY_WRAP_APPLICATION_WITH_FILLREAL_P1_V3 ===
try:
    _vsp_inner = globals().get("application") or globals().get("app")
    if _vsp_inner is not None and not isinstance(_vsp_inner, _VspHtmlInjectMw):
        application.wsgi_app = _VspHtmlInjectMw(_vsp_inner)
except Exception:
    pass
# === /VSP_GATEWAY_WRAP_APPLICATION_WITH_FILLREAL_P1_V3 ===



# === VSP_GATEWAY_FORCE_FILLREAL_TAIL_P1_V4 ===
try:
    # FORCE LAST WRAP: must be after all other `application = ...` wrappers
    application.wsgi_app = _VspHtmlInjectMw(application.wsgi_app)
except Exception:
    pass
# === /VSP_GATEWAY_FORCE_FILLREAL_TAIL_P1_V4 ===




# === VSP_GATEWAY_FILLREAL_PROBE_HEADER_P1_V5 ===
import re as _re

class _VspFillRealProbeMWP1V5:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        captured = {"status": None, "headers": None, "exc": None}

        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers) if headers else []
            captured["exc"] = exc_info
            # return write callable
            def _write(_data): return None
            return _write

        app_iter = self.app(environ, _sr)

        try:
            chunks=[]
            for c in app_iter:
                if c:
                    chunks.append(c)
            body = b"".join(chunks)
        finally:
            try:
                close=getattr(app_iter,"close",None)
                if callable(close): close()
            except Exception:
                pass

        headers = captured["headers"] or []
        # always add probe header
        headers = [(k,v) for (k,v) in headers if str(k).lower() != "x-vsp-fillreal"]
        headers.append(("X-VSP-FILLREAL", "P1_V5"))

        # sniff headers
        ct = ""
        ce = ""
        for (k,v) in headers:
            lk = str(k).lower()
            if lk == "content-type": ct = str(v).lower()
            if lk == "content-encoding": ce = str(v).lower()

        # only inject into plain html (skip gzip/br)
        if "text/html" in ct and body and (not ce or ("gzip" not in ce and "br" not in ce)):
            try:
                html = body.decode("utf-8", errors="replace")
                if ("vsp_fill_real_data_5tabs_p1_v1.js" not in html) and ("VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY" not in html) and ("VSP_RUNS_STANDALONE_HARDFIX_P0_V2" not in html) and ("VSP_RUNS_PAGE_FACTORY_RESET_STATIC_P0_V1" not in html) and (not _vsp_is_runs_path(environ)):  # VSP_P0_SKIP_FILLREAL_ON_RUNS_MARKER_V1
                    tag = (
                        "\n<!-- VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                        "<script src='/static/js/vsp_fill_real_data_5tabs_p1_v1.js'></script>\n"
                        "<!-- /VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY -->\n"
                    )
                    # case-insensitive insert before </body> or </html>
                    if _re.search(r"</body\s*>", html, flags=_re.I):
                        html = _re.sub(r"</body\s*>", tag + "</body>", html, count=1, flags=_re.I)
                    elif _re.search(r"</html\s*>", html, flags=_re.I):
                        html = _re.sub(r"</html\s*>", tag + "</html>", html, count=1, flags=_re.I)
                    else:
                        html = html + tag
                    body = html.encode("utf-8")

                    # fix content-length
                    headers = [(k,v) for (k,v) in headers if str(k).lower() != "content-length"]
                    headers.append(("Content-Length", str(len(body))))
            except Exception:
                pass

        start_response(captured["status"] or "200 OK", headers, captured["exc"])
        return [body]
# === /VSP_GATEWAY_FILLREAL_PROBE_HEADER_P1_V5 ===

# force last wrap
try:
    application.wsgi_app = _VspFillRealProbeMWP1V5(application.wsgi_app)
except Exception:
    pass




# === VSP_P1_FORCE_DEFAULT_VSP5_P1_V1 ===
def _vsp_force_default_to_vsp5(environ, start_response, app=application):
    try:
        path = (environ.get("PATH_INFO") or "")
        if path == "/" or path == "":
            start_response("302 FOUND", [("Location","/vsp5")])
            return [b""]
    except Exception:
        pass
    return app(environ, start_response)

try:
    application.wsgi_app = _vsp_force_default_to_vsp5(application.wsgi_app)
except Exception:
    pass
# === /VSP_P1_FORCE_DEFAULT_VSP5_P1_V1 ===




# === VSP_P1_RUNS_503_FALLBACK_MW_P1_V1 ===
import json as _json
from pathlib import Path as _Path
import time as _time
import urllib.parse as _urlparse

class _VspRuns503FallbackMWP1V1:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def _scan_runs(self, limit=20):
        roots = [
            _Path("/home/test/Data/SECURITY_BUNDLE/out"),
            _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
            _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        ]
        dirs=[]
        for r in roots:
            try:
                if not r.exists(): 
                    continue
                for d in r.iterdir():
                    if not d.is_dir(): 
                        continue
                    name=d.name
                    if "RUN_" not in name:
                        continue
                    try:
                        mt = d.stat().st_mtime
                    except Exception:
                        mt = 0
                    dirs.append((mt, name))
            except Exception:
                pass
        dirs.sort(reverse=True)
        items=[]
        for mt, name in dirs[:max(1,int(limit))]:
            items.append({
                "run_id": name,
                "mtime": mt,
                "has": {"csv": False, "html": False, "json": False, "sarif": False, "summary": False}
            })
        return items

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/runs"):
            return self.app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers) if headers else []
            captured["exc"] = exc_info
            def _write(_data): return None
            return _write

        try:
            it = self.app(environ, _sr)
            chunks=[]
            try:
                for c in it:
                    if c: chunks.append(c)
            finally:
                try:
                    close=getattr(it,"close",None)
                    if callable(close): close()
                except Exception:
                    pass
            body = b"".join(chunks)
            code = 200
            try:
                code = int((captured["status"] or "200").split()[0])
            except Exception:
                code = 200

            # if downstream OK -> return as-is
            if code < 500:
                start_response(captured["status"] or "200 OK", captured["headers"] or [], captured["exc"])
                return [body]

        except Exception:
            code = 503

        # FALLBACK JSON 200
        try:
            qs = (environ.get("QUERY_STRING") or "")
            q = _urlparse.parse_qs(qs)
            limit = int((q.get("limit") or [20])[0])
        except Exception:
            limit = 20

        items = self._scan_runs(limit=limit)
        payload = {
            "ok": True,
            "fallback": True,
            "items": items,
            "limit": limit,
            "error": "downstream /api/vsp/runs failed (>=500), served fallback list"
        }
        out = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
        hdrs = [("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(out))),
                ("Cache-Control","no-cache"),
                ("X-VSP-RUNS-FALLBACK","1")]
        start_response("200 OK", hdrs)
        return [out]

# wrap last
# VSP_P1_RUNS_CACHE_MW_V2
import json as _json, os as _os, time as _time, re as _re
from pathlib import Path as _Path

class _VspRunsCacheMW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
        self.ttl = float(_os.environ.get("VSP_RUNS_CACHE_TTL", "3"))
        self.limit_cap = int(_os.environ.get("VSP_RUNS_LIMIT_CAP", "10"))
        self.scan_cap = int(_os.environ.get("VSP_RUNS_SCAN_CAP", "500"))
        self._cache = {"ts": 0.0, "key": "", "payload": None}
        self._run_re = _re.compile(_os.environ.get("VSP_RUNS_DIR_REGEX", r"^(RUN_|AATE_|VSP_|btl).*"))

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path != "/api/vsp/runs":
            return self.app(environ, start_response)

        qs = (environ.get("QUERY_STRING") or "")
        limit = 5
        for part in qs.split("&"):
            if part.startswith("limit="):
                try: limit = int(part.split("=",1)[1] or "5")
                except Exception: limit = 5
        if limit <= 0: limit = 5
        if limit > self.limit_cap: limit = self.limit_cap

        roots = [
            _Path(_os.environ.get("VSP_RUNS_ROOT","") or "").expanduser(),
            _Path("/home/test/Data/SECURITY_BUNDLE/out"),
            _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        ]
        roots = [r for r in roots if str(r).strip() and r.is_dir()]

        key = "|".join(map(str,roots)) + f"|limit={limit}"
        now = _time.time()
        c = self._cache

        if c["payload"] is not None and c["key"] == key and (now - c["ts"]) < self.ttl:
            payload = c["payload"]
        else:
            items, seen, scanned = [], set(), 0
            for base in roots:
                for d in base.iterdir():
                    if scanned >= self.scan_cap: break
                    scanned += 1
                    if not d.is_dir(): continue
                    rid = d.name
                    if rid in seen: continue
                    if not self._run_re.match(rid): continue
                    seen.add(rid)

                    reports = d / "reports"
                    item = {
                        "run_id": rid,
                        "run_dir_resolved": str(d),
                        "has": {
                            "html": (reports/"index.html").is_file(),
                            "summary": (reports/"run_gate_summary.json").is_file(),
                            "json": (reports/"findings_unified.json").is_file(),
                            "csv": (reports/"findings_unified.csv").is_file(),
                            "sarif": False,
                        }
                    }
                    try: item["_mtime"] = d.stat().st_mtime
                    except Exception: item["_mtime"] = 0
                    items.append(item)

            items.sort(key=lambda x: x.get("_mtime",0), reverse=True)
            for it in items: it.pop("_mtime", None)
            payload = {"ok": True, "limit": limit, "_scanned": scanned, "items": items[:limit]}
            c["ts"], c["key"], c["payload"] = now, key, payload

        body = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
        start_response("200 OK", [
            ("Content-Type","application/json; charset=utf-8"),
            ("Content-Length", str(len(body))),
            ("Cache-Control","no-store"),
        ])
        return [body]
# /VSP_P1_RUNS_CACHE_MW_V2

_VSP_APP_INNER = _VspRuns503FallbackMWP1V1(application)
application.wsgi_app = _VspRunsCacheMW(_VSP_APP_INNER)

try:  # VSP_AUTOFIX_ORPHAN_EXCEPT
    pass
except Exception:
    pass
# === /VSP_P1_RUNS_503_FALLBACK_MW_P1_V1 ===


# ==== VSP_P1_RUNS_CONTRACT_EOF_V6B ====
# P1 commercial: guarantee /api/vsp/runs contains contract fields + at least 1 RID (fallback scan).
def _vsp_runs_contract_after_request_v6b(resp):
    try:
        from flask import request as _req
        if (_req.path or "") != "/api/vsp/runs":
            return resp

        mt = (getattr(resp, "mimetype", "") or "")
        if "json" not in mt:
            return resp

        try:
            resp.direct_passthrough = False
        except Exception:
            pass

        import json as _json, os as _os
        from pathlib import Path as _P

        raw = resp.get_data()
        txt = raw.decode("utf-8", "replace") if isinstance(raw, (bytes, bytearray)) else str(raw)
        data = _json.loads(txt) if txt.strip() else {}
        if not isinstance(data, dict) or data.get("ok") is not True:
            return resp

        items = data.get("items") or []
        if not isinstance(items, list):
            items = []
            data["items"] = items

        # effective limit = requested (cap)
        try:
            lim_req = int((_req.args.get("limit") or "50").strip())
        except Exception:
            lim_req = 50
        hard_cap = 120
        lim_eff = max(1, min(lim_req, hard_cap))
        data["limit"] = lim_eff

        # roots used (prefer env; else known defaults)
        roots = []
        env_roots = (_os.environ.get("VSP_RUNS_ROOTS") or "").strip()
        if env_roots:
            roots = [x.strip() for x in env_roots.split(":") if x.strip()]
        else:
            roots = ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci"]
        data["roots_used"] = roots

        # If items empty: fallback scan to populate recent runs (lightweight)
        if not items:
            runs = []
            for r in roots:
                rp = _P(r)
                if not rp.exists():
                    continue
                for pat in ("RUN_*", "*_RUN_*"):
                    for d in rp.glob(pat):
                        if d.is_dir():
                            try:
                                runs.append((d.stat().st_mtime, d))
                            except Exception:
                                pass
            runs.sort(key=lambda x: x[0], reverse=True)
            take = min(len(runs), lim_eff)
            if take > 0:
                new_items = []
                for _, d in runs[:take]:
                    rid = d.name
                    rep = d / "reports"
                    has = {
                        "csv": (rep / "findings_unified.csv").exists(),
                        "html": (rep / "checkmarx_like.html").exists(),
                        "json": (rep / "findings_unified.json").exists() or (d / "findings_unified.json").exists(),
                        "sarif": (rep / "findings_unified.sarif").exists() or (d / "findings_unified.sarif").exists(),
                        "summary": (rep / "run_gate_summary.json").exists() or (d / "run_gate_summary.json").exists(),
                    }
                    new_items.append({"run_id": rid, "has": has})
                data["items"] = new_items
                items = new_items

        # rid_latest
        rid_latest = ""
        if items:
            try:
                rid_latest = (items[0].get("run_id") or items[0].get("rid") or "").strip()
            except Exception:
                rid_latest = ""
        data["rid_latest"] = rid_latest

        # cache ttl
        try:
            data["cache_ttl"] = int(_os.environ.get("VSP_RUNS_CACHE_TTL", "2"))
        except Exception:
            data["cache_ttl"] = 2

        # scan cap hit (from _scanned)
        try:
            scanned = int(data.get("_scanned") or 0)
        except Exception:
            scanned = 0
        scan_cap = int(_os.environ.get("VSP_RUNS_SCAN_CAP", "500"))
        data["scan_cap"] = scan_cap
        data["scan_cap_hit"] = bool(scanned >= scan_cap)

        out = _json.dumps(data, ensure_ascii=False)
        resp.set_data(out.encode("utf-8"))
        resp.headers["Content-Length"] = str(len(resp.get_data()))
        resp.headers["X-VSP-RUNS-CONTRACT"] = "P1_V6B"
        return resp
    except Exception:
        return resp

try:
    application.after_request(_vsp_runs_contract_after_request_v6b)
except Exception:
    pass
# ==== /VSP_P1_RUNS_CONTRACT_EOF_V6B ====


# ==== VSP_P1_RUNS_CONTRACT_WSGIMW_V2 ====
# P1 commercial: WSGI middleware that rewrites /api/vsp/runs response at the LAST layer.
def _vsp__parse_qs_limit(environ, default=50, hard_cap=120):
    try:
        qs = environ.get("QUERY_STRING") or ""
        for part in qs.split("&"):
            if part.startswith("limit="):
                v = part.split("=",1)[1]
                n = int(v.strip() or default)
                return max(1, min(n, hard_cap))
    except Exception:
        pass
    return max(1, min(default, hard_cap))

def _vsp__list_latest_runs_cached(roots, limit, ttl=2):
    import time, os
    from pathlib import Path as _P
    now = time.time()
    cache = getattr(_vsp__list_latest_runs_cached, "_cache", None) or {}
    key = "|".join(roots) + ":" + str(limit)
    ent = cache.get(key)
    if ent and (now - ent["ts"] <= ttl):
        return ent["items"]

    runs = []
    for r in roots:
        try:
            rp = _P(r)
            if not rp.exists():
                continue
            with os.scandir(rp) as it:
                for de in it:
                    if not de.is_dir():
                        continue
                    nm = de.name
                    if nm.startswith("RUN_") or "_RUN_" in nm:
                        try:
                            st = de.stat()
                            runs.append((st.st_mtime, _P(de.path)))
                        except Exception:
                            pass
        except Exception:
            continue

    runs.sort(key=lambda x: x[0], reverse=True)
    take = min(len(runs), limit)
    items=[]
    for _, d in runs[:take]:
        rid = d.name
        rep = d / "reports"
        has = {
            "csv": (rep / "findings_unified.csv").exists(),
            "html": (rep / "checkmarx_like.html").exists(),
            "json": (rep / "findings_unified.json").exists() or (d / "findings_unified.json").exists(),
            "sarif": (rep / "findings_unified.sarif").exists() or (d / "findings_unified.sarif").exists(),
            "summary": (rep / "run_gate_summary.json").exists() or (d / "run_gate_summary.json").exists(),
        }
        items.append({"run_id": rid, "has": has})
    cache[key] = {"ts": now, "items": items}
    setattr(_vsp__list_latest_runs_cached, "_cache", cache)
    return items

class _VSPRunsContractWSGIMW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO") or ""
        if path != "/api/vsp/runs":
            return self.app(environ, start_response)

        captured = {"status": None, "headers": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            return None

        body_iter = self.app(environ, _sr)
        try:
            body = b"".join(body_iter)
        except Exception:
            return self.app(environ, start_response)

        status = captured["status"] or "200 OK"
        headers = captured["headers"] or []

        try:
            code = int(status.split()[0])
        except Exception:
            code = 200

        ct = ""
        for k,v in headers:
            if k.lower() == "content-type":
                ct = v
                break

        if code != 200 or ("json" not in (ct or "")):
            start_response(status, headers)
            return [body]

        try:
            import json, os
            data = json.loads(body.decode("utf-8","replace"))
            if not (isinstance(data, dict) and data.get("ok") is True and isinstance(data.get("items"), list)):
                start_response(status, headers)
                return [body]

            lim_eff = _vsp__parse_qs_limit(environ, default=int(data.get("limit") or 50))
            data["limit"] = lim_eff

            env_roots = (os.environ.get("VSP_RUNS_ROOTS") or "").strip()
            if env_roots:
                roots = [x.strip() for x in env_roots.split(":") if x.strip()]
            else:
                roots = ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci"]
            data["roots_used"] = roots

            items = data.get("items") or []
            if not items:
                items = _vsp__list_latest_runs_cached(roots, lim_eff, ttl=int(os.environ.get("VSP_RUNS_CACHE_TTL","2")))
                data["items"] = items

            rid_latest = ""
            if items:
                try:
                    rid_latest = (items[0].get("run_id") or items[0].get("rid") or "").strip()
                except Exception:
                    rid_latest = ""
            data["rid_latest"] = rid_latest

            try:
                data["cache_ttl"] = int(os.environ.get("VSP_RUNS_CACHE_TTL","2"))
            except Exception:
                data["cache_ttl"] = 2

            try:
                scanned = int(data.get("_scanned") or 0)
            except Exception:
                scanned = 0
            scan_cap = int(os.environ.get("VSP_RUNS_SCAN_CAP","500"))
            data["scan_cap"] = scan_cap
            data["scan_cap_hit"] = bool(scanned >= scan_cap)

            out = json.dumps(data, ensure_ascii=False).encode("utf-8")

            new_headers=[]
            for k,v in headers:
                if k.lower() == "content-length":
                    continue
                new_headers.append((k,v))
            new_headers.append(("Content-Length", str(len(out))))
            new_headers.append(("X-VSP-RUNS-CONTRACT", "P1_WSGI_V2"))

            start_response(status, new_headers)
            return [out]
        except Exception:
            start_response(status, headers)
            return [body]

try:
    if "application" in globals() and not getattr(application, "__vsp_runs_contract_wrapped__", False):
        application.wsgi_app = _VSPRunsContractWSGIMW(application.wsgi_app)
        try:
            application.__vsp_runs_contract_wrapped__ = True
        except Exception:
            pass
except Exception:
    pass
# ==== /VSP_P1_RUNS_CONTRACT_WSGIMW_V2 ====


# ==== VSP_P1_SHA256_FALLBACK_V1 ====
def _vsp__sha256_hex(path):
    import hashlib
    h=hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _vsp__qs_get(environ, key):
    qs = environ.get("QUERY_STRING") or ""
    for part in qs.split("&"):
        if part.startswith(key + "="):
            return part.split("=",1)[1]
    return ""

def _vsp__safe_unquote(s):
    try:
        from urllib.parse import unquote_plus
        return unquote_plus(s)
    except Exception:
        return s

class _VSPSha256FallbackWSGIMW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO") or ""
        if path != "/api/vsp/sha256":
            return self.app(environ, start_response)

        # Let downstream handler try first; if it returns 404, we attempt fallback.
        captured = {"status": None, "headers": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            return None

        body_iter = self.app(environ, _sr)
        try:
            body = b"".join(body_iter)
        except Exception:
            return self.app(environ, start_response)

        status = captured["status"] or "200 OK"
        headers = captured["headers"] or []
        try:
            code = int(status.split()[0])
        except Exception:
            code = 200

        if code != 404:
            start_response(status, headers)
            return [body]

        # fallback compute sha256 if possible
        import os
        from pathlib import Path as _P

        rid = _vsp__safe_unquote(_vsp__qs_get(environ, "rid"))
        name = _vsp__safe_unquote(_vsp__qs_get(environ, "name"))

        # basic guard
        if not rid or not name:
            start_response(status, headers)
            return [body]

        # candidate names
        cands = [name]
        # common fallbacks: reports/x -> x
        if name.startswith("reports/"):
            cands.append(name[len("reports/"):])

        # try to resolve within known roots used by runs listing
        roots = []
        env_roots = (os.environ.get("VSP_RUNS_ROOTS") or "").strip()
        if env_roots:
            roots = [x.strip() for x in env_roots.split(":") if x.strip()]
        else:
            roots = ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci"]

        found = None
        found_rel = None
        for r in roots:
            base = _P(r) / rid
            if not base.exists():
                continue
            for rel in cands:
                fp = base / rel
                if fp.exists() and fp.is_file():
                    found = fp
                    found_rel = rel
                    break
            if found:
                break

        if not found:
            start_response(status, headers)
            return [body]

        try:
            digest = _vsp__sha256_hex(str(found))
            import json
            out = json.dumps({"ok": True, "rid": rid, "name": name, "resolved": found_rel, "sha256": digest}, ensure_ascii=False).encode("utf-8")
            new_headers=[]
            for k,v in headers:
                if k.lower() in ("content-length","content-type"):
                    continue
                new_headers.append((k,v))
            new_headers.append(("Content-Type","application/json; charset=utf-8"))
            new_headers.append(("Content-Length", str(len(out))))
            new_headers.append(("X-VSP-SHA256-FALLBACK", found_rel or ""))
            start_response("200 OK", new_headers)
            return [out]
        except Exception:
            start_response(status, headers)
            return [body]

try:
    if "application" in globals() and not getattr(application, "__vsp_sha256_fallback_wrapped__", False):
        application.wsgi_app = _VSPSha256FallbackWSGIMW(application.wsgi_app)
        try:
            application.__vsp_sha256_fallback_wrapped__ = True
        except Exception:
            pass
except Exception:
    pass
# ==== /VSP_P1_SHA256_FALLBACK_V1 ====


# ==== VSP_P1_SHA256_ALWAYS200_WSGIMW_V2 ====
def _vsp__sha256_hex(path):
    import hashlib
    h=hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _vsp__qs_get(environ, key):
    qs = environ.get("QUERY_STRING") or ""
    for part in qs.split("&"):
        if part.startswith(key + "="):
            return part.split("=",1)[1]
    return ""

def _vsp__unq(s):
    try:
        from urllib.parse import unquote_plus
        return unquote_plus(s)
    except Exception:
        return s

def _vsp__is_safe_rel(rel):
    # prevent path traversal
    if not rel or rel.startswith("/") or rel.startswith("\\"):
        return False
    if ".." in rel.replace("\\\\","/").split("/"):
        return False
    return True

class _VSPSha256Always200WSGIMW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO") or ""
        if path not in ("/api/vsp/sha256", "/api/vsp/sha256/"):
            return self.app(environ, start_response)

        import os, json
        from pathlib import Path as _P

        rid  = _vsp__unq(_vsp__qs_get(environ, "rid"))
        name = _vsp__unq(_vsp__qs_get(environ, "name"))

        # default response (degraded)
        resp = {"ok": False, "rid": rid, "name": name, "missing": True, "resolved": None, "sha256": None}

        # resolve roots
        env_roots = (os.environ.get("VSP_RUNS_ROOTS") or "").strip()
        roots = [x.strip() for x in env_roots.split(":") if x.strip()] if env_roots else [
            "/home/test/Data/SECURITY_BUNDLE/out",
            "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        ]

        # candidate relative paths (fallbacks)
        cands = []
        if name and _vsp__is_safe_rel(name):
            cands.append(name)
            if name.startswith("reports/"):
                alt = name[len("reports/"):]
                if _vsp__is_safe_rel(alt):
                    cands.append(alt)

        found = None
        found_rel = None
        if rid and cands:
            for r in roots:
                base = _P(r) / rid
                if not base.exists():
                    continue
                for rel in cands:
                    fp = base / rel
                    if fp.exists() and fp.is_file():
                        found = fp
                        found_rel = rel
                        break
                if found:
                    break

        if found:
            try:
                resp["ok"] = True
                resp["missing"] = False
                resp["resolved"] = found_rel
                resp["sha256"] = _vsp__sha256_hex(str(found))
            except Exception:
                resp["ok"] = False
                resp["missing"] = True

        out = json.dumps(resp, ensure_ascii=False).encode("utf-8")
        headers = [
            ("Content-Type","application/json; charset=utf-8"),
            ("Content-Length", str(len(out))),
            ("X-VSP-SHA256", "P1_WSGI_V2"),
        ]
        if resp.get("missing"):
            headers.append(("X-VSP-DEGRADED", "sha256_missing_artifact"))
        else:
            headers.append(("X-VSP-SHA256-RESOLVED", resp.get("resolved") or ""))

        start_response("200 OK", headers)
        return [out]

try:
    if "application" in globals() and not getattr(application, "__vsp_sha256_always200_wrapped__", False):
        application.wsgi_app = _VSPSha256Always200WSGIMW(application.wsgi_app)
        try:
            application.__vsp_sha256_always200_wrapped__ = True
        except Exception:
            pass
except Exception:
    pass
# ==== /VSP_P1_SHA256_ALWAYS200_WSGIMW_V2 ====



# --- VSP_P1_RUNS_ALWAYS200_WSGIMW_V1 ---
# Commercial hardening: /api/vsp/runs never flakes the UI. If downstream fails, serve last-good cache (200) + degraded headers.
import os, json, time, traceback

class _VspRunsAlways200MW:
    def __init__(self, app, cache_path):
        self.app = _vsp_base_wsgi(app)
        self.cache_path = cache_path

    def _write_cache(self, body_bytes):
        try:
            os.makedirs(os.path.dirname(self.cache_path), exist_ok=True)
            with open(self.cache_path, "wb") as f:
                f.write(body_bytes)
        except Exception:
            pass

    def _read_cache(self):
        try:
            with open(self.cache_path, "rb") as f:
                return f.read()
        except Exception:
            return None

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        qs   = (environ.get("QUERY_STRING") or "")
        if not path.startswith("/api/vsp/runs"):
            return self.app(environ, start_response)

        info = {"path": path, "qs": qs}
        status_box = {}
        headers_box = {}

        def _sr(status, headers, exc_info=None):
            status_box["status"] = status
            headers_box["headers"] = list(headers or [])
            return start_response(status, headers, exc_info)

        try:
            chunks = []
            app_iter = self.app(environ, _sr)
            for c in app_iter:
                chunks.append(c)
            if hasattr(app_iter, "close"):
                try: app_iter.close()
                except Exception: pass

            body = b"".join(chunks)
            st = (status_box.get("status") or "500").split()[0]

            # If not 200 -> fallback to cache as 200 (degraded)
            if st != "200":
                cached = self._read_cache()
                if cached:
                    hdrs = [("Content-Type","application/json; charset=utf-8"),
                            ("Cache-Control","no-cache"),
                            ("X-VSP-RUNS-DEGRADED","1"),
                            ("X-VSP-RUNS-DEGRADED-REASON", f"status_{st}")]
                    start_response("200 OK", hdrs)
                    return [cached]
                # no cache => return minimal ok=true degraded payload
                payload = {"ok": True, "degraded": True, "reason": f"status_{st}", "items": [], "rid_latest": None, "ts": int(time.time())}
                b = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                hdrs = [("Content-Type","application/json; charset=utf-8"),
                        ("Cache-Control","no-cache"),
                        ("X-VSP-RUNS-DEGRADED","1"),
                        ("X-VSP-RUNS-DEGRADED-REASON", f"status_{st}")]
                start_response("200 OK", hdrs)
                return [b]

            # 200 OK => update cache and pass through
            self._write_cache(body)
            return [body]

        except Exception as e:
            cached = self._read_cache()
            if cached:
                hdrs = [("Content-Type","application/json; charset=utf-8"),
                        ("Cache-Control","no-cache"),
                        ("X-VSP-RUNS-DEGRADED","1"),
                        ("X-VSP-RUNS-DEGRADED-REASON","exception_cached")]
                start_response("200 OK", hdrs)
                return [cached]
            payload = {"ok": True, "degraded": True, "reason": "exception_no_cache", "error": str(e), "items": [], "rid_latest": None, "ts": int(time.time())}
            b = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            hdrs = [("Content-Type","application/json; charset=utf-8"),
                    ("Cache-Control","no-cache"),
                    ("X-VSP-RUNS-DEGRADED","1"),
                    ("X-VSP-RUNS-DEGRADED-REASON","exception_no_cache")]
            start_response("200 OK", hdrs)
            return [b]

# Wrap last-layer (outside everything else)
try:
    _RUNS_CACHE_PATH = os.environ.get("VSP_RUNS_CACHE_PATH", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/runs_cache_last_good.json")
    application.wsgi_app = _VspRunsAlways200MW(application.wsgi_app, _RUNS_CACHE_PATH)
except Exception:
    pass
# --- /VSP_P1_RUNS_ALWAYS200_WSGIMW_V1 ---


# --- VSP_P1_REPORTS_ALIAS_LATEST_WSGIMW_V1 ---
# Ensure /api/reports/* always targets current rid_latest (so UI dashboard never shows stale RID)
import os, json, time
from urllib.parse import urlencode

def _vsp_pick_rid_latest():
    roots = os.environ.get("VSP_RUNS_ROOTS","/home/test/Data/SECURITY_BUNDLE/out").split(":")
    roots = [r.strip() for r in roots if r.strip()]
    best = None
    best_m = -1
    for root in roots:
        try:
            for name in os.listdir(root):
                if name.startswith("."): 
                    continue
                pth = os.path.join(root, name)
                if not os.path.isdir(pth):
                    continue
                # accept things that look like run dirs, including our alias VSP_CI_RUN_*
                if ("_RUN_" not in name) and (not name.startswith("RUN_")) and (not name.startswith("VSP_CI_RUN_")):
                    continue
                try:
                    m = os.path.getmtime(pth)
                except Exception:
                    continue
                if m > best_m:
                    best_m = m
                    best = name
        except Exception:
            continue
    return best

class _VspReportsAliasLatestMW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/reports/"):
            return self.app(environ, start_response)

        # map /api/reports/<file> -> /api/vsp/run_file?rid=<rid_latest>&name=reports/<file>
        rid = _vsp_pick_rid_latest()
        fname = path[len("/api/reports/"):]  # e.g. run_gate_summary.json
        if not fname:
            payload = {"ok": False, "error":"missing filename", "ts": int(time.time())}
            b = json.dumps(payload).encode("utf-8")
            start_response("400 Bad Request", [("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store")])
            return [b]
        if not rid:
            payload = {"ok": False, "error":"no rid_latest", "ts": int(time.time())}
            b = json.dumps(payload).encode("utf-8")
            start_response("404 Not Found", [("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store")])
            return [b]

        qs = urlencode({"rid": rid, "name": f"reports/{fname}"})
        loc = f"/api/vsp/run_file?{qs}"
        hdrs = [("Location", loc),
                ("Cache-Control","no-store"),
                ("X-VSP-REPORTS-ALIAS","latest"),
                ("X-VSP-REPORTS-RID", rid)]
        start_response("302 Found", hdrs)
        return [b""]

try:
    application.wsgi_app = _VspReportsAliasLatestMW(application.wsgi_app)
except Exception:
    pass
# --- /VSP_P1_REPORTS_ALIAS_LATEST_WSGIMW_V1 ---


# --- VSP_P1_REPORTS_RUNFILE_FOLLOW_RIDLATEST_CACHE_V1 ---
# Data-first hardening:
# 1) /api/reports/* always redirects to rid_latest from runs cache (not "some latest RUN_*")
# 2) /api/vsp/run_file when rid/name missing -> fallback redirect to rid_latest (prevents Data Source 404 with stale RID)
import os, json, time
from urllib.parse import urlencode, parse_qs

def _vsp_runs_cache_path():
    return os.environ.get("VSP_RUNS_CACHE_PATH", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/runs_cache_last_good.json")

def _vsp_get_rid_latest_from_cache():
    force = os.environ.get("VSP_REPORTS_ALIAS_FORCE_RID","").strip()
    if force:
        return force
    try:
        b = open(_vsp_runs_cache_path(), "rb").read()
        j = json.loads(b.decode("utf-8","replace"))
        rid = (j.get("rid_latest") or "").strip()
        return rid or None
    except Exception:
        return None

def _vsp_runs_roots():
    roots = os.environ.get("VSP_RUNS_ROOTS", "/home/test/Data/SECURITY_BUNDLE/out").split(":")
    return [r.strip() for r in roots if r.strip()]

def _vsp_safe_rel(name: str) -> bool:
    if not name or name.startswith("/") or "\x00" in name:
        return False
    # prevent traversal
    if ".." in name.split("/"):
        return False
    return True

def _vsp_runfile_exists(rid: str, relname: str) -> bool:
    if not rid or not relname or (not _vsp_safe_rel(relname)):
        return False
    for root in _vsp_runs_roots():
        try:
            base = os.path.join(root, rid)
            if os.path.isdir(base):
                p = os.path.join(base, relname)
                if os.path.isfile(p):
                    return True
        except Exception:
            continue
    return False

class _VspReportsFollowRidLatestMW:
    def __init__(self, app): self.app = app
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/reports/"):
            return self.app(environ, start_response)
        fname = path[len("/api/reports/"):]  # e.g. findings_unified.json
        if not fname:
            start_response("400 Bad Request",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store")])
            return [b'{"ok":false,"error":"missing filename"}']
        rid = _vsp_get_rid_latest_from_cache()
        if not rid:
            start_response("503 Service Unavailable",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),
                                                     ("X-VSP-REPORTS-DEGRADED","1"),("X-VSP-REPORTS-REASON","no_rid_latest_cache")])
            return [b'{"ok":true,"degraded":true,"reason":"no_rid_latest_cache"}']
        qs = urlencode({"rid": rid, "name": f"reports/{fname}"})
        loc = f"/api/vsp/run_file?{qs}"
        start_response("302 Found",[("Location",loc),("Cache-Control","no-store"),
                                   ("X-VSP-REPORTS-ALIAS","rid_latest_cache"),
                                   ("X-VSP-REPORTS-RID",rid)])
        return [b""]

class _VspRunFileFallbackLatestMW:
    def __init__(self, app): self.app = app
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path != "/api/vsp/run_file":
            return self.app(environ, start_response)

        qs = parse_qs(environ.get("QUERY_STRING",""), keep_blank_values=True)
        rid = (qs.get("rid",[None])[0] or "").strip()
        name = (qs.get("name",[None])[0] or "").strip()

        # Only fallback for safe names (prevent traversal)
        if not _vsp_safe_rel(name):
            return self.app(environ, start_response)

        # If requested file exists -> normal
        if rid and _vsp_runfile_exists(rid, name):
            return self.app(environ, start_response)

        # If missing -> redirect to rid_latest if that file exists
        rid2 = _vsp_get_rid_latest_from_cache()
        if rid2 and _vsp_runfile_exists(rid2, name):
            qs2 = urlencode({"rid": rid2, "name": name})
            loc = f"/api/vsp/run_file?{qs2}"
            start_response("302 Found",[("Location",loc),("Cache-Control","no-store"),
                                       ("X-VSP-RUNFILE-FALLBACK","1"),
                                       ("X-VSP-RUNFILE-OLD", rid or "none"),
                                       ("X-VSP-RUNFILE-NEW", rid2)])
            return [b""]

        # else: let app handle (will 404/503 as before)
        return self.app(environ, start_response)

# Wrap OUTERMOST so it overrides any existing Flask route logic
try:
    application.wsgi_app = _VspRunFileFallbackLatestMW(application.wsgi_app)
    application.wsgi_app = _VspReportsFollowRidLatestMW(application.wsgi_app)
except Exception:
    pass
# --- /VSP_P1_REPORTS_RUNFILE_FOLLOW_RIDLATEST_CACHE_V1 ---


# --- VSP_P1_FORCE_WRAP_REPORTS_RUNFILE_LATEST_V1 ---
# Force WSGI wrapping at module-level `application` (works even if `application` is not Flask).
import os, json, time, glob
from urllib.parse import urlencode, parse_qs

def _vsp_roots():
    roots = os.environ.get("VSP_RUNS_ROOTS", "/home/test/Data/SECURITY_BUNDLE/out").split(":")
    return [r.strip() for r in roots if r.strip()]

def _safe_rel(name: str) -> bool:
    if not name or name.startswith("/") or "\x00" in name:
        return False
    if ".." in name.split("/"):
        return False
    return True

def _runfile_exists(rid: str, relname: str) -> bool:
    if not rid or not relname or (not _safe_rel(relname)):
        return False
    for root in _vsp_roots():
        try:
            base = os.path.join(root, rid)
            if os.path.isdir(base):
                p = os.path.join(base, relname)
                if os.path.isfile(p):
                    return True
        except Exception:
            continue
    return False

def _rid_latest_from_runs_cache():
    # If force env set, obey
    force = os.environ.get("VSP_REPORTS_ALIAS_FORCE_RID", "").strip()
    if force:
        return force

    # Try find newest cache file in ui/out_ci
    cand = []
    try:
        ui_out_ci = os.path.join(os.path.dirname(__file__), "out_ci")
        pats = [
            os.path.join(ui_out_ci, "runs_cache*.json"),
            os.path.join(ui_out_ci, "*runs*cache*.json"),
            os.path.join(ui_out_ci, "vsp_runs*.json"),
        ]
        for pat in pats:
            for f in glob.glob(pat):
                try:
                    cand.append((os.path.getmtime(f), f))
                except Exception:
                    pass
    except Exception:
        pass

    cand.sort(reverse=True)
    for _, f in cand[:5]:
        try:
            j = json.loads(open(f, "rb").read().decode("utf-8","replace"))
            rid = (j.get("rid_latest") or "").strip()
            if rid:
                return rid
        except Exception:
            continue

    # Fallback: scan roots, prefer VSP_CI_RUN_*, then any *_RUN_*/RUN_*
    best = None
    best_m = -1
    prefer = None
    prefer_m = -1
    for root in _vsp_roots():
        try:
            for name in os.listdir(root):
                if name.startswith("."): 
                    continue
                pth = os.path.join(root, name)
                if not os.path.isdir(pth) and not os.path.islink(pth):
                    continue
                try:
                    m = os.path.getmtime(pth)
                except Exception:
                    continue
                if name.startswith("VSP_CI_RUN_"):
                    if m > prefer_m:
                        prefer_m = m
                        prefer = name
                if ("_RUN_" in name) or name.startswith("RUN_"):
                    if m > best_m:
                        best_m = m
                        best = name
        except Exception:
            continue
    return prefer or best

class _ForceWrapReportsRunFileMW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        qs_raw = (environ.get("QUERY_STRING") or "")

        # 1) /api/reports/<file> -> redirect to rid_latest + reports/<file>
        if path.startswith("/api/reports/"):
            fname = path[len("/api/reports/"):]
            rid = _rid_latest_from_runs_cache()
            if not fname:
                start_response("400 Bad Request",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store")])
                return [b'{"ok":false,"error":"missing filename"}']
            if not rid:
                start_response("503 Service Unavailable",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),
                                                         ("X-VSP-REPORTS-DEGRADED","1"),("X-VSP-REPORTS-REASON","no_rid_latest")])
                return [b'{"ok":true,"degraded":true,"reason":"no_rid_latest"}']
            loc = "/api/vsp/run_file?" + urlencode({"rid": rid, "name": f"reports/{fname}"})
            start_response("302 Found",[("Location",loc),("Cache-Control","no-store"),
                                        ("X-VSP-REPORTS-ALIAS","rid_latest"),
                                        ("X-VSP-REPORTS-RID",rid)])
            return [b""]

        # 2) /api/vsp/run_file fallback:
        # if rid is stale and file missing => redirect to rid_latest if file exists there
        if path == "/api/vsp/run_file":
            qs = parse_qs(qs_raw, keep_blank_values=True)
            rid = (qs.get("rid",[None])[0] or "").strip()
            name = (qs.get("name",[None])[0] or "").strip()

            if _safe_rel(name):
                if (not rid) or (not _runfile_exists(rid, name)):
                    rid2 = _rid_latest_from_runs_cache()
                    if rid2 and _runfile_exists(rid2, name):
                        loc = "/api/vsp/run_file?" + urlencode({"rid": rid2, "name": name})
                        start_response("302 Found",[("Location",loc),("Cache-Control","no-store"),
                                                    ("X-VSP-RUNFILE-FALLBACK","1"),
                                                    ("X-VSP-RUNFILE-OLD", rid or "none"),
                                                    ("X-VSP-RUNFILE-NEW", rid2)])
                        return [b""]

        return self.app(environ, start_response)

# FORCE wrap callable application (outermost)
try:
    _orig_app = application
    # VSP_P1_FIX_FORCEWRAP_RECURSION_V11
    _fw_rrf_arg = _orig_app
    _fw_rrf_wsgi = getattr(_fw_rrf_arg, 'wsgi_app', _fw_rrf_arg)
    application.wsgi_app = _ForceWrapReportsRunFileMW(_fw_rrf_wsgi)
except Exception:
    pass
# --- /VSP_P1_FORCE_WRAP_REPORTS_RUNFILE_LATEST_V1 ---


# --- VSP_P1_FORCE_WRAP_RUNS_ALWAYS200_V1 ---
# Force /api/vsp/runs always returns 200 (cache fallback) to avoid UI "RUNS API FAIL 503".
import os, json, time

def _runs_cache_path():
    return os.environ.get("VSP_RUNS_CACHE_PATH", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/runs_cache_last_good.json")

class _ForceWrapRunsAlways200MW:
    def __init__(self, app):
        self.app = _vsp_base_wsgi(app)
    def _read_cache(self):
        try:
            return open(_runs_cache_path(), "rb").read()
        except Exception:
            return None

    def _write_cache(self, b):
        try:
            os.makedirs(os.path.dirname(_runs_cache_path()), exist_ok=True)
            with open(_runs_cache_path(), "wb") as f:
                f.write(b)
        except Exception:
            pass

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/runs"):
            return self.app(environ, start_response)

        status_box = {}
        headers_box = {}

        def _sr(status, headers, exc_info=None):
            status_box["status"] = status
            headers_box["headers"] = list(headers or [])
            return start_response(status, headers, exc_info)

        try:
            chunks=[]
            it = self.app(environ, _sr)
            for c in it:
                chunks.append(c)
            if hasattr(it, "close"):
                try: it.close()
                except Exception: pass

            body = b"".join(chunks)
            code = (status_box.get("status") or "500").split()[0]

            if code == "200":
                # cache only if JSON decodes
                try:
                    j = json.loads(body.decode("utf-8","replace"))
                    if isinstance(j, dict) and j.get("ok") is True and j.get("items") is not None:
                        self._write_cache(body)
                except Exception:
                    pass
                return [body]

            cached = self._read_cache()
            if cached:
                hdrs=[("Content-Type","application/json; charset=utf-8"),
                      ("Cache-Control","no-store"),
                      ("X-VSP-RUNS-DEGRADED","1"),
                      ("X-VSP-RUNS-DEGRADED-REASON", f"status_{code}")]
                start_response("200 OK", hdrs)
                return [cached]

            payload={"ok": True, "degraded": True, "reason": f"status_{code}", "rid_latest": None, "items": [], "ts": int(time.time())}
            b=json.dumps(payload, ensure_ascii=False).encode("utf-8")
            hdrs=[("Content-Type","application/json; charset=utf-8"),
                  ("Cache-Control","no-store"),
                  ("X-VSP-RUNS-DEGRADED","1"),
                  ("X-VSP-RUNS-DEGRADED-REASON", f"status_{code}")]
            start_response("200 OK", hdrs)
            return [b]

        except Exception as e:
            cached = self._read_cache()
            if cached:
                hdrs=[("Content-Type","application/json; charset=utf-8"),
                      ("Cache-Control","no-store"),
                      ("X-VSP-RUNS-DEGRADED","1"),
                      ("X-VSP-RUNS-DEGRADED-REASON","exception_cached")]
                start_response("200 OK", hdrs)
                return [cached]
            payload={"ok": True, "degraded": True, "reason":"exception_no_cache", "error": str(e), "rid_latest": None, "items": [], "ts": int(time.time())}
            b=json.dumps(payload, ensure_ascii=False).encode("utf-8")
            hdrs=[("Content-Type","application/json; charset=utf-8"),
                  ("Cache-Control","no-store"),
                  ("X-VSP-RUNS-DEGRADED","1"),
                  ("X-VSP-RUNS-DEGRADED-REASON","exception_no_cache")]
            start_response("200 OK", hdrs)
            return [b]

# FORCE wrap module-level callable `application`
try:
    _orig_app_runs = application
    # VSP_P1_FIX_RUNSALWAYS200_KEEP_FLASK_V2
    # keep Flask app; wrap only WSGI callable
    application.wsgi_app = _ForceWrapRunsAlways200MW(application.wsgi_app)
except Exception:
    pass
# --- /VSP_P1_FORCE_WRAP_RUNS_ALWAYS200_V1 ---


# VSP_P1_RUNS_NEVER_503_MW_V1 application
@application.after_request
def _vsp_p1_runs_never_503(resp):
    try:
        # local import: avoid touching global imports
        from flask import request, jsonify
        if request.path == "/api/vsp/runs":
            code = getattr(resp, "status_code", 200) if resp is not None else 500
            if code >= 500:
                payload = {
                    "ok": False,
                    "degraded": True,
                    "rid_latest": None,
                    "items": [],
                    "error": "runs endpoint degraded (auto-mapped from %s)" % code
                }
                r = jsonify(payload)
                r.status_code = 200
                r.headers["X-VSP-RUNS-DEGRADED"] = "1"
                r.headers["Cache-Control"] = "no-store"
                return r
    except Exception:
        pass
    return resp


# VSP_P0_ROOT_REDIRECT_TO_VSP5_MW_V1
class _VspRootRedirectToVsp5MW:
    def __init__(self, app, target="/vsp5"):
        self.app = _vsp_base_wsgi(app)
        self.target = target
    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "").strip()
        if path == "" or path == "/":
            start_response("302 Found", [
                ("Location", self.target),
                ("Content-Type", "text/plain; charset=utf-8"),
                ("Content-Length", "0"),
            ])
            return [b""]
        return self.app(environ, start_response)

try:
    application.wsgi_app = _VspRootRedirectToVsp5MW(application.wsgi_app)
except Exception:
    pass


# VSP_P1_DASH_KPIS_CHARTS_FROM_REPORTS_V2
# Provide /api/vsp/dash_kpis and /api/vsp/dash_charts used by vsp5 UI.
# Robust fallback: derive from existing /api/vsp/runs + /api/vsp/run_file artifacts.
import json as _json
import math as _math
from urllib.parse import parse_qs as _parse_qs, urlencode as _urlencode
from urllib.request import urlopen as _urlopen, Request as _Request

def _vsp__base_url_from_environ(environ):
    scheme = environ.get("wsgi.url_scheme") or "http"
    host = environ.get("HTTP_HOST")
    if not host:
        host = environ.get("SERVER_NAME") or "127.0.0.1"
        port = environ.get("SERVER_PORT")
        if port and port not in ("80","443"):
            host = f"{host}:{port}"
    return f"{scheme}://{host}"

def _vsp__http_json(base, path, timeout=3.0):
    req = _Request(base + path, headers={"Accept":"application/json","X-VSP-Internal":"1"})
    with _urlopen(req, timeout=timeout) as r:
        body = r.read().decode("utf-8", "replace")
    return _json.loads(body)

def _vsp__get_latest_rid(base):
    j = _vsp__http_json(base, "/api/vsp/runs?limit=1", timeout=3.0)
    items = (j or {}).get("items") or []
    if items and isinstance(items[0], dict):
        return items[0].get("run_id") or ""
    return ""

def _vsp__run_file_json(base, rid, name):
    q = _urlencode({"rid": rid, "name": name})
    return _vsp__http_json(base, f"/api/vsp/run_file?{q}", timeout=5.0)

def _vsp__extract_findings_list(obj):
    if obj is None:
        return []
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        for k in ("items","findings","data","results"):
            v = obj.get(k)
            if isinstance(v, list):
                return v
    return []

def _vsp__pick_cwe(f):
    if not isinstance(f, dict):
        return None
    for k in ("cwe","cwe_id","cweId","cwe_ids","cweIds"):
        v = f.get(k)
        if isinstance(v, str) and "CWE" in v.upper():
            vv = v.upper().replace(" ", "")
            if vv.startswith("CWE-"):
                return vv
            digits = "".join(ch for ch in vv if ch.isdigit())
            return "CWE-" + digits if digits else None
        if isinstance(v, int):
            return f"CWE-{v}"
        if isinstance(v, list):
            for x in v:
                if isinstance(x, int):
                    return f"CWE-{x}"
                if isinstance(x, str) and "CWE" in x.upper():
                    xx = x.upper().replace(" ", "")
                    if xx.startswith("CWE-"):
                        return xx
                    digits = "".join(ch for ch in xx if ch.isdigit())
                    return "CWE-" + digits if digits else None
    return None

def _vsp__pick_path(f):
    if not isinstance(f, dict):
        return None
    for k in ("path","file","filename","location","artifact","resource","uri"):
        v = f.get(k)
        if isinstance(v, str) and v:
            return v
        if isinstance(v, dict):
            for kk in ("path","file","uri"):
                vv = v.get(kk)
                if isinstance(vv, str) and vv:
                    return vv
    return None

def _vsp__score_from_total(total):
    try:
        t = max(0, int(total))
        return int(max(0, min(100, round(100 - (_math.log10(t+1)*19)))))
    except Exception:
        return 0

class _VSPDashKpisChartsMW:
    def __init__(self, app):
        base_wsgi = globals().get("_vsp_base_wsgi")
        self.app = base_wsgi(app) if callable(base_wsgi) else getattr(app, "wsgi_app", app)

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path not in ("/api/vsp/dash_kpis", "/api/vsp/dash_charts"):
            return self.app(environ, start_response)

        try:
            base = _vsp__base_url_from_environ(environ)
            qs = _parse_qs(environ.get("QUERY_STRING") or "")
            rid = (qs.get("rid") or [""])[0] or _vsp__get_latest_rid(base)

            summ = _vsp__run_file_json(base, rid, "reports/run_gate_summary.json")
            counts = (summ or {}).get("counts_total") or {}
            total = sum(int(counts.get(k,0) or 0) for k in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"))
            overall = (summ or {}).get("overall") or (summ or {}).get("gate") or "UNKNOWN"

            findings = []
            cwe_cnt = {}
            mod_cnt = {}

            try:
                fu = _vsp__run_file_json(base, rid, "reports/findings_unified.json")
                findings = _vsp__extract_findings_list(fu)
            except Exception:
                findings = []

            by_tool = (summ or {}).get("by_tool") or {}
            tool_score = {}
            if isinstance(by_tool, dict):
                for tname, tv in by_tool.items():
                    if isinstance(tv, dict):
                        c = int(tv.get("CRITICAL",0) or 0)
                        h = int(tv.get("HIGH",0) or 0)
                        tool_score[tname] = c*10 + h*3
            top_tool = sorted(tool_score.items(), key=lambda x: x[1], reverse=True)[0][0] if tool_score else None

            for f in findings[:5000]:
                cwe = _vsp__pick_cwe(f)
                if cwe:
                    cwe_cnt[cwe] = cwe_cnt.get(cwe,0)+1
                pth = _vsp__pick_path(f)
                if pth:
                    key = pth.split("?")[0]
                    if "/" in key:
                        key = "/".join(key.split("/")[:4])
                    mod_cnt[key] = mod_cnt.get(key,0)+1

            top_cwe = sorted(cwe_cnt.items(), key=lambda x: x[1], reverse=True)[0][0] if cwe_cnt else None
            top_module = sorted(mod_cnt.items(), key=lambda x: x[1], reverse=True)[0][0] if mod_cnt else None

            if path == "/api/vsp/dash_kpis":
                out = {
                    "ok": True,
                    "rid": rid,
                    "overall": overall,
                    "total_findings": total,
                    "counts_total": counts,
                    "security_score": (summ or {}).get("security_score") or _vsp__score_from_total(total),
                    "top_risky_tool": top_tool or (summ or {}).get("top_tool"),
                    "top_impacted_cwe": top_cwe or (summ or {}).get("top_cwe"),
                    "top_vulnerable_module": top_module or (summ or {}).get("top_module"),
                }
            else:
                sev = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"]
                out = {
                    "ok": True,
                    "rid": rid,
                    "severity_distribution": [{"sev":k,"count":int(counts.get(k,0) or 0)} for k in sev],
                    "critical_high_by_tool": [
                        {"tool":t,
                         "critical":int((by_tool.get(t,{}) or {}).get("CRITICAL",0) or 0),
                         "high":int((by_tool.get(t,{}) or {}).get("HIGH",0) or 0)}
                        for t in (list(by_tool.keys())[:30] if isinstance(by_tool, dict) else [])
                    ],
                    "top_cwe_exposure": [{"cwe":k,"count":v} for k,v in sorted(cwe_cnt.items(), key=lambda x: x[1], reverse=True)[:12]],
                    "findings_trend": [{"rid": rid, "total": total}],
                }

            body = _json.dumps(out, ensure_ascii=False).encode("utf-8")
            start_response("200 OK", [
                ("Content-Type","application/json; charset=utf-8"),
                ("Cache-Control","no-cache"),
                ("Content-Length", str(len(body))),
            ])
            return [body]
        except Exception as e:
            body = _json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False).encode("utf-8")
            start_response("200 OK", [
                ("Content-Type","application/json; charset=utf-8"),
                ("Cache-Control","no-cache"),
                ("Content-Length", str(len(body))),
            ])
            return [body]

try:
    application.wsgi_app = _VSPDashKpisChartsMW(application.wsgi_app)
except Exception:
    pass



# VSP_P1_DASH_KPIS_CHARTS_FROM_REPORTS_V3
import json as _json
import math as _math
from urllib.parse import parse_qs as _parse_qs, urlencode as _urlencode
from urllib.request import urlopen as _urlopen, Request as _Request

def _vsp__base_url_from_environ(environ):
    scheme = environ.get("wsgi.url_scheme") or "http"
    host = environ.get("HTTP_HOST")
    if not host:
        host = environ.get("SERVER_NAME") or "127.0.0.1"
        port = environ.get("SERVER_PORT")
        if port and port not in ("80","443"):
            host = f"{host}:{port}"
    return f"{scheme}://{host}"

def _vsp__http_json(base, path, timeout=3.0):
    req = _Request(base + path, headers={"Accept":"application/json","X-VSP-Internal":"1"})
    with _urlopen(req, timeout=timeout) as r:
        body = r.read().decode("utf-8", "replace")
    return _json.loads(body)

def _vsp__get_latest_rid(base):
    j = _vsp__http_json(base, "/api/vsp/runs?limit=1", timeout=2.5)
    items = (j or {}).get("items") or []
    if items and isinstance(items[0], dict):
        return items[0].get("run_id") or ""
    return ""

def _vsp__run_file_json(base, rid, name, timeout=5.0):
    q = _urlencode({"rid": rid, "name": name})
    return _vsp__http_json(base, f"/api/vsp/run_file?{q}", timeout=timeout)

def _vsp__extract_findings_list(obj):
    if obj is None:
        return []
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        v = obj.get("items")
        if isinstance(v, list):
            return v
        for k in ("findings","data","results"):
            v = obj.get(k)
            if isinstance(v, list):
                return v
    return []

def _vsp__score_from_total(total):
    try:
        t = max(0, int(total))
        return int(max(0, min(100, round(100 - (_math.log10(t+1)*19)))))
    except Exception:
        return 0

def _vsp__pick_tool(f):
    if not isinstance(f, dict):
        return None
    for k in ("tool","source","scanner","engine","detector"):
        v = f.get(k)
        if isinstance(v, str) and v:
            return v.upper()
    # sometimes nested
    v = f.get("meta") if isinstance(f.get("meta"), dict) else None
    if v:
        for k in ("tool","source","scanner"):
            vv = v.get(k)
            if isinstance(vv, str) and vv:
                return vv.upper()
    return None

def _vsp__pick_cwe(f):
    if not isinstance(f, dict):
        return None
    for k in ("cwe","cwe_id","cweId","cwe_ids","cweIds"):
        v = f.get(k)
        if isinstance(v, str) and "CWE" in v.upper():
            vv = v.upper().replace(" ", "")
            if vv.startswith("CWE-"):
                return vv
            digits = "".join(ch for ch in vv if ch.isdigit())
            return "CWE-" + digits if digits else None
        if isinstance(v, int):
            return f"CWE-{v}"
        if isinstance(v, list):
            for x in v:
                if isinstance(x, int):
                    return f"CWE-{x}"
                if isinstance(x, str) and "CWE" in x.upper():
                    xx = x.upper().replace(" ", "")
                    if xx.startswith("CWE-"):
                        return xx
                    digits = "".join(ch for ch in xx if ch.isdigit())
                    return "CWE-" + digits if digits else None
    return None

def _vsp__pick_path(f):
    if not isinstance(f, dict):
        return None
    for k in ("path","file","filename","location","artifact","resource","uri"):
        v = f.get(k)
        if isinstance(v, str) and v:
            return v
        if isinstance(v, dict):
            for kk in ("path","file","uri"):
                vv = v.get(kk)
                if isinstance(vv, str) and vv:
                    return vv
    # sometimes sarif-ish
    loc = f.get("location")
    if isinstance(loc, dict):
        for kk in ("physicalLocation","artifactLocation"):
            vv = loc.get(kk)
            if isinstance(vv, dict):
                u = vv.get("uri") or vv.get("path")
                if isinstance(u, str) and u:
                    return u
    return None

def _vsp__counts_from_summary(summ):
    counts = (summ or {}).get("counts_total") or {}
    if isinstance(counts, dict):
        return {k:int(counts.get(k,0) or 0) for k in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE")}
    return {k:0 for k in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE")}

def _vsp__counts_from_unified(fu):
    meta = (fu or {}).get("meta") if isinstance(fu, dict) else None
    c = (meta or {}).get("counts_by_severity") if isinstance(meta, dict) else None
    if isinstance(c, dict):
        return {k:int(c.get(k,0) or 0) for k in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE")}
    return None

def _vsp__sum_counts(c):
    return sum(int(c.get(k,0) or 0) for k in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"))

def _vsp__tool_counts_from_summary(summ):
    by = (summ or {}).get("by_tool") or {}
    out = {}
    if not isinstance(by, dict):
        return out
    for t, tv in by.items():
        if not isinstance(tv, dict):
            continue
        c = tv.get("counts") if isinstance(tv.get("counts"), dict) else {}
        out[t] = {
            "CRITICAL": int((c or {}).get("CRITICAL",0) or 0),
            "HIGH": int((c or {}).get("HIGH",0) or 0),
            "MEDIUM": int((c or {}).get("MEDIUM",0) or 0),
            "LOW": int((c or {}).get("LOW",0) or 0),
            "INFO": int((c or {}).get("INFO",0) or 0),
            "TRACE": int((c or {}).get("TRACE",0) or 0),
        }
    return out

def _vsp__trend_from_recent_runs(base, limit=12):
    trend = []
    try:
        j = _vsp__http_json(base, f"/api/vsp/runs?limit={limit}", timeout=2.5)
        items = (j or {}).get("items") or []
        for it in items:
            rid = (it or {}).get("run_id") if isinstance(it, dict) else None
            if not rid:
                continue
            try:
                summ = _vsp__run_file_json(base, rid, "reports/run_gate_summary.json", timeout=2.0)
                fu = _vsp__run_file_json(base, rid, "reports/findings_unified.json", timeout=2.0)
                cu = _vsp__counts_from_unified(fu)
                cs = _vsp__counts_from_summary(summ)
                counts = cu if (cu and _vsp__sum_counts(cu) > 0) else cs
                total = _vsp__sum_counts(counts)
                trend.append({"rid": rid, "total": total, "overall": (summ or {}).get("overall") or "UNKNOWN"})
            except Exception:
                continue
    except Exception:
        pass
    return trend

class _VSPDashKpisChartsMW_V3:
    def __init__(self, app):
        base_wsgi = globals().get("_vsp_base_wsgi")
        self.app = base_wsgi(app) if callable(base_wsgi) else getattr(app, "wsgi_app", app)

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path not in ("/api/vsp/dash_kpis", "/api/vsp/dash_charts"):
            return self.app(environ, start_response)

        base = _vsp__base_url_from_environ(environ)
        qs = _parse_qs(environ.get("QUERY_STRING") or "")
        rid = (qs.get("rid") or [""])[0] or _vsp__get_latest_rid(base)

        try:
            summ = _vsp__run_file_json(base, rid, "reports/run_gate_summary.json", timeout=4.0)
        except Exception:
            summ = {}

        try:
            fu = _vsp__run_file_json(base, rid, "reports/findings_unified.json", timeout=4.0)
        except Exception:
            fu = {}

        cs = _vsp__counts_from_summary(summ)
        cu = _vsp__counts_from_unified(fu)
        counts = cu if (cu and _vsp__sum_counts(cu) > 0) else cs
        total = _vsp__sum_counts(counts)

        overall = (summ or {}).get("overall") or "UNKNOWN"
        tool_counts = _vsp__tool_counts_from_summary(summ)

        # derive top tool/cwe/module from unified items (best-effort)
        items = _vsp__extract_findings_list(fu)
        cwe_cnt, mod_cnt, tool_cnt = {}, {}, {}
        for f in (items or [])[:2500]:
            t = _vsp__pick_tool(f)
            if t:
                tool_cnt[t] = tool_cnt.get(t,0)+1
            cwe = _vsp__pick_cwe(f)
            if cwe:
                cwe_cnt[cwe] = cwe_cnt.get(cwe,0)+1
            pth = _vsp__pick_path(f)
            if pth:
                key = pth.split("?")[0]
                if "/" in key:
                    key = "/".join(key.split("/")[:4])
                mod_cnt[key] = mod_cnt.get(key,0)+1

        top_tool = sorted(tool_cnt.items(), key=lambda x:x[1], reverse=True)[0][0] if tool_cnt else None
        top_cwe = sorted(cwe_cnt.items(), key=lambda x:x[1], reverse=True)[0][0] if cwe_cnt else None
        top_mod = sorted(mod_cnt.items(), key=lambda x:x[1], reverse=True)[0][0] if mod_cnt else None

        if path == "/api/vsp/dash_kpis":
            out = {
                "ok": True,
                "rid": rid,
                "overall": overall,
                "total_findings": total,
                "counts_total": counts,
                "security_score": (summ or {}).get("security_score") or _vsp__score_from_total(total),
                "top_risky_tool": top_tool,
                "top_impacted_cwe": top_cwe,
                "top_vulnerable_module": top_mod,
                "notes": {
                    "counts_source": "findings_unified.meta.counts_by_severity" if (cu and _vsp__sum_counts(cu)>0) else "run_gate_summary.counts_total"
                }
            }
        else:
            sev = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"]
            # prefer tool counts from summary schema by_tool.*.counts
            cht = []
            for t, c in tool_counts.items():
                cht.append({"tool": t, "critical": int(c.get("CRITICAL",0)), "high": int(c.get("HIGH",0))})
            out = {
                "ok": True,
                "rid": rid,
                "severity_distribution": [{"sev":k,"count":int(counts.get(k,0) or 0)} for k in sev],
                "critical_high_by_tool": cht[:30],
                "top_cwe_exposure": [{"cwe":k,"count":v} for k,v in sorted(cwe_cnt.items(), key=lambda x:x[1], reverse=True)[:12]],
                "findings_trend": _vsp__trend_from_recent_runs(base, limit=12),
            }

        body = _json.dumps(out, ensure_ascii=False).encode("utf-8")
        start_response("200 OK", [
            ("Content-Type","application/json; charset=utf-8"),
            ("Cache-Control","no-cache"),
            ("Content-Length", str(len(body))),
        ])
        return [body]

try:
    application.wsgi_app = _VSPDashKpisChartsMW_V3(application.wsgi_app)
except Exception:
    pass



# VSP_P1_DASH_SCHEMA_COMPAT_V4
import json as _json
from urllib.parse import parse_qs as _parse_qs

def _vsp__mk_donut(counts):
    sev = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"]
    vals = [int((counts or {}).get(k,0) or 0) for k in sev]
    return {"labels": sev, "values": vals}

def _vsp__mk_trend(trend_list):
    labels = [x.get("rid","") for x in (trend_list or []) if isinstance(x, dict)]
    values = [int(x.get("total",0) or 0) for x in (trend_list or []) if isinstance(x, dict)]
    return {"labels": labels, "values": values}

def _vsp__mk_bar_crit_high(ch_list):
    labels = [x.get("tool","") for x in (ch_list or []) if isinstance(x, dict)]
    crit = [int(x.get("critical",0) or 0) for x in (ch_list or []) if isinstance(x, dict)]
    high = [int(x.get("high",0) or 0) for x in (ch_list or []) if isinstance(x, dict)]
    return {"labels": labels, "series": [{"name":"CRITICAL","data":crit},{"name":"HIGH","data":high}]}

def _vsp__mk_top_list(kvs, key_name):
    labels = [k for k,_ in kvs]
    values = [int(v) for _,v in kvs]
    return {"labels": labels, "values": values, "key": key_name}

class _VSPDashSchemaCompatMW_V4:
    def __init__(self, app):
        base_wsgi = globals().get("_vsp_base_wsgi")
        self.app = base_wsgi(app) if callable(base_wsgi) else getattr(app, "wsgi_app", app)

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if path not in ("/api/vsp/dash_kpis", "/api/vsp/dash_charts"):
            return self.app(environ, start_response)

        # reuse helpers from V3 if present
        base_fn = globals().get("_vsp__base_url_from_environ")
        base = base_fn(environ) if callable(base_fn) else "http://127.0.0.1:8910"

        qs = _parse_qs(environ.get("QUERY_STRING") or "")
        rid = (qs.get("rid") or [""])[0] or (globals().get("_vsp__get_latest_rid")(base) if callable(globals().get("_vsp__get_latest_rid")) else "")

        run_file = globals().get("_vsp__run_file_json")
        counts_from_s = globals().get("_vsp__counts_from_summary")
        counts_from_u = globals().get("_vsp__counts_from_unified")
        sum_counts = globals().get("_vsp__sum_counts")
        score_fn = globals().get("_vsp__score_from_total")
        tool_counts_fn = globals().get("_vsp__tool_counts_from_summary")
        trend_fn = globals().get("_vsp__trend_from_recent_runs")
        extract_items = globals().get("_vsp__extract_findings_list")
        pick_tool = globals().get("_vsp__pick_tool")
        pick_cwe = globals().get("_vsp__pick_cwe")
        pick_path = globals().get("_vsp__pick_path")

        summ = {}
        fu = {}
        try:
            if callable(run_file): summ = run_file(base, rid, "reports/run_gate_summary.json", timeout=4.0)
        except Exception:
            summ = {}
        try:
            if callable(run_file): fu = run_file(base, rid, "reports/findings_unified.json", timeout=4.0)
        except Exception:
            fu = {}

        cs = counts_from_s(summ) if callable(counts_from_s) else {}
        cu = counts_from_u(fu) if callable(counts_from_u) else None
        counts = cu if (cu and (sum_counts(cu) if callable(sum_counts) else 0) > 0) else cs
        total = (sum_counts(counts) if callable(sum_counts) else sum(int(counts.get(k,0) or 0) for k in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE")))

        overall = (summ or {}).get("overall") or "UNKNOWN"
        security_score = (summ or {}).get("security_score") or (score_fn(total) if callable(score_fn) else 0)

        # derive best-effort top_* from unified items
        items = extract_items(fu) if callable(extract_items) else []
        tool_cnt, cwe_cnt, mod_cnt = {}, {}, {}
        for f in (items or [])[:2500]:
            t = pick_tool(f) if callable(pick_tool) else None
            if t: tool_cnt[t] = tool_cnt.get(t,0)+1
            cwe = pick_cwe(f) if callable(pick_cwe) else None
            if cwe: cwe_cnt[cwe] = cwe_cnt.get(cwe,0)+1
            pth = pick_path(f) if callable(pick_path) else None
            if pth:
                key = pth.split("?")[0]
                if "/" in key: key = "/".join(key.split("/")[:4])
                mod_cnt[key] = mod_cnt.get(key,0)+1

        top_tool = sorted(tool_cnt.items(), key=lambda x:x[1], reverse=True)[0][0] if tool_cnt else None
        top_cwe = sorted(cwe_cnt.items(), key=lambda x:x[1], reverse=True)[0][0] if cwe_cnt else None
        top_mod = sorted(mod_cnt.items(), key=lambda x:x[1], reverse=True)[0][0] if mod_cnt else None

        if path == "/api/vsp/dash_kpis":
            out = {
                "ok": True,
                "rid": rid,
                "overall": overall,
                "total_findings": total,
                "total": total,
                "counts_total": counts,
                "counts": counts,
                "security_score": security_score,
                "score": security_score,
                "top_risky_tool": top_tool,
                "top_tool": top_tool,
                "top_impacted_cwe": top_cwe,
                "top_cwe": top_cwe,
                "top_vulnerable_module": top_mod,
                "top_module": top_mod,
            }
        else:
            sev_dist = [{"sev":k,"count":int(counts.get(k,0) or 0)} for k in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE")]
            tool_counts = tool_counts_fn(summ) if callable(tool_counts_fn) else {}
            ch = [{"tool":t, "critical":int(c.get("CRITICAL",0)), "high":int(c.get("HIGH",0))} for t,c in (tool_counts or {}).items() if isinstance(c, dict)]

            trend = trend_fn(base, limit=12) if callable(trend_fn) else [{"rid":rid,"total":total,"overall":overall}]

            top_cwe_pairs = sorted(cwe_cnt.items(), key=lambda x:x[1], reverse=True)[:12]
            out = {
                "ok": True,
                "rid": rid,

                # existing keys (v3)
                "severity_distribution": sev_dist,
                "critical_high_by_tool": ch[:30],
                "top_cwe_exposure": [{"cwe":k,"count":v} for k,v in top_cwe_pairs],
                "findings_trend": trend,

                # compat aliases (to satisfy unknown JS expectations)
                "sev_dist": sev_dist,
                "sev_donut": sev_dist,
                "donut": _vsp__mk_donut(counts),

                "trend": _vsp__mk_trend(trend),
                "trend_series": _vsp__mk_trend(trend),

                "bar_crit_high": _vsp__mk_bar_crit_high(ch[:30]),
                "crit_high_bar": _vsp__mk_bar_crit_high(ch[:30]),

                "top_cwe": _vsp__mk_top_list(top_cwe_pairs, "cwe"),
                "cwe_top": _vsp__mk_top_list(top_cwe_pairs, "cwe"),

                "charts": {
                    "severity": {"distribution": sev_dist, "donut": _vsp__mk_donut(counts)},
                    "trend": {"points": trend, "series": _vsp__mk_trend(trend)},
                    "crit_high_by_tool": {"rows": ch[:30], "bar": _vsp__mk_bar_crit_high(ch[:30])},
                    "top_cwe": {"rows": [{"cwe":k,"count":v} for k,v in top_cwe_pairs], "series": _vsp__mk_top_list(top_cwe_pairs, "cwe")},
                }
            }

        body = _json.dumps(out, ensure_ascii=False).encode("utf-8")
        start_response("200 OK", [
            ("Content-Type","application/json; charset=utf-8"),
            ("Cache-Control","no-cache"),
            ("Content-Length", str(len(body))),
        ])
        return [body]

try:
    application.wsgi_app = _VSPDashSchemaCompatMW_V4(application.wsgi_app)
except Exception:
    pass




# === VSP_P1_STRIP_INLINE_DASH_AND_RID_LATEST_WSGIMW_V2 BEGIN ===
# Fix: capture BOTH iterable body and legacy start_response(write) body to avoid empty responses.
try:
    import re as _re
    import json as _json

    class _VspStripInlineDashAndRidLatestMW_V2:
        def __init__(self, app):
            self.app = app

        def __call__(self, environ, start_response):
            path = (environ.get("PATH_INFO") or "")
            captured = {"status": None, "headers": None, "exc": None}
            body_chunks = []

            def _sr(status, headers, exc_info=None):
                captured["status"] = status
                captured["headers"] = list(headers or [])
                captured["exc"] = exc_info

                # WSGI legacy: return a write() callable
                def write(data):
                    try:
                        if data:
                            if isinstance(data, str):
                                data = data.encode("utf-8", errors="replace")
                            body_chunks.append(data)
                    except Exception:
                        pass
                return write

            try:
                it = self.app(environ, _sr)
                for b in it:
                    if not b:
                        continue
                    if isinstance(b, str):
                        b = b.encode("utf-8", errors="replace")
                    body_chunks.append(b)
                if hasattr(it, "close"):
                    it.close()
            except Exception:
                return self.app(environ, start_response)

            status = captured["status"] or "200 OK"
            headers = captured["headers"] or []
            body = b"".join(body_chunks)

            def _get_header(name: str):
                ln = name.lower()
                for k, v in headers:
                    if str(k).lower() == ln:
                        return v
                return None

            ct = (_get_header("Content-Type") or "").lower()

            # A) Schema compat: ensure rid_latest on /api/vsp/runs JSON
            if path == "/api/vsp/runs" and ("application/json" in ct or ct.endswith("+json") or ct == ""):
                # ct can be empty if upstream MW forgets it; still attempt JSON parse guardedly
                try:
                    txt = body.decode("utf-8", errors="replace").strip()
                    if txt.startswith("{") and txt.endswith("}"):
                        j = _json.loads(txt)
                        if isinstance(j, dict) and ("rid_latest" not in j):
                            items = j.get("items") or []
                            if isinstance(items, list) and items:
                                rid0 = (items[0] or {}).get("run_id")
                                if rid0:
                                    j["rid_latest"] = rid0
                                    body = _json.dumps(j, ensure_ascii=False).encode("utf-8")
                                    # set ct if missing
                                    if not any(str(k).lower()=="content-type" for k,v in headers):
                                        headers.append(("Content-Type","application/json; charset=utf-8"))
                except Exception:
                    pass

            # B) Strip injected inline dash scripts on /vsp5 HTML (outermost)
            if path == "/vsp5" and ("text/html" in ct or ct == ""):
                try:
                    html = body.decode("utf-8", errors="replace")

                    def _kill_script(m):
                        whole = m.group(0)
                        inner = m.group(2) or ""
                        sigs = [
                            "rid_latest", "vsp_live_rid", "vsp_rid_latest_badge",
                            "containers/rid", "Chart/container", "[VSP][DASH]",
                            "gave up", "container missing"
                        ]
                        if any(s in inner for s in sigs):
                            return ""
                        return whole

                    html2 = _re.sub(r"(<script[^>]*>)(.*?)(</script>)", _kill_script, html, flags=_re.S|_re.I)
                    if html2 != html:
                        body = html2.encode("utf-8")
                        headers = [(k, v) for (k, v) in headers if str(k).lower() not in ("content-length", "cache-control")]
                        headers.append(("Cache-Control", "no-store"))
                except Exception:
                    pass

            # normalize Content-Length
            headers = [(k, v) for (k, v) in headers if str(k).lower() != "content-length"]
            headers.append(("Content-Length", str(len(body))))

            start_response(status, headers, captured["exc"])
            return [body]

    # Replace wsgi_app with V2 (outermost)
    try:
        application.wsgi_app = _VspStripInlineDashAndRidLatestMW_V2(application.wsgi_app)
    except Exception:
        pass

except Exception:
    pass
# === VSP_P1_STRIP_INLINE_DASH_AND_RID_LATEST_WSGIMW_V2 END ===


# ===== VSP_P0_ROUTE_ALIAS_VSP5_RUNS_V2 =====
try:
    # prefer app if exists
    _app = globals().get("app", None)
    if _app is not None:
        @_app.route("/vsp5/runs")
        def vsp5_runs_alias_v2():
            from flask import redirect
            return redirect("/runs", code=302)
    # or blueprint if app not present
    _bp = globals().get("bp", None) or globals().get("runs_bp", None)
    if _bp is not None:
        @_bp.route("/vsp5/runs")
        def vsp5_runs_alias_bp_v2():
            from flask import redirect
            return redirect("/runs", code=302)
except Exception:
    pass
# ===== end VSP_P0_ROUTE_ALIAS_VSP5_RUNS_V2 =====



# === VSP_P0_RUNS_NEVER503_MW_V1 ===
import json as _vsp_json

class _VSPRunsNever503MW:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not path.startswith("/api/vsp/runs"):
            return self.app(environ, start_response)

        status_headers = {"status": None, "headers": None}
        body_chunks = []

        def _sr(status, headers, exc_info=None):
            status_headers["status"] = status
            status_headers["headers"] = headers
            def _write(x):
                if x:
                    body_chunks.append(x if isinstance(x, (bytes, bytearray)) else str(x).encode("utf-8", "replace"))
            return _write

        try:
            res = self.app(environ, _sr)
            for ch in res:
                if ch:
                    body_chunks.append(ch if isinstance(ch, (bytes, bytearray)) else str(ch).encode("utf-8", "replace"))
            if hasattr(res, "close"):
                try: res.close()
                except Exception: pass

            st = status_headers["status"] or "500 INTERNAL SERVER ERROR"
            code = int(st.split()[0])
            if code >= 500:
                payload = {
                    "ok": True,
                    "degraded": True,
                    "degraded_reason": f"upstream_http_{code}",
                    "limit": 0,
                    "items": [],
                    "rid_latest": None,
                }
                out = _vsp_json.dumps(payload).encode("utf-8")
                hdrs = [
                    ("Content-Type","application/json; charset=utf-8"),
                    ("Cache-Control","no-store"),
                    ("Content-Length", str(len(out))),
                    ("X-VSP-RUNS-CONTRACT","P1_WSGI_V2"),
                    ("X-VSP-DEGRADED","1"),
                ]
                start_response("200 OK", hdrs)
                return [out]

            # pass-through original
            start_response(st, status_headers["headers"] or [])
            return [b"".join(body_chunks)]

        except Exception as e:
            payload = {
                "ok": True,
                "degraded": True,
                "degraded_reason": "exception",
                "error": str(e),
                "limit": 0,
                "items": [],
                "rid_latest": None,
            }
            out = _vsp_json.dumps(payload).encode("utf-8")
            hdrs = [
                ("Content-Type","application/json; charset=utf-8"),
                ("Cache-Control","no-store"),
                ("Content-Length", str(len(out))),
                ("X-VSP-RUNS-CONTRACT","P1_WSGI_V2"),
                ("X-VSP-DEGRADED","1"),
            ]
            start_response("200 OK", hdrs)
            return [out]

def _vsp_wrap_runs_never503(app):
    return _VSPRunsNever503MW(app)

try:
    if "application" in globals():
        application = _vsp_wrap_runs_never503(application)
    elif "app" in globals():
        app = _vsp_wrap_runs_never503(app)
except Exception as _e:
    print("[VSP][WARN] runs never503 mw attach failed:", _e)
# === END VSP_P0_RUNS_NEVER503_MW_V1 ===



# VSP_P0_STRIP_FILLREAL_RUNS_RESPONSE_V1
def _vsp_mw_strip_fillreal_on_runs(app):
    """WSGI MW: for /runs, strip vsp_fill_real_data_5tabs_p1_v1.js script tag from HTML."""
    def _mw(environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if not (path == "/runs" or path.startswith("/runs/")):
            return app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers) if headers else []
            captured["exc"] = exc_info
            # delay actual start_response until body is processed

        it = app(environ, _sr)
        chunks = []
        try:
            for c in it:
                if c:
                    chunks.append(c)
        finally:
            try:
                close = getattr(it, "close", None)
                if callable(close): close()
            except Exception:
                pass

        status = captured["status"] or "200 OK"
        headers = captured["headers"] or []
        body = b"".join(chunks)

        # detect content-type
        ct = ""
        for k, v in headers:
            if str(k).lower() == "content-type":
                ct = str(v)
                break

        if body and ("text/html" in ct.lower()):
            try:
                html = body.decode("utf-8", "replace")
                # strip gateway marker comments too (runs-only)
                html = re.sub(r"\s*<!--\s*VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY\s*-->\s*", "", html, flags=re.I)
                html = re.sub(r"\s*<!--\s*/VSP_FILL_REAL_DATA_5TABS_P1_V1_GATEWAY\s*-->\s*", "", html, flags=re.I)
                # VSP_P0_STRIP_FILLREAL_MARKERS_ON_RUNS_V5

                # remove script tag (allow quotes, attrs, querystring)
                html2 = re.sub(
                    r"""\s*<script[^>]+src=['\"]?/static/js/vsp_fill_real_data_5tabs_p1_v1\.js[^'\"]*['\"][^>]*>\s*</script>\s*""",

                    "",

                    html,

                    flags=re.I

                )
                if html2 != html:
                    body = html2.encode("utf-8")
                    # fix content-length
                    headers = [(k, v) for (k, v) in headers if str(k).lower() != "content-length"]
                    headers.append(("Content-Length", str(len(body))))
            except Exception:
                pass

        start_response(status, headers, captured["exc"])
        return [body]
    return _mw


# VSP_P0_DISABLE_FILLREAL_INJECTOR_ON_RUNS_V2


# VSP_P0_FORCEHOOK_STRIP_FILLREAL_RUNS_V3
try:
    # prefer Flask app if present
    if "app" in globals():
        _a = globals().get("app")
        if _a is not None and hasattr(_a, "wsgi_app"):
            try:
                _a.wsgi_app = _vsp_mw_strip_fillreal_on_runs(_a.wsgi_app)
                globals()["app"] = _a
            except Exception:
                pass
    # gunicorn may point to "application"
    if "application" in globals():
        _appx = globals().get("application")
        if _appx is not None:
            try:
                globals()["application"] = _vsp_mw_strip_fillreal_on_runs(_appx)
            except Exception:
                pass
except Exception:
    pass


# --- VSP_P1_HEALTHZ_JSON_V1 ---
from flask import jsonify

def _vsp_best_effort_latest_rid():
    # Try to call local function if exists, else return N/A
    try:
        # some codebases expose a function or cache; keep safe
        return None
    except Exception:
        return None

@app.get("/healthz")
def vsp_healthz_json_v1():
    data = {
        "ui_up": True,
        "ts": int(time.time()),
        "pid": os.getpid(),
        "host": socket.gethostname(),
        "contract": "P1_HEALTHZ_V1",
    }
    # best effort: attach latest rid via internal API handler if present
    try:
        # If there is a local function already used by /api/vsp/runs, reuse by calling it directly
        # Otherwise, leave N/A (avoid HTTP self-call to prevent deadlocks)
        if "vsp_runs_api" in globals() and callable(globals().get("vsp_runs_api")):
            resp = globals()["vsp_runs_api"]()
            # might be flask Response/json; we won't hard parse
        data["last_rid"] = data.get("last_rid","N/A")
    except Exception:
        data["last_rid"] = data.get("last_rid","N/A")

    return jsonify(data), 200
# --- /VSP_P1_HEALTHZ_JSON_V1 ---



# --- VSP_P1_HEALTHZ_WSGI_STRICT_V4 ---
# Guarantee JSON response even if Flask routes/templates change.
def _vsp_healthz_wsgi_wrap(_next):
    import json, os, time, socket
    def _app(environ, start_response):
        try:
            if environ.get("PATH_INFO") == "/healthz":
                payload = json.dumps({
                    "ui_up": True,
                    "ts": int(time.time()),
                    "pid": os.getpid(),
                    "host": socket.gethostname(),
                    "contract": "P1_HEALTHZ_V4"
                }).encode("utf-8")
                start_response("200 OK", [
                    ("Content-Type", "application/json; charset=utf-8"),
                    ("Cache-Control", "no-store"),
                    ("Content-Length", str(len(payload))),
                ])
                return [payload]
        except Exception:
            pass
        return _next(environ, start_response)
    return _app

try:
    # gunicorn entrypoint in this module is typically `application`
    if "application" in globals() and callable(application):
        application = _vsp_healthz_wsgi_wrap(application)
except Exception:
    pass
# --- /VSP_P1_HEALTHZ_WSGI_STRICT_V4 ---



# === VSP_P0_STATIC_FORCE_SEND_V1 ===
# Commercial: force-serve static assets from disk (fix 200-but-empty body issues)
try:
    import os
    from flask import Response
except Exception:
    pass

@app.get("/static/<path:filename>")
def vsp_p0_static_force_send_v1(filename):
    try:
        root = os.path.join(os.path.dirname(__file__), "static")
        resp = send_from_directory(root, filename)
        # ensure not cached in dev; commercial can tune later
        resp.headers["Cache-Control"] = "no-cache"
        return resp
    except Exception as e:
        # explicit non-empty error
        return Response("static serve error: " + str(e), status=500, mimetype="text/plain")
# === END VSP_P0_STATIC_FORCE_SEND_V1 ===




# --- VSP_P1_GATE_STORY_AFTER_REQUEST_V1 ---
try:
    from flask import request as _vsp_req
except Exception:
    _vsp_req = None

@app.after_request
def _vsp_p1_gate_story_after_request_v1(resp):
    try:
        if _vsp_req is None:
            return resp
        if _vsp_req.path != "/vsp5":
            return resp
        ctype = (resp.headers.get("Content-Type","") or "").lower()
        # accept text/html + utf-8 variants
        if "text/html" not in ctype:
            return resp
        data = resp.get_data(as_text=True)
        if "vsp_dashboard_gate_story_v1.js" in data:
            return resp
        if "</body>" not in data:
            return resp
        script = '<script src="/static/js/vsp_dashboard_gate_story_v1.js?v={ asset_v }"></script> <!-- VSP_P1_GATE_STORY_PANEL_V1 -->\n'
        data2 = data.replace("</body>", script + "</body>")
        resp.set_data(data2)
        # fix content-length for some gunicorn/proxy combos
        resp.headers["Content-Length"] = str(len(data2.encode("utf-8", errors="ignore")))
        return resp
    except Exception:
        return resp
# --- /VSP_P1_GATE_STORY_AFTER_REQUEST_V1 ---



# --- VSP_P0_FIX_STATIC_ZERO_LEN_FORCE_SEND_V1 ---
try:
    from flask import request as _vsp_req
except Exception:
    _vsp_req = None

@app.after_request
def _vsp_p0_fix_static_zero_len_force_send_v1(resp):
    try:
        if _vsp_req is None:
            return resp
        # only for /static/*
        path = getattr(_vsp_req, "path", "") or ""
        if not path.startswith("/static/"):
            return resp
        if resp.status_code != 200:
            return resp

        # If Content-Length is 0 (bug), force load from disk.
        cl = resp.headers.get("Content-Length", "")
        if str(cl).strip() not in ("0", ""):
            return resp

        # map URL -> file path under ./static
        rel = path[len("/static/"):]
        static_dir = Path(__file__).resolve().parent / "static"
        fp = (static_dir / rel).resolve()

        # prevent traversal
        if static_dir.resolve() not in fp.parents and fp != static_dir.resolve():
            return resp
        if not fp.is_file():
            return resp

        data = fp.read_bytes()
        # HEAD should return empty body but correct Content-Length
        if (_vsp_req.method or "").upper() == "HEAD":
            resp.set_data(b"")
            resp.headers["Content-Length"] = str(len(data))
            return resp

        resp.set_data(data)
        resp.headers["Content-Length"] = str(len(data))
        return resp
    except Exception:
        return resp
# --- /VSP_P0_FIX_STATIC_ZERO_LEN_FORCE_SEND_V1 ---


# --- VSP_P0_WSGI_STATIC_LAST_MILE_FORCE_LEN_V1 ---
def _vsp_p0_wsgi_static_last_mile_force_len_v1(wsgi_app):
    import mimetypes
    from pathlib import Path

    base_dir = Path(__file__).resolve().parent
    static_dir = (base_dir / "static").resolve()

    def _app(environ, start_response):
        try:
            path = (environ.get("PATH_INFO") or "")
            method = (environ.get("REQUEST_METHOD") or "GET").upper()

            if not path.startswith("/static/"):
                return wsgi_app(environ, start_response)

            rel = path[len("/static/"):]
            fp = (static_dir / rel).resolve()

            # prevent traversal
            if static_dir not in fp.parents and fp != static_dir:
                return wsgi_app(environ, start_response)
            if not fp.is_file():
                return wsgi_app(environ, start_response)

            data = fp.read_bytes()

            ctype, _ = mimetypes.guess_type(str(fp))
            if not ctype:
                ext = fp.suffix.lower()
                if ext == ".js":
                    ctype = "text/javascript"
                elif ext == ".css":
                    ctype = "text/css"
                else:
                    ctype = "application/octet-stream"

            headers = [
                ("Content-Type", (ctype + "; charset=utf-8") if ctype.startswith("text/") else ctype),
                ("Content-Length", str(len(data))),
                ("Cache-Control", "no-cache"),
                ("Content-Disposition", "inline; filename=" + fp.name),
            ]

            start_response("200 OK", headers)
            if method == "HEAD":
                return [b""]
            return [data]

        except Exception:
            return wsgi_app(environ, start_response)

    return _app

try:
    app.wsgi_app = _vsp_p0_wsgi_static_last_mile_force_len_v1(app.wsgi_app)
except Exception:
    pass
# --- /VSP_P0_WSGI_STATIC_LAST_MILE_FORCE_LEN_V1 ---


# --- VSP_P1_WSGI_VSP5_SAFE_MODE_GATE_STORY_ONLY_V2 ---
def _vsp_p1_wsgi_vsp5_safe_mode_gate_story_only_v2(wsgi_app):
    import time

    def _app(environ, start_response):
        try:
            path = (environ.get("PATH_INFO") or "")
            method = (environ.get("REQUEST_METHOD") or "GET").upper()

            if path != "/vsp5":
                return wsgi_app(environ, start_response)

            asset_v = str(int(time.time()))
            html_lines = [
                "<!doctype html>",
                "<html lang=\"en\">",
                "<head>",
                "  <meta charset=\"utf-8\"/>",
                "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>",
                "  <meta http-equiv=\"Cache-Control\" content=\"no-cache, no-store, must-revalidate\"/>",
                "  <meta http-equiv=\"Pragma\" content=\"no-cache\"/>",
                "  <meta http-equiv=\"Expires\" content=\"0\"/>",
                "  <title>VSP5</title>\n  <link rel='stylesheet' href='/static/css/vsp_dashboard_polish_v1.css'/>",
                "  <style>",
                "    body{ margin:0; background:#0b1220; color:rgba(226,232,240,.96);",
                "          font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; }",
                "    .vsp5nav{ display:flex; gap:10px; padding:10px 14px; border-bottom:1px solid rgba(255,255,255,.10);",
                "              background: rgba(0,0,0,.22); position:sticky; top:0; z-index:9999; }",
                "    .vsp5nav a{ color:rgba(226,232,240,.92); text-decoration:none; font-size:12px;",
                "                padding:8px 10px; border:1px solid rgba(255,255,255,.14); border-radius:12px; }",
                "    .vsp5nav a:hover{ background: rgba(255,255,255,.06); }",
                "    #vsp5_root{ min-height: 60vh; }",
                "  </style>",
                "</head>",
                "<body>",
                "  <div class=\"vsp5nav\">",
                "    <a href=\"/vsp5\">Dashboard</a>",
                "    <a href=\"/runs\">Runs &amp; Reports</a>",
                "    <a href=\"/data_source\">Data Source</a>",
                "    <a href=\"/settings\">Settings</a>",
                "    <a href=\"/rule_overrides\">Rule Overrides</a>",
                "  </div>",
                "  <div id=\"vsp5_root\"></div>",
                "",
                "  <!-- VSP_P1_VSP5_SWITCH_TO_DASHCOMMERCIAL_V1_FIX_V1: DASH MODE: DashCommercialV1 (single renderer) -->",
                "  <script src=\"/static/js/vsp_dashboard_gate_story_v1.js?v=" + asset_v + "\"></script>",
                "</body>",
                "</html>",
            ]
            html = "\n".join(html_lines).encode("utf-8", errors="ignore")
            headers = [
                ("Content-Type", "text/html; charset=utf-8"),
                ("Cache-Control", "no-cache, no-store, must-revalidate"),
                ("Pragma", "no-cache"),
                ("Expires", "0"),
                ("Content-Length", str(len(html))),
            ]
            start_response("200 OK", headers)
            if method == "HEAD":
                return [b""]
            return [html]
        except Exception:
            return wsgi_app(environ, start_response)

    return _app

try:
    app.wsgi_app = _vsp_p1_wsgi_vsp5_safe_mode_gate_story_only_v2(app.wsgi_app)
except Exception:
    pass
# --- /VSP_P1_WSGI_VSP5_SAFE_MODE_GATE_STORY_ONLY_V2 ---



# --- VSP_P1_TABS3_BP_REGISTER_V1 ---
try:
    from vsp_tabs_extras_bp_v1 import vsp_tabs_extras_bp as _vsp_tabs_extras_bp_v1
    # register only if Flask app is available
    if "app" in globals() and hasattr(globals()["app"], "register_blueprint"):
        globals()["app"].register_blueprint(_vsp_tabs_extras_bp_v1)
        print("[VSP_TABS3] registered blueprint: vsp_tabs_extras_bp_v1")
    else:
        print("[VSP_TABS3] skip register (no app in globals)")
except Exception as _e:
    print("[VSP_TABS3] blueprint disabled:", _e)
# --- /VSP_P1_TABS3_BP_REGISTER_V1 ---


# --- VSP_P1_FIX_CONTENT_LENGTH_ZERO_V1 ---
try:
    @app.after_request
    def _vsp_fix_cl_zero(resp):
        try:
            ct = (resp.content_type or "")
            if ct.startswith("text/html"):
                cl = resp.headers.get("Content-Length")
                if cl == "0":
                    b = resp.get_data()
                    if b:
                        resp.headers["Content-Length"] = str(len(b))
        except Exception:
            pass
        return resp
except Exception as _e:
    print("[VSP_FIX_CL0] disabled:", _e)
# --- /VSP_P1_FIX_CONTENT_LENGTH_ZERO_V1 ---


# --- VSP_P1_TABS3_UI_BP_REGISTER_V2 ---
try:
    from vsp_tabs3_ui_bp_v2 import vsp_tabs3_ui_bp_v2 as _vsp_tabs3_ui_bp_v2
    if "app" in globals() and hasattr(globals()["app"], "register_blueprint"):
        globals()["app"].register_blueprint(_vsp_tabs3_ui_bp_v2)
        print("[VSP_TABS3_V2] registered blueprint: vsp_tabs3_ui_bp_v2")
except Exception as _e:
    print("[VSP_TABS3_V2] blueprint disabled:", _e)
# --- /VSP_P1_TABS3_UI_BP_REGISTER_V2 ---

# --- VSP_TABS3_UI_BP_REGISTER_V3 ---
try:
    from vsp_tabs3_ui_bp_v3 import vsp_tabs3_ui_bp_v3 as _vsp_tabs3_ui_bp_v3
    if "app" in globals() and hasattr(globals()["app"], "register_blueprint"):
        globals()["app"].register_blueprint(_vsp_tabs3_ui_bp_v3)
        print("[VSP_TABS3_V3] registered blueprint: vsp_tabs3_ui_bp_v3")
except Exception as _e:
    print("[VSP_TABS3_V3] blueprint disabled:", _e)
# --- /VSP_TABS3_UI_BP_REGISTER_V3 ---

# --- VSP_HTML_BODY_GUARD_OUTERMOST_V1 ---
try:
    from pathlib import Path as _Path
    class _VSPHtmlBodyGuard:
        def __init__(self, wsgi_app, ui_root):
            self.wsgi_app = wsgi_app
            self.ui_root = _Path(ui_root)
            self.map = {
                "/data_source": self.ui_root/"templates"/"vsp_data_source_2025.html",
                "/settings": self.ui_root/"templates"/"vsp_settings_2025.html",
                "/rule_overrides": self.ui_root/"templates"/"vsp_rule_overrides_2025.html",
            }

        def __call__(self, environ, start_response):
            path = environ.get("PATH_INFO", "") or ""
            captured = {"status": None, "headers": None}

            def _sr(status, headers, exc_info=None):
                captured["status"] = status
                captured["headers"] = list(headers)
                return start_response(status, headers, exc_info)

            app_iter = self.wsgi_app(environ, _sr)

            # collect body
            body = b""
            try:
                for chunk in app_iter:
                    if chunk:
                        body += chunk
            finally:
                try:
                    close = getattr(app_iter, "close", None)
                    if close: close()
                except Exception:
                    pass

            status = captured["status"] or "200 OK"
            headers = captured["headers"] or []
            ct = ""
            for k,v in headers:
                if k.lower() == "content-type":
                    ct = v or ""
                    break

            # If HTML 200 and body empty => replace with template file content
            if status.startswith("200") and ct.startswith("text/html") and len(body) == 0 and path in self.map:
                fp = self.map[path]
                try:
                    if fp.exists():
                        body = fp.read_bytes()
                        # rebuild headers: remove Content-Length, then add correct
                        new_headers = [(k,v) for (k,v) in headers if k.lower() != "content-length"]
                        new_headers.append(("Content-Length", str(len(body))))
                        # replace headers by calling start_response again (WSGI allows if not committed; gunicorn ok here)
                        start_response(status, new_headers)
                        return [body]
                except Exception as _e:
                    pass

            return [body]

    if "app" in globals() and hasattr(globals()["app"], "wsgi_app"):
        globals()["app"].wsgi_app = _VSPHtmlBodyGuard(globals()["app"].wsgi_app, str(_Path(__file__).resolve().parent))
        print("[VSP_HTML_GUARD] enabled outermost guard")
except Exception as _e:
    print("[VSP_HTML_GUARD] disabled:", _e)
# --- /VSP_HTML_BODY_GUARD_OUTERMOST_V1 ---


# VSP_P1_RUN_FILE_WHITELIST_V2_MOUNT
# --- VSP_P1_RUN_FILE_WHITELIST_V2_MOUNT: safe run_file endpoint (whitelist + no traversal) ---
def _vsp_p1_run_file_register_v2(app_obj):
    try:
        import os, mimetypes
        from pathlib import Path
        from flask import request, jsonify, send_file
    except Exception:
        return False

    if not app_obj or not hasattr(app_obj, "add_url_rule"):
        return False

    try:
        if hasattr(app_obj, "view_functions") and ("vsp_run_file_whitelist_v2" in app_obj.view_functions):
            return True
    except Exception:
        pass

    BASE_DIRS = [
        os.environ.get("VSP_OUT_DIR", "") or "",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    ]
    BASE_DIRS = [d for d in BASE_DIRS if d and os.path.isdir(d)]

    ALLOW = {
        "run_gate.json",
        "run_gate_summary.json",
                "reports/run_gate.json",
"reports/run_gate_summary.json",
        "findings_unified.json",
        "findings_unified.sarif",
        "reports/findings_unified.csv",
        "reports/findings_unified.html",
        "reports/findings_unified.tgz",
        "reports/findings_unified.zip",
        "SUMMARY.txt",
    }
    _CACHE = {"rid2dir": {}}

    def _safe_rel(path: str) -> str:
        if not path:
            return ""
        path = path.strip().lstrip("/")
        if ".." in path.split("/"):
            return ""
        while "//" in path:
            path = path.replace("//", "/")
        return path

    def _max_bytes(rel: str) -> int:
        if rel.endswith(".tgz") or rel.endswith(".zip"):
            return 200 * 1024 * 1024
        if rel.endswith(".html"):
            return 80 * 1024 * 1024
        return 25 * 1024 * 1024

    def _find_run_dir(rid: str):
        rid = (rid or "").strip()
        if not rid:
            return None
        if rid in _CACHE["rid2dir"]:
            v = _CACHE["rid2dir"][rid]
            return Path(v) if v else None

        for b in BASE_DIRS:
            cand = Path(b) / rid
            if cand.is_dir():
                _CACHE["rid2dir"][rid] = str(cand)
                return cand

        # bounded shallow search
        for b in BASE_DIRS:
            base = Path(b)
            try:
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    cand = d1 / rid
                    if cand.is_dir():
                        _CACHE["rid2dir"][rid] = str(cand)
                        return cand
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    for d2 in d1.iterdir():
                        if not d2.is_dir(): continue
                        cand = d2 / rid
                        if cand.is_dir():
                            _CACHE["rid2dir"][rid] = str(cand)
                            return cand
            except Exception:
                continue

        _CACHE["rid2dir"][rid] = ""
        return None

    def vsp_run_file_whitelist_v2():
        rid = (request.args.get("rid") or "").strip()
        rel = _safe_rel(request.args.get("path") or "")
        if not rid or not rel:
            return jsonify({"ok": False, "err": "missing rid/path"}), 400
        if rel not in ALLOW:
            return jsonify({"ok": False, "err": "path not allowed", "allow": sorted(ALLOW)}), 200

        run_dir = _find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "run_dir not found", "rid": rid, "roots_used": BASE_DIRS}), 404

        fp = (run_dir / rel)
        try:
            fp_res = fp.resolve()
            rd_res = run_dir.resolve()
            if rd_res not in fp_res.parents and fp_res != rd_res:
                return jsonify({"ok": False, "err": "blocked escape"})
        except Exception:
            return jsonify({"ok": False, "err": "resolve failed"})

        if not fp.exists() or not fp.is_file():
            return jsonify({"ok": False, "err": "file not found", "path": rel}), 404

        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        lim = _max_bytes(rel)
        if sz >= 0 and sz > lim:
            return jsonify({"ok": False, "err": "file too large", "size": sz, "limit": lim}), 413

        mime, _ = mimetypes.guess_type(str(fp))
        mime = mime or "application/octet-stream"
        as_attach = rel.endswith(".tgz") or rel.endswith(".zip")
        dl_name = f"{rid}__{rel.replace('/','_')}"
        return send_file(str(fp), mimetype=mime, as_attachment=as_attach, download_name=dl_name)

    try:
        app_obj.add_url_rule("/api/vsp/run_file", "vsp_run_file_whitelist_v2", vsp_run_file_whitelist_v2, methods=["GET"])
        print("[VSP_RUN_FILE] mounted /api/vsp/run_file (v2 whitelist)")
        return True
    except Exception as e:
        print("[VSP_RUN_FILE] mount failed:", e)
        return False
# --- end VSP_P1_RUN_FILE_WHITELIST_V2_MOUNT ---

# auto-register run_file on import (best-effort)
try:
    _app = globals().get("app", None) or globals().get("application", None)
    _vsp_p1_run_file_register_v2(_app)
except Exception:
    pass


# --- VSP_TABS3_SHORTCIRCUIT_HTML_V1 ---
try:
    from pathlib import Path as _Path

    class _VSPTabs3ShortCircuit:
        def __init__(self, wsgi_app, ui_root: str):
            self.wsgi_app = wsgi_app
            self.ui_root = _Path(ui_root).resolve()
            self.map = {
                "/data_source": self.ui_root / "templates" / "vsp_data_source_2025.html",
                "/settings": self.ui_root / "templates" / "vsp_settings_2025.html",
                "/rule_overrides": self.ui_root / "templates" / "vsp_rule_overrides_2025.html",
            }

        def __call__(self, environ, start_response):
            path = (environ.get("PATH_INFO") or "").strip()
            method = (environ.get("REQUEST_METHOD") or "GET").upper()

            fp = self.map.get(path)
            if fp and fp.exists():
                try:
                    body = fp.read_bytes()
                except Exception:
                    body = b""

                headers = [
                    ("Content-Type", "text/html; charset=utf-8"),
                    ("Cache-Control", "no-store"),
                    ("Content-Length", str(len(body))),
                ]
                start_response("200 OK", headers)

                # HEAD must return no body but keep Content-Length
                if method == "HEAD":
                    return [b""]
                return [body]

            return self.wsgi_app(environ, start_response)

    if "app" in globals() and hasattr(globals()["app"], "wsgi_app"):
        _ui_root = _Path(__file__).resolve().parent
        globals()["app"].wsgi_app = _VSPTabs3ShortCircuit(globals()["app"].wsgi_app, str(_ui_root))
        print("[VSP_TABS3_SC] short-circuit enabled for /data_source,/settings,/rule_overrides")
except Exception as _e:
    print("[VSP_TABS3_SC] disabled:", _e)
# --- /VSP_TABS3_SHORTCIRCUIT_HTML_V1 ---


# VSP_P1_RUN_FILE_FINDER_FALLBACK_V3
# --- VSP_P1_RUN_FILE_FINDER_FALLBACK_V3: upgrade run_file handler to find run_dir robustly + fallback gate ---
def _vsp_p1_run_file_upgrade_v3(app_obj):
    try:
        import os, time, mimetypes
        from pathlib import Path
        from flask import request, jsonify, send_file
    except Exception:
        return False

    if not app_obj or not hasattr(app_obj, "add_url_rule"):
        return False

    # base roots (fast path)
    BASE_DIRS = [
        os.environ.get("VSP_OUT_DIR", "") or "",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",  # common in your env (safe to include)
    ]
    BASE_DIRS = [d for d in BASE_DIRS if d and os.path.isdir(d)]

    # bounded deep finder root (slow path, only on demand)
    DEEP_ROOT = os.environ.get("VSP_DEEP_RUN_ROOT", "/home/test/Data")
    if not os.path.isdir(DEEP_ROOT):
        DEEP_ROOT = ""

    ALLOW = {
        "run_gate.json",
        "run_gate_summary.json",
                "reports/run_gate.json",
"reports/run_gate_summary.json",
        "findings_unified.json",
        "findings_unified.sarif",
        "reports/findings_unified.csv",
        "reports/findings_unified.html",
        "reports/findings_unified.tgz",
        "reports/findings_unified.zip",
        "SUMMARY.txt",
    }
    _CACHE = {"rid2dir": {}}

    def _safe_rel(path: str) -> str:
        if not path:
            return ""
        path = path.strip().lstrip("/")
        if ".." in path.split("/"):
            return ""
        while "//" in path:
            path = path.replace("//", "/")
        return path

    def _max_bytes(rel: str) -> int:
        if rel.endswith(".tgz") or rel.endswith(".zip"):
            return 200 * 1024 * 1024
        if rel.endswith(".html"):
            return 80 * 1024 * 1024
        return 25 * 1024 * 1024

    def _deep_find_dir(rid: str):
        """Bounded os.walk: depth<=6, stop after ~40k dirs or 2.5s."""
        if not DEEP_ROOT:
            return None
        start = time.time()
        max_secs = 2.5
        max_dirs = 40000
        seen = 0

        root = Path(DEEP_ROOT)
        root_depth = len(root.parts)

        try:
            for cur, dirs, files in os.walk(root, topdown=True):
                seen += 1
                if seen > max_dirs or (time.time() - start) > max_secs:
                    return None
                pcur = Path(cur)
                depth = len(pcur.parts) - root_depth
                if depth > 6:
                    dirs[:] = []
                    continue
                # prune heavy dirs (safe)
                prune = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build"}
                dirs[:] = [d for d in dirs if d not in prune]
                if pcur.name == rid:
                    return pcur
        except Exception:
            return None
        return None

    def _find_run_dir(rid: str):
        rid = (rid or "").strip()
        if not rid:
            return None
        if rid in _CACHE["rid2dir"]:
            v = _CACHE["rid2dir"][rid]
            return Path(v) if v else None

        # fast: direct join
        for b in BASE_DIRS:
            cand = Path(b) / rid
            if cand.is_dir():
                _CACHE["rid2dir"][rid] = str(cand)
                return cand

        # fast: shallow search depth 2
        for b in BASE_DIRS:
            base = Path(b)
            try:
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    cand = d1 / rid
                    if cand.is_dir():
                        _CACHE["rid2dir"][rid] = str(cand)
                        return cand
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    for d2 in d1.iterdir():
                        if not d2.is_dir(): continue
                        cand = d2 / rid
                        if cand.is_dir():
                            _CACHE["rid2dir"][rid] = str(cand)
                            return cand
            except Exception:
                pass

        # slow: deep find (bounded)
        cand = _deep_find_dir(rid)
        if cand and cand.is_dir():
            _CACHE["rid2dir"][rid] = str(cand)
            return cand

        _CACHE["rid2dir"][rid] = ""
        return None

    def _resolve_safe(run_dir: Path, rel: str) -> Path | None:
        fp = (run_dir / rel)
        try:
            fp_res = fp.resolve()
            rd_res = run_dir.resolve()
            if rd_res not in fp_res.parents and fp_res != rd_res:
                return None
            return fp_res
        except Exception:
            return None

    def vsp_run_file_handler_v3():
        rid = (request.args.get("rid") or "").strip()
        rel = _safe_rel(request.args.get("path") or "")
        if not rid or not rel:
            return jsonify({"ok": False, "err": "missing rid/path"}), 400
        if rel not in ALLOW:
            return jsonify({"ok": False, "err": "path not allowed", "allow": sorted(ALLOW)}), 200

        run_dir = _find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "run_dir not found", "rid": rid, "roots_used": BASE_DIRS, "deep_root": DEEP_ROOT}), 404

        # fallback: if asking run_gate.json but missing, try summary
        rel_try = [rel]
        if rel == "run_gate.json":
            rel_try = ["run_gate.json", "run_gate_summary.json", "SUMMARY.txt"]

        picked = None
        for rr in rel_try:
            fp = _resolve_safe(run_dir, rr)
            if fp and fp.exists() and fp.is_file():
                picked = (rr, fp)
                break

        if not picked:
            # return helpful list of what exists among allowed
            exists = []
            for rr in sorted(ALLOW):
                fp = _resolve_safe(run_dir, rr)
                if fp and fp.exists() and fp.is_file():
                    exists.append(rr)
            return jsonify({"ok": False, "err": "file not found", "rid": rid, "path": rel, "run_dir": str(run_dir), "has": exists}), 404

        rr, fp = picked
        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        lim = _max_bytes(rr)
        if sz >= 0 and sz > lim:
            return jsonify({"ok": False, "err": "file too large", "size": sz, "limit": lim, "path": rr}), 413

        mime, _ = mimetypes.guess_type(str(fp))
        mime = mime or "application/octet-stream"
        as_attach = rr.endswith(".tgz") or rr.endswith(".zip")
        dl_name = f"{rid}__{rr.replace('/','_')}"
        resp = send_file(str(fp), mimetype=mime, as_attachment=as_attach, download_name=dl_name)
        try:
            if rr != rel:
                resp.headers["X-VSP-Fallback-Path"] = rr
        except Exception:
            pass
        return resp

    # prefer upgrade existing endpoint (your URL rule is already there)
    try:
        vf = getattr(app_obj, "view_functions", {}) or {}
        if "vsp_run_file_whitelist_v2" in vf:
            vf["vsp_run_file_whitelist_v2"] = vsp_run_file_handler_v3
            print("[VSP_RUN_FILE] upgraded endpoint v2 -> v3 handler")
            return True
    except Exception:
        pass

    # otherwise mount fresh
    try:
        app_obj.add_url_rule("/api/vsp/run_file", "vsp_run_file_handler_v3", vsp_run_file_handler_v3, methods=["GET"])
        print("[VSP_RUN_FILE] mounted /api/vsp/run_file (v3)")
        return True
    except Exception as e:
        print("[VSP_RUN_FILE] mount v3 failed:", e)
        return False
# --- end VSP_P1_RUN_FILE_FINDER_FALLBACK_V3 ---

try:
    _vsp_p1_run_file_upgrade_v3(globals().get('app') or globals().get('application'))
except Exception:
    pass


# VSP_P1_FORCE_RUN_FILE_HANDLER_V4
# --- VSP_P1_FORCE_RUN_FILE_HANDLER_V4: force-bind /api/vsp/run_file to whitelist handler (override any "not allowed") ---
def _vsp_p1_force_run_file_handler_v4(app_obj):
    try:
        import os, time, mimetypes
        from pathlib import Path
        from flask import request, jsonify, send_file
    except Exception:
        return False

    if not app_obj or not hasattr(app_obj, "url_map") or not hasattr(app_obj, "view_functions"):
        return False

    BASE_DIRS = [
        os.environ.get("VSP_OUT_DIR", "") or "",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]
    BASE_DIRS = [d for d in BASE_DIRS if d and os.path.isdir(d)]

    DEEP_ROOT = os.environ.get("VSP_DEEP_RUN_ROOT", "/home/test/Data")
    if not os.path.isdir(DEEP_ROOT):
        DEEP_ROOT = ""

    ALLOW = {
        "run_gate.json",
        "run_gate_summary.json",
                "reports/run_gate.json",
"reports/run_gate_summary.json",
        "findings_unified.json",
        "findings_unified.sarif",
        "reports/findings_unified.csv",
        "reports/findings_unified.html",
        "reports/findings_unified.tgz",
        "reports/findings_unified.zip",
        "SUMMARY.txt",
    }
    _CACHE = {"rid2dir": {}}

    def _safe_rel(path: str) -> str:
        if not path:
            return ""
        path = path.strip().lstrip("/")
        if ".." in path.split("/"):
            return ""
        while "//" in path:
            path = path.replace("//", "/")
        return path

    def _max_bytes(rel: str) -> int:
        if rel.endswith(".tgz") or rel.endswith(".zip"):
            return 200 * 1024 * 1024
        if rel.endswith(".html"):
            return 80 * 1024 * 1024
        return 25 * 1024 * 1024

    def _deep_find_dir(rid: str):
        if not DEEP_ROOT:
            return None
        start = time.time()
        max_secs = 2.5
        max_dirs = 40000
        seen = 0
        root = Path(DEEP_ROOT)
        root_depth = len(root.parts)
        prune = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build"}

        try:
            for cur, dirs, files in os.walk(root, topdown=True):
                seen += 1
                if seen > max_dirs or (time.time() - start) > max_secs:
                    return None
                pcur = Path(cur)
                depth = len(pcur.parts) - root_depth
                if depth > 6:
                    dirs[:] = []
                    continue
                dirs[:] = [d for d in dirs if d not in prune]
                if pcur.name == rid:
                    return pcur
        except Exception:
            return None
        return None

    def _find_run_dir(rid: str):
        rid = (rid or "").strip()
        if not rid:
            return None
        if rid in _CACHE["rid2dir"]:
            v = _CACHE["rid2dir"][rid]
            return Path(v) if v else None

        # direct
        for b in BASE_DIRS:
            cand = Path(b) / rid
            if cand.is_dir():
                _CACHE["rid2dir"][rid] = str(cand)
                return cand

        # shallow depth 2
        for b in BASE_DIRS:
            base = Path(b)
            try:
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    cand = d1 / rid
                    if cand.is_dir():
                        _CACHE["rid2dir"][rid] = str(cand)
                        return cand
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    for d2 in d1.iterdir():
                        if not d2.is_dir(): continue
                        cand = d2 / rid
                        if cand.is_dir():
                            _CACHE["rid2dir"][rid] = str(cand)
                            return cand
            except Exception:
                pass

        # deep bounded
        cand = _deep_find_dir(rid)
        if cand and cand.is_dir():
            _CACHE["rid2dir"][rid] = str(cand)
            return cand

        _CACHE["rid2dir"][rid] = ""
        return None

    def _resolve_safe(run_dir: Path, rel: str):
        fp = (run_dir / rel)
        try:
            fp_res = fp.resolve()
            rd_res = run_dir.resolve()
            if rd_res not in fp_res.parents and fp_res != rd_res:
                return None
            return fp_res
        except Exception:
            return None

    def vsp_run_file_v4():
        rid = (request.args.get("rid") or "").strip()
        rel = _safe_rel(request.args.get("path") or "")
        if not rid or not rel:
            return jsonify({"ok": False, "err": "missing rid/path"}), 400

        # keep "no auto probe" policy at UI-level; backend remains read-only whitelist
        if rel not in ALLOW:
            return jsonify({"ok": False, "err": "path not allowed", "allow": sorted(ALLOW)}), 200

        run_dir = _find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "run_dir not found", "rid": rid, "roots_used": BASE_DIRS, "deep_root": DEEP_ROOT}), 404

        rel_try = [rel]
        if rel == "run_gate.json":
            rel_try = ["run_gate.json", "run_gate_summary.json", "SUMMARY.txt"]

        picked = None
        for rr in rel_try:
            fp = _resolve_safe(run_dir, rr)
            if fp and fp.exists() and fp.is_file():
                picked = (rr, fp)
                break

        if not picked:
            exists = []
            for rr in sorted(ALLOW):
                fp = _resolve_safe(run_dir, rr)
                if fp and fp.exists() and fp.is_file():
                    exists.append(rr)
            return jsonify({"ok": False, "err": "file not found", "rid": rid, "path": rel, "run_dir": str(run_dir), "has": exists}), 404

        rr, fp = picked
        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        lim = _max_bytes(rr)
        if sz >= 0 and sz > lim:
            return jsonify({"ok": False, "err": "file too large", "size": sz, "limit": lim, "path": rr}), 413

        mime, _ = mimetypes.guess_type(str(fp))
        mime = mime or "application/octet-stream"
        as_attach = rr.endswith(".tgz") or rr.endswith(".zip")
        dl_name = f"{rid}__{rr.replace('/','_')}"
        resp = send_file(str(fp), mimetype=mime, as_attachment=as_attach, download_name=dl_name)
        try:
            if rr != rel:
                resp.headers["X-VSP-Fallback-Path"] = rr
        except Exception:
            pass
        return resp

    # FORCE override any existing endpoint bound to path "/api/vsp/run_file"
    endpoints = []
    try:
        for rule in app_obj.url_map.iter_rules():
            if getattr(rule, "rule", "") == "/api/vsp/run_file":
                endpoints.append(rule.endpoint)
    except Exception:
        endpoints = []

    ok = False
    for ep in set(endpoints):
        try:
            app_obj.view_functions[ep] = vsp_run_file_v4
            ok = True
        except Exception:
            pass

    if ok:
        print(f"[VSP_RUN_FILE] V4 force-bound endpoints={sorted(set(endpoints))}")
        return True

    # if no rule existed, mount it
    try:
        app_obj.add_url_rule("/api/vsp/run_file", "vsp_run_file_v4", vsp_run_file_v4, methods=["GET"])
        print("[VSP_RUN_FILE] V4 mounted fresh /api/vsp/run_file")
        return True
    except Exception as e:
        print("[VSP_RUN_FILE] V4 mount failed:", e)
        return False
# --- end VSP_P1_FORCE_RUN_FILE_HANDLER_V4 ---

# auto-bind on import (best-effort)
try:
    _app = globals().get("app", None) or globals().get("application", None)
    _vsp_p1_force_run_file_handler_v4(_app)
except Exception:
    pass


# VSP_P1_RUN_FILE_ALLOW_V5
# --- VSP_P1_RUN_FILE_ALLOW_V5: separate allow endpoint (keeps /api/vsp/run_file policy OFF) ---
def _vsp_p1_register_run_file_allow_v5(app_obj):
    try:
        import os, time, mimetypes
        from pathlib import Path
        from flask import request, jsonify, send_file
    except Exception:
        return False
    if not app_obj or not hasattr(app_obj, "add_url_rule"):
        return False

    # avoid double register
    try:
        if hasattr(app_obj, "view_functions") and ("vsp_run_file_allow_v5" in app_obj.view_functions):
            return True
    except Exception:
        pass

    BASE_DIRS = [
        os.environ.get("VSP_OUT_DIR", "") or "",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]
    BASE_DIRS = [d for d in BASE_DIRS if d and os.path.isdir(d)]

    # bounded deep find root (only on demand)
    DEEP_ROOT = os.environ.get("VSP_DEEP_RUN_ROOT", "/home/test/Data")
    if not os.path.isdir(DEEP_ROOT):
        DEEP_ROOT = ""

    # strict whitelist
    ALLOW = {
        "run_gate.json",
        "run_gate_summary.json",
                "reports/run_gate.json",
"reports/run_gate_summary.json",
        "findings_unified.json",
        "findings_unified.sarif",
        "reports/findings_unified.csv",
        "reports/findings_unified.html",
        "reports/findings_unified.tgz",
        "reports/findings_unified.zip",
        "SUMMARY.txt",
    }
    _CACHE = {"rid2dir": {}}

    def _safe_rel(path: str) -> str:
        if not path:
            return ""
        path = path.strip().lstrip("/")
        if ".." in path.split("/"):
            return ""
        while "//" in path:
            path = path.replace("//", "/")
        return path

    def _max_bytes(rel: str) -> int:
        if rel.endswith(".tgz") or rel.endswith(".zip"):
            return 200 * 1024 * 1024
        if rel.endswith(".html"):
            return 80 * 1024 * 1024
        return 25 * 1024 * 1024

    def _deep_find_dir(rid: str):
        if not DEEP_ROOT:
            return None
        start = time.time()
        max_secs = 2.5
        max_dirs = 40000
        seen = 0
        root = Path(DEEP_ROOT)
        root_depth = len(root.parts)
        prune = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build"}
        try:
            for cur, dirs, files in os.walk(root, topdown=True):
                seen += 1
                if seen > max_dirs or (time.time() - start) > max_secs:
                    return None
                pcur = Path(cur)
                depth = len(pcur.parts) - root_depth
                if depth > 6:
                    dirs[:] = []
                    continue
                dirs[:] = [d for d in dirs if d not in prune]
                if pcur.name == rid:
                    return pcur
        except Exception:
            return None
        return None

    def _find_run_dir(rid: str):
        rid = (rid or "").strip()
        if not rid:
            return None
        if rid in _CACHE["rid2dir"]:
            v = _CACHE["rid2dir"][rid]
            return Path(v) if v else None

        for b in BASE_DIRS:
            cand = Path(b) / rid
            if cand.is_dir():
                _CACHE["rid2dir"][rid] = str(cand)
                return cand

        for b in BASE_DIRS:
            base = Path(b)
            try:
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    cand = d1 / rid
                    if cand.is_dir():
                        _CACHE["rid2dir"][rid] = str(cand)
                        return cand
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    for d2 in d1.iterdir():
                        if not d2.is_dir(): continue
                        cand = d2 / rid
                        if cand.is_dir():
                            _CACHE["rid2dir"][rid] = str(cand)
                            return cand
            except Exception:
                pass

        cand = _deep_find_dir(rid)
        if cand and cand.is_dir():
            _CACHE["rid2dir"][rid] = str(cand)
            return cand

        _CACHE["rid2dir"][rid] = ""
        return None

    def _resolve_safe(run_dir: Path, rel: str):
        fp = (run_dir / rel)
        try:
            fp_res = fp.resolve()
            rd_res = run_dir.resolve()
            if rd_res not in fp_res.parents and fp_res != rd_res:
                return None
            return fp_res
        except Exception:
            return None

    def vsp_run_file_allow_v5():
        # ===== VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_DUALPATCH_V4_INJECT =====
        try:
            # Self-contained: no dependency on module-level imports/helpers.
            from flask import request, make_response
            import json, time

            _rid = request.args.get("rid", "") or request.args.get("RID", "")
            _path = request.args.get("path", "") or request.args.get("PATH", "")

            if _path in ("run_manifest.json", "run_evidence_index.json"):
                now = int(time.time())
                served_by = globals().get("__file__", "unknown")

                if _path == "run_manifest.json":
                    payload = {
                        "ok": True,
                        "rid": _rid,
                        "gate_root": (f"gate_root_{_rid}" if _rid else None),
                        "gate_root_path": None,
                        "generated": True,
                        "generated_at": now,
                        "degraded": True,
                        "served_by": served_by,
                        "required_paths": [
                            "run_gate.json",
                            "run_gate_summary.json",
                            "findings_unified.json",
                            "reports/findings_unified.csv",
                            "run_manifest.json",
                            "run_evidence_index.json",
                        ],
                        "optional_paths": [
                            "reports/findings_unified.sarif",
                            "reports/findings_unified.html",
                            "reports/findings_unified.pdf",
                        ],
                        "hints": {
                            "why_degraded": "RUNS root not resolved in filesystem yet (P0 safe mode).",
                            "set_env": "Set VSP_RUNS_ROOT or VSP_RUNS_ROOTS to parent folder that contains gate_root_<RID>.",
                            "example": "VSP_RUNS_ROOT=/home/test/Data/SECURITY-10-10-v4/out_ci",
                        },
                    }
                else:
                    payload = {
                        "ok": True,
                        "rid": _rid,
                        "gate_root": (f"gate_root_{_rid}" if _rid else None),
                        "gate_root_path": None,
                        "generated": True,
                        "generated_at": now,
                        "degraded": True,
                        "served_by": served_by,
                        "evidence_dir": None,
                        "files": [],
                        "missing_recommended": [
                            "evidence/ui_engine.log",
                            "evidence/trace.zip",
                            "evidence/last_page.html",
                            "evidence/storage_state.json",
                            "evidence/net_summary.json",
                        ],
                    }

                resp = make_response(json.dumps(payload, ensure_ascii=False, indent=2), 200)
                resp.mimetype = "application/json"
                return resp

        except Exception as e:
            # Even if Flask helpers fail, return a tuple fallback (never 500).
            try:
                import json
                served_by = globals().get("__file__", "unknown")
                payload = {
                    "ok": False,
                    "generated": True,
                    "degraded": True,
                    "served_by": served_by,
                    "err": f"{type(e).__name__}: {e}",
                    "hint": "P0 SAFE MODE: inject fallback engaged; check service logs for root cause.",
                }
                return (json.dumps(payload, ensure_ascii=False, indent=2), 200, {"Content-Type":"application/json; charset=utf-8"})
            except Exception:
                return ("{}", 200, {"Content-Type":"application/json; charset=utf-8"})
        # ===== /VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_DUALPATCH_V4_INJECT =====
        # ===== VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_ALWAYS200_V3_INJECT =====
        try:
            # Self-contained: no dependency on module-level imports/helpers.
            from flask import request, make_response
            import json, time

            _rid = request.args.get("rid", "") or request.args.get("RID", "")
            _path = request.args.get("path", "") or request.args.get("PATH", "")

            if _path in ("run_manifest.json", "run_evidence_index.json"):
                now = int(time.time())
                served_by = globals().get("__file__", "unknown")

                if _path == "run_manifest.json":
                    payload = {
                        "ok": True,
                        "rid": _rid,
                        "gate_root": (f"gate_root_{_rid}" if _rid else None),
                        "gate_root_path": None,
                        "generated": True,
                        "generated_at": now,
                        "degraded": True,
                        "served_by": served_by,
                        "required_paths": [
                            "run_gate.json",
                            "run_gate_summary.json",
                            "findings_unified.json",
                            "reports/findings_unified.csv",
                            "run_manifest.json",
                            "run_evidence_index.json",
                        ],
                        "optional_paths": [
                            "reports/findings_unified.sarif",
                            "reports/findings_unified.html",
                            "reports/findings_unified.pdf",
                        ],
                        "hints": {
                            "why_degraded": "RUNS root not resolved in filesystem yet (P0 safe mode).",
                            "set_env": "Set VSP_RUNS_ROOT or VSP_RUNS_ROOTS to parent folder that contains gate_root_<RID>.",
                            "example": "VSP_RUNS_ROOT=/home/test/Data/SECURITY-10-10-v4/out_ci",
                        },
                    }
                else:
                    payload = {
                        "ok": True,
                        "rid": _rid,
                        "gate_root": (f"gate_root_{_rid}" if _rid else None),
                        "gate_root_path": None,
                        "generated": True,
                        "generated_at": now,
                        "degraded": True,
                        "served_by": served_by,
                        "evidence_dir": None,
                        "files": [],
                        "missing_recommended": [
                            "evidence/ui_engine.log",
                            "evidence/trace.zip",
                            "evidence/last_page.html",
                            "evidence/storage_state.json",
                            "evidence/net_summary.json",
                        ],
                    }

                resp = make_response(json.dumps(payload, ensure_ascii=False, indent=2), 200)
                resp.mimetype = "application/json"
                return resp

        except Exception as e:
            # Even if Flask helpers fail, return a tuple fallback (never 500).
            try:
                import json
                served_by = globals().get("__file__", "unknown")
                payload = {
                    "ok": False,
                    "generated": True,
                    "degraded": True,
                    "served_by": served_by,
                    "err": f"{type(e).__name__}: {e}",
                    "hint": "P0 SAFE MODE: inject fallback engaged; check service logs for root cause.",
                }
                return (json.dumps(payload, ensure_ascii=False, indent=2), 200, {"Content-Type":"application/json; charset=utf-8"})
            except Exception:
                return ("{}", 200, {"Content-Type":"application/json; charset=utf-8"})
        # ===== /VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_ALWAYS200_V3_INJECT =====
        # VSP_P0_AUTOGEN_MANIFEST_EVIDENCEINDEX_V1: autogen core audit files if missing (P0)
        try:
            if path in ('run_manifest.json','run_evidence_index.json'):
                import os
                _run_dir = str(run_dir) if 'run_dir' in locals() else None
                # VSP_P0_RUN_DIR_GUARD_V4D
                try:
                  import os, time
                  from flask import jsonify
                  _rd = _run_dir
                  if (not _rd) or (not os.path.isdir(str(_rd))):
                    if path in ('run_manifest.json','run_evidence_index.json'):
                      obj={'rid':str(rid),'generated_at':int(time.time()),'run_dir':str(_rd),'note':'run_dir missing (P0)','required':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'present':[],'missing':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'audit_ready':False}
                      return jsonify(obj), 200
                    return jsonify({'ok':False,'err':'run_dir not found','rid':str(rid),'path':str(path),'run_dir':str(_rd)}), 404
                except Exception:
                  pass
                # VSP_P0_RUN_DIR_GUARD_V4C
                try:
                  import os, time
                  from flask import jsonify
                  _rd = _run_dir
                  if (not _rd) or (not os.path.isdir(str(_rd))):
                    if path in ('run_manifest.json','run_evidence_index.json'):
                      obj={'rid':str(rid),'generated_at':int(time.time()),'run_dir':str(_rd),'note':'run_dir missing (P0)','required':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'present':[],'missing':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'audit_ready':False}
                      return jsonify(obj), 200
                    return jsonify({'ok':False,'err':'run_dir not found','rid':str(rid),'path':str(path),'run_dir':str(_rd)}), 404
                except Exception:
                  pass
                if _run_dir and os.path.isdir(_run_dir):
                    _fp = os.path.join(_run_dir, path)
                    # VSP_P0_MISSING_FILE_GUARD_V4D
                    try:
                      import os, time, json
                      from flask import jsonify
                      if not os.path.exists(_fp):
                        if path in ('run_manifest.json','run_evidence_index.json'):
                          files=[]
                          try:
                            for root, dirs, fns in os.walk(_run_dir):
                              bn=os.path.basename(root)
                              if bn in ('node_modules','.git','__pycache__'): continue
                              for fn in fns:
                                fp2=os.path.join(root, fn)
                                rel=os.path.relpath(fp2, _run_dir).replace('\\','/')
                                try:
                                  st=os.stat(fp2)
                                  files.append({'path':rel,'size':int(st.st_size),'mtime':int(st.st_mtime)})
                                except Exception:
                                  files.append({'path':rel})
                            files.sort(key=lambda x: x.get('path',''))
                          except Exception:
                            files=[]
                          obj={'rid':str(rid),'generated_at':int(time.time()),'run_dir':str(_run_dir),'files_total':len(files),'files':files,'note':'auto-generated (P0)'}
                          if path=='run_evidence_index.json':
                            present=[]; missing=[]
                            for r in ['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html']:
                              (present if os.path.exists(os.path.join(_run_dir, r)) else missing).append(r)
                            obj.update({'required':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'present':present,'missing':missing,'audit_ready':(len(missing)==0)})
                          try:
                            os.makedirs(os.path.dirname(_fp), exist_ok=True)
                            with open(_fp, 'w', encoding='utf-8') as f:
                              json.dump(obj, f, ensure_ascii=False, indent=2)
                          except Exception:
                            pass
                          return jsonify(obj), 200
                        return jsonify({'ok':False,'err':'not found','rid':str(rid),'path':str(path)}), 404
                    except Exception:
                      pass
                    # VSP_P0_MISSING_FILE_GUARD_V4C
                    try:
                      import os, time, json
                      from flask import jsonify
                      if not os.path.exists(_fp):
                        if path in ('run_manifest.json','run_evidence_index.json'):
                          files=[]
                          try:
                            for root, dirs, fns in os.walk(_run_dir):
                              bn=os.path.basename(root)
                              if bn in ('node_modules','.git','__pycache__'): continue
                              for fn in fns:
                                fp2=os.path.join(root, fn)
                                rel=os.path.relpath(fp2, _run_dir).replace('\\','/')
                                try:
                                  st=os.stat(fp2)
                                  files.append({'path':rel,'size':int(st.st_size),'mtime':int(st.st_mtime)})
                                except Exception:
                                  files.append({'path':rel})
                            files.sort(key=lambda x: x.get('path',''))
                          except Exception:
                            files=[]
                          obj={'rid':str(rid), 'generated_at':int(time.time()), 'run_dir':str(_run_dir), 'files_total':len(files), 'files':files, 'note':'auto-generated (P0)'}
                          if path=='run_evidence_index.json':
                            required=['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html']
                            present=[]; missing=[]
                            for r in required:
                              (present if os.path.exists(os.path.join(_run_dir, r)) else missing).append(r)
                            obj.update({'required':required,'present':present,'missing':missing,'audit_ready':(len(missing)==0)})
                          try:
                            os.makedirs(os.path.dirname(_fp), exist_ok=True)
                            with open(_fp, 'w', encoding='utf-8') as f:
                              json.dump(obj, f, ensure_ascii=False, indent=2)
                          except Exception:
                            pass
                          return jsonify(obj), 200
                        return jsonify({'ok':False,'err':'not found','rid':str(rid),'path':str(path)}), 404
                    except Exception:
                      pass
                    # VSP_P0_RUNFILEALLOW_MISSING_GUARD_AUTOGEN_CORE_V3B
                    try:
                      import os, time, json
                      from flask import jsonify
                      if not os.path.exists(_fp):
                        if path in ('run_manifest.json','run_evidence_index.json'):
                          files=[]
                          try:
                            for root, dirs, fns in os.walk(_run_dir):
                              bn=os.path.basename(root)
                              if bn in ('node_modules','.git','__pycache__'): continue
                              for fn in fns:
                                fp2=os.path.join(root, fn)
                                rel=os.path.relpath(fp2, _run_dir).replace('\\','/')
                                # --- VSP_P0_RUN_FILE_ALLOW_REPORTS_GATE_V13B ---
                                # allow-key normalization for gate files; keep `rel` for file open
                                rel_key = rel
                                if isinstance(rel_key, str):
                                    if rel_key.startswith('/'):
                                        rel_key = rel_key[1:]
                                    if rel_key.startswith('reports/'):
                                        _tail = rel_key[len('reports/'):]
                                        if _tail in ('run_gate_summary.json','run_gate.json'):
                                            rel_key = _tail
                                # --- /VSP_P0_RUN_FILE_ALLOW_REPORTS_GATE_V13B ---
                                try:
                                  st=os.stat(fp2)
                                  files.append({'path':rel,'size':int(st.st_size),'mtime':int(st.st_mtime)})
                                except Exception:
                                  files.append({'path':rel})
                            files.sort(key=lambda x: x.get('path',''))
                          except Exception:
                            files=[]
                          obj={'rid':str(rid), 'generated_at':int(time.time()), 'run_dir':str(_run_dir), 'files_total':len(files), 'files':files, 'note':'auto-generated (P0)'}
                          if path=='run_evidence_index.json':
                            required=['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html']
                            present=[]; missing=[]
                            for r in required:
                              (present if os.path.exists(os.path.join(_run_dir, r)) else missing).append(r)
                            obj.update({'required':required,'present':present,'missing':missing,'audit_ready':(len(missing)==0)})
                          try:
                            os.makedirs(os.path.dirname(_fp), exist_ok=True)
                            with open(_fp, 'w', encoding='utf-8') as f:
                              json.dump(obj, f, ensure_ascii=False, indent=2)
                          except Exception:
                            pass
                          return jsonify(obj), 200
                        return jsonify({'ok':False,'err':'not found','rid':str(rid),'path':str(path)}), 404
                    except Exception:
                      # don't crash into 500 tracebacks for missing paths
                      try:
                        from flask import jsonify
                        return jsonify({'ok':False,'err':'internal error','rid':str(rid),'path':str(path)}), 500
                      except Exception:
                        return ('internal error', 500)
                    if not os.path.exists(_fp):
                        _obj = _vsp_p0_make_run_manifest(_run_dir, str(rid)) if path=='run_manifest.json' else _vsp_p0_make_run_evidence_index(_run_dir, str(rid))
                        _vsp_p0__write_json_if_possible(_fp, _obj)
                        # return 200 even if write failed
                        from flask import jsonify
                        return jsonify(_obj)
        except Exception:
            pass
        # VSP_P0_RUNFILEALLOW_CONTRACT_ALLOW_UPDATE_V5: dashboard contract whitelist
        try:
            ALLOW.update({'run_manifest.json','run_evidence_index.json','reports/findings_unified.sarif','reports/run_gate_summary.json','reports/run_gate.json'})
        except Exception:
            pass
        rid = (request.args.get("rid") or "").strip()
        rel = _safe_rel(request.args.get("path") or "")
        # VSP_P0_CORE_ALWAYS200_V5C
        try:
          import time
          from flask import jsonify
          if path in ('run_manifest.json','run_evidence_index.json'):
            _rid = str(rid)
            obj={'rid':_rid,'generated_at':int(time.time()),'note':'P0: core contract always 200; run_dir unresolved (set VSP_RUNS_ROOT later to autogen real files)'}
            if path=='run_manifest.json':
              obj.update({'files_total':0,'files':[]})
            else:
              obj.update({'required':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'present':[],'missing':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'audit_ready':False})
            return jsonify(obj), 200
        except Exception:
          pass
                # VSP_P0_DASHBOARD_FASTPATH_V5
        try:
          import os, time, json
          from pathlib import Path as _P
          from flask import jsonify, send_file
        
          _P0_CORE = ("run_manifest.json","run_evidence_index.json")
          _P0_OPT  = ("reports/findings_unified.sarif","reports/findings_unified.html")
          _P0_FAST = set(_P0_CORE + _P0_OPT)
        
          def _vsp_p0_resolve_run_dir(_rid: str) -> str:
            if not _rid:
              return ""
            here = _P(__file__).resolve()
            # repo layout: .../SECURITY_BUNDLE/ui/<file.py>
            bundle_root = here.parent.parent  # SECURITY_BUNDLE
            bases = [
              bundle_root / "out_ci",
              bundle_root / "out",
              bundle_root / "out_ci" / "VSP",
              bundle_root / "out" / "VSP",
            ]
            # direct candidates
            direct = [
              lambda b: b / _rid,
              lambda b: b / f"gate_root_{_rid}",
              lambda b: b / f"RUN_{_rid}",
              lambda b: b / f"VSP_CI_RUN_{_rid}",
            ]
            for b in bases:
              try:
                if not b.exists(): 
                  continue
                for fn in direct:
                  cand = fn(b)
                  if cand.is_dir() and ((cand/"run_gate.json").exists() or (cand/"run_gate_summary.json").exists() or (cand/"findings_unified.json").exists()):
                    return str(cand)
                # 1-level glob (cheap)
                for cand in b.glob(f"*{_rid}*"):
                  try:
                    if cand.is_dir() and ((cand/"run_gate.json").exists() or (cand/"run_gate_summary.json").exists() or (cand/"findings_unified.json").exists()):
                      return str(cand)
                  except Exception:
                    continue
              except Exception:
                continue
            return ""
        
          def _vsp_p0_autogen_manifest(_run_dir: str, _rid: str):
            # keep it cheap: only list top-level + reports/
            files=[]
            try:
              rd=_P(_run_dir)
              for p in sorted(rd.rglob("*")):
                try:
                  if p.is_dir(): 
                    continue
                  rel = str(p.relative_to(rd)).replace("\\\\","/")
                  st = p.stat()
                  files.append({"path":rel,"size":int(st.st_size),"mtime":int(st.st_mtime)})
                except Exception:
                  continue
            except Exception:
              files=[]
            return {
              "rid": _rid,
              "generated_at": int(time.time()),
              "run_dir": _run_dir,
              "files_total": len(files),
              "files": files,
              "note": "auto-generated (P0 dashboard fast-path)"
            }
        
          def _vsp_p0_autogen_evidence_index(_run_dir: str, _rid: str):
            required = [
              "run_gate.json","run_gate_summary.json","findings_unified.json",
              "run_manifest.json","run_evidence_index.json",
              "reports/findings_unified.csv","reports/findings_unified.sarif","reports/findings_unified.html"
            ]
            present=[]; missing=[]
            for r in required:
              (present if os.path.exists(os.path.join(_run_dir, r)) else missing).append(r)
            return {
              "rid": _rid,
              "generated_at": int(time.time()),
              "run_dir": _run_dir,
              "required": required,
              "present": present,
              "missing": missing,
              "audit_ready": (len(missing)==0),
              "note": "auto-generated (P0 dashboard fast-path)"
            }
        
          if path in _P0_FAST:
            _rid = str(rid)
            _rd = _vsp_p0_resolve_run_dir(_rid)
            if not _rd or (not os.path.isdir(_rd)):
              if path in _P0_CORE:
                # return 200 so Dashboard doesn't break; caller can see run_dir missing
                obj = {
                  "rid": _rid,
                  "generated_at": int(time.time()),
                  "run_dir": str(_rd),
                  "note": "run_dir not found (P0 dashboard fast-path)",
                  "required": [],
                  "present": [],
                  "missing": [],
                  "audit_ready": False
                }
                return jsonify(obj), 200
              return jsonify({"ok": False, "err": "not generated", "rid": _rid, "path": path, "run_dir": str(_rd)}), 404
        
            _fp = os.path.join(_rd, path)
            if not os.path.exists(_fp):
              if path == "run_manifest.json":
                obj = _vsp_p0_autogen_manifest(_rd, _rid)
              elif path == "run_evidence_index.json":
                obj = _vsp_p0_autogen_evidence_index(_rd, _rid)
              else:
                return jsonify({"ok": False, "err": "not generated", "rid": _rid, "path": path}), 404
              # persist best-effort
              try:
                os.makedirs(os.path.dirname(_fp), exist_ok=True)
                with open(_fp, "w", encoding="utf-8") as f:
                  json.dump(obj, f, ensure_ascii=False, indent=2)
              except Exception:
                pass
              return jsonify(obj), 200
        
            # exists => serve; never 500 for dashboard fast paths
            try:
              # ===================== VSP_P1_RUN_FILE_ALLOW_GATE_SUMMARY_JSONIFY_V6 =====================
              # If requesting run_gate_summary.json/run_gate.json: serve as jsonify with ok:true (avoid send_file passthrough)
              try:
                  _path = (locals().get("path") or locals().get("req_path") or "")
                  _rid  = (locals().get("rid") or locals().get("run_id") or "")
                  if _path and (str(_path).endswith("run_gate_summary.json") or str(_path).endswith("run_gate.json")):
                      import json as _json
                      from pathlib import Path as _Path
                      try:
                          from flask import jsonify as _jsonify
                      except Exception:
                          import flask as _flask
                          _jsonify = _flask.jsonify
                      _fp = _fp
                      _j = _json.loads(_Path(str(_fp)).read_text(encoding="utf-8", errors="replace"))
                      if isinstance(_j, dict):
                          _j.setdefault("ok", True)
                          if _rid:
                              _j.setdefault("rid", _rid)
                              _j.setdefault("run_id", _rid)
                      return _jsonify(_j)
              except Exception:
                  pass
              # ===================== /VSP_P1_RUN_FILE_ALLOW_GATE_SUMMARY_JSONIFY_V6 =====================
              return send_file(_fp, as_attachment=False)
            except Exception as e:
              return jsonify({"ok": False, "err": "send_file failed", "rid": _rid, "path": path, "detail": str(e)}), 404
        except Exception:
          pass
        
        # --- VSP_P0_TRUEFIX_REPORTS_GATE_V12 ---\n        def _vsp_allow_key(_p):\n            if isinstance(_p, str) and _p.startswith('reports/'):\n                _t = _p[len('reports/'):]\n                if _t in ('run_gate_summary.json','run_gate.json'):\n                    return _t\n            return _p\n        # --- /VSP_P0_TRUEFIX_REPORTS_GATE_V12 ---\n        # --- VSP_P0_RUN_FILE_ALLOW_REPORTS_GATE_TRUEFIX_V10 ---
        _vsp_rel_req = rel
        _vsp_allow_key = rel
        try:
            if isinstance(_vsp_allow_key, str) and _vsp_allow_key.startswith('reports/'):
                _s = _vsp_allow_key[len('reports/'):]
                if _s in ('run_gate_summary.json','run_gate.json'):
                    _vsp_allow_key = _s  # allow-check uses root name
        except Exception:
            _vsp_allow_key = rel
        # --- /VSP_P0_RUN_FILE_ALLOW_REPORTS_GATE_TRUEFIX_V10 ---
        if not rid or not rel:
            return jsonify({"ok": False, "err": "missing rid/path"}), 400

        # --- VSP_P0_FORCEALLOW_GATE_REPORTS_V3 ---
        __vsp_extra_allow = set(["reports/run_gate_summary.json","reports/run_gate.json"])
        # --- /VSP_P0_FORCEALLOW_GATE_REPORTS_V3 ---
        if (rel_key not in ALLOW) and (rel_key not in __vsp_extra_allow):

            return jsonify({"ok": False, "err": "not allowed", "allow": sorted(ALLOW)}), 200

        run_dir = _find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "run_dir not found", "rid": rid, "roots_used": BASE_DIRS, "deep_root": DEEP_ROOT}), 404

        rel_try = [rel]
        if rel == "run_gate.json":
            rel_try = ["run_gate.json", "run_gate_summary.json", "SUMMARY.txt"]

        picked = None
        for rr in rel_try:
            fp = _resolve_safe(run_dir, rr)
            if fp and fp.exists() and fp.is_file():
                picked = (rr, fp)
                break

        if not picked:
            exists = []
            for rr in sorted(ALLOW):
                fp = _resolve_safe(run_dir, rr)
                if fp and fp.exists() and fp.is_file():
                    exists.append(rr)
            return jsonify({"ok": False, "err": "file not found", "rid": rid, "path": rel, "run_dir": str(run_dir), "has": exists}), 404

        rr, fp = picked
        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        lim = _max_bytes(rr)
        if sz >= 0 and sz > lim:
            return jsonify({"ok": False, "err": "file too large", "size": sz, "limit": lim, "path": rr}), 413

        mime, _ = mimetypes.guess_type(str(fp))
        mime = mime or "application/octet-stream"
        as_attach = rr.endswith(".tgz") or rr.endswith(".zip")
        dl_name = f"{rid}__{rr.replace('/','_')}"
        resp = send_file(str(fp), mimetype=mime, as_attachment=as_attach, download_name=dl_name)
        try:
            if rr != rel:
                resp.headers["X-VSP-Fallback-Path"] = rr
        except Exception:
            pass
        return resp

    try:
        app_obj.add_url_rule("/api/vsp/run_file_allow", "vsp_run_file_allow_v5", vsp_run_file_allow_v5, methods=["GET"])
        print("[VSP_RUN_FILE_ALLOW] mounted /api/vsp/run_file_allow")
        return True
    except Exception as e:
        print("[VSP_RUN_FILE_ALLOW] mount failed:", e)
        return False
# --- end VSP_P1_RUN_FILE_ALLOW_V5 ---

try:
    _app = globals().get("app", None) or globals().get("application", None)
    _vsp_p1_register_run_file_allow_v5(_app)
except Exception:
    pass


# --- VSP_TABS3_UI_BP_REGISTER_V4 ---
try:
    from vsp_tabs3_ui_bp_v4 import vsp_tabs3_ui_bp_v4 as _vsp_tabs3_ui_bp_v4
    if "app" in globals() and hasattr(globals()["app"], "register_blueprint"):
        globals()["app"].register_blueprint(_vsp_tabs3_ui_bp_v4)
        print("[VSP_TABS3_V4] registered blueprint: vsp_tabs3_ui_bp_v4")
except Exception as _e:
    print("[VSP_TABS3_V4] blueprint disabled:", _e)
# --- /VSP_TABS3_UI_BP_REGISTER_V4 ---


# ============================================================
# VSP_P1_TABS3_API_ROUTES_AND_API404_V1
# - Ensure /api/ui/* routes exist (runs/findings/settings/rule_overrides/apply)
# - Ensure /api/* 404 returns JSON (no HTML injector)
# ============================================================
def _vsp__get_app_obj():
    try:
        return app  # type: ignore
    except Exception:
        pass
    try:
        return application  # type: ignore
    except Exception:
        pass
    return None

_vsp_app = _vsp__get_app_obj()
if _vsp_app:
    try:
        from flask import request, jsonify
    except Exception:
        request = None
        jsonify = None

    # --- harden 404 for /api/* ---
    try:
        @_vsp_app.errorhandler(404)
        def _vsp_api_404(e):  # noqa: F811
            try:
                path = (request.path if request else "")

                # VSP_P1_RUN_FILE_ALLOW_REPORTS_V1: commercial allowlist (read-only)
                try:
                    if not _vsp_run_file_allow_ok_v1(path):
                        return {"ok": False, "err": "not allowed", "path": path}
                except Exception:
                    return {"ok": False, "err": "not allowed", "path": (path if 'path' in locals() else None)}

                # VSP_P0_STRIP_REPORTS_GATE_IN_RUN_FILE_ALLOW_V2
                # normalize: accept reports/run_gate*.json via existing basename allowlist
                try:
                    _r = (rel or '').lstrip('/').replace('\\','/')
                except Exception:
                    _r = ''
                if _r in ('reports/run_gate_summary.json','reports/run_gate.json'):
                    rel = _r.split('/',1)[1]
            except Exception:
                path = ""
            if path.startswith("/api/"):
                payload = {"ok": False, "error": "HTTP_404_NOT_FOUND", "path": path, "ts": int(__import__("time").time())}
                return (jsonify(payload) if jsonify else ("Not Found", 404)), 404
            # keep existing behavior for non-api (simple)
            return ("Not Found", 404)
    except Exception as _e404:
        pass

    # --- add missing routes only (avoid duplicates) ---
    try:
        rules = {r.rule for r in _vsp_app.url_map.iter_rules()}
    except Exception:
        rules = set()

    def _add(rule, endpoint, view_func, methods):
        if rule in rules:
            return
        _vsp_app.add_url_rule(rule, endpoint=endpoint, view_func=view_func, methods=methods)

    try:
        from tools import vsp_tabs3_api_impl_v1 as _impl
    except Exception:
        _impl = None

    if _impl and request and jsonify:
        def _get_int(name, default):
            try:
                return int(request.args.get(name, default))
            except Exception:
                return default

        def _runs_v2():
            limit = _get_int("limit", 50)
            return jsonify(_impl.list_runs(limit=limit))

        def _findings_v2():
            rid = request.args.get("rid") or None
            limit = _get_int("limit", 50)
            offset = _get_int("offset", 0)
            q = request.args.get("q","")
            tool = request.args.get("tool","")
            severity = request.args.get("severity","ALL")
            return jsonify(_impl.findings_query(rid=rid, limit=limit, offset=offset, q=q, tool=tool, severity=severity))

        def _settings_v2():
            if request.method == "POST":
                obj = request.get_json(silent=True) or {}
                return jsonify(_impl.settings_save(obj))
            return jsonify(_impl.settings_get())

        def _rules_v2():
            if request.method == "POST":
                obj = request.get_json(silent=True) or {}
                return jsonify(_impl.rules_save(obj))
            return jsonify(_impl.rules_get())

        def _rules_apply_v2():
            obj = request.get_json(silent=True) or {}
            rid = obj.get("rid") or request.args.get("rid") or ""
            return jsonify(_impl.rules_apply_to_rid(str(rid)))

        _add("/api/ui/runs_v2", "vsp_ui_runs_v2", _runs_v2, ["GET"])
        _add("/api/ui/findings_v2", "vsp_ui_findings_v2", _findings_v2, ["GET"])
        _add("/api/ui/settings_v2", "vsp_ui_settings_v2", _settings_v2, ["GET","POST"])
        _add("/api/ui/rule_overrides_v2", "vsp_ui_rule_overrides_v2", _rules_v2, ["GET","POST"])
        _add("/api/ui/rule_overrides_apply_v2", "vsp_ui_rule_overrides_apply_v2", _rules_apply_v2, ["POST"])
# ============================================================


# ============================================================
# VSP_P1_APIUI_WSGI_SHIM_V1
# WSGI-level /api/ui/* handler (robust even if Flask routes can't be added)
# Endpoints:
#  - GET  /api/ui/runs_v2?limit=...
#  - GET  /api/ui/findings_v2?rid=&limit=&offset=&q=&tool=&severity=
#  - GET  /api/ui/settings_v2
#  - POST /api/ui/settings_v2   (json body)
#  - GET  /api/ui/rule_overrides_v2
#  - POST /api/ui/rule_overrides_v2 (json body)
#  - POST /api/ui/rule_overrides_apply_v2 (json body {rid})
# ============================================================
def _vsp__json_bytes(obj):
    import json
    return json.dumps(obj, ensure_ascii=False).encode("utf-8")

def _vsp__read_body(environ):
    try:
        n = int(environ.get("CONTENT_LENGTH") or "0")
    except Exception:
        n = 0
    if n <= 0:
        return b""
    try:
        return environ["wsgi.input"].read(n)  # type: ignore
    except Exception:
        return b""

def _vsp__parse_qs(environ):
    try:
        from urllib.parse import parse_qs
        return parse_qs(environ.get("QUERY_STRING","") or "")
    except Exception:
        return {}

def _vsp__qs_get(qs, k, default=""):
    v = qs.get(k)
    if not v:
        return default
    return v[0] if isinstance(v, list) else str(v)

def _vsp__qs_int(qs, k, default):
    try:
        return int(_vsp__qs_get(qs, k, str(default)))
    except Exception:
        return default

def _vsp__apiui_handle(environ):
    import json, time
    path = environ.get("PATH_INFO","") or ""
    method = (environ.get("REQUEST_METHOD","GET") or "GET").upper()
    try:
        from tools import vsp_tabs3_api_impl_v1 as _impl
    except Exception as e:
        return 500, {"ok": False, "error": "IMPL_IMPORT_FAILED", "detail": str(e), "path": path, "ts": int(time.time())}

    qs = _vsp__parse_qs(environ)

    if path == "/api/ui/runs_v2":
        if method != "GET":
            return 405, {"ok": False, "error": "METHOD_NOT_ALLOWED", "path": path, "ts": int(time.time())}
        limit = _vsp__qs_int(qs, "limit", 50)
        return 200, _impl.list_runs(limit=limit)

    if path == "/api/ui/findings_v2":
        if method != "GET":
            return 405, {"ok": False, "error": "METHOD_NOT_ALLOWED", "path": path, "ts": int(time.time())}
        rid = _vsp__qs_get(qs, "rid", "") or None
        limit = _vsp__qs_int(qs, "limit", 50)
        offset = _vsp__qs_int(qs, "offset", 0)
        q = _vsp__qs_get(qs, "q", "")
        tool = _vsp__qs_get(qs, "tool", "")
        severity = _vsp__qs_get(qs, "severity", "ALL")
        return 200, _impl.findings_query(rid=rid, limit=limit, offset=offset, q=q, tool=tool, severity=severity)

    if path == "/api/ui/settings_v2":
        if method == "GET":
            return 200, _impl.settings_get()
        if method == "POST":
            raw = _vsp__read_body(environ)
            try:
                obj = json.loads(raw.decode("utf-8","replace") or "{}")
            except Exception:
                obj = {}
            return 200, _impl.settings_save(obj)
        return 405, {"ok": False, "error": "METHOD_NOT_ALLOWED", "path": path, "ts": int(time.time())}

    if path == "/api/ui/rule_overrides_v2":
        if method == "GET":
            return 200, _impl.rules_get()
        if method == "POST":
            raw = _vsp__read_body(environ)
            try:
                obj = json.loads(raw.decode("utf-8","replace") or "{}")
            except Exception:
                obj = {}
            return 200, _impl.rules_save(obj)
        return 405, {"ok": False, "error": "METHOD_NOT_ALLOWED", "path": path, "ts": int(time.time())}

    if path == "/api/ui/rule_overrides_apply_v2":
        if method != "POST":
            return 405, {"ok": False, "error": "METHOD_NOT_ALLOWED", "path": path, "ts": int(time.time())}
        raw = _vsp__read_body(environ)
        try:
            obj = json.loads(raw.decode("utf-8","replace") or "{}")
        except Exception:
            obj = {}
        rid = str(obj.get("rid") or "")
        return 200, _impl.rules_apply_to_rid(rid)

    return 404, {"ok": False, "error": "HTTP_404_NOT_FOUND", "path": path, "ts": int(time.time())}

def _vsp__wrap_wsgi(orig_app):
    def _shim(environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if path.startswith("/api/ui/"):
            status, payload = _vsp__apiui_handle(environ)
            body = _vsp__json_bytes(payload)
            hdrs = [
                ("Content-Type","application/json; charset=utf-8"),
                ("Cache-Control","no-store"),
                ("Content-Length", str(len(body))),
            ]
            start_response(f"{status} OK" if status == 200 else f"{status} ERROR", hdrs)
            return [body]
        return orig_app(environ, start_response)
    return _shim

# Try wrap `application` first, else wrap `app.wsgi_app`
try:
    application  # noqa
    application = _vsp__wrap_wsgi(application)  # type: ignore
except Exception:
    try:
        app.wsgi_app = _vsp__wrap_wsgi(app.wsgi_app)  # type: ignore
    except Exception:
        pass
# ============================================================


# === VSP_TABS3_SAVE_APPLY_P1_V1 ===
# Add POST APIs for Settings/Rule Overrides (Save + Apply) with safe JSON parsing.
try:
    import json as _json
    from pathlib import Path as _Path
except Exception:
    _json = None
    _Path = None

def _vsp__json_response(payload, code=200):
    try:
        resp = make_response(_json.dumps(payload, ensure_ascii=False), code)
        resp.headers["Content-Type"] = "application/json; charset=utf-8"
        resp.headers["Cache-Control"] = "no-store"
        return resp
    except Exception:
        resp = make_response(str(payload), code)
        resp.headers["Content-Type"] = "text/plain; charset=utf-8"
        resp.headers["Cache-Control"] = "no-store"
        return resp

def _vsp__read_json_body():
    # flask request.get_json can fail if content-type isn't correct; handle raw body too.
    try:
        data = request.get_json(silent=True)
        if isinstance(data, dict):
            return data, None
    except Exception:
        pass
    try:
        raw = request.data.decode("utf-8", errors="replace") if getattr(request, "data", None) else ""
        raw = raw.strip()
        if not raw:
            return {}, None
        return _json.loads(raw), None
    except Exception as e:
        return None, f"bad_json: {e}"

_SETTINGS_PATH = _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/vsp_settings_v2/settings.json")
_RULES_PATH    = _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/rule_overrides_v2/rules.json")
_APPLIED_DIR   = _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/rule_overrides_v2/applied")

def _vsp__atomic_write_json(path: "_Path", obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp_{int(time.time())}")
    tmp.write_text(_json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)

@app.route("/api/ui/settings_save_v2", methods=["POST"])
def vsp_api_ui_settings_save_v2():
    if _json is None:
        return _vsp__json_response({"ok": False, "error": "json_unavailable", "ts": int(time.time())}, 500)
    body, err = _vsp__read_json_body()
    if err:
        return _vsp__json_response({"ok": False, "error": err, "ts": int(time.time())}, 400)
    if body is None:
        return _vsp__json_response({"ok": False, "error": "bad_body", "ts": int(time.time())}, 400)
    # accept either {"settings": {...}} or raw {...}
    settings = body.get("settings") if isinstance(body, dict) else None
    if settings is None and isinstance(body, dict):
        settings = body
    if not isinstance(settings, dict):
        return _vsp__json_response({"ok": False, "error": "settings_must_be_object", "ts": int(time.time())}, 400)
    _vsp__atomic_write_json(_SETTINGS_PATH, settings)
    return _vsp__json_response({"ok": True, "path": str(_SETTINGS_PATH), "settings": settings, "ts": int(time.time())})

@app.route("/api/ui/rule_overrides_save_v2", methods=["POST"])
def vsp_api_ui_rule_overrides_save_v2():
    if _json is None:
        return _vsp__json_response({"ok": False, "error": "json_unavailable", "ts": int(time.time())}, 500)
    body, err = _vsp__read_json_body()
    if err:
        return _vsp__json_response({"ok": False, "error": err, "ts": int(time.time())}, 400)
    if body is None:
        return _vsp__json_response({"ok": False, "error": "bad_body", "ts": int(time.time())}, 400)
    data = body.get("data") if isinstance(body, dict) else None
    if data is None and isinstance(body, dict):
        data = body
    if not isinstance(data, dict):
        return _vsp__json_response({"ok": False, "error": "data_must_be_object", "ts": int(time.time())}, 400)
    if "rules" not in data:
        data["rules"] = []
    if not isinstance(data.get("rules"), list):
        return _vsp__json_response({"ok": False, "error": "rules_must_be_array", "ts": int(time.time())}, 400)
    _vsp__atomic_write_json(_RULES_PATH, data)
    return _vsp__json_response({"ok": True, "path": str(_RULES_PATH), "data": data, "ts": int(time.time())})

@app.route("/api/ui/rule_overrides_apply_v2", methods=["POST"])
def vsp_api_ui_rule_overrides_apply_v2():
    if _json is None:
        return _vsp__json_response({"ok": False, "error": "json_unavailable", "ts": int(time.time())}, 500)
    rid = (request.args.get("rid") or "").strip()
    if not rid:
        return _vsp__json_response({"ok": False, "error": "missing_rid", "ts": int(time.time())}, 400)

    # optional body can override rules to apply; else use current rules file
    body, err = _vsp__read_json_body()
    if err:
        return _vsp__json_response({"ok": False, "error": err, "ts": int(time.time())}, 400)

    applied = None
    try:
        if isinstance(body, dict) and body:
            applied = body.get("data") or body
        if applied is None:
            if _RULES_PATH.exists():
                applied = _json.loads(_RULES_PATH.read_text(encoding="utf-8", errors="replace"))
            else:
                applied = {"rules": []}
    except Exception:
        applied = {"rules": []}

    _APPLIED_DIR.mkdir(parents=True, exist_ok=True)
    out = _APPLIED_DIR / f"{rid}.json"
    payload = {
        "rid": rid,
        "applied_at": int(time.time()),
        "source_rules_path": str(_RULES_PATH),
        "applied_rules_path": str(out),
        "data": applied if isinstance(applied, dict) else {"rules": []},
    }
    _vsp__atomic_write_json(out, payload)
    return _vsp__json_response({"ok": True, **payload, "ts": int(time.time())})
# === /VSP_TABS3_SAVE_APPLY_P1_V1 ===



# --- VSP_APIUI_POST_WRAPPER_P1_V2 ---
try:
    import json as __json, os as __os, time as __time
except Exception:
    __json = None
    __os = None
    __time = None

def __vsp__json(obj, code=200):
    try:
        body = (__json.dumps(obj, ensure_ascii=False, separators=(",",":")) if __json else str(obj)).encode("utf-8")
    except Exception:
        body = (str(obj)).encode("utf-8")
    status = f"{code} OK" if code < 400 else f"{code} ERROR"
    headers = [
        ("Content-Type", "application/json; charset=utf-8"),
        ("Cache-Control", "no-store"),
        ("Content-Length", str(len(body))),
    ]
    start_response(status, headers)
    return [body]

def __vsp__read_body(environ):
    try:
        cl = int(environ.get("CONTENT_LENGTH") or "0")
    except Exception:
        cl = 0
    if cl <= 0:
        return b""
    w = environ.get("wsgi.input")
    if not w:
        return b""
    try:
        return w.read(cl) or b""
    except Exception:
        return b""

def __vsp__read_json(environ):
    raw = __vsp__read_body(environ)
    if not raw:
        return {}
    try:
        return __json.loads(raw.decode("utf-8", "replace")) if __json else {"_raw": raw.decode("utf-8","replace")}
    except Exception:
        return {"_raw": raw.decode("utf-8","replace")}

def __vsp__save_json(path, data):
    __os.makedirs(__os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        __json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
    __os.replace(tmp, path)

def __vsp__wrap_post_only(orig):
    def _wsgi(environ, start_response):
        try:
            path = (environ.get("PATH_INFO") or "")
            method = (environ.get("REQUEST_METHOD") or "GET").upper()
            if method != "POST" or not path.startswith("/api/ui/"):
                return orig(environ, start_response)

            # POST /api/ui/settings_v2  body: {settings:{...}} or {...}
            if path == "/api/ui/settings_v2":
                payload = __vsp__read_json(environ)
                settings = payload.get("settings") if isinstance(payload, dict) and "settings" in payload else payload
                if settings is None:
                    settings = {}
                out_path = "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/vsp_settings_v2/settings.json"
                __vsp__save_json(out_path, settings if isinstance(settings, dict) else {"value": settings})
                return __vsp__json(__vsp__runs_enrich_v2({"ok": True, "path": out_path, "settings": settings, "ts": int(__time.time())}))

            # POST /api/ui/rule_overrides_v2 body: {data:{rules:[...]}} or {rules:[...]} or {...}
            if path == "/api/ui/rule_overrides_v2":
                payload = __vsp__read_json(environ)
                if isinstance(payload, dict) and "data" in payload and isinstance(payload["data"], dict):
                    data = payload["data"]
                else:
                    data = payload if isinstance(payload, dict) else {}
                if "rules" not in data and isinstance(payload, dict) and "rules" in payload:
                    data = {"rules": payload.get("rules")}
                if "rules" not in data:
                    data = {"rules": []}
                out_path = "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/rule_overrides_v2/rules.json"
                __vsp__save_json(out_path, data)
                return __vsp__json({"ok": True, "path": out_path, "data": data, "ts": int(__time.time())})

            # POST /api/ui/rule_overrides_apply_v2 body: {rid:"..."} or query ?rid=...
            if path == "/api/ui/rule_overrides_apply_v2":
                payload = __vsp__read_json(environ)
                rid = None
                qs = environ.get("QUERY_STRING") or ""
                for kv in qs.split("&"):
                    if kv.startswith("rid="):
                        rid = kv.split("=", 1)[1]
                        break
                if not rid and isinstance(payload, dict):
                    rid = payload.get("rid") or payload.get("RID") or payload.get("run_id")
                if not rid:
                    return __vsp__json({"ok": False, "error": "missing_rid", "ts": int(__time.time())}, 400)
                out_path = f"/home/test/Data/SECURITY_BUNDLE/ui/out_ci/rule_overrides_v2/applied/{rid}.json"
                __vsp__save_json(out_path, {"rid": rid, "applied_at": int(__time.time()), "payload": payload})
                return __vsp__json({"ok": True, "rid": rid, "path": out_path, "ts": int(__time.time())})

            return __vsp__json({"ok": False, "error": "not_found", "path": path, "ts": int(__time.time())}, 404)

        except Exception as e:
            return __vsp__json({"ok": False, "error": "exception", "message": str(e), "ts": int(__time.time())}, 500)
    setattr(_wsgi, "__vsp_postwrap_v2", True)
    return _wsgi

# install wrapper (wrap Flask app.wsgi_app OR global application)
try:
    if "app" in globals() and hasattr(globals()["app"], "wsgi_app"):
        _orig = globals()["app"].wsgi_app
        if not getattr(_orig, "__vsp_postwrap_v2", False):
            globals()["app"].wsgi_app = __vsp__wrap_post_only(_orig)
    elif "application" in globals() and callable(globals()["application"]):
        _orig = globals()["application"]
        if not getattr(_orig, "__vsp_postwrap_v2", False):
            globals()["application"] = __vsp__wrap_post_only(_orig)
except Exception:
    pass
# --- END VSP_APIUI_POST_WRAPPER_P1_V2 ---


# --- VSP_APIUI_ALIAS_COMPAT_P1_V2 ---
# Legacy endpoint compat for older JS/bundles calling /api/ui/runs (no _v2), etc.
try:
    __vsp_apiui_alias_prev = app.wsgi_app  # type: ignore[name-defined]
    def __vsp_apiui_alias_wrap(environ, start_response):
        try:
            path = (environ or {}).get("PATH_INFO", "") or ""
            alias = {
                "/api/ui/runs": "/api/ui/runs_v2",
                "/api/ui/findings": "/api/ui/findings_v2",
                "/api/ui/settings": "/api/ui/settings_v2",
                "/api/ui/rule_overrides": "/api/ui/rule_overrides_v2",
                "/api/ui/rule_overrides_apply": "/api/ui/rule_overrides_apply_v2",
            }
            if path in alias:
                environ["PATH_INFO"] = alias[path]
        except Exception:
            pass
        return __vsp_apiui_alias_prev(environ, start_response)
    app.wsgi_app = __vsp_apiui_alias_wrap  # type: ignore[name-defined]
except Exception:
    pass
# --- /VSP_APIUI_ALIAS_COMPAT_P1_V2 ---



# --- VSP_APIUI_LEGACY_REDIRECT_P1_V1 ---
# Guarantee backward-compat endpoints exist (no 404) by redirecting to *_v2 with 307 (keeps method/body).
try:
    from flask import request as __vsp_req, redirect as __vsp_redirect

    def __vsp_qs():
        try:
            q = (__vsp_req.query_string or b"").decode("utf-8", "ignore")
            return ("?" + q) if q else ""
        except Exception:
            return ""

    def __vsp_r307(path: str):
        return __vsp_redirect(path, code=307)

    # GET legacy -> v2
    @app.route("/api/ui/runs", methods=["GET"])  # type: ignore[name-defined]
    def __vsp_legacy_runs():
        return __vsp_r307("/api/ui/runs_v2" + __vsp_qs())

    @app.route("/api/ui/findings", methods=["GET"])  # type: ignore[name-defined]
    def __vsp_legacy_findings():
        return __vsp_r307("/api/ui/findings_v2" + __vsp_qs())

    @app.route("/api/ui/settings", methods=["GET"])  # type: ignore[name-defined]
    def __vsp_legacy_settings():
        return __vsp_r307("/api/ui/settings_v2" + __vsp_qs())

    @app.route("/api/ui/rule_overrides", methods=["GET"])  # type: ignore[name-defined]
    def __vsp_legacy_rule_overrides():
        return __vsp_r307("/api/ui/rule_overrides_v2" + __vsp_qs())

    # POST legacy -> v2 (giữ body)
    @app.route("/api/ui/settings_save", methods=["POST"])  # type: ignore[name-defined]
    def __vsp_legacy_settings_save():
        return __vsp_r307("/api/ui/settings_save_v2")

    @app.route("/api/ui/rule_overrides_save", methods=["POST"])  # type: ignore[name-defined]
    def __vsp_legacy_rule_overrides_save():
        return __vsp_r307("/api/ui/rule_overrides_save_v2")

    @app.route("/api/ui/rule_overrides_apply", methods=["POST"])  # type: ignore[name-defined]
    def __vsp_legacy_rule_overrides_apply():
        return __vsp_r307("/api/ui/rule_overrides_apply_v2")

except Exception:
    pass
# --- /VSP_APIUI_LEGACY_REDIRECT_P1_V1 ---



# VSP_APIUI_LEGACY_ALIAS_WRAPPER_P1_V1
try:
    import time as __time
    if not globals().get("__vsp_apiui_legacy_alias_installed", False):
        __vsp_apiui_legacy_alias_installed = True

        __VSP_APIUI_ALIAS_MAP = {
            "/api/ui/runs": "/api/ui/runs_v2",
            "/api/ui/findings": "/api/ui/findings_v2",
            "/api/ui/settings": "/api/ui/settings_v2",
            "/api/ui/rule_overrides": "/api/ui/rule_overrides_v2",
            # POST aliases (just in case)
            "/api/ui/settings_save": "/api/ui/settings_save_v2",
            "/api/ui/rule_overrides_save": "/api/ui/rule_overrides_save_v2",
            "/api/ui/rules_apply": "/api/ui/rules_apply_v2",
        }

        def __vsp_apiui_legacy_alias_wrapper(app):
            def _w(environ, start_response):
                try:
                    p = environ.get("PATH_INFO", "") or ""
                    newp = __VSP_APIUI_ALIAS_MAP.get(p)
                    if newp:
                        env2 = dict(environ)
                        env2["PATH_INFO"] = newp
                        return app(env2, start_response)
                except Exception:
                    pass
                return app(environ, start_response)
            return _w

        # gunicorn usually uses "application"
        if "application" in globals():
            application = __vsp_apiui_legacy_alias_wrapper(application)
except Exception:
    pass
# /VSP_APIUI_LEGACY_ALIAS_WRAPPER_P1_V1


# ==== VSP_APIUI_RUNS_KPI_PAGINATION_P1_V1 ====
try:
    import os as __os, json as __json, time as __time
    from urllib.parse import parse_qs as __parse_qs
except Exception:
    pass

def __apiui_qs(environ):
    try:
        return __parse_qs(environ.get("QUERY_STRING",""), keep_blank_values=True)
    except Exception:
        return {}

def __apiui_int(qs, k, default):
    try:
        v = (qs.get(k,[None])[0])
        if v is None or v == "": return default
        return int(v)
    except Exception:
        return default

def __apiui_read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return __json.load(f)
    except Exception:
        return None

def __apiui_pick_overall(run_dir):
    # prefer run_gate_summary.json then run_gate.json
    for fn in ("run_gate_summary.json", "run_gate.json"):
        j = __apiui_read_json(__os.path.join(run_dir, fn))
        if not isinstance(j, dict): 
            continue
        for k in ("overall", "overall_status", "overall_status_final"):
            v = j.get(k)
            if isinstance(v, str) and v.strip():
                return v.strip()
    return "UNKNOWN"

def __apiui_list_runs():
    out_root = "/home/test/Data/SECURITY_BUNDLE/out"
    try:
        names = []
        for name in __os.listdir(out_root):
            if name.startswith("RUN_"):
                run_dir = __os.path.join(out_root, name)
                try:
                    st = __os.stat(run_dir)
                    names.append((st.st_mtime, name, run_dir))
                except Exception:
                    names.append((0, name, run_dir))
        names.sort(key=lambda t: t[0], reverse=True)
        return names
    except Exception:
        return []

def __apiui_runs_page(environ):
    qs = __apiui_qs(environ)
    limit  = __apiui_int(qs, "limit", 20)
    offset = __apiui_int(qs, "offset", 0)
    limit = max(1, min(limit))
    offset = max(0, offset)

    runs = __apiui_list_runs()
    total = len(runs)
    sl = runs[offset:offset+limit]

    items = []
    for mtime, rid, run_dir in sl:
        items.append({
            "rid": rid,
            "run_dir": run_dir,
            "mtime": int(mtime or 0),
            "overall": __apiui_pick_overall(run_dir),
        })

    return {
        "ok": True,
        "items": items,
        "limit": limit,
        "offset": offset,
        "total": total,
        "has_more": (offset + limit) < total,
        "ts": int(__time.time()),
    }

def __apiui_runs_kpi():
    runs = __apiui_list_runs()
    total = len(runs)
    sample = runs[:200]  # cap for speed
    c = {"GREEN":0, "AMBER":0, "RED":0, "UNKNOWN":0}
    last = None
    for mtime, rid, run_dir in sample:
        ov = __apiui_pick_overall(run_dir).upper()
        if ov not in c:
            ov = "UNKNOWN"
        c[ov] += 1
        if last is None:
            last = {"rid": rid, "mtime": int(mtime or 0), "overall": ov}
    return {
        "ok": True,
        "kpi": {
            "total_runs": total,
            "sampled": len(sample),
            "by_overall": c,
            "latest": last or {"rid":"", "mtime":0, "overall":"UNKNOWN"},
        },
        "ts": int(__time.time()),
    }

# Patch into existing WSGI shim dispatcher:
# We add a tiny wrapper at bottom that intercepts paths we want.
def __apiui_extra_dispatch(app):
    def _wsgi(environ, start_response):
        try:
            path = environ.get("PATH_INFO","")
            if path == "/api/ui/runs_page_v1":
                return __wsgi_json(__apiui_runs_page(environ), 200)(environ, start_response)
            if path == "/api/ui/runs_kpi_v1":
                return __wsgi_json(__apiui_runs_kpi(), 200)(environ, start_response)
        except Exception as e:
            try:
                return __wsgi_json({"ok": False, "error": "apiui_extra_dispatch", "detail": str(e), "ts": int(__time.time())}, 200)(environ, start_response)
            except Exception:
                pass
        return app(environ, start_response)
    return _wsgi
# ==== /VSP_APIUI_RUNS_KPI_PAGINATION_P1_V1 ====


try:
    application = __apiui_extra_dispatch(application)
except Exception:
    try:
        app = __apiui_extra_dispatch(app)
    except Exception:
        pass


# ===================== VSP_APIUI_RUNS_KPI_PAGINATION_COMPAT_P1_V2 =====================
# Super-compat wrapper: add KPI + pagination endpoints for Runs & Reports
try:
    import os as __os, json as __json, time as __time
    import urllib.parse as __urlparse
    import re as __re

    def __vsp__json(obj, code=200):
        body = (__json.dumps(obj, ensure_ascii=False)).encode("utf-8")
        hdrs = [
            ("Content-Type","application/json; charset=utf-8"),
            ("Cache-Control","no-store"),
            ("Content-Length", str(len(body))),
        ]
        start_response(f"{code} OK" if code==200 else f"{code} ERROR", hdrs)
        return [body]

    def __vsp__qs(environ):
        return __urlparse.parse_qs(environ.get("QUERY_STRING",""), keep_blank_values=True)

    def __vsp__get1(qs, k, default=None):
        v = qs.get(k)
        if not v: return default
        return v[0]

    def __vsp__int(x, d):
        try: return int(x)
        except Exception: return d

    def __vsp__safe_read_json(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return __json.load(f)
        except Exception:
            return None

    def __vsp__guess_overall(run_dir):
        # prefer JSON gates if exist
        cand = [
            "run_gate_summary.json",
            "reports/run_gate_summary.json",
            "run_gate.json",
            "verdict_4t.json",
            "gate.json",
            "SUMMARY.json",
            # VSP_P0_ALLOW_REPORTS_GATE_LISTONLY_V5
            "reports/run_gate_summary.json",
            "reports/run_gate.json",
        ]
        for fn in cand:
            fp = __os.path.join(run_dir, fn)
            if __os.path.isfile(fp):
                j = __vsp__safe_read_json(fp)
                if isinstance(j, dict):
                    for k in ("overall_status","overall","status","verdict"):
                        v = j.get(k)
                        if isinstance(v, str) and v.strip():
                            return v.strip().upper()
        # fallback SUMMARY.txt
        fp = __os.path.join(run_dir, "SUMMARY.txt")
        if __os.path.isfile(fp):
            try:
                t = open(fp, "r", encoding="utf-8", errors="ignore").read()
                m = __re.search(r"\boverall\b\s*[:=]\s*([A-Za-z]+)", t, flags=__re.I)
                if m: return m.group(1).upper()
            except Exception:
                pass
        return "UNKNOWN"

    def __vsp__norm_overall(x):
        x = (x or "").upper()
        if x in ("GREEN","PASS","OK","SUCCESS"): return "GREEN"
        if x in ("AMBER","WARN","WARNING","DEGRADED"): return "AMBER"
        if x in ("RED","FAIL","FAILED","ERROR","BLOCK"): return "RED"
        if x in ("UNKNOWN","NA","N/A","NONE",""): return "UNKNOWN"
        # keep other (but bucket as UNKNOWN)
        return "UNKNOWN"

    def __vsp__list_runs(out_root, max_scan=2000):
        items = []
        try:
            if not __os.path.isdir(out_root):
                return items
            for name in __os.listdir(out_root):
                if not name.startswith("RUN_"):
                    continue
                run_dir = __os.path.join(out_root, name)
                if not __os.path.isdir(run_dir):
                    continue
                try:
                    mtime = int(__os.path.getmtime(run_dir))
                except Exception:
                    mtime = 0
                items.append((mtime, name, run_dir))
        except Exception:
            return []
        items.sort(key=lambda x: (x[0], x[1]), reverse=True)
        if len(items) > max_scan:
            items = items[:max_scan]
        return items

    def __vsp__runs_page_payload(out_root, limit, offset):
        all_items = __vsp__list_runs(out_root)
        total = len(all_items)
        limit = max(1, min(limit))
        offset = max(0, min(offset, total))
        page = all_items[offset:offset+limit]
        out = []
        for mtime, rid, run_dir in page:
            o = __vsp__norm_overall(__vsp__guess_overall(run_dir))
            out.append({"rid": rid, "run_dir": run_dir, "mtime": mtime, "overall": o})
        page_total = (total + limit - 1)//limit if total>0 else 1
        page_no = (offset//limit) + 1 if total>0 else 1
        return {
            "ok": True,
            "items": out,
            "limit": limit,
            "offset": offset,
            "total": total,
            "page_no": page_no,
            "page_total": page_total,
            "next_offset": (offset+limit if offset+limit < total else None),
            "prev_offset": (offset-limit if offset-limit >= 0 else None),
            "ts": int(__time.time()),
        }

    def __vsp__runs_kpi_payload(out_root, max_scan=2000):
        all_items = __vsp__list_runs(out_root, max_scan=max_scan)
        buckets = {"GREEN":0,"AMBER":0,"RED":0,"UNKNOWN":0}
        latest = all_items[0][1] if all_items else None
        for mtime, rid, run_dir in all_items:
            o = __vsp__norm_overall(__vsp__guess_overall(run_dir))
            buckets[o] = buckets.get(o,0) + 1
        return {
            "ok": True,
            "total_runs": len(all_items),
            "by_overall": buckets,
            "latest_rid": latest,
            "scan_cap": max_scan,
            "ts": int(__time.time()),
        }

    def __vsp__wrap_wsgi(inner):
        OUT_ROOT = "/home/test/Data/SECURITY_BUNDLE/out"
        def _app(environ, start_response):
            path = environ.get("PATH_INFO","") or ""
            qs = __vsp__qs(environ)

            # --- KPI endpoints (accept multiple names) ---
            if path in ("/api/ui/runs_kpi", "/api/ui/runs_kpi_v1", "/api/ui/runs_kpi_v2", "/api/ui/runs_kpi_v3"):
                cap = __vsp__int(__vsp__get1(qs,"cap", "2000"), 2000)
                return __vsp__json(__vsp__runs_kpi_payload(OUT_ROOT, max_scan=cap))

            # --- Pagination endpoints (accept multiple names) ---
            if path in ("/api/ui/runs_page", "/api/ui/runs_page_v1", "/api/ui/runs_page_v2", "/api/ui/runs_paged_v1"):
                limit = __vsp__int(__vsp__get1(qs,"limit","20"), 20)
                offset = __vsp__int(__vsp__get1(qs,"offset","0"), 0)
                return __vsp__json(__vsp__runs_page_payload(OUT_ROOT, limit, offset))

            # --- Upgrade runs_v2 to support offset (compat with UI pagination) ---
            if path == "/api/ui/runs_v2":
                limit = __vsp__int(__vsp__get1(qs,"limit","200"), 200)
                offset = __vsp__int(__vsp__get1(qs,"offset","0"), 0)
                return __vsp__json(__vsp__runs_page_payload(OUT_ROOT, limit, offset))

            return inner(environ, start_response)
        return _app

    __inner = globals().get("application") or globals().get("app")
    if __inner:
        __wrapped = __vsp__wrap_wsgi(__inner)
        globals()["application"] = __wrapped
        globals()["app"] = __wrapped
except Exception:
    pass
# =================== END VSP_APIUI_RUNS_KPI_PAGINATION_COMPAT_P1_V2 ===================


# ===================== VSP_TABS3_REALDATA_ENRICH_P1_V1 =====================
try:
    import os as __os, json as __json, time as __time
    import urllib.parse as __urlparse
    import re as __re

    __VSP_REALDATA_CACHE = {"ts": 0, "runs": None}

    def __vsp_json(start_response, obj, code=200):
        body = (__json.dumps(obj, ensure_ascii=False)).encode("utf-8")
        hdrs = [
            ("Content-Type","application/json; charset=utf-8"),
            ("Cache-Control","no-store"),
            ("Content-Length", str(len(body))),
        ]
        start_response(f"{code} OK" if code==200 else f"{code} ERROR", hdrs)
        return [body]

    def __vsp_qs(environ):
        return __urlparse.parse_qs(environ.get("QUERY_STRING",""), keep_blank_values=True)

    def __vsp_get1(qs, k, default=None):
        v = qs.get(k)
        if not v: return default
        return v[0]

    def __vsp_int(x, d):
        try: return int(x)
        except Exception: return d

    def __vsp_read_json(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return __json.load(f)
        except Exception:
            return None

    def __vsp_has_any(run_dir, rels):
        for r in rels:
            if __os.path.isfile(__os.path.join(run_dir, r)):
                return True
        return False

    def __vsp_findings_path(run_dir):
        cand = [
            "findings_unified.json",
            "reports/findings_unified.json",
            "reports/findings_unified_v1.json",
        ]
        for r in cand:
            fp = __os.path.join(run_dir, r)
            if __os.path.isfile(fp):
                return fp
        # note: csv/sarif exist but we don't parse here
        return None

    def __vsp_gate_path(run_dir):
        cand = [
            "run_gate_summary.json",
            "run_gate.json",
            "reports/run_gate_summary.json",
            "reports/run_gate.json",
        ]
        for r in cand:
            fp = __os.path.join(run_dir, r)
            if __os.path.isfile(fp):
                return fp
        return None

    def __vsp_norm_overall(x):
        x = (x or "").strip().upper()
        if x in ("GREEN","PASS","OK","SUCCESS"): return "GREEN"
        if x in ("AMBER","WARN","WARNING","DEGRADED"): return "AMBER"
        if x in ("RED","FAIL","FAILED","ERROR","BLOCK"): return "RED"
        return "UNKNOWN"

    def __vsp_guess_overall(run_dir):
        fp = __vsp_gate_path(run_dir)
        if fp:
            j = __vsp_read_json(fp)
            if isinstance(j, dict):
                for k in ("overall","overall_status","status","verdict","overall_status_final"):
                    v = j.get(k)
                    if isinstance(v, str) and v.strip():
                        return __vsp_norm_overall(v)
        # fallback: SUMMARY.txt
        sp = __os.path.join(run_dir, "SUMMARY.txt")
        if __os.path.isfile(sp):
            try:
                t = open(sp, "r", encoding="utf-8", errors="ignore").read()
                m = __re.search(r"\boverall\b\s*[:=]\s*([A-Za-z]+)", t, flags=__re.I)
                if m:
                    return __vsp_norm_overall(m.group(1))
            except Exception:
                pass
        return "UNKNOWN"

    def __vsp_list_runs(out_root="/home/test/Data/SECURITY_BUNDLE/out", cache_ttl=10):
        now = int(__time.time())
        c = __VSP_REALDATA_CACHE
        if c["runs"] is not None and (now - c["ts"]) <= cache_ttl:
            return c["runs"]

        runs = []
        try:
            if __os.path.isdir(out_root):
                for name in __os.listdir(out_root):
                    if not name.startswith("RUN_"):
                        continue
                    run_dir = __os.path.join(out_root, name)
                    if not __os.path.isdir(run_dir):
                        continue
                    try:
                        mtime = int(__os.path.getmtime(run_dir))
                    except Exception:
                        mtime = 0
                    has_findings = __vsp_findings_path(run_dir) is not None
                    has_gate = __vsp_gate_path(run_dir) is not None
                    overall = __vsp_guess_overall(run_dir)
                    runs.append((mtime, name, run_dir, has_findings, has_gate, overall))
        except Exception:
            runs = []

        runs.sort(key=lambda x: (x[0], x[1]), reverse=True)
        c["ts"] = now
        c["runs"] = runs
        return runs

    def __vsp_runs_page_payload(limit, offset):
        runs = __vsp_list_runs()
        total = len(runs)
        limit = max(1, min(limit, 200))
        offset = max(0, min(offset, total))
        page = runs[offset:offset+limit]
        items = []
        for mtime, rid, run_dir, has_findings, has_gate, overall in page:
            items.append({
                "rid": rid, "run_dir": run_dir, "mtime": mtime,
                "has_findings": bool(has_findings),
                "has_gate": bool(has_gate),
                "overall": overall,
            })
        return {
            "ok": True, "items": items,
            "limit": limit, "offset": offset, "total": total,
            "has_more": (offset + limit) < total,
            "ts": int(__time.time()),
        }

    def __vsp_runs_kpi_payload(cap=2000):
        runs = __vsp_list_runs()
        runs = runs[:max(1, min(int(cap), 5000))]
        b = {"GREEN":0,"AMBER":0,"RED":0,"UNKNOWN":0}
        hf = 0
        hg = 0
        latest = runs[0][1] if runs else ""
        for mtime, rid, run_dir, has_findings, has_gate, overall in runs:
            b[overall] = b.get(overall, 0) + 1
            if has_findings: hf += 1
            if has_gate: hg += 1
        return {
            "ok": True,
            "total_runs": len(runs),
            "latest_rid": latest,
            "by_overall": b,
            "has_findings": hf,
            "has_gate": hg,
            "ts": int(__time.time()),
        }

    def __vsp_extract_items(j):
        if isinstance(j, list):
            return j
        if isinstance(j, dict):
            for k in ("items","findings","results"):
                v = j.get(k)
                if isinstance(v, list):
                    return v
        return []

    def __vsp_norm_sev(x):
        x = (x or "").strip().upper()
        if x in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"):
            return x
        # some tools use ERROR/WARN/NOTE
        if x in ("ERROR","FATAL"): return "HIGH"
        if x in ("WARN","WARNING"): return "MEDIUM"
        if x in ("NOTE","NOTICE"): return "INFO"
        return "INFO"

    def __vsp_findings_payload(rid, limit, offset, q=""):
        runs = __vsp_list_runs()
        chosen = None
        if rid:
            for mtime, r, run_dir, hf, hg, ov in runs:
                if r == rid:
                    chosen = (mtime, r, run_dir, hf, hg, ov)
                    break
        if chosen is None:
            # default: first run that has findings, else first run
            for row in runs:
                if row[3]:
                    chosen = row
                    break
            if chosen is None and runs:
                chosen = runs[0]

        if not chosen:
            return {"ok": True, "rid":"", "run_dir":"", "items":[], "counts": {"TOTAL":0}, "limit":limit, "offset":offset, "total":0,
                    "reason":"NO_RUNS_FOUND", "ts": int(__time.time())}

        mtime, rid2, run_dir, has_findings, has_gate, overall = chosen
        fp = __vsp_findings_path(run_dir)
        if not fp:
            # report reason + common paths
            return {
                "ok": True, "rid": rid2, "run_dir": run_dir,
                "items": [], "counts": {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0,"TOTAL":0},
                "limit": limit, "offset": offset, "total": 0,
                "overall": overall,
                "reason": "NO_findings_unified.json (try run SECURITY_BUNDLE unify/pack_report)",
                "hint_paths": [
                    f"{run_dir}/findings_unified.json",
                    f"{run_dir}/reports/findings_unified.json",
                    f"{run_dir}/reports/findings_unified.csv",
                    f"{run_dir}/reports/findings_unified.sarif",
                ],
                "ts": int(__time.time())
            }

        raw = __vsp_read_json(fp)
        items = __vsp_extract_items(raw)

        # optional search
        q = (q or "").strip().lower()
        if q:
            def hit(it):
                try:
                    s = __json.dumps(it, ensure_ascii=False).lower()
                    return q in s
                except Exception:
                    return False
            items = [x for x in items if hit(x)]

        total = len(items)
        limit = max(1, min(limit, 200))
        offset = max(0, min(offset, total))
        page = items[offset:offset+limit]

        counts = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0,"TOTAL": total}
        for it in items:
            sev = __vsp_norm_sev(it.get("severity_norm") or it.get("severity") or it.get("level") or it.get("impact"))
            counts[sev] = counts.get(sev,0) + 1

        return {
            "ok": True,
            "rid": rid2, "run_dir": run_dir, "overall": overall,
            "items": page, "counts": counts,
            "limit": limit, "offset": offset, "total": total,
            "findings_path": fp,
            "ts": int(__time.time()),
        }

    def __vsp_wrap_wsgi(inner):
        def _app(environ, start_response):
            path = environ.get("PATH_INFO","") or ""
            qs = __vsp_qs(environ)

            # unify endpoints (accept both v1/v2 names)
            if path in ("/api/ui/runs_page_v1", "/api/ui/runs_page", "/api/ui/runs_page_v2"):
                limit = __vsp_int(__vsp_get1(qs,"limit","20"), 20)
                offset = __vsp_int(__vsp_get1(qs,"offset","0"), 0)
                return __vsp_json(start_response, __vsp_runs_page_payload(limit, offset), 200)

            if path in ("/api/ui/runs_kpi_v1", "/api/ui/runs_kpi", "/api/ui/runs_kpi_v2"):
                cap = __vsp_int(__vsp_get1(qs,"cap","2000"), 2000)
                return __vsp_json(start_response, __vsp_runs_kpi_payload(cap), 200)

            # upgrade runs_v2: now supports offset + extras
            if path == "/api/ui/runs_v2":
                limit = __vsp_int(__vsp_get1(qs,"limit","200"), 200)
                offset = __vsp_int(__vsp_get1(qs,"offset","0"), 0)
                return __vsp_json(start_response, __vsp_runs_page_payload(limit, offset), 200)

            # findings: accept rid/limit/offset/q
            if path in ("/api/ui/findings_v2", "/api/ui/findings_v1"):
                rid = __vsp_get1(qs, "rid", "") or ""
                limit = __vsp_int(__vsp_get1(qs,"limit","50"), 50)
                offset = __vsp_int(__vsp_get1(qs,"offset","0"), 0)
                q = __vsp_get1(qs, "q", "") or ""
                return __vsp_json(start_response, __vsp_findings_payload(rid, limit, offset, q=q), 200)

            return inner(environ, start_response)
        return _app

    __inner = globals().get("application") or globals().get("app")
    if __inner:
        __wrapped = __vsp_wrap_wsgi(__inner)
        globals()["application"] = __wrapped
        globals()["app"] = __wrapped
except Exception:
    pass
# =================== END VSP_TABS3_REALDATA_ENRICH_P1_V1 ===================


# ===================== VSP_TABS3_REALDATA_ENRICH_P1_V2 =====================
# Enrich /api/ui/runs_v2 + /api/ui/findings_v2 (real data + reasons)
try:
    import os as __os, json as __json, time as __time
    import urllib.parse as __urlparse
    import re as __re

    def __vsp__json(obj, code=200):
        body = (__json.dumps(obj, ensure_ascii=False)).encode("utf-8")
        hdrs = [
            ("Content-Type","application/json; charset=utf-8"),
            ("Cache-Control","no-store"),
            ("Content-Length", str(len(body))),
        ]
        start_response(f"{code} OK" if code==200 else f"{code} ERROR", hdrs)
        return [body]

    def __vsp__qs(environ):
        return __urlparse.parse_qs(environ.get("QUERY_STRING",""), keep_blank_values=True)

    def __vsp__get1(qs, k, default=None):
        v = qs.get(k)
        if not v: return default
        return v[0]

    def __vsp__int(x, d):
        try: return int(x)
        except Exception: return d

    def __vsp__read_json(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return __json.load(f)
        except Exception:
            return None

    def __vsp__findings_path(run_dir):
        cand = [
            "findings_unified.json",
            "reports/findings_unified.json",
            "reports/findings_unified_v1.json",
        ]
        for r in cand:
            fp = __os.path.join(run_dir, r)
            if __os.path.isfile(fp):
                return fp
        return None

    def __vsp__gate_path(run_dir):
        cand = [
            "run_gate_summary.json",
            "run_gate.json",
            "reports/run_gate_summary.json",
            "reports/run_gate.json",
            "verdict_4t.json",
        ]
        for r in cand:
            fp = __os.path.join(run_dir, r)
            if __os.path.isfile(fp):
                return fp
        return None

    def __vsp__norm_overall(x):
        x = (x or "").strip().upper()
        if x in ("GREEN","PASS","OK","SUCCESS"): return "GREEN"
        if x in ("AMBER","WARN","WARNING","DEGRADED"): return "AMBER"
        if x in ("RED","FAIL","FAILED","ERROR","BLOCK"): return "RED"
        return "UNKNOWN"

    def __vsp__guess_overall(run_dir):
        gp = __vsp__gate_path(run_dir)
        if gp:
            j = __vsp__read_json(gp)
            if isinstance(j, dict):
                for k in ("overall_status","overall","status","verdict","overall_status_final"):
                    v = j.get(k)
                    if isinstance(v, str) and v.strip():
                        return __vsp__norm_overall(v)
        sp = __os.path.join(run_dir, "SUMMARY.txt")
        if __os.path.isfile(sp):
            try:
                t = open(sp, "r", encoding="utf-8", errors="ignore").read()
                m = __re.search(r"\boverall\b\s*[:=]\s*([A-Za-z]+)", t, flags=__re.I)
                if m:
                    return __vsp__norm_overall(m.group(1))
            except Exception:
                pass
        return "UNKNOWN"

    def __vsp__list_runs(out_root="/home/test/Data/SECURITY_BUNDLE/out", cap=2000):
        rows = []
        if not __os.path.isdir(out_root):
            return rows
        for name in __os.listdir(out_root):
            if not name.startswith("RUN_"): 
                continue
            run_dir = __os.path.join(out_root, name)
            if not __os.path.isdir(run_dir):
                continue
            try:
                mtime = int(__os.path.getmtime(run_dir))
            except Exception:
                mtime = 0
            fp = __vsp__findings_path(run_dir)
            has_findings = bool(fp)
            has_gate = bool(__vsp__gate_path(run_dir))
            overall = __vsp__guess_overall(run_dir)
            rows.append((mtime, name, run_dir, has_findings, has_gate, overall, fp or ""))
        rows.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return rows[:max(1, min(int(cap), 5000))]

    def __vsp__runs_payload(limit, offset):
        rows = __vsp__list_runs()
        total = len(rows)
        limit = max(1, min(int(limit)))
        offset = max(0, min(int(offset), total))
        page = rows[offset:offset+limit]
        items = []
        for mtime, rid, run_dir, has_findings, has_gate, overall, fpath in page:
            items.append({
                "rid": rid, "run_dir": run_dir, "mtime": mtime,
                "has_findings": bool(has_findings),
                "has_gate": bool(has_gate),
                "overall": overall,
                "findings_path": fpath if fpath else None,
            })
        return {
            "ok": True,
            "items": items,
            "limit": limit,
            "offset": offset,
            "total": total,
            "has_more": (offset + limit) < total,
            "ts": int(__time.time()),
        }

    def __vsp__extract_items(j):
        if isinstance(j, list):
            return j
        if isinstance(j, dict):
            for k in ("items","findings","results"):
                v = j.get(k)
                if isinstance(v, list):
                    return v
        return []

    def __vsp__norm_sev(x):
        x = (x or "").strip().upper()
        if x in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"):
            return x
        if x in ("ERROR","FATAL"): return "HIGH"
        if x in ("WARN","WARNING"): return "MEDIUM"
        if x in ("NOTE","NOTICE"): return "INFO"
        return "INFO"

    def __vsp__findings_payload(rid, limit, offset, q=""):
        rows = __vsp__list_runs()
        chosen = None
        if rid:
            for row in rows:
                if row[1] == rid:
                    chosen = row
                    break
        if chosen is None:
            for row in rows:
                if row[3]:  # has_findings
                    chosen = row
                    break
        if chosen is None and rows:
            chosen = rows[0]

        if not chosen:
            return {
                "ok": True, "rid":"", "run_dir":"", "items":[],
                "counts":{"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0,"TOTAL":0},
                "limit": limit, "offset": offset, "total": 0,
                "reason":"NO_RUNS_FOUND", "ts": int(__time.time()),
            }

        mtime, rid2, run_dir, has_findings, has_gate, overall, fpath = chosen
        fp = fpath or __vsp__findings_path(run_dir)
        if not fp:
            return {
                "ok": True, "rid": rid2, "run_dir": run_dir, "overall": overall,
                "items": [],
                "counts":{"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0,"TOTAL":0},
                "limit": limit, "offset": offset, "total": 0,
                "reason":"NO_findings_unified.json",
                "hint_paths":[
                    f"{run_dir}/findings_unified.json",
                    f"{run_dir}/reports/findings_unified.json",
                    f"{run_dir}/reports/findings_unified.csv",
                    f"{run_dir}/reports/findings_unified.sarif",
                ],
                "ts": int(__time.time()),
            }

        raw = __vsp__read_json(fp)
        items = __vsp__extract_items(raw)

        q = (q or "").strip().lower()
        if q:
            def hit(it):
                try:
                    return q in __json.dumps(it, ensure_ascii=False).lower()
                except Exception:
                    return False
            items = [it for it in items if hit(it)]

        total = len(items)
        limit = max(1, min(int(limit), 200))
        offset = max(0, min(int(offset), total))
        page = items[offset:offset+limit]

        counts = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0,"TOTAL": total}
        for it in items:
            sev = __vsp__norm_sev(it.get("severity_norm") or it.get("severity") or it.get("level") or it.get("impact"))
            counts[sev] = counts.get(sev,0) + 1

        return {
            "ok": True,
            "rid": rid2, "run_dir": run_dir, "overall": overall,
            "items": page, "counts": counts,
            "limit": limit, "offset": offset, "total": total,
            "findings_path": fp,
            "ts": int(__time.time()),
        }

    def __vsp__wrap_wsgi(inner):
        def _app(environ, start_response):
            path = environ.get("PATH_INFO","") or ""
            qs = __vsp__qs(environ)

            if path == "/api/ui/runs_v2":
                limit = __vsp__int(__vsp__get1(qs, "limit", "200"), 200)
                offset = __vsp__int(__vsp__get1(qs, "offset", "0"), 0)
                return __vsp__json(__vsp__runs_payload(limit, offset))

            if path in ("/api/ui/findings_v2", "/api/ui/findings_v1"):
                rid = __vsp__get1(qs, "rid", "") or ""
                limit = __vsp__int(__vsp__get1(qs, "limit", "50"), 50)
                offset = __vsp__int(__vsp__get1(qs, "offset", "0"), 0)
                q = __vsp__get1(qs, "q", "") or ""
                return __vsp__json(__vsp__findings_payload(rid, limit, offset, q=q))

            return inner(environ, start_response)
        return _app

    __inner = globals().get("application") or globals().get("app")
    if __inner:
        __wrapped = __vsp__wrap_wsgi(__inner)
        globals()["application"] = __wrapped
        globals()["app"] = __wrapped
except Exception:
    pass
# =================== END VSP_TABS3_REALDATA_ENRICH_P1_V2 ===================

# ===================== VSP_APIUI_RUNS_V3_REALDATA_P1_V1 =====================
# 목적:
# - /api/ui/runs_v3: scan out/ runs, compute findings_total + overall, sort "real data" first
# - /api/ui/runs_kpi_v2 + /api/ui/runs_page_v2: KPI + pagination based on runs_v3 scan
try:
    import os as __os
    import json as __json
    import time as __time
    from flask import request as __request
    from flask import Response as __Response
except Exception as __e:
    __os = None; __json = None; __time = None; __request = None; __Response = None

def __vsp__json(payload, status=200):
    # prefer existing helper if present
    try:
        return __wsgi_json(payload, status)
    except Exception:
        if __Response is None:
            return payload
        return __Response(__json.dumps(payload, ensure_ascii=False), status=status, mimetype="application/json")

def __vsp__read_json(fp):
    try:
        with open(fp, "r", encoding="utf-8") as f:
            return __json.load(f)
    except Exception:
        return None

def __vsp__pick_overall(run_dir):
    # try run_gate.json, then run_gate_summary.json (fallback)
    cand = [
        __os.path.join(run_dir, "run_gate.json"),
        __os.path.join(run_dir, "run_gate_summary.json"),
        __os.path.join(run_dir, "SUMMARY.json"),
        # VSP_P0_ALLOW_REPORTS_GATE_LISTONLY_V5
        "reports/run_gate_summary.json",
        "reports/run_gate.json",
    ]
    for fp in cand:
        if __os.path.isfile(fp):
            j = __vsp__read_json(fp)
            if isinstance(j, dict):
                for k in ("overall_status", "overall", "status", "verdict", "final"):
                    v = j.get(k)
                    if isinstance(v, str) and v.strip():
                        return v.strip().upper()
                # sometimes nested
                v = j.get("overall", None)
                if isinstance(v, dict):
                    vv = v.get("status") or v.get("overall_status")
                    if isinstance(vv, str) and vv.strip():
                        return vv.strip().upper()
    return "UNKNOWN"

def __vsp__findings_meta(run_dir):
    fp = __os.path.join(run_dir, "reports", "findings_unified.json")
    if not __os.path.isfile(fp):
        return False, 0, None, None
    j = __vsp__read_json(fp)
    total = 0
    counts = None
    if isinstance(j, dict):
        counts = j.get("counts")
        if isinstance(counts, dict):
            # prefer TOTAL
            t = counts.get("TOTAL")
            if isinstance(t, int):
                total = t
            else:
                # some schemas use total/total_findings
                for k in ("total", "total_findings"):
                    v = counts.get(k)
                    if isinstance(v, int):
                        total = v
                        break
        # also support len(findings)
        if total == 0:
            v = j.get("findings")
            if isinstance(v, list):
                total = len(v)
    elif isinstance(j, list):
        total = len(j)
    return True, int(total or 0), fp, counts

def __vsp__scan_runs(root, cap=5000):
    items = []
    if __os is None:
        return items
    try:
        names = __os.listdir(root)
    except Exception:
        return items
    # only RUN_* folders
    runs = []
    for nm in names:
        if not nm.startswith("RUN_"):
            continue
        rd = __os.path.join(root, nm)
        if __os.path.isdir(rd):
            try:
                mt = int(__os.path.getmtime(rd))
            except Exception:
                mt = 0
            runs.append((mt, nm, rd))
    # newest first (base), then we'll resort with weights
    runs.sort(key=lambda x: x[0], reverse=True)

    for i, (mt, rid, rd) in enumerate(runs):
        if i >= cap:
            break
        has_f, total, fpath, counts = __vsp__findings_meta(rd)
        overall = __vsp__pick_overall(rd)
        items.append({
            "rid": rid,
            "run_dir": rd,
            "mtime": mt,
            "overall": overall,
            "has_findings": bool(has_f),
            "findings_total": int(total),
            "findings_path": fpath,
            "counts": counts if isinstance(counts, dict) else None,
            "has_gate": __os.path.isfile(__os.path.join(rd, "run_gate.json")) or __os.path.isfile(__os.path.join(rd, "run_gate_summary.json")),
        })
    return items

def __vsp__overall_weight(x):
    # higher = worse first (RED > AMBER > GREEN > UNKNOWN)
    o = (x or "").upper()
    if "RED" in o: return 3
    if "AMBER" in o or "YELLOW" in o: return 2
    if "GREEN" in o: return 1
    return 0

def __vsp__sort_realdata(items):
    # prioritize:
    # 1) findings_total desc (real data first)
    # 2) overall weight desc (RED/AMBER before GREEN/UNKNOWN)
    # 3) mtime desc
    items.sort(key=lambda it: (
        int(it.get("findings_total", 0)),
        __vsp__overall_weight(it.get("overall")),
        int(it.get("mtime", 0)),
    ), reverse=True)
    return items

try:
    app  # noqa
    __VSP_OUT_ROOT = "/home/test/Data/SECURITY_BUNDLE/out"

    @app.get("/api/ui/runs_v3")
    def vsp_apiui_runs_v3():
        limit = 200
        offset = 0
        try:
            if __request is not None:
                limit = int(__request.args.get("limit", limit))
                offset = int(__request.args.get("offset", offset))
        except Exception:
            pass
        limit = max(1, min(limit, 2000))
        offset = max(0, offset)

        items = __vsp__scan_runs(__VSP_OUT_ROOT, cap=8000)
        __vsp__sort_realdata(items)

        page = items[offset:offset+limit]
        __vsp__payload = {            "ok": True,
            "items": page,
            "limit": limit,
            "offset": offset,
            "total": len(items),
            "sorted": "findings_total_desc,overall_weight_desc,mtime_desc",
            "ts": int(__time.time()) if __time else 0
        }        # VSP_P1_FIX_OVERALL_RUNS_V3_INLINE_PAYLOAD_V6
        try:
            __items = __vsp__payload.get('items')
            if isinstance(__items, list):
                for __it in __items:
                    if not isinstance(__it, dict):
                        continue
                    __has_gate = bool(__it.get('has_gate'))
                    __overall = str(__it.get('overall') or '').strip().upper()
                    __counts = __it.get('counts')
                    if not isinstance(__counts, dict):
                        __counts = {}

                    __total   = __it.get('findings_total') or __it.get('total') or 0
                    def _i(v, d=0):
                        try: return int(v) if v is not None else d
                        except Exception: return d
                    __c = _i(__counts.get('CRITICAL') or __counts.get('critical'), 0)
                    __h = _i(__counts.get('HIGH') or __counts.get('high'), 0)
                    __m = _i(__counts.get('MEDIUM') or __counts.get('medium'), 0)
                    __l = _i(__counts.get('LOW') or __counts.get('low'), 0)
                    __inf = _i(__counts.get('INFO') or __counts.get('info'), 0)
                    __t = _i(__counts.get('TRACE') or __counts.get('trace'), 0)
                    __tot = _i(__total, 0)
                    if (__c > 0) or (__h > 0):
                        __inferred = 'RED'
                    elif (__m > 0):
                        __inferred = 'AMBER'
                    elif (__tot > 0) or ((__l+__inf+__t) > 0):
                        __inferred = 'GREEN'
                    else:
                        __inferred = 'GREEN'
                    __it['overall_inferred'] = __inferred
                    if __has_gate and __overall and (__overall != 'UNKNOWN'):
                        __it['overall_source'] = 'gate'
                    else:
                        if (not __overall) or (__overall == 'UNKNOWN'):
                            __it['overall'] = __inferred
                        __it['overall_source'] = 'inferred_counts'
        except Exception:
            pass
        return __vsp__json(__vsp__payload)

    @app.get("/api/ui/runs_kpi_v2")
    def vsp_apiui_runs_kpi_v2():
        items = __vsp__scan_runs(__VSP_OUT_ROOT, cap=8000)
        __vsp__sort_realdata(items)
        by = {"GREEN": 0, "AMBER": 0, "RED": 0, "UNKNOWN": 0}
        total_findings = 0
        nonzero_runs = 0
        latest_rid = items[0]["rid"] if items else None
        for it in items:
            o = (it.get("overall") or "UNKNOWN").upper()
            if "RED" in o: by["RED"] += 1
            elif "AMBER" in o or "YELLOW" in o: by["AMBER"] += 1
            elif "GREEN" in o: by["GREEN"] += 1
            else: by["UNKNOWN"] += 1
            ft = int(it.get("findings_total", 0) or 0)
            total_findings += ft
            if ft > 0:
                nonzero_runs += 1
        return __vsp__json({
            "ok": True,
            "total_runs": len(items),
            "nonzero_runs": nonzero_runs,
            "total_findings": total_findings,
            "by_overall": by,
            "latest_rid": latest_rid,
            "ts": int(__time.time()) if __time else 0
        })

    @app.get("/api/ui/runs_page_v2")
    def vsp_apiui_runs_page_v2():
        # same as runs_v3, just explicit pagination endpoint for legacy UI code
        return vsp_apiui_runs_v3()

except Exception as __e:
    pass
# =================== END VSP_APIUI_RUNS_V3_REALDATA_P1_V1 ===================

# --- VSP_P1_OPEN_API_STUB_P0_V1 ---
# Purpose: Runs tab may probe /api/vsp/open*; avoid 404 spam.
# Commercial-safe default: NO server-side opener unless VSP_UI_ALLOW_XDG_OPEN=1 (dev only).
try:
    from flask import request, jsonify
    import os as _os
    from pathlib import Path as _Path
    import subprocess as _subprocess
except Exception:
    request = None
    jsonify = None

def _vsp_try_find_run_dir(_rid: str):
    if not _rid:
        return None
    roots = [
        _os.environ.get("VSP_RUNS_ROOT", ""),
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        str(_Path(__file__).resolve().parent / "out"),
        str(_Path(__file__).resolve().parent.parent / "out"),
        str(_Path(__file__).resolve().parent / "out_ci"),
        str(_Path(__file__).resolve().parent.parent / "out_ci"),
    ]
    for r in roots:
        if not r:
            continue
        base = _Path(r)
        cand = base / _rid
        if cand.exists():
            return str(cand.resolve())
        # cheap depth-2 search
        try:
            for sub in base.glob("*"):
                if sub.is_dir():
                    cand2 = sub / _rid
                    if cand2.exists():
                        return str(cand2.resolve())
        except Exception:
            pass
    return None

def _vsp_open_payload(rid: str, what: str):
    run_dir = _vsp_try_find_run_dir(rid)
    allow = _os.environ.get("VSP_UI_ALLOW_XDG_OPEN", "0") == "1"
    opened = False
    err = None
    if allow and run_dir and what in ("folder","dir","run_dir"):
        try:
            _subprocess.Popen(["xdg-open", run_dir],
                              stdout=_subprocess.DEVNULL, stderr=_subprocess.DEVNULL)
            opened = True
        except Exception as e:
            err = str(e)
    payload = {
        "ok": True,
        "rid": rid,
        "what": what,
        "run_dir": run_dir,
        "opened": opened,
        "disabled": (not allow),
        "hint": "SAFE default: opener disabled. Set VSP_UI_ALLOW_XDG_OPEN=1 to enable (dev only)."
    }
    if err:
        payload["error"] = err
    return payload

try:
    _app_obj = globals().get("app") or globals().get("application")
    if _app_obj is not None and request is not None and jsonify is not None:
        @_app_obj.route("/api/vsp/open", methods=["GET"])
        def vsp_open_p0_v1():
            rid = (request.args.get("rid","") or "").strip()
            what = (request.args.get("what","folder") or "folder").strip()
            return jsonify(_vsp_open_payload(rid, what))

        @_app_obj.route("/api/vsp/open_folder", methods=["GET"])
        def vsp_open_folder_p0_v1():
            rid = (request.args.get("rid","") or "").strip()
            return jsonify(_vsp_open_payload(rid, "folder"))
except Exception:
    pass


# ===================== VSP_APIUI_RUNS_V3_WRAPPER_P1_V1 =====================
# Fix: /api/ui/runs_v3 404 under api/ui WSGI shim (force handle at outermost WSGI layer)
try:
    import os as __os
    import json as __json
    import time as __time
except Exception:
    __os = None; __json = None; __time = None

__VSP_RUNS_V3_CACHE = {"ts": 0, "data": None}

def __vsp__wsgi_json_bytes(payload, status=200):
    b = (__json.dumps(payload, ensure_ascii=False)).encode("utf-8")
    hdrs = [
        ("Content-Type", "application/json; charset=utf-8"),
        ("Cache-Control", "no-store"),
        ("Content-Length", str(len(b))),
    ]
    return status, hdrs, b

def __vsp__safe_int(x, d=0):
    try:
        return int(x)
    except Exception:
        return d

def __vsp__read_json(fp):
    try:
        with open(fp, "r", encoding="utf-8") as f:
            return __json.load(f)
    except Exception:
        return None

def __vsp__pick_overall(run_dir):
    if __os is None:
        return "UNKNOWN"
    cand = [
        __os.path.join(run_dir, "run_gate.json"),
        __os.path.join(run_dir, "run_gate_summary.json"),
        __os.path.join(run_dir, "SUMMARY.json"),
        # VSP_P0_ALLOW_REPORTS_GATE_LISTONLY_V5
        "reports/run_gate_summary.json",
        "reports/run_gate.json",
    ]
    for fp in cand:
        if __os.path.isfile(fp):
            j = __vsp__read_json(fp)
            if isinstance(j, dict):
                for k in ("overall_status","overall","status","verdict","final"):
                    v = j.get(k)
                    if isinstance(v, str) and v.strip():
                        return v.strip().upper()
                # nested variant
                ov = j.get("overall")
                if isinstance(ov, dict):
                    vv = ov.get("status") or ov.get("overall_status")
                    if isinstance(vv, str) and vv.strip():
                        return vv.strip().upper()
    return "UNKNOWN"

def __vsp__overall_weight(o):
    o = (o or "").upper()
    if "RED" in o: return 3
    if "AMBER" in o or "YELLOW" in o: return 2
    if "GREEN" in o: return 1
    return 0

def __vsp__findings_total(run_dir):
    if __os is None:
        return False, 0, None, None
    fp = __os.path.join(run_dir, "reports", "findings_unified.json")
    if not __os.path.isfile(fp):
        return False, 0, None, None
    j = __vsp__read_json(fp)
    total = 0
    counts = None
    if isinstance(j, dict):
        counts = j.get("counts")
        if isinstance(counts, dict):
            t = counts.get("TOTAL")
            if isinstance(t, int):
                total = t
            else:
                for k in ("total","total_findings"):
                    v = counts.get(k)
                    if isinstance(v, int):
                        total = v
                        break
        if total == 0:
            v = j.get("findings")
            if isinstance(v, list):
                total = len(v)
    elif isinstance(j, list):
        total = len(j)
    return True, int(total or 0), fp, counts if isinstance(counts, dict) else None

def __vsp__scan_runs_sorted(root="/home/test/Data/SECURITY_BUNDLE/out", cap=8000, cache_sec=8):
    # cache to avoid heavy scan on every poll
    if __time is None or __os is None:
        return []
    now = int(__time.time())
    if __VSP_RUNS_V3_CACHE["data"] is not None and now - int(__VSP_RUNS_V3_CACHE["ts"] or 0) <= cache_sec:
        return __VSP_RUNS_V3_CACHE["data"]

    items = []
    try:
        names = __os.listdir(root)
    except Exception:
        names = []
    runs = []
    for nm in names:
        if not nm.startswith("RUN_"):
            continue
        rd = __os.path.join(root, nm)
        if __os.path.isdir(rd):
            try:
                mt = int(__os.path.getmtime(rd))
            except Exception:
                mt = 0
            runs.append((mt, nm, rd))
    runs.sort(key=lambda x: x[0], reverse=True)

    for i, (mt, rid, rd) in enumerate(runs):
        if i >= cap:
            break
        has_f, ft, fpath, counts = __vsp__findings_total(rd)
        overall = __vsp__pick_overall(rd)
        items.append({
            "rid": rid,
            "run_dir": rd,
            "mtime": mt,
            "overall": overall,
            "has_findings": bool(has_f),
            "findings_total": int(ft),
            "findings_path": fpath,
            "counts": counts,
            "has_gate": __os.path.isfile(__os.path.join(rd, "run_gate.json")) or __os.path.isfile(__os.path.join(rd, "run_gate_summary.json")),
        })

    # sort “real data first”: findings_total desc, overall weight desc, mtime desc
    items.sort(key=lambda it: (
        int(it.get("findings_total", 0)),
        __vsp__overall_weight(it.get("overall")),
        int(it.get("mtime", 0)),
    ), reverse=True)

    __VSP_RUNS_V3_CACHE["ts"] = now
    __VSP_RUNS_V3_CACHE["data"] = items
    return items

try:
    __vsp__orig_application = application  # existing WSGI callable
except Exception:
    __vsp__orig_application = None

def __vsp__application_runs_v3_wrapper(environ, start_response):
    try:
        path = environ.get("PATH_INFO") or ""
        if path == "/api/ui/runs_v3":
            # parse query
            qs = environ.get("QUERY_STRING") or ""
            limit = 200
            offset = 0
            for part in qs.split("&"):
                if not part:
                    continue
                if part.startswith("limit="):
                    limit = __vsp__safe_int(part.split("=",1)[1], 200)
                elif part.startswith("offset="):
                    offset = __vsp__safe_int(part.split("=",1)[1], 0)
            limit = max(1, min(limit, 2000))
            offset = max(0, offset)

            items = __vsp__scan_runs_sorted()
            page = items[offset:offset+limit]
            status, hdrs, body = __vsp__wsgi_json_bytes({
                "ok": True,
                "items": page,
                "limit": limit,
                "offset": offset,
                "total": len(items),
                "sorted": "findings_total_desc,overall_weight_desc,mtime_desc",
                "ts": int(__time.time()) if __time else 0,
            }, 200)
            start_response(f"{status} OK", hdrs)
            return [body]
    except Exception as e:
        # fallthrough to original app
        pass

    if __vsp__orig_application is not None:
        return __vsp__orig_application(environ, start_response)

    # last resort 404
    status, hdrs, body = __vsp__wsgi_json_bytes({"ok": False, "error":"HTTP_404_NOT_FOUND", "path": environ.get("PATH_INFO",""), "ts": int(__time.time()) if __time else 0}, 404)
    start_response("404 NOT FOUND", hdrs)
    return [body]

# install wrapper once
try:
    if not globals().get("__VSP_RUNS_V3_WRAPPER_INSTALLED"):
        globals()["__VSP_RUNS_V3_WRAPPER_INSTALLED"] = True
        application = __vsp__application_runs_v3_wrapper
except Exception:
    pass
# =================== END VSP_APIUI_RUNS_V3_WRAPPER_P1_V1 ===================

# --- VSP_P1_RUNS_OPEN_AND_META_P1_V2 ---
# Goals:
# 1) Ensure /api/vsp/open* exists to stop 404 spam from Runs tab (SAFE default: no xdg-open).
# 2) Enrich /api/vsp/runs output with per-item has_gate/overall/degraded + rid_latest_gate (prefer gate run).

try:
    from flask import request, jsonify
    import os
    import json
    from pathlib import Path as _Path
    import subprocess
except Exception:
    request = None
    jsonify = None

def _vsp_gate_candidates():
    return [
        "run_gate_summary.json",
        "reports/run_gate_summary.json",
        "run_gate.json",
        "reports/run_gate.json",
    ]

def _vsp_try_read_json(fp: str, max_bytes: int = 2_000_000):
    try:
        p = _Path(fp)
        if (not p.exists()) or (not p.is_file()):
            return None
        if p.stat().st_size > max_bytes:
            return None
        return json.loads(p.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return None

def _vsp_extract_overall_degraded(obj):
    overall = "UNKNOWN"
    degraded = False
    if isinstance(obj, dict):
        overall = obj.get("overall") or obj.get("overall_status") or obj.get("status") or "UNKNOWN"
        if isinstance(obj.get("degraded"), bool):
            degraded = obj.get("degraded")
        bt = obj.get("by_type")
        if degraded is False and isinstance(bt, dict):
            for v in bt.values():
                if isinstance(v, dict) and v.get("degraded") is True:
                    degraded = True
                    break
    return str(overall), bool(degraded)

def _vsp_roots_from_env_or_resp(resp_json=None):
    roots = []
    roots += [os.environ.get("VSP_RUNS_ROOT","")]
    roots += ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/out_ci"]
    if isinstance(resp_json, dict):
        ru = resp_json.get("roots_used")
        if isinstance(ru, list):
            roots = ru + roots
    out = []
    for r in roots:
        if r and r not in out:
            out.append(r)
    return out

def _vsp_find_run_dir(rid: str, roots):
    if not rid:
        return None
    for r in roots or []:
        if not r:
            continue
        base = _Path(r)
        cand = base / rid
        if cand.exists():
            return str(cand.resolve())
    return None

def _vsp_open_payload(rid: str, what: str, roots):
    run_dir = _vsp_find_run_dir(rid, roots)
    allow = os.environ.get("VSP_UI_ALLOW_XDG_OPEN", "0") == "1"
    opened = False
    err = None
    if allow and run_dir and what in ("folder","dir","run_dir"):
        try:
            subprocess.Popen(["xdg-open", run_dir],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            opened = True
        except Exception as e:
            err = str(e)
    payload = {
        "ok": True,
        "rid": rid,
        "what": what,
        "run_dir": run_dir,
        "opened": opened,
        "disabled": (not allow),
        "hint": "SAFE default: opener disabled. Set VSP_UI_ALLOW_XDG_OPEN=1 to enable (dev only).",
    }
    if err:
        payload["error"] = err
    return payload

def _vsp_post_mount_fixups():
    app = globals().get("app") or globals().get("application")
    if app is None or request is None or jsonify is None:
        return

    # 1) Ensure /api/vsp/open endpoints exist
    rules = list(app.url_map.iter_rules())
    has_open = any(r.rule == "/api/vsp/open" for r in rules)
    has_open_folder = any(r.rule == "/api/vsp/open_folder" for r in rules)

    if not has_open:
        def vsp_open_p1_v2():
            rid = (request.args.get("rid","") or "").strip()
            what = (request.args.get("what","folder") or "folder").strip()
            roots = _vsp_roots_from_env_or_resp(None)
            return jsonify(_vsp_open_payload(rid, what, roots))
        app.add_url_rule("/api/vsp/open", endpoint="vsp_open_p1_v2", view_func=vsp_open_p1_v2, methods=["GET"])

    if not has_open_folder:
        def vsp_open_folder_p1_v2():
            rid = (request.args.get("rid","") or "").strip()
            roots = _vsp_roots_from_env_or_resp(None)
            return jsonify(_vsp_open_payload(rid, "folder", roots))
        app.add_url_rule("/api/vsp/open_folder", endpoint="vsp_open_folder_p1_v2", view_func=vsp_open_folder_p1_v2, methods=["GET"])

    # 2) Wrap /api/vsp/runs to enrich per-item gate/overall/degraded + rid_latest_gate
    for r in app.url_map.iter_rules():
        if r.rule != "/api/vsp/runs":
            continue
        ep = r.endpoint
        orig = app.view_functions.get(ep)
        if not orig or getattr(orig, "__vsp_wrapped_runsmeta_v2", False):
            continue

        def wrapped(*args, **kwargs):
            resp = orig(*args, **kwargs)
            status = None
            headers = None
            resp_obj = resp
            if isinstance(resp, tuple) and len(resp) >= 1:
                resp_obj = resp[0]
                if len(resp) >= 2: status = resp[1]
                if len(resp) >= 3: headers = resp[2]

            data = None
            if hasattr(resp_obj, "get_json"):
                data = resp_obj.get_json(silent=True)
            elif isinstance(resp_obj, dict):
                data = resp_obj

            if isinstance(data, dict) and isinstance(data.get("items"), list):
                roots = _vsp_roots_from_env_or_resp(data)
                rid_latest_gate = None

                for it in data["items"]:
                    if not isinstance(it, dict):
                        continue
                    rid = it.get("run_id")
                    run_dir = _vsp_find_run_dir(rid, roots) if rid else None

                    has_gate = False
                    overall = "UNKNOWN"
                    degraded = False

                    if run_dir:
                        for rel in _vsp_gate_candidates():
                            obj = _vsp_try_read_json(str(_Path(run_dir) / rel))
                            if isinstance(obj, dict):
                                has_gate = True
                                overall, degraded = _vsp_extract_overall_degraded(obj)
                                break

                    it.setdefault("has", {})
                    it["has"]["gate"] = bool(has_gate)
                    it["overall"] = str(overall)
                    it["degraded"] = bool(degraded)

                    if rid_latest_gate is None and has_gate:
                        rid_latest_gate = rid

                data["rid_latest_gate"] = rid_latest_gate
                if rid_latest_gate:
                    data["rid_latest"] = rid_latest_gate  # prefer gate run for UI stability

                new_resp = jsonify(data)
                if headers and hasattr(headers, "items"):
                    for k, v in headers.items():
                        new_resp.headers[k] = v
                if status is not None:
                    return new_resp, status
                return new_resp

            return resp

        wrapped.__vsp_wrapped_runsmeta_v2 = True
        app.view_functions[ep] = wrapped
        break

try:
    _vsp_post_mount_fixups()
except Exception:
    pass

# --- VSP_P0_JSON_COMPAT_ADAPTER_V1 ---
# Fix TypeError: __vsp__json() takes 1-2 args but some call sites pass 3 (start_response, payload, status).
# We keep original implementation and add a compat adapter that supports:
#   - __vsp__json(payload)
#   - __vsp__json(payload, status)
#   - __vsp__json(payload)
#   - __vsp__json(payload, status)
try:
    __vsp__json__orig = __vsp__json  # type: ignore[name-defined]
    def __vsp__json(*args, **kwargs):  # noqa: F811
        # Prefer explicit kw if provided
        if kwargs:
            return __vsp__json__orig(*args, **kwargs)

        # 3-args legacy: (start_response, payload, status)
        if len(args) == 3:
            _sr, _payload, _status = args
            # Most common modern form is (payload, status)
            try:
                return __vsp__json__orig(_payload, _status)
            except TypeError:
                # fallback: (start_response, payload)
                return __vsp__json__orig(_sr, _payload)

        # 2-args: could be (payload, status) OR (start_response, payload)
        if len(args) == 2:
            a0, a1 = args
            # if first arg is callable => likely start_response
            if callable(a0):
                try:
                    return __vsp__json__orig(a0, a1)
                except TypeError:
                    return __vsp__json__orig(a1)
            return __vsp__json__orig(a0, a1)

        # 1-arg or 0-arg
        return __vsp__json__orig(*args)
except Exception:
    pass


# === VSP_APIUI_FINDINGS_SAFE_V1 ===
# Safe endpoint: never raise 500 for findings loading.
try:
    import json, os, time
    from flask import request
except Exception:
    json = None

def __vsp__safe_int(v, default=0, lo=0, hi=5000):
    try:
        x = int(v)
    except Exception:
        return default
    if x < lo: x = lo
    if x > hi: x = hi
    return x

def __vsp__get_app_obj():
    for nm in ("app","application","flask_app"):
        obj = globals().get(nm)
        if obj is not None and hasattr(obj, "add_url_rule") and hasattr(obj, "url_map"):
            return obj
    return None

def __vsp__normalize_find_item(it):
    # accept dicts from multiple schemas
    if not isinstance(it, dict):
        return None
    tool = it.get("tool") or it.get("engine") or it.get("source") or ""
    sev  = it.get("severity") or it.get("sev") or it.get("level") or ""
    title = it.get("title") or it.get("name") or it.get("rule_name") or "Finding"
    rule_id = it.get("rule_id") or it.get("check_id") or it.get("id") or ""
    file_ = it.get("file") or it.get("path") or it.get("filename") or ""
    line  = it.get("line")
    try:
        line = int(line) if line is not None else 0
    except Exception:
        line = 0
    msg = it.get("message") or it.get("msg") or it.get("description") or it.get("details") or ""
    return {
        "tool": str(tool),
        "severity": str(sev),
        "title": str(title),
        "rule_id": str(rule_id),
        "file": str(file_),
        "line": line,
        "message": str(msg),
    }

def __vsp__derive_overall_from_counts(counts):
    # overall used by UI: GREEN/AMBER/RED/UNKNOWN
    try:
        c = int(counts.get("CRITICAL", 0) or 0)
        h = int(counts.get("HIGH", 0) or 0)
        m = int(counts.get("MEDIUM", 0) or 0)
        # any CRITICAL/HIGH => RED; else MEDIUM => AMBER; else GREEN
        if c > 0 or h > 0:
            return "RED"
        if m > 0:
            return "AMBER"
        return "GREEN"
    except Exception:
        return "UNKNOWN"

def __vsp__load_findings_list(fp):
    # returns (items_list, counts_dict, raw_root_type)
    import json
    with open(fp, "r", encoding="utf-8", errors="replace") as f:
        j = json.load(f)
    if isinstance(j, list):
        items = j
        counts = {}
        return items, counts, "list"
    if isinstance(j, dict):
        # your schema: dict + findings + counts
        counts = j.get("counts") if isinstance(j.get("counts"), dict) else {}
        for k in ("findings","items","results","data"):
            v = j.get(k)
            if isinstance(v, list):
                return v, counts, f"dict.{k}"
        return [], counts, "dict.no_list_key"
    return [], {}, "unknown"

def __vsp__resolve_run_dir_by_rid(rid):
    # best effort: use existing helper if present
    # common patterns in your gateway: run_dir under /home/test/Data/SECURITY_BUNDLE/out/<RID>
    if not rid:
        return None
    # if rid looks like RUN_xxx: assume standard out layout
    cand = f"/home/test/Data/SECURITY_BUNDLE/out/{rid}"
    try:
        import os
        if os.path.isdir(cand):
            return cand
    except Exception:
        pass
    return None

def __vsp__find_findings_path(run_dir):
    import os
    # prefer reports/findings_unified.json (your real file)
    cands = [
        os.path.join(run_dir, "reports", "findings_unified.json"),
        os.path.join(run_dir, "reports", "findings_unified.jsonl"),
        os.path.join(run_dir, "reports", "findings_unified.sarif"),
    ]
    for fp in cands:
        if os.path.isfile(fp):
            return fp
    return None

def vsp_apiui_findings_safe_v1_handler():
    ts = int(time.time())
    try:
        rid = (request.args.get("rid") or request.args.get("run_id") or "").strip()
        limit  = __vsp__safe_int(request.args.get("limit"), default=50, lo=1, hi=500)
        offset = __vsp__safe_int(request.args.get("offset"), default=0, lo=0, hi=10_000_000)

        run_dir = __vsp__resolve_run_dir_by_rid(rid)
        if not run_dir:
            return __wsgi_json({"ok": False, "error": "bad_rid", "rid": rid, "ts": ts})

        fp = __vsp__find_findings_path(run_dir)
        if not fp:
            return __wsgi_json({"ok": True, "rid": rid, "run_dir": run_dir, "overall": "UNKNOWN",
                                "items": [], "counts": {"TOTAL": 0}, "total": 0,
                                "limit": limit, "offset": offset, "findings_path": None, "ts": ts})

        items, counts, root_type = __vsp__load_findings_list(fp)
        # normalize + slice without breaking on weird items
        norm = []
        for it in items:
            x = __vsp__normalize_find_item(it)
            if x is not None:
                norm.append(x)

        total = len(norm)
        page = norm[offset: offset + limit]

        # counts: keep if present; else compute quick
        if not isinstance(counts, dict) or not counts:
            counts = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0}
            for it in norm:
                sev = (it.get("severity") or "").upper()
                if sev in counts:
                    counts[sev] += 1
            counts["TOTAL"] = total
        else:
            # ensure TOTAL
            try:
                counts["TOTAL"] = int(counts.get("TOTAL", total) or total)
            except Exception:
                counts["TOTAL"] = total

        overall = __vsp__derive_overall_from_counts(counts)

        return __wsgi_json({
            "ok": True,
            "rid": rid,
            "run_dir": run_dir,
            "overall": overall,
            "items": page,
            "counts": counts,
            "limit": limit,
            "offset": offset,
            "total": total,
            "findings_path": fp,
            "root_type": root_type,
            "ts": ts
        })
    except Exception as e:
        return __wsgi_json({"ok": False, "error": "exception", "detail": str(e)[:200], "ts": ts})

# register route only if absent
try:
    __app = __vsp__get_app_obj()
    if __app is not None:
        rules = set([r.rule for r in __app.url_map.iter_rules()])
        if "/api/ui/findings_safe_v1" not in rules:
            __app.add_url_rule("/api/ui/findings_safe_v1", "vsp_apiui_findings_safe_v1",
                               vsp_apiui_findings_safe_v1_handler, methods=["GET"])
except Exception:
    pass
# === /VSP_APIUI_FINDINGS_SAFE_V1 ===

# --- VSP_P0_RESTORE_VSP_JSON_ORIG_V1 ---
# We previously added compat adapters that can return a Response object -> WSGI error: 'Response' not iterable.
# Restore __vsp__json back to the original implementation if it was saved.
try:
    # Prefer the earliest saved original if present
    _orig = globals().get("__vsp__json__orig")
    if callable(_orig):
        __vsp__json = _orig  # type: ignore[misc]
    else:
        _orig2 = globals().get("__vsp__json__orig2")
        if callable(_orig2):
            __vsp__json = _orig2  # type: ignore[misc]
except Exception:
    pass

# --- VSP_P0_WSGI_RESPONSE_COERCE_V1 ---
# Gunicorn WSGI expects an iterable of bytes. If any handler returns a Werkzeug/Flask Response object,
# gunicorn may throw: TypeError: 'Response' object is not iterable.
# Fix: wrap global `application` and coerce Response objects by calling them as WSGI callables.
try:
    _vsp_app_orig = application  # type: ignore[name-defined]
    def application(environ, start_response):  # noqa: F811
        resp = _vsp_app_orig(environ, start_response)

        # If resp is a Werkzeug Response (or compatible), call it to get iterable bytes.
        try:
            from werkzeug.wrappers import Response as _WzResp
        except Exception:
            _WzResp = None

        if _WzResp is not None and isinstance(resp, _WzResp):
            return resp(environ, start_response)

        # Generic: callable + has headers/status ⇒ likely Response-like
        if hasattr(resp, "__call__") and hasattr(resp, "headers") and (hasattr(resp, "status") or hasattr(resp, "status_code")):
            try:
                return resp(environ, start_response)
            except Exception:
                return resp

        return resp
except Exception:
    pass


# --- VSP_APIUI_FINDINGS_V3_WRAPPER_P1_V1 ---
# Safe wrapper for /api/ui/findings_v3 to avoid 500/bad_json & bypass flask routing issues under /api/ui/*
import os, json, time, urllib.parse

def __vsp__json_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False).encode("utf-8"))

def __vsp__wsgi_json(start_response, obj, code="200 OK"):
    body = __vsp__json_bytes(obj)
    headers = [
        ("Content-Type", "application/json; charset=utf-8"),
        ("Cache-Control", "no-store"),
        ("Content-Length", str(len(body))),
    ]
    start_response(code, headers)
    return [body]

def __vsp__parse_qs(environ):
    qs = environ.get("QUERY_STRING","")
    q = urllib.parse.parse_qs(qs, keep_blank_values=True)
    def one(k, d=None):
        v = q.get(k)
        return (v[0] if v else d)
    return q, one

__vsp__FINDINGS_CACHE = {"runs": None, "ts": 0}

def __vsp__scan_runs(out_root):
    items = []
    try:
        for name in os.listdir(out_root):
            if not name.startswith("RUN_"):
                continue
            run_dir = os.path.join(out_root, name)
            if not os.path.isdir(run_dir):
                continue
            f1 = os.path.join(run_dir, "reports", "findings_unified.json")
            f2 = os.path.join(run_dir, "reports", "findings_unified.json".replace("reports/",""))  # no-op safety
            f = f1 if os.path.exists(f1) else (f2 if os.path.exists(f2) else None)
            has_findings = bool(f)
            mtime = int(os.path.getmtime(run_dir)) if os.path.exists(run_dir) else 0
            items.append({"rid": name, "run_dir": run_dir, "mtime": mtime, "has_findings": has_findings, "findings_path": f})
    except Exception:
        return []
    return items

def __vsp__get_run(out_root, rid):
    # cache for 10s to reduce listdir spam
    now = time.time()
    if (__vsp__FINDINGS_CACHE["runs"] is None) or (now - __vsp__FINDINGS_CACHE["ts"] > 10):
        __vsp__FINDINGS_CACHE["runs"] = __vsp__scan_runs(out_root)
        __vsp__FINDINGS_CACHE["ts"] = now
    for it in (__vsp__FINDINGS_CACHE["runs"] or []):
        if it.get("rid") == rid:
            return it
    # fallback direct path
    run_dir = os.path.join(out_root, rid)
    f = os.path.join(run_dir, "reports", "findings_unified.json")
    if os.path.exists(f):
        return {"rid": rid, "run_dir": run_dir, "mtime": int(os.path.getmtime(run_dir)), "has_findings": True, "findings_path": f}
    return None

def __vsp__load_findings(fp):
    try:
        j = json.load(open(fp, "r", encoding="utf-8"))
    except Exception as e:
        return None, "bad_json", str(e)
    # schema variants:
    # - dict with findings:list + counts
    # - dict with items/list keys
    # - raw list
    if isinstance(j, dict):
        if isinstance(j.get("findings"), list):
            return {"items": j["findings"], "counts": (j.get("counts") or {})}, "ok", None
        for k in ("items","results","data"):
            if isinstance(j.get(k), list):
                return {"items": j[k], "counts": (j.get("counts") or {})}, f"ok_dict_{k}", None
        return {"items": [], "counts": (j.get("counts") or {})}, "ok_empty_dict", None
    if isinstance(j, list):
        return {"items": j, "counts": {}}, "ok_list", None
    return None, "bad_shape", f"type={type(j).__name__}"

def __vsp__count_sev(items):
    # best-effort counts
    sev_keys = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"]
    c = {k: 0 for k in sev_keys}
    for it in items:
        sv = None
        if isinstance(it, dict):
            sv = (it.get("severity") or it.get("sev") or it.get("level"))
        if sv:
            sv = str(sv).upper().strip()
            if sv in c: c[sv] += 1
    c["TOTAL"] = sum(c.values())
    return c

def __vsp__norm_item(it):
    if not isinstance(it, dict):
        return {"tool":"", "severity":"INFO", "title":"Finding", "rule_id":"", "file":"", "line":0, "message":str(it)[:500]}
    tool = it.get("tool") or it.get("engine") or it.get("source") or ""
    sev  = (it.get("severity") or it.get("sev") or it.get("level") or "INFO")
    sev  = str(sev).upper().strip()
    title = it.get("title") or it.get("name") or "Finding"
    rule_id = it.get("rule_id") or it.get("rule") or it.get("check_id") or ""
    file_ = it.get("file") or it.get("path") or it.get("filename") or ""
    line  = it.get("line") or it.get("line_number") or 0
    msg   = it.get("message") or it.get("msg") or it.get("description") or ""
    return {"tool": str(tool), "severity": sev, "title": str(title), "rule_id": str(rule_id),
            "file": str(file_), "line": int(line) if str(line).isdigit() else 0, "message": str(msg)}

def __vsp__handle_findings_v3(environ, start_response):
    out_root = os.environ.get("VSP_OUT_ROOT", "/home/test/Data/SECURITY_BUNDLE/out")
    _, one = __vsp__parse_qs(environ)
    rid = one("rid", "")
    if not rid:
        return __vsp__wsgi_json(start_response, {"ok": False, "error":"missing_rid", "path": environ.get("PATH_INFO",""), "ts": int(time.time())}, "400 BAD REQUEST")
    limit = one("limit","50")
    offset = one("offset","0")
    try:
        limit = max(1, min(500, int(limit)))
    except Exception:
        limit = 50
    try:
        offset = max(0, int(offset))
    except Exception:
        offset = 0

    run = __vsp__get_run(out_root, rid)
    if not run or not run.get("findings_path"):
        return __vsp__wsgi_json(start_response, {"ok": False, "error":"missing_findings_file", "rid": rid, "out_root": out_root, "ts": int(time.time())}, "404 NOT FOUND")

    fp = run["findings_path"]
    payload, st, err = __vsp__load_findings(fp)
    if payload is None:
        return __vsp__wsgi_json(start_response, {"ok": False, "error": st, "rid": rid, "findings_path": fp, "detail": err, "ts": int(time.time())}, "200 OK")

    items_all = payload["items"] or []
    total = len(items_all)
    page = items_all[offset: offset+limit]
    page2 = [__vsp__norm_item(x) for x in page]

    counts = payload.get("counts") or {}
    if not isinstance(counts, dict) or not counts:
        # if file has no counts, compute from all items (can be heavy but accurate)
        counts = __vsp__count_sev(items_all)

    # overall best-effort: read run_gate.json if exists
    overall = "UNKNOWN"
    try:
        gate_fp = os.path.join(run["run_dir"], "run_gate.json")
        if os.path.exists(gate_fp):
            g = json.load(open(gate_fp, "r", encoding="utf-8"))
            overall = (g.get("overall") or g.get("overall_status") or overall)
    except Exception:
        pass

    return __vsp__wsgi_json(start_response, {
        "ok": True,
        "rid": rid,
        "run_dir": run.get("run_dir"),
        "overall": overall,
        "items": page2,
        "counts": {k: int(counts.get(k,0)) for k in ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"]} | {"TOTAL": int(counts.get("TOTAL", total))},
        "limit": limit,
        "offset": offset,
        "total": total,
        "findings_path": fp,
        "schema": st,
        "ts": int(time.time()),
    }, "200 OK")

def __vsp__wrap_wsgi_for_findings_v3(inner_app):
    def _w(environ, start_response):
        path = environ.get("PATH_INFO","")
        if path == "/api/ui/findings_v3":
            return __vsp__handle_findings_v3(environ, start_response)
        return inner_app(environ, start_response)
    return _w

# install wrapper on Flask app if present, else on 'application'
try:
    if "app" in globals() and hasattr(globals()["app"], "wsgi_app"):
        globals()["app"].wsgi_app = __vsp__wrap_wsgi_for_findings_v3(globals()["app"].wsgi_app)
except Exception:
    pass

try:
    if "application" in globals() and callable(globals()["application"]):
        globals()["application"] = __vsp__wrap_wsgi_for_findings_v3(globals()["application"])
except Exception:
    pass
# --- END VSP_APIUI_FINDINGS_V3_WRAPPER_P1_V1 ---

# --- VSP_P0_FIX_JSONSIG_DROP_START_RESPONSE_V2 ---
# Ensure __wsgi_json exists (avoid NameError in __vsp__json).
try:
    __wsgi_json  # noqa: F401
except Exception:
    try:
        # __Response and __json are already used inside __vsp__json fallback in this file
        def __wsgi_json(payload, status=200, mimetype="application/json"):  # noqa: F811
            try:
                return __Response(__json.dumps(payload, ensure_ascii=False), status=status, mimetype=mimetype)
            except TypeError:
                # last-resort: stringify non-serializable objects
                return __Response(__json.dumps(payload, ensure_ascii=False, default=str), status=status, mimetype=mimetype)
    except Exception:
        pass

# --- VSP_P0_WSGI_JSON_HARDLOCK_V1 ---
# Hard-lock: eliminate 500 in WSGI JSON responses.
# - Define __wsgi_json (avoid NameError)
# - Override __vsp__json to be WSGI-safe and callable/method-safe (never 500 on json.dumps)
try:
    import json as _vsp_json_mod
    from werkzeug.wrappers import Response as _VspWzResponse
except Exception:
    _vsp_json_mod = None
    _VspWzResponse = None

def __wsgi_json(payload, status=200, mimetype="application/json"):  # noqa: F811
    # Always return a proper WSGI Response (iterable bytes)
    if _vsp_json_mod is None or _VspWzResponse is None:
        # last resort: plain bytes iterable
        body = (str(payload) if payload is not None else "")
        if isinstance(body, str):
            body = body.encode("utf-8", errors="replace")
        return [body]
    try:
        body = _vsp_json_mod.dumps(payload, ensure_ascii=False, default=str)
    except Exception as e:
        body = _vsp_json_mod.dumps({"ok": False, "error": "json_dump_failed", "detail": str(e)}, ensure_ascii=False, default=str)
    return _VspWzResponse(body, status=int(status), mimetype=mimetype)

# Keep a reference to previous impl if exists (for debugging)
try:
    __vsp__json_prev = __vsp__json  # type: ignore[name-defined]
except Exception:
    __vsp__json_prev = None

def __vsp__json(*args, **kwargs):  # noqa: F811
    # Supported call patterns:
    #   __vsp__json(payload)
    #   __vsp__json(payload, status)
    #   __vsp__json(start_response, payload)
    #   __vsp__json(start_response, payload, status)
    status = int(kwargs.get("status", 200))
    payload = None

    if len(args) == 0:
        payload = kwargs.get("payload", {})
    elif len(args) == 1:
        payload = args[0]
    else:
        a0, a1 = args[0], args[1]
        # If first is callable, treat as start_response
        if callable(a0):
            payload = a1
            if len(args) >= 3 and isinstance(args[2], int):
                status = int(args[2])
        else:
            payload = a0
            if isinstance(a1, int):
                status = int(a1)

    # If payload is callable/method, try to materialize; otherwise stringify safely
    try:
        if callable(payload):
            try:
                payload2 = payload()  # may fail if needs args
                payload = payload2
            except Exception:
                payload = {"ok": False, "error": "payload_callable", "payload_type": str(type(payload))}
    except Exception:
        payload = {"ok": False, "error": "payload_inspect_failed"}

    return __wsgi_json(payload, status=status)

# --- VSP_P1_RUNS_PREFER_GATE_OR_FINDINGS_V1 ---
# Enrich /api/vsp/runs response with rid_latest_gate / rid_latest_findings and prefer them for rid_latest.
try:
    import os
    from pathlib import Path as _Path
except Exception:
    os = None
    _Path = None

def __vsp__runs_pick_latest_with_files(items, roots):
    if not _Path:
        return None, None
    gate_candidates = [
        "run_gate_summary.json",
        "reports/run_gate_summary.json",
        "run_gate.json",
        "reports/run_gate.json",
    ]
    findings_candidates = [
        "reports/findings_unified.json",
        "findings_unified.json",
    ]
    rid_latest_gate = None
    rid_latest_findings = None

    for it in items:
        if not isinstance(it, dict):
            continue
        rid = it.get("run_id")
        if not rid:
            continue
        run_dir = None
        for r in roots or []:
            if not r:
                continue
            cand = _Path(r) / rid
            if cand.exists():
                run_dir = cand
                break
        if not run_dir:
            continue

        # gate?
        if rid_latest_gate is None:
            for rel in gate_candidates:
                if (run_dir / rel).exists():
                    rid_latest_gate = rid
                    break

        # findings?
        if rid_latest_findings is None:
            for rel in findings_candidates:
                if (run_dir / rel).exists():
                    rid_latest_findings = rid
                    break

        if rid_latest_gate and rid_latest_findings:
            break

    return rid_latest_gate, rid_latest_findings

# Hook: wrap existing runs handler at WSGI layer if payload builder exists.
try:
    __vsp__runs_payload_prev = __vsp__runs_payload  # type: ignore[name-defined]
    def __vsp__runs_payload(*args, **kwargs):  # noqa: F811
        data = __vsp__runs_payload_prev(*args, **kwargs)
        try:
            if isinstance(data, dict) and isinstance(data.get("items"), list):
                roots = data.get("roots_used") or []
                rid_latest_gate, rid_latest_findings = __vsp__runs_pick_latest_with_files(data["items"], roots)
                data["rid_latest_gate"] = rid_latest_gate
                data["rid_latest_findings"] = rid_latest_findings
                # prefer stable latest
                data["rid_latest"] = rid_latest_gate or rid_latest_findings or data.get("rid_latest")
        except Exception:
            pass
        return data
except Exception:
    pass

# --- VSP_P1_RUNS_WSGI_ENRICH_V3 ---
# Enrich /api/vsp/runs response (rid_latest_gate/rid_latest_findings + per-item has.gate/findings).
try:
    from pathlib import Path as __Path
except Exception:
    __Path = None

def __vsp__runs_enrich_v2(data):
    try:
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            return data
        roots = data.get("roots_used") or []
        items = data["items"]

        gate_candidates = [
            "run_gate_summary.json",
            "reports/run_gate_summary.json",
            "run_gate.json",
            "reports/run_gate.json",
        ]
        findings_candidates = [
            "reports/findings_unified.json",
            "findings_unified.json",
        ]

        rid_latest_gate = None
        rid_latest_findings = None

        def find_run_dir(rid: str):
            if not __Path:
                return None
            for r in roots:
                if not r:
                    continue
                cand = __Path(r) / rid
                if cand.exists():
                    return cand
            return None

        for it in items:
            if not isinstance(it, dict):
                continue
            rid = it.get("run_id")
            if not rid:
                continue
            rd = find_run_dir(rid)
            has_gate = False
            has_findings = False
            if rd is not None:
                for rel in gate_candidates:
                    if (rd / rel).exists():
                        has_gate = True
                        break
                for rel in findings_candidates:
                    if (rd / rel).exists():
                        has_findings = True
                        break

            it.setdefault("has", {})
            it["has"]["gate"] = bool(has_gate)
            it["has"]["findings"] = bool(has_findings)

            if rid_latest_gate is None and has_gate:
                rid_latest_gate = rid
            if rid_latest_findings is None and has_findings:
                rid_latest_findings = rid

        data["rid_latest_gate"] = rid_latest_gate
        data["rid_latest_findings"] = rid_latest_findings
        # prefer gate -> findings -> existing rid_latest
        data["rid_latest"] = rid_latest_gate or rid_latest_findings or data.get("rid_latest")
        return data
    except Exception:
        return data

# --- VSP_P1_RUNS_ENRICH_APP_POST_V4 ---
# Post-process WSGI response for PATH_INFO=/api/vsp/runs.
# This avoids guessing which internal router branch generates the JSON.
try:
    import json as _vsp_json
    from pathlib import Path as _VspPath
    from werkzeug.wrappers import Response as _WzResp
except Exception:
    _vsp_json = None
    _VspPath = None
    _WzResp = None

def _vsp_runs_enrich_data_v4(data):
    try:
        if _VspPath is None:
            return data
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            return data

        roots = list(data.get("roots_used") or [])
        # Add extra roots defensively (your earlier output had ui/out_ci sometimes)
        extra = ["/home/test/Data/SECURITY_BUNDLE/ui/out_ci", "/home/test/Data/SECURITY_BUNDLE/out_ci"]
        for r in extra:
            if r not in roots:
                roots.append(r)

        gate_candidates = [
            "run_gate_summary.json",
            "reports/run_gate_summary.json",
            "run_gate.json",
            "reports/run_gate.json",
        ]
        findings_candidates = [
            "reports/findings_unified.json",
            "findings_unified.json",
        ]

        def find_run_dir(rid: str):
            for root in roots:
                if not root:
                    continue
                cand = _VspPath(root) / rid
                if cand.exists():
                    return cand
            return None

        rid_latest_gate = None
        rid_latest_findings = None

        for it in data["items"]:
            if not isinstance(it, dict):
                continue
            rid = it.get("run_id")
            if not rid:
                continue
            rd = find_run_dir(rid)
            has_gate = False
            has_findings = False
            if rd is not None:
                for rel in gate_candidates:
                    if (rd / rel).exists():
                        has_gate = True
                        break
                for rel in findings_candidates:
                    if (rd / rel).exists():
                        has_findings = True
                        break

            it.setdefault("has", {})
            it["has"]["gate"] = bool(has_gate)
            it["has"]["findings"] = bool(has_findings)

            if rid_latest_gate is None and has_gate:
                rid_latest_gate = rid
            if rid_latest_findings is None and has_findings:
                rid_latest_findings = rid

        data["rid_latest_gate"] = rid_latest_gate
        data["rid_latest_findings"] = rid_latest_findings
        data["rid_latest"] = rid_latest_gate or rid_latest_findings or data.get("rid_latest")
        return data
    except Exception:
        return data

try:
    _vsp_app_prev_v4 = application  # type: ignore[name-defined]
    def application(environ, start_response):  # noqa: F811
        resp = _vsp_app_prev_v4(environ, start_response)
        try:
            if _vsp_json is None or _WzResp is None:
                return resp
            path = (environ or {}).get("PATH_INFO", "")
            if path != "/api/vsp/runs":
                return resp

            # Only handle Werkzeug Response
            if isinstance(resp, _WzResp):
                body = resp.get_data(as_text=True) or ""
                if len(body) > 2_000_000:
                    return resp

                data = _vsp_json.loads(body)
                data2 = _vsp_runs_enrich_data_v4(data)
                out = _vsp_json.dumps(data2, ensure_ascii=False)
                resp.set_data(out)
                resp.mimetype = "application/json"
                resp.headers["X-VSP-RUNS-ENRICH"] = "V4"
                # content-length auto-updated by werkzeug on set_data, but keep safe:
                resp.headers["Content-Length"] = str(len(resp.get_data()))
                return resp(environ, start_response)

            return resp
        except Exception:
            return resp
except Exception:
    pass

# --- VSP_P1_RUNS_ENRICH_WSGI_MW_V5 ---
# True WSGI middleware for /api/vsp/runs that works even if the app returns iterable bytes (not Werkzeug Response).
try:
    import json as _v5_json
    from pathlib import Path as _V5Path
except Exception:
    _v5_json = None
    _V5Path = None

def _v5_runs_enrich(data):
    try:
        if _V5Path is None:
            return data
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            return data

        roots = list(data.get("roots_used") or [])
        # include ui/out_ci if missing (you already had it sometimes)
        extra = ["/home/test/Data/SECURITY_BUNDLE/ui/out_ci", "/home/test/Data/SECURITY_BUNDLE/out_ci"]
        for r in extra:
            if r not in roots:
                roots.append(r)

        gate_candidates = [
            "run_gate_summary.json",
            "reports/run_gate_summary.json",
            "run_gate.json",
            "reports/run_gate.json",
        ]
        findings_candidates = [
            "reports/findings_unified.json",
            "findings_unified.json",
        ]

        def find_run_dir(rid: str):
            for root in roots:
                if not root:
                    continue
                cand = _V5Path(root) / rid
                if cand.exists():
                    return cand
            return None

        rid_latest_gate = None
        rid_latest_findings = None

        for it in data["items"]:
            if not isinstance(it, dict):
                continue
            rid = it.get("run_id")
            if not rid:
                continue

            rd = find_run_dir(rid)
            has_gate = False
            has_findings = False
            if rd is not None:
                for rel in gate_candidates:
                    if (rd / rel).exists():
                        has_gate = True
                        break
                for rel in findings_candidates:
                    if (rd / rel).exists():
                        has_findings = True
                        break

            it.setdefault("has", {})
            it["has"]["gate"] = bool(has_gate)
            it["has"]["findings"] = bool(has_findings)

            if rid_latest_gate is None and has_gate:
                rid_latest_gate = rid
            if rid_latest_findings is None and has_findings:
                rid_latest_findings = rid

        data["rid_latest_gate"] = rid_latest_gate
        data["rid_latest_findings"] = rid_latest_findings
        data["rid_latest"] = rid_latest_gate or rid_latest_findings or data.get("rid_latest")
        return data
    except Exception:
        return data

try:
    _v5_inner_app = application  # type: ignore[name-defined]

    def application(environ, start_response):  # noqa: F811
        path = (environ or {}).get("PATH_INFO", "")
        if path != "/api/vsp/runs" or _v5_json is None:
            return _v5_inner_app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            captured["exc"] = exc_info
            # DO NOT call real start_response yet
            return None

        resp_iter = _v5_inner_app(environ, _sr)

        # buffer body (runs payload is small; still cap)
        buf = bytearray()
        cap = 3_000_000
        try:
            for chunk in resp_iter:
                if chunk:
                    buf += chunk
                if len(buf) > cap:
                    break
        finally:
            try:
                close = getattr(resp_iter, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        # if too big or no captured headers -> fallback passthrough (but we already buffered)
        status = captured["status"] or "200 OK"
        headers = captured["headers"] or [("Content-Type", "application/json; charset=utf-8")]

        body_bytes = bytes(buf)
        try:
            data = _v5_json.loads(body_bytes.decode("utf-8", errors="replace"))
            data2 = _v5_runs_enrich(data)
            out = _v5_json.dumps(data2, ensure_ascii=False).encode("utf-8")
            # update headers
            # remove old content-length
            headers = [(k, v) for (k, v) in headers if k.lower() != "content-length"]
            headers.append(("Content-Length", str(len(out))))
            headers.append(("X-VSP-RUNS-ENRICH", "V5"))
            start_response(status, headers, captured["exc"])
            return [out]
        except Exception:
            # fallback: return original buffered body
            headers = [(k, v) for (k, v) in headers if k.lower() != "content-length"]
            headers.append(("Content-Length", str(len(body_bytes))))
            headers.append(("X-VSP-RUNS-ENRICH", "V5_FAILSAFE"))
            start_response(status, headers, captured["exc"])
            return [body_bytes]
except Exception:
    pass



# VSP_P1_FIX_RUNS_OVERALL_UNKNOWN_V1
def _vsp_safe_int(v, default=0):
    try:
        return int(v) if v is not None else default
    except Exception:
        return default

def _vsp_infer_overall_from_counts(counts: dict, total: int = 0) -> str:
    counts = counts or {}
    c = _vsp_safe_int(counts.get("CRITICAL") or counts.get("critical"), 0)
    h = _vsp_safe_int(counts.get("HIGH") or counts.get("high"), 0)
    m = _vsp_safe_int(counts.get("MEDIUM") or counts.get("medium"), 0)
    l = _vsp_safe_int(counts.get("LOW") or counts.get("low"), 0)
    i = _vsp_safe_int(counts.get("INFO") or counts.get("info"), 0)
    t = _vsp_safe_int(counts.get("TRACE") or counts.get("trace"), 0)
    tot = _vsp_safe_int(total, 0)
    if c > 0 or h > 0: return "RED"
    if m > 0: return "AMBER"
    if tot > 0 or (l+i+t) > 0: return "GREEN"
    return "GREEN"

def _vsp_apply_overall_inference_on_payload(payload: dict):
    try:
        items = payload.get("items")
        if not isinstance(items, list): return
        for it in items:
            if not isinstance(it, dict): 
                continue
            has_gate = bool(it.get("has_gate"))
            overall  = (it.get("overall") or "").strip().upper()
            counts   = it.get("counts") or {}
            total    = it.get("findings_total") or it.get("total") or 0
            inferred = _vsp_infer_overall_from_counts(counts, total)
            it["overall_inferred"] = inferred
            if has_gate and overall and overall != "UNKNOWN":
                it["overall_source"] = "gate"
            else:
                if (not overall) or overall == "UNKNOWN":
                    it["overall"] = inferred
                it["overall_source"] = "inferred_counts"
    except Exception:
        return



# === VSP_P1_RUN_FILE_ALLOW_GATE_SMART_V1 ===
# Commercial: GateStory MUST NOT spam 404/403 due to wrong rid/path/name.
# If /api/vsp/run_file_allow is used to fetch gate files (run_gate*.json),
# rewrite to latest gate-root RID and force root file run_gate_summary.json.
try:
    from pathlib import Path as __Path
    from urllib.parse import parse_qs as __parse_qs, urlencode as __urlencode
    import time as __time

    def __vsp__pick_latest_gate_root_rid_v1():
        roots = [
            __Path("/home/test/Data/SECURITY_BUNDLE/out"),
            __Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        ]
        best = (0.0, "")
        for root in roots:
            if not root.exists():
                continue
            try:
                for d in root.iterdir():
                    if not d.is_dir():
                        continue
                    name = d.name
                    if not (name.startswith("RUN_") or name.startswith("VSP_CI_RUN_") or "_RUN_" in name):
                        continue
                    gate = d / "run_gate_summary.json"
                    if gate.exists():
                        try:
                            mt = gate.stat().st_mtime
                        except Exception:
                            mt = __time.time()
                        if mt > best[0]:
                            best = (mt, name)
            except Exception:
                continue
        return best[1] or ""

    def __vsp__run_file_allow_gate_smart_wrapper_v1(app):
        def _w(environ, start_response):
            try:
                pi = (environ.get("PATH_INFO") or "")
                if pi == "/api/vsp/run_file_allow":
                    qs = __parse_qs(environ.get("QUERY_STRING",""), keep_blank_values=True)
                    # accept both "path" and "name" (your console shows name=...)
                    want = ""
                    if "path" in qs and qs["path"]:
                        want = (qs["path"][0] or "")
                    elif "name" in qs and qs["name"]:
                        want = (qs["name"][0] or "")
                    want_l = want.lower()

                    # only gate-related files trigger smart rewrite
                    if want_l.startswith("run_gate") and want_l.endswith(".json"):
                        rid_gate = __vsp__pick_latest_gate_root_rid_v1()
                        if rid_gate:
                            qs["rid"] = [rid_gate]
                        # force stable file at root => avoids reports/403 + run_gate.json missing/404
                        qs["path"] = ["run_gate_summary.json"]
                        qs["name"] = ["run_gate_summary.json"]
                        environ["QUERY_STRING"] = __urlencode(qs, doseq=True)
            except Exception:
                pass
            return app(environ, start_response)
        return _w

    # wrap once
    if "__vsp__application_gate_smart_wrapped_v1" not in globals():
        __vsp__application_gate_smart_wrapped_v1 = True
        try:
            application = __vsp__run_file_allow_gate_smart_wrapper_v1(application)
        except Exception:
            pass
except Exception:
    pass
# === end VSP_P1_RUN_FILE_ALLOW_GATE_SMART_V1 ===




# === VSP_P1_RUN_FILE_ALLOW_GATE_SMART_V2 ===
# Prefer gate_root + overall known, so GateStory shows real latest gate (e.g., VSP_CI_RUN...).
try:
    import json as __json
    from pathlib import Path as __Path
    import time as __time

    def __vsp__pick_latest_gate_root_rid_v1():
        roots = [
            __Path("/home/test/Data/SECURITY_BUNDLE/out"),
            __Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        ]
        # score: (gate_root, overall_known, mtime)
        best = (-1, -1, 0.0, "")
        for root in roots:
            if not root.exists():
                continue
            try:
                for d in root.iterdir():
                    if not d.is_dir():
                        continue
                    name = d.name
                    if not (name.startswith("RUN_") or name.startswith("VSP_CI_RUN_") or "_RUN_" in name):
                        continue

                    gate_root_path = d / "run_gate_summary.json"
                    gate_rep_path  = d / "reports" / "run_gate_summary.json"

                    gate_path = None
                    gate_root = 0
                    if gate_root_path.exists():
                        gate_path = gate_root_path
                        gate_root = 1
                    elif gate_rep_path.exists():
                        gate_path = gate_rep_path
                        gate_root = 0
                    else:
                        continue

                    try:
                        mt = gate_path.stat().st_mtime
                    except Exception:
                        mt = __time.time()

                    overall_known = 0
                    try:
                        # read small, gate summary is tiny
                        obj = __json.loads(gate_path.read_text(encoding="utf-8", errors="replace"))
                        ov = str(obj.get("overall","")).upper().strip()
                        vd = str(obj.get("verdict","")).upper().strip()
                        if ov and ov != "UNKNOWN" and vd and vd != "UNKNOWN":
                            overall_known = 1
                    except Exception:
                        overall_known = 0

                    cand = (gate_root, overall_known, mt, name)
                    if cand > best:
                        best = cand
            except Exception:
                continue
        return best[3] or ""
except Exception:
    pass
# === end VSP_P1_RUN_FILE_ALLOW_GATE_SMART_V2 ===




# === VSP_P1_RUN_FILE_ALLOW_GATE_SMART_V3 ===
# Strongly prefer VSP_CI_RUN + gate_root + non-UNKNOWN + non-backfilled/non-degraded.
try:
    import json as __json
    from pathlib import Path as __Path
    import time as __time

    def __vsp__pick_latest_gate_root_rid_v3():
        roots = [
            __Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
            __Path("/home/test/Data/SECURITY_BUNDLE/out"),
        ]
        # score tuple (is_ci, gate_root, overall_known, not_degraded, not_backfilled, mtime)
        best = (-1, -1, -1, -1, -1, 0.0, "")
        for root in roots:
            if not root.exists():
                continue
            try:
                for d in root.iterdir():
                    if not d.is_dir():
                        continue
                    name = d.name
                    if not (name.startswith("RUN_") or name.startswith("VSP_CI_RUN_") or "_RUN_" in name):
                        continue

                    gate_root_path = d / "run_gate_summary.json"
                    gate_rep_path  = d / "reports" / "run_gate_summary.json"

                    gate_path = None
                    gate_root = 0
                    if gate_root_path.exists():
                        gate_path = gate_root_path
                        gate_root = 1
                    elif gate_rep_path.exists():
                        gate_path = gate_rep_path
                        gate_root = 0
                    else:
                        continue

                    try:
                        mt = gate_path.stat().st_mtime
                    except Exception:
                        mt = __time.time()

                    is_ci = 1 if name.startswith("VSP_CI_RUN_") else 0

                    overall_known = 0
                    not_degraded = 1
                    not_backfilled = 1

                    try:
                        obj = __json.loads(gate_path.read_text(encoding="utf-8", errors="replace"))
                        ov = str(obj.get("overall","")).upper().strip()
                        vd = str(obj.get("verdict","")).upper().strip()
                        if ov and ov != "UNKNOWN" and vd and vd != "UNKNOWN":
                            overall_known = 1
                        if bool(obj.get("degraded", False)) is True:
                            not_degraded = 0
                        note = str(obj.get("note","") or "")
                        if "Backfilled minimal reports" in note or "no report artifacts" in note:
                            not_backfilled = 0
                    except Exception:
                        # if unreadable => treat as weak
                        overall_known = 0
                        not_degraded = 0
                        not_backfilled = 0

                    cand = (is_ci, gate_root, overall_known, not_degraded, not_backfilled, mt, name)
                    if cand > best:
                        best = cand
            except Exception:
                continue
        return best[-1] or ""

    # Replace v1 picker used by the V1 wrapper
    __vsp__pick_latest_gate_root_rid_v1 = __vsp__pick_latest_gate_root_rid_v3
except Exception:
    pass
# === end VSP_P1_RUN_FILE_ALLOW_GATE_SMART_V3 ===

# VSP_P1_FIX_RUNS_V3_OVERALL_WRAPAPP_V2
def __vsp__wrap_runs_v3_overall_v2(_orig_callable):
    def _w(environ, start_response):
        try:
            path = (environ.get("PATH_INFO") or "")
        except Exception:
            path = ""
        if path == "/api/ui/runs_v3":
            _cap = {}
            def _sr(_status, _headers, _exc_info=None):
                _cap["status"] = _status
                _cap["headers"] = list(_headers or [])
                _cap["exc_info"] = _exc_info
                return (lambda _b: None)

            _it = _orig_callable(environ, _sr)
            try:
                _body = b"".join(_it)
            finally:
                try:
                    _close = getattr(_it, "close", None)
                    if callable(_close):
                        _close()
                except Exception:
                    pass

            _status = _cap.get("status") or "200 OK"
            _headers = _cap.get("headers") or []
            _ct = ""
            try:
                for k, v in _headers:
                    if str(k).lower() == "content-type":
                        _ct = str(v)
                        break
            except Exception:
                _ct = ""

            _new_body = _body
            try:
                if "application/json" in (_ct or "") and (_body or b"").strip():
                    import json as _json
                    _obj = _json.loads(_body.decode("utf-8", "replace"))
                    if isinstance(_obj, dict) and isinstance(_obj.get("items"), list):
                        for _it2 in _obj["items"]:
                            if not isinstance(_it2, dict):
                                continue
                            _has_gate = bool(_it2.get("has_gate"))
                            _overall = str(_it2.get("overall") or "").strip().upper()
                            _counts = _it2.get("counts")
                            if not isinstance(_counts, dict):
                                _counts = {}
                            def _i(v, d=0):
                                try:
                                    return int(v) if v is not None else d
                                except Exception:
                                    return d
                            c = _i(_counts.get("CRITICAL") or _counts.get("critical"), 0)
                            h = _i(_counts.get("HIGH") or _counts.get("high"), 0)
                            m = _i(_counts.get("MEDIUM") or _counts.get("medium"), 0)
                            l = _i(_counts.get("LOW") or _counts.get("low"), 0)
                            i = _i(_counts.get("INFO") or _counts.get("info"), 0)
                            t = _i(_counts.get("TRACE") or _counts.get("trace"), 0)
                            tot = _i(_it2.get("findings_total") or _it2.get("total") or 0, 0)

                            if (c > 0) or (h > 0):
                                inf = "RED"
                            elif (m > 0):
                                inf = "AMBER"
                            elif (tot > 0) or ((l + i + t) > 0):
                                inf = "GREEN"
                            else:
                                inf = "GREEN"

                            if (not _has_gate) and ((not _overall) or (_overall == "UNKNOWN")):
                                _it2["overall"] = inf
                            _it2["overall_inferred"] = inf
                            _it2["overall_source"] = ("gate" if (_has_gate and _overall and _overall != "UNKNOWN") else "inferred_counts")

                        _new_body = _json.dumps(_obj, ensure_ascii=False).encode("utf-8")
            except Exception:
                _new_body = _body

            _h2 = []
            for k, v in _headers:
                if str(k).lower() == "content-length":
                    continue
                _h2.append((k, v))
            _h2.append(("Content-Length", str(len(_new_body))))
            start_response(_status, _h2, _cap.get("exc_info"))
            return [_new_body]

        return _orig_callable(environ, start_response)
    return _w

def __vsp__maybe_wrap_callable_v2(name):
    try:
        obj = globals().get(name)
        if obj is None:
            return False
        # wrap only plain callables (functions), not Flask app objects
        try:
            from flask import Flask
            if isinstance(obj, Flask):
                return False
        except Exception:
            pass
        if callable(obj):
            globals()[name] = __vsp__wrap_runs_v3_overall_v2(obj)
            return True
        return False
    except Exception:
        return False

_wrapped = []
for _n in ("app", "application"):
    if __vsp__maybe_wrap_callable_v2(_n):
        _wrapped.append(_n)
print("[VSP_FIX_RUNS_V3_WRAPAPP_V2] wrapped:", _wrapped)

# --- VSP_P1_RUNS_ENRICH_WSGI_MW_V6 ---
# Tighten has.gate: true only if gate JSON is parseable (and prefer root gate files).
try:
    import json as _v6_json
    from pathlib import Path as _V6Path
except Exception:
    _v6_json = None
    _V6Path = None

def _v6_gate_parse_ok(fp: "_V6Path"):
    try:
        if _v6_json is None:
            return False, None
        if not fp.exists() or not fp.is_file():
            return False, None
        # cap read (2MB)
        b = fp.read_bytes()
        if len(b) > 2_000_000:
            return False, str(fp)
        obj = _v6_json.loads(b.decode("utf-8", errors="replace"))
        if not isinstance(obj, dict):
            return False, str(fp)
        # heuristic: gate json should have at least one of these keys
        if not (("overall" in obj) or ("overall_status" in obj) or ("by_type" in obj) or ("verdict" in obj)):
            # still JSON but not gate-ish
            return False, str(fp)
        return True, str(fp)
    except Exception:
        return False, str(fp)

def _v6_runs_enrich(data):
    try:
        if _V6Path is None:
            return data
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            return data

        roots = list(data.get("roots_used") or [])
        extra = ["/home/test/Data/SECURITY_BUNDLE/ui/out_ci", "/home/test/Data/SECURITY_BUNDLE/out_ci"]
        for r in extra:
            if r not in roots:
                roots.append(r)

        # prefer root first (avoid reports-only until run_file_allow is smart-fallback)
        gate_candidates = [
            "run_gate_summary.json",
            "run_gate.json",
            "reports/run_gate_summary.json",
            "reports/run_gate.json",
        ]
        findings_candidates = [
            "reports/findings_unified.json",
            "findings_unified.json",
        ]

        def find_run_dir(rid: str):
            for root in roots:
                if not root:
                    continue
                cand = _V6Path(root) / rid
                if cand.exists():
                    return cand
            return None

        rid_latest_gate_root = None
        rid_latest_gate_any = None
        rid_latest_findings = None

        for it in data["items"]:
            if not isinstance(it, dict):
                continue
            rid = it.get("run_id")
            if not rid:
                continue
            rd = find_run_dir(rid)

            has_findings = False
            has_gate = False
            has_gate_root = False
            gate_src = None

            if rd is not None:
                # findings existence
                for rel in findings_candidates:
                    if (rd / rel).exists():
                        has_findings = True
                        break

                # gate parse check
                for rel in gate_candidates:
                    fp = rd / rel
                    ok, src = _v6_gate_parse_ok(fp)
                    if ok:
                        has_gate = True
                        gate_src = rel
                        has_gate_root = (not rel.startswith("reports/"))
                        break

            it.setdefault("has", {})
            it["has"]["findings"] = bool(has_findings)
            it["has"]["gate"] = bool(has_gate)
            it["has"]["gate_root"] = bool(has_gate_root)
            if gate_src:
                it["has"]["gate_source"] = gate_src

            if rid_latest_findings is None and has_findings:
                rid_latest_findings = rid
            if has_gate_root and rid_latest_gate_root is None:
                rid_latest_gate_root = rid
            if has_gate and rid_latest_gate_any is None:
                rid_latest_gate_any = rid

        data["rid_latest_gate_root"] = rid_latest_gate_root
        data["rid_latest_gate"] = rid_latest_gate_root or rid_latest_gate_any
        data["rid_latest_findings"] = rid_latest_findings
        data["rid_latest"] = data["rid_latest_gate"] or rid_latest_findings or data.get("rid_latest")
        return data
    except Exception:
        return data

try:
    _v6_inner_app = application  # type: ignore[name-defined]
    def application(environ, start_response):  # noqa: F811
        path = (environ or {}).get("PATH_INFO", "")
        if path != "/api/vsp/runs" or _v6_json is None:
            return _v6_inner_app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            captured["exc"] = exc_info
            return None

        resp_iter = _v6_inner_app(environ, _sr)

        buf = bytearray()
        cap = 3_000_000
        try:
            for chunk in resp_iter:
                if chunk:
                    buf += chunk
                if len(buf) > cap:
                    break
        finally:
            try:
                close = getattr(resp_iter, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        status = captured["status"] or "200 OK"
        headers = captured["headers"] or [("Content-Type", "application/json; charset=utf-8")]
        body_bytes = bytes(buf)

        try:
            data = _v6_json.loads(body_bytes.decode("utf-8", errors="replace"))
            data2 = _v6_runs_enrich(data)
            out = _v6_json.dumps(data2, ensure_ascii=False).encode("utf-8")
            headers = [(k, v) for (k, v) in headers if k.lower() != "content-length"]
            headers.append(("Content-Length", str(len(out))))
            # override/replace enrich header
            headers = [(k, v) for (k, v) in headers if k.lower() != "x-vsp-runs-enrich"]
            headers.append(("X-VSP-RUNS-ENRICH", "V6"))
            start_response(status, headers, captured["exc"])
            return [out]
        except Exception:
            headers = [(k, v) for (k, v) in headers if k.lower() != "content-length"]
            headers.append(("Content-Length", str(len(body_bytes))))
            headers = [(k, v) for (k, v) in headers if k.lower() != "x-vsp-runs-enrich"]
            headers.append(("X-VSP-RUNS-ENRICH", "V6_FAILSAFE"))
            start_response(status, headers, captured["exc"])
            return [body_bytes]
except Exception:
    pass


# ===================== VSP_P1_RULE_OVERRIDES_APPLY_COMMERCIAL_V1 =====================
# Commercial-hardening for Rule Overrides apply endpoint:
# - Never 404 for apply endpoint
# - Never crash 8910 (always catches exceptions)
# - Always returns HTTP 200 JSON with ok/degraded flags
# - Writes an "applied marker" into run_dir for UI to detect
try:
    import os, json, time, traceback
    from pathlib import Path
    from flask import request, jsonify, make_response
except Exception:
    pass

def _vsp_json_200(payload: dict):
    try:
        resp = make_response(jsonify(payload), 200)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["Pragma"] = "no-cache"
        resp.headers["Expires"] = "0"
        return resp
    except Exception:
        # fallback ultra-safe
        import json as _json
        body = _json.dumps(payload, ensure_ascii=False)
        return (body, 200, {"Content-Type":"application/json; charset=utf-8",
                            "Cache-Control":"no-store","Pragma":"no-cache","Expires":"0"})

def _vsp_guess_run_dir(rid: str):
    # Prefer env override, else common roots in SECURITY_BUNDLE
    roots = []
    env_root = os.environ.get("VSP_OUT_ROOT") or os.environ.get("SECURITY_BUNDLE_OUT_ROOT")
    if env_root:
        roots.append(env_root)
    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]
    for r in roots:
        pr = Path(r)
        cand = pr / rid
        if cand.is_dir():
            return cand

    # fallback: try fuzzy match (rid prefix) by mtime
    for r in roots:
        pr = Path(r)
        if not pr.is_dir():
            continue
        cands = sorted(pr.glob(f"{rid}*"), key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True)
        for c in cands:
            if c.is_dir():
                return c
    return None

def _vsp_rule_overrides_store():
    # central store for UI editing; safe default under ui/out_ci
    base = os.environ.get("VSP_RULE_OVERRIDES_DIR") or "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/rule_overrides_v2"
    bd = Path(base)
    bd.mkdir(parents=True, exist_ok=True)
    return bd / "rule_overrides.json"

def _vsp_read_overrides():
    f = _vsp_rule_overrides_store()
    if not f.exists():
        # create minimal v2 structure
        f.write_text(json.dumps({"version":2,"rules":[]}, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        return json.loads(f.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        # if corrupted, don't break apply
        return {"version":2,"rules":[],"_corrupted":True}

def _vsp_write_applied_marker(run_dir: Path, rid: str, overrides_obj: dict, status: str, note: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    payload = {
        "rid": rid,
        "applied_at": ts,
        "status": status,          # OK / DEGRADED / ERROR
        "note": note,
        "overrides_meta": {
            "version": overrides_obj.get("version", None),
            "rules_count": len(overrides_obj.get("rules", []) or []),
            "corrupted": bool(overrides_obj.get("_corrupted", False)),
        }
    }
    # write in both root + reports/ for easy pickup
    try:
        (run_dir / "reports").mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    for out in [run_dir/"rule_overrides_applied.json", run_dir/"reports"/"rule_overrides_applied.json"]:
        try:
            out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
    return payload

# ---- (A) GET: UI fetch current overrides (optional helper) ----
try:
    @app.route("/api/ui/rule_overrides_v2_get_v1", methods=["GET"])
    def vsp_rule_overrides_v2_get_v1():
        obj = _vsp_read_overrides()
        return _vsp_json_200({"ok": True, "data": obj, "store": str(_vsp_rule_overrides_store())})
except Exception:
    pass

# ---- (B) POST: UI save overrides (optional helper) ----
try:
    @app.route("/api/ui/rule_overrides_v2_save_v1", methods=["POST"])
    def vsp_rule_overrides_v2_save_v1():
        try:
            body = request.get_json(force=True, silent=True) or {}
            data = body.get("data")
            if not isinstance(data, dict):
                return _vsp_json_200({"ok": False, "degraded": True, "error": "invalid_payload_expect_data_object"})
            f = _vsp_rule_overrides_store()
            f.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            return _vsp_json_200({"ok": True, "saved": True, "store": str(f)})
        except Exception as e:
            return _vsp_json_200({"ok": False, "degraded": True, "error": str(e), "trace": traceback.format_exc()[-1200:]})
except Exception:
    pass

# ---- (C) POST: Apply overrides to a run (commercial contract) ----
def _vsp_apply_rule_overrides_v2_apply_v2_impl():
    rid = ""
    try:
        body = request.get_json(force=True, silent=True) or {}
        rid = (body.get("rid") or "").strip()
        if not rid:
            return _vsp_json_200({"ok": False, "degraded": True, "error": "missing_rid"})
        run_dir = _vsp_guess_run_dir(rid)
        overrides = _vsp_read_overrides()

        if run_dir is None:
            # don't 404; return degraded
            return _vsp_json_200({
                "ok": False,
                "degraded": True,
                "rid": rid,
                "error": "run_dir_not_found",
                "roots_hint": [
                    os.environ.get("VSP_OUT_ROOT"),
                    "/home/test/Data/SECURITY_BUNDLE/out",
                    "/home/test/Data/SECURITY_BUNDLE/out_ci",
                    "/home/test/Data/SECURITY-10-10-v4/out_ci",
                ],
                "overrides_meta": {
                    "store": str(_vsp_rule_overrides_store()),
                    "version": overrides.get("version", None),
                    "rules_count": len(overrides.get("rules", []) or []),
                    "corrupted": bool(overrides.get("_corrupted", False)),
                }
            })

        # We do NOT attempt to mutate findings here (schema unknown).
        # We write an applied marker file so UI + any downstream tool can pick it up safely.
        marker = _vsp_write_applied_marker(run_dir, rid, overrides, status="OK", note="marker_written_only")

        return _vsp_json_200({
            "ok": True,
            "degraded": False,
            "rid": rid,
            "run_dir": str(run_dir),
            "applied": True,
            "mode": "MARKER_ONLY",
            "marker": marker,
            "overrides_store": str(_vsp_rule_overrides_store()),
        })
    except Exception as e:
        return _vsp_json_200({
            "ok": False,
            "degraded": True,
            "rid": rid,
            "error": str(e),
            "trace": traceback.format_exc()[-1800:],
        })

# Replace existing route if present; else register new route
try:
    _has = "/api/ui/rule_overrides_v2_apply_v2" in globals().get("__file__", "")  # dummy
except Exception:
    _has = False

try:
    # if an old handler exists, we still register under same URL but unique endpoint name is important
    app.add_url_rule(
        "/api/ui/rule_overrides_v2_apply_v2",
        endpoint="vsp_rule_overrides_v2_apply_v2__commercial_v1",
        view_func=_vsp_apply_rule_overrides_v2_apply_v2_impl,
        methods=["POST"]
    )
except Exception:
    # as last resort, try decorator form (may fail if already registered)
    try:
        @app.route("/api/ui/rule_overrides_v2_apply_v2", methods=["POST"])
        def vsp_rule_overrides_v2_apply_v2__commercial_v1():
            return _vsp_apply_rule_overrides_v2_apply_v2_impl()
    except Exception:
        pass
# ===================== /VSP_P1_RULE_OVERRIDES_APPLY_COMMERCIAL_V1 =====================


# ===================== VSP_P1_RULE_OVERRIDES_APPLY_WSGI_INTERCEPT_V1_FIX =====================
# Commercial hardening: WSGI intercept so /api/ui/rule_overrides_v2_apply_v2 never 404,
# always returns HTTP 200 JSON, and never crashes the 8910 process.

def _vsp_ro_json(start_response, payload):
    import json
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = [
        ("Content-Type", "application/json; charset=utf-8"),
        ("Cache-Control", "no-store"),
        ("Pragma", "no-cache"),
        ("Expires", "0"),
        ("Content-Length", str(len(body))),
    ]
    start_response("200 OK", headers)
    return [body]

def _vsp_ro_read_body(environ, limit=262144):
    try:
        wsgi_input = environ.get("wsgi.input")
        if not wsgi_input:
            return b""
        try:
            clen = int(environ.get("CONTENT_LENGTH") or "0")
        except Exception:
            clen = 0
        n = clen if 0 < clen <= limit else limit
        return wsgi_input.read(n) if n > 0 else b""
    except Exception:
        return b""

def _vsp_ro_guess_run_dir(rid):
    import os
    from pathlib import Path

    roots = []
    env_root = os.environ.get("VSP_OUT_ROOT") or os.environ.get("SECURITY_BUNDLE_OUT_ROOT")
    if env_root:
        roots.append(env_root)

    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]

    # direct hit
    for r in roots:
        pr = Path(r)
        cand = pr / rid
        if cand.is_dir():
            return cand

    # fuzzy search by prefix (top-level)
    for r in roots:
        pr = Path(r)
        if not pr.is_dir():
            continue
        try:
            cands = sorted(pr.glob(rid + "*"), key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True)
            for c in cands:
                if c.is_dir():
                    return c
        except Exception:
            pass

    # bounded deep search (avoid heavy scan)
    for r in roots:
        pr = Path(r)
        if not pr.is_dir():
            continue
        try:
            deep = []
            # only scan 2 levels deep to stay safe
            for a in pr.iterdir():
                if not a.is_dir():
                    continue
                b = a / rid
                if b.is_dir():
                    deep.append(b)
            if deep:
                deep = sorted(deep, key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True)
                return deep[0]
        except Exception:
            pass

    return None

def _vsp_ro_store_path():
    import os
    from pathlib import Path
    base = os.environ.get("VSP_RULE_OVERRIDES_DIR") or "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/rule_overrides_v2"
    bd = Path(base)
    bd.mkdir(parents=True, exist_ok=True)
    return bd / "rule_overrides.json"

def _vsp_ro_read_overrides():
    import json
    f = _vsp_ro_store_path()
    if not f.exists():
        f.write_text(json.dumps({"version": 2, "rules": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        return json.loads(f.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return {"version": 2, "rules": [], "_corrupted": True}

def _vsp_ro_write_marker(run_dir, rid, overrides, status, note):
    import json, time
    from pathlib import Path
    rd = Path(str(run_dir))
    payload = {
        "rid": rid,
        "applied_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "status": status,
        "note": note,
        "overrides_meta": {
            "store": str(_vsp_ro_store_path()),
            "version": overrides.get("version"),
            "rules_count": len(overrides.get("rules") or []),
            "corrupted": bool(overrides.get("_corrupted", False)),
        }
    }
    try:
        (rd / "reports").mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    for out in [rd / "rule_overrides_applied.json", rd / "reports" / "rule_overrides_applied.json"]:
        try:
            out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
    return payload

class _VSPRuleOverridesApplyWSGI:
    def __init__(self, inner_app):
        self.inner_app = inner_app

    def __call__(self, environ, start_response):
        import time, json, traceback
        path = environ.get("PATH_INFO") or ""
        method = (environ.get("REQUEST_METHOD") or "GET").upper()

        if path == "/api/ui/rule_overrides_v2_apply_v2" and method == "POST":
            try:
                raw = _vsp_ro_read_body(environ)
                try:
                    body = json.loads(raw.decode("utf-8", errors="replace") or "{}")
                except Exception:
                    body = {}

                rid = (body.get("rid") or "").strip()
                if not rid:
                    return _vsp_ro_json(start_response, {"ok": False, "degraded": True, "error": "missing_rid", "path": path, "ts": int(time.time())})

                overrides = _vsp_ro_read_overrides()
                run_dir = _vsp_ro_guess_run_dir(rid)

                if run_dir is None:
                    return _vsp_ro_json(start_response, {
                        "ok": False, "degraded": True, "rid": rid,
                        "error": "run_dir_not_found",
                        "overrides_meta": {
                            "store": str(_vsp_ro_store_path()),
                            "version": overrides.get("version"),
                            "rules_count": len(overrides.get("rules") or []),
                            "corrupted": bool(overrides.get("_corrupted", False)),
                        },
                        "path": path, "ts": int(time.time())
                    })

                marker = _vsp_ro_write_marker(run_dir, rid, overrides, status="OK", note="marker_written_only")
                return _vsp_ro_json(start_response, {"ok": True, "degraded": False, "rid": rid, "run_dir": str(run_dir), "mode": "MARKER_ONLY", "marker": marker, "path": path, "ts": int(time.time())})
            except Exception as e:
                return _vsp_ro_json(start_response, {"ok": False, "degraded": True, "error": str(e), "trace": traceback.format_exc()[-1600:], "path": path, "ts": int(time.time())})

        return self.inner_app(environ, start_response)

# Wrap exported WSGI application safely
try:
    application
except Exception:
    try:
        application = app
    except Exception:
        application = None

if application is not None:
    if not getattr(application, "_vsp_ro_wsgi_wrapped", False):
        wrapped = _VSPRuleOverridesApplyWSGI(application)
        setattr(wrapped, "_vsp_ro_wsgi_wrapped", True)
        application = wrapped
# ===================== /VSP_P1_RULE_OVERRIDES_APPLY_WSGI_INTERCEPT_V1_FIX =====================


# ===================== VSP_P1_RULE_OVERRIDES_GET_SAVE_WSGI_V1 =====================
def _vsp_ro2_json(start_response, payload):
    import json
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = [
        ("Content-Type", "application/json; charset=utf-8"),
        ("Cache-Control", "no-store"),
        ("Pragma", "no-cache"),
        ("Expires", "0"),
        ("Content-Length", str(len(body))),
    ]
    start_response("200 OK", headers)
    return [body]

def _vsp_ro2_read_body(environ, limit=262144):
    try:
        wsgi_input = environ.get("wsgi.input")
        if not wsgi_input:
            return b""
        try:
            clen = int(environ.get("CONTENT_LENGTH") or "0")
        except Exception:
            clen = 0
        n = clen if 0 < clen <= limit else limit
        return wsgi_input.read(n) if n > 0 else b""
    except Exception:
        return b""

def _vsp_ro2_store_path():
    import os
    from pathlib import Path
    base = os.environ.get("VSP_RULE_OVERRIDES_DIR") or "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/rule_overrides_v2"
    bd = Path(base)
    bd.mkdir(parents=True, exist_ok=True)
    return bd / "rule_overrides.json"

def _vsp_ro2_read_overrides():
    import json
    f = _vsp_ro2_store_path()
    if not f.exists():
        f.write_text(json.dumps({"version": 2, "rules": []}, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            f.chmod(0o644)
        except Exception:
            pass
    try:
        return json.loads(f.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return {"version": 2, "rules": [], "_corrupted": True}

def _vsp_ro2_write_overrides(obj):
    import json
    f = _vsp_ro2_store_path()
    f.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        f.chmod(0o644)
    except Exception:
        pass
    return f

class _VSPRuleOverridesGetSaveWSGI:
    def __init__(self, inner_app):
        self.inner_app = inner_app

    def __call__(self, environ, start_response):
        import time, json, traceback
        path = environ.get("PATH_INFO") or ""
        method = (environ.get("REQUEST_METHOD") or "GET").upper()

        # GET: load current overrides
        if path == "/api/ui/rule_overrides_v2_get_v1" and method == "GET":
            try:
                obj = _vsp_ro2_read_overrides()
                return _vsp_ro2_json(start_response, {
                    "ok": True,
                    "data": obj,
                    "store": str(_vsp_ro2_store_path()),
                    "ts": int(time.time())
                })
            except Exception as e:
                return _vsp_ro2_json(start_response, {
                    "ok": False, "degraded": True, "error": str(e),
                    "trace": traceback.format_exc()[-1200:],
                    "ts": int(time.time())
                })

        # POST: save overrides
        if path == "/api/ui/rule_overrides_v2_save_v1" and method == "POST":
            try:
                raw = _vsp_ro2_read_body(environ)
                try:
                    body = json.loads(raw.decode("utf-8", errors="replace") or "{}")
                except Exception:
                    body = {}

                # Accept either {"data":{...}} or direct object {...}
                data = body.get("data") if isinstance(body, dict) else None
                obj = data if isinstance(data, dict) else (body if isinstance(body, dict) else {})

                # Minimal normalize
                if "version" not in obj:
                    obj["version"] = 2
                if "rules" not in obj or not isinstance(obj.get("rules"), list):
                    obj["rules"] = []

                f = _vsp_ro2_write_overrides(obj)
                return _vsp_ro2_json(start_response, {
                    "ok": True,
                    "saved": True,
                    "store": str(f),
                    "rules_count": len(obj.get("rules") or []),
                    "ts": int(time.time())
                })
            except Exception as e:
                return _vsp_ro2_json(start_response, {
                    "ok": False, "degraded": True, "error": str(e),
                    "trace": traceback.format_exc()[-1600:],
                    "ts": int(time.time())
                })

        return self.inner_app(environ, start_response)

# Wrap exported WSGI application safely (stackable with existing wrappers)
try:
    application
except Exception:
    try:
        application = app
    except Exception:
        application = None

if application is not None:
    if not getattr(application, "_vsp_ro2_getsave_wrapped", False):
        wrapped = _VSPRuleOverridesGetSaveWSGI(application)
        setattr(wrapped, "_vsp_ro2_getsave_wrapped", True)
        application = wrapped
# ===================== /VSP_P1_RULE_OVERRIDES_GET_SAVE_WSGI_V1 =====================
# ===================== VSP_P1_EXPORT_ZIP_PDF_AND_RUNS_FIX_WSGI_V1B =====================
# Commercial-safe WSGI intercept:
#  - GET /runs                       -> never zero-length (serves template or fallback)
#  - GET /api/vsp/run_export_zip?rid=RUN_... -> evidence zip bundle (attachment)
#  - GET /api/vsp/run_export_pdf?rid=RUN_... -> minimal executive PDF (attachment)
#
# No Flask route dependency. Never crashes gunicorn. No-store headers.

def _vsp_exp2_no_store(extra=None):
    h = [("Cache-Control","no-store"),("Pragma","no-cache"),("Expires","0")]
    if extra:
        h.extend(extra)
    return h

def _vsp_exp2_resp(start_response, status, body, ctype, extra=None):
    if body is None:
        body = b""
    hdr = [("Content-Type", ctype), ("Content-Length", str(len(body)))]
    hdr += _vsp_exp2_no_store(extra)
    start_response(status, hdr)
    return [body]

def _vsp_exp2_json(start_response, obj):
    import json
    b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    return _vsp_exp2_resp(start_response, "200 OK", b, "application/json; charset=utf-8")

def _vsp_exp2_qs(environ):
    from urllib.parse import parse_qs
    return parse_qs(environ.get("QUERY_STRING") or "", keep_blank_values=True)

def _vsp_exp2_safe_rid(rid):
    import re
    if not isinstance(rid, str):
        return None
    rid = rid.strip()
    if re.match(r"^RUN_\d{8}_\d{6}([A-Za-z0-9_.-]+)?$", rid):
        return rid
    return None

def _vsp_exp2_guess_run_dir(rid):
    import os
    from pathlib import Path
    roots = []
    env_root = os.environ.get("VSP_OUT_ROOT") or os.environ.get("SECURITY_BUNDLE_OUT_ROOT")
    if env_root:
        roots.append(env_root)
    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]
    for r in roots:
        pr = Path(r)
        cand = pr / rid
        if cand.is_dir():
            return cand
    # fuzzy prefix
    for r in roots:
        pr = Path(r)
        if not pr.is_dir():
            continue
        try:
            cands = sorted(pr.glob(rid + "*"), key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True)
            for c in cands:
                if c.is_dir():
                    return c
        except Exception:
            pass
    return None

def _vsp_exp2_runs_html_bytes():
    import time
    from pathlib import Path
    cands = [
        "templates/vsp_runs_reports_v1.html",
        "templates/vsp_runs_reports.html",
        "templates/vsp_runs.html",
    ]
    for c in cands:
        f = Path(c)
        if f.exists():
            html = f.read_text(encoding="utf-8", errors="replace")
            v = str(int(time.time()))
            html = html.replace("{{ asset_v }}", v).replace("{{asset_v}}", v)
            return html.encode("utf-8")
    return b"<!doctype html><html><head><meta charset='utf-8'><title>Runs</title></head><body><h3>Runs page template not found</h3><p>Go to <a href='/vsp5'>/vsp5</a></p></body></html>"

def _vsp_exp2_collect_files(run_dir, max_bytes=50*1024*1024):
    from pathlib import Path
    rd = Path(str(run_dir))
    prefer = [
        "run_manifest.json","run_evidence_index.json","run_gate.json","run_gate_summary.json",
        "findings_unified.json","findings_unified.sarif","findings_unified.csv",
        "rule_overrides_applied.json","reports/rule_overrides_applied.json",
        "reports/findings_unified.json","reports/findings_unified.sarif","reports/findings_unified.csv",
        # VSP_P0_ALLOW_REPORTS_GATE_LISTONLY_V5
        "reports/run_gate_summary.json",
        "reports/run_gate.json",
    ]
    files = []
    for rel in prefer:
        f = rd / rel
        if f.exists() and f.is_file():
            files.append(f)
    for relroot in ["reports","evidence"]:
        d = rd / relroot
        if d.exists() and d.is_dir():
            for f in sorted(d.rglob("*")):
                if f.is_file():
                    files.append(f)
    # dedup
    seen=set(); uniq=[]
    for f in files:
        try:
            key=str(f.resolve())
        except Exception:
            key=str(f)
        if key in seen: continue
        seen.add(key); uniq.append(f)

    final=[]; skipped=[]
    for f in uniq:
        try:
            sz=f.stat().st_size
            rel=str(f.relative_to(rd))
            if sz>max_bytes:
                skipped.append({"path":rel,"size":sz,"reason":"too_large"})
                continue
            final.append({"rel":rel,"abs":str(f),"size":sz})
        except Exception:
            skipped.append({"path":str(f),"reason":"stat_failed"})
    return final, skipped

def _vsp_exp2_make_zip(run_dir, rid):
    import io, json, time, zipfile
    from pathlib import Path
    rd = Path(str(run_dir))
    files, skipped = _vsp_exp2_collect_files(rd)
    note = {
        "rid": rid,
        "run_dir": str(rd),
        "exported_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "files_count": len(files),
        "skipped": skipped,
        "policy": {"max_file_bytes": 50*1024*1024},
    }
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("_export_note.json", json.dumps(note, ensure_ascii=False, indent=2))
        for it in files:
            try:
                z.write(it["abs"], arcname=it["rel"])
            except Exception:
                pass
    return buf.getvalue()

def _vsp_exp2_pdf_minimal(title, lines):
    # Minimal PDF generator (Helvetica), no external deps.
    # Enough for executive summary export.
    def esc(x):
        x = (x or "")
        return x.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")[:140]

    y=760
    stream=[f"BT /F1 14 Tf 50 {y} Td ({esc(title)}) Tj ET"]
    y-=24
    for ln in lines[:32]:
        stream.append(f"BT /F1 10 Tf 50 {y} Td ({esc(ln)}) Tj ET")
        y-=14
    stream_bytes=("\n".join(stream)).encode("utf-8")

    objs=[]
    objs.append(b"1 0 obj<< /Type /Catalog /Pages 2 0 R >>endobj\n")
    objs.append(b"2 0 obj<< /Type /Pages /Kids [3 0 R] /Count 1 >>endobj\n")
    objs.append(b"3 0 obj<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources<< /Font<< /F1 4 0 R >> >> /Contents 5 0 R >>endobj\n")
    objs.append(b"4 0 obj<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>endobj\n")
    objs.append(("5 0 obj<< /Length %d >>stream\n" % len(stream_bytes)).encode("ascii") + stream_bytes + b"\nendstream\nendobj\n")

    header=b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
    out=bytearray(); out+=header
    offsets=[0]
    for o in objs:
        offsets.append(len(out))
        out+=o
    xref_pos=len(out)
    out+=b"xref\n0 6\n"
    out+=b"0000000000 65535 f \n"
    for off in offsets[1:]:
        out+=("%010d 00000 n \n" % off).encode("ascii")
    out+=b"trailer<< /Size 6 /Root 1 0 R >>\nstartxref\n"
    out+=(str(xref_pos).encode("ascii")+b"\n%%EOF\n")
    return bytes(out)

def _vsp_exp2_make_pdf(run_dir, rid):
    import json
    from pathlib import Path
    rd = Path(str(run_dir))
    gate={}
    for cand in ["run_gate.json","reports/run_gate.json"]:
        f=rd/cand
        if f.exists():
            try:
                gate=json.loads(f.read_text(encoding="utf-8", errors="replace"))
                break
            except Exception:
                pass
    overall = gate.get("overall") or gate.get("overall_status") or "UNKNOWN"
    lines=[f"Run ID: {rid}", f"Run dir: {rd}", f"Overall: {overall}"]
    return _vsp_exp2_pdf_minimal("VSP Executive Summary", lines)

class _VSPExportWSGI2:
    def __init__(self, inner):
        self.inner = inner

    def __call__(self, environ, start_response):
        import time, traceback
        path = environ.get("PATH_INFO") or ""
        method = (environ.get("REQUEST_METHOD") or "GET").upper()

        if path == "/runs" and method == "GET":
            try:
                body = _vsp_exp2_runs_html_bytes()
                return _vsp_exp2_resp(start_response, "200 OK", body, "text/html; charset=utf-8")
            except Exception as e:
                return _vsp_exp2_json(start_response, {"ok": False, "degraded": True, "error": str(e), "trace": traceback.format_exc()[-1000:], "ts": int(time.time())})

        if path == "/api/vsp/run_export_zip" and method == "GET":
            try:
                q=_vsp_exp2_qs(environ)
                rid=(q.get("rid") or [""])[0]
                rid2=_vsp_exp2_safe_rid(rid)
                if not rid2:
                    return _vsp_exp2_json(start_response, {"ok": False, "degraded": True, "error": "invalid_rid", "rid": rid, "ts": int(time.time())})
                rd=_vsp_exp2_guess_run_dir(rid2)
                if rd is None:
                    return _vsp_exp2_json(start_response, {"ok": False, "degraded": True, "error": "run_dir_not_found", "rid": rid2, "ts": int(time.time())})
                z=_vsp_exp2_make_zip(rd, rid2)
                fname = rid2 + "_evidence.zip"
                return _vsp_exp2_resp(start_response, "200 OK", z, "application/zip",
                                      extra=[("Content-Disposition", 'attachment; filename="%s"' % fname)])
            except Exception as e:
                return _vsp_exp2_json(start_response, {"ok": False, "degraded": True, "error": str(e), "trace": traceback.format_exc()[-1200:], "ts": int(time.time())})

        if path == "/api/vsp/run_export_pdf" and method == "GET":
            try:
                q=_vsp_exp2_qs(environ)
                rid=(q.get("rid") or [""])[0]
                rid2=_vsp_exp2_safe_rid(rid)
                if not rid2:
                    return _vsp_exp2_json(start_response, {"ok": False, "degraded": True, "error": "invalid_rid", "rid": rid, "ts": int(time.time())})
                rd=_vsp_exp2_guess_run_dir(rid2)
                if rd is None:
                    return _vsp_exp2_json(start_response, {"ok": False, "degraded": True, "error": "run_dir_not_found", "rid": rid2, "ts": int(time.time())})
                pdf=_vsp_exp2_make_pdf(rd, rid2)
                fname = rid2 + "_executive.pdf"
                return _vsp_exp2_resp(start_response, "200 OK", pdf, "application/pdf",
                                      extra=[("Content-Disposition", 'attachment; filename="%s"' % fname)])
            except Exception as e:
                return _vsp_exp2_json(start_response, {"ok": False, "degraded": True, "error": str(e), "trace": traceback.format_exc()[-1200:], "ts": int(time.time())})

        return self.inner(environ, start_response)

# Stackable wrap
try:
    application
except Exception:
    try:
        application = app
    except Exception:
        application = None

if application is not None:
    if not getattr(application, "_vsp_export2_wrapped", False):
        w = _VSPExportWSGI2(application)
        setattr(w, "_vsp_export2_wrapped", True)
        application = w
# ===================== /VSP_P1_EXPORT_ZIP_PDF_AND_RUNS_FIX_WSGI_V1B =====================

# ===================== VSP_P0_RID_LATEST_GATE_ROOT_API_V2_REASON_V1 =====================
# WSGI intercept for /api/vsp/rid_latest_gate_root that always picks the latest run WITH details.
try:
    import json as _json
    import os as _os
    import glob as _glob
    import time as _time

    _VSP_RID_ROOTS = [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
    ]

    _VSP_SKIP = set(["kics","bandit","trivy","grype","semgrep","gitleaks","codeql","reports","out","out_ci","tmp","cache"])

    def _vsp_csv_has_2_lines(path: str) -> bool:
        try:
            if (not _os.path.isfile(path)) or _os.path.getsize(path) < 120:
                return False
            n = 0
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for _ in f:
                    n += 1
                    if n >= 2:
                        return True
            return False
        except Exception:
            return False

    def _vsp_sarif_has_results(path: str) -> bool:
        try:
            if (not _os.path.isfile(path)) or _os.path.getsize(path) < 200:
                return False
            j = _json.load(open(path, "r", encoding="utf-8", errors="ignore"))
            for run in (j.get("runs") or []):
                if (run.get("results") or []):
                    return True
            return False
        except Exception:
            return False

    def _vsp_looks_like_rid(name: str) -> bool:
        if not name or name.startswith("."):
            return False
        if name in _VSP_SKIP:
            return False
        return name.startswith(("VSP_CI_","RUN_","RUN-","VSP_"))

    def _vsp_is_run_dir(rid: str, run_dir: str) -> bool:
        if not _os.path.isdir(run_dir):
            return False
        if _vsp_looks_like_rid(rid):
            return True
        # accept weird names if they contain run artifacts
        if _os.path.isfile(_os.path.join(run_dir, "run_gate_summary.json")) or _os.path.isfile(_os.path.join(run_dir, "run_manifest.json")):
            return True
        return False

    def _vsp_has_details(run_dir: str) -> str:
        fu = _os.path.join(run_dir, "findings_unified.json")
        try:
            if _os.path.isfile(fu) and _os.path.getsize(fu) > 500:
                return "findings_unified.json"
        except Exception:
            pass

        csvp = _os.path.join(run_dir, "reports", "findings_unified.csv")
        if _vsp_csv_has_2_lines(csvp):
            return "reports/findings_unified.csv"

        sarifp = _os.path.join(run_dir, "reports", "findings_unified.sarif")
        if _vsp_sarif_has_results(sarifp):
            return "reports/findings_unified.sarif"

        pats = [
            "semgrep/**/*.json","grype/**/*.json","trivy/**/*.json","kics/**/*.json",
            "bandit/**/*.json","gitleaks/**/*.json","codeql/**/*.sarif",
            "**/*semgrep*.json","**/*grype*.json","**/*trivy*.json",
            "**/*kics*.json","**/*bandit*.json","**/*gitleaks*.json","**/*codeql*.sarif",
        ]
        for pat in pats:
            for f in _glob.glob(_os.path.join(run_dir, pat), recursive=True):
                try:
                    if _os.path.getsize(f) > 800:
                        rel = _os.path.relpath(f, run_dir).replace("\\","/")
                        if rel == "reports/findings_unified.sarif":
                            continue
                        return rel
                except Exception:
                    continue
        return ""

    def _vsp_pick_latest_with_details(max_scan: int = 500):
        best = None  # (mtime, rid, root, why)
        for root in _VSP_RID_ROOTS:
            if not _os.path.isdir(root):
                continue
            cands = []
            for rid in _os.listdir(root):
                run_dir = _os.path.join(root, rid)
                if not _vsp_is_run_dir(rid, run_dir):
                    continue
                try:
                    mtime = int(_os.path.getmtime(run_dir))
                except Exception:
                    mtime = 0
                cands.append((mtime, rid, run_dir))
            cands.sort(reverse=True)
            for mtime, rid, run_dir in cands[:max_scan]:
                why = _vsp_has_details(run_dir)
                if why:
                    cand = (mtime, rid, root, why)
                    if best is None or cand[0] > best[0]:
                        best = cand
                    break
        return best

    def _vsp_pick_latest_existing():
        best = None  # (mtime, rid, root)
        for root in _VSP_RID_ROOTS:
            if not _os.path.isdir(root):
                continue
            cands = []
            for rid in _os.listdir(root):
                run_dir = _os.path.join(root, rid)
                if not _vsp_is_run_dir(rid, run_dir):
                    continue
                try:
                    cands.append((int(_os.path.getmtime(run_dir)), rid, root))
                except Exception:
                    cands.append((0, rid, root))
            cands.sort(reverse=True)
            if cands and (best is None or cands[0][0] > best[0]):
                best = cands[0]
        return best

    def _vsp_rid_latest_payload():
        best = _vsp_pick_latest_with_details()
        if best:
            _, rid, _root, why = best
            return {
                "ok": True,
                "rid": rid,
                "gate_root": "gate_root_" + rid,
                "roots": _VSP_RID_ROOTS,
                "reason": "latest_with_details",
                "why": why,
                "ts": int(_time.time()),
            }
        fb = _vsp_pick_latest_existing()
        if fb:
            _, rid, _root = fb
            return {
                "ok": True,
                "rid": rid,
                "gate_root": "gate_root_" + rid,
                "roots": _VSP_RID_ROOTS,
                "reason": "latest_existing_fallback_no_details",
                "why": "",
                "ts": int(_time.time()),
            }
        return {
            "ok": False,
            "rid": "",
            "gate_root": "",
            "roots": _VSP_RID_ROOTS,
            "reason": "no_runs_found",
            "why": "",
            "ts": int(_time.time()),
        }

    def _vsp_wsgi_json(start_response, payload, code="200 OK"):
        body = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = [
            ("Content-Type", "application/json; charset=utf-8"),
            ("Cache-Control", "no-store"),
            ("Content-Length", str(len(body))),
        ]
        start_response(code, headers)
        return [body]

    def _wrap(_app):
        def _mw(environ, start_response):
            path = environ.get("PATH_INFO", "") or ""
            if path in ("/api/vsp/rid_latest_gate_root", "/api/vsp/rid_latest_gate_root.json"):
                payload = _vsp_rid_latest_payload()
                return _vsp_wsgi_json(start_response, payload, "200 OK")
            return _app(environ, start_response)
        return _mw

    # wrap whichever callable exists
    if "app" in globals() and callable(globals().get("app")):
        app = _wrap(app)
    if "application" in globals() and callable(globals().get("application")):
        application = _wrap(application)

    print("[VSP_P0_RID_LATEST_GATE_ROOT_API_V2] enabled")
except Exception as _e:
    print("[VSP_P0_RID_LATEST_GATE_ROOT_API_V2] ERROR:", _e)
# ===================== /VSP_P0_RID_LATEST_GATE_ROOT_API_V2_REASON_V1 =====================




# ===================== VSP_P0_TABS_COMMERCIAL_HEADERS_V1 =====================
# Add enterprise headers (security + cache) for 3 tabs (runs/data_source/settings) & static.
try:
    def _add_hdrs(path, status, headers):
        h = [(k, v) for (k, v) in headers if k and v]
        keys = {k.lower() for (k, _) in h}

        # Security headers (safe defaults)
        def put(k, v):
            lk = k.lower()
            nonlocal h, keys
            if lk not in keys:
                h.append((k, v)); keys.add(lk)

        put("X-Content-Type-Options", "nosniff")
        put("X-Frame-Options", "DENY")
        put("Referrer-Policy", "no-referrer")
        put("Permissions-Policy", "geolocation=(), microphone=(), camera=()")

        # Cache policy
        lp = (path or "").lower()
        is_static = lp.startswith("/static/") or lp.startswith("/out_ci/")
        if is_static:
            # allow caching static assets (browser side)
            # keep "no-store" away from static
            # only set if not already present
            if "cache-control" not in keys:
                h.append(("Cache-Control", "public, max-age=86400"))
        else:
            # HTML & API should not be cached by default
            # (avoid stale UI + security)
            if "cache-control" in keys:
                # keep existing if it's already no-store
                pass
            else:
                h.append(("Cache-Control", "no-store"))


        # CSP Report-Only (safe, non-breaking; for HTML tabs only)
        # VSP_P1_CSP_REPORT_ONLY_V2_FORCE
        if (path or "") in ("/runs","/data_source","/settings","/vsp5"):
            if "content-security-policy-report-only" not in keys:
                h.append(("Content-Security-Policy-Report-Only",
                          "default-src 'self'; img-src 'self' data:; "
                          "style-src 'self' 'unsafe-inline'; "
                          "script-src 'self' 'unsafe-inline'; "
                          "connect-src 'self'; font-src 'self' data:; "
                          "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"))
                keys.add("content-security-policy-report-only")

        return h

    def _wrap_headers(inner):
        def _wsgi(environ, start_response):
            path = environ.get("PATH_INFO", "") or ""
            def _sr(status, headers, exc_info=None):
                headers2 = _add_hdrs(path, status, headers or [])
                return start_response(status, headers2, exc_info)
            return inner(environ, _sr)
        return _wsgi

    if "app" in globals() and callable(globals().get("app")):
        app = _wrap_headers(app)
    if "application" in globals() and callable(globals().get("application")):
        application = _wrap_headers(application)

    print("[VSP_P0_TABS_COMMERCIAL_HEADERS_V1] enabled")
except Exception as _e:
    print("[VSP_P0_TABS_COMMERCIAL_HEADERS_V1] ERROR:", _e)
# ===================== /VSP_P0_TABS_COMMERCIAL_HEADERS_V1 =====================


# ===================== VSP_P0_UI_STATUS_V1 =====================
# Ops endpoint: quick health of 3 tabs + core API (NO dashboard dependency).
# Commercial rule: NEVER 500. Always return JSON 200.
# Implementation: INTERNAL WSGI subrequests (no loopback HTTP).
try:
    import json, time, traceback, io, sys

    def _json_resp(start_response, obj):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        start_response("200 OK", [
            ("Content-Type","application/json; charset=utf-8"),
            ("Cache-Control","no-store"),
            ("Content-Length", str(len(b))),
        ])
        return [b]

    def _wsgi_call(inner, path, method="GET", query_string="", max_read=400000):
        qs = query_string or ""
        uri = path + (("?" + qs) if qs else "")
        env = {
            "REQUEST_METHOD": method,
            "PATH_INFO": path,
            "QUERY_STRING": qs,
            "SCRIPT_NAME": "",
            "SERVER_PROTOCOL": "HTTP/1.1",
            "SERVER_NAME": "127.0.0.1",
            "SERVER_PORT": "8910",
            "REMOTE_ADDR": "127.0.0.1",
            "REQUEST_URI": uri,
            "RAW_URI": uri,
            "wsgi.version": (1, 0),
            "wsgi.url_scheme": "http",
            "wsgi.input": io.BytesIO(b""),
            "wsgi.errors": sys.stderr,
            "wsgi.multithread": True,
            "wsgi.multiprocess": True,
            "wsgi.run_once": False,
            "HTTP_HOST": "127.0.0.1:8910",
            "HTTP_USER_AGENT": "VSP-UI-Status/1.3",
            "HTTP_ACCEPT": "*/*",
            "HTTP_ACCEPT_LANGUAGE": "en-US,en;q=0.9",
            "HTTP_CONNECTION": "close",
        }

        status_line = {"v": "500 INTERNAL"}
        headers = {"v": []}
        def _sr(st, hdrs, exc_info=None):
            status_line["v"] = st
            headers["v"] = hdrs or []
            return None

        t0 = time.time()
        body = b""
        err = None
        try:
            it = inner(env, _sr)
            for chunk in it or []:
                if not chunk:
                    continue
                if isinstance(chunk, str):
                    chunk = chunk.encode("utf-8","replace")
                body += chunk
                if len(body) >= max_read:
                    break
            try:
                if hasattr(it, "close"):
                    it.close()
            except Exception:
                pass
        except Exception as e:
            err = str(e)

        ms = int((time.time() - t0) * 1000)
        try:
            code = int((status_line["v"].split(" ", 1)[0] or "0").strip())
        except Exception:
            code = None

        hdr_map = {}
        try:
            for k, v in (headers["v"] or []):
                if k:
                    hdr_map[str(k).lower()] = str(v)
        except Exception:
            pass

        # Return full body for small JSON only (release_latest JSON is small)
        body_text = None
        ct = (hdr_map.get("content-type","") or "").lower()
        if method != "HEAD" and body and ("application/json" in ct) and len(body) <= 200000:
            body_text = body.decode("utf-8","replace")

        return {"method": method, "path": path, "qs": qs, "code": code, "ms": ms,
                "bytes": len(body), "err": err, "ct": hdr_map.get("content-type"), "body_text": body_text}

    def _wrap_ui_status(inner):
        def _wsgi(environ, start_response):
            if (environ.get("PATH_INFO","") or "") != "/api/vsp/ui_status_v1":
                return inner(environ, start_response)
            try:
                checks = {}
                warn = []
                fails = []

                # REQUIRED: 3 tabs + runs api
                checks["tab:/runs"] = _wsgi_call(inner, "/runs", "GET", max_read=800000)
                checks["tab:/data_source"] = _wsgi_call(inner, "/data_source", "GET", max_read=200000)
                checks["tab:/settings"] = _wsgi_call(inner, "/settings", "GET", max_read=200000)
                checks["api:/api/vsp/runs?limit=1"] = _wsgi_call(inner, "/api/vsp/runs", "GET", "limit=1", max_read=120000)

                # OPTIONAL (WARN only): release_latest + download head
                checks["api:/api/vsp/release_latest"] = _wsgi_call(inner, "/api/vsp/release_latest", "GET", "", max_read=200000)
                rel = None
                try:
                    bt = checks["api:/api/vsp/release_latest"].get("body_text")
                    if bt and bt.lstrip().startswith("{"):
                        j = json.loads(bt)
                        if isinstance(j, dict):
                            rel = j.get("release_pkg") or None
                except Exception:
                    rel = None
                if rel:
                    checks["release:download_head"] = _wsgi_call(inner, "/api/vsp/release_pkg_download", "HEAD", "path=" + rel, max_read=1)

                def need200(k):
                    v = checks.get(k, {})
                    if v.get("code") != 200:
                        fails.append({"check": k, "reason": f"code={v.get('code')}", "err": v.get("err")})

                def need_bytes_ge(k, n):
                    v = checks.get(k, {})
                    if v.get("code") == 200 and int(v.get("bytes") or 0) < n:
                        fails.append({"check": k, "reason": f"bytes<{n}", "bytes": v.get("bytes")})

                # Required gates
                need200("tab:/runs");        need_bytes_ge("tab:/runs", 3000)
                need200("tab:/data_source"); need_bytes_ge("tab:/data_source", 500)
                need200("tab:/settings");    need_bytes_ge("tab:/settings", 500)
                need200("api:/api/vsp/runs?limit=1")

                # Optional warn
                if checks["api:/api/vsp/release_latest"].get("code") != 200:
                    warn.append({"check":"api:/api/vsp/release_latest","reason":f"code={checks['api:/api/vsp/release_latest'].get('code')}"})

                out = {
                    "ok": (len(fails) == 0),
                    "ts": int(time.time()),
                    "fails": fails,
                    "warn": warn,
                    "checks": {k: {kk: vv for kk, vv in v.items() if kk != "body_text"} for k, v in checks.items()},
                }
                return _json_resp(start_response, out)
            except Exception as e:
                return _json_resp(start_response, {"ok": False, "ts": int(time.time()), "err": str(e), "tb": traceback.format_exc(limit=8)})
        return _wsgi

    # apply wrapper last
    if "application" in globals() and callable(globals().get("application")):
        application = _wrap_ui_status(application)
    if "app" in globals() and callable(globals().get("app")):
        app = _wrap_ui_status(app)

    print("[VSP_P0_UI_STATUS_V1] enabled v3c (internal wsgi + warn)")
except Exception as _e:
    print("[VSP_P0_UI_STATUS_V1] ERROR:", _e)
# ===================== /VSP_P0_UI_STATUS_V1 =====================


# ===================== VSP_P1_CSP_REPORT_ONLY_V1 =====================
# Add CSP in Report-Only mode for HTML pages (safe, non-breaking).
try:
    _CSP_RO = "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; " \
              "script-src 'self' 'unsafe-inline'; connect-src 'self'; font-src 'self' data:; " \
              "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"

    def _wrap_csp_ro(inner):
        def _wsgi(environ, start_response):
            path = environ.get("PATH_INFO","") or ""
            def _sr(status, headers, exc_info=None):
                h = list(headers or [])
                # Only for HTML routes (tabs). Keep APIs untouched.
                if path in ("/runs","/data_source","/settings","/vsp5"):
                    h.append(("Content-Security-Policy-Report-Only", _CSP_RO))
                return start_response(status, h, exc_info)
            return inner(environ, _sr)
        return _wsgi

    if "application" in globals() and callable(globals().get("application")):
        application = _wrap_csp_ro(application)
    if "app" in globals() and callable(globals().get("app")):
        app = _wrap_csp_ro(app)

    print("[VSP_P1_CSP_REPORT_ONLY_V1] enabled")
except Exception as _e:
    print("[VSP_P1_CSP_REPORT_ONLY_V1] ERROR:", _e)
# ===================== /VSP_P1_CSP_REPORT_ONLY_V1 =====================


# ===================== VSP_P1_AUDIT_PACK_DOWNLOAD_V1 =====================
# Upgraded to V2: build pack via internal WSGI calls to /api/vsp/run_file_allow (no filesystem RID lookup).
# API: /api/vsp/audit_pack_download?rid=<RID>&lite=1(optional)
# NEVER 500: always returns tgz or JSON error 200.
try:
    import io, json, tarfile, time, traceback
    from urllib.parse import parse_qs, quote_plus

    def _json200(start_response, obj):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        start_response("200 OK", [
            ("Content-Type","application/json; charset=utf-8"),
            ("Cache-Control","no-store"),
            ("Content-Length", str(len(b))),
        ])
        return [b]

    def _call_internal(inner, path, qs="", method="GET", max_read=50_000_000):
        # Internal WSGI subrequest (no loopback HTTP)
        import io as _io, sys as _sys
        env = {
            "REQUEST_METHOD": method,
            "PATH_INFO": path,
            "QUERY_STRING": qs or "",
            "SCRIPT_NAME": "",
            "SERVER_PROTOCOL": "HTTP/1.1",
            "SERVER_NAME": "127.0.0.1",
            "SERVER_PORT": "8910",
            "REMOTE_ADDR": "127.0.0.1",
            "wsgi.version": (1,0),
            "wsgi.url_scheme": "http",
            "wsgi.input": _io.BytesIO(b""),
            "wsgi.errors": _sys.stderr,
            "wsgi.multithread": True,
            "wsgi.multiprocess": True,
            "wsgi.run_once": False,
            "HTTP_HOST": "127.0.0.1:8910",
            "HTTP_USER_AGENT": "VSP-AuditPack/2.0",
            "HTTP_ACCEPT": "*/*",
            "HTTP_CONNECTION": "close",
        }
        st = {"v":"500 INTERNAL"}
        hdrs = {"v":[]}
        def _sr(status, headers, exc_info=None):
            st["v"] = status
            hdrs["v"] = headers or []
            return None

        t0 = time.time()
        body = b""
        err = None
        try:
            it = inner(env, _sr)
            for chunk in it or []:
                if not chunk:
                    continue
                if isinstance(chunk, str):
                    chunk = chunk.encode("utf-8","replace")
                body += chunk
                if len(body) >= max_read:
                    break
            try:
                if hasattr(it, "close"): it.close()
            except Exception:
                pass
        except Exception as e:
            err = str(e)

        ms = int((time.time()-t0)*1000)
        try:
            code = int((st["v"].split(" ",1)[0] or "0").strip())
        except Exception:
            code = None
        # headers map
        hm = {}
        try:
            for k,v in (hdrs["v"] or []):
                if k:
                    hm[str(k).lower()] = str(v)
        except Exception:
            pass
        return {"code": code, "ms": ms, "body": body, "err": err, "hdr": hm}

    def _wrap_audit_pack(inner):
        def _wsgi(environ, start_response):
            if (environ.get("PATH_INFO","") or "") != "/api/vsp/audit_pack_download":
                return inner(environ, start_response)
            try:
                qs = parse_qs(environ.get("QUERY_STRING","") or "")
                rid = (qs.get("rid") or [""])[0].strip()
                lite = (qs.get("lite") or [""])[0].strip() in ("1","true","yes","on")
                if not rid:
                    return _json200(start_response, {"ok": False, "err": "missing rid"})

                # files to fetch via run_file_allow
                items = [
                    ("run_gate_summary.json", "run_gate_summary.json"),
                    ("run_gate.json", "run_gate.json"),
                    ("SUMMARY.txt", "SUMMARY.txt"),
                    ("run_manifest.json", "run_manifest.json"),
                    ("run_evidence_index.json", "run_evidence_index.json"),
                    ("reports/findings_unified.csv", "reports/findings_unified.csv"),
                    ("reports/findings_unified.sarif", "reports/findings_unified.sarif"),
                    ("reports/findings_unified.html", "reports/findings_unified.html"),
                    ("reports/findings_unified.pdf", "reports/findings_unified.pdf"),
                ]
                if not lite:
                    items.insert(0, ("findings_unified.json", "findings_unified.json"))

                included = []
                missing = []
                errors = []

                bio = io.BytesIO()
                with tarfile.open(fileobj=bio, mode="w:gz") as tf:
                    for path, arc in items:
                        q = f"rid={quote_plus(rid)}&path={quote_plus(path)}"
                        r = _call_internal(inner, "/api/vsp/run_file_allow", qs=q, method="GET", max_read=60_000_000)
                        if r.get("code") != 200 or r.get("err"):
                            errors.append({"path": path, "code": r.get("code"), "err": r.get("err")})
                            continue

                        body = r.get("body") or b""
                        if not body:
                            missing.append({"path": path, "reason": "empty"})
                            continue

                        # run_file_allow usually returns JSON-parsed content (already JSON body), or {"ok":false,...}
                        is_json = ("application/json" in (r.get("hdr",{}).get("content-type","").lower()))
                        if is_json:
                            try:
                                j = json.loads(body.decode("utf-8","replace"))
                                if isinstance(j, dict) and j.get("ok") is False and ("err" in j or "error" in j):
                                    missing.append({"path": path, "reason": j.get("err") or j.get("error")})
                                    continue
                                body = json.dumps(j, ensure_ascii=False, indent=2).encode("utf-8")
                            except Exception:
                                # keep raw
                                pass

                        info = tarfile.TarInfo(name=arc)
                        info.size = len(body)
                        info.mtime = int(time.time())
                        tf.addfile(info, io.BytesIO(body))
                        included.append({"path": path, "arc": arc, "bytes": len(body)})

                    manifest = {
                        "ok": True,
                        "rid": rid,
                        "lite": lite,
                        "included": included,
                        "missing": missing,
                        "errors": errors,
                        "ts": int(time.time()),
                    }
                    mb = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
                    mi = tarfile.TarInfo(name="manifest.json")
                    mi.size = len(mb)
                    mi.mtime = int(time.time())
                    tf.addfile(mi, io.BytesIO(mb))

                data = bio.getvalue()
                name = f"audit_pack_{rid}.tgz" if not lite else f"audit_pack_{rid}_lite.tgz"
                start_response("200 OK", [
                    ("Content-Type", "application/gzip"),
                    ("Content-Disposition", f'attachment; filename="{name}"'),
                    ("Cache-Control","no-store"),
                    ("X-VSP-AUDIT-PACK","2"),
                    ("Content-Length", str(len(data))),
                ])
                return [data]

            except Exception as e:
                return _json200(start_response, {"ok": False, "err": str(e), "tb": traceback.format_exc(limit=6)})
        return _wsgi

    # wrap last
    if "application" in globals() and callable(globals().get("application")):
        application = _wrap_audit_pack(application)
    if "app" in globals() and callable(globals().get("app")):
        app = _wrap_audit_pack(app)

    print("[VSP_P1_AUDIT_PACK_DOWNLOAD_V2] enabled")
except Exception as _e:
    print("[VSP_P1_AUDIT_PACK_DOWNLOAD_V2] ERROR:", _e)
# ===================== /VSP_P1_AUDIT_PACK_DOWNLOAD_V1 =====================

# ===================== VSP_P1_EXPORT_HEAD_SUPPORT_WSGI_V1C =====================
# Make HEAD behave like GET for existence probes:
# - HEAD /runs
# - HEAD /api/vsp/run_export_zip?rid=...
# - HEAD /api/vsp/run_export_pdf?rid=...
# Always 200 for these endpoints (commercial probe-friendly), never crashes gunicorn.

def _vsp_head_no_store(extra=None):
    h = [("Cache-Control","no-store"),("Pragma","no-cache"),("Expires","0")]
    if extra:
        h.extend(extra)
    return h

def _vsp_head_start(start_response, ctype, clen="0", extra=None):
    headers = [("Content-Type", ctype), ("Content-Length", str(clen))]
    headers += _vsp_head_no_store(extra)
    start_response("200 OK", headers)
    return [b""]  # HEAD must not return body

def _vsp_head_qs(environ):
    from urllib.parse import parse_qs
    return parse_qs(environ.get("QUERY_STRING") or "", keep_blank_values=True)

def _vsp_head_safe_rid(rid):
    import re
    if not isinstance(rid, str):
        return None
    rid = rid.strip()
    if re.match(r"^RUN_\d{8}_\d{6}([A-Za-z0-9_.-]+)?$", rid):
        return rid
    return None

def _vsp_head_guess_run_dir(rid):
    # reuse if already defined
    try:
        return _vsp_exp2_guess_run_dir(rid)  # type: ignore
    except Exception:
        pass
    import os
    from pathlib import Path
    roots = []
    env_root = os.environ.get("VSP_OUT_ROOT") or os.environ.get("SECURITY_BUNDLE_OUT_ROOT")
    if env_root:
        roots.append(env_root)
    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]
    for r in roots:
        pr = Path(r)
        cand = pr / rid
        if cand.is_dir():
            return cand
    return None

def _vsp_head_runs_len():
    # compute expected HTML length (for Content-Length)
    try:
        b = _vsp_exp2_runs_html_bytes()  # type: ignore
        return len(b)
    except Exception:
        pass
    import time
    from pathlib import Path
    cands = [
        "templates/vsp_runs_reports_v1.html",
        "templates/vsp_runs_reports.html",
        "templates/vsp_runs.html",
    ]
    for c in cands:
        f = Path(c)
        if f.exists():
            html = f.read_text(encoding="utf-8", errors="replace")
            v = str(int(time.time()))
            html = html.replace("{{ asset_v }}", v).replace("{{asset_v}}", v)
            return len(html.encode("utf-8"))
    return 0

def _vsp_head_pdf_len(run_dir, rid):
    # if export code exists, compute actual pdf length; else give a small sane default
    try:
        pdf = _vsp_exp2_make_pdf(run_dir, rid)  # type: ignore
        return len(pdf)
    except Exception:
        pass
    return 1200

def _vsp_head_zip_len(run_dir, rid):
    # zip can be heavy to compute for HEAD; return 0 (still ok for probe)
    try:
        z = _vsp_exp2_make_zip(run_dir, rid)  # type: ignore
        return len(z)
    except Exception:
        pass
    return 0

class _VSPExportHeadWSGI:
    def __init__(self, inner):
        self.inner = inner

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO") or ""
        method = (environ.get("REQUEST_METHOD") or "GET").upper()

        if method == "HEAD":
            # /runs
            if path == "/runs":
                clen = _vsp_head_runs_len()
                return _vsp_head_start(start_response, "text/html; charset=utf-8", clen=str(clen))

            # export endpoints (always 200 for probe)
            if path in ("/api/vsp/run_export_zip", "/api/vsp/run_export_pdf"):
                q = _vsp_head_qs(environ)
                rid = (q.get("rid") or [""])[0]
                rid2 = _vsp_head_safe_rid(rid)

                # invalid rid → 200 JSON (probe-friendly)
                if not rid2:
                    return _vsp_head_start(start_response, "application/json; charset=utf-8", clen="0")

                rd = _vsp_head_guess_run_dir(rid2)
                if rd is None:
                    return _vsp_head_start(start_response, "application/json; charset=utf-8", clen="0")

                if path.endswith("_pdf"):
                    clen = _vsp_head_pdf_len(rd, rid2)
                    fname = rid2 + "_executive.pdf"
                    return _vsp_head_start(
                        start_response,
                        "application/pdf",
                        clen=str(clen),
                        extra=[("Content-Disposition", 'attachment; filename="%s"' % fname)]
                    )

                # zip
                clen = _vsp_head_zip_len(rd, rid2)
                fname = rid2 + "_evidence.zip"
                return _vsp_head_start(
                    start_response,
                    "application/zip",
                    clen=str(clen),
                    extra=[("Content-Disposition", 'attachment; filename="%s"' % fname)]
                )

        return self.inner(environ, start_response)

# Stackable wrap
try:
    application
except Exception:
    try:
        application = app
    except Exception:
        application = None

if application is not None:
    if not getattr(application, "_vsp_export_head_wrapped_v1c", False):
        w = _VSPExportHeadWSGI(application)
        setattr(w, "_vsp_export_head_wrapped_v1c", True)
        application = w
# ===================== VSP_P1_WSGI_MW_GATE_FILENAME_V1 =====================
# P1 polish: keep P0 alias, but fix Content-Disposition filename to match requested path.
try:
  from urllib.parse import parse_qs, urlencode

  class _VSPAliasReportsGateMW:
    def __init__(self, app):
      self.app = app

    def __call__(self, environ, start_response):
      orig_path = None

      # wrap start_response to adjust filename when needed
      def _sr(status, headers, exc_info=None):
        try:
          op = environ.get("_VSP_ORIG_RUNFILE_PATH") or ""
          if op in ("run_gate.json", "reports/run_gate.json"):
            new_headers = []
            for (k, v) in headers:
              if k.lower() == "content-disposition" and "__run_gate_summary.json" in (v or ""):
                new_headers.append((k, (v or "").replace("__run_gate_summary.json", "__run_gate.json")))
              else:
                new_headers.append((k, v))
            headers = new_headers
        except Exception:
          pass
        return start_response(status, headers, exc_info)

      try:
        if (environ.get("PATH_INFO","") or "") == "/api/vsp/run_file_allow":
          qs = environ.get("QUERY_STRING","") or ""
          q = parse_qs(qs, keep_blank_values=True)
          path = (q.get("path") or [None])[0]
          if path:
            orig_path = path.replace("\\","/").lstrip("/")
            environ["_VSP_ORIG_RUNFILE_PATH"] = orig_path

          # P0 alias: reports/run_gate*.json -> root gate*.json
          if orig_path in ("reports/run_gate_summary.json", "reports/run_gate.json"):
            q["path"] = [orig_path.split("/", 1)[1]]
            environ["QUERY_STRING"] = urlencode(q, doseq=True)
      except Exception:
        pass

      return self.app(environ, _sr)

  if "application" in globals() and callable(globals().get("application")):
    application = _VSPAliasReportsGateMW(application)
except Exception:
  pass
# ===================== /VSP_P1_WSGI_MW_GATE_FILENAME_V1 =====================
# ===================== /VSP_P1_EXPORT_HEAD_SUPPORT_WSGI_V1C =====================

# ===================== VSP_P0_RELEASE_IDENTITY_EXPORTS_AFTERREQ_V1 =====================
# P0: attach release identity headers + normalize export filenames with _rel-<ts>_sha-<12> (or _norel-... fallback)
try:
    from flask import request
except Exception:
    request = None

import os, json, time, re
from pathlib import Path

__vsp_rel_cache = {"t": 0.0, "meta": None}
__vsp_rel_cache_ttl = float(os.environ.get("VSP_RELEASE_CACHE_TTL", "5.0"))

def __vsp_now_ts():
    return time.strftime("%Y%m%d_%H%M%S", time.localtime())

def __vsp_pick_release_latest_json():
    # precedence: env -> common absolute -> relative
    envp = os.environ.get("VSP_RELEASE_LATEST_JSON")
    cands = []
    if envp:
        cands.append(envp)
    cands += [
        "/home/test/Data/SECURITY_BUNDLE/out_ci/releases/release_latest.json",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/releases/release_latest.json",
        str(Path(".") / "out_ci" / "releases" / "release_latest.json"),
        str(Path(".") / "out" / "releases" / "release_latest.json"),
    ]
    for x in cands:
        try:
            xp = Path(x)
            if xp.is_file() and xp.stat().st_size > 0:
                return xp
        except Exception:
            pass
    return None

def __vsp_read_release_latest():
    rp = __vsp_pick_release_latest_json()
    if not rp:
        return None
    try:
        return json.loads(rp.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return None

def __vsp_release_meta():
    # tiny cache to avoid IO per request
    now = time.time()
    if __vsp_rel_cache["meta"] is not None and (now - __vsp_rel_cache["t"]) < __vsp_rel_cache_ttl:
        return __vsp_rel_cache["meta"]

    j = __vsp_read_release_latest() or {}
    # accept several possible shapes
    rel_ts  = str(j.get("release_ts") or j.get("ts") or j.get("built_ts") or "").strip()
    rel_sha = str(j.get("release_sha") or j.get("sha") or j.get("git_sha") or j.get("commit") or "").strip()
    rel_pkg = str(j.get("release_pkg") or j.get("pkg") or j.get("package") or j.get("tgz") or "").strip()

    if rel_sha:
        rel_sha12 = re.sub(r"[^0-9a-fA-F]", "", rel_sha)[:12] or "unknown"
    else:
        rel_sha12 = "unknown"

    if not rel_ts:
        rel_ts = "norel-" + __vsp_now_ts()

    meta = {
        "release_ts": rel_ts,
        "release_sha": rel_sha,
        "release_sha12": rel_sha12,
        "release_pkg": rel_pkg or "-",
    }
    __vsp_rel_cache["t"] = now
    __vsp_rel_cache["meta"] = meta
    return meta

def __vsp_suffix(meta):
    # sanitize timestamp for filenames (avoid ':' '+' etc)
    ts_raw = (meta.get("release_ts") or "").strip()
    sha12 = meta.get("release_sha12") or "unknown"

    def _san(ts: str) -> str:
        t = (ts or "").strip()
        if not t:
            return ""
        # ISO-ish -> file-safe
        t = t.replace("T", "_")
        t = t.replace(":", "")
        t = t.replace("+", "p")   # +07:00 -> p0700
        # keep '-' (safe), remove other weird chars
        t = re.sub(r"[^0-9A-Za-z._-]+", "", t)
        return t

    ts = _san(ts_raw) or ("norel-" + __vsp_now_ts())

    if ts.startswith("norel-"):
        return f"_{ts}_sha-{sha12}"
    return f"_rel-{ts}_sha-{sha12}"

def __vsp_rewrite_filename(fn, meta):
    if not fn:
        return fn
    # already stamped?
    if ("_rel-" in fn) or ("_norel-" in fn):
        return fn
    suf = __vsp_suffix(meta)

    # insert before extension (last dot), but keep .tar.gz style intact
    lower = fn.lower()
    if lower.endswith(".tar.gz"):
        base = fn[:-7]
        return base + suf + ".tar.gz"
    if "." in fn:
        base, ext = fn.rsplit(".", 1)
        return base + suf + "." + ext
    return fn + suf

def __vsp_parse_cd_filename(cd):
    # supports: filename="x"; filename=x; filename*=UTF-8''x
    if not cd:
        return None
    m = re.search(r'filename\*\s*=\s*UTF-8\'\'([^;]+)', cd, flags=re.I)
    if m:
        return m.group(1).strip().strip('"').strip("'")
    m = re.search(r'filename\s*=\s*"([^"]+)"', cd, flags=re.I)
    if m:
        return m.group(1)
    m = re.search(r'filename\s*=\s*([^;]+)', cd, flags=re.I)
    if m:
        return m.group(1).strip().strip('"').strip("'")
    return None

def __vsp_is_attachment(cd):
    return bool(cd) and ("attachment" in cd.lower()) and ("filename" in cd.lower())

def __vsp_after_request(resp):
    try:
        meta = __vsp_release_meta()
        # Headers for audit/build identity
        resp.headers.setdefault("X-VSP-RELEASE-TS", meta.get("release_ts", "-"))
        resp.headers.setdefault("X-VSP-RELEASE-SHA", meta.get("release_sha", ""))
        resp.headers.setdefault("X-VSP-RELEASE-PKG", meta.get("release_pkg", "-"))

        # Rewrite only when it's an attachment (export/download)
        cd = resp.headers.get("Content-Disposition", "")
        if __vsp_is_attachment(cd):
            fn = __vsp_parse_cd_filename(cd)
            newfn = __vsp_rewrite_filename(fn, meta)
            if newfn and newfn != fn:
                # normalize to a simple, consistent header
                resp.headers["Content-Disposition"] = f'attachment; filename="{newfn}"'
        return resp
    except Exception:
        return resp
# register hook robustly (try multiple candidates: globals + vsp_demo_app + wrapped .app)
def __vsp_try_attach(obj, label="obj"):
    try:
        if not obj or not hasattr(obj, "after_request"):
            return False
        if getattr(obj, "__vsp_p0_relid_afterreq_v1", False):
            return True
        obj.after_request(__vsp_after_request)
        obj.__vsp_p0_relid_afterreq_v1 = True
        return True
    except Exception:
        return False

_candidates = []

# 1) common globals
for _k in ("app","application","flask_app","vsp_app"):
    _o = globals().get(_k)
    if _o and _o not in _candidates:
        _candidates.append(_o)

# 2) if application is a wrapper exposing .app (common)
try:
    _wrap = globals().get("application")
    _inner = getattr(_wrap, "app", None)
    if _inner and _inner not in _candidates:
        _candidates.append(_inner)
except Exception:
    pass

# 3) import vsp_demo_app (UI flask app usually lives here)
try:
    import vsp_demo_app as _vda
    for _k in ("app","application"):
        _o = getattr(_vda, _k, None)
        if _o and _o not in _candidates:
            _candidates.append(_o)
except Exception:
    pass

_attached = False
for _idx, _o in enumerate(_candidates):
    if __vsp_try_attach(_o, f"cand{_idx}"):
        _attached = True

# Optional debug (set env VSP_RELID_DEBUG=1)
try:
    import os
    if os.environ.get("VSP_RELID_DEBUG","") == "1":
        print("[VSP_RELID] candidates=", len(_candidates), "attached=", _attached)
except Exception:
    pass
# ===================== /VSP_P0_RELEASE_IDENTITY_EXPORTS_AFTERREQ_V1 =====================



# ===================== VSP_P2_RUNS_KPI_V2_ENDPOINT_V1 =====================
# Safe read-only aggregation endpoint (NO generic run_file). Small-file only.
try:
  import os, json, time, math, re
  from datetime import datetime, timedelta
  from flask import request, jsonify
except Exception:
  request = None
  jsonify = None

def _vsp_p2_pick_app():
  # try common globals
  for name in ("app", "application"):
    try:
      obj = globals().get(name)
      # flask app has .route or .get attribute
      if obj is not None and (hasattr(obj, "route") or hasattr(obj, "get")):
        return obj
    except Exception:
      pass
  return None

def _vsp_p2_safe_read_json(fp):
  try:
    with open(fp, "r", encoding="utf-8", errors="replace") as f:
      return json.load(f)
  except Exception:
    return None

def _vsp_p2_parse_day(name: str):
  try:
    m = re.search(r"(20\d{2})(\d{2})(\d{2})", name or "")
    if m:
      return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
  except Exception:
    pass
  return None

def _vsp_p2_norm_overall(v):
  if not v:
    return "UNKNOWN"
  vv = str(v).strip().upper()
  if vv in ("GREEN", "AMBER", "RED", "UNKNOWN"):
    return vv
  if vv in ("PASS", "OK", "SUCCESS"):
    return "GREEN"
  if vv in ("WARN", "WARNING"):
    return "AMBER"
  if vv in ("FAIL", "FAILED", "ERROR"):
    return "RED"
  return "UNKNOWN"

def _vsp_p2_pick_sev(j: dict):
  if not isinstance(j, dict):
    return {}
  # best-effort: common keys
  for k in ("by_severity", "severity", "counts_by_severity", "sev"):
    v = j.get(k)
    if isinstance(v, dict):
      return v
  c = j.get("counts")
  if isinstance(c, dict):
    v = c.get("by_severity")
    if isinstance(v, dict):
      return v
  return {}

def _vsp_p2_is_degraded(j: dict):
  if not isinstance(j, dict):
    return False
  if bool(j.get("degraded")):
    return True
  bt = j.get("by_type")
  if isinstance(bt, dict):
    for _, vv in bt.items():
      if isinstance(vv, dict) and bool(vv.get("degraded")):
        return True
  return False

def _vsp_p2_duration_s(run_dir: str):
  # best-effort only
  for name in ("run_manifest.json", "run_status.json", "run_status_v1.json"):
    fp = os.path.join(run_dir, name)
    j = _vsp_p2_safe_read_json(fp) or {}
    for k in ("duration_s", "duration_sec", "duration"):
      if k in j:
        try:
          return float(j.get(k))
        except Exception:
          pass
    ts0 = j.get("ts_start") or j.get("start_ts") or j.get("started_ts")
    ts1 = j.get("ts_end")   or j.get("end_ts")   or j.get("finished_ts")
    try:
      if ts0 and ts1:
        return float(ts1) - float(ts0)
    except Exception:
      pass
  return None

def _vsp_p2_has_findings(run_dir: str):
  # presence only (avoid heavy reads)
  if os.path.isfile(os.path.join(run_dir, "findings_unified.json")):
    return True
  if os.path.isfile(os.path.join(run_dir, "reports", "findings_unified.json")):
    return True
  if os.path.isfile(os.path.join(run_dir, "reports", "findings_unified.csv")):
    return True
  return False

_app = _vsp_p2_pick_app()
if _app is not None:
  # flask 2+: .get exists; fallback to .route
  deco = getattr(_app, "get", None) or (lambda path: _app.route(path, methods=["GET"]))

  @deco("/api/ui/runs_kpi_v2")
  def vsp_ui_runs_kpi_v2():
    try:
      days = int(request.args.get("days", "30")) if request else 30
    except Exception:
      days = 30
    days = max(1, min(days, 3650))
    now = datetime.now()
    cut = now - timedelta(days=days)

    roots = []
    for r in (
      os.environ.get("VSP_RUNS_ROOT"),
      "/home/test/Data/SECURITY_BUNDLE/out",
      "/home/test/Data/SECURITY_BUNDLE/out_ci",
      "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    ):
      if r and os.path.isdir(r) and r not in roots:
        roots.append(r)

    runs = []
    for root in roots:
      try:
        for name in os.listdir(root):
          run_dir = os.path.join(root, name)
          if not os.path.isdir(run_dir):
            continue
          # accept your real patterns: RUN_* OR contains _RUN_ OR VSP_*
          if not (name.startswith("RUN_") or "_RUN_" in name or name.startswith("VSP_")):
            continue

          day = _vsp_p2_parse_day(name)
          if day:
            try:
              d = datetime.strptime(day, "%Y-%m-%d")
            except Exception:
              d = datetime.fromtimestamp(os.path.getmtime(run_dir))
              day = d.strftime("%Y-%m-%d")
          else:
            d = datetime.fromtimestamp(os.path.getmtime(run_dir))
            day = d.strftime("%Y-%m-%d")

          if d < cut:
            continue
          runs.append((d, day, run_dir, name))
      except Exception:
        pass

    runs.sort(key=lambda x: x[0], reverse=True)
    latest_rid = runs[0][3] if runs else None

    by_overall = {"GREEN":0, "AMBER":0, "RED":0, "UNKNOWN":0}
    bucket = {}
    has_gate = 0
    has_findings = 0
    durs = []
    degraded_count = 0

    for _, day, run_dir, rid in runs:
      b = bucket.setdefault(day, {"GREEN":0,"AMBER":0,"RED":0,"UNKNOWN":0,"CRITICAL":0,"HIGH":0,"degraded":0})

      j = _vsp_p2_safe_read_json(os.path.join(run_dir, "run_gate_summary.json")) or {}
      if j:
        has_gate += 1

      ov = _vsp_p2_norm_overall(j.get("overall_status") or j.get("overall") or j.get("status"))
      by_overall[ov] += 1
      b[ov] += 1

      if _vsp_p2_is_degraded(j):
        degraded_count += 1
        b["degraded"] += 1

      sev = _vsp_p2_pick_sev(j)
      try:
        b["CRITICAL"] += int(sev.get("CRITICAL", 0) or 0)
        b["HIGH"]     += int(sev.get("HIGH", 0) or 0)
      except Exception:
        pass

      if _vsp_p2_has_findings(run_dir):
        has_findings += 1

      du = _vsp_p2_duration_s(run_dir)
      if du is not None:
        try:
          durs.append(float(du))
        except Exception:
          pass

    labels = sorted(bucket.keys())

    trend_overall = {
      "labels": labels,
      "GREEN":   [bucket[d]["GREEN"] for d in labels],
      "AMBER":   [bucket[d]["AMBER"] for d in labels],
      "RED":     [bucket[d]["RED"] for d in labels],
      "UNKNOWN": [bucket[d]["UNKNOWN"] for d in labels],
    }
    trend_sev = {
      "labels": labels,
      "CRITICAL": [bucket[d]["CRITICAL"] for d in labels],
      "HIGH":     [bucket[d]["HIGH"] for d in labels],
    }

    total_runs = len(runs)
    rate = (degraded_count/total_runs) if total_runs else 0.0

    dur_avg = None
    dur_p95 = None
    if durs:
      dur_avg = sum(durs)/len(durs)
      ds = sorted(durs)
      k = max(0, min(len(ds)-1, int(math.ceil(0.95*len(ds))-1)))
      dur_p95 = ds[k]

    out = {
      "ok": True,
      "total_runs": total_runs,
      "latest_rid": latest_rid,
      "by_overall": by_overall,
      "has_gate": has_gate,
      "has_findings": has_findings,
      "trend_overall": trend_overall,
      "trend_sev": trend_sev,
      "degraded": {"count": degraded_count, "rate": rate},
      "duration": {"avg_s": dur_avg, "p95_s": dur_p95},
      "roots_used": roots,
      "ts": int(time.time()),
    }
    return jsonify(out) if jsonify else out
# ===================== /VSP_P2_RUNS_KPI_V2_ENDPOINT_V1 =====================


# ===================== VSP_P2_RUNS_KPI_V3_ENDPOINT_V1 =====================
# V3: returns trend_overall/trend_sev + degraded + duration. Small-file only.
try:
  import os, json, time, math, re
  from datetime import datetime, timedelta
  from flask import request, jsonify
except Exception:
  request = None
  jsonify = None

def _vsp_p2_app():
  for nm in ("app","application"):
    try:
      obj = globals().get(nm)
      if obj is not None and (hasattr(obj,"route") or hasattr(obj,"get")):
        return obj
    except Exception:
      pass
  return None

def _vsp_p2_rjson(fp):
  try:
    with open(fp,"r",encoding="utf-8",errors="replace") as f:
      return json.load(f)
  except Exception:
    return None

def _vsp_p2_day(name:str):
  try:
    m = re.search(r"(20\d{2})(\d{2})(\d{2})", name or "")
    if m:
      return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
  except Exception:
    pass
  return None

def _vsp_p2_overall(v):
  if not v: return "UNKNOWN"
  vv = str(v).strip().upper()
  if vv in ("GREEN","AMBER","RED","UNKNOWN"): return vv
  if vv in ("PASS","OK","SUCCESS"): return "GREEN"
  if vv in ("WARN","WARNING"): return "AMBER"
  if vv in ("FAIL","FAILED","ERROR"): return "RED"
  return "UNKNOWN"

def _vsp_p2_sev(j:dict):
  if not isinstance(j, dict): return {}
  for k in ("by_severity","severity","counts_by_severity","sev"):
    v = j.get(k)
    if isinstance(v, dict): return v
  c = j.get("counts")
  if isinstance(c, dict):
    v = c.get("by_severity")
    if isinstance(v, dict): return v
  return {}

def _vsp_p2_degraded(j:dict):
  if not isinstance(j, dict): return False
  if bool(j.get("degraded")): return True
  bt = j.get("by_type")
  if isinstance(bt, dict):
    for _, vv in bt.items():
      if isinstance(vv, dict) and bool(vv.get("degraded")):
        return True
  return False

def _vsp_p2_dur(run_dir:str):
  for name in ("run_manifest.json","run_status.json","run_status_v1.json"):
    fp = os.path.join(run_dir, name)
    j = _vsp_p2_rjson(fp) or {}
    for k in ("duration_s","duration_sec","duration"):
      if k in j:
        try: return float(j.get(k))
        except Exception: pass
    ts0 = j.get("ts_start") or j.get("start_ts") or j.get("started_ts")
    ts1 = j.get("ts_end")   or j.get("end_ts")   or j.get("finished_ts")
    try:
      if ts0 and ts1: return float(ts1) - float(ts0)
    except Exception:
      pass
  return None

def _vsp_p2_has_findings(run_dir:str):
  if os.path.isfile(os.path.join(run_dir,"findings_unified.json")): return True
  if os.path.isfile(os.path.join(run_dir,"reports","findings_unified.json")): return True
  if os.path.isfile(os.path.join(run_dir,"reports","findings_unified.csv")): return True
  return False

_app = _vsp_p2_app()
if _app is not None:
  deco = getattr(_app, "get", None) or (lambda path: _app.route(path, methods=["GET"]))

  @deco("/api/ui/runs_kpi_v3")
  def vsp_ui_runs_kpi_v3():
    try:
      days = int(request.args.get("days","30")) if request else 30
    except Exception:
      days = 30
    days = max(1, min(days, 3650))
    now = datetime.now()
    cut = now - timedelta(days=days)

    roots = []
    for r in (
      os.environ.get("VSP_RUNS_ROOT"),
      "/home/test/Data/SECURITY_BUNDLE/out",
      "/home/test/Data/SECURITY_BUNDLE/out_ci",
      "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    ):
      if r and os.path.isdir(r) and r not in roots:
        roots.append(r)

    runs = []
    for root in roots:
      try:
        for name in os.listdir(root):
          run_dir = os.path.join(root, name)
          if not os.path.isdir(run_dir): 
            continue
          if not (name.startswith("RUN_") or "_RUN_" in name or name.startswith("VSP_")):
            continue
          day = _vsp_p2_day(name)
          if day:
            try:
              d = datetime.strptime(day, "%Y-%m-%d")
            except Exception:
              d = datetime.fromtimestamp(os.path.getmtime(run_dir))
              day = d.strftime("%Y-%m-%d")
          else:
            d = datetime.fromtimestamp(os.path.getmtime(run_dir))
            day = d.strftime("%Y-%m-%d")
          if d < cut:
            continue
          runs.append((d, day, run_dir, name))
      except Exception:
        pass

    runs.sort(key=lambda x: x[0], reverse=True)
    latest_rid = runs[0][3] if runs else None

    by_overall = {"GREEN":0,"AMBER":0,"RED":0,"UNKNOWN":0}
    bucket = {}
    has_gate = 0
    has_findings = 0
    durs = []
    degraded_count = 0

    for _, day, run_dir, rid in runs:
      b = bucket.setdefault(day, {"GREEN":0,"AMBER":0,"RED":0,"UNKNOWN":0,"CRITICAL":0,"HIGH":0,"degraded":0})
      j = _vsp_p2_rjson(os.path.join(run_dir,"run_gate_summary.json")) or {}
      if j: has_gate += 1
      ov = _vsp_p2_overall(j.get("overall_status") or j.get("overall") or j.get("status"))
      by_overall[ov] += 1
      b[ov] += 1

      if _vsp_p2_degraded(j):
        degraded_count += 1
        b["degraded"] += 1

      sev = _vsp_p2_sev(j)
      try:
        b["CRITICAL"] += int(sev.get("CRITICAL",0) or 0)
        b["HIGH"]     += int(sev.get("HIGH",0) or 0)
      except Exception:
        pass

      if _vsp_p2_has_findings(run_dir):
        has_findings += 1

      du = _vsp_p2_dur(run_dir)
      if du is not None:
        try: durs.append(float(du))
        except Exception: pass

    labels = sorted(bucket.keys())
    trend_overall = {
      "labels": labels,
      "GREEN":   [bucket[d]["GREEN"] for d in labels],
      "AMBER":   [bucket[d]["AMBER"] for d in labels],
      "RED":     [bucket[d]["RED"] for d in labels],
      "UNKNOWN": [bucket[d]["UNKNOWN"] for d in labels],
    }
    trend_sev = {
      "labels": labels,
      "CRITICAL": [bucket[d]["CRITICAL"] for d in labels],
      "HIGH":     [bucket[d]["HIGH"] for d in labels],
    }

    total_runs = len(runs)
    rate = (degraded_count/total_runs) if total_runs else 0.0

    dur_avg = None
    dur_p95 = None
    if durs:
      dur_avg = sum(durs)/len(durs)
      ds = sorted(durs)
      k = max(0, min(len(ds)-1, int(math.ceil(0.95*len(ds))-1)))
      dur_p95 = ds[k]

    out = {
      "ok": True,
      "total_runs": total_runs,
      "latest_rid": latest_rid,
      "by_overall": by_overall,
      "has_gate": has_gate,
      "has_findings": has_findings,
      "trend_overall": trend_overall,
      "trend_sev": trend_sev,
      "degraded": {"count": degraded_count, "rate": rate},
      "duration": {"avg_s": dur_avg, "p95_s": dur_p95},
      "roots_used": roots,
      "ts": int(time.time()),
    }
    return jsonify(out) if jsonify else out
# ===================== /VSP_P2_RUNS_KPI_V3_ENDPOINT_V1 =====================


# ===================== VSP_P2_RUNS_KPI_V3B_ENDPOINT_V1 =====================
# v3b: harden v3 (never 500 HTML). Always returns JSON (ok/err).
try:
  import os, json, time, math, re, traceback
  from datetime import datetime, timedelta
  from flask import request, Response
except Exception:
  request = None
  Response = None

def _vsp_kpi_app():
  for nm in ("app","application"):
    try:
      obj = globals().get(nm)
      if obj is not None and (hasattr(obj,"route") or hasattr(obj,"get")):
        return obj
    except Exception:
      pass
  return None

def _vsp_json_resp(payload, code=200):
  try:
    body = json.dumps(payload, ensure_ascii=False)
  except Exception:
    body = '{"ok":false,"err":"json_dumps_failed"}'
    code = 200
  if Response is None:
    return body
  return Response(body, status=code, mimetype="application/json")

def _rjson(fp):
  try:
    with open(fp,"r",encoding="utf-8",errors="replace") as f:
      return json.load(f)
  except Exception:
    return None

def _day(name:str):
  try:
    m = re.search(r"(20\d{2})(\d{2})(\d{2})", name or "")
    if m:
      return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
  except Exception:
    pass
  return None

def _overall(v):
  if not v: return "UNKNOWN"
  vv = str(v).strip().upper()
  if vv in ("GREEN","AMBER","RED","UNKNOWN"): return vv
  if vv in ("PASS","OK","SUCCESS"): return "GREEN"
  if vv in ("WARN","WARNING"): return "AMBER"
  if vv in ("FAIL","FAILED","ERROR"): return "RED"
  return "UNKNOWN"

def _sev(j:dict):
  if not isinstance(j, dict): return {}
  for k in ("by_severity","severity","counts_by_severity","sev"):
    v = j.get(k)
    if isinstance(v, dict): return v
  c = j.get("counts")
  if isinstance(c, dict):
    v = c.get("by_severity")
    if isinstance(v, dict): return v
  return {}

def _degraded(j:dict):
  if not isinstance(j, dict): return False
  if bool(j.get("degraded")): return True
  bt = j.get("by_type")
  if isinstance(bt, dict):
    for _, vv in bt.items():
      if isinstance(vv, dict) and bool(vv.get("degraded")):
        return True
  return False

def _dur(run_dir:str):
  for name in ("run_manifest.json","run_status.json","run_status_v1.json"):
    fp = os.path.join(run_dir, name)
    j = _rjson(fp) or {}
    for k in ("duration_s","duration_sec","duration"):
      if k in j:
        try: return float(j.get(k))
        except Exception: pass
    ts0 = j.get("ts_start") or j.get("start_ts") or j.get("started_ts")
    ts1 = j.get("ts_end")   or j.get("end_ts")   or j.get("finished_ts")
    try:
      if ts0 and ts1: return float(ts1) - float(ts0)
    except Exception:
      pass
  return None

def _has_findings(run_dir:str):
  if os.path.isfile(os.path.join(run_dir,"findings_unified.json")): return True
  if os.path.isfile(os.path.join(run_dir,"reports","findings_unified.json")): return True
  if os.path.isfile(os.path.join(run_dir,"reports","findings_unified.csv")): return True
  return False

_app = _vsp_kpi_app()
if _app is not None:
  deco = getattr(_app, "get", None) or (lambda path: _app.route(path, methods=["GET"]))

  @deco("/api/ui/runs_kpi_v3b")
  def vsp_ui_runs_kpi_v3b():
    try:
      try:
        days = int(request.args.get("days","30")) if request else 30
      except Exception:
        days = 30
      days = max(1, min(days, 3650))
      now = datetime.now()
      cut = now - timedelta(days=days)

      roots = []
      for r in (
        os.environ.get("VSP_RUNS_ROOT"),
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
      ):
        if r and os.path.isdir(r) and r not in roots:
          roots.append(r)

      runs = []
      for root in roots:
        try:
          for name in os.listdir(root):
            run_dir = os.path.join(root, name)
            if not os.path.isdir(run_dir):
              continue
            if not (name.startswith("RUN_") or "_RUN_" in name or name.startswith("VSP_")):
              continue
            day = _day(name)
            if day:
              try:
                d = datetime.strptime(day, "%Y-%m-%d")
              except Exception:
                d = datetime.fromtimestamp(os.path.getmtime(run_dir))
                day = d.strftime("%Y-%m-%d")
            else:
              d = datetime.fromtimestamp(os.path.getmtime(run_dir))
              day = d.strftime("%Y-%m-%d")

            if d < cut:
              continue
            runs.append((d, day, run_dir, name))
        except Exception:
          continue

      runs.sort(key=lambda x: x[0], reverse=True)
      latest_rid = runs[0][3] if runs else None

      by_overall = {"GREEN":0,"AMBER":0,"RED":0,"UNKNOWN":0}
      bucket = {}
      has_gate = 0
      has_findings = 0
      durs = []
      degraded_count = 0

      for _, day, run_dir, rid in runs:
        b = bucket.setdefault(day, {"GREEN":0,"AMBER":0,"RED":0,"UNKNOWN":0,"CRITICAL":0,"HIGH":0,"degraded":0})
        j = _rjson(os.path.join(run_dir,"run_gate_summary.json")) or {}
        if j: has_gate += 1

        ov = _overall(j.get("overall_status") or j.get("overall") or j.get("status"))
        by_overall[ov] += 1
        b[ov] += 1

        if _degraded(j):
          degraded_count += 1
          b["degraded"] += 1

        sev = _sev(j)
        try:
          b["CRITICAL"] += int(sev.get("CRITICAL",0) or 0)
          b["HIGH"]     += int(sev.get("HIGH",0) or 0)
        except Exception:
          pass

        if _has_findings(run_dir):
          has_findings += 1

        du = _dur(run_dir)
        if du is not None:
          try: durs.append(float(du))
          except Exception: pass

      labels = sorted(bucket.keys())
      trend_overall = {
        "labels": labels,
        "GREEN":   [bucket[d]["GREEN"] for d in labels],
        "AMBER":   [bucket[d]["AMBER"] for d in labels],
        "RED":     [bucket[d]["RED"] for d in labels],
        "UNKNOWN": [bucket[d]["UNKNOWN"] for d in labels],
      }
      trend_sev = {
        "labels": labels,
        "CRITICAL": [bucket[d]["CRITICAL"] for d in labels],
        "HIGH":     [bucket[d]["HIGH"] for d in labels],
      }

      total_runs = len(runs)
      rate = (degraded_count/total_runs) if total_runs else 0.0

      dur_avg = None
      dur_p95 = None
      if durs:
        dur_avg = sum(durs)/len(durs)
        ds = sorted(durs)
        k = max(0, min(len(ds)-1, int(math.ceil(0.95*len(ds))-1)))
        dur_p95 = ds[k]

      out = {
        "ok": True,
        "total_runs": total_runs,
        "latest_rid": latest_rid,
        "by_overall": by_overall,
        "has_gate": has_gate,
        "has_findings": has_findings,
        "trend_overall": trend_overall,
        "trend_sev": trend_sev,
        "degraded": {"count": degraded_count, "rate": rate},
        "duration": {"avg_s": dur_avg, "p95_s": dur_p95},
        "roots_used": roots,
        "ts": int(time.time()),
        "v": "v3b",
      }
      return _vsp_json_resp(out, 200)
    except Exception as e:
      # NEVER 500 HTML: return JSON error
      out = {"ok": False, "err": str(e), "v": "v3b", "ts": int(time.time())}
      return _vsp_json_resp(out, 200)
# ===================== /VSP_P2_RUNS_KPI_V3B_ENDPOINT_V1 =====================

# ===================== VSP_P2_KPI_V3_PROXY_HTTP_V1 =====================
# Goal: never 500 on legacy /api/ui/runs_kpi_v3 calls. Proxy to v2 endpoint.
# This is intentionally implemented as an HTTP proxy to avoid coupling to internal handler names.
try:
    from flask import request, jsonify, Response
except Exception:
    request = None
    jsonify = None
    Response = None
# ===================== VSP_P0_LATEST_RID_ENDPOINT_V1 =====================
try:
    import time
    from pathlib import Path
    from flask import jsonify, Flask as _VSP_Flask

    # Find the real Flask() instance (application may be a middleware wrapper)
    _vsp_flask_app = None
    for _k, _v in list(globals().items()):
        try:
            if isinstance(_v, _VSP_Flask):
                _vsp_flask_app = _v
                break
        except Exception:
            pass

    def _vsp_latest_rid__impl_p0_v1():
        roots = [
            Path("/home/test/Data/SECURITY_BUNDLE/out"),
            Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
            Path("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        ]
        roots = [r for r in roots if r.exists() and r.is_dir()]
        must_files = ["run_gate_summary.json", "run_gate.json", "findings_unified.json"]

        cands = []
        for root in roots:
            try:
                for d in root.iterdir():
                    if not d.is_dir():
                        continue
                    rid = d.name
                    score = 0
                    if rid.startswith("VSP_"): score += 3
                    if rid.startswith("RUN_"): score += 2

                    have = []
                    for f in must_files:
                        fp = d / f
                        try:
                            if fp.exists() and fp.is_file() and fp.stat().st_size > 20:
                                have.append(f)
                        except Exception:
                            pass
                    if not have:
                        continue

                    try:
                        mtime = d.stat().st_mtime
                    except Exception:
                        continue

                    cands.append((mtime, score, rid, str(d), have))
            except Exception:
                continue

        if not cands:
            return jsonify({"ok": False, "err": "no run dir with gate artifacts found"}), 404

        cands.sort(key=lambda x: (x[0], x[1]), reverse=True)
        mtime, score, rid, path, have = cands[0]
        return jsonify({
            "ok": True,
            "rid": rid,
            "path": path,
            "have": have,
            "mtime": mtime,
            "mtime_iso": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(mtime)),
            "roots_checked": [str(r) for r in roots],
        })

    if _vsp_flask_app is not None:
        # Idempotent register
        try:
            vf = getattr(_vsp_flask_app, "view_functions", {}) or {}
            if "vsp_latest_rid__p0_v1" not in vf:
                _vsp_flask_app.add_url_rule(
                    "/api/vsp/latest_rid",
                    endpoint="vsp_latest_rid__p0_v1",
                    view_func=_vsp_latest_rid__impl_p0_v1,
                    methods=["GET"],
                )
        except Exception:
            # fallback decorator-style
            _vsp_flask_app.route("/api/vsp/latest_rid", methods=["GET"])(_vsp_latest_rid__impl_p0_v1)
except Exception:
    pass
# ===================== /VSP_P0_LATEST_RID_ENDPOINT_V1 =====================


# ===================== VSP_P0_VSP5_BUNDLE_INJECT_MW_V3 =====================
# Inject vsp_bundle_commercial_v2.js into /vsp5 HTML if missing (prefer before gate_story).
import re as _re

class _VSP5BundleInjectMW_V3:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        try:
            path = environ.get("PATH_INFO") or ""
        except Exception:
            path = ""

        if path != "/vsp5":
            return self.app(environ, start_response)

        captured = {}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            captured["exc_info"] = exc_info
            return lambda x: None  # delay

        resp_iter = self.app(environ, _sr)

        try:
            body = b"".join(resp_iter or [])
        finally:
            try:
                close = getattr(resp_iter, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        headers = captured.get("headers", [])
        status = captured.get("status", "200 OK")
        exc_info = captured.get("exc_info", None)

        ctype = ""
        for k, v in headers:
            if str(k).lower() == "content-type":
                ctype = str(v)
                break

        if "text/html" not in ctype.lower():
            start_response(status, headers, exc_info)
            return [body]

        try:
            html = body.decode("utf-8", "replace")
        except Exception:
            start_response(status, headers, exc_info)
            return [body]

        if "vsp_bundle_commercial_v2.js" in html:
            start_response(status, headers, exc_info)
            return [body]

        # reuse ?v= from gate_story if possible
        m = _re.search(r'vsp_dashboard_gate_story_v1\.js\?v=([0-9A-Za-z_.:-]+)', html)
        v = m.group(1) if m else ""
        # VSP_LUXE_SAFE_INJECT_V9
        # VSP_P0_VSP5_BUNDLETAG_CANON_V15
        bundle_tag = (
            f'<script src="/static/js/vsp_p0_fetch_shim_v1.js?v={v}"></script>'
            f'<script src="/static/js/vsp_bundle_commercial_v2.js?v={v}"></script>'
            f'<script src="/static/js/vsp_dashboard_gate_story_v1.js?v={v}"></script>'
            f'<script src="/static/js/vsp_dashboard_containers_fix_v1.js?v={v}"></script>'
            f'<script src="/static/js/vsp_dashboard_luxe_v1.js?v={v}"></script>'
        )
        html2 = html

        # prefer insert before gate_story
        if "vsp_dashboard_gate_story_v1.js" in html2:
            html2, n = _re.subn(
                r'(<script[^>]+vsp_dashboard_gate_story_v1\.js[^>]*></script>)',
                bundle_tag + r"\n\1",
                html2,
                count=1
            )

        # fallback before </body>
        if "vsp_bundle_commercial_v2.js" not in html2:
            if _re.search(r"</body\s*>", html2, flags=_re.I):
                html2 = _re.sub(r"(</body\s*>)", bundle_tag + r"\n\1", html2, count=1, flags=_re.I)
            else:
                html2 = html2 + "\n" + bundle_tag + "\n"

        body2 = html2.encode("utf-8")

        # rewrite Content-Length
        new_headers = [(k, v) for (k, v) in headers if str(k).lower() != "content-length"]
        new_headers.append(("Content-Length", str(len(body2))))

        start_response(status, new_headers, exc_info)
        return [body2]

# wrap gunicorn entry
try:
    if "application" in globals():
        globals()["application"] = _VSP5BundleInjectMW_V3(globals()["application"])
    if "app" in globals():
        globals()["app"] = globals().get("application", globals()["app"])
    print("[VSP5_BUNDLE_INJECT_MW_V3] enabled")
except Exception as _e:
    print("[VSP5_BUNDLE_INJECT_MW_V3] enable failed:", _e)
# ===================== /VSP_P0_VSP5_BUNDLE_INJECT_MW_V3 =====================


# ===================== VSP_P0_RID_LATEST_GATE_ROOT_MW_V1 =====================
# Provide endpoint expected by dashboard bundle:
#   GET /api/vsp/rid_latest_gate_root
# by internally calling existing handlers (/api/vsp/latest_rid, fallback /api/vsp/runs)
# without requiring Flask route edits (pure WSGI intercept).

def _vsp_p0__call_inner_wsgi(app, path, query_string=""):
    import json
    env2 = {}
    def _sr(status, headers, exc_info=None):
        env2["_status"] = status
        env2["_headers"] = headers
    # call inner app with a minimal env clone (will be merged from a real environ in MW)
    # this function will be called with a fully built environ in MW below.
    raise RuntimeError("should be patched by MW with real environ")

class VSPP0RidLatestGateRootMW:
    def __init__(self, app):
        self.app = app
        setattr(self, "__vsp_p0_rid_latest_gate_root_mw_v1__", True)

    def _call_inner(self, environ, path, query_string=""):
        import json
        # clone environ and force GET
        env2 = dict(environ)
        env2["REQUEST_METHOD"] = "GET"
        env2["PATH_INFO"] = path
        env2["QUERY_STRING"] = query_string or ""
        env2.pop("CONTENT_LENGTH", None)
        env2.pop("CONTENT_TYPE", None)

        captured = {"status": None, "headers": None}
        body_chunks = []

        def sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = headers

        it = self.app(env2, sr)
        try:
            for c in it:
                body_chunks.append(c)
        finally:
            if hasattr(it, "close"):
                try: it.close()
                except Exception: pass

        raw = b"".join(body_chunks)
        # best-effort json decode
        try:
            return captured["status"] or "200 OK", captured["headers"] or [], json.loads(raw.decode("utf-8", "replace"))
        except Exception:
            return captured["status"] or "200 OK", captured["headers"] or [], {"_raw": raw.decode("utf-8", "replace")}

    def __call__(self, environ, start_response):
        import json, time, re

        path = environ.get("PATH_INFO") or ""
        if path in ("/api/vsp/rid_latest_gate_root", "/api/vsp/rid_latest_gate_root.json"):
            rid = None
            src = None

            # 1) preferred: /api/vsp/latest_rid
            try:
                _st, _hdr, j = self._call_inner(environ, "/api/vsp/latest_rid", "")
                rid = j.get("rid") or j.get("run_id") or j.get("id")
                if rid:
                    src = "/api/vsp/latest_rid"
            except Exception:
                rid = None

            # 2) fallback: /api/vsp/runs?limit=10  (pick first non-empty, prefer non RUN_*)
            if not rid:
                try:
                    _st, _hdr, j2 = self._call_inner(environ, "/api/vsp/runs", "limit=10")
                    runs = j2.get("runs") or j2.get("data") or j2.get("items") or []
                    cands = []
                    for r in runs:
                        if not isinstance(r, dict): 
                            continue
                        x = r.get("rid") or r.get("run_id") or r.get("id")
                        if x: cands.append(x)
                    # prefer VSP_* then RUN_*
                    for x in cands:
                        if isinstance(x, str) and x.startswith("VSP_"):
                            rid = x; break
                    if not rid and cands:
                        rid = cands[0]
                    if rid:
                        src = "/api/vsp/runs?limit=10"
                except Exception:
                    rid = None

            # build response: be generous with field names for JS compatibility
            gate_root = f"gate_root_{rid}" if rid else None
            out = {
                "ok": bool(rid),
                "rid": rid,
                "run_id": rid,
                "gate_root": gate_root,
                "gate_root_id": gate_root,
                "source": src,
                "ts": time.time(),
            }
            b = json.dumps(out, ensure_ascii=False).encode("utf-8")
            start_response("200 OK", [
                ("Content-Type","application/json; charset=utf-8"),
                ("Cache-Control","no-store"),
                ("Content-Length", str(len(b))),
            ])
            return [b]

        return self.app(environ, start_response)

# Wrap exported WSGI callables if present (idempotent)
for _name in ("application", "app"):
    _obj = globals().get(_name)
    if callable(_obj) and not getattr(_obj, "__vsp_p0_rid_latest_gate_root_mw_v1__", False):
        globals()[_name] = VSPP0RidLatestGateRootMW(_obj)
# ===================== /VSP_P0_RID_LATEST_GATE_ROOT_MW_V1 =====================


# ===================== VSP_P0_API_RID_LATEST_GATE_ROOT_V1 =====================
# Back-compat endpoint for dashboard bundle: /api/vsp/rid_latest_gate_root
try:
    from flask import jsonify
except Exception:
    jsonify = None

def _vsp_p0_scan_latest_gate_root_rid_v1():
    try:
        from pathlib import Path
        import re
        roots = [
            Path("/home/test/Data/SECURITY_BUNDLE/out"),
            Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
            Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        ]
        pats = [
            re.compile(r"^VSP_CI_RUN_\d{8}_\d{6}$"),
            re.compile(r"^VSP_CI_\d{8}_\d{6}$"),
            re.compile(r"^RUN_\d{8}_\d{6}$"),
        ]
        cands = []
        for root in roots:
            if not root.exists() or not root.is_dir():
                continue
            for p in root.iterdir():
                if not p.is_dir():
                    continue
                name = p.name
                if any(rx.match(name) for rx in pats):
                    try:
                        cands.append((p.stat().st_mtime, name, str(root)))
                    except Exception:
                        pass
        cands.sort(reverse=True)
        if not cands:
            return None, {"roots": [str(r) for r in roots if r.exists()], "count": 0}
        mt, rid, root = cands[0]
        return rid, {"root": root, "mtime": mt, "count": len(cands)}
    except Exception as e:
        return None, {"err": str(e)}

def _vsp_p0_register_rid_latest_gate_root_v1():
    g = globals()
    app_obj = g.get("application") or g.get("app")
    if not app_obj or jsonify is None:
        return False

    # Avoid double-register
    try:
        for rule in getattr(app_obj, "url_map").iter_rules():
            if str(getattr(rule, "rule", "")) == "/api/vsp/rid_latest_gate_root":
                return True
    except Exception:
        pass

    @app_obj.get("/api/vsp/rid_latest_gate_root")
    def vsp_rid_latest_gate_root_v1():
        rid, meta = _vsp_p0_scan_latest_gate_root_rid_v1()
        return jsonify({"ok": bool(rid), "rid": rid or "", "meta": meta})

    return True

try:
    _vsp_p0_register_rid_latest_gate_root_v1()
except Exception:
    pass
# ===================== /VSP_P0_API_RID_LATEST_GATE_ROOT_V1 =====================

# ===================== VSP_P0_RUNS_KPI_V4_TREND_SERVER_SIDE_V1 =====================
try:
    import json, time
    from pathlib import Path as _Path
    from datetime import datetime as _dt
    from flask import jsonify as _jsonify, request as _request
    _VSP_KPI_V4_IMPORT_ERR = None
except Exception as _e:
    _VSP_KPI_V4_IMPORT_ERR = _e

def _vsp_pick_flask_app_v4():
    # VSP_P0_WSGI_RID_LATEST_PICK_ANY_DETAILS_V6_HANDLER
    from flask import jsonify, request
    import os, glob, time, json as _json

    roots = [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
    ]

    try:
        max_scan = int(request.args.get("max_scan", "450"))
    except Exception:
        max_scan = 450
    max_scan = max(50, min(max_scan, 900))

    SKIP = set(["kics","bandit","trivy","grype","semgrep","gitleaks","codeql","reports","out","out_ci","tmp","cache"])

    def looks_like_rid(name: str) -> bool:
        if not name or name.startswith("."): return False
        if name in SKIP: return False
        if name.startswith(("VSP_CI_","RUN_","RUN-","VSP_")): return True
        return False

    def is_run_dir(rid: str, run_dir: str) -> bool:
        if not os.path.isdir(run_dir): return False
        if looks_like_rid(rid): return True
        if os.path.isfile(os.path.join(run_dir,"run_gate_summary.json")) or os.path.isfile(os.path.join(run_dir,"run_manifest.json")):
            return True
        return False

    def csv_has_2_lines(path: str) -> bool:
        try:
            if (not os.path.isfile(path)) or os.path.getsize(path) < 120: return False
            n=0
            with open(path,"r",encoding="utf-8",errors="ignore") as f:
                for _ in f:
                    n += 1
                    if n >= 2: return True
            return False
        except Exception:
            return False

    def sarif_has_results(path: str) -> bool:
        try:
            if (not os.path.isfile(path)) or os.path.getsize(path) < 200: return False
            j=_json.load(open(path,"r",encoding="utf-8",errors="ignore"))
            for run in (j.get("runs") or []):
                if (run.get("results") or []):
                    return True
            return False
        except Exception:
            return False

    def has_details(run_dir: str) -> str:
        fu = os.path.join(run_dir,"findings_unified.json")
        try:
            if os.path.isfile(fu) and os.path.getsize(fu) > 500:
                return "findings_unified.json"
        except Exception:
            pass

        csvp = os.path.join(run_dir,"reports","findings_unified.csv")
        if csv_has_2_lines(csvp):
            return "reports/findings_unified.csv"

        sarifp = os.path.join(run_dir,"reports","findings_unified.sarif")
        if sarif_has_results(sarifp):
            return "reports/findings_unified.sarif"

        pats = [
            "semgrep/**/*.json","grype/**/*.json","trivy/**/*.json","kics/**/*.json",
            "bandit/**/*.json","gitleaks/**/*.json","codeql/**/*.sarif",
            "**/*semgrep*.json","**/*grype*.json","**/*trivy*.json",
            "**/*kics*.json","**/*bandit*.json","**/*gitleaks*.json","**/*codeql*.sarif",
        ]
        for pat in pats:
            for f in glob.glob(os.path.join(run_dir, pat), recursive=True):
                try:
                    if os.path.getsize(f) > 800:
                        rel = os.path.relpath(f, run_dir).replace("\\","/")
                        if rel == "reports/findings_unified.sarif":
                            continue
                        return rel
                except Exception:
                    continue
        return ""

    def pick_latest_with_details():
        best=None  # (mtime,rid,root,why)
        for root in roots:
            if not os.path.isdir(root): 
                continue
            cands=[]
            for rid in os.listdir(root):
                run_dir=os.path.join(root,rid)
                if not is_run_dir(rid, run_dir):
                    continue
                try: mtime=int(os.path.getmtime(run_dir))
                except Exception: mtime=0
                cands.append((mtime,rid,run_dir))
            cands.sort(reverse=True)
            for mtime,rid,run_dir in cands[:max_scan]:
                why=has_details(run_dir)
                if why:
                    cand=(mtime,rid,root,why)
                    if best is None or cand[0] > best[0]:
                        best=cand
                    break
        return best

    def pick_latest_existing():
        best=None  # (mtime,rid,root)
        for root in roots:
            if not os.path.isdir(root): 
                continue
            cands=[]
            for rid in os.listdir(root):
                run_dir=os.path.join(root,rid)
                if not is_run_dir(rid, run_dir):
                    continue
                try: cands.append((int(os.path.getmtime(run_dir)), rid, root))
                except Exception: cands.append((0, rid, root))
            cands.sort(reverse=True)
            if cands and (best is None or cands[0][0] > best[0]):
                best=cands[0]
        return best

    best = pick_latest_with_details()
    if best:
        _, rid, _root, why = best
        return jsonify({
            "ok": True,
            "rid": rid,
            "gate_root": "gate_root_" + rid,
            "roots": roots,
            "reason": "latest_with_details",
            "why": why,
            "ts": int(time.time()),
        })

    fb = pick_latest_existing()
    if fb:
        _, rid, _root = fb
        return jsonify({
            "ok": True,
            "rid": rid,
            "gate_root": "gate_root_" + rid,
            "roots": roots,
            "reason": "latest_existing_fallback_no_details",
            "why": "",
            "ts": int(time.time()),
        })

    return jsonify({
        "ok": False,
        "rid": "",
        "gate_root": "",
        "roots": roots,
        "reason": "no_runs_found",
        "why": "",
        "ts": int(time.time()),
    }), 200


def _vsp_safe_read_json_v4(p: _Path):
    try:
        return json.loads(p.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return None

def _vsp_list_run_dirs_v4(roots, cap=3000):
    dirs = []
    for r in roots:
        rr = _Path(r)
        if not rr.exists():
            continue
        try:
            for p in rr.iterdir():
                if not p.is_dir():
                    continue
                n = p.name
                if n.startswith(("RUN_","VSP_CI_RUN_","BOSS_BUNDLE_")):
                    dirs.append(p)
        except Exception:
            pass
    def _mtime(x):
        try:
            return x.stat().st_mtime
        except Exception:
            return 0
    dirs.sort(key=_mtime, reverse=True)
    return dirs[:cap]

def vsp_ui_runs_kpi_v4():
    if _VSP_KPI_V4_IMPORT_ERR is not None:
        return _jsonify(ok=False, err="import_failed", detail=str(_VSP_KPI_V4_IMPORT_ERR)), 500

    # days window
    try:
        days = int((_request.args.get("days","30") or "30").strip())
    except Exception:
        days = 30
    days = max(1, min(days, 365))

    now = time.time()
    cutoff = now - days*86400

    roots = [
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    ]

    run_dirs = _vsp_list_run_dirs_v4(roots, cap=4000)

    total_runs = 0
    has_gate = 0
    has_findings = 0
    latest_rid = ""

    by_overall = {"GREEN":0,"AMBER":0,"RED":0,"UNKNOWN":0}
    bucket = {}  # YYYY-mm-dd -> counts

    for rd in run_dirs:
        rid = rd.name
        try:
            ts = rd.stat().st_mtime
        except Exception:
            ts = now

        if ts < cutoff:
            continue

        total_runs += 1
        if not latest_rid:
            latest_rid = rid

        # findings presence (cheap)
        if (rd/"findings_unified.json").exists() or (rd/"reports"/"findings_unified.json").exists():
            has_findings += 1

        # gate summary candidates
        j = _vsp_safe_read_json_v4(rd/"run_gate_summary.json") or _vsp_safe_read_json_v4(rd/"reports"/"run_gate_summary.json")
        if j:
            has_gate += 1
            ov = (j.get("overall_status") or j.get("overall") or j.get("status") or "UNKNOWN")
            ov = str(ov).upper().strip()
            if ov not in by_overall:
                ov = "UNKNOWN"
        else:
            ov = "UNKNOWN"

        by_overall[ov] = by_overall.get(ov, 0) + 1

        dkey = _dt.fromtimestamp(ts).astimezone().strftime("%Y-%m-%d")
        b = bucket.get(dkey)
        if b is None:
            b = {"GREEN":0,"AMBER":0,"RED":0,"UNKNOWN":0}
            bucket[dkey] = b
        b[ov] = b.get(ov, 0) + 1

    labels = sorted(bucket.keys())
    series = {k:[bucket[d].get(k,0) for d in labels] for k in ["GREEN","AMBER","RED","UNKNOWN"]}

    return _jsonify(
        ok=True,
        total_runs=total_runs,
        latest_rid=latest_rid,
        by_overall=by_overall,
        has_findings=has_findings,
        has_gate=has_gate,
        trend_overall={"labels":labels, "series":series},
        ts=int(now),
    )

try:
    _app_v4 = _vsp_pick_flask_app_v4()
    if _app_v4 is not None:
        _app_v4.add_url_rule("/api/ui/runs_kpi_v4", "vsp_ui_runs_kpi_v4", vsp_ui_runs_kpi_v4, methods=["GET"])
        print("[VSP_KPI_V4] mounted /api/ui/runs_kpi_v4")
    else:
        print("[VSP_KPI_V4] no Flask app found to mount")
except Exception as _e:
    print("[VSP_KPI_V4] mount failed:", _e)
# ===================== /VSP_P0_RUNS_KPI_V4_TREND_SERVER_SIDE_V1 =====================

# ===================== VSP_P0_MW_FIX_RUNSREPORTS_AND_RUNSAPI_JSON_V1 =====================
# P0 commercial: do NOT touch Dashboard. Just:
# 1) alias /runs_reports -> /runs at WSGI level
# 2) ensure /api/vsp/runs always returns JSON (avoid empty/HTML breaking clients/selfcheck)
try:
  import json as _json
  from werkzeug.wrappers import Response as _Resp

  class _VSPFixRunsMW:
    def __init__(self, app):
      self.app = app

    def __call__(self, environ, start_response):
      try:
        path = (environ.get("PATH_INFO","") or "")
        if path == "/runs_reports":
          environ["PATH_INFO"] = "/runs"

        if path == "/api/vsp/runs":
          status_box = {"status":"200 OK"}
          headers_box = []
          body_chunks = []

          def _sr(status, headers, exc_info=None):
            status_box["status"] = status
            headers_box[:] = headers[:] if headers else []
            return lambda x: None  # placeholder; we will call real start_response later

          it = self.app(environ, _sr)

          try:
            for x in it:
              body_chunks.append(x)
          finally:
            try:
              if hasattr(it, "close"): it.close()
            except Exception:
              pass

          body = b"".join(body_chunks)
          # detect content-type
          ct = ""
          for (k,v) in headers_box:
            if (k or "").lower() == "content-type":
              ct = (v or "")
              break

          def _is_json_bytes(b):
            bb = (b or b"").lstrip()
            return bb[:1] in (b"{", b"[")

          if ("application/json" in (ct or "").lower()) and _is_json_bytes(body) and body:
            # pass-through original
            start_response(status_box["status"], headers_box)
            return [body]

          # else: return safe JSON stub (commercial degrade)
          payload = {
            "ok": False,
            "err": "runs_api_non_json_or_empty",
            "items": [],
            "_orig_status": status_box["status"],
            "_orig_ct": ct,
            "_orig_len": len(body),
          }
          resp = _Resp(_json.dumps(payload).encode("utf-8"), content_type="application/json", status=200)
          return resp(environ, start_response)

      except Exception:
        pass

      return self.app(environ, start_response)

  if "application" in globals() and callable(globals().get("application")):
    application = _VSPFixRunsMW(application)
except Exception:
  pass
# ===================== /VSP_P0_MW_FIX_RUNSREPORTS_AND_RUNSAPI_JSON_V1 =====================
# ===================== VSP_P0_MW_STREAM_FINDINGS_BIG_AND_ALIAS_JSON_V1 =====================
# Purpose:
# - reports/findings_unified.csv may be huge -> run_file_allow sometimes returns 413. Stream it here.
# - findings_unified.json may live under reports/ -> alias to avoid 404.
try:
  import os
  from pathlib import Path as _Path
  from urllib.parse import parse_qs as _parse_qs
  from werkzeug.wrappers import Response as _Resp

  class _VSPFindingsArtifactsMW:
    def __init__(self, app):
      self.app = app

    def _norm(self, x: str) -> str:
      x = (x or "").replace("\\", "/")
      while x.startswith("/"):
        x = x[1:]
      return x

    def _resolve_run_dir(self, rid: str):
      # Keep it deterministic + cheap
      roots = [
        _Path("/home/test/Data/SECURITY_BUNDLE/out"),
        _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
      ]
      for root in roots:
        if not root.exists():
          continue
        # direct
        d = root / rid
        if d.is_dir():
          return d
        # one level nested
        try:
          for sub in root.iterdir():
            if sub.is_dir():
              d2 = sub / rid
              if d2.is_dir():
                return d2
        except Exception:
          pass
      return None

    def _send_file(self, environ, fp: _Path, rid: str, base_name: str, content_type: str):
      try:
        f = open(fp, "rb")
      except Exception:
        return None
      wrapper = environ.get("wsgi.file_wrapper")
      data = wrapper(f, 8192) if wrapper else iter(lambda: f.read(8192), b"")
      resp = _Resp(data, content_type=content_type, direct_passthrough=True)
      resp.headers["Cache-Control"] = "no-cache"
      resp.headers["Content-Disposition"] = f'inline; filename={rid}__{base_name}'
      try:
        resp.headers["Content-Length"] = str(fp.stat().st_size)
      except Exception:
        pass
      return resp

    def __call__(self, environ, start_response):
      try:
        if (environ.get("REQUEST_METHOD","GET") or "GET").upper() != "GET":
          return self.app(environ, start_response)

        if (environ.get("PATH_INFO","") or "") != "/api/vsp/run_file_allow":
          return self.app(environ, start_response)

        qs = _parse_qs(environ.get("QUERY_STRING","") or "")
        rid = (qs.get("rid") or [""])[0]
        path = (qs.get("path") or [""])[0]
        rid = (rid or "").strip()
        rel = self._norm(path)

        if not rid or not rel:
          return self.app(environ, start_response)

        # Only special-case these 2 artifacts (commercial safe)
        want_csv = (rel == "reports/findings_unified.csv")
        want_json = (rel == "findings_unified.json" or rel == "reports/findings_unified.json")

        if not (want_csv or want_json):
          return self.app(environ, start_response)

        run_dir = self._resolve_run_dir(rid)
        if not run_dir:
          return self.app(environ, start_response)

        # Build candidate paths
        cands = []
        if want_csv:
          cands = [run_dir / "reports/findings_unified.csv"]
          ctype = "text/csv; charset=utf-8"
          base_name = "findings_unified.csv"
        else:
          cands = [run_dir / "findings_unified.json", run_dir / "reports/findings_unified.json"]
          ctype = "application/json"
          base_name = "findings_unified.json"

        for fp in cands:
          if fp.is_file():
            resp = self._send_file(environ, fp, rid, base_name, ctype)
            if resp is not None:
              return resp(environ, start_response)

        return self.app(environ, start_response)
      except Exception:
        return self.app(environ, start_response)

  if "application" in globals() and callable(globals().get("application")):
    application = _VSPFindingsArtifactsMW(application)
except Exception:
  pass
# ===================== /VSP_P0_MW_STREAM_FINDINGS_BIG_AND_ALIAS_JSON_V1 =====================


# ===================== VSP_P0_API_RID_LATEST_V1 =====================
# Provides /api/vsp/rid_latest so UI can bootstrap RID and stop skeleton loading.
# Commercial: set VSP_RUNS_ROOT or VSP_RUNS_ROOTS (colon/comma separated) to avoid scanning.
try:
    import os, time
    from flask import request, jsonify
except Exception:
    request = None
    jsonify = None

_VSP_P0_RID_LATEST_CACHE = {"ts": 0.0, "rid": None}

def _vsp_p0_guess_roots_v1():
    roots = []
    env = (os.environ.get("VSP_RUNS_ROOTS") or os.environ.get("VSP_RUNS_ROOT") or "").strip()
    if env:
        for part in env.replace(",", ":").split(":"):
            part = part.strip()
            if part:
                roots.append(part)
    # common defaults (no sudo)
    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out",
        "/home/test/Data/SECURITY_BUNDLE",
        "/home/test/Data",
    ]
    # de-dup keep order
    seen = set()
    out = []
    for r in roots:
        if r in seen: 
            continue
        seen.add(r)
        out.append(r)
    return out

def _vsp_p0_pick_latest_rid_v1():
    # cache 5 seconds to avoid repeated scans
    now = time.time()
    if (now - _VSP_P0_RID_LATEST_CACHE["ts"]) < 5 and _VSP_P0_RID_LATEST_CACHE["rid"]:
        return _VSP_P0_RID_LATEST_CACHE["rid"]

    best = (None, -1.0)  # (rid, mtime)
    roots = _vsp_p0_guess_roots_v1()

    for base in roots:
        try:
            if not os.path.isdir(base):
                continue

            # 1) direct gate_root_* under base
            try:
                for name in os.listdir(base):
                    if not name.startswith("gate_root_"):
                        continue
                    p = os.path.join(base, name)
                    if not os.path.isdir(p):
                        continue
                    mt = os.path.getmtime(p)
                    rid = name[len("gate_root_"):]
                    if mt > best[1] and rid:
                        best = (rid, mt)
            except Exception:
                pass

            # 2) one-level down: base/*/gate_root_*
            try:
                for name in os.listdir(base):
                    p1 = os.path.join(base, name)
                    if not os.path.isdir(p1):
                        continue
                    try:
                        for name2 in os.listdir(p1):
                            if not name2.startswith("gate_root_"):
                                continue
                            p = os.path.join(p1, name2)
                            if not os.path.isdir(p):
                                continue
                            mt = os.path.getmtime(p)
                            rid = name2[len("gate_root_"):]
                            if mt > best[1] and rid:
                                best = (rid, mt)
                    except Exception:
                        pass
            except Exception:
                pass

        except Exception:
            continue

    rid = best[0]
    _VSP_P0_RID_LATEST_CACHE["ts"] = now
    _VSP_P0_RID_LATEST_CACHE["rid"] = rid
    return rid

def vsp_rid_latest_v1():
    # Always 200 JSON
    try:
        rid = None
        if request is not None:
            rid = (request.args.get("rid") or request.args.get("run_id") or "").strip() or None
        if not rid:
            rid = _vsp_p0_pick_latest_rid_v1()
        gate_root = f"gate_root_{rid}" if rid else None
        return jsonify({
            "ok": bool(rid),
            "rid": rid,
            "gate_root": gate_root,
            "degraded": (not bool(rid)),
            "served_by": __file__,
        }), 200
    except Exception as e:
        try:
            return jsonify({"ok": False, "err": str(e), "served_by": __file__}), 200
        except Exception:
            return ("{}", 200, {"Content-Type":"application/json"})

# Register route if possible
try:
    _app = globals().get("app") or globals().get("application")
    if _app and hasattr(_app, "add_url_rule"):
        try:
            _app.add_url_rule("/api/vsp/rid_latest", "vsp_rid_latest_v1", vsp_rid_latest_v1, methods=["GET"])
        except Exception:
            pass
except Exception:
    pass
# ===================== /VSP_P0_API_RID_LATEST_V1 =====================

# ===================== VSP_P0_API_RELEASE_LATEST_V1 =====================
# Provide stable endpoint: GET /api/vsp/release_latest
try:
  import json as _json
  from pathlib import Path as _Path
  from werkzeug.wrappers import Response as _Resp

  class _VSPReleaseLatestMW:
    def __init__(self, app):
      self.app = app

    def __call__(self, environ, start_response):
      try:
        if (environ.get("REQUEST_METHOD","GET") or "GET").upper() != "GET":
          return self.app(environ, start_response)

        if (environ.get("PATH_INFO","") or "") != "/api/vsp/release_latest":
          return self.app(environ, start_response)

        f = _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/release_latest.json")
        if f.is_file():
          txt = f.read_text(encoding="utf-8", errors="replace").strip()
          try:
            j = _json.loads(txt) if txt else {}
          except Exception:
            j = {"ok": False, "err": "bad_release_latest_json", "_path": str(f)}
          if "ok" not in j: j["ok"] = True
          resp = _Resp(_json.dumps(j, ensure_ascii=False).encode("utf-8"),
                       content_type="application/json; charset=utf-8", status=200)
        else:
          resp = _Resp(_json.dumps({"ok": False, "err": "missing_release_latest_json", "_path": str(f)}).encode("utf-8"),
                       content_type="application/json; charset=utf-8", status=200)
        resp.headers["Cache-Control"] = "no-store"
        return resp(environ, start_response)
      except Exception:
        return self.app(environ, start_response)

  if "application" in globals() and callable(globals().get("application")):
    application = _VSPReleaseLatestMW(application)
except Exception:
  pass
# ===================== /VSP_P0_API_RELEASE_LATEST_V1 =====================
# ===================== VSP_P0_CACHE_HOT_PATHS_V2 =====================
# Runtime cache+fallback for hot endpoints using url_map (works with route/add_url_rule/blueprints).
try:
    import time as _time
    from flask import jsonify as _jsonify

    _APP = globals().get("application") or globals().get("app")
    _VSP_P0_CACHE = {
        "rid_latest_gate_root": {"ts": 0.0, "data": None},
        "runs": {"ts": 0.0, "data": None},
    }

    def _vsp_find_endpoint(app, path):
        try:
            for r in app.url_map.iter_rules():
                if str(r.rule) == path:
                    return r.endpoint
        except Exception:
            return None
        return None

    def _vsp_wrap_cached(app, path, cache_key, ttl_sec):
        ep = _vsp_find_endpoint(app, path)
        if not ep:
            print("[VSP] cachehot: endpoint NOT FOUND for", path)
            return False
        if ep not in app.view_functions:
            print("[VSP] cachehot: view_functions missing for", path, "endpoint=", ep)
            return False

        orig = app.view_functions[ep]

        def wrapped(*args, **kwargs):
            now = _time.time()
            c = _VSP_P0_CACHE[cache_key]
            if c.get("data") and (now - c.get("ts", 0.0)) < ttl_sec:
                return _jsonify(c["data"])
            try:
                resp = orig(*args, **kwargs)
                # If resp is 5xx and we have cache -> serve cache
                try:
                    sc = getattr(resp, "status_code", 200)
                    if sc >= 500 and c.get("data"):
                        return _jsonify(c["data"])
                except Exception:
                    pass
                # Try refresh cache from JSON body
                try:
                    data = resp.get_json(silent=True)
                    if isinstance(data, dict):
                        # heuristic: rid endpoint must have rid; runs endpoint must have ok/items
                        ok1 = (cache_key == "rid_latest_gate_root" and data.get("rid"))
                        ok2 = (cache_key == "runs" and data.get("ok") is True and isinstance(data.get("items"), list))
                        if ok1 or ok2:
                            c["ts"] = now
                            c["data"] = data
                except Exception:
                    pass
                return resp
            except Exception:
                if c.get("data"):
                    return _jsonify(c["data"])
                raise

        app.view_functions[ep] = wrapped
        print("[VSP] cachehot enabled:", path, "endpoint=", ep, "ttl=", ttl_sec)
        return True

    if _APP:
        _vsp_wrap_cached(_APP, "/api/vsp/rid_latest_gate_root", "rid_latest_gate_root", 8.0)
        _vsp_wrap_cached(_APP, "/api/vsp/runs", "runs", 3.0)
except Exception as _e:
    print("[VSP] cachehot V2 skipped:", _e)
# ===================== /VSP_P0_CACHE_HOT_PATHS_V2 =====================

# ===================== VSP_P0_HOT_CACHE_MW_V3 =====================
# WSGI-level micro cache for hot GET endpoints to keep dashboard live polling snappy.
# Rationale: app is wrapped (not always Flask-mountable), so cache at outermost WSGI.
import time as _vsp_time
import threading as _vsp_threading

class _VSPHotCacheWSGI:
    def __init__(self, app, ttl=4.0, max_items=128, max_bytes=256*1024):
        self.app = app
        self.ttl = float(ttl)
        self.max_items = int(max_items)
        self.max_bytes = int(max_bytes)
        self._lock = _vsp_threading.Lock()
        # key -> (exp_ts, status, headers_list, body_bytes)
        self._cache = {}

        # hot endpoints (PATH_INFO). Query string is part of cache key automatically.
        self._hot_paths = {
            "/api/vsp/rid_latest_gate_root",
            "/api/vsp/rid_latest",
            "/api/vsp/runs",
            "/api/vsp/run_file_allow",
        }

    def _is_cacheable(self, environ):
        if environ.get("REQUEST_METHOD", "GET") != "GET":
            return False
        path = environ.get("PATH_INFO") or ""
        if path not in self._hot_paths:
            return False

        # Avoid caching very large payloads (findings_unified.json can be >1MB)
        qs = (environ.get("QUERY_STRING") or "").lower()
        if path == "/api/vsp/run_file_allow":
            # only cache small JSONs
            if "path=run_gate_summary.json" in qs or "path=run_gate.json" in qs:
                return True
            return False

        # /api/vsp/runs can be a bit large but usually still OK; keep it.
        return True

    def __call__(self, environ, start_response):
        try:
            path = environ.get("PATH_INFO") or ""
            qs = environ.get("QUERY_STRING") or ""
            key = path + ("?" + qs if qs else "")

            if not self._is_cacheable(environ):
                return self.app(environ, start_response)

            now = _vsp_time.time()
            with self._lock:
                hit = self._cache.get(key)
                if hit and hit[0] >= now:
                    status, headers, body = hit[1], hit[2], hit[3]
                    start_response(status, headers)
                    return [body]

            # miss: capture downstream response
            captured = {"status": "200 OK", "headers": []}
            def _sr(status, headers, exc_info=None):
                captured["status"] = status
                captured["headers"] = list(headers or [])
                return start_response(status, headers, exc_info)

            it = self.app(environ, _sr)
            body = b""
            try:
                for chunk in it:
                    if chunk:
                        body += chunk
                        if len(body) > self.max_bytes:
                            # too big, do not cache
                            return [body] + list(it)
            finally:
                if hasattr(it, "close"):
                    try: it.close()
                    except Exception: pass

            # store
            with self._lock:
                if len(self._cache) >= self.max_items:
                    # drop oldest expiring
                    k_old = min(self._cache.items(), key=lambda kv: kv[1][0])[0]
                    self._cache.pop(k_old, None)
                self._cache[key] = (now + self.ttl, captured["status"], captured["headers"], body)

            return [body]

        except Exception:
            # fail-open
            return self.app(environ, start_response)

# Wrap outermost WSGI entrypoint if present.
try:
    if "application" in globals() and callable(globals().get("application")):
        application = _VSPHotCacheWSGI(application, ttl=4.0, max_items=128, max_bytes=256*1024)
        try:
            print("[VSP_P0_HOT_CACHE_MW_V3] wrapped application (ttl=4s)")
        except Exception:
            pass
except Exception:
    pass
# ===================== /VSP_P0_HOT_CACHE_MW_V3 =====================


# ===================== VSP_P1_EXPORT_FORCE_OVERRIDE_HOTFIX_V3 =====================
# Apply export override to the *actual* Flask app(s) present in this module.
try:
    import re as _re, json as _json, tarfile as _tarfile
    from pathlib import Path as _Path
    from flask import request as _req, send_file as _send_file, jsonify as _jsonify

    def _vsp__pick_apps_v3():
        apps=[]
        for k,v in list(globals().items()):
            try:
                if hasattr(v, "url_map") and hasattr(v, "view_functions"):
                    apps.append(v)
            except Exception:
                pass
        # also common names
        for k in ("app","application","_app"):
            v = globals().get(k)
            if v is not None and v not in apps:
                try:
                    if hasattr(v, "url_map") and hasattr(v, "view_functions"):
                        apps.append(v)
                except Exception:
                    pass
        return apps

    def _vsp__norm_rid_v3(rid0: str) -> str:
        rid0 = (rid0 or "").strip()
        m = _re.search(r'(\d{8}_\d{6})', rid0)
        return (m.group(1) if m else rid0.replace("VSP_CI_RUN_","").replace("VSP_CI_","").replace("RUN_","")).strip()

    def _vsp__rel_meta_v3():
        try:
            ui_root = _Path(__file__).resolve().parent
            cands = [
                ui_root/"out_ci"/"releases"/"release_latest.json",
                ui_root/"out"/"releases"/"release_latest.json",
                ui_root.parent/"out_ci"/"releases"/"release_latest.json",
                ui_root.parent/"out"/"releases"/"release_latest.json",
            ]
            for f in cands:
                if f.exists():
                    j = _json.loads(f.read_text(encoding="utf-8", errors="replace"))
                    return {
                        "ts": (j.get("ts") or j.get("timestamp") or ""),
                        "sha": (j.get("sha") or j.get("sha256") or ""),
                    }
        except Exception:
            pass
        return {"ts":"", "sha":""}

    def _vsp__resolve_run_dir_v3(rid0: str, rid_norm: str) -> str:
        # prefer existing helper if present
        try:
            if "_vsp__resolve_run_dir_for_export" in globals():
                x = globals()["_vsp__resolve_run_dir_for_export"](rid0, rid_norm)  # type: ignore
                if x:
                    return str(x)
        except Exception:
            pass
        # hard fallback (your confirmed real path)
        cand = _Path("/home/test/Data/SECURITY_BUNDLE/out") / (rid0 if rid0.startswith("RUN_") else f"RUN_{rid_norm}")
        if cand.exists() and cand.is_dir():
            return str(cand)
        # also check CI roots
        for root in [
            _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
            _Path("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        ]:
            try:
                if not root.exists():
                    continue
                for nm in [rid0, f"RUN_{rid_norm}", f"VSP_CI_RUN_{rid_norm}", f"VSP_CI_{rid_norm}", rid_norm]:
                    if not nm:
                        continue
                    c = root / nm
                    if c.exists() and c.is_dir():
                        return str(c)
            except Exception:
                pass
        return ""

    def _vsp__export_build_tgz_v3(run_dir: str, rid_norm: str) -> str:
        rd = _Path(run_dir)
        out = _Path("/tmp") / f"vsp_export_{rid_norm or rd.name}.tgz"
        try:
            if out.exists():
                out.unlink()
        except Exception:
            pass
        picks = [
            rd/"run_gate.json",
            rd/"run_gate_summary.json",
            rd/"findings_unified.json",
            rd/"reports",
            rd/"SUMMARY.txt",
        ]
        with _tarfile.open(out, "w:gz") as tf:
            base = f"{rid_norm or rd.name}"
            for x in picks:
                try:
                    if not x.exists():
                        continue
                    tf.add(str(x), arcname=f"{base}/{x.name}")
                except Exception:
                    continue
        return str(out)

    def api_vsp_run_export_v3_force_hotfix_v3(**kwargs):
        rid0 = (_req.args.get("rid") or _req.args.get("run_id") or _req.args.get("RID") or "").strip()
        if not rid0:
            rid0 = (kwargs.get("rid") or kwargs.get("run_id") or "").strip() if isinstance(kwargs, dict) else ""
        fmt = (_req.args.get("fmt") or "tgz").strip().lower()
        rid_norm = _vsp__norm_rid_v3(rid0)

        run_dir = _vsp__resolve_run_dir_v3(rid0, rid_norm)
        if not run_dir:
            return _jsonify({"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix": "export_override_v3"}), 404

        rel = _vsp__rel_meta_v3()
        suffix = ""
        if rel.get("ts"):
            t = str(rel["ts"]).replace(":","").replace("-","").replace("T","_")
            suffix += f"_rel-{t[:15]}"
        if rel.get("sha"):
            suffix += f"_sha-{str(rel['sha'])[:12]}"

        if fmt == "tgz":
            fp = _vsp__export_build_tgz_v3(run_dir, rid_norm or rid0)
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.tgz"
            resp = _send_file(fp, as_attachment=True, download_name=dl, mimetype="application/gzip")
            try: resp.headers["X-VSP-HOTFIX"] = "export_override_v3"
            except Exception: pass
            return resp

        if fmt == "csv":
            rd = _Path(run_dir)
            cand = rd/"reports"/"findings_unified.csv"
            if not cand.exists():
                cand = rd/"reports"/"findings.csv"
            if not cand.exists():
                return _jsonify({"ok": False, "error": "CSV_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix": "export_override_v3"}), 404
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.csv"
            resp = _send_file(str(cand), as_attachment=True, download_name=dl, mimetype="text/csv")
            try: resp.headers["X-VSP-HOTFIX"] = "export_override_v3"
            except Exception: pass
            return resp

        if fmt == "html":
            rd = _Path(run_dir)
            cand = rd/"reports"/"findings_unified.html"
            if not cand.exists():
                cand = rd/"reports"/"index.html"
            if not cand.exists():
                return _jsonify({"ok": False, "error": "HTML_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix": "export_override_v3"}), 404
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.html"
            resp = _send_file(str(cand), as_attachment=True, download_name=dl, mimetype="text/html")
            try: resp.headers["X-VSP-HOTFIX"] = "export_override_v3"
            except Exception: pass
            return resp

        return _jsonify({"ok": False, "error": "FMT_UNSUPPORTED", "fmt": fmt, "hotfix":"export_override_v3"}), 400

    # Bind override to all endpoints whose rule is /api/vsp/run_export_v3 (or contains run_export_v3)
    for __A in _vsp__pick_apps_v3():
        try:
            eps=set()
            for rule in __A.url_map.iter_rules():
                rr = getattr(rule, "rule", "") or ""
                if rr == "/api/vsp/run_export_v3" or "run_export_v3" in rr:
                    eps.add(rule.endpoint)
            for ep in eps:
                try:
                    __A.view_functions[ep] = api_vsp_run_export_v3_force_hotfix_v3
                except Exception:
                    pass
        except Exception:
            pass
except Exception:
    pass
# ===================== /VSP_P1_EXPORT_FORCE_OVERRIDE_HOTFIX_V3 =====================


# ===================== VSP_P1_WSGI_INTERCEPT_RUN_EXPORT_V4 =====================
# Intercept /api/vsp/run_export_v3 at WSGI layer to bypass proxy/dispatcher route ambiguity.
try:
    import os, re, json, tarfile
    from pathlib import Path as _Path
    from urllib.parse import parse_qs as _parse_qs

    def _vsp__rid_norm_v4(rid0: str) -> str:
        rid0 = (rid0 or "").strip()
        m = re.search(r'(\d{8}_\d{6})', rid0)
        if m:
            return m.group(1)
        return rid0.replace("VSP_CI_RUN_","").replace("VSP_CI_","").replace("RUN_","").strip()

    def _vsp__resolve_run_dir_v4(rid0: str, rid_norm: str) -> str:
        # strongest: the path you already confirmed exists
        cand = _Path("/home/test/Data/SECURITY_BUNDLE/out") / (rid0 if rid0.startswith("RUN_") else f"RUN_{rid_norm}")
        if cand.exists() and cand.is_dir():
            return str(cand)

        ui_root = _Path(__file__).resolve().parent
        bundle_root = ui_root.parent
        roots = [
            ui_root/"out_ci", ui_root/"out",
            bundle_root/"out_ci", bundle_root/"out",
            _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        ]

        names = []
        for x in [rid0, rid_norm]:
            if x and x not in names:
                names.append(x)
        if rid_norm:
            for pref in ["RUN_","VSP_CI_RUN_","VSP_CI_"]:
                n = pref + rid_norm
                if n not in names:
                    names.append(n)

        for root in roots:
            try:
                if not root.exists(): 
                    continue
                for nm in names:
                    c = root / nm
                    if c.exists() and c.is_dir():
                        return str(c)
            except Exception:
                pass
        return ""

    def _vsp__wsgi_json(start_response, code: str, payload: dict):
        body = (json.dumps(payload, ensure_ascii=False)).encode("utf-8")
        hdrs = [
            ("Content-Type","application/json; charset=utf-8"),
            ("Content-Length", str(len(body))),
            ("X-VSP-HOTFIX","wsgi_export_v4"),
        ]
        start_response(code, hdrs)
        return [body]

    def _vsp__rel_meta_v4():
        # read release_latest.json from common locations; return dict(ts, sha, package)
        try:
            ui_root = _Path(__file__).resolve().parent
            cands = [
                ui_root/'out_ci'/'releases'/'release_latest.json',
                ui_root/'out'/'releases'/'release_latest.json',
                ui_root.parent/'out_ci'/'releases'/'release_latest.json',
                ui_root.parent/'out'/'releases'/'release_latest.json',
                _Path('/home/test/Data/SECURITY_BUNDLE/ui/out_ci/releases/release_latest.json'),
                _Path('/home/test/Data/SECURITY_BUNDLE/out_ci/releases/release_latest.json'),
            ]
            for f in cands:
                if f.exists():
                    j = json.loads(f.read_text(encoding='utf-8', errors='replace'))
                    return {
                        'ts': (j.get('ts') or j.get('timestamp') or ''),
                        'sha': (j.get('sha') or j.get('sha256') or ''),
                        'package': (j.get('package') or j.get('pkg') or j.get('file') or ''),
                    }
        except Exception:
            pass
        return {'ts':'', 'sha':'', 'package':''}

    def _vsp__tgz_build_v4(run_dir: str, rid_norm: str) -> str:
        rd = _Path(run_dir)
        out = _Path("/tmp") / f"vsp_export_{rid_norm or rd.name}.tgz"
        try:
            if out.exists(): out.unlink()
        except Exception:
            pass

        picks = [
            rd/"run_gate.json",
            rd/"run_gate_summary.json",
            rd/"findings_unified.json",
            rd/"reports",
            rd/"SUMMARY.txt",
        ]
        with tarfile.open(out, "w:gz") as tf:
            base = f"{rid_norm or rd.name}"
            for x in picks:
                try:
                    if not x.exists(): 
                        continue
                    tf.add(str(x), arcname=f"{base}/{x.name}")
                except Exception:
                    continue
        return str(out)

    def _vsp__wsgi_send_file(start_response, fp: str, dl_name: str, ctype: str):
        fsz = 0
        try:
            fsz = os.path.getsize(fp)
        except Exception:
            fsz = 0
        hdrs = [
            ("Content-Type", ctype),
            ("Content-Disposition", f'attachment; filename="{dl_name}"'),
            ("Content-Length", str(fsz)),
            ("X-VSP-HOTFIX","wsgi_export_v4"),
        ]
        start_response("200 OK", hdrs)

        file_wrapper = None
        try:
            # wsgi.file_wrapper may exist in environ but not here; fallback to chunk iterator
            file_wrapper = None
        except Exception:
            file_wrapper = None

        def _iterfile():
            with open(fp, "rb") as f:
                while True:
                    b = f.read(1024*256)
                    if not b:
                        break
                    yield b
        return _iterfile()

    def _vsp_wsgi_export_intercept_v4(app_callable):
        def _wrap(environ, start_response):
            try:
                path = (environ.get("PATH_INFO") or "").strip()
                if path != "/api/vsp/run_export_v3":
                    return app_callable(environ, start_response)

                qs = _parse_qs(environ.get("QUERY_STRING",""), keep_blank_values=True)
                rid0 = (qs.get("rid",[""])[0] or qs.get("run_id",[""])[0] or "").strip()
                fmt = (qs.get("fmt",["tgz"])[0] or "tgz").strip().lower()
                rid_norm = _vsp__rid_norm_v4(rid0)

                run_dir = _vsp__resolve_run_dir_v4(rid0, rid_norm)
                if not run_dir:
                    return _vsp__wsgi_json(start_response, "404 NOT FOUND", {
                        "ok": False, "error":"RUN_DIR_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix":"wsgi_export_v4"
                    })

                if fmt == "tgz":
                    fp = _vsp__tgz_build_v4(run_dir, rid_norm or rid0)
                    rel = _vsp__rel_meta_v4()
                    suffix = ''
                    ts0 = str(rel.get('ts') or '').strip()
                    if ts0:
                        t = ts0.replace(':','').replace('-','').replace('T','_')
                        t15 = t[:15]
                        if t15: suffix += f"_rel-{t15}"
                    else:
                        suffix += "_norel-20251221_201954"
                    sha12 = str(rel.get('sha') or '').strip()[:12]
                    if sha12: suffix += f"_sha-{sha12}"
                    dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.tgz"
                    return _vsp__wsgi_send_file(start_response, fp, dl, "application/gzip")

                # csv/html: best-effort direct file
                rd = _Path(run_dir)
                if fmt == "csv":
                    cand = rd/"reports"/"findings_unified.csv"
                    if not cand.exists(): cand = rd/"reports"/"findings.csv"
                    if not cand.exists():
                        return _vsp__wsgi_json(start_response, "404 NOT FOUND", {"ok":False,"error":"CSV_NOT_FOUND","rid":rid0,"rid_norm":rid_norm,"hotfix":"wsgi_export_v4"})
                    return _vsp__wsgi_send_file(start_response, str(cand), f"VSP_EXPORT_{rid_norm or rid0}.csv", "text/csv")

                if fmt == "html":
                    cand = rd/"reports"/"findings_unified.html"
                    if not cand.exists(): cand = rd/"reports"/"index.html"
                    if not cand.exists():
                        return _vsp__wsgi_json(start_response, "404 NOT FOUND", {"ok":False,"error":"HTML_NOT_FOUND","rid":rid0,"rid_norm":rid_norm,"hotfix":"wsgi_export_v4"})
                    return _vsp__wsgi_send_file(start_response, str(cand), f"VSP_EXPORT_{rid_norm or rid0}.html", "text/html")

                return _vsp__wsgi_json(start_response, "400 BAD REQUEST", {"ok":False,"error":"FMT_UNSUPPORTED","fmt":fmt,"hotfix":"wsgi_export_v4"})
            except Exception as e:
                return _vsp__wsgi_json(start_response, "500 INTERNAL SERVER ERROR", {"ok":False,"error":"HOTFIX_EXCEPTION","msg":str(e),"hotfix":"wsgi_export_v4"})
        return _wrap

    # wrap both 'application' and 'app' if present
    _orig = globals().get("application") or globals().get("app")
    if callable(_orig):
        _wrapped = _vsp_wsgi_export_intercept_v4(_orig)
        if "application" in globals(): globals()["application"] = _wrapped
        if "app" in globals(): globals()["app"] = _wrapped
except Exception:
    pass
# ===================== /VSP_P1_WSGI_INTERCEPT_RUN_EXPORT_V4 =====================

# ===================== VSP_P1_API_RELEASE_LATEST_JSON_V1 =====================
# Provide /api/vsp/release_latest.json for Runs "Current Release" card (NO_PKG/STALE/OK)
# - Reads release_latest.json from common roots (no user-supplied path)
# - Resolves package path safely (absolute or relative under SECURITY_BUNDLE roots)
# - Always returns HTTP 200 JSON (ok=true; status indicates state)
# ============================================================================

def _vsp__now_ts_int():
    try:
        import time
        return int(time.time())
    except Exception:
        return 0

def _vsp__release_latest_json_paths_v1():
    # keep in sync with ops scripts
    return [
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/releases/release_latest.json",
        "/home/test/Data/SECURITY_BUNDLE/ui/out/releases/release_latest.json",
        "/home/test/Data/SECURITY_BUNDLE/out_ci/releases/release_latest.json",
        "/home/test/Data/SECURITY_BUNDLE/out/releases/release_latest.json",
    ]

def _vsp__resolve_pkg_path_v1(pkg: str, json_path: str):
    try:
        from pathlib import Path
        pkg = (pkg or "").strip()
        if not pkg:
            return None
        cand = []
        p = Path(pkg)
        if p.is_absolute():
            cand.append(p)
        else:
            # try relative under known roots
            cand.append(Path("/home/test/Data/SECURITY_BUNDLE/ui") / pkg)
            cand.append(Path("/home/test/Data/SECURITY_BUNDLE") / pkg)
            # also relative to json directory
            try:
                cand.append(Path(json_path).parent.parent.parent / pkg)
            except Exception:
                pass
        for c in cand:
            try:
                if c.exists() and c.is_file():
                    return str(c)
            except Exception:
                continue
        return None
    except Exception:
        return None

def _vsp__load_release_latest_v1():
    import json, os
    out = {
        "ok": True,
        "status": "NO_PKG",   # NO_PKG | STALE | OK | ERROR
        "ts": None,
        "package": None,
        "sha": None,
        "json_path": None,
        "package_exists": None,
        "package_path": None,
        "_ts": _vsp__now_ts_int(),
    }

    jp = None
    for path in _vsp__release_latest_json_paths_v1():
        try:
            if os.path.isfile(path):
                jp = path
                break
        except Exception:
            continue

    if not jp:
        return out

    out["json_path"] = jp
    try:
        with open(jp, "r", encoding="utf-8") as f:
            j = json.load(f)
    except Exception as e:
        out["ok"] = False
        out["status"] = "ERROR"
        out["error"] = "RELEASE_JSON_PARSE_ERROR"
        out["detail"] = str(e)
        return out

    out["ts"] = j.get("ts") or j.get("time") or j.get("created_at")
    out["package"] = j.get("package") or j.get("pkg") or j.get("path")
    out["sha"] = j.get("sha") or j.get("sha256") or j.get("hash")

    pkg_path = _vsp__resolve_pkg_path_v1(str(out["package"] or ""), jp)
    if not out["package"]:
        out["status"] = "NO_PKG"
        out["package_exists"] = None
        out["package_path"] = None
        return out

    if pkg_path:
        out["status"] = "OK"
        out["package_exists"] = True
        out["package_path"] = pkg_path
    else:
        out["status"] = "STALE"
        out["package_exists"] = False
        out["package_path"] = None

    return out

try:
    from flask import jsonify
    _vsp_app = globals().get("app") or globals().get("application")
    if _vsp_app:
        @_vsp_app.route("/api/vsp/release_latest.json", methods=["GET"])
        def api_vsp_release_latest_json_v1():
            return jsonify(_vsp__load_release_latest_v1()), 200
except Exception:
    pass

# ===================== /VSP_P1_API_RELEASE_LATEST_JSON_V1 =====================


# ===================== VSP_P1_AFTERREQ_OKWRAP_RUNFILEALLOW_V1 =====================
# Contractize /api/vsp/run_file_allow?path=run_gate_summary.json / run_gate.json => always include ok:true (+ rid/run_id)
def _vsp_after_request_okwrap_runfileallow(resp):
    try:
        from flask import request as _req
        if _req.path != "/api/vsp/run_file_allow":
            return resp
        _path = _req.args.get("path", "") or ""
        if not (str(_path).endswith("run_gate_summary.json") or str(_path).endswith("run_gate.json")):
            return resp

        _rid = _req.args.get("rid", "") or ""
        try:
            resp.direct_passthrough = False
        except Exception:
            pass
        txt = resp.get_data(as_text=True)

        import json as _json
        j = _json.loads(txt)
        if isinstance(j, dict):
            j.setdefault("ok", True)
            if _rid:
                j.setdefault("rid", _rid)
                j.setdefault("run_id", _rid)
            out = _json.dumps(j, ensure_ascii=False)
            resp.set_data(out)
            resp.headers["Content-Type"] = "application/json; charset=utf-8"
            resp.headers["Cache-Control"] = "no-cache"
            resp.headers["Content-Length"] = str(len(resp.get_data()))
        return resp
    except Exception:
        return resp

# register to whichever Flask app exists in this module
try:
    _APP = globals().get("app") or globals().get("application")
    if _APP is not None and hasattr(_APP, "after_request"):
        _APP.after_request(_vsp_after_request_okwrap_runfileallow)
except Exception:
    pass
# ===================== /VSP_P1_AFTERREQ_OKWRAP_RUNFILEALLOW_V1 =====================

# ===================== VSP_P1_API_RELEASE_LATEST_JSON_V2 =====================
# Provide /api/vsp/release_latest.json (ALWAYS 200) to support Release Card v2.
# - resolves file across common roots
# - returns ok/exists + package_exists for STALE amber in UI
# ============================================================================

def _vsp__get_flask_app_v2():
    # Try common names used in this gateway.
    for name in ("app", "application"):
        obj = globals().get(name)
        if obj is None:
            continue
        # Flask app has add_url_rule / view_functions / route
        if hasattr(obj, "add_url_rule") and hasattr(obj, "view_functions"):
            return obj
    return None

def _vsp__release_latest_search_paths_v2():
    from pathlib import Path as _Path
    here = _Path(__file__).resolve()
    ui_root = here.parent  # .../SECURITY_BUNDLE/ui
    bundle_root = ui_root.parent  # .../SECURITY_BUNDLE

    cands = [
        ui_root / "out_ci" / "releases" / "release_latest.json",
        ui_root / "out" / "releases" / "release_latest.json",
        bundle_root / "out_ci" / "releases" / "release_latest.json",
        bundle_root / "out" / "releases" / "release_latest.json",
    ]
    return cands

def _vsp__read_release_latest_v2():
    import json, time
    from pathlib import Path as _Path

    for f in _vsp__release_latest_search_paths_v2():
        try:
            if f.is_file():
                j = json.loads(f.read_text(encoding="utf-8", errors="replace"))
                pkg = (j.get("package") or "").strip()
                sha = (j.get("sha") or "").strip()
                ts  = (j.get("ts") or "").strip()

                # resolve package existence:
                pkg_exists = None
                pkg_abs = None
                if pkg:
                    # allow "out_ci/releases/xxx.tgz" or absolute
                    p2 = _Path(pkg)
                    if not p2.is_absolute():
                        # interpret relative to UI root and bundle root
                        ui_root = _Path(__file__).resolve().parent
                        bundle_root = ui_root.parent
                        cand = ui_root / pkg
                        cand2 = bundle_root / pkg
                        if cand.is_file():
                            pkg_abs = str(cand)
                            pkg_exists = True
                        elif cand2.is_file():
                            pkg_abs = str(cand2)
                            pkg_exists = True
                        else:
                            pkg_abs = str(cand)  # best-effort for debug
                            pkg_exists = False
                    else:
                        pkg_abs = str(p2)
                        pkg_exists = bool(p2.is_file())

                return {
                    "ok": True,
                    "exists": True,
                    "source": str(f),
                    "ts": ts,
                    "package": pkg,
                    "sha": sha,
                    "package_exists": pkg_exists,
                    "package_abs": pkg_abs,
                }
        except Exception:
            continue

    return {
        "ok": False,
        "exists": False,
        "error": "RELEASE_LATEST_NOT_FOUND",
        "searched": [str(x) for x in _vsp__release_latest_search_paths_v2()],
        "ts": __import__("time").time(),
    }

def api_vsp_release_latest_json_v2():
    # ALWAYS 200 to avoid console spam; UI decides STALE.
    try:
        from flask import jsonify
    except Exception:
        # very defensive fallback
        import json
        return (json.dumps(_vsp__read_release_latest_v2()), 200, {"Content-Type":"application/json"})
    return jsonify(_vsp__read_release_latest_v2()), 200

_A = _vsp__get_flask_app_v2()
if _A is not None:
    ep = "api_vsp_release_latest_json_v2"
    if not hasattr(_A, "view_functions") or ep not in getattr(_A, "view_functions", {}):
        try:
            _A.add_url_rule("/api/vsp/release_latest.json", ep, api_vsp_release_latest_json_v2, methods=["GET"])
        except Exception:
            pass
# ===================== /VSP_P1_API_RELEASE_LATEST_JSON_V2 =====================

# ===================== VSP_P1_WSGI_INTERCEPT_RELEASE_LATEST_JSON_V1 =====================
# Intercept /api/vsp/release_latest.json at WSGI layer (ALWAYS 200) to avoid 404 spam and
# support Release Card v2 STALE/NO-PKG logic.
# ============================================================================

def _vsp__release_latest_payload_v1():
    import json, time
    from pathlib import Path as _P

    here = _P(__file__).resolve()
    ui_root = here.parent
    bundle_root = ui_root.parent

    cands = [
        ui_root / "out_ci" / "releases" / "release_latest.json",
        ui_root / "out" / "releases" / "release_latest.json",
        bundle_root / "out_ci" / "releases" / "release_latest.json",
        bundle_root / "out" / "releases" / "release_latest.json",
    ]

    for f in cands:
        try:
            if f.is_file():
                j = json.loads(f.read_text(encoding="utf-8", errors="replace"))
                pkg = (j.get("package") or "").strip()
                sha = (j.get("sha") or "").strip()
                ts  = (j.get("ts") or "").strip()

                pkg_exists = None
                pkg_abs = None
                if pkg:
                    p2 = _P(pkg)
                    if not p2.is_absolute():
                        cand1 = ui_root / pkg
                        cand2 = bundle_root / pkg
                        if cand1.is_file():
                            pkg_abs = str(cand1); pkg_exists = True
                        elif cand2.is_file():
                            pkg_abs = str(cand2); pkg_exists = True
                        else:
                            pkg_abs = str(cand1); pkg_exists = False
                    else:
                        pkg_abs = str(p2); pkg_exists = bool(p2.is_file())

                return {
                    "ok": True,
                    "exists": True,
                    "source": str(f),
                    "ts": ts,
                    "package": pkg,
                    "sha": sha,
                    "package_exists": pkg_exists,
                    "package_abs": pkg_abs,
                }
        except Exception:
            continue

    return {
        "ok": False,
        "exists": False,
        "error": "RELEASE_LATEST_NOT_FOUND",
        "searched": [str(x) for x in cands],
        "ts": time.time(),
    }

def _vsp__wsgi_intercept_release_latest_json_v1(_next):
    def _app(environ, start_response):
        path = (environ.get("PATH_INFO") or "").rstrip("/")
        if path == "/api/vsp/release_latest.json":
            import json
            payload = _vsp__release_latest_payload_v1()
            body = (json.dumps(payload, ensure_ascii=False)).encode("utf-8")
            headers = [
                ("Content-Type","application/json; charset=utf-8"),
                ("Content-Length", str(len(body))),
                ("Cache-Control","no-store"),
                ("X-VSP-HOTFIX","wsgi_release_latest_v1"),
            ]
            start_response("200 OK", headers)
            return [body]
        return _next(environ, start_response)
    return _app

try:
    application = _vsp__wsgi_intercept_release_latest_json_v1(application)
except Exception:
    pass
# ===================== /VSP_P1_WSGI_INTERCEPT_RELEASE_LATEST_JSON_V1 =====================


# ===================== VSP_P1_RELEASE_LATEST_REALFILE_INTERCEPT_V2_SAFEAPPEND =====================
def _vsp_release_latest_realfile_intercept_v2(wsgi_app):
    import json, time, os
    from pathlib import Path

    def _read_release_latest():
        cands = []
        envp = os.environ.get("VSP_RELEASE_LATEST_JSON", "").strip()
        if envp:
            cands.append(envp)
        cands += [
            "/home/test/Data/SECURITY_BUNDLE/out_ci/releases/release_latest.json",
            "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/releases/release_latest.json",
            str(Path(__file__).resolve().parent / "out_ci" / "releases" / "release_latest.json"),
            str(Path(__file__).resolve().parent / "out" / "releases" / "release_latest.json"),
        ]
        for x in cands:
            try:
                rp = Path(x)
                if rp.is_file() and rp.stat().st_size > 0:
                    return json.loads(rp.read_text(encoding="utf-8", errors="replace")), str(rp)
            except Exception:
                continue
        return {}, ""

    def _pkg_exists(pkg: str):
        if not pkg:
            return (False, "")
        pkg = pkg.strip()
        pp = Path(pkg) if pkg.startswith("/") else (Path("/home/test/Data/SECURITY_BUNDLE") / pkg)
        ok = pp.is_file() and pp.stat().st_size > 0
        return (ok, str(pp))

    def _resp_json(start_response, payload: dict):
        body = (json.dumps(payload, ensure_ascii=False)).encode("utf-8")
        headers = [
            ("Content-Type", "application/json; charset=utf-8"),
            ("Cache-Control", "no-store"),
            ("Content-Length", str(len(body))),
        ]
        if payload.get("release_ts"):  headers.append(("X-VSP-RELEASE-TS", str(payload["release_ts"])))
        if payload.get("release_sha"): headers.append(("X-VSP-RELEASE-SHA", str(payload["release_sha"])))
        if payload.get("release_pkg"): headers.append(("X-VSP-RELEASE-PKG", str(payload["release_pkg"])))
        headers.append(("X-VSP-RELEASE-LATEST", "ok"))
        start_response("200 OK", headers)
        return [body]

    def _app(environ, start_response):
        try:
            if environ.get("PATH_INFO") == "/api/vsp/release_latest":
                relj, src = _read_release_latest()
                pkg = str(relj.get("release_pkg") or "").strip()
                ok_pkg, abs_pkg = _pkg_exists(pkg)
                out = {
                    "ok": True,
                    "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                    "release_status": "OK" if ok_pkg else "STALE",
                "status": "OK" if ok_pkg else "NO PKG",
                    "release_ts": relj.get("release_ts",""),
                    "release_sha": relj.get("release_sha",""),
                    "release_pkg": pkg,
                    "release_pkg_exists": ok_pkg,
                    "release_pkg_abs": abs_pkg,
                    "source_json": src,
                
        # --- compat keys for legacy UI card (expects ts/package/sha) ---
        "updated": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "ts": relj.get("release_ts","") or time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "package": pkg,
        "sha": relj.get("release_sha",""),
        "sha12": (str(relj.get("release_sha",""))[:12] if relj.get("release_sha") else ""),
        "ok_pkg": ok_pkg,
}
                return _resp_json(start_response, out)
        except Exception as e:
            out = {"ok": True, "release_status": "STALE", "err": str(e)}
            return _resp_json(start_response, out)
        return wsgi_app(environ, start_response)

    return _app
# ===================== /VSP_P1_RELEASE_LATEST_REALFILE_INTERCEPT_V2_SAFEAPPEND =====================

# Activate at EOF (safe order: after all other wrappers)
try:
    application = _vsp_release_latest_realfile_intercept_v2(application)
    app = application
except Exception:
    pass



# VSP_P0_VSP5_DEDUPE_GATE_STORY_V1



# ===================== VSP_P0_VSP5_HTML_DEDUPE_GATE_STORY_MW_V2 =====================
import re as _re

class _Vsp5HtmlDedupeGateStoryMW_V2:
    __slots__ = ("app",)
    def __init__(self, app):
        self.app = app
        try:
            setattr(self.app, "__vsp_p0_vsp5_html_dedupe_gate_story_mw_v2", True)
        except Exception:
            pass

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if not (path == "/vsp5" or path.startswith("/vsp5/")):
            return self.app(environ, start_response)

        captured = {"status": None, "headers": None}

        # IMPORTANT: do NOT call downstream start_response here.
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers)
            return (lambda _x=None: None)

        it = self.app(environ, _sr)

        ctype = ""
        try:
            for k, v in (captured["headers"] or []):
                if str(k).lower() == "content-type":
                    ctype = str(v)
                    break
        except Exception:
            ctype = ""

        if "text/html" not in (ctype or "").lower():
            start_response(captured["status"] or "200 OK", captured["headers"] or [])
            return it

        body_chunks = []
        try:
            for chunk in it:
                body_chunks.append(chunk)
        finally:
            try:
                close = getattr(it, "close", None)
                if callable(close): close()
            except Exception:
                pass

        body = b"".join(body_chunks)
        try:
            html = body.decode("utf-8", errors="replace")
        except Exception:
            start_response(captured["status"] or "200 OK", captured["headers"] or [])
            return [body]

        pat = _re.compile(r'(?is)<script[^>]+src="/static/js/vsp_dashboard_gate_story_v1\.js[^"]*"[^>]*>\s*</script>')
        ms = list(pat.finditer(html))
        if len(ms) > 1:
            for a, b in sorted((m.span() for m in ms[1:]), key=lambda x: x[0], reverse=True):
                html = html[:a] + "" + html[b:]

        out = html.encode("utf-8", errors="ignore")

        new_headers = []
        for k, v in (captured["headers"] or []):
            if str(k).lower() == "content-length":
                continue
            new_headers.append((k, v))
        new_headers.append(("Content-Length", str(len(out))))

        start_response(captured["status"] or "200 OK", new_headers)
        return [out]

try:
    _app_obj = application
except Exception:
    _app_obj = None

if _app_obj is not None and not getattr(_app_obj, "__vsp_p0_vsp5_html_dedupe_gate_story_mw_v2", False):
    application = _Vsp5HtmlDedupeGateStoryMW_V2(_app_obj)
# ===================== /VSP_P0_VSP5_HTML_DEDUPE_GATE_STORY_MW_V2 =====================


# ===================== VSP_P0_VSP5_DASHBOARD_ONLY_REWRITE_MW_V1 =====================
def _vsp5_dashonly_rewrite_mw(app):
    import re, time
    def _wrap(environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if path != "/vsp5":
            return app(environ, start_response)

        captured = {"status":None, "headers":None}
        def _sr(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = headers
            return lambda x: None

        body_iter = app(environ, _sr)
        try:
            body = b"".join(body_iter)
        finally:
            try:
                close = getattr(body_iter, "close", None)
                if close: close()
            except Exception:
                pass

        # Only rewrite HTML
        hdrs = captured["headers"] or []
        ctype = ""
        for k,v in hdrs:
            if str(k).lower() == "content-type":
                ctype = str(v).lower()
                break
        if "text/html" not in ctype:
            start_response(captured["status"] or "200 OK", hdrs)
            return [body]

        html = body.decode("utf-8", "replace")

        # 1) Remove extra dashboard scripts (gate_story / containers_fix / luxe / rid_autofix etc.)
        html = re.sub(r'<script[^>]+src=["\']/static/js/vsp_dashboard_gate_story_v1\.js[^"\']*["\'][^>]*>\s*</script>\s*', '', html, flags=re.I)
        html = re.sub(r'<script[^>]+src=["\']/static/js/vsp_dashboard_containers_fix_v1\.js[^"\']*["\'][^>]*>\s*</script>\s*', '', html, flags=re.I)
        html = re.sub(r'<script[^>]+src=["\']/static/js/vsp_dashboard_luxe_v1\.js[^"\']*["\'][^>]*>\s*</script>\s*', '', html, flags=re.I)
        html = re.sub(r'<script[^>]+src=["\']/static/js/vsp_rid_autofix_v1\.js[^"\']*["\'][^>]*>\s*</script>\s*', '', html, flags=re.I)

        # 2) Ensure polish css is present
        if "/static/css/vsp_dashboard_polish_v1.css" not in html:
            html = re.sub(r'</title>\s*', "</title>\n  <link rel='stylesheet' href='/static/css/vsp_dashboard_polish_v1.css'/>\n", html, count=1, flags=re.I)

        # 3) Add dash-only flags (before scripts)
        flag = "<script>window.__VSP_DASH_ONLY=1;window.__VSP_DASHBOARD_ONLY=1;window.__VSP_DISABLE_AUTOFRESH=1;window.__VSP_DISABLE_RUNS_META=1;window.__VSP_DISABLE_LUXE=1;</script>"
        if "window.__VSP_DASH_ONLY" not in html:
            html = re.sub(r'(<div id="vsp5_root"\s*></div>)', r'\1\n  ' + flag, html, count=1, flags=re.I)

        # 4) Keep only minimal scripts: fetch_shim + commercial bundle
        # Remove all /static/js script tags then re-add the two we want, using same ?v= if present.
        m = re.search(r'v=([0-9]{10,})', html)
        v = m.group(1) if m else str(int(time.time()))
        html = re.sub(r'<script[^>]+src=["\']/static/js/[^"\']+["\'][^>]*>\s*</script>\s*', '', html, flags=re.I)

        inject = (
          f"\n  <script src=\"/static/js/vsp_p0_fetch_shim_v1.js?v={v}\"></script>"
          f"\n  <script src=\"/static/js/vsp_bundle_commercial_v2.js?v={v}\"></script>\n"
        )
        if "</body>" in html:
            html = html.replace("</body>", inject + "</body>", 1)
        else:
            html += inject

        out = html.encode("utf-8")

        # Fix headers (Content-Length)
        new_headers = []
        for k,vh in (captured["headers"] or []):
            if str(k).lower() == "content-length":
                continue
            new_headers.append((k,vh))
        new_headers.append(("Content-Length", str(len(out))))

        start_response(captured["status"] or "200 OK", new_headers)
        return [out]
    return _wrap
# ===================== /VSP_P0_VSP5_DASHBOARD_ONLY_REWRITE_MW_V1 =====================


# VSP_P0_VSP5_DASHBOARD_ONLY_REWRITE_MW_V1 apply
try:
    application = _vsp5_dashonly_rewrite_mw(application)
except Exception as _e:
    pass


    # ===================== VSP_P0_VSP5_DASH_ONLY_CLEAN_MW_V1 =====================
    # Serve /vsp5 as DASH-ONLY page (no vsp_bundle_commercial_v2.js) to stop "jump"/double-render.
    import os, json, time
    from datetime import datetime

    def _vsp_json(start_response, code, obj):
        body = json.dumps(obj, ensure_ascii=False, separators=(",",":")).encode("utf-8")
        headers = [
            ("Content-Type","application/json; charset=utf-8"),
            ("Cache-Control","no-cache, no-store, must-revalidate"),
            ("Pragma","no-cache"),
            ("Expires","0"),
            ("Content-Length", str(len(body))),
        ]
        start_response(code, headers)
        return [body]

    def _vsp_text(start_response, code, text, ctype="text/html; charset=utf-8"):
        body = text.encode("utf-8")
        headers = [
            ("Content-Type", ctype),
            ("Cache-Control","no-cache, no-store, must-revalidate"),
            ("Pragma","no-cache"),
            ("Expires","0"),
            ("Content-Length", str(len(body))),
        ]
        start_response(code, headers)
        return [body]

    def _vsp_guess_run_roots():
        # Best-effort roots (override with env VSP_RUNS_ROOT if needed)
        roots = []
        env = os.environ.get("VSP_RUNS_ROOT","").strip()
        if env:
            roots.extend([x.strip() for x in env.split(":") if x.strip()])
        roots += [
            "/home/test/Data/SECURITY_BUNDLE/out_ci",
            "/home/test/Data/SECURITY_BUNDLE/out",
            "/home/test/Data/SECURITY-10-10-v4/out_ci",
            "/home/test/Data/SECURITY-10-10-v4/out",
            "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        ]
        # keep existing ones only
        out=[]
        for r in roots:
            try:
                if os.path.isdir(r):
                    out.append(r)
            except Exception:
                pass
        return out

    def _vsp_scan_runs(limit=200):
        roots = _vsp_guess_run_roots()
        found = []
        wanted = ("run_gate_summary.json","run_gate.json","findings_unified.json")
        for root in roots:
            try:
                for name in os.listdir(root):
                    d = os.path.join(root, name)
                    if not os.path.isdir(d): 
                        continue
                    # accept dirs likely to be runs
                    if not (name.startswith("RUN_") or name.startswith("VSP_") or name.startswith("AATE_")):
                        # still allow if it contains key files
                        pass
                    hit = False
                    for fn in wanted:
                        if os.path.exists(os.path.join(d, fn)) or os.path.exists(os.path.join(d, "reports", "findings_unified.csv")):
                            hit = True
                            break
                    if not hit:
                        continue
                    st = os.stat(d)
                    found.append({"rid": name, "root": root, "mtime": int(st.st_mtime)})
            except Exception:
                continue
        found.sort(key=lambda x: x["mtime"], reverse=True)
        return found[:limit]

    def _vsp5_dash_only_html():
        # minimal /vsp5 shell (nav kept), only loads fetch shim + dash-only JS + dash-only CSS
        v = str(int(time.time()))
        return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
  <meta http-equiv="Pragma" content="no-cache"/>
  <meta http-equiv="Expires" content="0"/>
  <title>VSP5</title>
  <link rel="stylesheet" href="/static/css/vsp_dash_only_v1.css?v={v}"/>
  <style>
    body{{ margin:0; background:#0b1220; color:rgba(226,232,240,.96);
          font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; }}
    .vsp5nav{{ display:flex; gap:10px; padding:10px 14px; border-bottom:1px solid rgba(255,255,255,.10);
              background: rgba(0,0,0,.22); position:sticky; top:0; z-index:9999; }}
    .vsp5nav a{{ color:rgba(226,232,240,.92); text-decoration:none; font-size:12px;
                padding:8px 10px; border:1px solid rgba(255,255,255,.14); border-radius:12px; }}
    .vsp5nav a:hover{{ background: rgba(255,255,255,.06); }}
    #vsp5_root{{ min-height: 60vh; }}
  </style>
</head>
<body>
  <div class="vsp5nav">
    <a href="/vsp5">Dashboard</a>
    <a href="/runs">Runs &amp; Reports</a>
    <a href="/data_source">Data Source</a>
    <a href="/settings">Settings</a>
    <a href="/rule_overrides">Rule Overrides</a>
  </div>
  <div id="vsp5_root"></div>

  <!-- DASH ONLY: stop jump/double-render -->
  <script src="/static/js/vsp_p0_fetch_shim_v1.js?v={v}"></script>
  <script src="/static/js/vsp_dash_only_v1.js?v={v}"></script>
</body>
</html>"""

    def _vsp5_dash_only_mw(app):
        def _wrap(environ, start_response):
            path = environ.get("PATH_INFO","") or ""
            if path == "/vsp5":
                return _vsp_text(start_response, "200 OK", _vsp5_dash_only_html(), "text/html; charset=utf-8")

            # Fallback API (safe) for dash-only and other pages
            if path == "/api/vsp/runs":
                runs = _vsp_scan_runs(limit=200)
                return _vsp_json(start_response, "200 OK", {"ok": True, "runs": runs, "latest_rid": (runs[0]["rid"] if runs else None)})

            if path == "/api/vsp/rid_latest_gate_root":
                runs = _vsp_scan_runs(limit=1)
                if not runs:
                    return _vsp_json(start_response, "200 OK", {"ok": False, "err": "no runs found"})
                rid = runs[0]["rid"]
                return _vsp_json(start_response, "200 OK", {"ok": True, "rid": rid, "gate_root": f"gate_root_{rid}"})

            return app(environ, start_response)
        return _wrap
    # ===================== /VSP_P0_VSP5_DASH_ONLY_CLEAN_MW_V1 =====================

# [AUTO] wrap main WSGI app for /vsp5 dash-only
try:
    application = _vsp5_dash_only_mw(application)
except Exception:
    pass





# ===================== VSP_P0_VSP5_ISOLATE_DASH_ONLY_V1 =====================
def _vsp_p0_dashonly_isolate_v1(_app):
    if getattr(_app, "_vsp_p0_dashonly_isolate_v1", False):
        return _app
    from urllib.parse import parse_qs
    from pathlib import Path
    import os, json, time

    def _resp(start_response, status, ctype, body_bytes, extra_headers=None):
        hs = [
            ("Content-Type", ctype),
            ("Cache-Control", "no-store"),
            ("Content-Length", str(len(body_bytes))),
        ]
        if extra_headers:
            hs.extend(list(extra_headers))
        start_response(status, hs)
        return [body_bytes]

    def _json(start_response, obj, status="200 OK"):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        return _resp(start_response, status, "application/json; charset=utf-8", body)

    def _guess_roots():
        env = os.environ.get("VSP_RUNS_ROOT","").strip()
        roots = [r for r in env.split(":") if r] if env else []
        # safe fallbacks commonly used in your repo
        roots += [
            "/home/test/Data/SECURITY-10-10-v4/out_ci",
            "/home/test/Data/SECURITY_BUNDLE/out",
            "/home/test/Data/SECURITY_BUNDLE/out_ci",
        ]
        # unique + exists
        out = []
        for r in roots:
            p = Path(r)
            if p.exists() and str(p) not in out:
                out.append(str(p))
        return out

    def _list_runs(limit=30, offset=0):
        roots = _guess_roots()
        cands = []
        for r in roots:
            rp = Path(r)
            try:
                for d in rp.iterdir():
                    if not d.is_dir():
                        continue
                    name = d.name
                    if not (name.startswith("RUN_") or name.startswith("VSP_") or "RUN" in name):
                        continue
                    f1 = d/"run_gate_summary.json"
                    f2 = d/"run_gate.json"
                    if f1.is_file():
                        mt = f1.stat().st_mtime
                    elif f2.is_file():
                        mt = f2.stat().st_mtime
                    else:
                        continue
                    cands.append((mt, name))
            except Exception:
                continue
        cands.sort(key=lambda x: x[0], reverse=True)
        total = len(cands)
        sl = cands[offset:offset+limit]
        runs = [{"rid": rid, "mtime": int(mt)} for (mt, rid) in sl]
        return total, runs, roots

    def _latest_rid():
        total, runs, roots = _list_runs(limit=1, offset=0)
        if runs:
            rid = runs[0]["rid"]
            return rid, f"gate_root_{rid}", roots
        return None, None, roots

    def _html_vsp5():
        v = str(int(time.time()))
        html = f"""<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/><meta http-equiv="Expires" content="0"/>
<title>VSP5</title>
<link rel="stylesheet" href="/static/css/vsp_dash_only_v1.css?v={v}"/>
</head><body>
<div class="topnav">
  <a href="/vsp5">Dashboard</a>
  <a href="/runs">Runs &amp; Reports</a>
  <a href="/data_source">Data Source</a>
  <a href="/settings">Settings</a>
  <a href="/rule_overrides">Rule Overrides</a>
</div>

<div class="wrap">
  <div class="row">
    <div class="card pill">RID: <b id="rid_txt">—</b></div>
    <div class="card pill">Overall: <b id="overall_badge">—</b></div>
    <button class="btn" id="btn_refresh">Refresh</button>
    <button class="btn" id="btn_pin">Pin RID</button>
    <button class="btn" id="btn_unpin">Unpin</button>
  </div>

  <div style="height:10px"></div>
  <div class="row">
    <div class="card kpi"><div class="v" id="k_total">—</div><div class="l">TOTAL</div></div>
    <div class="card kpi"><div class="v" id="k_crit">—</div><div class="l">CRITICAL</div></div>
    <div class="card kpi"><div class="v" id="k_high">—</div><div class="l">HIGH</div></div>
    <div class="card kpi"><div class="v" id="k_med">—</div><div class="l">MEDIUM</div></div>
    <div class="card kpi"><div class="v" id="k_low">—</div><div class="l">LOW</div></div>
    <div class="card kpi"><div class="v" id="k_info">—</div><div class="l">INFO</div></div>
    <div class="card kpi"><div class="v" id="k_trace">—</div><div class="l">TRACE</div></div>
  </div>

  <div style="height:10px"></div>
  <div class="card">
    <div style="display:flex;justify-content:space-between;gap:10px;align-items:center">
      <div>
        <div style="font-weight:700">Tool lane (8 tools)</div>
        <div class="small">Derived from run_gate_summary.json</div>
      </div>
      <button class="btn" id="btn_load_findings">Load top findings (25)</button>
    </div>
    <div style="height:10px"></div>
    <div class="grid" id="tools_box"></div>
  </div>

  <div style="height:10px"></div>
  <div class="card">
    <div style="font-weight:700">Notes</div>
    <div style="height:8px"></div>
    <pre id="note_box">Loading...</pre>
  </div>

  <div style="height:10px"></div>
  <div class="card">
    <div style="font-weight:700">Top findings (sample)</div>
    <div class="small">Only loads when you click the button (avoid heavy fetch by default)</div>
    <div style="height:8px"></div>
    <table>
      <thead><tr><th>Severity</th><th>Tool</th><th>Title</th><th>Location</th></tr></thead>
      <tbody id="findings_tbl"><tr><td colspan="4">Not loaded</td></tr></tbody>
    </table>
  </div>
</div>

<script src="/static/js/vsp_p0_fetch_shim_v1.js?v={v}"></script>
<script src="/static/js/vsp_dash_only_v1.js?v={v}"></script>
</body></html>"""
        return html.encode("utf-8")

    def app(environ, start_response):
        path = environ.get("PATH_INFO","") or ""
        if path == "/vsp5":
            body = _html_vsp5()
            return _resp(start_response, "200 OK", "text/html; charset=utf-8", body, extra_headers=[
                ("Cache-Control","no-cache, no-store, must-revalidate"),
                ("Pragma","no-cache"),
                ("Expires","0"),
            ])

        if path == "/api/vsp/rid_latest_gate_root":
            rid, gate_root, roots = _latest_rid()
            if rid:
                return _json(start_response, {"ok": True, "rid": rid, "gate_root": gate_root, "roots": roots, "ts": int(time.time())})
            return _json(start_response, {"ok": False, "err": "no runs found", "roots": roots, "ts": int(time.time())}, status="404 Not Found")

        if path == "/api/vsp/runs":
            qs = parse_qs(environ.get("QUERY_STRING","") or "")
            try: limit = int((qs.get("limit") or ["30"])[0])
            except Exception: limit = 30
            try: offset = int((qs.get("offset") or ["0"])[0])
            except Exception: offset = 0
            limit = max(1, min(limit, 200))
            offset = max(0, offset)
            total, runs, roots = _list_runs(limit=limit, offset=offset)
            return _json(start_response, {"ok": True, "total": total, "limit": limit, "offset": offset, "runs": runs, "roots": roots, "ts": int(time.time())})

        return _app(environ, start_response)

    app._vsp_p0_dashonly_isolate_v1 = True
    return app

try:
    application = _vsp_p0_dashonly_isolate_v1(application)
except Exception:
    pass
# ===================== /VSP_P0_VSP5_ISOLATE_DASH_ONLY_V1 =====================


# ===================== VSP_P1_CSP_RO_HARDHOOK_EOF_V3 =====================
# Force CSP-Report-Only for HTML tabs by wrapping start_response at EOF (wins against rebind/filters).
try:
    _CSP_RO_V3 = (
      "default-src 'self'; img-src 'self' data:; "
      "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; "
      "connect-src 'self'; font-src 'self' data:; "
      "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    )

    def _csp_ro_wrap(inner):
        def _wsgi(environ, start_response):
            path = environ.get("PATH_INFO","") or ""
            def _sr(status, headers, exc_info=None):
                h = list(headers or [])
                keys = {str(k).lower() for (k, _v) in h if k}
                if path in ("/runs","/data_source","/settings","/vsp5"):
                    if "content-security-policy-report-only" not in keys:
                        h.append(("Content-Security-Policy-Report-Only", _CSP_RO_V3))
                return start_response(status, h, exc_info)
            return inner(environ, _sr)
        return _wsgi

    if "application" in globals() and callable(globals().get("application")):
        application = _csp_ro_wrap(application)
    if "app" in globals() and callable(globals().get("app")):
        app = _csp_ro_wrap(app)

    print("[VSP_P1_CSP_RO_HARDHOOK_EOF_V3] installed")
except Exception as _e:
    print("[VSP_P1_CSP_RO_HARDHOOK_EOF_V3] ERROR:", _e)
# ===================== /VSP_P1_CSP_RO_HARDHOOK_EOF_V3 =====================


# ===================== VSP_P1_AUDIT_PACK_MANIFEST_API_V1 =====================
# API: /api/vsp/audit_pack_manifest?rid=<RID>&lite=1(optional)
# Build manifest via the SAME internal calls as audit_pack_download (no tgz).
try:
    import json, time, traceback
    from urllib.parse import parse_qs, quote_plus

    def _wrap_audit_manifest(inner):
        def _wsgi(environ, start_response):
            if (environ.get("PATH_INFO","") or "") != "/api/vsp/audit_pack_manifest":
                return inner(environ, start_response)
            try:
                qs = parse_qs(environ.get("QUERY_STRING","") or "")
                rid = (qs.get("rid") or [""])[0].strip()
                lite = (qs.get("lite") or [""])[0].strip() in ("1","true","yes","on")
                if not rid:
                    b = json.dumps({"ok":False,"err":"missing rid"}, ensure_ascii=False).encode("utf-8")
                    start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                    return [b]

                # reuse internal caller defined in audit pack V2 block if exists
                caller = globals().get("_call_internal")
                if not callable(caller):
                    b = json.dumps({"ok":False,"err":"internal caller not available"}, ensure_ascii=False).encode("utf-8")
                    start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                    return [b]

                items = [
                    "run_gate_summary.json",
                    "run_gate.json",
                    "SUMMARY.txt",
                    "run_manifest.json",
                    "run_evidence_index.json",
                    "reports/findings_unified.csv",
                    "reports/findings_unified.sarif",
                    "reports/findings_unified.html",
                    "reports/findings_unified.pdf",
                ]
                if not lite:
                    items.insert(0, "findings_unified.json")

                included=[]; missing=[]; errors=[]
                for path in items:
                    q = f"rid={quote_plus(rid)}&path={quote_plus(path)}"
                    r = caller(inner, "/api/vsp/run_file_allow", qs=q, method="GET", max_read=5_000_000)
                    if r.get("code") != 200 or r.get("err"):
                        errors.append({"path": path, "code": r.get("code"), "err": r.get("err")})
                        continue
                    body = r.get("body") or b""
                    if not body:
                        missing.append({"path": path, "reason": "empty"})
                        continue
                    # detect run_file_allow error json
                    ct = (r.get("hdr") or {}).get("content-type","").lower()
                    if "application/json" in ct:
                        try:
                            j = json.loads(body.decode("utf-8","replace"))
                            if isinstance(j, dict) and j.get("ok") is False:
                                missing.append({"path": path, "reason": j.get("err") or "not allowed"})
                                continue
                        except Exception:
                            pass
                    included.append({"path": path, "bytes": len(body)})

                out = {
                    "ok": True, "rid": rid, "lite": lite,
                    "included_count": len(included),
                    "missing_count": len(missing),
                    "errors_count": len(errors),
                    "included": included,
                    "missing": missing,
                    "errors": errors,
                    "ts": int(time.time()),
                }
                b = json.dumps(out, ensure_ascii=False).encode("utf-8")
                start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                return [b]
            except Exception as e:
                b = json.dumps({"ok":False,"err":str(e),"tb":traceback.format_exc(limit=6)}, ensure_ascii=False).encode("utf-8")
                start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                return [b]
        return _wsgi

    if "application" in globals() and callable(globals().get("application")):
        application = _wrap_audit_manifest(application)
    if "app" in globals() and callable(globals().get("app")):
        app = _wrap_audit_manifest(app)

    print("[VSP_P1_AUDIT_PACK_MANIFEST_API_V1] enabled")
except Exception as _e:
    print("[VSP_P1_AUDIT_PACK_MANIFEST_API_V1] ERROR:", _e)
# ===================== /VSP_P1_AUDIT_PACK_MANIFEST_API_V1 =====================


# ===================== VSP_P1_AUDIT_PACK_MANIFEST_API_V2_FS_APPEND_V1 =====================
# FS-check manifest (no run_file_allow internal calls). Outer wrapper intercepts /api/vsp/audit_pack_manifest.
try:
    import json, time, traceback
    from pathlib import Path
    from urllib.parse import parse_qs

    _VSP_MF_ITEMS_BASE = [
        "run_gate_summary.json",
        "run_gate.json",
        "SUMMARY.txt",
        "run_manifest.json",
        "run_evidence_index.json",
        "reports/findings_unified.csv",
        "reports/findings_unified.sarif",
        "reports/findings_unified.html",
        "reports/findings_unified.pdf",
    ]
    _VSP_MF_FULL_ONLY = ["findings_unified.json"]

    _VSP_MF_ROOTS = [
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
    ]

    def _vsp_mf_find_run_dir(rid: str):
        for root in _VSP_MF_ROOTS:
            try:
                d = Path(root) / rid
                if d.is_dir():
                    return d
            except Exception:
                pass
        return None

    def _vsp_mf_safe_join(run_dir: Path, rel: str) -> Path:
        rel = (rel or "").lstrip("/").replace("\\", "/")
        parts = [x for x in rel.split("/") if x not in ("", ".", "..")]
        return run_dir.joinpath(*parts)

    def _vsp_wrap_manifest_v2_fs(inner):
        def _wsgi(environ, start_response):
            if (environ.get("PATH_INFO","") or "") != "/api/vsp/audit_pack_manifest":
                return inner(environ, start_response)
            try:
                qs = parse_qs(environ.get("QUERY_STRING","") or "")
                rid = (qs.get("rid") or [""])[0].strip()
                lite = (qs.get("lite") or [""])[0].strip() in ("1","true","yes","on")
                if not rid:
                    b = json.dumps({"ok": False, "err": "missing rid"}, ensure_ascii=False).encode("utf-8")
                    start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                    return [b]

                run_dir = _vsp_mf_find_run_dir(rid)
                if not run_dir:
                    b = json.dumps({"ok": False, "err": "rid not found", "rid": rid}, ensure_ascii=False).encode("utf-8")
                    start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                    return [b]

                items = list(_VSP_MF_ITEMS_BASE)
                if not lite:
                    items = _VSP_MF_FULL_ONLY + items

                included = []
                missing = []
                for rel in items:
                    fp = _vsp_mf_safe_join(run_dir, rel)
                    if fp.is_file():
                        try:
                            included.append({"path": rel, "bytes": fp.stat().st_size})
                        except Exception:
                            included.append({"path": rel, "bytes": None})
                    else:
                        missing.append({"path": rel, "reason": "not found"})

                out = {
                    "ok": True,
                    "rid": rid,
                    "lite": lite,
                    "run_dir": str(run_dir),
                    "included_count": len(included),
                    "missing_count": len(missing),
                    "errors_count": 0,
                    "included": included,
                    "missing": missing,
                    "errors": [],
                    "ts": int(time.time()),
                }
                b = json.dumps(out, ensure_ascii=False).encode("utf-8")
                start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                return [b]
            except Exception as e:
                b = json.dumps({"ok": False, "err": str(e), "tb": traceback.format_exc(limit=6)}, ensure_ascii=False).encode("utf-8")
                start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                return [b]
        return _wsgi

    if "application" in globals() and callable(globals().get("application")):
        application = _vsp_wrap_manifest_v2_fs(application)
    if "app" in globals() and callable(globals().get("app")):
        app = _vsp_wrap_manifest_v2_fs(app)

    print("[VSP] manifest v2 fs wrapper enabled")
except Exception as _e:
    print("[VSP] manifest v2 fs wrapper ERROR:", _e)
# ===================== /VSP_P1_AUDIT_PACK_MANIFEST_API_V2_FS_APPEND_V1 =====================


# ===================== VSP_P1_AUDIT_PACK_MANIFEST_API_V3_FSSEARCH_V1 =====================
# API: /api/vsp/audit_pack_manifest?rid=<RID>&lite=1(optional)
# V3: find RID dir by bounded FS-search (no dependency on run_file_allow/internal proxy).
#      Never breaks import: whole block is guarded.
try:
    import json, time, traceback, os
    from pathlib import Path
    from urllib.parse import parse_qs

    _VSP_MF_ITEMS_BASE_V3 = [
        "run_gate_summary.json",
        "run_gate.json",
        "SUMMARY.txt",
        "run_manifest.json",
        "run_evidence_index.json",
        "reports/findings_unified.csv",
        "reports/findings_unified.sarif",
        "reports/findings_unified.html",
        "reports/findings_unified.pdf",
    ]
    _VSP_MF_FULL_ONLY_V3 = ["findings_unified.json"]

    # Candidate roots (fast checks first). You can add more safely.
    _VSP_MF_ROOTS_V3 = [
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1",
        "/home/test/Data",  # last resort (bounded walk)
    ]

    def _vsp_safe_join_v3(run_dir: Path, rel: str) -> Path:
        rel = (rel or "").lstrip("/").replace("\\", "/")
        parts = [x for x in rel.split("/") if x not in ("", ".", "..")]
        return run_dir.joinpath(*parts)

    def _vsp_find_rid_dir_v3(rid: str) -> Path | None:
        # 1) direct hit root/rid
        for root in _VSP_MF_ROOTS_V3:
            try:
                d = Path(root) / rid
                if d.is_dir():
                    return d
            except Exception:
                pass

        # 2) bounded search: depth<=3, dirs<=3500
        #    Stops on first match of a directory named exactly RID.
        max_depth = 3
        max_dirs = 3500
        scanned = 0

        for root in _VSP_MF_ROOTS_V3:
            rr = Path(root)
            if not rr.is_dir():
                continue
            root_depth = len(rr.parts)
            try:
                for cur, dirnames, _filenames in os.walk(str(rr), topdown=True):
                    scanned += 1
                    if scanned > max_dirs:
                        return None
                    curp = Path(cur)
                    depth = len(curp.parts) - root_depth
                    if depth > max_depth:
                        dirnames[:] = []
                        continue
                    # prune common heavy dirs
                    dirnames[:] = [d for d in dirnames if d not in (".git","node_modules","__pycache__","venv",".venv")]
                    # check children quickly
                    if rid in dirnames:
                        cand = curp / rid
                        if cand.is_dir():
                            return cand
            except Exception:
                continue
        return None

    def _vsp_manifest_v3(inner):
        def _wsgi(environ, start_response):
            if (environ.get("PATH_INFO","") or "") != "/api/vsp/audit_pack_manifest":
                return inner(environ, start_response)
            try:
                qs = parse_qs(environ.get("QUERY_STRING","") or "")
                rid = (qs.get("rid") or [""])[0].strip()
                lite = (qs.get("lite") or [""])[0].strip() in ("1","true","yes","on")

                if not rid:
                    b = json.dumps({"ok": False, "err": "missing rid"}, ensure_ascii=False).encode("utf-8")
                    start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                    return [b]

                run_dir = _vsp_find_rid_dir_v3(rid)
                if not run_dir:
                    b = json.dumps({"ok": False, "err": "rid not found", "rid": rid}, ensure_ascii=False).encode("utf-8")
                    start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                    return [b]

                items = list(_VSP_MF_ITEMS_BASE_V3)
                if not lite:
                    items = _VSP_MF_FULL_ONLY_V3 + items

                included=[]; missing=[]
                for rel in items:
                    fp = _vsp_safe_join_v3(run_dir, rel)
                    if fp.is_file():
                        try:
                            included.append({"path": rel, "bytes": fp.stat().st_size})
                        except Exception:
                            included.append({"path": rel, "bytes": None})
                    else:
                        missing.append({"path": rel, "reason": "not found"})

                out = {
                    "ok": True,
                    "rid": rid,
                    "lite": lite,
                    "run_dir": str(run_dir),
                    "included_count": len(included),
                    "missing_count": len(missing),
                    "errors_count": 0,
                    "included": included,
                    "missing": missing,
                    "errors": [],
                    "ts": int(time.time()),
                }
                b = json.dumps(out, ensure_ascii=False).encode("utf-8")
                start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                return [b]
            except Exception as e:
                b = json.dumps({"ok": False, "err": str(e), "tb": traceback.format_exc(limit=6)}, ensure_ascii=False).encode("utf-8")
                start_response("200 OK",[("Content-Type","application/json; charset=utf-8"),("Cache-Control","no-store"),("Content-Length",str(len(b)))])
                return [b]
        return _wsgi

    if "application" in globals() and callable(globals().get("application")):
        application = _vsp_manifest_v3(application)
    if "app" in globals() and callable(globals().get("app")):
        app = _vsp_manifest_v3(app)

    print("[VSP] manifest V3 FSSEARCH enabled")
except Exception as _e:
    print("[VSP] manifest V3 FSSEARCH ERROR:", _e)
# ===================== /VSP_P1_AUDIT_PACK_MANIFEST_API_V3_FSSEARCH_V1 =====================


# ===================== VSP_P0_FINDINGS_PAGE_API_V2_FIXRID_V1 =====================
# GET /api/vsp/findings_page?rid=...&offset=0&limit=200&severity=&tool=&q=&debug=1
try:
    import json, time
    from pathlib import Path as _Path

    _VSP_FP_CACHE = {"ts": 0.0, "rid": None, "run_dir": None, "items": None}

    def _vsp_fp_roots():
        # keep aligned with your ecosystem (SECURITY-10-10-v4 + SECURITY_BUNDLE + UI out_ci)
        roots = [
            _Path("/home/test/Data/SECURITY-10-10-v4/out_ci"),
            _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
            _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        ]
        # allow override via env (optional)
        try:
            import os as _os
            extra = (_os.environ.get("VSP_OUT_CI_ROOTS") or "").strip()
            if extra:
                for x in extra.split(":"):
                    x=x.strip()
                    if x:
                        roots.append(_Path(x))
        except Exception:
            pass
        # de-dup while preserving order
        out=[]
        seen=set()
        for r in roots:
            rs=str(r)
            if rs in seen: 
                continue
            seen.add(rs)
            out.append(r)
        return out

    def _vsp_fp_find_run_dir(rid: str):
        roots = _vsp_fp_roots()
        # fast path root/rid
        for root in roots:
            try:
                if root.is_dir():
                    cand = root / rid
                    if cand.is_dir():
                        return str(cand)
            except Exception:
                pass
        # bounded scan newest dirs
        for root in roots:
            try:
                if not root.is_dir():
                    continue
                ds = [d for d in root.iterdir() if d.is_dir()]
                ds.sort(key=lambda x: x.stat().st_mtime, reverse=True)
                for d in ds[:260]:
                    if d.name == rid:
                        return str(d)
            except Exception:
                pass
        return None

    def _vsp_fp_load_findings(rid: str):
        now = time.time()
        if _VSP_FP_CACHE.get("rid")==rid and (now - float(_VSP_FP_CACHE.get("ts") or 0)) < 8.0:
            return _VSP_FP_CACHE.get("run_dir"), (_VSP_FP_CACHE.get("items") or [])

        rd = _vsp_fp_find_run_dir(rid)
        if not rd:
            return None, None

        fu = _Path(rd) / "findings_unified.json"
        if not fu.is_file():
            _VSP_FP_CACHE.update({"ts": now, "rid": rid, "run_dir": rd, "items": []})
            return rd, []

        try:
            j = json.loads(fu.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            _VSP_FP_CACHE.update({"ts": now, "rid": rid, "run_dir": rd, "items": []})
            return rd, []

        items = []
        if isinstance(j, dict) and isinstance(j.get("findings"), list):
            items = j["findings"]
        elif isinstance(j, list):
            items = j
        else:
            items = []

        _VSP_FP_CACHE.update({"ts": now, "rid": rid, "run_dir": rd, "items": items})
        return rd, items

    @app.get("/api/vsp/findings_page")
    def vsp_findings_page():
        rid = (request.args.get("rid") or "").strip()
        if not rid:
            return jsonify({"ok": False, "err": "missing rid"}), 400

        try:
            offset = int(request.args.get("offset") or "0")
            limit  = int(request.args.get("limit") or "200")
        except Exception:
            offset, limit = 0, 200
        offset = max(0, offset)
        limit = min(max(1, limit), 500)

        severity = (request.args.get("severity") or "").strip().upper()
        tool = (request.args.get("tool") or "").strip()
        q = (request.args.get("q") or "").strip().lower()
        debug = (request.args.get("debug") or "").strip() in ("1","true","yes","on")

        run_dir, items = _vsp_fp_load_findings(rid)
        if items is None:
            out = {"ok": False, "err": "rid not found", "rid": rid}
            if debug:
                out.update({
                    "run_dir": run_dir,
                    "roots": [str(x) for x in _vsp_fp_roots()],
                })
            return jsonify(out), 200

        # filter
        def ok_item(x):
            if not isinstance(x, dict):
                return False
            if severity:
                s = (x.get("severity") or x.get("sev") or "").upper()
                if s != severity:
                    return False
            if tool:
                t = (x.get("tool") or x.get("scanner") or x.get("source") or "")
                if t != tool:
                    return False
            if q:
                blob = (" ".join([
                    str(x.get("rule_id") or ""),
                    str(x.get("id") or ""),
                    str(x.get("title") or ""),
                    str(x.get("message") or ""),
                    str(x.get("file") or x.get("path") or ""),
                ])).lower()
                if q not in blob:
                    return False
            return True

        filtered = [x for x in (items or []) if ok_item(x)]
        total = len(filtered)
        page = filtered[offset: offset + limit]

        out=[]
        for x in page:
            out.append({
                "severity": x.get("severity") or x.get("sev"),
                "tool": x.get("tool") or x.get("scanner") or x.get("source"),
                "rule_id": x.get("rule_id") or x.get("id"),
                "title": x.get("title") or x.get("check_name") or x.get("message"),
                "file": x.get("file") or x.get("path"),
                "line": x.get("line") or x.get("start_line") or x.get("location",{}).get("line"),
            })

        resp = {"ok": True, "rid": rid, "offset": offset, "limit": limit, "total": total, "page": out}
        if debug:
            resp["run_dir"] = run_dir
            fu = _Path(run_dir)/"findings_unified.json"
            resp["findings_path"] = str(fu)
            resp["findings_exists"] = fu.is_file()
            try:
                resp["findings_bytes"] = fu.stat().st_size if fu.is_file() else 0
            except Exception:
                resp["findings_bytes"] = None
        return jsonify(resp), 200

except Exception:
    pass
# ===================== /VSP_P0_FINDINGS_PAGE_API_V2_FIXRID_V1 =====================

# ===================== VSP_P0_FINDINGS_PAGE_V3_ALLOW_FORCEBIND_V1 =====================
# Purpose:
#  - Ensure /api/vsp/findings_page is NOT blocked by outer allowlist guard ("not allowed")
#  - Provide commercial-grade findings pagination API (bounded, cached, safe defaults)
try:
    import os, json, time
    from pathlib import Path
    try:
        from flask import request, jsonify
    except Exception:
        request = None
        jsonify = None

    _VSP_FINDINGS_PAGE_PATH = "/api/vsp/findings_page"

    def _vsp__patch_allowlists_for_findings_page() -> bool:
        """
        Best-effort: find global allowlist containers that already allow /api/vsp/runs + /api/vsp/release_latest
        and append/add /api/vsp/findings_page.
        This fixes: {"ok":false,"err":"not allowed","path":"/api/vsp/findings_page"}.
        """
        added = False
        try:
            g = globals()
            needle_a = "/api/vsp/runs"
            needle_b = "/api/vsp/release_latest"
            for k, v in list(g.items()):
                if isinstance(v, (set, list, tuple)) and (needle_a in v) and (needle_b in v):
                    if _VSP_FINDINGS_PAGE_PATH in v:
                        continue
                    try:
                        # set
                        v.add(_VSP_FINDINGS_PAGE_PATH)  # type: ignore[attr-defined]
                        added = True
                    except Exception:
                        try:
                            # list
                            v = list(v) + [_VSP_FINDINGS_PAGE_PATH]
                            g[k] = v
                            added = True
                        except Exception:
                            pass
            # also patch dict-of-bools allow tables if any
            for k, v in list(g.items()):
                if isinstance(v, dict) and (needle_a in v) and (needle_b in v):
                    if _VSP_FINDINGS_PAGE_PATH not in v:
                        try:
                            v[_VSP_FINDINGS_PAGE_PATH] = True
                            added = True
                        except Exception:
                            pass
        except Exception:
            pass
        return added

    _VSP_FP_CACHE = {
        "rid": None,
        "run_dir": None,
        "fp": None,
        "mtime": 0.0,
        "total": 0,
        "meta": None,
        "findings": None,
        "ts": 0.0,
    }

    def _vsp__pick_flask_app():
        g = globals()
        # common names first
        for name in ("app", "flask_app", "vsp_app"):
            obj = g.get(name)
            if obj is not None and hasattr(obj, "add_url_rule") and hasattr(obj, "url_map"):
                return obj
        # scan any global object that looks like Flask
        for obj in g.values():
            if obj is not None and hasattr(obj, "add_url_rule") and hasattr(obj, "url_map") and hasattr(obj, "view_functions"):
                return obj
        return None

    def _vsp__bounded_find_run_dir(rid: str):
        # accept absolute dir
        if rid and rid.startswith("/") and Path(rid).is_dir():
            return rid
        rid = (rid or "").strip()
        if not rid:
            return None

        # roots: keep aligned with your ecosystem (SECURITY_BUNDLE + legacy out_ci)
        roots = []
        roots += [os.environ.get("VSP_OUT_CI", "").strip()] if os.environ.get("VSP_OUT_CI") else []
        roots += [
            "/home/test/Data/SECURITY-10-10-v4/out_ci",
            "/home/test/Data/SECURITY_BUNDLE/out_ci",
            "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
            "/home/test/Data/SECURITY_BUNDLE/out",
        ]
        # de-dup keep order
        seen = set()
        roots2 = []
        for r in roots:
            r = (r or "").strip()
            if not r or r in seen:
                continue
            seen.add(r)
            roots2.append(r)
        roots = roots2

        # fast direct hit
        for r in roots:
            cand = Path(r) / rid
            if cand.is_dir():
                return str(cand)

        # bounded scan (top N recent dirs in each root)
        SCAN_CAP = int(os.environ.get("VSP_FP_SCAN_CAP", "2000"))
        try_prefix = rid.split("_")[0] if "_" in rid else rid  # e.g. VSP or RUN
        for r in roots:
            pr = Path(r)
            if not pr.is_dir():
                continue
            try:
                dirs = [d for d in pr.iterdir() if d.is_dir()]
            except Exception:
                continue
            # prioritize name match first
            dirs_name = [d for d in dirs if (d.name == rid or d.name.startswith(rid))]
            if dirs_name:
                # pick newest
                dirs_name.sort(key=lambda d: d.stat().st_mtime, reverse=True)
                return str(dirs_name[0])

            # then bounded recent scan
            try:
                dirs.sort(key=lambda d: d.stat().st_mtime, reverse=True)
            except Exception:
                pass
            checked = 0
            for d in dirs:
                if checked >= SCAN_CAP:
                    break
                checked += 1
                n = d.name
                # cheap filters
                if try_prefix and (try_prefix not in n):
                    continue
                if (rid in n) or n.endswith(rid):
                    return str(d)
        return None

    def _vsp__load_findings(rid: str, run_dir: str):
        # try common locations
        rd = Path(run_dir)
        candidates = [
            rd / "findings_unified.json",
            rd / "reports" / "findings_unified.json",
            rd / "reports" / "findings_unified.sarif",  # fallback (not ideal)
        ]
        fp = None
        for c in candidates:
            if c.is_file():
                fp = c
                break
        if fp is None:
            return None, None, None, "findings file missing"

        # file size guard
        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        max_mb = int(os.environ.get("VSP_FP_MAX_MB", "60"))
        if sz >= 0 and sz > max_mb * 1024 * 1024:
            return str(fp), None, None, f"file too large ({sz} bytes) > {max_mb}MB"

        raw = fp.read_text(encoding="utf-8", errors="replace")
        j = json.loads(raw)
        # expected schema: {"meta":..., "findings":[...]}
        meta = j.get("meta") if isinstance(j, dict) else None
        findings = None
        if isinstance(j, dict):
            if isinstance(j.get("findings"), list):
                findings = j["findings"]
            elif isinstance(j.get("items"), list):
                findings = j["items"]
        if findings is None:
            return str(fp), meta, None, "unexpected findings schema"
        return str(fp), meta, findings, None

    def _vsp_findings_page_v3():
        t0 = time.time()
        if request is None or jsonify is None:
            return (json.dumps({"ok": False, "err": "flask not available"}), 500, {"Content-Type": "application/json"})

        rid = (request.args.get("rid") or "").strip()
        # pagination
        try:
            offset = int(request.args.get("offset") or "0")
        except Exception:
            offset = 0
        try:
            limit = int(request.args.get("limit") or "200")
        except Exception:
            limit = 200
        if offset < 0: offset = 0
        if limit < 1: limit = 1
        limit_cap = int(os.environ.get("VSP_FP_LIMIT_CAP", "400"))
        if limit > limit_cap: limit = limit_cap

        debug = (request.args.get("debug") or "").strip() in ("1","true","yes","on")

        if not rid:
            return jsonify({"ok": False, "err": "missing rid"}), 400

        run_dir = _vsp__bounded_find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "rid not found", "rid": rid}), 200

        # cache by (rid, mtime)
        try:
            # choose canonical findings path first to get mtime
            rd = Path(run_dir)
            fp0 = rd / "findings_unified.json"
            if not fp0.is_file():
                fp0 = rd / "reports" / "findings_unified.json"
            mtime = fp0.stat().st_mtime if fp0.is_file() else 0.0
        except Exception:
            mtime = 0.0

        if _VSP_FP_CACHE.get("rid") == rid and _VSP_FP_CACHE.get("run_dir") == run_dir and _VSP_FP_CACHE.get("mtime") == mtime and _VSP_FP_CACHE.get("findings") is not None:
            findings = _VSP_FP_CACHE["findings"]
            meta = _VSP_FP_CACHE["meta"]
            fp = _VSP_FP_CACHE.get("fp")
            total = int(_VSP_FP_CACHE.get("total") or (len(findings) if findings else 0))
        else:
            fp, meta, findings, err = _vsp__load_findings(rid, run_dir)
            if err:
                out = {"ok": False, "err": err, "rid": rid, "run_dir": run_dir}
                if debug:
                    out["fp"] = fp
                return jsonify(out), 200
            total = len(findings)
            _VSP_FP_CACHE.update({
                "rid": rid, "run_dir": run_dir, "fp": fp, "mtime": mtime,
                "total": total, "meta": meta, "findings": findings, "ts": time.time()
            })

        page = findings[offset: offset + limit] if findings else []
        out = {
            "ok": True,
            "rid": rid,
            "run_dir": run_dir,
            "offset": offset,
            "limit": limit,
            "total": total,
            "page_len": len(page),
            "page": page,
        }
        # small meta (optional)
        if isinstance(meta, dict):
            # keep it lean: only counts if present
            counts = meta.get("counts_by_severity") or meta.get("counts") or None
            if counts is not None:
                out["counts"] = counts

        out["ms"] = int((time.time() - t0) * 1000)
        if debug:
            out["fp_cache_hit"] = bool(_VSP_FP_CACHE.get("ts")) and (_VSP_FP_CACHE.get("rid") == rid)
        return jsonify(out), 200

    # 1) allowlist patch
    _added = _vsp__patch_allowlists_for_findings_page()
    try:
        if _added:
            print("[VSP_FP_V3] allowlist patched for /api/vsp/findings_page")
    except Exception:
        pass

    # 2) force-bind route into Flask app (override if already exists)
    _app = _vsp__pick_flask_app()
    if _app is not None and hasattr(_app, "url_map") and hasattr(_app, "view_functions"):
        existing_ep = None
        try:
            for r in _app.url_map.iter_rules():
                if getattr(r, "rule", None) == _VSP_FINDINGS_PAGE_PATH:
                    existing_ep = r.endpoint
                    break
        except Exception:
            existing_ep = None

        if existing_ep:
            # override handler
            _app.view_functions[existing_ep] = _vsp_findings_page_v3
            try:
                print(f"[VSP_FP_V3] override endpoint={existing_ep} path={_VSP_FINDINGS_PAGE_PATH}")
            except Exception:
                pass
        else:
            # new rule
            try:
                _app.add_url_rule(_VSP_FINDINGS_PAGE_PATH, endpoint="api_vsp_findings_page_v3", view_func=_vsp_findings_page_v3, methods=["GET"])
                print(f"[VSP_FP_V3] added path={_VSP_FINDINGS_PAGE_PATH}")
            except Exception as e:
                try:
                    print("[VSP_FP_V3] add_url_rule failed:", repr(e))
                except Exception:
                    pass

except Exception as _e:
    try:
        print("[VSP_P0_FINDINGS_PAGE_V3_ALLOW_FORCEBIND_V1] failed:", repr(_e))
    except Exception:
        pass
# ===================== /VSP_P0_FINDINGS_PAGE_V3_ALLOW_FORCEBIND_V1 =====================


# ===================== VSP_P0_ALLOWLIST_ADD_FINDINGS_PAGE_V1 (already had target string) =====================

# ===================== VSP_P0_GUARD_ALLOW_FINDINGS_PAGE_V1 =====================
# patched_if_lines=0
# allow bypass for /api/vsp/findings_page even under outer guard
# ===================== /VSP_P0_GUARD_ALLOW_FINDINGS_PAGE_V1 =====================

# ===================== VSP_P0_WSGI_BYPASS_FINDINGS_PAGE_V1 =====================
# Purpose: bypass outer "not allowed" guard for /api/vsp/findings_page by routing to Flask app directly.
try:
    _VSP_FP_PATH = "/api/vsp/findings_page"

    # keep original gateway (may include allowlist guard)
    try:
        _VSP_GW_APP = application
    except Exception:
        _VSP_GW_APP = None

    def _vsp_pick_flask_app():
        # 1) search globals
        try:
            g = globals()
            for name, obj in list(g.items()):
                # Flask instance usually has .route and .wsgi_app
                if obj is None: 
                    continue
                if hasattr(obj, "wsgi_app") and hasattr(obj, "route") and callable(obj):
                    return obj
        except Exception:
            pass

        # 2) import vsp_demo_app as fallback
        try:
            import vsp_demo_app as m
            for n in ("app", "flask_app", "application"):
                obj = getattr(m, n, None)
                if obj is None:
                    continue
                if hasattr(obj, "wsgi_app") and callable(obj):
                    return obj
        except Exception:
            pass

        return None

    _VSP_FLASK_APP = _vsp_pick_flask_app()

    def _vsp_sr_inject(start_response):
        # inject commercial headers if missing (best effort)
        def _sr(status, headers, exc_info=None):
            try:
                h = {k.lower(): v for k, v in (headers or [])}
                def add(k, v):
                    if k.lower() not in h:
                        headers.append((k, v))
                        h[k.lower()] = v
                add("Cache-Control", "no-store")
                add("X-Content-Type-Options", "nosniff")
                add("X-Frame-Options", "DENY")
                add("Referrer-Policy", "no-referrer")
            except Exception:
                pass
            return start_response(status, headers, exc_info) if exc_info is not None else start_response(status, headers)
        return _sr

    def application(environ, start_response):
        path = (environ or {}).get("PATH_INFO", "") or ""
        if path == _VSP_FP_PATH and _VSP_FLASK_APP is not None:
            # call Flask app directly (avoid gateway guard)
            sr = _vsp_sr_inject(start_response)
            try:
                return _VSP_FLASK_APP.wsgi_app(environ, sr)
            except Exception:
                return _VSP_FLASK_APP(environ, sr)

        if _VSP_GW_APP is not None:
            return _VSP_GW_APP(environ, start_response)

        # last resort
        sr = _vsp_sr_inject(start_response)
        if _VSP_FLASK_APP is not None:
            try:
                return _VSP_FLASK_APP.wsgi_app(environ, sr)
            except Exception:
                return _VSP_FLASK_APP(environ, sr)

        # hard fail
        body = b'{"ok":false,"err":"no app"}'
        sr("500 INTERNAL SERVER ERROR", [("Content-Type","application/json"), ("Content-Length", str(len(body)))])
        return [body]

    try:
        print("[VSP_FP_BYPASS] installed, flask=", bool(_VSP_FLASK_APP), "gw=", bool(_VSP_GW_APP))
    except Exception:
        pass

except Exception as _e:
    try:
        print("[VSP_FP_BYPASS] failed:", repr(_e))
    except Exception:
        pass
# ===================== /VSP_P0_WSGI_BYPASS_FINDINGS_PAGE_V1 =====================



# ===================== VSP_P0_RID_LATEST_ENDWRAP_V3 =====================
# Final WSGI intercept for /api/vsp/rid_latest_gate_root (must be at EOF to avoid later overrides)
try:
    import json as _json
    import os as _os
    import glob as _glob
    import time as _time

    if globals().get("__vsp_p0_rid_latest_endwrap_v3"):
        pass
    else:
        globals()["__vsp_p0_rid_latest_endwrap_v3"] = True

        _VSP_RID_ROOTS = [
            "/home/test/Data/SECURITY-10-10-v4/out_ci",
            "/home/test/Data/SECURITY_BUNDLE/out",
            "/home/test/Data/SECURITY_BUNDLE/out_ci",
        ]
        _VSP_SKIP = set(["kics","bandit","trivy","grype","semgrep","gitleaks","codeql","reports","out","out_ci","tmp","cache"])

        def _vsp_csv_has_2_lines(path: str) -> bool:
            try:
                if (not _os.path.isfile(path)) or _os.path.getsize(path) < 120:
                    return False
                n=0
                with open(path,"r",encoding="utf-8",errors="ignore") as f:
                    for _ in f:
                        n += 1
                        if n >= 2:
                            return True
                return False
            except Exception:
                return False

        def _vsp_sarif_has_results(path: str) -> bool:
            try:
                if (not _os.path.isfile(path)) or _os.path.getsize(path) < 200:
                    return False
                j=_json.load(open(path,"r",encoding="utf-8",errors="ignore"))
                for run in (j.get("runs") or []):
                    if (run.get("results") or []):
                        return True
                return False
            except Exception:
                return False

        def _vsp_looks_like_rid(name: str) -> bool:
            if not name or name.startswith("."):
                return False
            if name in _VSP_SKIP:
                return False
            return name.startswith(("VSP_CI_","RUN_","RUN-","VSP_"))

        def _vsp_is_run_dir(rid: str, run_dir: str) -> bool:
            if not _os.path.isdir(run_dir):
                return False
            if _vsp_looks_like_rid(rid):
                return True
            # accept weird names if they contain run artifacts
            if _os.path.isfile(_os.path.join(run_dir, "run_gate_summary.json")) or _os.path.isfile(_os.path.join(run_dir, "run_manifest.json")):
                return True
            return False

        def _vsp_has_details(run_dir: str) -> str:
            fu=_os.path.join(run_dir,"findings_unified.json")
            try:
                if _os.path.isfile(fu) and _os.path.getsize(fu) > 500:
                    return "findings_unified.json"
            except Exception:
                pass

            csvp=_os.path.join(run_dir,"reports","findings_unified.csv")
            if _vsp_csv_has_2_lines(csvp):
                return "reports/findings_unified.csv"

            sarifp=_os.path.join(run_dir,"reports","findings_unified.sarif")
            if _vsp_sarif_has_results(sarifp):
                return "reports/findings_unified.sarif"

            pats=[
                "semgrep/**/*.json","grype/**/*.json","trivy/**/*.json","kics/**/*.json",
                "bandit/**/*.json","gitleaks/**/*.json","codeql/**/*.sarif",
                "**/*semgrep*.json","**/*grype*.json","**/*trivy*.json",
                "**/*kics*.json","**/*bandit*.json","**/*gitleaks*.json","**/*codeql*.sarif",
            ]
            for pat in pats:
                for f in _glob.glob(_os.path.join(run_dir, pat), recursive=True):
                    try:
                        if _os.path.getsize(f) > 800:
                            rel=_os.path.relpath(f, run_dir).replace("\\","/")
                            if rel == "reports/findings_unified.sarif":
                                continue
                            return rel
                    except Exception:
                        continue
            return ""

        def _vsp_pick_latest_with_details(max_scan: int = 600):
            best=None  # (mtime,rid,root,why)
            for root in _VSP_RID_ROOTS:
                if not _os.path.isdir(root):
                    continue
                cands=[]
                for rid in _os.listdir(root):
                    run_dir=_os.path.join(root,rid)
                    if not _vsp_is_run_dir(rid, run_dir):
                        continue
                    try:
                        mtime=int(_os.path.getmtime(run_dir))
                    except Exception:
                        mtime=0
                    cands.append((mtime,rid,run_dir))
                cands.sort(reverse=True)
                for mtime,rid,run_dir in cands[:max_scan]:
                    why=_vsp_has_details(run_dir)
                    if why:
                        cand=(mtime,rid,root,why)
                        if best is None or cand[0] > best[0]:
                            best=cand
                        break
            return best

        def _vsp_pick_latest_existing():
            best=None
            for root in _VSP_RID_ROOTS:
                if not _os.path.isdir(root):
                    continue
                cands=[]
                for rid in _os.listdir(root):
                    run_dir=_os.path.join(root,rid)
                    if not _vsp_is_run_dir(rid, run_dir):
                        continue
                    try:
                        cands.append((int(_os.path.getmtime(run_dir)), rid, root))
                    except Exception:
                        cands.append((0, rid, root))
                cands.sort(reverse=True)
                if cands and (best is None or cands[0][0] > best[0]):
                    best=cands[0]
            return best

        def _vsp_payload():
            best=_vsp_pick_latest_with_details()
            if best:
                _, rid, _root, why = best
                return {
                    "ok": True,
                    "rid": rid,
                    "gate_root": "gate_root_" + rid,
                    "roots": _VSP_RID_ROOTS,
                    "reason": "latest_with_details",
                    "why": why,
                    "ts": int(_time.time()),
                }
            fb=_vsp_pick_latest_existing()
            if fb:
                _, rid, _root = fb
                return {
                    "ok": True,
                    "rid": rid,
                    "gate_root": "gate_root_" + rid,
                    "roots": _VSP_RID_ROOTS,
                    "reason": "latest_existing_fallback_no_details",
                    "why": "",
                    "ts": int(_time.time()),
                }
            return {
                "ok": False,
                "rid": "",
                "gate_root": "",
                "roots": _VSP_RID_ROOTS,
                "reason": "no_runs_found",
                "why": "",
                "ts": int(_time.time()),
            }

        def _vsp_json_resp(start_response, payload):
            body=_json.dumps(payload, ensure_ascii=False).encode("utf-8")
            hdrs=[
                ("Content-Type","application/json; charset=utf-8"),
                ("Cache-Control","no-store"),
                ("X-VSP-RIDPICK","ENDWRAP_V3"),
                ("Content-Length", str(len(body))),
            ]
            start_response("200 OK", hdrs)
            return [body]

        def _vsp_mw(_app):
            def _wsgi(environ, start_response):
                path = environ.get("PATH_INFO","") or ""
                if path in ("/api/vsp/rid_latest_gate_root", "/api/vsp/rid_latest_gate_root.json"):
                    return _vsp_json_resp(start_response, _vsp_payload())
                return _app(environ, start_response)
            return _wsgi

        # Wrap at EOF so nothing overrides it later
        if "application" in globals() and callable(globals().get("application")):
            application = _vsp_mw(application)
        if "app" in globals() and callable(globals().get("app")):
            app = _vsp_mw(app)

        print("[VSP_P0_RID_LATEST_ENDWRAP_V3] enabled")
except Exception as _e:
    print("[VSP_P0_RID_LATEST_ENDWRAP_V3] ERROR:", _e)
# ===================== /VSP_P0_RID_LATEST_ENDWRAP_V3 =====================


# ===================== VSP_P0_RID_LATEST_ENDWRAP_V4_STRICT =====================
# Outer-most intercept: accept only RID like VSP_CI_* or RUN_* (avoid out_ci/reports/tool dirs)
try:
    import json as _json
    import os as _os
    import glob as _glob
    import time as _time
    import re as _re

    if globals().get("__vsp_p0_rid_latest_endwrap_v4"):
        pass
    else:
        globals()["__vsp_p0_rid_latest_endwrap_v4"] = True

        _VSP_RID_ROOTS = [
            "/home/test/Data/SECURITY-10-10-v4/out_ci",
            "/home/test/Data/SECURITY_BUNDLE/out",
            "/home/test/Data/SECURITY_BUNDLE/out_ci",
        ]
        _RID_RE = _re.compile(r"^(VSP_CI_|RUN_).+")

        def _csv_has_2_lines(path: str) -> bool:
            try:
                if (not _os.path.isfile(path)) or _os.path.getsize(path) < 120:
                    return False
                n = 0
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    for _ in f:
                        n += 1
                        if n >= 2:
                            return True
                return False
            except Exception:
                return False

        def _sarif_has_results(path: str) -> bool:
            try:
                if (not _os.path.isfile(path)) or _os.path.getsize(path) < 200:
                    return False
                j = _json.load(open(path, "r", encoding="utf-8", errors="ignore"))
                for run in (j.get("runs") or []):
                    if (run.get("results") or []):
                        return True
                return False
            except Exception:
                return False

        def _is_rid(name: str) -> bool:
            if not name or name.startswith("."):
                return False
            if name.startswith("gate_root_"):
                return False
            return bool(_RID_RE.match(name))

        def _has_details(run_dir: str) -> str:
            fu = _os.path.join(run_dir, "findings_unified.json")
            try:
                if _os.path.isfile(fu) and _os.path.getsize(fu) > 500:
                    return "findings_unified.json"
            except Exception:
                pass

            csvp = _os.path.join(run_dir, "reports", "findings_unified.csv")
            if _csv_has_2_lines(csvp):
                return "reports/findings_unified.csv"

            sarifp = _os.path.join(run_dir, "reports", "findings_unified.sarif")
            if _sarif_has_results(sarifp):
                return "reports/findings_unified.sarif"

            pats = [
                "semgrep/**/*.json","grype/**/*.json","trivy/**/*.json","kics/**/*.json",
                "bandit/**/*.json","gitleaks/**/*.json","codeql/**/*.sarif",
            ]
            for pat in pats:
                for f in _glob.glob(_os.path.join(run_dir, pat), recursive=True):
                    try:
                        if _os.path.getsize(f) > 800:
                            return _os.path.relpath(f, run_dir).replace("\\","/")
                    except Exception:
                        continue
            return ""

        def _pick_latest_with_details(max_scan: int = 800):
            best = None  # (mtime, rid, root, why)
            for root in _VSP_RID_ROOTS:
                if not _os.path.isdir(root):
                    continue
                cands = []
                for rid in _os.listdir(root):
                    if not _is_rid(rid):
                        continue
                    d = _os.path.join(root, rid)
                    if not _os.path.isdir(d):
                        continue
                    try:
                        mtime = int(_os.path.getmtime(d))
                    except Exception:
                        mtime = 0
                    cands.append((mtime, rid, d))
                cands.sort(reverse=True)
                for mtime, rid, d in cands[:max_scan]:
                    why = _has_details(d)
                    if why:
                        cand = (mtime, rid, root, why)
                        if best is None or cand[0] > best[0]:
                            best = cand
                        break
            return best

        def _pick_latest_existing():
            best = None
            for root in _VSP_RID_ROOTS:
                if not _os.path.isdir(root):
                    continue
                cands = []
                for rid in _os.listdir(root):
                    if not _is_rid(rid):
                        continue
                    d = _os.path.join(root, rid)
                    if not _os.path.isdir(d):
                        continue
                    try:
                        cands.append((int(_os.path.getmtime(d)), rid, root))
                    except Exception:
                        cands.append((0, rid, root))
                cands.sort(reverse=True)
                if cands and (best is None or cands[0][0] > best[0]):
                    best = cands[0]
            return best

        def _payload():
            best = _pick_latest_with_details()
            if best:
                _, rid, _root, why = best
                return {
                    "ok": True,
                    "rid": rid,
                    "gate_root": "gate_root_" + rid,
                    "roots": _VSP_RID_ROOTS,
                    "reason": "latest_with_details",
                    "why": why,
                    "ts": int(_time.time()),
                }
            fb = _pick_latest_existing()
            if fb:
                _, rid, _root = fb
                return {
                    "ok": True,
                    "rid": rid,
                    "gate_root": "gate_root_" + rid,
                    "roots": _VSP_RID_ROOTS,
                    "reason": "latest_existing_fallback_no_details",
                    "why": "",
                    "ts": int(_time.time()),
                }
            return {
                "ok": False,
                "rid": "",
                "gate_root": "",
                "roots": _VSP_RID_ROOTS,
                "reason": "no_runs_found",
                "why": "",
                "ts": int(_time.time()),
            }

        def _json_resp(start_response, payload):
            body = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
            hdrs = [
                ("Content-Type","application/json; charset=utf-8"),
                ("Cache-Control","no-store"),
                ("X-VSP-RIDPICK","ENDWRAP_V4"),
                ("Content-Length", str(len(body))),
            ]
            start_response("200 OK", hdrs)
            return [body]

        def _mw(_app):
            def _wsgi(environ, start_response):
                path = environ.get("PATH_INFO","") or ""
                if path in ("/api/vsp/rid_latest_gate_root", "/api/vsp/rid_latest_gate_root.json"):
                    return _json_resp(start_response, _payload())
                return _app(environ, start_response)
            return _wsgi

        # Make this the outer-most wrapper (EOF)
        if "application" in globals() and callable(globals().get("application")):
            application = _mw(application)
        if "app" in globals() and callable(globals().get("app")):
            app = _mw(app)

        print("[VSP_P0_RID_LATEST_ENDWRAP_V4] enabled")
except Exception as _e:
    print("[VSP_P0_RID_LATEST_ENDWRAP_V4] ERROR:", _e)
# ===================== /VSP_P0_RID_LATEST_ENDWRAP_V4_STRICT =====================
