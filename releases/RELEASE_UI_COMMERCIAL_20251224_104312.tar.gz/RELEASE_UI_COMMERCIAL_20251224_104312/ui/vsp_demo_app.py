import socket
from datetime import datetime

# VSP_P0_TOPFIND_HELPERS_V3
def _vsp__sanitize_path(pth: str) -> str:
    if not pth:
        return ""
    pth = pth.replace("\\", "/")
    pth = re.sub(r'^/+', '', pth)
    parts = [x for x in pth.split("/") if x]
    return "/".join(parts[-4:]) if len(parts) > 4 else "/".join(parts)

def _vsp__sev_weight(sev: str) -> int:
    m = {
        "CRITICAL": 600, "HIGH": 500, "MEDIUM": 400, "LOW": 300, "INFO": 200, "TRACE": 100
    }
    return m.get((sev or "").upper(), 0)

def _vsp__candidate_run_roots():
    return [
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]

def _vsp__pick_latest_rid() -> str:
    best = ("", -1.0)
    for root in _vsp__candidate_run_roots():
        try:
            if not os.path.isdir(root): 
                continue
            for d in glob.glob(os.path.join(root, "VSP_*")):
                if not os.path.isdir(d):
                    continue
                mt = os.path.getmtime(d)
                name = os.path.basename(d)
                if mt > best[1]:
                    best = (name, mt)
        except Exception:
            continue
    return best[0] or ""

def _vsp__find_run_dir_for_rid(rid: str) -> str:
    if not rid:
        return ""
    for root in _vsp__candidate_run_roots():
        d = os.path.join(root, rid)
        if os.path.isdir(d):
            return d
    # prefix match
    best = ("", -1.0)
    for root in _vsp__candidate_run_roots():
        try:
            for d in glob.glob(os.path.join(root, rid + "*")):
                if not os.path.isdir(d):
                    continue
                mt = os.path.getmtime(d)
                if mt > best[1]:
                    best = (d, mt)
        except Exception:
            continue
    return best[0] or ""

def _vsp__load_unified_findings_anywhere(rid: str):
    run_dir = _vsp__find_run_dir_for_rid(rid)
    if not run_dir:
        return None, "RID_NOT_FOUND"
    candidates = [
        os.path.join(run_dir, "reports", "findings_unified.json"),
        os.path.join(run_dir, "findings_unified.json"),
        os.path.join(run_dir, "report", "findings_unified.json"),
    ]
    for fp in candidates:
        try:
            if not os.path.isfile(fp):
                continue
            with open(fp, "r", encoding="utf-8") as f:
                obj = json.load(f)
            if isinstance(obj, dict) and isinstance(obj.get("findings"), list):
                return (obj.get("findings") or []), ""
            if isinstance(obj, list):
                return obj, ""
        except Exception:
            continue
    return None, "UNIFIED_NOT_FOUND"

# VSP_P0_TOPFIND_PICK_RID_WITH_UNIFIED_V1
def _vsp__pick_latest_rid_with_unified() -> str:
    best = ("", -1.0)
    for root in _vsp__candidate_run_roots():
        try:
            if not os.path.isdir(root):
                continue
            for d in glob.glob(os.path.join(root, "VSP_*")):
                if not os.path.isdir(d):
                    continue
                # require at least one usable source
                cand = [
                    os.path.join(d, "reports", "findings_unified.json"),
                    os.path.join(d, "findings_unified.json"),
                    os.path.join(d, "report", "findings_unified.json"),
                    os.path.join(d, "reports", "findings_unified.csv"),
                ]
                ok = False
                for fp in cand:
                    try:
                        if os.path.isfile(fp) and os.path.getsize(fp) > 20:
                            ok = True
                            break
                    except Exception:
                        pass
                if not ok:
                    continue
                mt = os.path.getmtime(d)
                name = os.path.basename(d)
                if mt > best[1]:
                    best = (name, mt)
        except Exception:
            continue
    return best[0] or ""

# END VSP_P0_TOPFIND_HELPERS_V3


# VSP_P0_TOP_FINDINGS_HELPERS_V2
def _vsp__sanitize_path(pth: str) -> str:
    if not pth:
        return ""
    pth = pth.replace("\\", "/")
    pth = re.sub(r'^/+', '', pth)
    parts = [x for x in pth.split("/") if x]
    if len(parts) <= 4:
        return "/".join(parts)
    return "/".join(parts[-4:])

def _vsp__sev_weight(sev: str) -> int:
    m = {
        "CRITICAL": 600, "HIGH": 500, "MEDIUM": 400, "LOW": 300, "INFO": 200, "TRACE": 100
    }
    return m.get((sev or "").upper(), 0)

def _vsp__candidate_run_roots():
    return [
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]

def _vsp__pick_latest_rid() -> str:
    best = ("", -1.0)
    for root in _vsp__candidate_run_roots():
        try:
            if not os.path.isdir(root):
                continue
            for d in glob.glob(os.path.join(root, "VSP_*")):
                if not os.path.isdir(d):
                    continue
                mt = os.path.getmtime(d)
                name = os.path.basename(d)
                if mt > best[1]:
                    best = (name, mt)
        except Exception:
            continue
    return best[0] or ""

def _vsp__find_run_dir_for_rid(rid: str) -> str:
    if not rid:
        return ""
    for root in _vsp__candidate_run_roots():
        d = os.path.join(root, rid)
        if os.path.isdir(d):
            return d
    best = ("", -1.0)
    for root in _vsp__candidate_run_roots():
        try:
            for d in glob.glob(os.path.join(root, rid + "*")):
                if not os.path.isdir(d):
                    continue
                mt = os.path.getmtime(d)
                if mt > best[1]:
                    best = (d, mt)
        except Exception:
            continue
    return best[0] or ""

def _vsp__load_unified_findings_anywhere(rid: str):
    run_dir = _vsp__find_run_dir_for_rid(rid)
    if not run_dir:
        return None, "RID_NOT_FOUND"
    candidates = [
        os.path.join(run_dir, "reports", "findings_unified.json"),
        os.path.join(run_dir, "findings_unified.json"),
        os.path.join(run_dir, "report", "findings_unified.json"),
    ]
    for fp in candidates:
        try:
            if not os.path.isfile(fp):
                continue
            with open(fp, "r", encoding="utf-8") as f:
                obj = json.load(f)
            if isinstance(obj, dict) and isinstance(obj.get("findings"), list):
                findings = obj.get("findings") or []
            elif isinstance(obj, list):
                findings = obj
            else:
                findings = []
            return findings, ""
        except Exception:
            continue
    return None, "UNIFIED_NOT_FOUND"
# END VSP_P0_TOP_FINDINGS_HELPERS_V2


# ===================== VSP_P0_RID_PICK_ANY_DETAILS_HELPER_V3C =====================
import os as _os
import glob as _glob

def _vsp__csv_has_2_lines(path: str) -> bool:
    try:
        if not _os.path.isfile(path) or _os.path.getsize(path) < 120:
            return False
        n = 0
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for _ in f:
                n += 1
                if n >= 2:
                    return True
        return False
    except Exception:
        return False

def _vsp__sarif_has_results(path: str) -> bool:
    try:
        if not _os.path.isfile(path) or _os.path.getsize(path) < 200:
            return False
        import json as _json
        j = _json.load(open(path, "r", encoding="utf-8", errors="ignore"))
        for run in (j.get("runs") or []):
            if (run.get("results") or []):
                return True
        return False
    except Exception:
        return False

def _vsp__has_any_details(run_dir: str) -> str:
    # 1) unified json
    fu = _os.path.join(run_dir, "findings_unified.json")
    try:
        if _os.path.isfile(fu) and _os.path.getsize(fu) > 500:
            return "findings_unified.json"
    except Exception:
        pass

    # 2) reports csv/sarif
    csvp = _os.path.join(run_dir, "reports", "findings_unified.csv")
    if _vsp__csv_has_2_lines(csvp):
        return "reports/findings_unified.csv"

    sarifp = _os.path.join(run_dir, "reports", "findings_unified.sarif")
    if _vsp__sarif_has_results(sarifp):
        return "reports/findings_unified.sarif"

    # 3) raw tool outputs (fast patterns)
    pats = [
        "semgrep/**/*.json",
        "grype/**/*.json",
        "trivy/**/*.json",
        "kics/**/*.json",
        "bandit/**/*.json",
        "gitleaks/**/*.json",
        "codeql/**/*.sarif",
        "**/*codeql*.sarif",
        "**/*semgrep*.json",
        "**/*grype*.json",
        "**/*trivy*.json",
        "**/*kics*.json",
        "**/*bandit*.json",
        "**/*gitleaks*.json",
    ]
    for pat in pats:
        for f in _glob.glob(_os.path.join(run_dir, pat), recursive=True):
            try:
                if _os.path.getsize(f) > 800:
                    rel = _os.path.relpath(f, run_dir)
                    # skip the empty unified sarif to avoid false-positive
                    if rel.replace("\\","/") == "reports/findings_unified.sarif":
                        continue
                    return rel.replace("\\","/")
            except Exception:
                continue

    return ""

def _vsp__pick_latest_rid_with_details(roots, max_scan=200):
    best = None  # (mtime, rid, root, why)
    for root in roots:
        try:
            if not _os.path.isdir(root):
                continue
            # list subdirs and sort by mtime desc, scan top N only
            cands = []
            for name in _os.listdir(root):
                if not name or name.startswith("."):
                    continue
                run_dir = _os.path.join(root, name)
                if not _os.path.isdir(run_dir):
                    continue
                try:
                    mtime = int(_os.path.getmtime(run_dir))
                except Exception:
                    mtime = 0
                cands.append((mtime, name, run_dir))
            cands.sort(reverse=True)
            for mtime, rid, run_dir in cands[:max_scan]:
                why = _vsp__has_any_details(run_dir)
                if why:
                    cand = (mtime, rid, root, why)
                    if best is None or cand[0] > best[0]:
                        best = cand
                    break
        except Exception:
            continue
    if best:
        return {"ok": True, "rid": best[1], "root": best[2], "why": best[3]}
    return {"ok": False, "rid": "", "root": "", "why": ""}
# ===================== /VSP_P0_RID_PICK_ANY_DETAILS_HELPER_V3C =====================



# ===================== VSP_P0_RID_LATEST_PICK_EXISTING_V2B =====================
def _vsp__file_ok(path: str, min_bytes: int = 64) -> bool:
    try:
        return os.path.isfile(path) and os.path.getsize(path) >= min_bytes
    except Exception:
        return False

def _vsp__pick_latest_valid_rid(roots):
    best = None  # (mtime, rid, root)
    for root in roots:
        try:
            if not os.path.isdir(root):
                continue
            for name in os.listdir(root):
                if not name or name.startswith("."):
                    continue
                run_dir = os.path.join(root, name)
                if not os.path.isdir(run_dir):
                    continue

                gate_sum = os.path.join(run_dir, "run_gate_summary.json")
                gate = os.path.join(run_dir, "run_gate.json")
                if not (_vsp__file_ok(gate_sum, 10) or _vsp__file_ok(gate, 10)):
                    continue

                fu = os.path.join(run_dir, "findings_unified.json")
                if not _vsp__file_ok(fu, 200):
                    continue

                try:
                    mtime = int(os.path.getmtime(run_dir))
                except Exception:
                    mtime = 0

                cand = (mtime, name, root)
                if (best is None) or (cand[0] > best[0]):
                    best = cand
        except Exception:
            continue

    if best:
        return { "ok": True, "rid": best[1], "root": best[2], "reason": "gate+findings_unified" }
    return { "ok": False, "rid": "", "root": "", "reason": "no_valid_run_with_findings_unified" }
# ===================== /VSP_P0_RID_LATEST_PICK_EXISTING_V2B =====================


# ===================== VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_DUALPATCH_V4 =====================
import os, json, time
from pathlib import Path as _VSPPath
from flask import Response, request, send_file

def _vsp_p0_runs_roots():
    roots = []
    one = os.environ.get("VSP_RUNS_ROOT", "").strip()
    if one:
        roots.append(one)
    many = os.environ.get("VSP_RUNS_ROOTS", "").strip()
    if many:
        for x in many.split(":"):
            x = x.strip()
            if x:
                roots.append(x)

    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
    ]

    out, seen = [], set()
    for r in roots:
        if r not in seen:
            seen.add(r)
            out.append(r)
    return out

def _vsp_p0_try_resolve_gate_root_path(rid, gate_root_name):
    if not rid:
        return None
    if not gate_root_name:
        gate_root_name = f"gate_root_{rid}"

    for base in _vsp_p0_runs_roots():
        try:
            b = _VSPPath(base)
            if not b.is_dir():
                continue

            cand = b / gate_root_name
            if cand.is_dir():
                return str(cand)

            # 1 level
            for d1 in b.iterdir():
                if d1.is_dir():
                    c1 = d1 / gate_root_name
                    if c1.is_dir():
                        return str(c1)

            # 2 levels (bounded)
            for d1 in b.iterdir():
                if not d1.is_dir():
                    continue
                try:
                    for d2 in d1.iterdir():
                        if d2.is_dir():
                            c2 = d2 / gate_root_name
                            if c2.is_dir():
                                return str(c2)
                except Exception:
                    continue
        except Exception:
            continue
    return None

def _vsp_p0_virtual_manifest(rid, gate_root_name, gate_root_path, served_by):
    now = int(time.time())
    return {
        "ok": True,
        "rid": rid,
        "gate_root": gate_root_name,
        "gate_root_path": gate_root_path,
        "generated": True,
        "generated_at": now,
        "degraded": (gate_root_path is None),
        "served_by": served_by,
        "required_paths": [
            "run_gate.json",
            "run_gate_summary.json",
            "findings_unified.json",
            "reports/findings_unified.csv",
            "run_manifest.json",
            "run_evidence_index.json",
        ],
        "optional_paths": [
            "reports/findings_unified.sarif",
            "reports/findings_unified.html",
            "reports/findings_unified.pdf",
        ],
        "hints": {
            "set_env": "Set VSP_RUNS_ROOT or VSP_RUNS_ROOTS (colon-separated) to the parent folder that contains gate_root_<RID> directories.",
            "example": "VSP_RUNS_ROOT=/home/test/Data/SECURITY-10-10-v4/out_ci",
        },
    }

def _vsp_p0_virtual_evidence_index(rid, gate_root_name, gate_root_path, served_by):
    now = int(time.time())
    evidence_files = []
    evidence_dir = None

    if gate_root_path:
        for sub in ("evidence", "artifacts", "out/evidence"):
            ed = _VSPPath(gate_root_path) / sub
            if ed.is_dir():
                evidence_dir = str(ed)
                try:
                    for fp in sorted(ed.rglob("*")):
                        if fp.is_file():
                            evidence_files.append(str(fp.relative_to(ed)))
                except Exception:
                    pass
                break

    return {
        "ok": True,
        "rid": rid,
        "gate_root": gate_root_name,
        "gate_root_path": gate_root_path,
        "generated": True,
        "generated_at": now,
        "degraded": (gate_root_path is None),
        "served_by": served_by,
        "evidence_dir": evidence_dir,
        "files": evidence_files,
        "missing_recommended": [
            "evidence/ui_engine.log",
            "evidence/trace.zip",
            "evidence/last_page.html",
            "evidence/storage_state.json",
            "evidence/net_summary.json",
        ],
    }
# ===================== /VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_DUALPATCH_V4 =====================



# ===================== VSP_P0_AUTOGEN_MANIFEST_EVIDENCEINDEX_V1 =====================
def _vsp_p0__scan_run_dir(run_dir: str):
  import os, time, hashlib
  out=[]
  for root, dirs, files in os.walk(run_dir):
    # skip heavy/irrelevant dirs if any
    bn = os.path.basename(root)
    if bn in ("node_modules",".git","__pycache__"):
      continue
    for fn in files:
      fp = os.path.join(root, fn)
      rel = os.path.relpath(fp, run_dir)
      try:
        st=os.stat(fp)
        out.append({
          "path": rel.replace("\\","/"),
          "size": int(st.st_size),
          "mtime": int(st.st_mtime),
        })
      except Exception:
        out.append({"path": rel.replace("\\","/")})
  out.sort(key=lambda x: x.get("path",""))
  return out

def _vsp_p0__write_json_if_possible(fp: str, obj):
  import os, json
  try:
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    with open(fp, "w", encoding="utf-8") as f:
      json.dump(obj, f, ensure_ascii=False, indent=2)
    return True
  except Exception:
    return False

def _vsp_p0_make_run_manifest(run_dir: str, rid: str):
  import time, os
  files = _vsp_p0__scan_run_dir(run_dir)
  return {
    "rid": rid,
    "generated_at": int(time.time()),
    "run_dir": run_dir,
    "files_total": len(files),
    "files": files,
    "note": "auto-generated (P0) because run_manifest.json was missing",
  }

def _vsp_p0_make_run_evidence_index(run_dir: str, rid: str):
  import time, os
  required = [
    "run_gate.json",
    "run_gate_summary.json",
    "findings_unified.json",
    "run_manifest.json",
    "run_evidence_index.json",
    "reports/findings_unified.csv",
    "reports/findings_unified.sarif",
    "reports/findings_unified.html",
  ]
  present=[]
  missing=[]
  for p in required:
    if os.path.exists(os.path.join(run_dir, p)):
      present.append(p)
    else:
      missing.append(p)
  return {
    "rid": rid,
    "generated_at": int(time.time()),
    "run_dir": run_dir,
    "required": required,
    "present": present,
    "missing": missing,
    "audit_ready": (len(missing)==0),
    "note": "auto-generated (P0) because run_evidence_index.json was missing",
  }
# ===================== /VSP_P0_AUTOGEN_MANIFEST_EVIDENCEINDEX_V1 =====================

# VSP_P1_RUN_FILE_ALLOW_GATE_ALLOWLIST_AND_STRICT_V1
# === VSP_DASHV2_HARDEN_ALT_P0_V1 ===

# --- moved to bottom: dashboard_commercial_v2_harden ---
from flask import Flask, Response, send_file, jsonify, request, Blueprint, render_template, redirect, url_for
# VSP_FORCE_DEFINE_BLUEPRINT_TOP_P0_V2
# VSP_NULL_BLUEPRINTS_P0_V1
class _VSP_NullBlueprint:
    """Degrade-graceful Blueprint shim: decorators become no-ops so app can boot."""
    def __init__(self, name): self.name=name
    def route(self, *a, **k):
        def dec(fn): return fn
        return dec
    def get(self, *a, **k): return self.route(*a, **k)
    def post(self, *a, **k): return self.route(*a, **k)
    def put(self, *a, **k): return self.route(*a, **k)
    def delete(self, *a, **k): return self.route(*a, **k)

if 'vsp_runs_fs_bp' not in globals():
    vsp_runs_fs_bp = _VSP_NullBlueprint('vsp_runs_fs_bp')

# /VSP_NULL_BLUEPRINTS_P0_V1

_VSP_Blueprint = None  # FORCE early default to avoid import-time NameError


# --- VSP_P1_HEALTHZ_JSON_V1 ---
from flask import jsonify

def _vsp_best_effort_latest_rid():
    # Try to call local function if exists, else return N/A
    try:
        # some codebases expose a function or cache; keep safe
        return None
    except Exception:
        return None

# @app.get("/healthz")
def vsp_healthz_json_v1():
    data = {
        "ui_up": True,
        "ts": int(time.time()),
        "pid": os.getpid(),
        "host": socket.gethostname(),
        "contract": "P1_HEALTHZ_V1",
    }
    # best effort: attach latest rid via internal API handler if present
    try:
        # If there is a local function already used by /api/vsp/runs, reuse by calling it directly
        # Otherwise, leave N/A (avoid HTTP self-call to prevent deadlocks)
        if "vsp_runs_api" in globals() and callable(globals().get("vsp_runs_api")):
            resp = globals()["vsp_runs_api"]()
            # might be flask Response/json; we won't hard parse
        data["last_rid"] = data.get("last_rid","N/A")
    except Exception:
        data["last_rid"] = data.get("last_rid","N/A")

    return jsonify(data), 200
# --- /VSP_P1_HEALTHZ_JSON_V1 ---



app = Flask(

    __name__,
    static_folder="static",
    template_folder="templates",
)

# ===================== VSP_P2_RFALLOW_CONTRACT_AFTER_REQUEST_V2D_SAFE =====================
def _vsp_p2_rfallow_contract_after_request(resp):
    # Enrich wrapper contract for /api/vsp/run_file_allow ONLY.
    # IMPORTANT: do NOT wrap/modify raw JSON files (run_gate_summary.json, findings_unified.json, ...).
    try:
        from flask import request
        if request.path != '/api/vsp/run_file_allow':
            return resp
        txt = resp.get_data(as_text=True) if hasattr(resp, 'get_data') else ''
        if not txt:
            return resp
        ctype = (resp.headers.get('Content-Type') or '').lower()
        if ('application/json' not in ctype) and (not txt.lstrip().startswith('{')):
            return resp
        try:
            d = json.loads(txt)
        except Exception:
            return resp
        if not isinstance(d, dict):
            return resp
        # wrapper detection: only touch payloads that already look like wrapper
        if not ('path' in d or 'marker' in d or 'err' in d or 'ok' in d):
            return resp
        # If this looks like a raw file JSON (typical keys), skip
        raw_keys = {'by_tool','counts_total','findings','meta','runs','items'}
        if any(k in d for k in raw_keys) and ('err' not in d and 'marker' not in d):
            return resp
        rid = (request.args.get('rid','') or d.get('rid','') or '')
        path_raw = request.args.get('path','')
        if not path_raw:
            path_raw = (d.get('path','') or '')
        ok = bool(d.get('ok'))
        err = (d.get('err') or '')
        err_l = err.lower()
        http = d.get('http', None)
        if http is None:
            if ok: http = 200
            elif ('not allowed' in err_l) or ('forbidden' in err_l) or ('deny' in err_l): http = 403
            elif ('not found' in err_l) or ('missing' in err_l) or ('no such' in err_l): http = 404
            else: http = 400
        allow = d.get('allow', None)
        if allow is None or not isinstance(allow, list):
            allow = []
        d['ok'] = ok
        # [P2] override semantic http for missing RID
        if ('bad rid' in err_l) or ('unknown rid' in err_l):
            http = 404

        d['http'] = int(http)
        d['allow'] = allow
        d['rid'] = rid
        d['path'] = path_raw
        if 'marker' not in d:
            d['marker'] = 'VSP_P2_RFALLOW_CONTRACT_AFTER_REQUEST_V2D_SAFE'
        resp.set_data(json.dumps(d, ensure_ascii=False))
        resp.headers['Content-Type'] = 'application/json; charset=utf-8'
        return resp
    except Exception:
        return resp

# attach safely (NO decorator) -> avoids SyntaxError entirely
try:
    app.after_request(_vsp_p2_rfallow_contract_after_request)  # type: ignore[name-defined]
except Exception:
    pass
# ===================== /VSP_P2_RFALLOW_CONTRACT_AFTER_REQUEST_V2D_SAFE =====================






# ===================== VSP_P1_API_TABS3_COMMON_V3_JS_ALWAYS200_V1 =====================
try:
  from flask import Response, send_file, current_app
except Exception:
  Response = None
  send_file = None

from pathlib import Path as _Path

@app.get("/api/vsp_tabs3_common_v3.js")
def vsp_api_tabs3_common_v3_js():
  """Commercial P1: stop 404 noise for legacy/common bundle reference.
  - If static/js/vsp_tabs3_common_v3.js exists => serve it.
  - Else => return 200 placeholder JS (no-op).
  """
  try:
    js_path = _Path(current_app.root_path) / "static" / "js" / "vsp_tabs3_common_v3.js"
  except Exception:
    js_path = _Path("static/js/vsp_tabs3_common_v3.js")

  try:
    if send_file is not None and js_path.exists():
      return send_file(str(js_path), mimetype="application/javascript")
  except Exception:
    pass

  body = "/* VSP_P1_API_TABS3_COMMON_V3_JS_ALWAYS200_V1: placeholder to avoid 404 noise. */\n(()=>{/* noop */})();\n"
  if Response is None:
    return __vsp_rfa_finalize(body)
  return Response(body, mimetype="application/javascript")
# ===================== /VSP_P1_API_TABS3_COMMON_V3_JS_ALWAYS200_V1 =====================


# === VSP_LANDING_ALIAS_COMMERCIAL_P0_V1 ===
@app.get("/")
def vsp_landing():
    return redirect(url_for("vsp4"))

@app.get("/dashboard")
def vsp_dashboard_alias():
    return redirect(url_for("vsp4"))

@app.get("/vsp5")
def vsp5():
    # enterprise 5-tabs view
    return render_template("vsp_5tabs_enterprise_v2.html")
# === /VSP_LANDING_ALIAS_COMMERCIAL_P0_V1 ===



# === VSP_VSP4_TEMPLATE_FALLBACK_P0_V1 ===
@app.get("/vsp4")
def vsp4():
    """P0 fallback: always render vsp_dashboard_2025.html if present."""
    from pathlib import Path
    tpl = Path(__file__).resolve().parent / "templates" / "vsp_dashboard_2025.html"
    if tpl.exists():
        return render_template("vsp_dashboard_2025.html")
    # legacy message
    return "VSP4 template not found", 404
# === /VSP_VSP4_TEMPLATE_FALLBACK_P0_V1 ===


@app.get("/api/vsp/dashboard_commercial_v2_harden")
def vsp_api_dashboard_commercial_v2_harden():
    from pathlib import Path
    import json
    base = Path(__file__).resolve().parent
    fp = base / "findings_unified.json"

    payload = {"ok": False, "notes": ["missing findings_unified.json"], "counts_by_severity": {}, "items": [], "findings": []}
    if fp.exists():
        try:
            payload = json.loads(fp.read_text(encoding="utf-8", errors="replace"))
        except Exception as e:
            payload = {"ok": False, "notes": [f"invalid findings_unified.json: {e}"], "counts_by_severity": {}, "items": [], "findings": []}

    out = {
        "ok": True,
        "who": "VSP_DASHV2_HARDEN_ALT_P0_V1",
        "run_dir": payload.get("run_dir"),
        "summary_only": (payload.get("findings")==[] and len(payload.get("items") or [])>0),
        "counts_by_severity": payload.get("counts_by_severity") or {},
        "items_len": len(payload.get("items") or []),
    }
    return Response(json.dumps(out, ensure_ascii=False), mimetype="application/json")
# === /VSP_DASHV2_HARDEN_ALT_P0_V1 ===


import shutil
import zipfile


# === VSP_RUN_STATUS_V2_CONTRACT_P1_V1_BEGIN ===
import os, json, glob

# VSP_P1_RUNFILE_RIDNAME_ALLOW_SHA_V4

def _vsp_read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _vsp_find_run_dir(rid: str):
    """Best-effort resolve run dir for VSP_CI_* RID."""
    if not rid:
        return None
    # candidate roots (add more if needed)
    roots = [
        os.environ.get("VSP_OUT_CI_ROOT", ""),
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
    ]
    roots = [r for r in roots if r and os.path.isdir(r)]
    for r in roots:
        cand = os.path.join(r, rid)
        if os.path.isdir(cand):
            return cand
    # fallback glob
    for r in roots:
        hits = glob.glob(os.path.join(r, rid + "*"))
        for h in hits:
            if os.path.isdir(h):
                return h
    return None

def _vsp_findings_total(run_dir: str):
    if not run_dir:
        return None
    # prefer unified file if exists
    for fn in ("findings_unified.json","reports/findings_unified.json","findings_unified.sarif.json"):
        fp=os.path.join(run_dir, fn)
        if os.path.isfile(fp):
            j=_vsp_read_json(fp)
            if isinstance(j, dict):
                if isinstance(j.get("total"), int):
                    return j["total"]
                items=j.get("items")
                if isinstance(items, list):
                    return len(items)
    # fallback: any findings json
    fp=os.path.join(run_dir,"summary_unified.json")
    j=_vsp_read_json(fp) if os.path.isfile(fp) else None
    if isinstance(j, dict):
        t=j.get("total") or j.get("total_findings")
        if isinstance(t, int):
            return t
    return None

def _vsp_degraded_info(run_dir: str):
    """Best-effort degraded detection from runner.log (commercial degrade markers)."""
    if not run_dir:
        return (None, None)
    logp=os.path.join(run_dir,"runner.log")
    if not os.path.isfile(logp):
        # try tool logs
        for alt in ("kics/kics.log","codeql/codeql.log","trivy/trivy.log"):
            if os.path.isfile(os.path.join(run_dir,alt)):
                logp=os.path.join(run_dir,alt); break
        else:
            return (None, None)

    try:
        txt=Path(logp).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return (None, None)

    tools = ["BANDIT","SEMGREP","GITLEAKS","KICS","TRIVY","SYFT","GRYPE","CODEQL"]
    degraded=set()
    for t in tools:
        # strong markers we already use in scripts
        pats = [
            fr"VSP_{t}_TIMEOUT_DEGRADE",
            fr"\[{t}\].*DEGRADED",
            fr"{t}.*timeout.*degrad",
            fr"{t}.*missing.*degrad",
        ]
        for pat in pats:
            if re.search(pat, txt, flags=re.I):
                degraded.add(t)
                break
    n=len(degraded)
    return (n, n>0)

# === VSP_RUN_STATUS_V2_CONTRACT_P1_V1_END ===


# === VSP_MIN_IMPORTS_COMMERCIAL_V1 ===
# Hardened minimal imports to avoid NameError chain after patches
import os, sys, json, time, re, subprocess


# ---- commercial findings resolver ----  # VSP_FINDINGS_RESOLVE_V1
def vsp_resolve_findings_file(run_dir: str):
    import os
    cands = [
        "findings_unified_current.json",
        "findings_unified_commercial_v2.json",
        "findings_unified_commercial.json",
        "findings_unified.json",
    ]
    for name in cands:
        fp = os.path.join(run_dir, name)
        if os.path.isfile(fp) and os.path.getsize(fp) > 0:
            return fp
    return None
# ---- end resolver ----


# === VSP_EXPORT_PDF_RESOLVE_RUN_DIR_FROM_STATUSV2_V2 ===
def _vsp_resolve_ci_run_dir_from_status_v2_v2(rid: str):
    """Commercial: resolve run_dir using same contract as UI (run_status_v2)."""
    try:
        # local call: avoid requests dependency by importing urllib
        # local call: avoid requests dependency by importing urllib
        import json as _json
        from urllib.request import urlopen as _urlopen
        u = "http://127.0.0.1:8910/api/vsp/run_status_v2/" + str(rid)
        with _urlopen(u, timeout=2) as r:
            data = r.read().decode("utf-8", "ignore")
        d = _json.loads(data)
        ci = d.get("ci_run_dir") or d.get("ci") or ""
        if ci and isinstance(ci, str):
            return ci
    except Exception:
        return None
    return None

from pathlib import Path

class _VSP_WSGI_BYTES_POSTPROCESS_STATUSV2_GITLEAKS_V1:
    """Outermost WSGI wrapper: mutate JSON bytes for /api/vsp/run_status_v2/* so fields can't be overwritten later."""
    # === VSP_WSGI_BYTES_POSTPROCESS_STATUSV2_GITLEAKS_V1 ===
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        path = (environ.get("PATH_INFO") or "")
        if "/api/vsp/run_status_v2/" not in path:
            return self.app(environ, start_response)

        captured = {"status": None, "headers": None, "exc": None, "body_via_write": []}

        def _start_response_cap(status, headers, exc_info=None):
            captured["status"] = status
            captured["headers"] = list(headers or [])
            captured["exc"] = exc_info
            def _write(data):
                try:
                    if data:
                        captured["body_via_write"].append(data)
                except Exception:
                    pass
            return _write

        it = self.app(environ, _start_response_cap)

        chunks = []
        try:
            if captured["body_via_write"]:
                chunks.extend(captured["body_via_write"])
            if it is not None:
                for c in it:
                    if c:
                        chunks.append(c)
        finally:
            try:
                close = getattr(it, "close", None)
                if callable(close):
                    close()
            except Exception:
                pass

        body = b"".join(chunks)
        status = captured["status"] or "200 OK"
        headers = captured["headers"] or []

        ct = ""
        for k, v in headers:
            if str(k).lower() == "content-type":
                ct = str(v)
                break

        if ("application/json" not in ct.lower()) or (not body):
            start_response(status, headers, captured["exc"])
            return [body]

        try:
            import json
            from pathlib import Path as _P

            payload = json.loads(body.decode("utf-8", errors="ignore"))
            if isinstance(payload, dict):
                if payload.get("overall_verdict", None) is None:
                    payload["overall_verdict"] = ""

                payload.setdefault("has_gitleaks", False)
                payload.setdefault("gitleaks_verdict", "")
                payload.setdefault("gitleaks_total", 0)
                payload.setdefault("gitleaks_counts", {})

                ci = payload.get("ci_run_dir") or payload.get("ci_dir") or payload.get("ci") or ""
                ci = str(ci).strip()
                if ci:
                    def _readj(fp):
                        try:
                            if fp and fp.exists():
                                return json.loads(fp.read_text(encoding="utf-8", errors="ignore") or "{}")
                        except Exception:
                            return None
                        return None

                    base = _P(ci)

                    gsum = _readj(base / "gitleaks" / "gitleaks_summary.json") or _readj(base / "gitleaks_summary.json")
                    if not isinstance(gsum, dict):
                        try:
                            for fp in base.rglob("gitleaks_summary.json"):
                                gsum = _readj(fp)
                                if isinstance(gsum, dict):
                                    break
                        except Exception:
                            gsum = None

                    if isinstance(gsum, dict):
                        payload["has_gitleaks"] = True
                        payload["gitleaks_verdict"] = str(gsum.get("verdict") or "")
                        try:
                            payload["gitleaks_total"] = int(gsum.get("total") or 0)
                        except Exception:
                            payload["gitleaks_total"] = 0
                        cc = gsum.get("counts")
                        payload["gitleaks_counts"] = cc if isinstance(cc, dict) else {}

                    gate = _readj(base / "run_gate_summary.json")
                    if isinstance(gate, dict):
                        payload["overall_verdict"] = str(gate.get("overall") or payload.get("overall_verdict") or "")

                new_body = json.dumps(payload, ensure_ascii=False).encode("utf-8")

                new_headers = []
                for k, v in headers:
                    if str(k).lower() == "content-length":
                        continue
                    new_headers.append((k, v))
                new_headers.append(("Content-Length", str(len(new_body))))

                start_response(status, new_headers, captured["exc"])
                return [new_body]
        except Exception:
            pass

        start_response(status, headers, captured["exc"])
        return [body]


# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===
def _vsp_read_kics_summary(ci_run_dir: str):
    try:
        from pathlib import Path as _P
        fp = _P(ci_run_dir) / "kics" / "kics_summary.json"
        if not fp.exists():
            return None
        import json as _json
        obj = _json.loads(fp.read_text(encoding="utf-8", errors="ignore") or "{}")
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===

try:
    pass
except Exception:
    # allow import-time failure to surface clearly
    Flask = Blueprint = request = jsonify = Response = abort = send_file = None
# === END VSP_MIN_IMPORTS_COMMERCIAL_V1 ===

# === VSP_DEFINE__PATH_ALIAS_V1 ===
try:
    _Path
except Exception:
    _Path = Path
# === END VSP_DEFINE__PATH_ALIAS_V1 ===
UIREQ_STATE_DIR = Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")  # VSP_UIREQ_CANON_DIR_V1
from collections import defaultdict
import functools
import re
from api.vsp_run_export_api_v3 import bp_run_export_v3
from api.vsp_settings_rules_v1 import bp_settings_rules

# === VSP_RESTORE_MISSING_BLUEPRINTS_V1 ===
try:
    pass
except Exception:
    _VSP_Blueprint = None

if _VSP_Blueprint is not None:
    vsp_runs_fs_bp = _VSP_Blueprint("vsp_runs_fs_bp", __name__)
# === END VSP_RESTORE_MISSING_BLUEPRINTS_V1 ===


# === VSP_KICS_TAIL_HELPERS_V2 ===
import json as _vsp_json
from pathlib import Path as _vsp_Path

def _vsp_safe_tail_text(_p, max_bytes=8192, max_lines=120):

    # === VSP_RUN_EXPORT_V3_PDF_EARLY_RETURN_V1 ===
    try:
        _fmt = (request.args.get("fmt","") or "").lower()
    except Exception:
        _fmt = ""
    if _fmt == "pdf":
        # Resolve run_dir robustly from rid
        try:
            rid_in = rid
        except Exception:
            rid_in = request.view_args.get("rid","") if hasattr(request, "view_args") else ""
        rid_norm = str(rid_in or "")
        # Normalize RUN_VSP_CI_... -> VSP_CI_...
        if rid_norm.startswith("RUN_"):
            rid_norm2 = rid_norm[len("RUN_"):]
        else:
            rid_norm2 = rid_norm

        # Candidate run dirs (keep your current base)
        bases = [
            "/home/test/Data/SECURITY-10-10-v4/out_ci",
            "/home/test/Data/SECURITY-10-10-v4/out_ci/",
        ]
        cands = []
        for b in bases:
            cands.append(os.path.join(b, rid_norm2))
            cands.append(os.path.join(b, rid_norm))
            # also allow VSP_CI_ prefix if missing
            if "VSP_CI_" not in rid_norm2 and rid_norm2:
                cands.append(os.path.join(b, "VSP_CI_" + rid_norm2))

        run_dir = None
        for c in cands:
            try:
                if os.path.isdir(c):
                    run_dir = c
                    break
            except Exception:
                pass

        # If your existing code already computed run_dir earlier, prefer it
        if "run_dir" in locals() and isinstance(locals().get("run_dir"), str) and os.path.isdir(locals().get("run_dir")):
            run_dir = locals().get("run_dir")

        files = []
        if run_dir:
            globs = [
                os.path.join(run_dir, "report*.pdf"),
                os.path.join(run_dir, "reports", "report*.pdf"),
                os.path.join(run_dir, "*.pdf"),
                os.path.join(run_dir, "reports", "*.pdf"),
            ]
            for g in globs:
                try:
                    files += glob.glob(g)
                except Exception:
                    pass

        files = [f for f in files if isinstance(f, str) and os.path.isfile(f)]
        if files:
            try:
                pick = max(files, key=lambda x: os.path.getmtime(x))
            except Exception:
                pick = files[-1]
            rsp = send_file(pick, mimetype="application/pdf", as_attachment=True, download_name=os.path.basename(pick))
            rsp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
            return rsp

        # Not found => commercial: 200 + available=0 (NOT 404)
        rsp = jsonify({
            "ok": True,
            "fmt": "pdf",
            "available": 0,
            "rid": rid_norm,
            "rid_norm": rid_norm2,
            "run_dir": run_dir,
            "reason": "pdf_not_found",
        })
        rsp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        return rsp
    try:
        _p = _vsp_Path(_p)
        if not _p.exists():
            return ""
        b = _p.read_bytes()
    except Exception:
        return ""
    if max_bytes and len(b) > max_bytes:
        b = b[-max_bytes:]
    try:
        s = b.decode("utf-8", errors="replace")
    except Exception:
        s = str(b)
    lines = s.splitlines()
    if max_lines and len(lines) > max_lines:
        lines = lines[-max_lines:]
    return "\n".join(lines).strip()
def _vsp_kics_tail_from_ci(ci_run_dir):
    """
    Commercial guarantee:
      - If KICS log exists => return tail
      - Else try degraded_tools.json for KICS (rc/reason)
      - Else try runner.log tail for KICS rc=127 / command not found / No such file / timeout
      - Else if CI dir hints KICS stage => return explicit NO_KICS_LOG/NO_EVIDENCE message (NOT empty)
      - Else return "" (non-KICS runs)
    """
    if not ci_run_dir:
        return ""
    try:
        base = _vsp_Path(str(ci_run_dir))
    except Exception:
        return ""

    # 1) kics.log
    klog = base / "kics" / "kics.log"
    if klog.exists():
        return _vsp_safe_tail_text(klog)

    # 2) degraded_tools.json (either list or {"degraded_tools":[...]})
    for dj in (base / "degraded_tools.json",):
        if dj.exists():
            try:
                raw = dj.read_text(encoding="utf-8", errors="ignore").strip() or "[]"
                data = _vsp_json.loads(raw)
                items = data.get("degraded_tools", []) if isinstance(data, dict) else data
                for it in (items or []):
                    tool = str((it or {}).get("tool","")).upper()
                    if tool == "KICS":
                        rc = (it or {}).get("rc")
                        reason = (it or {}).get("reason") or (it or {}).get("msg") or "degraded"
                        return "MISSING_TOOL: KICS (rc=%s) reason=%s" % (rc, reason)
            except Exception:
                pass

    # 3) runner.log fallback (best effort)
    rlog = base / "runner.log"
    if rlog.exists():
        tail = _vsp_safe_tail_text(rlog, max_bytes=16384, max_lines=200)
        up = tail.upper()
        # detect KICS-related failures
        if "KICS" in up:
            # common missing/rc patterns
            if ("RC=127" in up) or ("COMMAND NOT FOUND" in up) or ("NO SUCH FILE" in up) or ("NOT FOUND" in up):
                # include last few lines containing KICS / rc=127 / not found
                lines = tail.splitlines()
                keep = []
                for ln in lines[-200:]:
                    u = ln.upper()
                    if ("KICS" in u) or ("RC=127" in u) or ("COMMAND NOT FOUND" in u) or ("NO SUCH FILE" in u) or ("NOT FOUND" in u):
                        keep.append(ln)
                msg = "\n".join(keep[-30:]).strip() or tail
                return "MISSING_TOOL: KICS (from runner.log)\n" + msg

            if ("TIMEOUT" in up) or ("RC=124" in up):
                return "TIMEOUT: KICS (from runner.log)\n" + tail

            # KICS mentioned but no explicit error: still give useful context
            return "NO_KICS_LOG: %s\n(from runner.log)\n%s" % (klog, tail)

    # 4) heuristic: CI dir hints KICS stage (kics folder exists or stage marker exists somewhere)
    if (base / "kics").exists():
        return "NO_KICS_LOG: %s" % (klog,)

    # runner.log missing, kics dir missing: cannot assert it's KICS stage
    return ""

def _runsfs_safe_load_json(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return json.load(f)
    except Exception:
        return None

def _runsfs_sum_totals(totals):
    if not isinstance(totals, dict):
        return 0
    s = 0
    for k,v in totals.items():
        try:
            s += int(v)
        except Exception:
            pass
    return s

def _runsfs_pick_runs(out_root, limit=50, hide_empty=False):
    items = []
    try:
        for name in os.listdir(out_root):
            if not name.startswith("RUN_"):
                continue
            run_dir = os.path.join(out_root, name)
            if not os.path.isdir(run_dir):
                continue
            rpt = os.path.join(run_dir, "report")
            summary = os.path.join(rpt, "summary_unified.json")
            st = os.stat(run_dir)
            created_at = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(st.st_mtime))
            meta = _runsfs_safe_load_json(os.path.join(run_dir, "ci_source_meta.json")) or {}
            s = _runsfs_safe_load_json(summary) or {}
            bysev = (s.get("summary_by_severity") or s.get("by_severity") or {})
            items.append({
                "rid": name,
                "created_at": created_at,
                "profile": (meta.get("profile") or s.get("profile") or ""),
                "target": (meta.get("target") or s.get("target") or ""),
                "totals": bysev if isinstance(bysev, dict) else {},
                "total_findings": _runsfs_sum_totals(bysev if isinstance(bysev, dict) else {}),
                "has_findings": 1 if _runsfs_sum_totals(bysev if isinstance(bysev, dict) else {}) > 0 else 0,
            })
    except Exception:
        pass
    if hide_empty:
        items = [it for it in items if int(it.get('has_findings',0)) == 1]
    # prefer has_findings then by time
    items.sort(key=lambda x: (int(x.get('has_findings',0)), x.get('created_at','')), reverse=True)
    # prefer has_findings sorting
    return items[:max(1, int(limit))]

@vsp_runs_fs_bp.get("/api/vsp/runs_index_v3_fs")
def vsp_runs_index_v3_fs():
    limit = request.args.get("limit", "40")
    try:
        limit_i = max(1, min(500, int(limit)))
    except Exception:
        limit_i = 40
    bundle_root = _Path(__file__).resolve().parents[1]  # .../SECURITY_BUNDLE
    bundle_root = _Path(os.environ.get('VSP_BUNDLE_ROOT', str(bundle_root))).resolve()
    out_dir = bundle_root / "out"
    hide_empty = request.args.get('hide_empty','0') in ('1','true','yes')
    items = _runsfs_pick_runs(str(out_dir), limit_i, hide_empty=hide_empty)
    kpi = {"total_runs": len(items), "last_n": min(20, len(items))}
    # === VSP_COMMERCIAL_RUNSFS_SORT_V1 (CI-first + newest-first) ===
    try:
        # 1) newest-first (ISO string compare works for YYYY-mm-ddTHH:MM:SS)
        # 1) newest-first (ISO string compare works for YYYY-mm-ddTHH:MM:SS)
        items.sort(key=lambda r: (str(r.get('created_at','')), str(r.get('run_id',''))), reverse=True)
        # 2) CI-first (stable sort)
        items.sort(key=lambda r: (0 if str(r.get('run_id','')).startswith('RUN_VSP_CI_') else 1))
    except Exception:
        pass
    # === END VSP_COMMERCIAL_RUNSFS_SORT_V1 ===

    return jsonify({"ok": True, "source": "fs", "items": items, "kpi": kpi})
# === END RUNS_INDEX_FS_V1 ===

import requests

# === Config chung ===
from pathlib import Path  # VSP_FORCE_PATH_SYMBOL_V3
ROOT = Path(__file__).resolve().parents[1]  # /home/test/Data/SECURITY_BUNDLE
CORE_BASE = "http://localhost:8961"         # Core API (dashboard_v3, runs_index_v3, datasource_v2)


# === VSP_SERVE_FINDINGS_UNIFIED_P0_V1 ===
@app.get("/findings_unified.json")
def vsp_findings_unified_json():
    """Serve unified findings in same-origin mode for UI widgets."""
    try:
        from pathlib import Path
        base = Path(__file__).resolve().parent
        fp = base / "findings_unified.json"
        if not fp.exists():
            return (
                "{\"ok\":false,\"error\":\"missing findings_unified.json\"}",
                404,
                {"Content-Type": "application/json"},
            )
        return send_file(str(fp), mimetype="application/json", as_attachment=False)
    except Exception as e:
        msg = str(e).replace('"', '\\"')
        return (
            "{\"ok\":false,\"error\":\"%s\"}" % msg,
            500,
            {"Content-Type": "application/json"},
        )
# === /VSP_SERVE_FINDINGS_UNIFIED_P0_V1 ===


# --- VSP_ASSET_VERSION (commercial) ---
import os as _os
import time as _time
from pathlib import Path as _Path

def _vsp_asset_v():
  v = _os.environ.get("VSP_ASSET_V", "").strip()
  if v:
    return v
  try:
    bp = (_Path(__file__).resolve().parent / "static/js/vsp_bundle_commercial_v1.js")
    return str(int(bp.stat().st_mtime))
  except Exception:
    return str(int(_time.time()))

@app.context_processor
def inject_vsp_asset_v():
  # Used by templates as: {{ asset_v }
  return {"asset_v": _vsp_asset_v()}
# --- /VSP_ASSET_VERSION ---


# === VSP_RUN_STATUS_V2_WINLAST_V6 ===
# Commercial harden: /api/vsp/run_status_v2/<rid> never 404, inject stage + degraded + KICS summary.
import json, re
def _vsp__sanitize_stage_name_v2(s: str) -> str:
    if not s:
        return ""
    s = str(s)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    # keep first line only
    s = s.split("\n", 1)[0].strip()
    # remove trailing markers
    if "=====" in s:
        s = s.split("=====", 1)[0].strip()
    # remove possible prefix like "===== [3/8]"
    s = re.sub(r"^=+\s*\[\s*\d+\s*/\s*\d+\s*\]\s*", "", s).strip()
    s = re.sub(r"\s*=+\s*$", "", s).strip()
    return s


from pathlib import Path
_STAGE_RE_V2 = re.compile(r"=+\s*\[\s*(\d+)\s*/\s*(\d+)\s*\]\s*([^\n=]+?)\s*=+", re.IGNORECASE)

def _vsp__tail_text_v2(pp: Path, max_bytes: int = 20000) -> str:
    try:
        if not pp.exists() or not pp.is_file():
            return ""
        bs = pp.read_bytes()
        if len(bs) > max_bytes:
            bs = bs[-max_bytes:]
        return bs.decode("utf-8", errors="ignore")
    except Exception:
        return ""

def _vsp__resolve_ci_run_dir_v2(rid: str):
    fn = globals().get("_vsp_guess_ci_run_dir_from_rid_v33")
    if callable(fn):
        try:
            d = fn(rid)
            if d and Path(d).exists():
                return str(Path(d))
        except Exception:
            pass

    rid_norm = str(rid).strip()
    rid_norm = rid_norm.replace("RUN_", "").replace("VSP_UIREQ_", "VSP_CI_")
    m = re.search(r"(VSP_CI_\d{8}_\d{6})", rid_norm)
    if m:
        cand = Path("/home/test/Data/SECURITY-10-10-v4/out_ci") / m.group(1)
        if cand.exists():
            return str(cand)
    return None

def _vsp__inject_stage_progress_v2(ci_dir: str, payload: dict):
    payload.setdefault("stage_name", "")
    payload.setdefault("stage_index", 0)
    payload.setdefault("stage_total", 0)
    payload.setdefault("progress_pct", 0)
    if not ci_dir:
        return
    tail = _vsp__tail_text_v2(Path(ci_dir) / "runner.log")
    if not tail:
        return

    # Normalize CRLF/CR to LF
    tail = tail.replace("\r\n", "\n").replace("\r", "\n")

    last = None
    for line in tail.split("\n"):
        # example line: "===== [3/8] KICS (EXT) ====="
        if "=====" in line and "]" in line and "[" in line:
            if re.search(r"\[\s*\d+\s*/\s*\d+\s*\]", line):
                last = line

    if not last:
        return

    mm = re.search(r"\[\s*(\d+)\s*/\s*(\d+)\s*\]", last)
    if not mm:
        return

    si = int(mm.group(1) or 0)
    st = int(mm.group(2) or 0)

    after = last.split("]", 1)[1] if "]" in last else ""
    name = after.split("=====", 1)[0].strip()

    payload["stage_name"] = name
    payload["stage_index"] = si
    payload["stage_total"] = st
    payload["progress_pct"] = int((si / st) * 100) if st > 0 else 0


def _vsp__read_json_if_exists_v2(p):
    """Return parsed JSON if file exists, else None. Never raises."""
    try:
        import json
        from pathlib import Path as _Path
        pp = _Path(p)
        if not pp.exists():
            return None
        with pp.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _vsp__inject_degraded_tools_v2(ci_dir: str, payload: dict):
    payload.setdefault("degraded_tools", [])
    if not ci_dir:
        return
    dj = _vsp__read_json_if_exists_v2(Path(ci_dir) / "degraded_tools.json")
    if isinstance(dj, list):
        payload["degraded_tools"] = dj

def _vsp__inject_kics_summary_v2(ci_dir: str, payload: dict):
    # === VSP_PAYLOAD_DEFAULT_GITLEAKS_V1 ===
    payload.setdefault("has_gitleaks", False)
    payload.setdefault("gitleaks_verdict", "")
    payload.setdefault("gitleaks_total", 0)
    payload.setdefault("gitleaks_counts", {})
    payload.setdefault("kics_verdict", "")
    payload.setdefault("kics_total", 0)
    payload.setdefault("kics_counts", {})
    if not ci_dir:
        return
    ksum = _vsp__read_json_if_exists_v2(Path(ci_dir) / "kics" / "kics_summary.json")
    if isinstance(ksum, dict):
        payload["kics_verdict"] = str(ksum.get("verdict") or "")
        payload["kics_total"] = int(ksum.get("total") or 0)
        cnt = ksum.get("counts") or {}
        payload["kics_counts"] = cnt if isinstance(cnt, dict) else {}

def api_vsp_run_status_v2_winlast_v6(rid):
    payload = {
        "ok": True,
        "rid": str(rid),
        "ci_run_dir": None,
        "stage_name": "",
        "stage_index": 0,
        "stage_total": 0,
        "progress_pct": 0,
        "kics_verdict": "",
        "kics_total": 0,
        "kics_counts": {},
        "degraded_tools": [],
    }

    ci_dir = _vsp__resolve_ci_run_dir_v2(str(rid))
    payload["ci_run_dir"] = ci_dir
    if not ci_dir:
        payload["ok"] = False
        payload["error"] = "CI_RUN_DIR_NOT_FOUND"

        # === VSP_STATUS_V2_CALLS_FIX_NO_CI_RUN_DIR_V1 ===
        try:
            _ci = None
            # prefer response field (most stable)
            if isinstance(resp, dict):
                _ci = resp.get("ci_run_dir") or resp.get("ci_dir") or resp.get("run_dir")
            # fallback: local vars if present
            try:
                _ci = _ci or ci_run_dir
            except Exception:
                pass
            try:
                _ci = _ci or ci_dir
            except Exception:
                pass
            _vsp_inject_tool_summary(resp, _ci, "semgrep", "semgrep_summary.json")
            _vsp_inject_tool_summary(resp, _ci, "trivy",   "trivy_summary.json")
            _vsp_inject_run_gate(resp, _ci)
        except Exception:
            pass

# === VSP_STATUS_ALWAYS8_TOOLS_V1 ===
    # Force commercial invariant: always present 8 tool lanes in status payload (NOT_RUN if missing)
    try:
        _CANON_TOOLS = ["SEMGREP","GITLEAKS","TRIVY","CODEQL","KICS","GRYPE","SYFT","BANDIT"]
        _ZERO_COUNTS = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0}

        # payload variable name may differ; attempt common ones
        _payload = None
        for _nm in ["payload","rsp","out","data","ret","result"]:
            if _nm in locals() and isinstance(locals().get(_nm), dict):
                _payload = locals()[_nm]
                break
        if _payload is None:
            # fallback: try the argument passed into jsonify(...) if it is a dict var
            pass

        if isinstance(_payload, dict):
            tools = _payload.get("tools") or _payload.get("by_tool") or _payload.get("tool_status") or {}
            if isinstance(tools, dict):
                for t in _CANON_TOOLS:
                    if t not in tools:
                        tools[t] = {
                            "tool": t,
                            "status": "NOT_RUN",
                            "verdict": "NOT_RUN",
                            "total": 0,
                            "counts": dict(_ZERO_COUNTS),
                            "reason": "missing_tool_output"
                        }
                # normalize container key
                _payload["tools"] = tools

            # Optional: keep a stable ordered list for UI
            _payload["tools_order"] = _CANON_TOOLS
    except Exception as _e:
        try:
            _payload = locals().get("payload")
            if isinstance(_payload, dict):
                _payload.setdefault("warnings", []).append("always8_tools_patch_failed")
        except Exception:
            pass


        return jsonify(payload), 200

    _vsp__inject_stage_progress_v2(ci_dir, payload)
    _vsp__inject_degraded_tools_v2(ci_dir, payload)
    _vsp__inject_kics_summary_v2(ci_dir, payload)
    payload["stage_name"] = _vsp__sanitize_stage_name_v2(payload.get("stage_name",""))
    return jsonify(payload), 200
def _vsp__register_run_status_v2_winlast_v6(flask_app):
    if flask_app is None:
        return
    try:
        flask_app.add_url_rule(
            "/api/vsp/run_status_v2/<rid>",
            endpoint="api_vsp_run_status_v2_winlast_v6",
            view_func=api_vsp_run_status_v2_winlast_v6,
            methods=["GET"],
        )
    except Exception as e:
        msg = str(e)
        if "already exists" in msg or "existing endpoint function" in msg:
            return
# === END VSP_RUN_STATUS_V2_WINLAST_V6 ===

_vsp__register_run_status_v2_winlast_v6(app)
# === VSP_AFTER_REQUEST_KICS_TAIL_V2_SAFE ===
def _vsp__kics_tail_from_ci(ci_run_dir: str, max_bytes: int = 65536) -> str:
    try:
        import os
        from pathlib import Path
        NL = chr(10)
        klog = os.path.join(ci_run_dir, "kics", "kics.log")
        if not os.path.exists(klog):
            return ""
        rawb = Path(klog).read_bytes()
        if len(rawb) > max_bytes:
            rawb = rawb[-max_bytes:]
        raw = rawb.decode("utf-8", errors="ignore").replace(chr(13), NL)
        # keep last non-empty lines (avoid spinner noise)
        lines2 = [x for x in raw.splitlines() if x.strip()]
        tail = NL.join(lines2[-60:])
        # pick latest HB/rc marker
        hb = ""
        for ln in reversed(lines2):
            if ("[KICS_V" in ln and "][HB]" in ln) or ("[KICS_V" in ln and "rc=" in ln) or ("[DEGRADED]" in ln):
                hb = ln.strip()
                break
        if hb and hb not in tail:
            tail = hb + NL + tail
        return tail[-4096:]
    except Exception:
        return ""

def _vsp__load_ci_dir_from_state(req_id: str) -> str:
    try:
        import json
        from pathlib import Path
        base = Path(__file__).resolve().parent
        cands = [
            base / "out_ci" / "uireq_v1" / (req_id + ".json"),
            base / "ui" / "out_ci" / "uireq_v1" / (req_id + ".json"),
            base / "out_ci" / "ui_req_state" / (req_id + ".json"),
            base / "ui" / "out_ci" / "ui_req_state" / (req_id + ".json"),
        ]
        for fp in cands:
            if fp.exists():
                txt = fp.read_text(encoding="utf-8", errors="ignore") or ""
                j = json.loads(txt) if txt.strip() else {}
                # === VSP_PREEMPT_STATUSV2_POSTPROCESS_HOOK_V1 ===
                try:
                    j = _vsp_preempt_statusv2_postprocess_v1(j)
                except Exception:
                    pass
                ci = str(j.get("ci_run_dir") or "")
                if ci:
                    return ci
        return ""
    except Exception:
        return ""

def _vsp__after_request_kics_tail(resp):
    try:
        import json
        if not request.path.startswith("/api/vsp/run_status_v1/"):
            return resp
        # only patch JSON responses
        if (getattr(resp, "mimetype", "") or "") != "application/json":
            return resp
        rid = request.path.rsplit("/", 1)[-1]
        data = resp.get_data(as_text=True) or ""
        obj = json.loads(data) if data.strip() else {}
        stage = str(obj.get("stage_name") or "").lower()
        ci = str(obj.get("ci_run_dir") or "")
        if not ci:
            ci = _vsp__load_ci_dir_from_state(rid)
        if ci and ("kics" in stage):
            kt = _vsp__kics_tail_from_ci(ci)
            if kt:
                obj["kics_tail"] = kt
                resp.set_data(json.dumps(obj, ensure_ascii=False))
                resp.headers["Content-Length"] = str(len(resp.get_data()))
        return resp
    except Exception:
        return resp

try:
    app.after_request(_vsp__after_request_kics_tail)
except Exception:
    pass
# === END VSP_AFTER_REQUEST_KICS_TAIL_V2_SAFE ===
# === VSP_RUN_API_FORCE_REGISTER_V2_AST (do not edit) ===
def _vsp__load_runapi_bp__v2():
    try:
        # normal import (package-style)
        # normal import (package-style)
        from run_api.vsp_run_api_v1 import bp_vsp_run_api_v1
        return bp_vsp_run_api_v1
    except Exception as e1:
        try:
            # fallback: load by file path (works even if run_api isn't a package)
            # fallback: load by file path (works even if run_api isn't a package)
            import importlib.util
            from pathlib import Path as _Path
            mod_path = _Path(__file__).resolve().parent / "run_api" / "vsp_run_api_v1.py"
            spec = importlib.util.spec_from_file_location("vsp_run_api_v1_dyn_v2", str(mod_path))
            mod = importlib.util.module_from_spec(spec)
            assert spec and spec.loader
            spec.loader.exec_module(mod)
            return getattr(mod, "bp_vsp_run_api_v1", None)
        except Exception as e2:
            print("[VSP_RUN_API] WARN load failed:", repr(e1), repr(e2))
            return None

try:
    _bp = _vsp__load_runapi_bp__v2()
    if _bp is not None:
        _bps = getattr(app, "blueprints", None) or {}
        if getattr(_bp, "name", None) in _bps:
            print("[VSP_RUN_API] already registered:", _bp.name)
        else:
            app.register_blueprint(_bp)
            print("[VSP_RUN_API] OK registered: /api/vsp/run_v1 + /api/vsp/run_status_v1/<REQ_ID>")
    else:
        print("[VSP_RUN_API] WARN: bp_vsp_run_api_v1 is None")
except Exception as e:
    print("[VSP_RUN_API] WARN: cannot register run_api blueprint:", repr(e))
# === END VSP_RUN_API_FORCE_REGISTER_V2_AST ===
# === RUNS_INDEX_FS_REGISTER_V1 ===
try:
    app.register_blueprint(vsp_runs_fs_bp)
except Exception as _e:
    pass
# === END RUNS_INDEX_FS_REGISTER_V1 ===

# === Helper proxy sang core 8961 ===
def proxy_get(path: str) -> Response:
    """
    Proxy GET từ 8910 -> 8961, giữ nguyên query string.
    """
    core_url = CORE_BASE + path
    try:
        resp = requests.get(core_url, params=request.args, timeout=60)
    except Exception as e:
        return jsonify(ok=False, error=f"Proxy error to core {core_url}: {e}"), 502

    headers = {}
    ct = resp.headers.get("Content-Type")
    if ct:
        headers["Content-Type"] = ct
    return Response(resp.content, status=resp.status_code, headers=headers)


# === Routes UI chính ===

# ===================== VSP_P1_RUNFILEALLOW_GUARD_ALWAYS200_V1H =====================
# UI-safety: never 404 for run_file_allow due to missing params; return JSON 200 instead.
try:
    from flask import request as _vsp_req, jsonify as _vsp_jsonify
except Exception:
    _vsp_req = None
    _vsp_jsonify = None

def _vsp_runfileallow_guard_v1h():
    if _vsp_req is None or _vsp_jsonify is None:
        return None
    try:
        path = (_vsp_req.path or "")
        if not path.startswith("/api/"):
            return None
        if path.endswith("/run_file_allow") or path.endswith("/run_file_allow/"):
            rid = (_vsp_req.args.get("rid","") or "").strip()
            fpath = _vsp_req.args.get("path", None)
            if not rid:
                return _vsp_jsonify(ok=False, err="missing rid", where="run_file_allow_guard_v1h"), 200
            if fpath is None or str(fpath).strip() == "":
                return _vsp_jsonify(ok=False, rid=rid, err="missing path", where="run_file_allow_guard_v1h"), 200
        return None
    except Exception as e:
        return _vsp_jsonify(ok=False, err="guard_exc:"+type(e).__name__, where="run_file_allow_guard_v1h"), 200

try:
    app.before_request(_vsp_runfileallow_guard_v1h)
except Exception:
    pass
# ===================== /VSP_P1_RUNFILEALLOW_GUARD_ALWAYS200_V1H =====================


@app.route("/")
def index():
    # Trang VSP 5 tab (index.html đã là layout mới)
    return render_template('vsp_5tabs_enterprise_v2.html')


@app.route("/security_bundle")
def security_bundle():
    # Giữ route cũ nếu có chỗ nào gọi
    return render_template('vsp_5tabs_enterprise_v2.html')


# === Proxy API: dashboard_v3, runs_index_v3, datasource_v2 ===



    try:
        root = pathlib.Path(__file__).resolve().parents[1]
        out_dir = root / "out"
        if not out_dir.is_dir():
            return jsonify(ok=False, error="no_out_dir"), 404

        ci_runs = sorted(
            [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_VSP_CI_")]
        )
        if not ci_runs:
            return jsonify(ok=False, error="no_ci_runs"), 404

        latest = ci_runs[-1]
        snap_path = latest / "report" / "ci_snapshot.json"
        flag_path = latest / "report" / "ci_flag_has_findings.env"

        snap_data = {}
        if snap_path.is_file():
            try:
                snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
            except Exception as e:
                app.logger.error("[CI_SNAPSHOT_API] Lỗi đọc %s: %s", snap_path, e)

        has_flag = None
        if flag_path.is_file():
            try:
                for line in flag_path.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith("has_findings="):
                        v = line.split("=", 1)[1].strip()
                        has_flag = (v == "1")
                        break
            except Exception as e:
                app.logger.error("[CI_SNAPSHOT_API] Lỗi đọc %s: %s", flag_path, e)

        # Ưu tiên has_findings từ snapshot, fallback sang flag
        has_findings = snap_data.get("has_findings", has_flag)

        resp = {
            "ok": True,
            "rid": snap_data.get("run_id", latest.name),
            "ci_run_dir": latest.name,
            "source": snap_data.get("source", "CI"),
            "has_findings": bool(has_findings) if has_findings is not None else None,
            "total_findings": snap_data.get("total_findings"),
            "by_severity": snap_data.get("by_severity", {}),
            "top_tools": snap_data.get("top_tools", []),
            "top_cwe": snap_data.get("top_cwe", []),
            "generated_at": snap_data.get("generated_at"),
            "raw": snap_data,
        }
        return jsonify(resp)
    except Exception as e:
        app.logger.exception("[CI_SNAPSHOT_API] Exception: %s", e)
        return jsonify(ok=False, error="exception", detail=str(e)), 500




    ci_runs = sorted(
        [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_VSP_CI_")]
    )
    if not ci_runs:
        return jsonify(ok=False, error="no_ci_runs"), 404

    latest = ci_runs[-1]
    snap_path = latest / "report" / "ci_snapshot.json"
    flag_path = latest / "report" / "ci_flag_has_findings.env"

    if not snap_path.is_file():
        return jsonify(ok=False, error="no_ci_snapshot", run_dir=latest.name), 404

    try:
        snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
    except Exception as e:
        app.logger.exception("[CI_SNAPSHOT_API_V2] Lỗi parse %s: %s", snap_path, e)
        return jsonify(ok=False, error="invalid_snapshot_json", run_dir=latest.name), 500

    has_flag = None
    if flag_path.is_file():
        try:
            for line in flag_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("has_findings="):
                    v = line.split("=", 1)[1].strip()
                    has_flag = (v == "1")
                    break
        except Exception as e:
            app.logger.error("[CI_SNAPSHOT_API_V2] Lỗi đọc %s: %s", flag_path, e)

    has_findings = snap_data.get("has_findings", has_flag)

    resp = {
        "ok": True,
        "rid": snap_data.get("run_id", latest.name),
        "ci_run_dir": latest.name,
        "source": snap_data.get("source", "CI"),
        "has_findings": bool(has_findings) if has_findings is not None else None,
        "total_findings": snap_data.get("total_findings"),
        "by_severity": snap_data.get("by_severity", {}),
        "top_tools": snap_data.get("top_tools", []),
        "top_cwe": snap_data.get("top_cwe", []),
        "generated_at": snap_data.get("generated_at"),
    }
    return jsonify(resp)


@app.route("/api/vsp/ci_snapshot_latest", methods=["GET"])
def vsp_ci_snapshot_latest():
    """
    Trả về snapshot CI mới nhất:
    - Chọn RUN_VSP_CI_* mới nhất trong out/
    - Đọc report/ci_snapshot.json + ci_flag_has_findings.env
    """
    import json
    import pathlib

    root = pathlib.Path(__file__).resolve().parents[1]
    out_dir = root / "out"

    if not out_dir.is_dir():
        return jsonify(ok=False, error="no_out_dir"), 404

    ci_runs = sorted(
        [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_VSP_CI_")]
    )
    if not ci_runs:
        return jsonify(ok=False, error="no_ci_runs"), 404

    latest = ci_runs[-1]
    snap_path = latest / "report" / "ci_snapshot.json"
    flag_path = latest / "report" / "ci_flag_has_findings.env"

    if not snap_path.is_file():
        return jsonify(ok=False, error="no_ci_snapshot", run_dir=latest.name), 404

    try:
        snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
    except Exception as e:
        app.logger.exception("[CI_SNAPSHOT_API_V2] Lỗi parse %s: %s", snap_path, e)
        return jsonify(ok=False, error="invalid_snapshot_json", run_dir=latest.name), 500

    has_flag = None
    if flag_path.is_file():
        try:
            for line in flag_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("has_findings="):
                    v = line.split("=", 1)[1].strip()
                    has_flag = (v == "1")
                    break
        except Exception as e:
            app.logger.error("[CI_SNAPSHOT_API_V2] Lỗi đọc %s: %s", flag_path, e)

    has_findings = snap_data.get("has_findings", has_flag)

    resp = {
        "ok": True,
        "rid": snap_data.get("run_id", latest.name),
        "ci_run_dir": latest.name,
        "source": snap_data.get("source", "CI"),
        "has_findings": bool(has_findings) if has_findings is not None else None,
        "total_findings": snap_data.get("total_findings"),
        "by_severity": snap_data.get("by_severity", {}),
        "top_tools": snap_data.get("top_tools", []),
        "top_cwe": snap_data.get("top_cwe", []),
        "generated_at": snap_data.get("generated_at"),
    }
    return jsonify(resp)


@app.route("/api/vsp/dashboard_delta_latest", methods=["GET"])
def vsp_dashboard_delta_latest():
    """
    Lightweight API: so sánh run mới nhất với run liền trước
    dựa trên out/summary_by_run.json.
    """
    import os, json, datetime as _dt

    root = os.path.dirname(os.path.dirname(__file__))
    summary_path = os.path.join(root, "out", "summary_by_run.json")

    if not os.path.exists(summary_path):
        return jsonify({"ok": False, "error": "summary_by_run.json not found"}), 404

    try:
        with open(summary_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        return jsonify({"ok": False, "error": "failed to load summary_by_run.json: %s" % e}), 500

    # Chuẩn hoá list run
    if isinstance(data, dict):
        items = list(data.get("runs") or data.get("items") or data.values())
    else:
        items = list(data or [])

    if not items:
        return jsonify({"ok": False, "error": "no runs in summary_by_run.json"}), 200

    def extract_ts(item):
        meta = item.get("meta") or {}
        for key in ("started_at", "created_at", "generated_at"):
            v = meta.get(key) or item.get(key)
            if isinstance(v, str):
                try:
                    return _dt.datetime.fromisoformat(v.replace("Z", ""))
                except Exception:
                    pass
        # Fallback: dùng run_id như timestamp thô
        rid = str(item.get("run_id") or "")
        try:
            return _dt.datetime.strptime(rid[-15:], "%Y%m%d_%H%M%S")
        except Exception:
            return _dt.datetime.min

    def is_full_ext(item):
        profile = (item.get("profile") or item.get("mode") or "").upper()
        rid = (item.get("run_id") or "").upper()
        return ("FULL_EXT" in profile) or ("FULL_EXT" in rid)

    full_ext = [it for it in items if is_full_ext(it)]
    source_items = full_ext if len(full_ext) >= 2 else items

    source_items = [it for it in source_items if isinstance(it, dict)]
    if len(source_items) < 2:
        return jsonify({"ok": False, "error": "not enough runs for delta"}), 200

    source_items.sort(
        key=lambda it: (extract_ts(it), str(it.get("run_id") or "")),
        reverse=True,
    )

    current, previous = source_items[0], source_items[1]

    def pick_num(it, keys, default=0):
        for k in keys:
            v = it.get(k)
            if isinstance(v, (int, float)):
                return v
        summary_all = it.get("summary_all") or {}
        for k in keys:
            v = summary_all.get(k)
            if isinstance(v, (int, float)):
                return v
        return default

    cur_total = pick_num(current, ["total_findings", "findings_total"])
    prev_total = pick_num(previous, ["total_findings", "findings_total"])

    cur_score = pick_num(current, ["security_posture_score", "security_score", "score"])
    prev_score = pick_num(previous, ["security_posture_score", "security_score", "score"])

    delta_total = None if (cur_total is None or prev_total is None) else cur_total - prev_total
    delta_score = None if (cur_score is None or prev_score is None) else cur_score - prev_score

    resp = {
        "ok": True,
        "current": {
            "rid": current.get("run_id"),
            "total_findings": cur_total,
            "security_posture_score": cur_score,
        },
        "previous": {
            "rid": previous.get("run_id"),
            "total_findings": prev_total,
            "security_posture_score": prev_score,
        },
        "delta": {
            "total_findings": delta_total,
            "security_posture_score": delta_score,
        },
    }
    return jsonify(resp)
@app.route("/api/vsp/dashboard_v3", methods=["GET"])
def api_vsp_dashboard_v3():

    # [VSP_UI_DASHBOARD_V3_LATEST_JSON_PATCH] Ưu tiên đọc file out/vsp_dashboard_v3_latest.json nếu tồn tại
    try:
        import json, pathlib
        ui_root = pathlib.Path(__file__).resolve().parent
        root = ui_root.parent  # /home/test/Data/SECURITY_BUNDLE
        latest_path = root / "out" / "vsp_dashboard_v3_latest.json"
        if latest_path.is_file():
            model = json.loads(latest_path.read_text(encoding="utf-8"))
            return jsonify(model)
    except Exception as e:  # noqa: E722
        try:
            current_app.logger.warning("VSP_UI_DASHBOARD_V3_LATEST_JSON_PATCH failed: %r", e)
        except Exception:
            print("VSP_UI_DASHBOARD_V3_LATEST_JSON_PATCH failed:", repr(e))
    return proxy_get("/api/vsp/dashboard_v3")






@app.route("/api/vsp/runs_index_v3")
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    - KPI + trend: cố gắng lấy từ out/summary_by_run.json (nếu có).
    - Danh sách runs (items): *không phụ thuộc* vào summary_by_run.json,
      mà tự quét out/RUN_*/report/findings_unified.json.
    """
    import json
    import datetime
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    kpi = {}
    trend = []

    # (1) Đọc KPI + trend (nếu có)
    if summary_path.exists():
        try:
            with summary_path.open("r", encoding="utf-8") as f:
                summary = json.load(f)
            if isinstance(summary, dict):
                kpi = summary.get("kpi") or {}
                trend = summary.get("trend_crit_high") or summary.get("trend") or []
        except Exception:
            pass

    # (2) Build items bằng cách duyệt RUN_* + findings_unified.json
    items = []

    run_dirs = [
        p for p in out_dir.iterdir()
        if p.is_dir() and p.name.startswith("RUN_")
    ]
    run_dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    for run_dir in run_dirs:
        run_id = run_dir.name
        report_dir = run_dir / "report"
        findings_file = report_dir / "findings_unified.json"
        summary_file = report_dir / "summary_unified.json"

        if not findings_file.exists() and not summary_file.exists():
            continue

        total_findings = None
        run_type = "UNKNOWN"
        source = "FULL_EXT"
        score = None
        started_at = None

        # (2a) Ưu tiên lấy total_findings từ findings_unified.json
        if findings_file.exists():
            try:
                with findings_file.open("r", encoding="utf-8") as f:
                    fd = json.load(f)
                if isinstance(fd, dict):
                    if isinstance(fd.get("items"), list):
                        items_list = fd["items"]
                        total_findings = int(fd.get("total", len(items_list)))
                    elif isinstance(fd.get("findings"), list):
                        items_list = fd["findings"]
                        total_findings = len(items_list)
                elif isinstance(fd, list):
                    total_findings = len(fd)
            except Exception:
                pass

        # (2b) Nếu vẫn chưa có total_findings, fallback sang summary_unified.json
        if total_findings is None and summary_file.exists():
            try:
                with summary_file.open("r", encoding="utf-8") as f:
                    s = json.load(f)
            except Exception:
                s = None

            if isinstance(s, dict):
                total_findings = (
                    s.get("summary_all", {}).get("total_findings")
                    if isinstance(s.get("summary_all"), dict)
                    else None
                )
                if total_findings is None:
                    total_findings = s.get("total_findings")

                if total_findings is None:
                    sev = None
                    if "summary_all" in s and isinstance(s["summary_all"], dict):
                        sev = s["summary_all"].get("by_severity")
                    if sev is None:
                        sev = s.get("by_severity")
                    if isinstance(sev, dict):
                        try:
                            total_findings = int(sum(int(v) for v in sev.values()))
                        except Exception:
                            total_findings = None

                run_profile = s.get("run_profile") if isinstance(s.get("run_profile"), dict) else {}
                run_type = run_profile.get("type") or run_profile.get("run_type") or run_type
                source = run_profile.get("source") or run_profile.get("source_type") or source
                score = s.get("security_posture_score")
                if score is None and isinstance(s.get("summary_all"), dict):
                    score = s["summary_all"].get("security_posture_score")
                started_at = run_profile.get("started_at") or run_profile.get("started") or started_at

        # (2c) Nếu vẫn không có total_findings thì bỏ run này
        if total_findings is None:
            continue

        # (2d) Nếu chưa có started_at thì lấy mtime thư mục
        if not started_at:
            try:
                dt = datetime.datetime.fromtimestamp(run_dir.stat().st_mtime)
                started_at = dt.isoformat(timespec="seconds")
            except Exception:
                started_at = ""

        item = {
            "rid": run_id,
            "run_type": run_type,
            "source": source,
            "total_findings": int(total_findings),
            "security_posture_score": score if isinstance(score, (int, float)) else None,
            "started_at": started_at,
        }
        items.append(item)

    # (3) Áp dụng limit
    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50
    items_slice = items[:limit]

    # (4) Nếu chưa có KPI thì tự build
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = total_findings_sum / float(last_n) if last_n > 0 else 0.0
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    Ưu tiên:
    1) Đọc KPI + trend từ out/summary_by_run.json (nếu có).
    2) Tự quét thư mục out/RUN_* để build danh sách items (list run)
       nên không phụ thuộc schema summary_by_run.json nữa.
    """
    import json
    from pathlib import Path
    import os
    import datetime

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    kpi = {}
    trend = []

    # (1) Đọc KPI + trend (nếu có)
    if summary_path.exists():
        try:
            with summary_path.open("r", encoding="utf-8") as f:
                summary = json.load(f)
            if isinstance(summary, dict):
                kpi = summary.get("kpi") or {}
                trend = summary.get("trend_crit_high") or summary.get("trend") or []
        except Exception:
            pass

    # (2) Quét thư mục RUN_* để build items
    items = []

    # Duyệt tất cả thư mục RUN_* trong out/
    run_dirs = [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_")]
    # Sắp xếp theo thời gian sửa đổi mới nhất (mới -> cũ)
    run_dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    for run_dir in run_dirs:
        run_id = run_dir.name
        report_dir = run_dir / "report"
        summary_file = report_dir / "summary_unified.json"
        if not summary_file.exists():
            continue

        try:
            with summary_file.open("r", encoding="utf-8") as f:
                s = json.load(f)
        except Exception:
            continue

        # Lấy total_findings
        total_findings = None
        # Ưu tiên các kiểu phổ biến
        if isinstance(s, dict):
            # Kiểu summary_all.total_findings
            total_findings = (
                s.get("summary_all", {}).get("total_findings")
                if isinstance(s.get("summary_all"), dict)
                else None
            )
            # Kiểu top-level total_findings
            if total_findings is None:
                total_findings = s.get("total_findings")

            # Nếu vẫn None, thử tính từ by_severity
            if total_findings is None:
                sev = None
                if "summary_all" in s and isinstance(s["summary_all"], dict):
                    sev = s["summary_all"].get("by_severity")
                if sev is None:
                    sev = s.get("by_severity")
                if isinstance(sev, dict):
                    try:
                        total_findings = int(sum(int(v) for v in sev.values()))
                    except Exception:
                        total_findings = None

            # Run type / source
            run_profile = s.get("run_profile") if isinstance(s.get("run_profile"), dict) else {}
            run_type = run_profile.get("type") or run_profile.get("run_type") or "UNKNOWN"
            source = run_profile.get("source") or run_profile.get("source_type") or "FULL_EXT"

            # Score nếu có
            score = s.get("security_posture_score")
            if score is None and isinstance(s.get("summary_all"), dict):
                score = s["summary_all"].get("security_posture_score")

            # Time nếu có
            started_at = run_profile.get("started_at") or run_profile.get("started") or None
        else:
            run_type = "UNKNOWN"
            source = "FULL_EXT"
            score = None
            started_at = None

        # Nếu vẫn chưa có total_findings, bỏ qua run này
        if total_findings is None:
            continue

        # Nếu không có started_at thì lấy mtime thư mục
        if not started_at:
            try:
                dt = datetime.datetime.fromtimestamp(run_dir.stat().st_mtime)
                started_at = dt.isoformat(timespec="seconds")
            except Exception:
                started_at = ""

        item = {
            "rid": run_id,
            "run_type": run_type,
            "source": source,
            "total_findings": int(total_findings),
            "security_posture_score": score if isinstance(score, (int, float)) else None,
            "started_at": started_at,
        }
        items.append(item)

    # (3) Áp dụng limit
    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50
    items_slice = items[:limit]

    # (4) Nếu chưa có KPI thì tự build
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = total_findings_sum / float(last_n) if last_n > 0 else 0.0
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    Đọc summary_by_run.json trong SECURITY_BUNDLE/out và
    expose items + kpi + trend_crit_high cho UI.
    """
    import json
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    try:
        with summary_path.open("r", encoding="utf-8") as f:
            summary = json.load(f)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Missing {summary_path}"}), 500

    # Chuẩn hóa items theo nhiều kiểu schema khác nhau
    if isinstance(summary, dict):
        raw_items = (
            summary.get("items")
            or summary.get("by_run")
            or summary.get("runs")
            or summary.get("data")
        )
        if isinstance(raw_items, list):
            items = raw_items
        else:
            items = []
        kpi = summary.get("kpi") or {}
        trend = summary.get("trend_crit_high") or summary.get("trend") or []
    else:
        items = summary if isinstance(summary, list) else []
        kpi = {}
        trend = []

    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50

    items_slice = items[:limit]

    # Nếu summary_by_run.json chưa có kpi ⇒ tự tính KPI cơ bản
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = total_findings_sum / float(last_n) if last_n > 0 else 0.0
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    Đọc summary_by_run.json trong SECURITY_BUNDLE/out và
    expose items + kpi + trend_crit_high cho UI.
    """
    import json
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    try:
        with summary_path.open("r", encoding="utf-8") as f:
            summary = json.load(f)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Missing {summary_path}"}), 500

    if isinstance(summary, dict):
        items = summary.get("items") or []
        kpi = summary.get("kpi") or {}
        trend = summary.get("trend_crit_high") or []
    else:
        items = summary
        kpi = {}
        trend = []

    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50

    items_slice = items[:limit]

    # Nếu summary_by_run.json chưa có kpi ⇒ tự tính KPI cơ bản
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = (
                total_findings_sum / float(last_n) if last_n > 0 else 0.0
            )
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    return proxy_get("/api/vsp/runs_index_v3")



@app.route("/api/vsp/datasource_v2")
def api_vsp_datasource_v2():
    """
    Local implementation cho Data Source tab (VSP 2025 UI demo).

    Thay vì proxy sang core, route này đọc trực tiếp
    findings_unified.json của latest FULL_EXT run trong
    SECURITY_BUNDLE/out.
    """
    import json
    from pathlib import Path

    # SECURITY_BUNDLE root = parent của thư mục ui/
    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"

    dash_path = out_dir / "vsp_dashboard_v3_latest.json"
    try:
        with dash_path.open("r", encoding="utf-8") as f:
            dash = json.load(f)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Missing {dash_path}"}), 500

    latest_run = dash.get("latest_run_id")
    if not latest_run:
        return jsonify(
            {"ok": False, "error": "No latest_run_id in vsp_dashboard_v3_latest.json"}
        ), 500

    findings_path = out_dir / latest_run / "report" / "findings_unified.json"
    try:
        with findings_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return jsonify(
            {
                "ok": False,
                "error": f"Missing findings_unified.json for run {latest_run}",
            }
        ), 500

    # data có thể là list hoặc {items: [...], total: N}
    if isinstance(data, dict) and "items" in data:
        items = data.get("items") or []
        total = int(data.get("total", len(items)))
    else:
        items = data
        total = len(items)

    try:
        limit = int(request.args.get("limit", 100))
    except Exception:
        limit = 100

    items_slice = items[:limit]

    return jsonify(
        {
            "ok": True,
            "rid": latest_run,
            "total": total,
            "limit": limit,
            "items": items_slice,
        }
    )
def api_vsp_datasource_v2():
    # Proxy đúng sang core, giữ nguyên run_dir, limit, filters,...
    return proxy_get("/api/vsp/datasource_v2")


# === RUN FULL SCAN EXT+ – gọi bin/vsp_selfcheck_full.sh ===

@app.route("/api/vsp/run_full_scan", methods=["POST", "OPTIONS"])
def api_vsp_run_full_scan():
    """
    Nhận JSON:
      {
        "profile": "EXT" | "FAST" | "AGGR" | "FULL" | ...,
        "source_root": "/home/test/Data/khach6",
        "target_url": "https://demo.demasterpro.com"
      }

    Gọi: bin/vsp_selfcheck_full.sh <profile> <source_root> <target_url>
    cwd = /home/test/Data/SECURITY_BUNDLE
    """
    if request.method == "OPTIONS":
        # Đơn giản trả 200 cho preflight nếu có
        return ("", 200)

    data = request.get_json(silent=True) or {}

    profile = data.get("profile") or "FULL_EXT"
    source_root = data.get("source_root") or data.get("src_path") or str(ROOT / "khach6")
    target_url = data.get("target_url") or data.get("url") or "https://demo.demasterpro.com"

    script = ROOT / "bin" / "vsp_selfcheck_full.sh"

    if not script.is_file():
        return jsonify(
            ok=False,
            error=f"Script không tồn tại: {script}",
        ), 500

    # Đảm bảo script có quyền execute
    try:
        os.chmod(str(script), 0o755)
    except Exception:
        pass

    try:
        proc = subprocess.Popen(
            [str(script), profile, source_root, target_url],
            cwd=str(ROOT),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as e:
        return jsonify(ok=False, error=f"Lỗi chạy {script}: {e}"), 500

    return jsonify(
        ok=True,
        pid=proc.pid,
        profile=profile,
        source_root=source_root,
        target_url=target_url,
    )


# === Healthcheck đơn giản (tuỳ chọn) ===
@app.route("/health")
def health():
    return jsonify(ok=True, app="vsp_demo_app", core=CORE_BASE)


# VSP_RUN_EXPORT_DIRECT_V1_BEGIN
import io, json, zipfile, subprocess, shutil
from pathlib import Path

@app.route("/api/vsp/settings_v1", methods=["GET", "POST"])

def _settings_file_path():
    import os
    # Cho phép override bằng env nếu cần
    path = os.environ.get("VSP_SETTINGS_FILE")
    if path:
        return path
    return os.path.join(os.path.dirname(__file__), "config", "settings_v1.json")


def _load_settings_from_file():
    import json, os
    path = _settings_file_path()
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        # Nếu file hỏng thì trả rỗng để UI còn tự fill mặc định
        return {}


def _save_settings_to_file(data):
    import json, os
    path = _settings_file_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

@app.route("/api/vsp/settings_ui_v1", methods=["GET", "POST"])
def vsp_settings_ui_v1():
    """
    Settings API cho UI:
    - GET  -> trả JSON {ok: true, settings: {...}
    - POST -> nhận {settings: {...}} hoặc object raw, lưu file rồi trả lại JSON.
    """

    if request.method == "GET":
        settings = _load_settings_from_file()
        return jsonify({"ok": True, "settings": settings})

    payload = request.get_json(silent=True) or {}
    # Nếu payload dạng {settings: {...}} thì lấy bên trong, còn không thì dùng cả object
    if isinstance(payload, dict) and "settings" in payload and isinstance(payload["settings"], dict):
        settings = payload["settings"]
    else:
        settings = payload

    _save_settings_to_file(settings)
    return jsonify({"ok": True, "settings": settings})


def vsp_settings_v1():
    """GET/POST settings trực tiếp trên gateway 8910 (lưu file JSON)."""
    if request.method == "GET":
        settings = _load_settings_from_file()
        return jsonify(ok=True, settings=settings)

    payload = request.get_json(silent=True) or {}
    try:
        _SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        _SETTINGS_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    return jsonify(ok=True)




    """
    UI-only wrapper cho file config/rule_overrides_v1.json.
    Dùng riêng cho tab Rules trên VSP_UI 2025.
    """
    import os, json, flask

    cfg_dir = os.path.join(os.path.dirname(__file__), "config")
    cfg_path = os.path.join(cfg_dir, "rule_overrides_v1.json")

    # POST: lưu overrides từ UI
    if flask.request.method == "POST":
        try:
            body = flask.request.get_json(force=True, silent=False)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc)), 400

        # Hỗ trợ các format:
        # - { "items": [...] }
        # - { "overrides": [...] }
        # - [ ... ]
        data = body
        if isinstance(body, dict):
            if "items" in body:
                data = body["items"]
            elif "overrides" in body:
                data = body["overrides"]

        os.makedirs(cfg_dir, exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return flask.jsonify(ok=True)

    # GET: đọc file, nếu chưa có thì trả [] để UI render bảng trống
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc), items=[], overrides=[], raw=None), 200
    else:
        raw = []

    # Chuẩn hóa: luôn có items + overrides
    if isinstance(raw, dict):
        items = raw.get("items") or raw.get("overrides") or raw
    else:
        items = raw

    return flask.jsonify(ok=True, items=items, overrides=items, raw=raw)
@app.route("/api/vsp/rule_overrides_ui_v1", methods=["GET", "POST", "OPTIONS"])
def vsp_rule_overrides_ui_v1():
    """
    UI-only wrapper cho file config/rule_overrides_v1.json.
    Dùng riêng cho tab Rules trên VSP_UI 2025.
    """
    import os, json, flask

    cfg_dir = os.path.join(os.path.dirname(__file__), "config")
    cfg_path = os.path.join(cfg_dir, "rule_overrides_v1.json")

    # POST: lưu overrides từ UI
    if flask.request.method == "POST":
        try:
            body = flask.request.get_json(force=True, silent=False)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc)), 400

        # Hỗ trợ các format:
        # - { "items": [...] }
        # - { "overrides": [...] }
        # - [ ... ]
        data = body
        if isinstance(body, dict):
            if "items" in body:
                data = body["items"]
            elif "overrides" in body:
                data = body["overrides"]

        os.makedirs(cfg_dir, exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return flask.jsonify(ok=True)

    # GET: đọc file, nếu chưa có thì trả [] để UI render bảng trống
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc), items=[], overrides=[], raw=None), 200
    else:
        raw = []

    # Chuẩn hóa: luôn có items + overrides
    if isinstance(raw, dict):
        items = raw.get("items") or raw.get("overrides") or raw
    else:
        items = raw

    return flask.jsonify(ok=True, items=items, overrides=items, raw=raw)

@app.route("/api/vsp/run_export_v3", methods=["GET"])
def vsp_run_export_v3():
    """
    Direct export HTML/ZIP/PDF/CSV cho 1 run - chạy trên UI gateway (8910).
    """
    import os, io, zipfile, json

    run_id = (request.args.get("run_id") or "").strip()
    fmt = (request.args.get("fmt") or "html").strip().lower()

    if not run_id:
        return jsonify({"ok": False, "error": "Missing run_id"}), 400

    # Thư mục out gốc: ưu tiên env VSP_OUT_ROOT, fallback ../out cạnh ui/
    base_out = os.environ.get("VSP_OUT_ROOT")
    if not base_out:
        base_out = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "out"))

    run_dir = os.path.join(base_out, run_id)
    if not os.path.isdir(run_dir):
        return jsonify({"ok": False, "error": f"Run dir not found: {run_dir}"}), 404

    report_dir = os.path.join(run_dir, "report")

    # HTML export
    if fmt == "html":
        candidates = [
            os.path.join(report_dir, "vsp_run_report_cio_v3.html"),
            os.path.join(report_dir, "vsp_run_report_cio_v2.html"),
            os.path.join(report_dir, "vsp_run_report_cio.html"),
            os.path.join(report_dir, "run_report.html"),
        ]
        for path in candidates:
            if os.path.isfile(path):
                return send_file(
                    path,
                    mimetype="text/html",
                    as_attachment=False,
                    download_name=os.path.basename(path),
                )

        # fallback – render summary_unified.json thành HTML đơn giản
        summary_path = os.path.join(report_dir, "summary_unified.json")
        summary = {}
        if os.path.isfile(summary_path):
            try:
                with open(summary_path, "r", encoding="utf-8") as f:
                    summary = json.load(f)
            except Exception:
                summary = {}

        body = json.dumps(
            summary or {"note": "No summary_unified.json found"},
            indent=2,
            ensure_ascii=False,
        )

        html = (
            "<html><head><meta charset='utf-8'>"
            "<title>VSP run {run_id}</title></head><body>"
            "<h1>VSP run {run_id}</h1>"
            "<pre>{body}</pre>"
            "</body></html>"
        ).format(run_id=run_id, body=body)

        return html

    # CSV export
    if fmt == "csv":
        csv_path = os.path.join(report_dir, "findings_unified.csv")
        if os.path.isfile(csv_path):
            return send_file(
                csv_path,
                mimetype="text/csv",
                as_attachment=True,
                download_name=f"{run_id}_findings.csv",
            )
        return jsonify({"ok": False, "error": "findings_unified.csv not found"}), 404

    # ZIP export
    if fmt == "zip":
        if not os.path.isdir(report_dir):
            return jsonify({"ok": False, "error": "report dir not found"}), 404

        mem = io.BytesIO()
        with zipfile.ZipFile(mem, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(report_dir):
                for fn in files:
                    full = os.path.join(root, fn)
                    rel = os.path.relpath(full, run_dir)
                    zf.write(full, rel)

        mem.seek(0)
        return send_file(
            mem,
            mimetype="application/zip",
            as_attachment=True,
            download_name=f"{run_id}_report.zip",
        )

    # PDF export (nếu có sẵn file PDF trong report/)
    if fmt == "pdf":
        if os.path.isdir(report_dir):
            for name in os.listdir(report_dir):
                if name.lower().endswith(".pdf"):
                    path = os.path.join(report_dir, name)
                    return send_file(
                        path,
                        mimetype="application/pdf",
                        as_attachment=True,
                        download_name=name,
                    )
        return jsonify({"ok": False, "error": "PDF report not found"}), 404

    return jsonify({"ok": False, "error": f"Unsupported fmt={fmt}"}), 400



@app.route("/api/vsp/run_fullscan_v1", methods=["POST"])
def vsp_run_fullscan_v1():
    """
    Nhận source_root / target_url / profile / mode từ UI,
    gọi shell wrapper vsp_run_fullscan_from_api_v1.sh chạy background.
    """
    import subprocess
    from pathlib import Path

    payload = request.get_json(force=True) or {}
    source_root = payload.get("source_root") or ""
    target_url = payload.get("target_url") or ""
    profile = payload.get("profile") or "FULL_EXT"
    mode = payload.get("mode") or "EXT_ONLY"

    wrapper = Path(__file__).resolve().parent.parent / "bin" / "vsp_run_fullscan_from_api_v1.sh"

    proc = subprocess.Popen(
        [str(wrapper), profile, mode, source_root, target_url],
        cwd=str(wrapper.parent.parent),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    app.logger.info("[VSP_RUN_FULLSCAN_API] payload=%s pid=%s", payload, proc.pid)

    return jsonify({
        "ok": True,
        "pid": proc.pid,
        "profile": profile,
        "mode": mode,
    })



@app.route("/api/vsp/rule_overrides_v1", methods=["GET", "POST"], endpoint="vsp_rule_overrides_v1_api_ui")
def vsp_rule_overrides_v1_api():
    """Simple file-based storage cho rule_overrides_v1.

    File lưu tại: ../config/rule_overrides_v1.json (tính từ thư mục ui/).
    """
    root = _VSP_Path2(__file__).resolve().parent.parent  # .../SECURITY_BUNDLE
    cfg_dir = root / "config"
    cfg_dir.mkdir(exist_ok=True)
    cfg_file = cfg_dir / "rule_overrides_v1.json"

    if request.method == "GET":
        if cfg_file.exists():
            try:
                data = _vsp_json2.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception as exc:  # pragma: no cover
                app.logger.warning("Invalid rule_overrides_v1.json: %s", exc)
                data = []
        else:
            data = []
        return jsonify(data)

    payload = request.get_json(force=True, silent=True)
    if payload is None:
        payload = []

    to_save = payload
    try:
        cfg_file.write_text(
            _vsp_json2.dumps(to_save, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception as exc:  # pragma: no cover
        app.logger.error("Cannot write rule_overrides_v1.json: %s", exc)
        return jsonify({"ok": False, "error": str(exc)}), 500

    return jsonify(to_save)

# === VSP Rule Overrides UI API stub V1 ===
from pathlib import Path as _VSP_Path_UI
import json as _vsp_json_ui



@app.route("/api/vsp/rule_overrides_ui_v1", methods=["GET", "POST"])
def vsp_rule_overrides_ui_v1_force():
    app.logger.info("[VSP_RULES_UI] stub handler active (vsp_rule_overrides_ui_v1_force)")
    root = _VSP_Path_UI2(__file__).resolve().parent.parent  # .../SECURITY_BUNDLE
    cfg_dir = root / "config"
    cfg_dir.mkdir(exist_ok=True)
    cfg_file = cfg_dir / "rule_overrides_v1.json"

    if request.method == "GET":
        if cfg_file.exists():
            try:
                data = _vsp_json_ui2.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception as exc:  # pragma: no cover
                app.logger.warning("Invalid rule_overrides_v1.json: %s", exc)
                data = []
        else:
            data = []
        return jsonify(data)

    payload = request.get_json(force=True, silent=True)
    if payload is None:
        payload = []

    to_save = payload
    try:
        cfg_file.write_text(
            _vsp_json_ui2.dumps(to_save, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception as exc:  # pragma: no cover
        app.logger.error("Cannot write rule_overrides_v1.json: %s", exc)
        return jsonify({"ok": False, "error": str(exc)}), 500

    return jsonify(to_save)




    """
    UI-only wrapper cho file config/rule_overrides_v1.json.
    Dùng riêng cho tab Rules trên VSP_UI 2025.
    """
    import os, json, flask

    cfg_dir = os.path.join(os.path.dirname(__file__), "config")
    cfg_path = os.path.join(cfg_dir, "rule_overrides_v1.json")

    # POST: lưu overrides từ UI
    if flask.request.method == "POST":
        try:
            body = flask.request.get_json(force=True, silent=False)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc)), 400

        # Hỗ trợ vài format:
        # - { "items": [...] }
        # - { "overrides": [...] }
        # - [ ... ]
        data = body
        if isinstance(body, dict):
            if "items" in body:
                data = body["items"]
            elif "overrides" in body:
                data = body["overrides"]

        os.makedirs(cfg_dir, exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return flask.jsonify(ok=True)

    # GET: đọc file, nếu chưa có thì trả [] để UI render bảng trống
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc), items=[], overrides=[], raw=None), 200
    else:
        raw = []

    # Chuẩn hóa: luôn có items + overrides
    if isinstance(raw, dict):
        items = raw.get("items") or raw.get("overrides") or raw
    else:
        items = raw

    return flask.jsonify(ok=True, items=items, overrides=items, raw=raw)


@app.route("/api/vsp/dashboard_extras_v1")
def vsp_dashboard_extras_v1():
    """Extras cho Dashboard: top findings, noisy paths, CVE, by_tool – stub V1.

    V1 chỉ wrap lại /api/vsp/dashboard_v3 nếu có, để UI có data tối thiểu.
    Sau này có thể mở rộng để đọc trực tiếp findings_unified.json.
    """

    base = {}
    try:
        # Gọi lại dashboard_v3 để lấy latest_run_id, by_tool...
        # Gọi lại dashboard_v3 để lấy latest_run_id, by_tool...
        with app.test_client() as c:
            r = c.get("/api/vsp/dashboard_v3")
            if r.is_json:
                base = r.get_json() or {}
    except Exception as e:
        base = {"error": str(e)}

    by_tool = (
        base.get("by_tool")
        or base.get("summary_by_tool")
        or {}
    )

    payload = {
        "ok": True,
        "latest_run_id": base.get("latest_run_id"),
        # Các field này V1 có thể rỗng, UI sẽ hiển thị 'No data'
        "top_risky": base.get("top_risky") or [],
        "top_noisy_paths": base.get("top_noisy_paths") or [],
        "top_cves": base.get("top_cves") or [],
        "by_tool_severity": by_tool,
    }
    return jsonify(payload)


@app.route("/api/vsp/datasource_export_v1")
def vsp_datasource_export_v1():
    """Export findings_unified cho Data Source – V1: JSON + CSV.

    - Nếu có run_dir trong query thì dùng run_dir đó.
    - Nếu không, dùng latest_run_id từ /api/vsp/dashboard_v3.
    """

    import json
    import csv
    import tempfile

    ui_root = Path(__file__).resolve().parent
    bundle_root = ui_root.parent
    out_root = bundle_root / "out"

    fmt = (request.args.get("fmt") or "json").strip().lower()
    run_dir_arg = (request.args.get("run_dir") or "").strip()

    run_dir = None

    if run_dir_arg:
        run_dir = Path(run_dir_arg)
    else:
        # Lấy latest_run_id từ dashboard_v3
        try:
            with app.test_client() as c:
                r = c.get("/api/vsp/dashboard_v3")
                if r.is_json:
                    data = r.get_json() or {}
                else:
                    data = {}
            latest_run_id = data.get("latest_run_id")
            if latest_run_id:
                run_dir = out_root / latest_run_id
        except Exception as e:
            return jsonify(ok=False, error=f"Không lấy được latest_run_id: {e}"), 500

    if run_dir is None:
        return jsonify(ok=False, error="Không xác định được run_dir"), 400

    if not run_dir.is_dir():
        return jsonify(ok=False, error=f"Run dir not found: {run_dir}"), 404

    report_dir = run_dir / "report"
    findings_path = report_dir / "findings_unified.json"

    if not findings_path.is_file():
        return jsonify(ok=False, error=f"Không tìm thấy findings_unified.json trong {report_dir}"), 404

    if fmt == "json":
        # Trả thẳng file JSON
        return send_file(
            findings_path,
            mimetype="application/json",
            as_attachment=True,
            download_name=f"{run_dir.name}_findings_unified.json",
        )

    if fmt == "csv":
        # Convert JSON -> CSV với các cột chuẩn
        try:
            items = json.loads(findings_path.read_text(encoding="utf-8"))
        except Exception as e:
            return jsonify(ok=False, error=f"Không đọc được JSON: {e}"), 500

        if not isinstance(items, list):
            return jsonify(ok=False, error="findings_unified.json không phải là list"), 500

        # Giữ schema giống Data Source ext columns
        fieldnames = [
            "severity",
            "tool",
            "rule",
            "path",
            "line",
            "message",
            "run",
            "cwe",
            "cve",
            "component",
            "tags",
            "fix",
        ]

        def norm_sev(s):
            if not s:
                return ""
            up = str(s).upper()
            known = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "TRACE"]
            return up if up in known else str(s)

        def extract_line(item):
            if "line" in item and item["line"] is not None:
                return item["line"]
            if "line_number" in item and item["line_number"] is not None:
                return item["line_number"]
            loc = item.get("location") or {}
            if isinstance(loc, dict) and "line" in loc:
                return loc["line"]
            return ""

        def extract_rule(item):
            for k in ["rule_id", "rule", "check_id", "check", "rule_name", "id"]:
                if k in item and item[k]:
                    return item[k]
            return ""

        def extract_msg(item):
            for k in ["message", "msg", "description", "title"]:
                if k in item and item[k]:
                    return item[k]
            return ""

        def extract_run(item):
            for k in ["run_id", "run", "run_ref"]:
                if k in item and item[k]:
                    return item[k]
            return ""

        def extract_cwe(item):
            if item.get("cwe"):
                return item["cwe"]
            if item.get("cwe_id"):
                return item["cwe_id"]
            if isinstance(item.get("cwe_list"), list) and item["cwe_list"]:
                return ",".join(map(str, item["cwe_list"]))
            return ""

        def extract_cve(item):
            if item.get("cve"):
                return item["cve"]
            for k in ["cve_list", "cves"]:
                v = item.get(k)
                if isinstance(v, list) and v:
                    return ",".join(map(str, v))
            return ""

        def extract_component(item):
            for k in ["component", "module", "package", "image"]:
                if item.get(k):
                    return item[k]
            return ""

        def extract_tags(item):
            tags = item.get("tags") or item.get("labels")
            if not tags:
                return ""
            if isinstance(tags, list):
                return ",".join(map(str, tags))
            return str(tags)

        def extract_fix(item):
            for k in ["fix", "remediation", "recommendation"]:
                if item.get(k):
                    return item[k]
            return ""

        tmp = tempfile.NamedTemporaryFile(mode="w+", suffix=".csv", delete=False, encoding="utf-8", newline="")
        tmp_path = Path(tmp.name)

        writer = csv.DictWriter(tmp, fieldnames=fieldnames)
        writer.writeheader()

        for it in items:
            if not isinstance(it, dict):
                continue
            row = {
                "severity": norm_sev(it.get("severity") or it.get("level")),
                "tool": it.get("tool") or it.get("source") or it.get("scanner") or "",
                "rule": extract_rule(it),
                "path": it.get("path") or it.get("file") or it.get("location") or "",
                "line": extract_line(it),
                "message": extract_msg(it),
                "run": extract_run(it),
                "cwe": extract_cwe(it),
                "cve": extract_cve(it),
                "component": extract_component(it),
                "tags": extract_tags(it),
                "fix": extract_fix(it),
            }
            writer.writerow(row)

        tmp.flush()
        tmp.close()

        return send_file(
            tmp_path,
            mimetype="text/csv",
            as_attachment=True,
            download_name=f"{run_dir.name}_findings_unified.csv",
        )

    return jsonify(ok=False, error=f"Unsupported fmt={fmt} (chỉ hỗ trợ json|csv trong V1)"), 400

@app.route("/api/vsp/dashboard_v3", methods=["GET"])
def vsp_dashboard_v3():
    """
    Dashboard V3:
      - Chọn run theo:
        + Pin trong vsp_dashboard_pin_v1.json, hoặc
        + FULL_EXT mới nhất có summary_unified.json
      - Trả total_findings + by_severity + by_tool
    """
    import json

    run_id = request.args.get("run_id") or pick_dashboard_run()

    if not run_id:
        return jsonify({
            "ok": False,
            "error": "No FULL_EXT run with summary_unified.json found",
            "latest_run_id": None,
        }), 500

    summary_file = (OUT_DIR / run_id / "report" / "summary_unified.json")

    if not summary_file.is_file():
        return jsonify({
            "ok": False,
            "error": f"summary_unified.json not found for {run_id}",
            "latest_run_id": run_id,
        }), 500

    summary = json.loads(summary_file.read_text(encoding="utf-8"))

    data = {
        "ok": True,
        "latest_run_id": run_id,
        "total_findings": sum(
            s.get("count", 0) for s in summary.get("summary_by_severity", {}).values()
        ),
        "by_severity": summary["summary_by_severity"],
        "by_tool": summary.get("by_tool", {}),
    }
    return jsonify(data)




# ==== VSP_METRICS_AFTER_REQUEST_V1 ====
# Inject KPI cho /api/vsp/dashboard_v3 và /api/vsp/runs_index_v3
# Không phá code cũ – chỉ chỉnh JSON response sau khi route xử lý xong.

import json as _vsp_json
import pathlib as _vsp_pathlib

SEVERITY_BUCKETS = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "TRACE"]

_VSP_ROOT = _vsp_pathlib.Path(__file__).resolve().parents[1]


def _vsp_build_severity_cards(by_sev):
    """Chuẩn hoá by_severity thành đầy đủ 6 bucket."""
    cards = {sev: 0 for sev in SEVERITY_BUCKETS}
    if not isinstance(by_sev, dict):
        return cards
    for sev, v in by_sev.items():
        if sev not in cards:
            continue
        if isinstance(v, dict):
            n = v.get("count") or v.get("total") or 0
        else:
            n = v
        try:
            cards[sev] = int(n)
        except Exception:
            pass
    return cards


def _vsp_security_score_simple(cards):
    """Score 0–100, càng nhiều CRIT/HIGH thì trừ điểm mạnh."""
    crit = cards.get("CRITICAL", 0)
    high = cards.get("HIGH", 0)
    med = cards.get("MEDIUM", 0)
    low = cards.get("LOW", 0)

    # model đơn giản: mỗi CRIT trừ 8, HIGH trừ 4, MED trừ 2, LOW trừ 1
    penalty = crit * 8 + high * 4 + med * 2 + low * 1
    score = 100 - penalty
    if score < 0:
        score = 0
    if score > 100:
        score = 100
    return int(score)


def vsp_metrics_after_request_v1(resp):
    """Bơm thêm KPI vào dashboard_v3 & runs_index_v3."""
    try:
        path = request.path
    except Exception:
        return resp

    # Chỉ xử lý JSON của namespace /api/vsp/
    if not getattr(resp, "is_json", False):
        return resp
    if not (isinstance(path, str) and path.startswith("/api/vsp/")):
        return resp

    try:
        data = resp.get_json(silent=True)
    except Exception:
        return resp

    changed = False

    # ===== 1) DASHBOARD V3 KPI =====
    if path == "/api/vsp/dashboard_v3" and isinstance(data, dict):
        by_sev = data.get("by_severity") or {}
        cards = _vsp_build_severity_cards(by_sev)

        if not data.get("severity_cards"):
            data["severity_cards"] = cards
            changed = True

        if "security_posture_score" not in data or data.get("security_posture_score") is None:
            data["security_posture_score"] = _vsp_security_score_simple(cards)
            changed = True

        # Alias cho field top_* nếu backend chỉ có top_cwe, top_module
        if "top_risky_tool" not in data:
            data["top_risky_tool"] = data.get("top_risky_tool") or data.get("top_tool")
        if "top_impacted_cwe" not in data:
            data["top_impacted_cwe"] = data.get("top_impacted_cwe") or data.get("top_cwe")
        if "top_vulnerable_module" not in data:
            data["top_vulnerable_module"] = data.get("top_vulnerable_module") or data.get("top_module")
        changed = True

    # ===== 2) RUNS_INDEX V3 KPI (dùng summary_by_run.json) =====
    if path == "/api/vsp/runs_index_v3" and isinstance(data, dict):
        summary_path = _VSP_ROOT / "out" / "summary_by_run.json"
        s = {}
        try:
            if summary_path.is_file():
                s = _vsp_json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[VSP_METRICS] Lỗi đọc {summary_path}: {e}")

        kpi = s.get("kpi")
        trend = s.get("trend_crit_high")

        if "kpi" not in data and kpi is not None:
            data["kpi"] = kpi
            changed = True
        if "trend_crit_high" not in data and trend is not None:
            data["trend_crit_high"] = trend
            changed = True

    if not changed:
        return resp

    # Ghi lại body JSON mới
    try:
        new_body = _vsp_json.dumps(data, ensure_ascii=False)
        resp.set_data(new_body)
        resp.mimetype = "application/json"
        resp.headers["Content-Type"] = "application/json; charset=utf-8"
        resp.headers["Content-Length"] = str(len(new_body.encode("utf-8")))
    except Exception as e:
        print(f"[VSP_METRICS] Lỗi set_data: {e}")
    return resp

# ==== END VSP_METRICS_AFTER_REQUEST_V1 ====



# ========== VSP_METRICS_TOP_V1 START ==========
import json
import logging
from collections import Counter
from pathlib import Path

logger = logging.getLogger(__name__)

_VSP_RISKY_SEVERITIES_TOP = {"CRITICAL", "HIGH"}

def _vsp_root_dir_from_ui_top():
    try:
        return Path(__file__).resolve().parent.parent
    except Exception:
        return Path(".")

def _vsp_find_report_dir_top(latest_run_id):
    try:
        root = _vsp_root_dir_from_ui_top()
        report_dir = root / "out" / latest_run_id / "report"
        if report_dir.is_dir():
            return report_dir
    except Exception as exc:
        logger.warning("[VSP_METRICS_TOP] Cannot resolve report dir for %s: %s", latest_run_id, exc)
    return None

def _vsp_load_findings_top(report_dir):
    f = report_dir / "findings_unified.json"
    if not f.exists():
        logger.info("[VSP_METRICS_TOP] %s không tồn tại – bỏ qua top_*", f)
        return []

    try:
        data = json.loads(f.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("[VSP_METRICS_TOP] Lỗi đọc %s: %s", f, exc)
        return []

    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        if isinstance(data.get("findings"), list):
            return data["findings"]
        if isinstance(data.get("items"), list):
            return data["items"]
    return []

def _vsp_extract_cwe_top(f):
    # 1) Field trực tiếp
    for key in ("cwe_id", "cwe", "cwe_code", "cweid"):
        val = f.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
        if isinstance(val, list) and val:
            first = val[0]
            if isinstance(first, str) and first.strip():
                return first.strip()
            if isinstance(first, dict):
                for kk in ("id", "code", "name"):
                    v2 = first.get(kk)
                    if isinstance(v2, str) and v2.strip():
                        return v2.strip()

    # 2) Danh sách cwes / cwe_ids
    for key in ("cwes", "cwe_ids"):
        val = f.get(key)
        if isinstance(val, list) and val:
            first = val[0]
            if isinstance(first, str) and first.strip():
                return first.strip()
            if isinstance(first, dict):
                for kk in ("id", "code", "name"):
                    v2 = first.get(kk)
                    if isinstance(v2, str) and v2.strip():
                        return v2.strip()

    # 3) Bên trong extra / metadata
    for key in ("extra", "metadata", "details"):
        sub = f.get(key)
        if isinstance(sub, dict):
            for kk in ("cwe_id", "cwe", "cwe_code", "cweid"):
                val = sub.get(kk)
                if isinstance(val, str) and val.strip():
                    return val.strip()
                if isinstance(val, list) and val:
                    first = val[0]
                    if isinstance(first, str) and first.strip():
                        return first.strip()
                    if isinstance(first, dict):
                        for k2 in ("id", "code", "name"):
                            v2 = first.get(k2)
                            if isinstance(v2, str) and v2.strip():
                                return v2.strip()

    # 4) Tìm trong tags/labels có "CWE-"
    for key in ("tags", "labels", "categories"):
        val = f.get(key)
        if isinstance(val, list):
            for item in val:
                if isinstance(item, str) and "CWE-" in item.upper():
                    return item.strip()

    return None

def _vsp_extract_module_top(f):
    # 1) Các key phổ biến cho module/dependency
    for key in (
        "dependency",
        "package",
        "package_name",
        "module",
        "component",
        "image",
        "image_name",
        "target",
        "resource",
        "resource_name",
        "artifact",
    ):
        val = f.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()

    # 2) Một số tool gói trong extra/metadata
    for key in ("extra", "metadata", "details"):
        sub = f.get(key)
        if isinstance(sub, dict):
            for kk in (
                "dependency",
                "package",
                "package_name",
                "module",
                "component",
                "image",
                "image_name",
                "target",
                "resource",
                "resource_name",
                "artifact",
            ):
                val = sub.get(kk)
                if isinstance(val, str) and val.strip():
                    return val.strip()

    # 3) Fallback: dùng đường dẫn file như "module"
    for key in ("file", "filepath", "path", "location"):
        val = f.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()

    return None

def _vsp_accumulate_top_metrics(findings, risky_only):
    by_tool = Counter()
    by_cwe = Counter()
    by_module = Counter()

    for item in findings:
        if not isinstance(item, dict):
            continue
        sev = str(item.get("severity", "")).upper()
        if risky_only and sev not in _VSP_RISKY_SEVERITIES_TOP:
            continue

        # Tool / engine
        tool = (
            item.get("tool")
            or item.get("source")
            or item.get("scanner")
            or item.get("engine")
            or item.get("engine_id")
            or item.get("provider")
        )
        if isinstance(tool, str) and tool.strip():
            by_tool[tool.strip()] += 1

        cwe = _vsp_extract_cwe_top(item)
        if cwe:
            by_cwe[cwe] += 1

        module = _vsp_extract_module_top(item)
        if module:
            by_module[module] += 1

    return by_tool, by_cwe, by_module

def _vsp_compute_top_metrics_top(latest_run_id):
    report_dir = _vsp_find_report_dir_top(latest_run_id)
    if not report_dir:
        return {}

    findings = _vsp_load_findings_top(report_dir)
    if not findings:
        return {}

    # Pass 1: chỉ CRITICAL/HIGH
    by_tool, by_cwe, by_module = _vsp_accumulate_top_metrics(findings, risky_only=True)

    # Nếu CWE/module không có thì fallback dùng tất cả severity
    if not by_cwe or not by_module:
        by_tool_all, by_cwe_all, by_module_all = _vsp_accumulate_top_metrics(findings, risky_only=False)
        if not by_tool and by_tool_all:
            by_tool = by_tool_all
        if not by_cwe and by_cwe_all:
            by_cwe = by_cwe_all
        if not by_module and by_module_all:
            by_module = by_module_all

    result = {}

    if by_tool:
        tool, n = by_tool.most_common(1)[0]
        result["top_risky_tool"] = {
            "id": tool,
            "label": tool,
            "crit_high": int(n),
        }

    if by_cwe:
        cwe, n = by_cwe.most_common(1)[0]
        result["top_impacted_cwe"] = {
            "id": cwe,
            "label": cwe,
            "count": int(n),
        }

    if by_module:
        module, n = by_module.most_common(1)[0]
        result["top_vulnerable_module"] = {
            "id": module,
            "label": module,
            "count": int(n),
        }

    return result

def vsp_metrics_after_request_top_v1(response):
    # Hậu xử lý riêng cho Dashboard V3 để bơm top_* nếu thiếu.
    try:
        path = request.path
    except RuntimeError:
        return response

    if path != "/api/vsp/dashboard_v3":
        return response

    mimetype = response.mimetype or ""
    if not mimetype.startswith("application/json"):
        return response

    try:
        data = json.loads(response.get_data(as_text=True) or "{}")
    except Exception:
        logger.warning("[VSP_METRICS_TOP] Không parse được JSON từ %s", path)
        return response

    latest_run_id = data.get("latest_run_id")
    if not isinstance(latest_run_id, str) or not latest_run_id:
        return response

    top = _vsp_compute_top_metrics_top(latest_run_id)
    if not top:
        return response

    for key in ("top_risky_tool", "top_impacted_cwe", "top_vulnerable_module"):
        if key in top and not data.get(key):
            data[key] = top[key]

    new_body = json.dumps(data, ensure_ascii=False).encode("utf-8")
    response.set_data(new_body)
    response.headers["Content-Length"] = str(len(new_body))
    return response

# ========== VSP_METRICS_TOP_V1 END ==========
# == VSP_TABS_ROUTER_INJECT_ANY_V1 ==
def vsp_tabs_router_inject_any(response):
    """Inject router JS vào TẤT CẢ response text/html.
    Không phụ thuộc id vsp-dashboard-main nữa.
    """
    try:
        ctype = response.headers.get("Content-Type", "")
        if "text/html" not in ctype.lower():
            return response

        body = response.get_data(as_text=True)

        # Nếu đã có script rồi thì thôi
        if "vsp_tabs_hash_router_v1.js" in body:
            return response

        if "</body>" not in body:
            return response

        body = body.replace(
            "</body>",
            '  <script src="/static/js/vsp_tabs_hash_router_v1.js" defer></script>\n</body>'
        )
        response.set_data(body)
    except Exception as e:
        print("[VSP_TABS_ROUTER_INJECT_ANY][ERR]", e)
    return response



# === VSP UI WHOAMI DEBUG V2 + API RUN CI TRIGGER ===
@app.route("/__vsp_ui_whoami", methods=["GET"])
def vsp_ui_whoami():
    """
    Endpoint debug để kiểm tra app nào đang chạy trên gateway 8910.
    """
    import os
    return jsonify({
        "ok": True,
        "app": "vsp_demo_app",
        "cwd": os.getcwd(),
        "file": __file__,
    })

@app.route("/api/vsp/run", methods=["POST"])
def api_vsp_run():
    """
    Trigger scan từ UI:
    Body:
    {
      "mode": "local" | "ci",
      "profile": "FULL_EXT",
      "target_type": "path",
      "target": "/path/to/project"
    }
    """
    import subprocess
    from pathlib import Path

    try:
        data = request.get_json(force=True, silent=True) or {}
    except Exception:
        data = {}

    mode = (data.get("mode") or "local").lower()
    profile = data.get("profile") or "FULL_EXT"
    target_type = data.get("target_type") or "path"
    target = data.get("target") or ""

    ci_mode = "LOCAL_UI"
    if mode in ("ci", "gitlab", "jenkins"):
        ci_mode = mode.upper() + "_UI"

    # Hiện tại chỉ hỗ trợ target_type=path
    if target_type != "path":
        return jsonify({
            "ok": False,
            "implemented": True,
            "ci_triggered": False,
            "error": "Only target_type='path' is supported currently"
        }), 400

    # Nếu không truyền, default là project SECURITY-10-10-v4
    if not target:
        target = "/home/test/Data/SECURITY-10-10-v4"

    wrapper = Path(__file__).resolve().parents[1] / "bin" / "vsp_ci_trigger_from_ui_v1.sh"

    if not wrapper.exists():
        return jsonify({
            "ok": False,
            "implemented": False,
            "ci_triggered": False,
            "error": f"Wrapper not found: {wrapper}"
        }), 500

    try:
        proc = subprocess.Popen(
            [str(wrapper), profile, target, ci_mode],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        stdout, stderr = proc.communicate(timeout=5)
        req_id = (stdout or "").strip() or "UNKNOWN"

        if proc.returncode != 0:
            return jsonify({
                "ok": False,
                "implemented": True,
                "ci_triggered": False,
                "request_id": req_id,
                "error": f"Wrapper exited with code {proc.returncode}",
                "stderr": (stderr or "")[-4000:],
            }), 500

        return jsonify({
            "ok": True,
            "implemented": True,
            "ci_triggered": True,
            "request_id": req_id,
            "profile": profile,
            "target": target,
            "ci_mode": ci_mode,
            "message": "Scan request accepted, CI pipeline running in background."
        })
    except subprocess.TimeoutExpired:
        return jsonify({
            "ok": True,
            "implemented": True,
            "ci_triggered": True,
            "request_id": "TIMEOUT_SPAWN",
            "profile": profile,
            "target": target,
            "ci_mode": ci_mode,
            "message": "Scan request spawned (timeout on wrapper stdout)."
        })
    except Exception as e:
        return jsonify({
            "ok": False,
            "implemented": False,
            "ci_triggered": False,
            "error": str(e),
        }), 500
# === END VSP UI WHOAMI DEBUG V2 + API RUN CI TRIGGER ===



# ============================================================
# VSP UI -> CI: Status endpoint for polling (Run Scan Now UI)
# GET /api/vsp/run_status/<req_id>
# - Reads UI trigger log: SECURITY_BUNDLE/out_ci/ui_triggers/UIREQ_*.log
# - Parses ci_run_id, gate, final rc
# - Returns tail log lines
# ============================================================
def _vsp_tail_lines(p: str, n: int = 80):
    try:
        with open(p, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.read().splitlines()
        return lines[-n:]
    except Exception as e:
        return [f"[run_status][ERR] cannot read log: {e}"]

def _vsp_parse_status_from_log(lines):
    # defaults
    status = "PENDING"
    final_rc = None
    ci_run_id = None
    gate = None

    # Parse ci_run_id from OUTER banner
    rx_run = re.compile(r"\bRUN_ID\b\s*=\s*(VSP_CI_\d{8}_\d{6})")
    rx_run2 = re.compile(r"\bRUN_ID\b\s*=\s*(VSP_CI_\d{8}_\d{6})")
    rx_outer = re.compile(r"\[VSP_CI_OUTER\].*?\bRUN_ID\b\s*=\s*(VSP_CI_\d{8}_\d{6})")
    rx_pipe_end = re.compile(r"\[VSP_UI_RUN\].*?Pipeline kết thúc với RC=(\-?\d+)")
    rx_gate_final = re.compile(r"\[VSP_CI_GATE\].*?\bFinal RC\b\s*:\s*(\-?\d+)")
    rx_runner_rc = re.compile(r"\[VSP_CI_GATE\].*?Runner kết thúc với RC=(\-?\d+)")
    rx_gate_pass = re.compile(r"\[VSP_CI_GATE\].*?\bGATE PASS\b")
    rx_gate_fail = re.compile(r"\[VSP_CI_GATE\].*?\bGATE FAIL\b")

    saw_start = False
    for ln in lines:
        if "[VSP_UI_RUN]" in ln or "[VSP_CI_OUTER]" in ln or "[VSP_CI_GATE]" in ln:
            saw_start = True

        m = rx_outer.search(ln) or rx_run.search(ln) or rx_run2.search(ln)
        if m and not ci_run_id:
            ci_run_id = m.group(1)

        if rx_gate_pass.search(ln):
            gate = "PASS"
        if rx_gate_fail.search(ln):
            gate = "FAIL"

        m = rx_gate_final.search(ln)
        if m:
            final_rc = int(m.group(1))

        m = rx_pipe_end.search(ln)
        if m:
            final_rc = int(m.group(1))

        # Nếu runner chết sớm mà chưa có Final RC
        if final_rc is None:
            m = rx_runner_rc.search(ln)
            if m:
                final_rc = int(m.group(1))

    if not saw_start:
        status = "PENDING"
    else:
        # Có start
        status = "RUNNING"
        if final_rc is not None:
            status = "DONE" if final_rc == 0 else "FAILED"

    return status, ci_run_id, gate, final_rc

def _vsp_try_read_has_findings(ci_run_id: str):
    # ưu tiên nếu đã sync về VSP core: out/RUN_VSP_CI_x/report/ci_flag_has_findings.env
    if not ci_run_id:
        return None

    vsp_run_id = "RUN_" + ci_run_id.replace("VSP_CI_", "VSP_CI_")
    vsp_flag = Path("/home/test/Data/SECURITY_BUNDLE/out") / vsp_run_id / "report" / "ci_flag_has_findings.env"
    # fallback: có thể có flag trong CI_RUN_DIR/report/ci_flag_has_findings.env (nếu bạn tạo ở outer)
    ci_flag = Path("/home/test/Data/SECURITY-10-10-v4/out_ci") / ci_run_id / "report" / "ci_flag_has_findings.env"

    for fp in [vsp_flag, ci_flag]:
        try:
            if fp.is_file():
                data = fp.read_text(encoding="utf-8", errors="ignore").splitlines()
                for ln in data:
                    ln = ln.strip()
                    if ln.startswith("has_findings="):
                        return int(ln.split("=", 1)[1].strip())
        except Exception:
            continue
    return None

@app.route("/api/vsp/run_status/<req_id>", methods=["GET"])
def api_vsp_run_status(req_id):
    # req_id expected like UIREQ_YYYYmmdd_HHMMSS_pid
    log_dir = Path("/home/test/Data/SECURITY_BUNDLE/out_ci/ui_triggers")
    log_path = log_dir / f"{req_id}.log"

    if not log_path.is_file():
        return jsonify({
            "ok": False,
            "error": f"REQ log not found: {log_path}"
        }), 404

    lines = _vsp_tail_lines(str(log_path), n=90)
    status, ci_run_id, gate, final_rc = _vsp_parse_status_from_log(lines)

    has_findings = _vsp_try_read_has_findings(ci_run_id)
    flag = {}
    if has_findings is not None:
        flag["has_findings"] = has_findings

    # === VSP_API_VSP_RUN_STATUS_INJECT_CI_KICS_V1 ===
    try:
        # ensure payload exists + is dict
        # ensure payload exists + is dict
        _pl = payload if isinstance(locals().get("payload", None), dict) else None
        if _pl is None:
            _pl = locals().get("obj", None) if isinstance(locals().get("obj", None), dict) else None
        if _pl is not None:
            _rid = (req_id or "").strip()
            _ci = (_pl.get("ci_run_dir") or "").strip()
            if not _ci:
                try:
                    _ci = _vsp_guess_ci_run_dir_from_rid_v33(_rid) or ""
                except Exception:
                    _ci = ""
                if _ci:
                    _pl["ci_run_dir"] = _ci
            if _ci:
                # inject KICS summary (if exists)
                try:
                    import json as _json
                    from pathlib import Path as _Path
                    _ks = _Path(_ci) / "kics" / "kics_summary.json"
                    if _ks.is_file():
                        _ko = _json.loads(_ks.read_text(encoding="utf-8", errors="ignore") or "{}")
                        if isinstance(_ko, dict):
                            _pl["kics_verdict"] = _ko.get("verdict","") or _pl.get("kics_verdict","")
                            try:
                                _pl["kics_total"] = int(_ko.get("total") or 0)
                            except Exception:
                                pass
                            _pl["kics_counts"] = _ko.get("counts") or _pl.get("kics_counts") or {}
                except Exception:
                    pass
    except Exception:
        pass

    return jsonify({
        "ok": True,
        "request_id": req_id,
        "status": status,
        "ci_run_id": ci_run_id,
        "gate": gate,
        "final": final_rc,
        "flag": flag,
        "tail": lines[-60:]  # UI show last 60 lines
    })


# === VSP_JSON_ERRHANDLERS_V4 ===
# Contract: any /api/vsp/* error must still be JSON so jq never dies.
def _vsp_env_int(name, default):
    try:
        import os
        v = os.getenv(name, "")
        if str(v).strip() == "":
            return int(default)
        return int(float(v))
    except Exception:
        return int(default)

def _vsp_api_json_err(code, msg):
    stall = _vsp_env_int("VSP_UIREQ_STALL_TIMEOUT_SEC", _vsp_env_int("VSP_STALL_TIMEOUT_SEC", 600))
    total = _vsp_env_int("VSP_UIREQ_TOTAL_TIMEOUT_SEC", _vsp_env_int("VSP_TOTAL_TIMEOUT_SEC", 7200))
    if stall < 1: stall = 1
    if total < 1: total = 1
    payload = {
        "ok": False,
        "status": "ERROR",
        "final": True,
        "error": msg,
        "http_code": code,
        "stall_timeout_sec": stall,
        "total_timeout_sec": total,
        "progress_pct": 0,
        "stage_index": 0,
        "stage_total": 0,
        "stage_name": "",
        "stage_sig": "",
    }
    return jsonify(payload), 200

def _vsp_err_404(e):
    try:
        if request.path.startswith("/api/vsp/"):
            return _vsp_api_json_err(404, "HTTP_404_NOT_FOUND")
    except Exception:
        pass
    return ("Not Found", 404)

def _vsp_err_500(e):
    try:
        if request.path.startswith("/api/vsp/"):
            return _vsp_api_json_err(500, "HTTP_500_INTERNAL")
    except Exception:
        pass
    return ("Internal Server Error", 500)

app.register_error_handler(404, _vsp_err_404)
app.register_error_handler(500, _vsp_err_500)
# === END VSP_JSON_ERRHANDLERS_V4 ===

# === VSP_RUN_API_FALLBACK_V1 ===
    
import os as _os
if _os.getenv("VSP_DISABLE_RUNAPI_FALLBACK", "0") == "1":
    print("[VSP_RUN_API_FALLBACK] disabled by VSP_DISABLE_RUNAPI_FALLBACK=1")
else:
    # If real run_api blueprint fails to load, we still MUST expose /api/vsp/run_v1 and /api/vsp/run_status_v1/*
    # so UI + jq never breaks. This is the "commercial contract".
    def _vsp_env_int(name, default):
        try:
            import os
            v = os.getenv(name, "")
            if str(v).strip() == "":
                return int(default)
            return int(float(v))
        except Exception:
            return int(default)

    def _vsp_contractize(payload):
        if not isinstance(payload, dict):
            payload = {"ok": False, "status": "ERROR", "final": True, "error": "INVALID_STATUS_PAYLOAD"}
        stall = _vsp_env_int("VSP_UIREQ_STALL_TIMEOUT_SEC", _vsp_env_int("VSP_STALL_TIMEOUT_SEC", 600))
        total = _vsp_env_int("VSP_UIREQ_TOTAL_TIMEOUT_SEC", _vsp_env_int("VSP_TOTAL_TIMEOUT_SEC", 7200))
        if stall < 1: stall = 1
        if total < 1: total = 1
        payload.setdefault("ok", bool(payload.get("ok", False)))
        payload.setdefault("status", payload.get("status") or "UNKNOWN")
        payload.setdefault("final", bool(payload.get("final", False)))
        payload.setdefault("error", payload.get("error") or "")
        payload.setdefault("req_id", payload.get("req_id") or "")
        payload["stall_timeout_sec"] = int(payload.get("stall_timeout_sec") or stall)
        payload["total_timeout_sec"] = int(payload.get("total_timeout_sec") or total)
        payload.setdefault("killed", bool(payload.get("killed", False)))
        payload.setdefault("kill_reason", payload.get("kill_reason") or "")
        payload.setdefault("progress_pct", int(payload.get("progress_pct") or 0))
        payload.setdefault("stage_index", int(payload.get("stage_index") or 0))
        payload.setdefault("stage_total", int(payload.get("stage_total") or 0))
        payload.setdefault("stage_name", payload.get("stage_name") or "")
        payload.setdefault("stage_sig", payload.get("stage_sig") or "")
        payload.setdefault("updated_at", int(__import__("time").time()))
        return payload

    try:
        bp_vsp_run_api_v1  # noqa
    except Exception:
        bp_vsp_run_api_v1 = None

    if bp_vsp_run_api_v1 is None:
        bp_vsp_run_api_v1 = Blueprint("vsp_run_api_v1_fallback", __name__)
        _VSP_FALLBACK_REQ = {}

        @bp_vsp_run_api_v1.route("/api/vsp/run_v1", methods=["POST"])
        def _fallback_run_v1():
            # Keep same behavior: missing body => 400 but still JSON
            body = None
            try:
                body = request.get_json(silent=True)
            except Exception:
                body = None
            if not body:
                return jsonify({"ok": False, "error": "MISSING_BODY"}), 400

            req_id = "REQ_FALLBACK_" + __import__("time").strftime("%Y%m%d_%H%M%S")
            st = _vsp_contractize({
                "ok": True,
                "status": "RUNNING",
                "final": False,
                "error": "",
                "req_id": req_id,
                "progress_pct": 0,
                "stage_index": 0,
                "stage_total": 0,
                "stage_name": "INIT",
                "stage_sig": "0/0|INIT|0",
            })
            _VSP_FALLBACK_REQ[req_id] = st
            return jsonify({"ok": True, "request_id": req_id, "implemented": False, "message": "Fallback run_api active (real bp load failed)."}), 200

        @bp_vsp_run_api_v1.route("/api/vsp/run_status_v1/<req_id>", methods=["GET"])
        def _fallback_run_status_v1(req_id):
            if req_id not in _VSP_FALLBACK_REQ:
                # === VSP_KICS_TAIL_PRE_RETURN_V3_DEBUG ===
                try:
                    import os, json
                    from pathlib import Path
                    NL = chr(10)
                    d = None
                    # try common local dict vars
                    for k in ('_out','out','resp','payload','ret','data','result','st'):
                        v = locals().get(k)
                        if isinstance(v, dict):
                            d = v; break
                    # fallback store (if exists)
                    if d is None:
                        fb = globals().get('_VSP_FALLBACK_REQ')
                        if isinstance(fb, dict):
                            vv = fb.get(req_id)
                            if isinstance(vv, dict): d = vv
                    if isinstance(d, dict):
                        d['_handler'] = '_fallback_run_status_v1'
                        ci = str(d.get('ci_run_dir') or '')
                        # if ci missing, try statefile candidates
                        if not ci:
                            base = Path(__file__).resolve().parent
                            cands = [
                                base / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                                base / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                                base / 'ui' / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                            ]
                            for stp in cands:
                                if stp.exists():
                                    try:
                                        t = stp.read_text(encoding='utf-8', errors='ignore') or ''
                                        j = json.loads(t) if t.strip() else dict()
                                        ci = str(j.get('ci_run_dir') or '')
                                        if ci: break
                                    except Exception:
                                        pass
                        klog = os.path.join(ci, 'kics', 'kics.log')
                        if ci and os.path.exists(klog):
                            rawb = Path(klog).read_bytes()
                            if len(rawb) > 65536: rawb = rawb[-65536:]
                            raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                            hb = ''
                            for ln in reversed(raw.splitlines()):
                                if '][HB]' in ln and '[KICS_V' in ln:
                                    hb = ln.strip(); break
                            ls2 = [x for x in raw.splitlines() if x.strip()]
                            tail = NL.join(ls2[-30:])
                            if hb and (hb not in tail): tail = hb + NL + tail
                            d['kics_tail'] = tail[-4096:]
                        else:
                            d['kics_tail'] = '[kics_tail] ci=' + str(ci) + ' exists=' + str(os.path.exists(klog))
                except Exception:
                    pass
                # === END VSP_KICS_TAIL_PRE_RETURN_V3_DEBUG ===
                return jsonify(_vsp_contractize({
                    "ok": False,
                    "status": "NOT_FOUND",
                    "final": True,
                    "error": "REQ_ID_NOT_FOUND",
                    "req_id": req_id
                })), 200
            # === VSP_STATUS_TAIL_APPEND_KICS_HB_V6_FIXED_SAFE ===
            try:
                import os
                st = _VSP_FALLBACK_REQ.get(req_id) or {}
                _stage = str(st.get('stage_name') or '').lower()
                _ci = str(st.get('ci_run_dir') or '')
                if ('kics' in _stage) and _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if os.path.exists(_klog):
                        with open(_klog, 'rb') as fh:
                            _rawb = fh.read()
                        if len(_rawb) > 65536:
                            _rawb = _rawb[-65536:]
                        _raw = _rawb.decode('utf-8', errors='ignore').replace('\r','\n')
                        _hb = ''
                        for _ln in reversed(_raw.splitlines()):
                            if '][HB]' in _ln and '[KICS_V' in _ln:
                                _hb = _ln.strip()
                                break
                        _lines = [x for x in _raw.splitlines() if x.strip()]
                        _tail = '\n'.join(_lines[-25:])
                        if _hb and (_hb not in _tail):
                            _tail = _hb + '\n' + _tail
                        st['tail'] = (_tail or '')[-4096:]
                        _VSP_FALLBACK_REQ[req_id] = st
            except Exception:
                pass
            # === END VSP_STATUS_TAIL_APPEND_KICS_HB_V6_FIXED_SAFE ===
            _out = _vsp_contractize(_VSP_FALLBACK_REQ[req_id])
            # === VSP_STATUS_TAIL_OVERRIDE_KICS_V8 ===
            try:
                import os
                from pathlib import Path
                _stage = str(_out.get('stage_name') or '').lower()
                _ci = str(_out.get('ci_run_dir') or '')
                if _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if os.path.exists(_klog):
                        rawb = Path(_klog).read_bytes()
                        if len(rawb) > 65536:
                            rawb = rawb[-65536:]
                        raw = rawb.decode('utf-8', errors='ignore').replace('\\r','\\n')
                        hb = ''
                        for ln in reversed(raw.splitlines()):
                            if '][HB]' in ln and '[KICS_V' in ln:
                                hb = ln.strip(); break
                        clean = [x for x in raw.splitlines() if x.strip()]
                        ktail = '\\n'.join(clean[-25:])
                        if hb and (hb not in ktail):
                            ktail = hb + '\\n' + ktail
                        _out['kics_tail'] = (ktail or '')[-4096:]
                        # only override main tail when stage is KICS
                        if 'kics' in _stage:
                            _out['tail'] = _out['kics_tail']
            except Exception:
                pass
            # === END VSP_STATUS_TAIL_OVERRIDE_KICS_V8 ===
            # === VSP_STATUS_TAIL_OVERRIDE_KICS_V10_RETURNPATCH ===
            _out = _vsp_contractize(_VSP_FALLBACK_REQ[req_id])
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                _stage = str(_out.get('stage_name') or '').lower()
                _ci = str(_out.get('ci_run_dir') or '')
                if not _ci:
                    try:
                        _st = (Path(__file__).resolve().parent / 'out_ci' / 'uireq_v1' / (req_id + '.json'))
                        if _st.exists():
                            txt = _st.read_text(encoding='utf-8', errors='ignore') or ''
                            j = json.loads(txt) if txt.strip() else dict()
                            _ci = str(j.get('ci_run_dir') or '')
                    except Exception:
                        pass
                if _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if os.path.exists(_klog):
                        rawb = Path(_klog).read_bytes()
                        if len(rawb) > 65536:
                            rawb = rawb[-65536:]
                        raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                        hb = ''
                        for ln in reversed(raw.splitlines()):
                            if '][HB]' in ln and '[KICS_V' in ln:
                                hb = ln.strip()
                                break
                        clean = [x for x in raw.splitlines() if x.strip()]
                        ktail = NL.join(clean[-25:])
                        if hb and (hb not in ktail):
                            ktail = hb + NL + ktail
                        _out['kics_tail'] = (ktail or '')[-4096:]
                        if 'kics' in _stage:
                            _out['tail'] = _out.get('kics_tail','')
            except Exception:
                pass
            # === END VSP_STATUS_TAIL_OVERRIDE_KICS_V10_RETURNPATCH ===
            # === VSP_KICS_TAIL_HOTFIX_V11_LITE2 ===
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                # ensure _out exists
                if '_out' not in locals():
                    _out = _vsp_contractize(_VSP_FALLBACK_REQ[req_id])
                _stage = str(_out.get('stage_name') or '').lower()
                _ci = str(_out.get('ci_run_dir') or _out.get('ci_dir') or '')
                if not _ci:
                    base = Path(__file__).resolve().parent
                    cands = [
                        base / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                        base / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                        base / 'ui' / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                        UIREQ_STATE_DIR / (req_id + '.json'),
                        UIREQ_STATE_DIR / (req_id + '.json'),
                    ]
                    for st in cands:
                        try:
                            if st.exists():
                                txt = st.read_text(encoding='utf-8', errors='ignore') or ''
                                j = json.loads(txt) if txt.strip() else dict()
                                _ci = str(j.get('ci_run_dir') or j.get('ci_dir') or '')
                                if _ci:
                                    _out['ci_run_dir'] = _ci
                                    break
                        except Exception:
                            pass
                _klog = ''
                if _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if not os.path.exists(_klog):
                        try:
                            kd = Path(_ci) / 'kics'
                            if kd.exists():
                                logs = [x for x in kd.glob('*.log') if x.is_file()]
                                logs.sort(key=lambda x: x.stat().st_mtime, reverse=True)
                                if logs:
                                    _klog = str(logs[0])
                        except Exception:
                            pass
                _tail_msg = ''
                if _klog and os.path.exists(_klog):
                    rawb = Path(_klog).read_bytes()
                    if len(rawb) > 65536:
                        rawb = rawb[-65536:]
                    raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                    hb = ''
                    for ln in reversed(raw.splitlines()):
                        if '][HB]' in ln and '[KICS_V' in ln:
                            hb = ln.strip(); break
                    clean = [x for x in raw.splitlines() if x.strip()]
                    ktail = NL.join(clean[-25:])
                    if hb and (hb not in ktail):
                        ktail = hb + NL + ktail
                    _tail_msg = (ktail or '')[-4096:]
                else:
                    # fallback: runner.log
                    if _ci:
                        rlog = os.path.join(_ci, 'runner.log')
                        if os.path.exists(rlog):
                            rawb = Path(rlog).read_bytes()
                            if len(rawb) > 65536:
                                rawb = rawb[-65536:]
                            raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                            clean = [x for x in raw.splitlines() if x.strip()]
                            _tail_msg = ('[KICS_TAIL][fallback runner.log]' + NL + NL.join(clean[-25:]))[-4096:]
                    if not _tail_msg:
                        _tail_msg = '[KICS_TAIL] no kics log yet'
                _out['kics_tail'] = _tail_msg
                if 'kics' in _stage:
                    _out['tail'] = _tail_msg
            except Exception:
                pass
            # === END VSP_KICS_TAIL_HOTFIX_V11_LITE2 ===
            # === VSP_FORCE_KICS_TAIL_V2 ===
            _out = _vsp_contractize(_VSP_FALLBACK_REQ[req_id])
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                _ci = str(_out.get('ci_run_dir') or '')
                if not _ci:
                    cands = [
                        (Path(__file__).resolve().parent / 'out_ci' / 'uireq_v1' / (req_id + '.json')),
                        (Path(__file__).resolve().parent / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json')),
                        (Path(__file__).resolve().parent / 'ui' / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json')),
                    ]
                    for _st in cands:
                        if _st.exists():
                            txt = _st.read_text(encoding='utf-8', errors='ignore') or ''
                            j = json.loads(txt) if txt.strip() else {}
                            _ci = str(j.get('ci_run_dir') or '')
                            break
                if _ci:
                    _klog = os.path.join(_ci, 'kics', 'kics.log')
                    if os.path.exists(_klog):
                        rawb = Path(_klog).read_bytes()
                        if len(rawb) > 65536:
                            rawb = rawb[-65536:]
                        raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                        hb = ''
                        for ln in reversed(raw.splitlines()):
                            if '][HB]' in ln and '[KICS_V' in ln:
                                hb = ln.strip(); break
                        lines2 = [x for x in raw.splitlines() if x.strip()]
                        tail = NL.join(lines2[-60:])
                        if hb and hb not in tail:
                            tail = hb + NL + tail
                        _out['kics_tail'] = tail[-4096:]
            except Exception:
                pass
            # === END VSP_FORCE_KICS_TAIL_V2 ===
            # === VSP_FORCE_KICS_TAIL_FINAL_RETURN_V1 ===
            _out = _out
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                if isinstance(_out, dict):
                    stage = str(_out.get('stage_name') or '').lower()
                    ci = str(_out.get('ci_run_dir') or '')
                    if ('kics' in stage) and ci:
                        klog = os.path.join(ci, 'kics', 'kics.log')
                        if os.path.exists(klog):
                            rawb = Path(klog).read_bytes()
                            if len(rawb) > 65536:
                                rawb = rawb[-65536:]
                            raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                            hb = ''
                            for ln in reversed(raw.splitlines()):
                                if '][HB]' in ln and '[KICS_V' in ln:
                                    hb = ln.strip(); break
                            lines2 = [x for x in raw.splitlines() if x.strip()]
                            tail = NL.join(lines2[-30:])
                            if hb and (hb not in tail):
                                tail = hb + NL + tail
                            _out['kics_tail'] = tail[-4096:]
            except Exception:
                pass
            # === END VSP_FORCE_KICS_TAIL_FINAL_RETURN_V1 ===
            # === VSP_FORCE_KICS_TAIL_BY_ROUTE_V2 ===
            _out = _out
            try:
                import os
                from pathlib import Path
                NL = chr(10)
                if isinstance(_out, dict):
                    ci = str(_out.get('ci_run_dir') or '')
                    if ci:
                        klog = os.path.join(ci, 'kics', 'kics.log')
                        if os.path.exists(klog):
                            rawb = Path(klog).read_bytes()
                            if len(rawb) > 65536:
                                rawb = rawb[-65536:]
                            raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                            hb = ''
                            for ln in reversed(raw.splitlines()):
                                if '][HB]' in ln and '[KICS_V' in ln:
                                    hb = ln.strip(); break
                            lines2 = [x for x in raw.splitlines() if x.strip()]
                            tail = NL.join(lines2[-30:])
                            if hb and (hb not in tail):
                                tail = hb + NL + tail
                            _out['kics_tail'] = tail[-4096:]
            except Exception:
                pass
            # === END VSP_FORCE_KICS_TAIL_BY_ROUTE_V2 ===
            # === VSP_KICS_TAIL_PRE_RETURN_V3_DEBUG ===
            try:
                import os, json
                from pathlib import Path
                NL = chr(10)
                d = None
                # try common local dict vars
                for k in ('_out','out','resp','payload','ret','data','result','st'):
                    v = locals().get(k)
                    if isinstance(v, dict):
                        d = v; break
                # fallback store (if exists)
                if d is None:
                    fb = globals().get('_VSP_FALLBACK_REQ')
                    if isinstance(fb, dict):
                        vv = fb.get(req_id)
                        if isinstance(vv, dict): d = vv
                if isinstance(d, dict):
                    d['_handler'] = '_fallback_run_status_v1'
                    ci = str(d.get('ci_run_dir') or '')
                    # if ci missing, try statefile candidates
                    if not ci:
                        base = Path(__file__).resolve().parent
                        cands = [
                            base / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                            base / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                            base / 'ui' / 'ui' / 'out_ci' / 'uireq_v1' / (req_id + '.json'),
                        ]
                        for stp in cands:
                            if stp.exists():
                                try:
                                    t = stp.read_text(encoding='utf-8', errors='ignore') or ''
                                    j = json.loads(t) if t.strip() else dict()
                                    ci = str(j.get('ci_run_dir') or '')
                                    if ci: break
                                except Exception:
                                    pass
                    klog = os.path.join(ci, 'kics', 'kics.log')
                    if ci and os.path.exists(klog):
                        rawb = Path(klog).read_bytes()
                        if len(rawb) > 65536: rawb = rawb[-65536:]
                        raw = rawb.decode('utf-8', errors='ignore').replace(chr(13), NL)
                        hb = ''
                        for ln in reversed(raw.splitlines()):
                            if '][HB]' in ln and '[KICS_V' in ln:
                                hb = ln.strip(); break
                        ls2 = [x for x in raw.splitlines() if x.strip()]
                        tail = NL.join(ls2[-30:])
                        if hb and (hb not in tail): tail = hb + NL + tail
                        d['kics_tail'] = tail[-4096:]
                    else:
                        d['kics_tail'] = '[kics_tail] ci=' + str(ci) + ' exists=' + str(os.path.exists(klog))
            except Exception:
                pass
            # === END VSP_KICS_TAIL_PRE_RETURN_V3_DEBUG ===
            # === VSP_UIREQ_PERSIST_AND_RESOLVE_CI_V1 ===
            # Persist UIREQ state under out_ci/uireq_v1 and try resolve ci_run_dir from state (commercial)
            try:
                import os, json, glob, datetime
                rid = req_id if 'req_id' in locals() else (request_id if 'request_id' in locals() else None)
                if not rid:
                    rid = (locals().get("REQ_ID") or locals().get("RID") or None)
                udir = os.path.join(os.path.dirname(__file__), "out_ci", "uireq_v1")
                os.makedirs(udir, exist_ok=True)
                spath = os.path.join(udir, f"{rid}.json") if rid else None
            
                # choose dst dict (prefer resp/out)
                dst = None
                if isinstance(locals().get("resp", None), dict): dst = resp
                if isinstance(locals().get("out", None), dict): dst = out
            
                if isinstance(dst, dict):
                    # normalize empties
                    if dst.get("stage_name") is None: dst["stage_name"] = ""
                    if dst.get("ci_run_dir") is None: dst["ci_run_dir"] = ""
            
                    # resolve ci_run_dir if empty: read previously persisted state or fallback to latest CI dir
                    if (not dst.get("ci_run_dir")) and spath and os.path.isfile(spath):
                        try:
                            j = json.load(open(spath, "r", encoding="utf-8"))
                            dst["ci_run_dir"] = j.get("ci_run_dir") or j.get("ci") or dst.get("ci_run_dir") or ""
                        except Exception:
                            pass
            
                    if (not dst.get("ci_run_dir")):
                        # fallback guess: newest CI dir under /home/test/Data/SECURITY-10-10-v4/out_ci
                        cand = sorted(glob.glob("/home/test/Data/SECURITY-10-10-v4/out_ci/VSP_CI_*"), reverse=True)
                        if cand:
                            dst["ci_run_dir"] = cand[0]
            
                    # persist state every call (so UI has stable mapping)
                    if spath:
                        payload = dict(dst)
                        payload["ts_persist"] = datetime.datetime.utcnow().isoformat() + "Z"
                        try:
                            open(spath, "w", encoding="utf-8").write(json.dumps(payload, ensure_ascii=False, indent=2))
                        except Exception:
                            pass
            except Exception:
                pass

            return jsonify(_out), 200

        try:
            app.register_blueprint(bp_vsp_run_api_v1)
            print("[VSP_RUN_API_FALLBACK] mounted /api/vsp/run_v1 + /api/vsp/run_status_v1/*")
        except Exception as e:
            print("[VSP_RUN_API_FALLBACK] mount failed:", repr(e))
# === END VSP_RUN_API_FALLBACK_V1 ===

# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===
def _vsp_try_inject_kics_into_payload(payload: dict):
    try:
        ci_dir = payload.get("ci_run_dir") or payload.get("ci_run_dir_abs") or payload.get("run_dir") or payload.get("ci_dir") or ""
        ks = _vsp_read_kics_summary(ci_dir) if ci_dir else None
        if isinstance(ks, dict):
            payload["kics_verdict"] = ks.get("verdict","") or ""
            payload["kics_counts"]  = ks.get("counts",{}) if isinstance(ks.get("counts"), dict) else {}
            payload["kics_total"]   = int(ks.get("total",0) or 0)
        else:
            payload.setdefault("kics_verdict","")
            payload.setdefault("kics_counts",{})
            payload.setdefault("kics_total",0)
    except Exception:
        payload.setdefault("kics_verdict","")
        payload.setdefault("kics_counts",{})
        payload.setdefault("kics_total",0)

def vsp_after_request_inject_kics_summary_v31(resp):
    try:
        path = getattr(_req, "path", "") or ""
        if not (path.startswith("/api/vsp/run_status_v1/") or path.startswith("/api/vsp/run_status_v2/")):
            return resp

        # read JSON body
        raw = resp.get_data(as_text=True) or ""
        s = raw.lstrip()
        if not s:
            return resp
        c0 = s[0]
        if c0 not in ("{", "["):
            return resp

        import json as _json
        payload = _json.loads(s)
        if not isinstance(payload, dict):
            return resp

        _vsp_try_inject_kics_into_payload(payload)

        resp.set_data(_json.dumps(payload, ensure_ascii=False))
        resp.headers["Content-Type"] = "application/json"
        return resp
    except Exception:
        # === VSP_STATUS_GUARD_INJECT_CI_KICS_V10 ===
        try:
            import json as _json
            from pathlib import Path as _Path
            _resp = resp
            _path = (_req.path or '')
            if _path.startswith('/api/vsp/run_status_v1/') or _path.startswith('/api/vsp/run_status_v2/'):
                _rid = (_path.rsplit('/', 1)[-1] or '').split('?', 1)[0].strip()
                _rid_norm = _rid[4:].strip() if _rid.startswith('RUN_') else _rid
                _obj = None
                try:
                    _obj = _resp.get_json(silent=True)
                except Exception:
                    _obj = None
                if not isinstance(_obj, dict):
                    try:
                        _raw = (_resp.get_data(as_text=True) or '').lstrip()
                        if _raw.startswith('{'):
                            _obj = _json.loads(_raw)
                    except Exception:
                        _obj = None
                if isinstance(_obj, dict):
                    _obj.setdefault('ci_run_dir', None)
                    _obj.setdefault('kics_verdict', '')
                    _obj.setdefault('kics_total', 0)
                    _obj.setdefault('kics_counts', {})
                    _ci = (_obj.get('ci_run_dir') or '').strip()
                    if (not _ci) and _rid_norm:
                        try:
                            _ci = _vsp_guess_ci_run_dir_from_rid_v33(_rid_norm) or ''
                        except Exception:
                            _ci = ''
                        if _ci:
                            _obj['ci_run_dir'] = _ci
                    _ci = (_obj.get('ci_run_dir') or '').strip()
                    if _ci:
                        _ks = _Path(_ci) / 'kics' / 'kics_summary.json'
                        if _ks.is_file():
                            try:
                                _jj = _json.loads(_ks.read_text(encoding='utf-8', errors='ignore') or '{}')
                                if isinstance(_jj, dict):
                                    _obj['kics_verdict'] = str(_jj.get('verdict') or _obj.get('kics_verdict') or '')
                                    try:
                                        _obj['kics_total'] = int(_jj.get('total') or _obj.get('kics_total') or 0)
                                    except Exception:
                                        pass
                                    _cc = _jj.get('counts')
                                    if isinstance(_cc, dict):
                                        _obj['kics_counts'] = _cc
                            except Exception:
                                pass
                    try:
                        _resp.set_data(_json.dumps(_obj, ensure_ascii=False))
                        _resp.mimetype = 'application/json'
                    except Exception:
                        pass
        except Exception:
            pass
        return resp
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===


# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===
try:
    app.after_request(vsp_after_request_inject_kics_summary_v31)
except Exception:
    pass
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V31 ===


# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V33 ===
def _vsp_guess_ci_run_dir_from_rid_v33(rid_norm):
    # === VSP_GUESS_CI_RUN_DIR_V33_REWRITE_CLEAN_V4 ===
    """Return absolute CI run dir for a RID (RUN_* / VSP_CI_* / VSP_UIREQ_*).
    - If RID is UIREQ: read persisted state under ui/out_ci/uireq_v1/<RID>.json
    - Else: find */out_ci/<RID> under /home/test/Data with shallow globs
    """
    try:
        import json
        from pathlib import Path
        rn = str(rid_norm or '').strip()
        if not rn:
            return None
        if rn.startswith("RUN_"):
            rn = rn[4:].strip()

        # UIREQ -> read persisted state (if exists)
        if rn.startswith("VSP_UIREQ_"):
            st = Path("/home/test/Data/SECURITY_BUNDLE/ui/ui/out_ci/uireq_v1") / (rn + ".json")
            if st.is_file():
                try:
                    obj = json.loads(st.read_text(encoding="utf-8", errors="ignore") or "{}")
                    if isinstance(obj, dict):
                        ci = (obj.get("ci_run_dir") or obj.get("ci_dir") or obj.get("ci") or "").strip()
                        if ci and Path(ci).is_dir():
                            return str(Path(ci))
                except Exception:
                    pass

        base = Path("/home/test/Data")

        # very fast common hit: /home/test/Data/*/out_ci/<rn>
        try:
            for c in base.glob("*/out_ci/" + rn):
                if c.is_dir():
                    return str(c)
        except Exception:
            pass

        # shallow fallbacks (no ** recursion)
        pats = (
            "*/*/out_ci/" + rn,
            "*/*/*/out_ci/" + rn,
            "*/*/*/*/out_ci/" + rn,
        )
        for pat in pats:
            try:
                for c in base.glob(pat):
                    if c.is_dir():
                        return str(c)
            except Exception:
                continue

        return None
    except Exception:
        return None
def _vsp_try_inject_kics_into_payload_v33(payload: dict, req_path: str):
    try:
        ci_dir = payload.get("ci_run_dir") or payload.get("ci_run_dir_abs") or payload.get("run_dir") or payload.get("ci_dir") or ""
        if not ci_dir:
            rid = payload.get("rid_norm") or payload.get("run_id") or payload.get("request_id") or ""
            if not rid and req_path:
                rid = req_path.rsplit("/", 1)[-1]
            g = _vsp_guess_ci_run_dir_from_rid_v33(rid)
            if g:
                payload["ci_run_dir"] = g
                ci_dir = g

        ks = _vsp_read_kics_summary(ci_dir) if ci_dir else None
        if isinstance(ks, dict):
            payload["kics_verdict"] = ks.get("verdict","") or ""
            payload["kics_counts"]  = ks.get("counts",{}) if isinstance(ks.get("counts"), dict) else {}
            payload["kics_total"]   = int(ks.get("total",0) or 0)
        else:
            payload.setdefault("kics_verdict","")
            payload.setdefault("kics_counts",{})
            payload.setdefault("kics_total",0)
    except Exception:
        payload.setdefault("kics_verdict","")
        payload.setdefault("kics_counts",{})
        payload.setdefault("kics_total",0)

def vsp_after_request_inject_kics_summary_v33(resp):
    try:
        path = getattr(_req, "path", "") or ""
        if not (path.startswith("/api/vsp/run_status_v1/") or path.startswith("/api/vsp/run_status_v2/")):
            return resp

        import json as _json
        raw = resp.get_data(as_text=True) or ""
        s = raw.lstrip()
        if not s:
            return resp
        c0 = s[0]
        # FIX: correct JSON detection
        if c0 not in ("{","["):
            return resp

        payload = _json.loads(s)
        if not isinstance(payload, dict):
            return resp

        _vsp_try_inject_kics_into_payload_v33(payload, path)

        resp.set_data(_json.dumps(payload, ensure_ascii=False))
        resp.headers["Content-Type"] = "application/json"
        return resp
    except Exception:
        return resp
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V33 ===


# === VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V33 ===
try:
    app.after_request(vsp_after_request_inject_kics_summary_v33)
except Exception:
    pass
# === END VSP_AFTER_REQUEST_INJECT_KICS_SUMMARY_V33 ===







def _vsp_preempt_statusv2_postprocess_v1(payload):
    """Postprocess run_status_v2 JSON payload inside WSGI preempt to avoid nulls and inject tool summaries."""
    # === VSP_PREEMPT_STATUSV2_POSTPROCESS_HELPER_V1 ===
    try:
        import json
        from pathlib import Path as _P

        if not isinstance(payload, dict):
            return payload

        # never return nulls for commercial contract keys
        if payload.get("overall_verdict", None) is None:
            payload["overall_verdict"] = ""

        payload.setdefault("has_gitleaks", False)
        payload.setdefault("gitleaks_verdict", "")
        payload.setdefault("gitleaks_total", 0)
        payload.setdefault("gitleaks_counts", {})

        ci = payload.get("ci_run_dir") or payload.get("ci_dir") or payload.get("ci") or ""
        ci = str(ci).strip()
        if not ci:
            return payload

        # local helper read json
        def _readj(fp):
            try:
                if fp and fp.exists():
                    return json.loads(fp.read_text(encoding="utf-8", errors="ignore") or "{}")
            except Exception:
                return None
            return None

        # inject gitleaks from CI
        gsum = _readj(_P(ci) / "gitleaks" / "gitleaks_summary.json") or _readj(_P(ci) / "gitleaks_summary.json")
        if isinstance(gsum, dict):
            payload["has_gitleaks"] = True
            payload["gitleaks_verdict"] = str(gsum.get("verdict") or "")
            try:
                payload["gitleaks_total"] = int(gsum.get("total") or 0)
            except Exception:
                payload.setdefault('gitleaks_total', 0)
            cc = gsum.get("counts")
            payload["gitleaks_counts"] = cc if isinstance(cc, dict) else {}

        # if run_gate exists, take overall from it (single source of truth)
        gate = _readj(_P(ci) / "run_gate_summary.json")
        if isinstance(gate, dict):
            payload["overall_verdict"] = str(gate.get("overall") or payload.get("overall_verdict") or "")

        return payload
    except Exception:
        return payload


# === VSP_EXPORT_OVERRIDE_VIEWFUNC_V2 ===
import os, glob

try:
    pass
except Exception:
    # in case imports are structured differently
    pass

def _vsp_norm_rid(rid: str) -> str:
    rid = (rid or "").strip()
    return rid[4:] if rid.startswith("RUN_") else rid

def _vsp_ci_root() -> str:
    return os.environ.get("VSP_CI_OUT_ROOT") or "/home/test/Data/SECURITY-10-10-v4/out_ci"

def _vsp_resolve_ci_dir(rid: str) -> str:
    rn = _vsp_norm_rid(rid)
    base = _vsp_ci_root()
    cand = os.path.join(base, rn)
    if os.path.isdir(cand):
        return cand
    # fallback: try match substring in latest dirs
    gl = sorted(glob.glob(os.path.join(base, "VSP_CI_*")), reverse=True)
    for d in gl:
        if rn in os.path.basename(d):
            return d
    return ""

def _pick_newest(patterns):
    best = ""
    best_m = -1.0
    for pat in patterns:
        for f in glob.glob(pat):
            try:
                m = os.path.getmtime(f)
            except Exception:
                continue
            if m > best_m:
                best_m = m
                best = f
    return best

def _pick_pdf(ci_dir: str) -> str:
    return _pick_newest([
        os.path.join(ci_dir, "reports", "*.pdf"),
        os.path.join(ci_dir, "*.pdf"),
    ])

def _pick_html(ci_dir: str) -> str:
    return _pick_newest([
        os.path.join(ci_dir, "reports", "*.html"),
        os.path.join(ci_dir, "*.html"),
    ])

def _pick_zip(ci_dir: str) -> str:
    return _pick_newest([
        os.path.join(ci_dir, "reports", "*.zip"),
        os.path.join(ci_dir, "*.zip"),
    ])


    ### [COMMERCIAL] EXPORT_FORCEFS_V2 ###

    # NOTE: this is the REAL handler bound to /api/vsp/run_export_v3/<rid>

    import os, json, csv, glob, shutil, zipfile, tempfile, subprocess

    from datetime import datetime, timezone


    fmt = (request.args.get('fmt') or 'zip').lower()

    rid_str = str(rid)

    rid_norm = rid_str.replace('RUN_', '')


    def nowz():

        return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')


    def find_run_dir(rid_norm: str):

        cands = []

        cands += glob.glob('/home/test/Data/SECURITY-*/out_ci/' + rid_norm)

        cands += glob.glob('/home/test/Data/*/out_ci/' + rid_norm)

        for x in cands:

            try:


                if os.path.isdir(x):

                    return x

            except Exception:

                pass

        return None


    def ensure_report(run_dir: str):

        report_dir = os.path.join(run_dir, 'report')

        os.makedirs(report_dir, exist_ok=True)


        # copy unified json into report/ if needed

        src_json = os.path.join(run_dir, 'findings_unified.json')

        dst_json = os.path.join(report_dir, 'findings_unified.json')

        if os.path.isfile(src_json) and (not os.path.isfile(dst_json)):

            try:


                shutil.copy2(src_json, dst_json)

            except Exception:

                pass


        # build csv if missing

        dst_csv = os.path.join(report_dir, 'findings_unified.csv')

        if (not os.path.isfile(dst_csv)) and os.path.isfile(dst_json):

            cols = ['tool','severity','title','file','line','cwe','fingerprint']

            try:


                d = json.load(open(dst_json,'r',encoding='utf-8'))

                items = d.get('items') or []

                with open(dst_csv,'w',encoding='utf-8',newline='') as f:

                    w = csv.DictWriter(f, fieldnames=cols)

                    w.writeheader()

                    for it in items:

                        cwe = it.get('cwe')

                        if isinstance(cwe, list):

                            cwe = ','.join(cwe)

                        w.writerow({

                            'tool': it.get('tool'),

                            'severity': (it.get('severity_norm') or it.get('severity')),

                            'title': it.get('title'),

                            'file': it.get('file'),

                            'line': it.get('line'),

                            'cwe': cwe,

                            'fingerprint': it.get('fingerprint'),

                        })

            except Exception:

                pass


        # build minimal html if missing

        html_path = os.path.join(report_dir, 'export_v3.html')

        if not (os.path.isfile(html_path) and os.path.getsize(html_path) > 0):

            total = 0

            sev = {}

            try:


                if os.path.isfile(dst_json):

                    d = json.load(open(dst_json,'r',encoding='utf-8'))

                    items = d.get('items') or []

                    total = len(items)

                    for it in items:

                        k = (it.get('severity_norm') or it.get('severity') or 'INFO').upper()

                        sev[k] = sev.get(k, 0) + 1

            except Exception:

                pass

            rows = ''

            for k,v in sorted(sev.items(), key=lambda kv:(-kv[1], kv[0])):

                rows += f"<tr><td>{k}</td><td>{v}</td></tr>\n"

            if not rows:

                rows = "<tr><td colspan='2'>(none)</td></tr>"

            html = (

                "<!doctype html><html><head><meta charset='utf-8'/>"

                "<title>VSP Export</title>"

                "<style>body{font-family:Arial;padding:24px} table{border-collapse:collapse;width:100%}"

                "td,th{border:1px solid #eee;padding:6px 8px}</style></head><body>"

                f"<h2>VSP Export v3</h2><p>Generated: {nowz()}</p><p><b>Total findings:</b> {total}</p>"

                "<h3>By severity</h3><table><tr><th>Severity</th><th>Count</th></tr>" + rows + "</table>"

                "</body></html>"

            )

            try:


                with open(html_path,'w',encoding='utf-8') as f:

                    f.write(html)

            except Exception:

                pass


        return report_dir


    def zip_dir(report_dir: str):

        tmp = tempfile.NamedTemporaryFile(prefix='vsp_export_', suffix='.zip', delete=False)

        tmp.close()

        with zipfile.ZipFile(tmp.name, 'w', compression=zipfile.ZIP_DEFLATED) as z:

            for root, _, files in os.walk(report_dir):

                for fn in files:

                    ap = os.path.join(root, fn)

                    rel = os.path.relpath(ap, report_dir)

                    z.write(ap, arcname=rel)

        return tmp.name


    def pdf_from_html(html_file: str, timeout_sec: int = 180):

        exe = shutil.which('wkhtmltopdf')

        if not exe:

            return None, 'wkhtmltopdf_missing'

        tmp = tempfile.NamedTemporaryFile(prefix='vsp_export_', suffix='.pdf', delete=False)

        tmp.close()

        try:


            subprocess.run([exe, '--quiet', html_file, tmp.name], timeout=timeout_sec, check=True)

            if os.path.isfile(tmp.name) and os.path.getsize(tmp.name) > 0:

                return tmp.name, None

            return None, 'wkhtmltopdf_empty_output'

        except Exception as ex:

            return None, 'wkhtmltopdf_failed:' + type(ex).__name__


    # PROBE proves this handler is active

    if (request.args.get('probe') or '') == '1':

        resp = jsonify({'ok': True, 'probe': 'EXPORT_FORCEFS_V2', 'rid_norm': rid_norm, 'fmt': fmt})

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '1'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp


    run_dir = find_run_dir(rid_norm)

    if (not run_dir) or (not os.path.isdir(run_dir)):

        resp = jsonify({'ok': False, 'error': 'RUN_DIR_NOT_FOUND', 'rid_norm': rid_norm})

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '0'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp, 404


    report_dir = ensure_report(run_dir)

    html_file = os.path.join(report_dir, 'export_v3.html')


    if fmt == 'html':

        resp = send_file(html_file, mimetype='text/html', as_attachment=True, download_name=rid_norm + '.html')

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '1'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp


    if fmt == 'zip':

        zpath = zip_dir(report_dir)

        resp = send_file(zpath, mimetype='application/zip', as_attachment=True, download_name=rid_norm + '.zip')

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '1'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp


    if fmt == 'pdf':

        pdf_path, err = pdf_from_html(html_file, timeout_sec=180)

        if pdf_path:

            resp = send_file(pdf_path, mimetype='application/pdf', as_attachment=True, download_name=rid_norm + '.pdf')

            resp.headers['X-VSP-EXPORT-AVAILABLE'] = '1'

            resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

            return resp

        resp = jsonify({'ok': False, 'error': 'PDF_EXPORT_FAILED', 'detail': err})

        resp.headers['X-VSP-EXPORT-AVAILABLE'] = '0'

        resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

        return resp, 500


    resp = jsonify({'ok': False, 'error': 'BAD_FMT', 'fmt': fmt, 'allowed': ['html','zip','pdf']})

    resp.headers['X-VSP-EXPORT-AVAILABLE'] = '0'

    resp.headers['X-VSP-EXPORT-MODE'] = 'EXPORT_FORCEFS_V2'

    return resp, 400

### [COMMERCIAL] EXPORT_FORCE_BIND_V4 ###
def _vsp_export_v3_forcefs_impl(rid=None):
    """
    Commercial force-fs export handler for:
      - /api/vsp/run_export_v3/<rid>?fmt=html|zip|pdf
      - /api/vsp/run_export_v3?rid=...&fmt=...
    """
    import os, json, csv, glob, shutil, zipfile, tempfile, subprocess
    from datetime import datetime, timezone

    fmt = (request.args.get("fmt") or "zip").lower()
    probe = (request.args.get("probe") or "") == "1"

    # allow rid via query for the non-<rid> route
    if (rid is None) or (str(rid).lower() in ("", "none", "null")):
        rid = request.args.get("rid") or request.args.get("run_id") or request.args.get("id")
        # VSP_RUN_FILE_ALLOW_SUMMARY_P0_V1
        # Normalize SUMMARY.txt to reports/SUMMARY.txt (commercial: keep whitelist tight, but allow this common artifact)
        try:
            _n = (name or "").strip()
            if _n in ("SUMMARY.txt","SHA256SUMS.txt"):
                name = "reports/SUMMARY.txt", "reports/SHA256SUMS.txt"
        except Exception:
            pass


    rid_str = "" if rid is None else str(rid)
    rid_norm = rid_str.replace("RUN_", "")

    def nowz():
        return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00","Z")

    def resolve_run_dir_by_status_v2(rid_value: str):
        try:
            fn = current_app.view_functions.get("api_vsp_run_status_v2_winlast_v6")
            if not fn:
                return None
            r = fn(rid_value)
            payload = None
            if isinstance(r, tuple) and len(r) >= 1 and hasattr(r[0], "get_json"):
                payload = r[0].get_json(silent=True)
            elif hasattr(r, "get_json"):
                payload = r.get_json(silent=True)
            if isinstance(payload, dict):
                rd = payload.get("ci_run_dir") or payload.get("ci") or payload.get("run_dir")
                if isinstance(rd, str) and rd and os.path.isdir(rd):
                    return rd
        except Exception:
            return None
        return None

    def resolve_run_dir_fallback(rid_norm_value: str):
        cands = []
        cands += glob.glob("/home/test/Data/SECURITY-*/out_ci/" + rid_norm_value)
        cands += glob.glob("/home/test/Data/*/out_ci/" + rid_norm_value)
        for x in cands:
            try:
                if os.path.isdir(x):
                    return x
            except Exception:
                pass
        return None

    def ensure_report(run_dir: str):
        report_dir = os.path.join(run_dir, "report")
        os.makedirs(report_dir, exist_ok=True)

        src_json = os.path.join(run_dir, "findings_unified.json")
        dst_json = os.path.join(report_dir, "findings_unified.json")
        if os.path.isfile(src_json) and (not os.path.isfile(dst_json)):
            try:
                shutil.copy2(src_json, dst_json)
            except Exception:
                pass

        dst_csv = os.path.join(report_dir, "findings_unified.csv")
        if (not os.path.isfile(dst_csv)) and os.path.isfile(dst_json):
            cols = ["tool","severity","title","file","line","cwe","fingerprint"]
            try:
                d = json.load(open(dst_json, "r", encoding="utf-8"))
                items = d.get("items") or []
                with open(dst_csv, "w", encoding="utf-8", newline="") as f:
                    w = csv.DictWriter(f, fieldnames=cols)
                    w.writeheader()
                    for it in items:
                        cwe = it.get("cwe")
                        if isinstance(cwe, list):
                            cwe = ",".join(cwe)
                        w.writerow({
                            "tool": it.get("tool"),
                            "severity": (it.get("severity_norm") or it.get("severity")),
                            "title": it.get("title"),
                            "file": it.get("file"),
                            "line": it.get("line"),
                            "cwe": cwe,
                            "fingerprint": it.get("fingerprint"),
                        })
            except Exception:
                pass

        html_path = os.path.join(report_dir, "export_v3.html")
        if not (os.path.isfile(html_path) and os.path.getsize(html_path) > 0):
            total = 0
            sev = {}
            try:
                if os.path.isfile(dst_json):
                    d = json.load(open(dst_json, "r", encoding="utf-8"))
                    items = d.get("items") or []
                    total = len(items)
                    for it in items:
                        k = (it.get("severity_norm") or it.get("severity") or "INFO").upper()
                        sev[k] = sev.get(k, 0) + 1
            except Exception:
                pass
            rows = ""
            for k,v in sorted(sev.items(), key=lambda kv:(-kv[1], kv[0])):
                rows += f"<tr><td>{k}</td><td>{v}</td></tr>\n"
            if not rows:
                rows = "<tr><td colspan='2'>(none)</td></tr>"
            html = (
                "<!doctype html><html><head><meta charset='utf-8'/>"
                "<title>VSP Export</title>"
                "<style>body{font-family:Arial;padding:24px} table{border-collapse:collapse;width:100%}"
                "td,th{border:1px solid #eee;padding:6px 8px}</style></head><body>"
                f"<h2>VSP Export v3</h2><p>Generated: {nowz()}</p><p><b>Total findings:</b> {total}</p>"
                "<h3>By severity</h3><table><tr><th>Severity</th><th>Count</th></tr>" + rows + "</table>"
                "</body></html>"
            )
            try:
                with open(html_path, "w", encoding="utf-8") as f:
                    f.write(html)
            except Exception:
                pass

        return report_dir

    def zip_dir(report_dir: str):
        tmp = tempfile.NamedTemporaryFile(prefix="vsp_export_", suffix=".zip", delete=False)
        tmp.close()
        with zipfile.ZipFile(tmp.name, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(report_dir):
                for fn in files:
                    ap = os.path.join(root, fn)
                    rel = os.path.relpath(ap, report_dir)
                    z.write(ap, arcname=rel)
        return tmp.name

    def pdf_from_html(html_file: str, timeout_sec: int = 180):
        exe = shutil.which("wkhtmltopdf")
        if not exe:
            return None, "wkhtmltopdf_missing"
        tmp = tempfile.NamedTemporaryFile(prefix="vsp_export_", suffix=".pdf", delete=False)
        tmp.close()
        try:
            subprocess.run([exe, "--quiet", html_file, tmp.name], timeout=timeout_sec, check=True)
            if os.path.isfile(tmp.name) and os.path.getsize(tmp.name) > 0:
                return tmp.name, None
            return None, "wkhtmltopdf_empty_output"
        except Exception as ex:
            return None, "wkhtmltopdf_failed:" + type(ex).__name__

    # PROBE must always prove handler is active
    if probe:
        resp = jsonify({
            "ok": True,
            "probe": "EXPORT_FORCE_BIND_V4",
            "rid": rid_str,
            "rid_norm": rid_norm,
            "fmt": fmt
        })
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp

    if not rid_str:
        resp = jsonify({"ok": False, "error": "RID_MISSING"})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp, 400

    run_dir = resolve_run_dir_by_status_v2(rid_str) or resolve_run_dir_fallback(rid_norm)
    if (not run_dir) or (not os.path.isdir(run_dir)):
        resp = jsonify({"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid_str, "rid_norm": rid_norm})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp, 404

    report_dir = ensure_report(run_dir)
    html_file = os.path.join(report_dir, "export_v3.html")

    if fmt == "html":
        resp = send_file(html_file, mimetype="text/html", as_attachment=True, download_name=rid_norm + ".html")
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp

    if fmt == "zip":
        zpath = zip_dir(report_dir)
        resp = send_file(zpath, mimetype="application/zip", as_attachment=True, download_name=rid_norm + ".zip")
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp

    if fmt == "pdf":
        pdf_path, err = pdf_from_html(html_file, timeout_sec=180)
        if pdf_path:
            resp = send_file(pdf_path, mimetype="application/pdf", as_attachment=True, download_name=rid_norm + ".pdf")
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
            resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
            return resp
        resp = jsonify({"ok": False, "error": "PDF_EXPORT_FAILED", "detail": err})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
        return resp, 500

    resp = jsonify({"ok": False, "error": "BAD_FMT", "fmt": fmt, "allowed": ["html","zip","pdf"]})
    resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
    resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V4"
    return resp, 400


# Bind hard to endpoints (avoid route confusion)
try:
    if "api_vsp_run_export_v3_force_fs" in app.view_functions:
        app.view_functions["api_vsp_run_export_v3_force_fs"] = _vsp_export_v3_forcefs_impl
    if "vsp_run_export_v3" in app.view_functions:
        app.view_functions["vsp_run_export_v3"] = _vsp_export_v3_forcefs_impl
except Exception:
    pass

### [COMMERCIAL] EXPORT_FORCE_BIND_V5 ###
def _vsp_export_v3_forcefs_impl_v5(rid=None):
    import os, json, csv, glob, shutil, zipfile, tempfile, subprocess
    from datetime import datetime, timezone

    fmt = (request.args.get("fmt") or "zip").lower()
    probe = (request.args.get("probe") or "") == "1"

    # allow rid via query for the non-<rid> route
    if (rid is None) or (str(rid).lower() in ("", "none", "null")):
        rid = request.args.get("rid") or request.args.get("run_id") or request.args.get("id")

    rid_str = "" if rid is None else str(rid)
    rid_norm = rid_str.replace("RUN_", "")

    def nowz():
        return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00","Z")

    def resolve_run_dir_by_status_v2(rid_value: str):
        try:
            fn = current_app.view_functions.get("api_vsp_run_status_v2_winlast_v6")
            if not fn:
                return None
            r = fn(rid_value)
            payload = None
            if isinstance(r, tuple) and len(r) >= 1 and hasattr(r[0], "get_json"):
                payload = r[0].get_json(silent=True)
            elif hasattr(r, "get_json"):
                payload = r.get_json(silent=True)
            if isinstance(payload, dict):
                rd = payload.get("ci_run_dir") or payload.get("ci") or payload.get("run_dir")
                if isinstance(rd, str) and rd and os.path.isdir(rd):
                    return rd
        except Exception:
            return None
        return None

    def resolve_run_dir_fallback(rid_norm_value: str):
        cands = []
        cands += glob.glob("/home/test/Data/SECURITY-*/out_ci/" + rid_norm_value)
        cands += glob.glob("/home/test/Data/*/out_ci/" + rid_norm_value)
        for x in cands:
            try:
                if os.path.isdir(x):
                    return x
            except Exception:
                pass
        return None

    def ensure_report(run_dir: str):
        report_dir = os.path.join(run_dir, "report")
        os.makedirs(report_dir, exist_ok=True)

        src_json = os.path.join(run_dir, "findings_unified.json")
        dst_json = os.path.join(report_dir, "findings_unified.json")
        if os.path.isfile(src_json) and (not os.path.isfile(dst_json)):
            try:
                shutil.copy2(src_json, dst_json)
            except Exception:
                pass

        dst_csv = os.path.join(report_dir, "findings_unified.csv")
        if (not os.path.isfile(dst_csv)) and os.path.isfile(dst_json):
            cols = ["tool","severity","title","file","line","cwe","fingerprint"]
            try:
                d = json.load(open(dst_json, "r", encoding="utf-8"))
                items = d.get("items") or []
                with open(dst_csv, "w", encoding="utf-8", newline="") as f:
                    w = csv.DictWriter(f, fieldnames=cols)
                    w.writeheader()
                    for it in items:
                        cwe = it.get("cwe")
                        if isinstance(cwe, list):
                            cwe = ",".join(cwe)
                        w.writerow({
                            "tool": it.get("tool"),
                            "severity": (it.get("severity_norm") or it.get("severity")),
                            "title": it.get("title"),
                            "file": it.get("file"),
                            "line": it.get("line"),
                            "cwe": cwe,
                            "fingerprint": it.get("fingerprint"),
                        })
            except Exception:
                pass

        html_path = os.path.join(report_dir, "export_v3.html")
        if not (os.path.isfile(html_path) and os.path.getsize(html_path) > 0):
            total = 0
            sev = {}
            try:
                if os.path.isfile(dst_json):
                    d = json.load(open(dst_json, "r", encoding="utf-8"))
                    items = d.get("items") or []
                    total = len(items)
                    for it in items:
                        k = (it.get("severity_norm") or it.get("severity") or "INFO").upper()
                        sev[k] = sev.get(k, 0) + 1
            except Exception:
                pass
            rows = ""
            for k,v in sorted(sev.items(), key=lambda kv:(-kv[1], kv[0])):
                rows += f"<tr><td>{k}</td><td>{v}</td></tr>\n"
            if not rows:
                rows = "<tr><td colspan='2'>(none)</td></tr>"
            html = (
                "<!doctype html><html><head><meta charset='utf-8'/>"
                "<title>VSP Export</title>"
                "<style>body{font-family:Arial;padding:24px} table{border-collapse:collapse;width:100%}"
                "td,th{border:1px solid #eee;padding:6px 8px}</style></head><body>"
                f"<h2>VSP Export v3</h2><p>Generated: {nowz()}</p><p><b>Total findings:</b> {total}</p>"
                "<h3>By severity</h3><table><tr><th>Severity</th><th>Count</th></tr>" + rows + "</table>"
                "</body></html>"
            )
            try:
                with open(html_path, "w", encoding="utf-8") as f:
                    f.write(html)
            except Exception:
                pass

        return report_dir

    def zip_dir(report_dir: str):
        tmp = tempfile.NamedTemporaryFile(prefix="vsp_export_", suffix=".zip", delete=False)
        tmp.close()
        with zipfile.ZipFile(tmp.name, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(report_dir):
                for fn in files:
                    ap = os.path.join(root, fn)
                    rel = os.path.relpath(ap, report_dir)
                    z.write(ap, arcname=rel)
        return tmp.name

    def pdf_from_html(html_file: str, timeout_sec: int = 180):
        exe = shutil.which("wkhtmltopdf")
        if not exe:
            return None, "wkhtmltopdf_missing"
        tmp = tempfile.NamedTemporaryFile(prefix="vsp_export_", suffix=".pdf", delete=False)
        tmp.close()
        try:
            subprocess.run([exe, "--quiet", html_file, tmp.name], timeout=timeout_sec, check=True)
            if os.path.isfile(tmp.name) and os.path.getsize(tmp.name) > 0:
                return tmp.name, None
            return None, "wkhtmltopdf_empty_output"
        except Exception as ex:
            return None, "wkhtmltopdf_failed:" + type(ex).__name__

    if probe:
        resp = jsonify({"ok": True, "probe": "EXPORT_FORCE_BIND_V5", "rid": rid_str, "rid_norm": rid_norm, "fmt": fmt})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp

    if not rid_str:
        resp = jsonify({"ok": False, "error": "RID_MISSING"})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp, 400

    run_dir = resolve_run_dir_by_status_v2(rid_str) or resolve_run_dir_fallback(rid_norm)
    if (not run_dir) or (not os.path.isdir(run_dir)):
        resp = jsonify({"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid_str, "rid_norm": rid_norm})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp, 404

    report_dir = ensure_report(run_dir)
    html_file = os.path.join(report_dir, "export_v3.html")

    if fmt == "html":
        resp = send_file(html_file, mimetype="text/html", as_attachment=True, download_name=rid_norm + ".html")
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp

    if fmt == "zip":
        zpath = zip_dir(report_dir)
        resp = send_file(zpath, mimetype="application/zip", as_attachment=True, download_name=rid_norm + ".zip")
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp

    if fmt == "pdf":
        pdf_path, err = pdf_from_html(html_file, timeout_sec=180)
        if pdf_path:
            resp = send_file(pdf_path, mimetype="application/pdf", as_attachment=True, download_name=rid_norm + ".pdf")
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
            resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
            return resp
        resp = jsonify({"ok": False, "error": "PDF_EXPORT_FAILED", "detail": err})
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
        resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
        return resp, 500

    resp = jsonify({"ok": False, "error": "BAD_FMT", "fmt": fmt, "allowed": ["html","zip","pdf"]})
    resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
    resp.headers["X-VSP-EXPORT-MODE"] = "EXPORT_FORCE_BIND_V5"
    return resp, 400


# Rebind on every first request (guaranteed to happen AFTER all wrappers are installed)
try:
    @app.before_request
    def _vsp_export_v3_force_bind_v5_before_request():
        if app.config.get("VSP_EXPORT_FORCE_BIND_V5_DONE"):
            return None
        changed = []
        for rule in list(app.url_map.iter_rules()):
            if "run_export_v3" in (rule.rule or ""):
                ep = rule.endpoint
                if ep in app.view_functions:
                    app.view_functions[ep] = _vsp_export_v3_forcefs_impl_v5
                    changed.append((rule.rule, ep))
        app.config["VSP_EXPORT_FORCE_BIND_V5_DONE"] = True
        if changed:
            print("[VSP_EXPORT_FORCE_BIND_V5] rebound:", changed[:10])
        return None
except Exception as _e:
    pass

# === VSP_EXPORT_V3_COMMERCIAL_REAL_V1 BEGIN ===
# 목적: /api/vsp/run_export_v3/<rid> must return REAL html/zip/pdf (not JSON fallback)
try:
    pass
except Exception:
    request = None
    jsonify = None
    make_response = None
    send_file = None
    render_template = None

import os, json, tempfile, zipfile, shutil, subprocess
from pathlib import Path
from datetime import datetime, timezone

def _vsp_export_v3_resolve_run_dir_real_v1(rid: str):
    """
    Accepts:
      - RUN_VSP_CI_YYYYmmdd_HHMMSS  -> maps to VSP_CI_YYYYmmdd_HHMMSS
      - VSP_CI_YYYYmmdd_HHMMSS      -> direct
    Tries common parents to avoid slow rglob.
    """
    if not rid or rid == "null":
        return None, "rid_null"

    base = rid.strip()
    if base.startswith("RUN_"):
        base = base[len("RUN_"):]
    # now base usually == VSP_CI_...

    parents = [
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out",
    ]
    for parent in parents:
        p = Path(parent)
        if not p.exists():
            continue
        cand = p / base
        if cand.exists() and cand.is_dir():
            return str(cand), f"direct:{cand}"

    # last-resort bounded search (still cheap): check two well-known roots
    roots = ["/home/test/Data/SECURITY_BUNDLE", "/home/test/Data/SECURITY-10-10-v4"]
    for root in roots:
        r = Path(root)
        if not r.exists():
            continue
        for sub in (r / "out_ci" / base, r / "out" / base):
            if sub.exists() and sub.is_dir():
                return str(sub), f"glob:{sub}"

    return None, "not_found"

def _vsp_export_v3_pick_html_real_v1(run_dir: str):
    """
    Prefer an existing CIO html in report/.
    Otherwise generate a minimal HTML from findings_unified.json.
    """
    report = Path(run_dir) / "report"
    for name in [
        "vsp_run_report_cio_v3.html",
        "vsp_run_report_cio_v2.html",
        "run_report.html",
        "export_v3.html",
        "index.html",
        "report.html",
    ]:
        f = report / name
        if f.exists() and f.is_file() and f.stat().st_size > 200:
            return f, f"file:{name}"

    fu = Path(run_dir) / "findings_unified.json"
    total = None
    bysev = {}
    if fu.exists() and fu.is_file():
        try:
            data = json.load(open(fu, "r", encoding="utf-8"))
            total = data.get("total")
            # fast-ish severity count (cap to avoid worst-case memory)
            for it in (data.get("items") or [])[:200000]:
                sev = (it.get("severity") or "TRACE").upper()
                bysev[sev] = bysev.get(sev, 0) + 1
        except Exception:
            pass

    now = datetime.now(timezone.utc).isoformat()
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>VSP Export {run_dir}</title></head>
<body style="font-family: Arial, sans-serif">
<h1>VSP Export (Generated)</h1>
<p><b>run_dir</b>: {run_dir}</p>
<p><b>generated_at_utc</b>: {now}</p>
<h2>Findings summary</h2>
<p><b>total</b>: {total}</p>
<pre>{json.dumps(bysev, indent=2, ensure_ascii=False)}</pre>
</body></html>"""
    return html, "generated:inline"

def _vsp_export_v3_send_html_real_v1(html_or_path, mode: str):
    if isinstance(html_or_path, Path):
        body = html_or_path.read_text(encoding="utf-8", errors="replace")
        resp = make_response(body, 200)
        resp.headers["Content-Type"] = "text/html; charset=utf-8"
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = mode
        return resp
    else:
        resp = make_response(html_or_path, 200)
        resp.headers["Content-Type"] = "text/html; charset=utf-8"
        resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
        resp.headers["X-VSP-EXPORT-MODE"] = mode
        return resp

def _vsp_export_v3_make_zip_real_v1(run_dir: str, rid: str):
    tmp = tempfile.NamedTemporaryFile(prefix=f"vsp_export_{rid}_", suffix=".zip", delete=False)
    tmp.close()
    zpath = Path(tmp.name)
    base = Path(run_dir)

    with zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for rel in ["report", "findings_unified.json", "findings_unified.csv", "SUMMARY.txt", "SHA256SUMS.txt", "runner.log"]:
            p = base / rel
            if not p.exists():
                continue
            if p.is_dir():
                for f in p.rglob("*"):
                    if f.is_file():
                        zf.write(f, arcname=str(f.relative_to(base)))
            else:
                zf.write(p, arcname=str(p.relative_to(base)))
    return zpath

def _vsp_export_v3_make_pdf_real_v1(run_dir: str, rid: str):
    wk = shutil.which("wkhtmltopdf")
    if not wk:
        return None, {"ok": False, "error": "WKHTMLTOPDF_NOT_FOUND"}

    report_dir = Path(run_dir) / "report"
    report_dir.mkdir(parents=True, exist_ok=True)

    html_or_path, mode = _vsp_export_v3_pick_html_real_v1(run_dir)
    if isinstance(html_or_path, Path):
        html_path = html_or_path
    else:
        html_path = report_dir / "export_v3_generated.html"
        html_path.write_text(html_or_path, encoding="utf-8")

    tmp = tempfile.NamedTemporaryFile(prefix=f"vsp_export_{rid}_", suffix=".pdf", delete=False)
    tmp.close()
    pdf_path = Path(tmp.name)

    cmd = [wk, "--quiet", str(html_path), str(pdf_path)]
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0 or (not pdf_path.exists()) or pdf_path.stat().st_size < 1000:
        return None, {
            "ok": False,
            "error": "WKHTMLTOPDF_FAILED",
            "rc": r.returncode,
            "stderr_tail": (r.stderr or "")[-2000:],
        }
    return pdf_path, {"ok": True, "mode": mode, "wkhtmltopdf": wk}

# Register routes SAFELY (avoid AssertionError if reloaded)
try:
    _app = app  # app must exist in vsp_demo_app.py
except Exception:
    _app = None

if _app is not None:
    # /vsp4 page (optional fix) - only if not already registered
    if "vsp4_page_commercial_real_v1" not in _app.view_functions:
        def vsp4_page_commercial_real_v1():
            # render your 4-tabs commercial template if exists; else simple message
            try:
                return render_template("vsp_5tabs_enterprise_v2.html")
            except Exception:
                return "VSP4 template not found", 404
        _app.add_url_rule("/vsp4", endpoint="vsp4_page_commercial_real_v1", view_func=vsp4_page_commercial_real_v1, methods=["GET"])

    # export v3 route
    if "api_vsp_run_export_v3_commercial_real_v1" not in _app.view_functions:
        def api_vsp_run_export_v3_commercial_real_v1(rid):
            from flask import request as _vsp_req
            _rid = (_vsp_req.args.get('rid') or _vsp_req.args.get('run_id') or _vsp_req.args.get('RID') or 'RUN')
            fmt = (request.args.get("fmt") or "").lower().strip()
            probe = request.args.get("probe")

            run_dir, how = _vsp_export_v3_resolve_run_dir_real_v1(rid)
            # --- VSP_P1_EXPORT_RUNDIR_FALLBACK_IN_HANDLER_V1 ---
            # v2: request.args based (stable)
            try:
                from flask import request as _vsp_req
                __rid = (_vsp_req.args.get('rid') or _vsp_req.args.get('run_id') or _vsp_req.args.get('RID') or '').strip()
                __rid_norm = ''
                try:
                    import re as __re
                    mm = __re.search(r'(\d{8}_\d{6})', __rid)
                    __rid_norm = (mm.group(1) if mm else '').strip()
                except Exception:
                    __rid_norm = ''
                __cand = _vsp__resolve_run_dir_for_export(__rid, __rid_norm)
                if __cand:
                    run_dir = __cand
                    ci_dir  = __cand
                    RUN_DIR = __cand
            except Exception:
                pass
            # --- /VSP_P1_EXPORT_RUNDIR_FALLBACK_IN_HANDLER_V1 ---

            # --- VSP_P1_EXPORT_RUNDIR_HANDLER_RESOLVED_FALLBACK_V3 (var=run_dir) ---
            try:
                __rid = str(rid).strip() if rid is not None else ''
                __rid_norm = ''
                try:
                    import re as __re
                    mm = __re.search(r'(\d{8}_\d{6})', __rid)
                    __rid_norm = (mm.group(1) if mm else '').strip()
                except Exception:
                    __rid_norm = ''
                __cand = _vsp__resolve_run_dir_for_export(__rid, __rid_norm)
                if __cand:
                    run_dir = __cand
                    try:
                        how = 'fs_fallback'
                    except Exception:
                        pass
            except Exception:
                pass
            # --- /VSP_P1_EXPORT_RUNDIR_HANDLER_RESOLVED_FALLBACK_V3 ---
            if not run_dir:
                payload = {"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid, "resolved": None, "how": how}
                return jsonify(payload), 404

            # probe = advertise capability
            if probe:
                wk = shutil.which("wkhtmltopdf")
                return jsonify({
                    "ok": True,
                    "rid": rid,
                    "run_dir": run_dir,
                    "how": how,
                    "available": {"html": True, "zip": True, "pdf": bool(wk)},
                    "wkhtmltopdf": wk
                }), 200

            if fmt in ("", "html"):
                html_or_path, mode = _vsp_export_v3_pick_html_real_v1(run_dir)
                return _vsp_export_v3_send_html_real_v1(html_or_path, mode)

            if fmt == "zip":
                zpath = _vsp_export_v3_make_zip_real_v1(run_dir, rid)
                resp = send_file(str(zpath), mimetype="application/zip", as_attachment=True, download_name=f"{rid}.zip")
                resp = _vsp__rewrite_cd(resp, _rid)
                return _vsp__rewrite_cd(resp, _rid)
            if fmt == "pdf":
                pdf_path, meta = _vsp_export_v3_make_pdf_real_v1(run_dir, rid)
                if not pdf_path:
                    return jsonify({"ok": False, "rid": rid, **meta}), 501 if meta.get("error") == "WKHTMLTOPDF_NOT_FOUND" else 500
                resp = send_file(str(pdf_path), mimetype="application/pdf", as_attachment=True, download_name=f"{rid}.pdf")
                resp = _vsp__rewrite_cd(resp, _rid)
                return _vsp__rewrite_cd(resp, _rid)
            return jsonify({"ok": False, "error": "BAD_FMT", "fmt": fmt, "rid": rid}), 400

        _app.add_url_rule(
            "/api/vsp/run_export_v3/<rid>",
            endpoint="api_vsp_run_export_v3_commercial_real_v1",
            view_func=api_vsp_run_export_v3_commercial_real_v1,
            methods=["GET"],
        )

# === VSP_EXPORT_V3_COMMERCIAL_REAL_V1 END ===

# === VSP_RULE_OVERRIDES_API_V1 BEGIN ===
import json
from pathlib import Path

_RULE_OVR_PATH = Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/vsp_rule_overrides_v1.json")

def _rule_ovr_default():
    return {
        "meta": {"version": "v1", "updated_at": None},
        "overrides": []
    }

@app.route("/api/vsp/rule_overrides_v1", methods=["GET"])
def api_vsp_rule_overrides_get_v1():
    if _RULE_OVR_PATH.exists():
        try:
            return jsonify(json.load(open(_RULE_OVR_PATH, "r", encoding="utf-8")))
        except Exception:
            return jsonify(_rule_ovr_default()), 200
    return jsonify(_rule_ovr_default()), 200

@app.route("/api/vsp/rule_overrides_v1", methods=["POST"])
def api_vsp_rule_overrides_post_v1():
    data = request.get_json(silent=True) or _rule_ovr_default()
    try:
        data.setdefault("meta", {})
        data["meta"]["updated_at"] = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
        _RULE_OVR_PATH.parent.mkdir(parents=True, exist_ok=True)
        json.dump(data, open(_RULE_OVR_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        return jsonify({"ok": True, "file": str(_RULE_OVR_PATH)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500
# === VSP_RULE_OVERRIDES_API_V1 END ===


### VSP_RULE_OVERRIDES_APPLY_PREVIEW_V1 ###
# NOTE: commercial P0: preview/apply rule overrides -> effective findings
import os, json, urllib.request, urllib.error
from datetime import datetime, timezone

try:
    from vsp_rule_overrides_apply_v1 import load_overrides_file, apply_overrides, summarize
except Exception as _e:
    load_overrides_file = None
    apply_overrides = None
    summarize = None

def _vsp_http_get_json_local(path, timeout_sec=1.2):
    # P0 commercial: NEVER hang worker by self-calling local HTTP. Fail-soft.
    import json, urllib.request
    url = 'http://127.0.0.1:8910' + str(path)
    try:
        req = urllib.request.Request(url, headers={'Accept': 'application/json'})
        with urllib.request.urlopen(req, timeout=float(timeout_sec)) as resp:
            raw = resp.read().decode('utf-8', 'ignore')
            return json.loads(raw) if raw else {}
    except Exception as e:
        return {'_degraded': True, '_error': str(e), '_path': str(path), '_url': url}

def _vsp_get_run_dir_from_statusv2(rid: str):
    st = _vsp_http_get_json_local(f"/api/vsp/run_status_v2/{rid}")
    rd = st.get("ci_run_dir") or st.get("ci") or st.get("run_dir")
    return rd, st

def _vsp_get_overrides_path():
    return os.environ.get("VSP_RULE_OVERRIDES_FILE") or "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/vsp_rule_overrides_v1.json"

def _vsp_load_findings_items(run_dir: str):
    f = os.path.join(run_dir, "findings_unified.json")
    if not os.path.isfile(f):
        return None, f, "findings_unified_not_found"
    try:
        doc = json.load(open(f, "r", encoding="utf-8"))
    except Exception:
        return None, f, "findings_unified_read_failed"
    items = doc.get("items") if isinstance(doc, dict) else None
    if not isinstance(items, list):
        return None, f, "findings_unified_bad_format"
    return items, f, None

def _vsp_apply_overrides_preview(rid: str):
    if not (load_overrides_file and apply_overrides and summarize):
        return {"ok":False, "error":"apply_module_missing"}

    run_dir, st = _vsp_get_run_dir_from_statusv2(rid)
    if not run_dir:
        return {"ok":False, "rid":rid, "error":"run_dir_not_resolved", "statusv2": st}

    items, fpath, err = _vsp_load_findings_items(run_dir)
    if err:
        return {"ok":False, "rid":rid, "run_dir":run_dir, "error":err, "file":fpath}

    ov_path = _vsp_get_overrides_path()
    meta, ovs = load_overrides_file(ov_path)
    now = datetime.now(timezone.utc)
    eff, delta = apply_overrides(items, ovs, now=now)

    out = {
        "ok": True,
        "rid": rid,
        "run_dir": run_dir,
        "overrides": meta,
        "delta": delta,
        "raw_summary": summarize(items),
        "effective_summary": summarize(eff),
        # return effective items for datasource
        "items": eff,
        "raw_total": len(items),
        "effective_total": len(eff),
    }
    return out

# GET: preview effective findings (raw+effective+delta)
if "api_vsp_findings_effective_v1" not in getattr(app, "view_functions", {}):
    @app.get("/api/vsp/findings_effective_v1/<rid>")
    def api_vsp_findings_effective_v1(rid):
        limit = int(request.args.get("limit", "200"))
        offset = int(request.args.get("offset", "0"))
        view = (request.args.get("view") or "effective").lower()  # effective|raw
        out = _vsp_apply_overrides_preview(rid)
        if not out.get("ok"):
            return jsonify(out), 200

        # optional raw view (no overrides)
        if view == "raw":
            run_dir = out.get("run_dir")
            items, fpath, err = _vsp_load_findings_items(run_dir)
            if err:
                return jsonify({"ok":False,"rid":rid,"error":err,"file":fpath}), 200
            out["items"] = items

        items = out.get("items") or []
        out["items_n"] = len(items)
        out["items"] = items[offset: offset+limit]
        out["offset"] = offset
        out["limit"] = limit
        out["view"] = view
        return jsonify(out), 200

# POST: apply and persist findings_effective.json to RUN_DIR
if "api_vsp_rule_overrides_apply_v1" not in getattr(app, "view_functions", {}):
    @app.post("/api/vsp/rule_overrides_apply_v1/<rid>")
    def api_vsp_rule_overrides_apply_v1(rid):
        out = _vsp_apply_overrides_preview(rid)
        if not out.get("ok"):
            return jsonify(out), 200
        run_dir = out.get("run_dir")
        f_out = os.path.join(run_dir, "findings_effective.json")
        try:
            with open(f_out, "w", encoding="utf-8") as f:
                json.dump(out, f, ensure_ascii=False, indent=2)
            out["persisted_file"] = f_out
            out["persist_ok"] = True
        except Exception as e:
            out["persist_ok"] = False
            out["persist_error"] = str(e)
        return jsonify(out), 200





### VSP_RUNS_INDEX_ALIAS_FALLBACK_V1 ###
# Backward-compat: some UI/scripts still call this; map it to filesystem scan.
if "api_vsp_runs_index_v3_fs_resolved" not in getattr(app, "view_functions", {}):
    @app.get("/api/vsp/runs_index_v3_fs_resolved")
    def api_vsp_runs_index_v3_fs_resolved():
        try:
            limit = int(request.args.get("limit","20"))
        except Exception:
            limit = 20
        items = _vsp_scan_latest_run_dirs(limit=limit)
        return jsonify({
          "ok": True,
          "items": items,
          "items_n": len(items),
          "source": "FS_FALLBACK_V1"
        }), 200

### VSP_RID_FALLBACK_FS_V1 ###
# commercial: RID fallback by filesystem when runs_index/dashboard returns null
import glob, os, json

def _vsp_scan_latest_run_dirs(limit=50):
    pats = [
      "/home/test/Data/*/out_ci/VSP_CI_*",
      "/home/test/Data/*/out/VSP_CI_*",
      "/home/test/Data/SECURITY_BUNDLE/out_ci/VSP_CI_*",
      "/home/test/Data/SECURITY-10-10-v4/out_ci/VSP_CI_*",
    ]
    cands=[]
    for pat in pats:
        for d in glob.glob(pat):
            if os.path.isfile(os.path.join(d, "findings_unified.json")):
                try:
                    cands.append((os.path.getmtime(d), d))
                except Exception:
                    pass
    cands.sort(reverse=True)
    out=[]
    for _, d in cands[:max(1, int(limit))]:
        out.append({
          "rid": os.path.basename(d),
          "ci_run_dir": d,
          "has_findings_unified": True,
        })
    return out

@app.get("/api/vsp/runs_index_safe_v1")
def api_vsp_runs_index_safe_v1():
    limit = int(request.args.get("limit","20"))
    items = _vsp_scan_latest_run_dirs(limit=limit)
    return jsonify({"ok": True, "items": items, "items_n": len(items)}), 200

@app.get("/api/vsp/latest_rid_v1")
def api_vsp_latest_rid_v1():
    items = _vsp_scan_latest_run_dirs(limit=1)
    if not items:
        return jsonify({"ok": False, "error":"no_runs_found"}), 200
    item = items[0] if items else {}
    rid = item.get("run_id") or item.get("rid") or item.get("id") or item.get("run")
    ci = item.get("ci_run_dir") or item.get("run_dir") or item.get("dir")
    return jsonify({"ok": True, "rid": rid, "ci_run_dir": ci}), 200



### VSP_ARTIFACTS_API_V1 ###
# Artifacts API: list + serve selected artifacts (commercial safe whitelist)
import os, glob
try:
    pass
except Exception:
    send_file = None
    abort = None

def _vsp_resolve_run_dir_by_rid(rid: str):
    if not rid:
        return None
    pats = [
      f"/home/test/Data/*/out_ci/{rid}",
      f"/home/test/Data/*/out/{rid}",
      f"/home/test/Data/SECURITY-10-10-v4/out_ci/{rid}",
      f"/home/test/Data/SECURITY_BUNDLE/out_ci/{rid}",
    ]
    for pat in pats:
        for d in glob.glob(pat.format(rid=rid)):
            if os.path.isdir(d):
                return d
    return None

# whitelist relative paths we are allowed to expose
_VSP_ART_WHITELIST = [
  "kics/kics.log",
  "kics/kics.json",
  "kics/kics_summary.json",
  "codeql/codeql.log",
  "codeql/codeql.sarif",
  "trivy/trivy.json",
  "trivy/trivy.json.err",
  "semgrep/semgrep.json",
  "gitleaks/gitleaks.json",
  "bandit/bandit.json",
  "syft/syft.json",
  "grype/grype.json",
  "SUMMARY.txt", "SHA256SUMS.txt",
  "findings_unified.json",
  "findings_effective.json",
]

@app.get("/api/vsp/run_artifacts_index_v1/<rid>")
def api_vsp_run_artifacts_index_v1(rid):
    rd = _vsp_resolve_run_dir_by_rid(rid)
    if not rd:
        return jsonify({"ok": False, "rid": rid, "error": "run_dir_not_found", "items": []}), 200
    items = []
    for rel in _VSP_ART_WHITELIST:
        ap = os.path.join(rd, rel)
        if os.path.isfile(ap):
            try:
                sz = os.path.getsize(ap)
            except Exception:
                sz = None
            items.append({
              "name": rel,
              "rel": rel,
              "size": sz,
              "url": f"/api/vsp/run_artifact_raw_v1/{rid}?rel=" + rel
            })
    return jsonify({"ok": True, "rid": rid, "run_dir": rd, "items": items, "items_n": len(items)}), 200

@app.get("/api/vsp/run_artifact_raw_v1/<rid>")
def api_vsp_run_artifact_raw_v1(rid):
    if send_file is None:
        return jsonify({"ok": False, "rid": rid, "error": "send_file_unavailable"}), 500
    rel = request.args.get("rel","")
    if rel not in _VSP_ART_WHITELIST:
        return jsonify({"ok": False, "rid": rid, "error": "rel_not_allowed", "rel": rel}), 403
    rd = _vsp_resolve_run_dir_by_rid(rid)
    if not rd:
        return jsonify({"ok": False, "rid": rid, "error": "run_dir_not_found"}), 404
    ap = os.path.join(rd, rel)
    if not os.path.isfile(ap):
        return jsonify({"ok": False, "rid": rid, "error": "file_not_found", "rel": rel}), 404
    # serve inline (browser can open .log/.json)
    return send_file(ap, as_attachment=False)



### VSP_REPORT_CIO_V1 ###
import os

def _vsp_run_dir_report_cio_v1(rid: str):
    # Try reuse existing resolver if already defined by other patches
    for nm in ("_vsp_resolve_run_dir_by_rid", "_vsp_resolve_run_dir_by_rid_v1", "_vsp_resolve_run_dir_by_rid_v2"):
        fn = globals().get(nm)
        if callable(fn):
            rd = fn(rid)
            if rd: return rd
    # Fallback minimal glob resolver
    import glob
    pats = [
      f"/home/test/Data/*/out_ci/{rid}",
      f"/home/test/Data/*/out/{rid}",
      f"/home/test/Data/SECURITY-10-10-v4/out_ci/{rid}",
      f"/home/test/Data/SECURITY_BUNDLE/out_ci/{rid}",
    ]
    for pat in pats:
        for d in glob.glob(pat):
            if os.path.isdir(d):
                return d
    return None




### VSP_REPORT_CIO_DUALROUTE_V1 ###
import os, glob

def _vsp_resolve_run_dir_report_v1(rid: str):
    # prefer existing resolver if present
    for nm in ("_vsp_resolve_run_dir_by_rid", "_vsp_resolve_run_dir_by_rid_v1", "_vsp_resolve_run_dir_by_rid_v2", "_vsp_resolve_run_dir_by_rid_v3"):
        fn = globals().get(nm)
        if callable(fn):
            try:
                rd = fn(rid)
                if rd: return rd
            except Exception:
                pass
    # fallback glob
    pats = [
      f"/home/test/Data/*/out_ci/{rid}",
      f"/home/test/Data/*/out/{rid}",
      f"/home/test/Data/SECURITY-10-10-v4/out_ci/{rid}",
      f"/home/test/Data/SECURITY_BUNDLE/out_ci/{rid}",
    ]
    for pat in pats:
        for d in glob.glob(pat):
            if os.path.isdir(d):
                return d
    return None

def _vsp_build_report_ctx_v1(rid: str, rd: str):
    import traceback, importlib.util
    ui_root = os.path.abspath(os.path.dirname(__file__))
    tpl_path = os.path.join(ui_root, "report_templates", "vsp_report_cio_v1.html")
    if not os.path.isfile(tpl_path):
        return None, {"ok": False, "rid": rid, "error": "template_missing", "template": tpl_path}, 500

    try:
        mod_path = os.path.join(ui_root, "bin", "vsp_build_report_cio_v1.py")
        if not os.path.isfile(mod_path):
            return None, {"ok": False, "rid": rid, "error": "renderer_missing", "path": mod_path}, 500
        spec = importlib.util.spec_from_file_location("vsp_build_report_cio_v1", mod_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore
        if not hasattr(mod, "build"):
            return None, {"ok": False, "rid": rid, "error": "renderer_no_build"}, 500
        ctx = mod.build(rd, ui_root)
        return (ctx, {"ok": True, "rid": rid}, 200)
    except Exception as e:
        return None, {"ok": False, "rid": rid, "error": "renderer_failed", "detail": str(e), "trace": traceback.format_exc()[-2000:]}, 500

@app.get("/api/vsp/run_report_cio_v1/<rid>")
def api_vsp_run_report_cio_v1(rid):
    # API returns JSON only (commercial-safe). HTML is served by /vsp/report_cio_v1/<rid>.
    rd = _vsp_resolve_run_dir_report_v1(rid)
    if not rd:
        return jsonify({"ok": False, "rid": rid, "error": "run_dir_not_found"}), 200

    ctx, meta, code = _vsp_build_report_ctx_v1(rid, rd)
    if not ctx:
        return jsonify(meta), code

    return jsonify({
        "ok": True,
        "rid": rid,
        "run_dir": rd,
        "url": f"/vsp/report_cio_v1/{rid}",
        "note": "Open url for HTML report. API returns JSON by design."
    }), 200

@app.get("/vsp/report_cio_v1/<rid>")
def vsp_report_cio_v1(rid):
    # HTML report route (safe render with debug)
    import traceback

    rd = _vsp_resolve_run_dir_report_v1(rid)
    if not rd:
        return Response(f"<h3>run_dir_not_found</h3><pre>{rid}</pre>", status=404, content_type="text/html; charset=utf-8")

    ctx, meta, code = _vsp_build_report_ctx_v1(rid, rd)
    if not ctx:
        return Response(f"<h3>report_failed</h3><pre>{meta}</pre>", status=500, content_type="text/html; charset=utf-8")

    ui_root = os.path.abspath(os.path.dirname(__file__))
    tpl_path = os.path.join(ui_root, "report_templates", "vsp_report_cio_v1.html")

    try:
        if not isinstance(ctx, dict):
            raise TypeError(f"ctx must be dict, got {type(ctx)}")
        tpl = open(tpl_path, "r", encoding="utf-8").read()
        # VSP_REPORT_CTX_RENAME_V1
        # avoid Flask arg-name collision: ctx['source'] conflicts with render_template_string(source,...)
        if isinstance(ctx, dict) and 'source' in ctx:
            ctx['source_id'] = ctx.get('source')
            ctx.pop('source', None)

        html = render_template_string(tpl, **ctx)
    except Exception as e:
        err = {
            "ok": False,
            "rid": rid,
            "error": "template_render_failed",
            "detail": str(e),
            "template": tpl_path,
            "ctx_keys_sample": sorted(list(ctx.keys()))[:80],
            "trace_tail": traceback.format_exc()[-2500:],
        }
        return Response(f"<h3>template_render_failed</h3><pre>{err}</pre>", status=500, content_type="text/html; charset=utf-8")

    # archive
    try:
        rep_dir = os.path.join(rd, "reports")
        os.makedirs(rep_dir, exist_ok=True)
        with open(os.path.join(rep_dir, "vsp_run_report_cio_v1.html"), "w", encoding="utf-8") as f:
            f.write(html)
    except Exception:
        pass

    return Response(html, status=200, content_type="text/html; charset=utf-8")


@app.get("/api/vsp/run_status_v2/<rid>")
def api_vsp_run_status_v2_contract_p1_v1(rid):
    # try to call existing v1/v2 provider if available, else return contract only
    base = {}
    try:
        # attempt reuse: if there is an internal helper, keep as-is
        # attempt reuse: if there is an internal helper, keep as-is
        pass
    except Exception:
        base = {}
    run_dir = base.get("ci_run_dir") or base.get("ci") or _vsp_find_run_dir(rid)
    if run_dir:
        base["ci_run_dir"] = run_dir
    base["run_id"] = rid

    total = _vsp_findings_total(run_dir) if run_dir else None
    if isinstance(total, int):
        base["total_findings"] = total
        base["has_findings"] = True if total > 0 else False

    dn, da = _vsp_degraded_info(run_dir) if run_dir else (None, None)
    if isinstance(dn, int):
        base["degraded_n"] = dn
    if isinstance(da, bool):
        base["degraded_any"] = da

    base.setdefault("ok", True)
    base.setdefault("status", base.get("status") or "UNKNOWN")
    return jsonify(base)


# === VSP_EXPORT_CIO_ROUTE_SAFE_V2_BEGIN ===
import os
import subprocess

@app.get("/api/vsp/run_export_cio_v1/<rid>")
def api_vsp_run_export_cio_v1(rid):
    fmt = (request.args.get("fmt") or "html").lower().strip()
    rebuild = (request.args.get("rebuild") or "0").strip() == "1"
    if fmt != "html":
        return jsonify({"ok": False, "error": "only_html_supported", "fmt": fmt, "rid": rid}), 400

    builder = "/home/test/Data/SECURITY_BUNDLE/bin/vsp_build_cio_report_v1.py"
    if not os.path.isfile(builder):
        return jsonify({"ok": False, "error": "missing_builder", "builder": builder, "rid": rid}), 500

    # Always build (or rebuild) deterministically
    cmd = ["python3", "-u", builder, rid]
    if rebuild:
        cmd = ["python3", "-u", builder, rid]

    r = subprocess.run(cmd, capture_output=True, text=True)
    # builder prints output path on success; parse it
    out_html = None
    for line in (r.stdout or "").splitlines():
        if "wrote " in line and "vsp_run_report_cio_v1.html" in line:
            out_html = line.split("wrote ",1)[1].split(" (run_dir=",1)[0].strip()
            break

    if not out_html or not os.path.isfile(out_html):
        # fallback: search common roots
        roots = [
          "/home/test/Data/SECURITY-10-10-v4/out_ci",
          "/home/test/Data/SECURITY_BUNDLE/out_ci",
          "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        ]
        for rr in roots:
            cand = os.path.join(rr, rid, "reports", "vsp_run_report_cio_v1.html")
            if os.path.isfile(cand):
                out_html = cand
                break

    if not out_html or not os.path.isfile(out_html):
        return jsonify({
            "ok": False,
            "error": "cio_report_not_found",
            "rid": rid,
            "builder_stdout": (r.stdout or "")[-2000:],
            "builder_stderr": (r.stderr or "")[-2000:],
            "rc": r.returncode
        }), 404

    return send_file(out_html, mimetype="text/html")
# === VSP_EXPORT_CIO_ROUTE_SAFE_V2_END ===


# === VSP_EXPORT_CIO_ROUTE_SAFE_V2B_BEGIN ===
import os
import subprocess

@app.get("/api/vsp/run_export_cio_v2/<rid>")
def api_vsp_run_export_cio_v2(rid):
    fmt = (request.args.get("fmt") or "html").lower().strip()

    # VSP_CIO_V2_PDF_DEGRADED_SAFE_BEGIN
    # commercial: PDF export for CIO v2 (resolve run_dir + auto-build HTML if missing)
    if fmt == "pdf":
        try:
            rid_local = rid

            # Resolve RUN_DIR by probing common roots (fast + accurate)
            run_dir_local = None
            for rr in [
                "/home/test/Data/SECURITY-10-10-v4/out_ci",
                "/home/test/Data/SECURITY_BUNDLE/out_ci",
                "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
                "/home/test/Data",
            ]:
                cand = Path(rr) / rid_local
                if cand.is_dir():
                    run_dir_local = str(cand)
                    break

            html_path_local = Path(run_dir_local) / "reports" / "vsp_run_report_cio_v2.html" if run_dir_local else None

            # Auto-build HTML if missing
            if not html_path_local or not html_path_local.is_file():
                builder = "/home/test/Data/SECURITY_BUNDLE/bin/vsp_cio_upgrade_v2_one_shot.sh"
                if Path(builder).is_file():
                    subprocess.run(["bash", builder, rid_local], timeout=60, check=False)
                if not html_path_local or not html_path_local.is_file():
                    resp = jsonify({
                        "ok": False,
                        "degraded": True,
                        "reason": "cio_v2_html_missing",
                        "hint": "run vsp_cio_upgrade_v2_one_shot.sh to build reports/vsp_run_report_cio_v2.html",
                        "run_dir": run_dir_local
                    })
                    resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
                    return resp, 200

            wk = shutil.which("wkhtmltopdf")
            if not wk:
                resp = jsonify({
                    "ok": False,
                    "degraded": True,
                    "reason": "wkhtmltopdf_missing",
                    "hint": "apt install wkhtmltopdf (or keep HTML export)"
                })
                resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
                return resp, 200

            pdf_path = str(html_path_local.with_suffix(".pdf"))
            need_build = (not Path(pdf_path).is_file()) or (Path(pdf_path).stat().st_mtime < html_path_local.stat().st_mtime)
            if need_build:
                subprocess.run([wk, "--quiet", str(html_path_local), pdf_path], timeout=90, check=True)

            resp = send_file(pdf_path, mimetype="application/pdf", as_attachment=False, download_name=Path(pdf_path).name)
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "1"
            return resp
        except subprocess.TimeoutExpired:
            resp = jsonify({"ok": False, "degraded": True, "reason": "wkhtmltopdf_timeout"})
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
            return resp, 200
        except Exception as e:
            resp = jsonify({"ok": False, "degraded": True, "reason": "wkhtmltopdf_error", "error": str(e)})
            resp.headers["X-VSP-EXPORT-AVAILABLE"] = "0"
            return resp, 200
    # VSP_CIO_V2_PDF_DEGRADED_SAFE_END



    rebuild = (request.args.get("rebuild") or "0").strip() == "1"
    if fmt != "html":
        return jsonify({"ok": False, "error": "only_html_supported", "fmt": fmt, "rid": rid}), 400

    builder = "/home/test/Data/SECURITY_BUNDLE/bin/vsp_build_cio_report_v2.py"
    if not os.path.isfile(builder):
        return jsonify({"ok": False, "error": "missing_builder", "builder": builder, "rid": rid}), 500

    r = subprocess.run(["python3","-u",builder,rid], capture_output=True, text=True)

    out_html = None
    for line in (r.stdout or "").splitlines():
        if "wrote " in line and "vsp_run_report_cio_v2.html" in line:
            out_html = line.split("wrote ",1)[1].split(" (run_dir=",1)[0].strip()
            break

    if rebuild or (not out_html) or (not os.path.isfile(out_html)):
        # fallback search common roots
        roots = [
          "/home/test/Data/SECURITY-10-10-v4/out_ci",
          "/home/test/Data/SECURITY_BUNDLE/out_ci",
          "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        ]
        for rr in roots:
            cand = os.path.join(rr, rid, "reports", "vsp_run_report_cio_v2.html")
            if os.path.isfile(cand):
                out_html = cand
                break

    if not out_html or not os.path.isfile(out_html):
        return jsonify({
            "ok": False,
            "error": "cio_report_not_found",
            "rid": rid,
            "builder_stdout": (r.stdout or "")[-2000:],
            "builder_stderr": (r.stderr or "")[-2000:],
            "rc": r.returncode
        }), 404

    return send_file(out_html, mimetype="text/html")
# === VSP_EXPORT_CIO_ROUTE_SAFE_V2B_END ===




### VSP_ROUTE_P_TS_204_BEGIN
@app.route("/P<token>")
def vsp_p_ts_204(token):
    # Some UI patches may accidentally embed /PYYMMDD_HHMMSS as a resource.
    # Return 204 to avoid console 404 noise; otherwise keep 404.
    try:
        if re.fullmatch(r"\d{6}_\d{6}", token or ""):
            return ("", 204, {
                "Cache-Control": "no-store",
                "Pragma": "no-cache",
            })
    except Exception:
        pass
    return ({"ok": False, "reason": "not_found"}, 404)
### VSP_ROUTE_P_TS_204_END


# === VSP_FINDINGS_UNIFIED_API_P1_V1 (commercial) ===
# Purpose:
#   - Resolve ci_run_dir from RID reliably (prefer persisted uireq state JSON)
#   - Read findings_unified.json and return paging + filters for Data Source tab
import os, json, glob

VSP_UIREQ_DIR = os.environ.get("VSP_UIREQ_DIR", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/uireq_v1")
VSP_CI_OUT_GLOB = os.environ.get("VSP_CI_OUT_GLOB", "/home/test/Data/**/out_ci/VSP_CI_*")

_SEV_W = {"CRITICAL": 50, "HIGH": 40, "MEDIUM": 30, "LOW": 20, "INFO": 10, "TRACE": 0}
def _sev_w(x): return _SEV_W.get((x or "").upper(), -1)

def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _resolve_run_dir_from_rid(rid: str):
    # 1) persisted UIREQ state (most reliable in VSP commercial flow)
    st = _read_json(os.path.join(VSP_UIREQ_DIR, f"{rid}.json")) or {}
    for k in ("ci_run_dir", "ci_run_dir_resolved", "run_dir", "RUN_DIR"):
        v = st.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip(), "uireq_state"

    # 2) scan known out_ci pattern as fallback (best-effort)
    cands = []
    for d in glob.glob(VSP_CI_OUT_GLOB, recursive=True):
        if rid in os.path.basename(d) or rid in d:
            cands.append(d)
    cands = sorted(set(cands), key=lambda x: os.path.getmtime(x) if os.path.exists(x) else 0, reverse=True)
    if cands:
        return cands[0], "scan_out_ci"

    return None, "not_found"

def _apply_filters(items, q=None, sev=None, tool=None, cwe=None, fileq=None):
    q = (q or "").strip().lower()
    fileq = (fileq or "").strip().lower()
    sev = (sev or "").strip().upper()
    tool = (tool or "").strip().lower()
    cwe = (cwe or "").strip().upper()

    out = []
    for it in items or []:
        t = (it.get("title") or "")
        f = (it.get("file") or "")
        sv = (it.get("severity") or "").upper()
        tl = (it.get("tool") or "").lower()
        c = ""
        cw = it.get("cwe")
        if isinstance(cw, list) and cw:
            c = str(cw[0] or "").upper()
        elif isinstance(cw, str):
            c = cw.upper()

        if sev and sv != sev: 
            continue
        if tool and tool != tl:
            continue
        if cwe and cwe != c:
            continue
        if fileq and fileq not in f.lower():
            continue
        if q:
            hay = (t + " " + f + " " + (it.get("id") or "")).lower()
            if q not in hay:
                continue
        out.append(it)
    return out

@app.get("/api/vsp/findings_unified_v1/<rid>")
def api_vsp_findings_unified_v1(rid):
    page = int(request.args.get("page", "1") or "1")
    limit = int(request.args.get("limit", "50") or "50")
    page = 1 if page < 1 else page
    limit = 50 if limit < 1 else (500 if limit > 500 else limit)

    q = request.args.get("q")
    sev = request.args.get("sev")
    tool = request.args.get("tool")
    cwe = request.args.get("cwe")
    fileq = request.args.get("file")

    run_dir, src = _resolve_run_dir_from_rid(rid)
    if not run_dir:
        return jsonify({
            "ok": False,
            "warning": "run_dir_not_found",
            "rid": rid,
            "resolve_source": src,
            "total": 0,
            "items": [],
        }), 200

    fp = os.path.join(run_dir, "findings_unified.json")
    data = _read_json(fp)
    if not data or not isinstance(data, dict):
        return jsonify({
            "ok": True,
            "warning": "findings_unified_not_found_or_bad",
            "rid": rid,
            "resolve_source": src,
            "run_dir": run_dir,
            "file": fp,
            "total": 0,
            "items": [],
        }), 200

    items = data.get("items") or []
    items = _apply_filters(items, q=q, sev=sev, tool=tool, cwe=cwe, fileq=fileq)

    # sort: severity desc, tool, file, line
    items.sort(key=lambda it: (-_sev_w(it.get("severity")), (it.get("tool") or ""), (it.get("file") or ""), int(it.get("line") or 0)))

    total = len(items)
    start = (page - 1) * limit
    end = start + limit
    page_items = items[start:end]

    # quick counts (for UI filters)
    by_sev = {}
    by_tool = {}
    by_cwe = {}
    for it in items:
        sv = (it.get("severity") or "UNKNOWN").upper()
        tl = (it.get("tool") or "UNKNOWN")
        cw = it.get("cwe")
        c = "UNKNOWN"
        if isinstance(cw, list) and cw:
            c = str(cw[0] or "UNKNOWN").upper()
        elif isinstance(cw, str) and cw.strip():
            c = cw.strip().upper()
        by_sev[sv] = by_sev.get(sv, 0) + 1
        by_tool[tl] = by_tool.get(tl, 0) + 1
        by_cwe[c] = by_cwe.get(c, 0) + 1

    top_cwe = sorted(by_cwe.items(), key=lambda kv: kv[1], reverse=True)[:10]

    return jsonify({
        "ok": True,
        "rid": rid,
        "run_dir": run_dir,
        "resolve_source": src,
        "file": fp,
        "page": page,
        "limit": limit,
        "total": total,
        "counts": {
            "by_sev": by_sev,
            "by_tool": by_tool,
            "top_cwe": top_cwe,
        },
        "items": page_items,
        "filters": {"q": q, "sev": sev, "tool": tool, "cwe": cwe, "file": fileq},
    }), 200
# === /VSP_FINDINGS_UNIFIED_API_P1_V1 ===

# =========================
# P0: Canonical Gate Summary (run_gate_summary_v1) [V2 bind-multi-app]
# =========================
from pathlib import Path as _Path
import os as _os, json as _json, re as _re, datetime as _dt

def _vsp_now_iso():
    try:
        return _dt.datetime.utcnow().isoformat() + "Z"
    except Exception:
        return ""

def _vsp_sanitize_rid(rid: str) -> str:
    rid = (rid or "").strip()
    if not rid:
        return ""
    if _re.fullmatch(r"[A-Za-z0-9_.:-]+", rid):
        return rid
    return ""

def _vsp_guess_run_dir(rid: str) -> str:
    if not rid:
        return ""
    roots = []
    env = (_os.environ.get("VSP_RUN_ROOTS") or "").strip()
    if env:
        roots += [x for x in env.split(":") if x.strip()]

    roots += [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out",
    ]

    for r in roots:
        try:
            d = _Path(r) / rid
            if d.is_dir():
                return str(d)
        except Exception:
            pass

    base = _Path("/home/test/Data")
    for pat in [f"*/out_ci/{rid}", f"*/out/{rid}"]:
        try:
            for d in base.glob(pat):
                if d.is_dir():
                    return str(d)
        except Exception:
            pass
    return ""

def _vsp_read_json(path: _Path):
    try:
        return _json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return None

def _vsp_try_gate_files(run_dir: str):
    d = _Path(run_dir)
    for name in ["run_gate_summary.json","run_gate_summary_v1.json","run_gate_summary_v2.json","run_gate.json"]:
        fp = d / name
        if fp.is_file() and fp.stat().st_size > 2:
            j = _vsp_read_json(fp)
            if isinstance(j, dict):
                j.setdefault("source", f"FILE:{name}")
                return j
    return None

def _vsp_derive_gate_from_findings(run_dir: str, rid: str):
    fu = _Path(run_dir) / "findings_unified.json"
    if not fu.is_file() or fu.stat().st_size <= 2:
        return None
    j = _vsp_read_json(fu)
    if not isinstance(j, dict):
        return None
    items = j.get("items") or []
    if not isinstance(items, list):
        items = []

    counts = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0,"UNKNOWN":0}
    for it in items:
        if not isinstance(it, dict): 
            continue
        sev = str(it.get("severity") or it.get("sev") or "UNKNOWN").upper()
        if sev not in counts:
            sev = "UNKNOWN"
        counts[sev] += 1
    total = sum(counts.values())

    if (counts["CRITICAL"] + counts["HIGH"]) > 0:
        status = "FAIL"
        reasons = [f"derived from findings_unified: CRITICAL+HIGH={counts['CRITICAL']+counts['HIGH']}"]
    elif counts["MEDIUM"] > 0:
        status = "DEGRADED"
        reasons = [f"derived from findings_unified: MEDIUM={counts['MEDIUM']}"]
    else:
        status = "OK"
        reasons = [f"derived from findings_unified: total={total}"]

    return {
        "ok": True,
        "source": "DERIVED:findings_unified.json",
        "rid": rid,
        "ci_run_dir": run_dir,
        "overall": {
            "status": status,
            "reasons": reasons + ["gate summary file missing (derived fallback)"],
            "degraded": ["gate_summary_missing_derived"],
            "ts": _vsp_now_iso(),
        },
        "counts": {"total": total, "by_severity": counts},
    }

def _vsp_run_gate_summary_v1_impl(rid):
    rid0 = _vsp_sanitize_rid(rid)
    if not rid0:
        return _jsonify({"ok": False, "status":"ERROR", "error":"BAD_RID", "http_code":400, "final":True, "rid":rid, "ts":_vsp_now_iso()}), 200

    run_dir = _vsp_guess_run_dir(rid0)
    if not run_dir:
        return _jsonify({"ok": False, "status":"ERROR", "error":"RUN_DIR_NOT_FOUND", "http_code":404, "final":True, "rid":rid0, "ts":_vsp_now_iso()}), 200

    g = _vsp_try_gate_files(run_dir)
    if isinstance(g, dict):
        g.setdefault("ok", True)
        g.setdefault("run_id", rid0)
        g.setdefault("ci_run_dir", run_dir)
        g.setdefault("overall", {"status":"DEGRADED","reasons":["missing overall in gate file"],"degraded":["gate_overall_missing"],"ts":_vsp_now_iso()})
        return _jsonify(g), 200

    d = _vsp_derive_gate_from_findings(run_dir, rid0)
    if isinstance(d, dict):
        return _jsonify(d), 200

    return _jsonify({"ok": False, "status":"ERROR", "error":"GATE_SUMMARY_MISSING", "http_code":404, "final":True, "rid":rid0, "ci_run_dir":run_dir, "ts":_vsp_now_iso()}), 200

# Bind to whichever object exists: app / application / bp / vsp_bp
_targets = []
for _name in ("app","application","bp","vsp_bp","vsp_api","api_bp"):
    try:
        _obj = globals().get(_name, None)
        if _obj is not None and hasattr(_obj, "route"):
            _targets.append((_name, _obj))
    except Exception:
        pass

for _n, _obj in _targets:
    try:
        _obj.route("/api/vsp/run_gate_summary_v1/<rid>", methods=["GET"])(lambda rid, _f=_vsp_run_gate_summary_v1_impl: _f(rid))
    except Exception:
        pass


# ================================
# VSP_VSP4_INJECT_AFTER_REQUEST_V3
# ================================
import re as _vsp_re

def _vsp__inject_tags_v3(html: str) -> str:
  try:
    # hash normalizer into <head>
    # hash normalizer into <head>
    if 'vsp_hash_normalize_v1.js' not in html:
      tag = '<script src="/static/js/vsp_hash_normalize_v1.js?v=1765944602"></script>'
      mm = _vsp_re.search(r'<head[^>]*>', html, flags=_vsp_re.I)
      if mm:
        i = mm.end()
        html = html[:i] + '\n  ' + tag + '\n' + html[i:]
      else:
        html = tag + '\n' + html

        # drilldown stub into <head> (must be function)
    if 'vsp_drilldown_stub_safe_v1.js' not in html:
      tag2 = '<script src="/static/js/vsp_drilldown_stub_safe_v1.js?v=1765945236"></script>'
      mm2 = _vsp_re.search(r'<head[^>]*>', html, flags=_vsp_re.I)
      if mm2:
        j = mm2.end()
        html = html[:j] + '\n  ' + tag2 + '\n' + html[j:]
      else:
        html = tag2 + '\n' + html

# loader+features before </body>
    if 'vsp_ui_loader_route_v1.js' not in html:
      ins = '\n  <script src="/static/js/vsp_ui_features_v1.js?v=1765944602"></script>\n' \
            '  <script src="/static/js/vsp_ui_loader_route_v1.js?v=1765944602"></script>\n'
      if '</body>' in html:
        html = html.replace('</body>', ins + '</body>')
      else:
        html = html + ins
  except Exception:
    pass
  return html

def __vsp_after_request_inject_v3(resp):
  try:
    path = (request.path or '').rstrip('/')
    if path == '/vsp4':
      ct = (resp.headers.get('Content-Type','') or '')
      if 'text/html' in ct:
        html = resp.get_data(as_text=True)
        html2 = _vsp__inject_tags_v3(html)
        if html2 != html:
          resp.set_data(html2)
  except Exception:
    pass
  return resp


# ================================
# VSP_ROOT_FORCE_REDIRECT_V2
# ================================
try:
    pass
except Exception:
  _vsp_redirect = None

@app.before_request
def __vsp_force_root_to_vsp4_v2():
  try:
    # exact root only
    # exact root only
    if request.path == "/" and _vsp_redirect is not None:
      return _vsp_redirect("/vsp4/#dashboard", code=302)
  except Exception:
    pass
  return None



# ================================
# VSP_VSP4_SLASH_REDIRECT_V1
# ================================
@app.before_request
def __vsp_redirect_vsp4_slash_v1():
  try:
    if request.path == "/vsp4/":
      return _vsp_redirect("/vsp4", code=301) if "_vsp_redirect" in globals() and _vsp_redirect else redirect("/vsp4", code=301)
  except Exception:
    pass
  return None


# ================================
# VSP_FAVICON_REDIRECT_V1
# ================================
@app.before_request
def __vsp_favicon_redirect_v1():
  try:
    pth = request.path or ""
    if pth == "/favicon.ico" or pth == "/vsp4/favicon.ico":
      return redirect("/static/favicon.ico", code=302)
  except Exception:
    pass
  return None


# ================================
# VSP_VSP4_HTML_SANITIZE_P0_V1
# - remove stray <script src="P\d{6}_\d{6}..."> which causes noisy 404
# ================================
def __vsp_vsp4_html_sanitize_p0_v1(resp):
  try:
    pth = (request.path or "")
    if pth not in ("/vsp4", "/vsp4/"):
      return resp
    ct = (resp.content_type or "")
    if "text/html" not in ct:
      return resp
    html = resp.get_data(as_text=True)
    # remove broken/stray script tags like: <script src="P251217_065927"></script>
    html2 = re.sub(r'<script\s+[^>]*src="P\d{6}_\d{6}[^"]*"[^>]*>\s*</script>\s*', '', html, flags=re.I)
    if html2 != html:
      resp.set_data(html2)
  except Exception:
    pass
  return resp


# ================================
# VSP_HTML_SANITIZE_P_SCRIPT_V2
# - remove stray script tags like /static/js/P251217_065927?... or /static/js/p251217_065927?...
# ================================
def __vsp_html_sanitize_p_script_v2(resp):
  try:
    ct = (resp.headers.get("Content-Type") or "")
    if "text/html" in ct:
      html = resp.get_data(as_text=True)
      # remove <script src="/static/js/P...._......"> stray tags (case-insensitive P/p)
      html2 = re.sub(r'(?is)<script[^>]+src="\/static\/js\/[pP]\d{6,8}_\d{6}[^"]*"[^>]*>\s*<\/script>', '', html)
      if html2 != html:
        resp.set_data(html2)
  except Exception:
    pass
  return resp


# ================================
# VSP_API_LIMIT_CAPS_P0_V1
# - prevent OOM by capping heavy list endpoints
# ================================
def __vsp__wrap_limit_redirect(app, rule_path, cap):
  try:
    from urllib.parse import urlencode
  except Exception:
    return
  try:
    ep = None
    for rule in app.url_map.iter_rules():
      if getattr(rule, "rule", "") == rule_path:
        ep = rule.endpoint
        break
    if not ep:
      return
    orig = app.view_functions.get(ep)
    if not callable(orig):
      return

    def _wrapped(*a, **kw):
      try:
        lim = request.args.get("limit", "")
        if lim:
          try:
            n = int(lim)
          except Exception:
            n = cap
          if n > cap:
            q = request.args.to_dict(flat=True)
            q["limit"] = str(cap)
            url = request.path + "?" + urlencode(q)
            return redirect(url, code=302)
      except Exception:
        pass
      return orig(*a, **kw)

    app.view_functions[ep] = _wrapped
  except Exception:
    pass

try:
  # cap datasource to 200, runs list to 50 (đủ dùng UI)
  # cap datasource to 200, runs list to 50 (đủ dùng UI)
  __vsp__wrap_limit_redirect(app, "/api/vsp/datasource_v2", 200)
  __vsp__wrap_limit_redirect(app, "/api/vsp/runs_index_v3", 50)
except Exception:
  pass


# --- VSP_AFTERREQ_LATEST_RID_COMPAT_P0_V1: ensure /api/vsp/latest_rid_v1 returns `rid` (compat with UI) ---
def vsp_afterreq_latest_rid_compat_p0_v1(resp):
    pass


# --- VSP_AFTERREQ_BUNDLE_ONLY_VSP4_P0_V5CLEAN: force /vsp4 to load ONLY bundle v2 (commercial) ---
@app.after_request
def vsp_afterreq_bundle_only_vsp4_p0_v5clean(resp):
    try:
        import re as _re

        path = getattr(request, "path", "") or ""
        if not (path == "/vsp4" or path.startswith("/vsp4/")):
            return resp

        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype:
            return resp
        if getattr(resp, "status_code", 200) != 200:
            return resp

        body = resp.get_data(as_text=True)

        m = _re.search(r'/static/js/vsp_[^"\']+\?v=(\d+)', body, _re.I)
        try:
            import os as _os
            _bf = _os.path.join(_os.path.dirname(__file__), "static", "js", "vsp_bundle_commercial_v2.js")
            asset_v = str(int(_os.path.getmtime(_bf))) if _os.path.exists(_bf) else "1"
        except Exception:
            asset_v = "1"
        # VSP_AFTERREQ_BUNDLE_MTIME_CACHEBUST_P0_V1


        # drop ALL vsp_*.js script tags (we will re-insert bundle v2 once)
        pat = _re.compile(r"""(?is)<script\b[^>]*\bsrc\s*=\s*(['"])([^'"]*?/static/js/vsp_[^'"]+)\1[^>]*>\s*</script\s*>""")
        body2 = pat.sub("\n", body)

        bundle_tag = f'<script defer src="/static/js/vsp_bundle_commercial_v2.js?v={asset_v}"></script>'
        if _re.search(r"(?is)</body\s*>", body2):
            body2 = _re.sub(r"(?is)</body\s*>", "\n"+bundle_tag+"\n</body>", body2, count=1)
        else:
            body2 += "\n" + bundle_tag + "\n"

        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
    except Exception:
        pass
    return resp



# --- VSP_AFTERREQ_STRIP_PSCRIPT_P0_V1: /vsp4 keep ONLY vsp_bundle_commercial_v2.js and drop /static/js/P* script ---
@app.after_request
def vsp_afterreq_strip_pscript_p0_v1(resp):
    try:
        path = getattr(request, "path", "") or ""
        if not (path == "/vsp4" or path.startswith("/vsp4/")):
            return resp
        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp

        body = resp.get_data(as_text=True)

        # Remove any <script ... src="/static/js/P....">...</script>
        # (very conservative: only matches '/static/js/P' prefix)
        body2 = re.sub(r'(?is)\s*<script\b[^>]*\bsrc\s*=\s*["\'](/static/js/P[^"\']+)["\'][^>]*>\s*</script\s*>\s*', "\n", body)

        # Also remove any other vsp_*.js tags except the bundle v2
        def keep_only_bundle(m):
            src = (m.group(1) or "")
            if "vsp_bundle_commercial_v2.js" in src:
                return m.group(0)
            if "/static/js/vsp_" in src or "static/js/vsp_" in src:
                return "\n"
            return m.group(0)

        body2 = re.sub(r'(?is)<script\b[^>]*\bsrc\s*=\s*["\']([^"\']+)["\'][^>]*>\s*</script\s*>', keep_only_bundle, body2)

        # Ensure bundle tag exists (if someone removed it)
        if "vsp_bundle_commercial_v2.js" not in body2:
            # try keep the same v= from old body if present
            mv = re.search(r'vsp_bundle_commercial_v2\.js\?v=(\d+)', body, re.I)
            vv = mv.group(1) if mv else "1"
            bundle_tag = f'<script defer src="/static/js/vsp_bundle_commercial_v2.js?v={vv}"></script>'
            if re.search(r"(?is)</body\s*>", body2):
                body2 = re.sub(r"(?is)</body\s*>", "\n"+bundle_tag+"\n</body>", body2, count=1)
            else:
                body2 += "\n" + bundle_tag + "\n"

        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-VSP-BUNDLEONLY"] = "STRIP_PSCRIPT_P0_V1"
    except Exception:
        pass
    return resp



# --- VSP_AFTERREQ_FORCE_CLEAN_BUNDLEONLY_P0_V1: hard clean /vsp4 HTML + keep ONLY bundle v2 ---
@app.after_request
def vsp_afterreq_force_clean_bundleonly_p0_v1(resp):
    try:
        path = getattr(request, "path", "") or ""
        if path != "/vsp4":
            return resp

        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp

        body = resp.get_data(as_text=True)

        # (0) Drop any garbage BEFORE <!DOCTYPE or <html
        idx = body.lower().find("<!doctype")
        if idx == -1:
            idx = body.lower().find("<html")
        if idx > 0:
            body = body[idx:]

        # (1) Find asset_v from existing bundle tag, else fallback
        m = re.search(r'vsp_bundle_commercial_v2\.js\?v=(\d+)', body, re.I)
        asset_v = m.group(1) if m else "1"

        # (2) Remove ALL external script tags that reference /static/js/P* OR /static/js/vsp_* (we will re-add bundle)
        def drop_external_scripts(html: str) -> str:
            parts = html.split("<script")
            if len(parts) == 1:
                return html
            out = [parts[0]]
            for chunk in parts[1:]:
                seg = "<script" + chunk
                low = seg.lower()
                # inline script => keep
                if 'src="' not in low and "src='" not in low:
                    out.append(seg); continue
                # detect src value quickly
                if "/static/js/p" in low or "static/js/p" in low:
                    end = low.find("</script>")
                    if end != -1:
                        continue
                if "/static/js/vsp_" in low or "static/js/vsp_" in low:
                    end = low.find("</script>")
                    if end != -1:
                        continue
                out.append(seg)
            return "".join(out)

        body2 = drop_external_scripts(body)

        # (3) Ensure exactly one bundle v2 tag before </body>
        bundle_tag = f'<script defer src="/static/js/vsp_bundle_commercial_v2.js?v={asset_v}"></script>'
        # remove any existing bundle tags first
        body2 = re.sub(r'(?is)\s*<script\b[^>]*vsp_bundle_commercial_v2\.js[^>]*>\s*</script\s*>\s*', "\n", body2)

        if re.search(r"(?is)</body\s*>", body2):
            body2 = re.sub(r"(?is)</body\s*>", "\n"+bundle_tag+"\n</body>", body2, count=1)
        else:
            body2 += "\n" + bundle_tag + "\n"

        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-VSP-BUNDLEONLY"] = "FORCE_CLEAN_P0_V1"
    except Exception:
        pass
    return resp

# --- VSP_AFTERREQ_STRIP_BROKEN_P_SCRIPT_P0_V1: strip broken <script src="/static/js/P... "?v=...> tags in /vsp4 ---
@app.after_request
def vsp_afterreq_strip_broken_p_script_p0_v1(resp):
    try:
        path = getattr(request, "path", "") or ""
        if path != "/vsp4":
            return resp
        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp

        body = resp.get_data(as_text=True)

        # remove any script tag that contains src="/static/js/P" even if ?v is outside quotes
        body2 = re.sub(r'(?is)\s*<script\b[^>]*src="/static/js/P[^"]*"[^>]*>\s*</script\s*>\s*', "\n", body)
        # also cover the exact broken pattern: src="/static/js/P..."?v=..."
        body2 = re.sub(r'(?is)\s*<script\b[^>]*src="/static/js/P[^"]*"\?v=[^>]*>\s*</script\s*>\s*', "\n", body2)

        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-VSP-BUNDLEONLY"] = "STRIP_BROKEN_P_P0_V1"
    except Exception:
        pass
    return resp

# --- VSP_AFTERREQ_STRIP_PSCRIPT_RESPONSE_P0_V2: force-strip /static/js/P* script tags from /vsp4 HTML (handles broken quote ?v= outside) ---
@app.after_request
def vsp_afterreq_strip_pscript_response_p0_v2(resp):
    try:
        path = getattr(request, "path", "") or ""
        if path != "/vsp4":
            return resp
        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp
        body = resp.get_data(as_text=True)
        # remove <script ... src="/static/js/Pxxxx"?v=...></script>
        body2 = re.sub(r'(?is)\s*<script\b[^>]*\bsrc="/static/js/P[^"]*"(?:\?v=[^>]*)?[^>]*>\s*</script\s*>\s*', "\n", body)
        resp.set_data(body2)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-VSP-STRIP-P"] = "P0_V2"
    except Exception:
        pass
    return resp


# --- VSP_AFTERREQ_STRIP_PSCRIPT_RESPONSE_P0_V3: strip /static/js/P* script tags from /vsp4 HTML (robust + header) ---
@app.after_request
def vsp_afterreq_strip_pscript_response_p0_v3(resp):
    try:
        import re as _re

        path = getattr(request, "path", "") or ""
        if path != "/vsp4":
            return resp
        ctype = (getattr(resp, "mimetype", "") or "").lower()
        if "html" not in ctype or getattr(resp, "status_code", 200) != 200:
            return resp

        # set probe header early (even if stripping fails)
        resp.headers["X-VSP-STRIP-P"] = "P0_V3"
        resp.headers["Cache-Control"] = "no-store"

        body = resp.get_data(as_text=True)

        # 1) remove normal P-script tags
        body2 = _re.sub(r'(?is)\s*<script\b[^>]*\bsrc="/static/js/P[^"]*"[^>]*>\s*</script\s*>\s*', "\n", body)

        # 2) remove broken quote form: src="/static/js/Pxxx"?v=....
        body2 = _re.sub(r'(?is)\s*<script\b[^>]*\bsrc="/static/js/P[^"]*"\?v=[^>]*>\s*</script\s*>\s*', "\n", body2)

        resp.set_data(body2)
    except Exception:
        pass
    return resp

# --- VSP_HEALTHZ_READYZ_P0_V1: commercial health endpoints ---
# @app.get("/healthz")
def vsp_healthz_p0_v1():
    return "ok", 200

@app.get("/readyz")
def vsp_readyz_p0_v1():
    # lightweight readiness: app is up + can answer latest rid quickly
    return {"ok": True}, 200

# --- VSP_HEALTHZ_READYZ_P0_V2: commercial health endpoints ---
# @app.get("/healthz")
def vsp_healthz_p0_v2():
    return "ok", 200

@app.get("/readyz")
def vsp_readyz_p0_v2():
    return {"ok": True}, 200


# ==== VSP_EXPORT_QUICK_ACTIONS_P0_V1 ====
def _vsp__latest_rid_info__p0():
    """
    Returns dict from /api/vsp/latest_rid_v1:
      {{ rid, ci_run_dir, ... }
    """
    u = "http://127.0.0.1:8910/api/vsp/latest_rid_v1"
    try:
        with urllib.request.urlopen(u, timeout=3) as r:
            return json.loads(r.read().decode("utf-8","replace"))
    except Exception as e:
        return {"error": str(e), "rid": "", "ci_run_dir": ""}

def _vsp__pack_report__p0(run_dir: str):
    bundle = "/home/test/Data/SECURITY_BUNDLE"
    pack = f"{bundle}/bin/pack_report.sh"
    env = os.environ.copy()
    env["RUN_DIR"] = run_dir
    env["BUNDLE"] = bundle
    # tránh pack_report tự curl lại nếu đã có RUN_DIR
    p = subprocess.run(["bash", pack], cwd=bundle, env=env, capture_output=True, text=True, timeout=180)
    # find tgz
    tgzs = sorted(glob.glob(os.path.join(run_dir, "*__REPORT.tgz")), key=lambda x: os.path.getmtime(x), reverse=True)
    tgz = tgzs[0] if tgzs else ""
    sha = os.path.join(run_dir, "SHA256SUMS.txt")
    return {
        "ok": (p.returncode == 0 and bool(tgz)),
        "returncode": p.returncode,
        "stdout_tail": "\n".join((p.stdout or "").splitlines()[-80:]),
        "stderr_tail": "\n".join((p.stderr or "").splitlines()[-80:]),
        "tgz": tgz,
        "sha": sha if os.path.isfile(sha) else "",
    }

@app.get("/api/vsp/pack_report_latest_v1")
def api_pack_report_latest_v1():
    info = _vsp__latest_rid_info__p0()
    run_dir = (info or {{}}).get("ci_run_dir") or ""
    rid = (info or {{}}).get("rid") or ""
    if not run_dir or not os.path.isdir(run_dir):
        return jsonify({{"ok": False, "rid": rid, "ci_run_dir": run_dir, "error": "bad ci_run_dir", "info": info}}), 400
    res = _vsp__pack_report__p0(run_dir)
    res.update({{"rid": rid, "ci_run_dir": run_dir}})
    return jsonify(res), (200 if res.get("ok") else 500)

@app.get("/api/vsp/export_report_tgz_latest_v1")
def api_export_report_tgz_latest_v1():
    info = _vsp__latest_rid_info__p0()
    run_dir = (info or {{}}).get("ci_run_dir") or ""
    rid = (info or {{}}).get("rid") or ""
    if not run_dir or not os.path.isdir(run_dir):
        return jsonify({{"ok": False, "rid": rid, "ci_run_dir": run_dir, "error": "bad ci_run_dir", "info": info}}), 400
    res = _vsp__pack_report__p0(run_dir)
    if not res.get("ok"):
        return jsonify({{"ok": False, "rid": rid, "ci_run_dir": run_dir, "error": "pack failed", **res}}), 500
    return send_file(res["tgz"], as_attachment=True, download_name=os.path.basename(res["tgz"]))

@app.get("/api/vsp/open_report_html_latest_v1")
def api_open_report_html_latest_v1():
    info = _vsp__latest_rid_info__p0()
    run_dir = (info or {{}}).get("ci_run_dir") or ""
    if not run_dir or not os.path.isdir(run_dir):
        return "bad ci_run_dir", 400
    html = os.path.join(run_dir, "report", "security_resilient.html")
    if not os.path.isfile(html):
        # try to pack (autofill will create it)
        _vsp__pack_report__p0(run_dir)
    if not os.path.isfile(html):
        return "missing security_resilient.html", 404
    return send_file(html, mimetype="text/html")

@app.get("/api/vsp/verify_report_sha_latest_v1")
def api_verify_report_sha_latest_v1():
    info = _vsp__latest_rid_info__p0()
    run_dir = (info or {{}}).get("ci_run_dir") or ""
    rid = (info or {{}}).get("rid") or ""
    if not run_dir or not os.path.isdir(run_dir):
        return jsonify({{"ok": False, "rid": rid, "ci_run_dir": run_dir, "error": "bad ci_run_dir"}}), 400
    # ensure tgz exists
    _vsp__pack_report__p0(run_dir)
    sha = os.path.join(run_dir, "SHA256SUMS.txt")
    if not os.path.isfile(sha):
        return jsonify({{"ok": False, "rid": rid, "ci_run_dir": run_dir, "error": "missing SHA256SUMS.txt"}}), 500
    p = subprocess.run(["bash","-lc", f'cd "{run_dir}" && sha256sum -c SHA256SUMS.txt'], capture_output=True, text=True, timeout=30)
    return jsonify({{
        "ok": (p.returncode == 0),
        "rid": rid,
        "ci_run_dir": run_dir,
        "returncode": p.returncode,
        "stdout": p.stdout,
        "stderr": p.stderr,
    }}), (200 if p.returncode == 0 else 500)
# ==== /VSP_EXPORT_QUICK_ACTIONS_P0_V1 ====



# ==== VSP_EXPORT_QUICK_ACTIONS_P0_V2 ====
def _vsp_safe_run_dir__p0(run_dir: str) -> str:
    """allow only /home/test/Data/... directories to avoid path traversal"""
    if not run_dir:
        return ""
    run_dir = str(run_dir).strip()
    if "\x00" in run_dir:
        return ""
    if ".." in run_dir.replace("\\","/"):
        return ""
    if not run_dir.startswith("/home/test/Data/"):
        return ""
    if not os.path.isdir(run_dir):
        return ""
    return run_dir

def _vsp_pack_report__p0(run_dir: str):
    bundle = "/home/test/Data/SECURITY_BUNDLE"
    pack = f"{bundle}/bin/pack_report.sh"
    env = os.environ.copy()
    env["RUN_DIR"] = run_dir
    env["BUNDLE"] = bundle
    p = subprocess.run(["bash", pack], cwd=bundle, env=env, capture_output=True, text=True, timeout=240)
    tgzs = sorted(glob.glob(os.path.join(run_dir, "*__REPORT.tgz")), key=lambda x: os.path.getmtime(x), reverse=True)
    tgz = tgzs[0] if tgzs else ""
    sha = os.path.join(run_dir, "SHA256SUMS.txt")
    return {
        "ok": (p.returncode == 0 and bool(tgz)),
        "returncode": p.returncode,
        "stdout_tail": "\n".join((p.stdout or "").splitlines()[-60:]),
        "stderr_tail": "\n".join((p.stderr or "").splitlines()[-60:]),
        "tgz": tgz,
        "sha": sha if os.path.isfile(sha) else "",
        "run_dir": run_dir,
    }

@app.get("/api/vsp/export_report_tgz_v1")
def api_export_report_tgz_v1():
    try:
        run_dir = _vsp_safe_run_dir__p0(request.args.get("run_dir",""))
        if not run_dir:
            return jsonify({"ok": False, "error": "bad run_dir"}), 400
        res = _vsp_pack_report__p0(run_dir)
        if not res.get("ok"):
            return jsonify({"ok": False, "error": "pack failed", **res}), 500
        return send_file(res["tgz"], as_attachment=True, download_name=os.path.basename(res["tgz"]))
    except Exception as e:
        return jsonify({"ok": False, "error": "EXC", "msg": str(e)}), 500

@app.get("/api/vsp/open_report_html_v1")
def api_open_report_html_v1():
    try:
        run_dir = _vsp_safe_run_dir__p0(request.args.get("run_dir",""))
        if not run_dir:
            return "bad run_dir", 400
        html = os.path.join(run_dir, "report", "security_resilient.html")
        if not os.path.isfile(html):
            _vsp_pack_report__p0(run_dir)
        if not os.path.isfile(html):
            return "missing security_resilient.html", 404
        return send_file(html, mimetype="text/html")
    except Exception as e:
        return f"EXC: {e}", 500

@app.get("/api/vsp/verify_report_sha_v1")
def api_verify_report_sha_v1():
    try:
        run_dir = _vsp_safe_run_dir__p0(request.args.get("run_dir",""))
        if not run_dir:
            return jsonify({"ok": False, "error": "bad run_dir"}), 400
        _vsp_pack_report__p0(run_dir)
        sha = os.path.join(run_dir, "SHA256SUMS.txt")
        if not os.path.isfile(sha):
            return jsonify({"ok": False, "error": "missing SHA256SUMS.txt", "run_dir": run_dir}), 500
        p = subprocess.run(["bash","-lc", f'cd "{run_dir}" && sha256sum -c SHA256SUMS.txt'],
                           capture_output=True, text=True, timeout=30)
        return jsonify({
            "ok": (p.returncode == 0),
            "run_dir": run_dir,
            "returncode": p.returncode,
            "stdout": p.stdout,
            "stderr": p.stderr,
        }), (200 if p.returncode == 0 else 500)
    except Exception as e:
        return jsonify({"ok": False, "error": "EXC", "msg": str(e)}), 500
# ==== /VSP_EXPORT_QUICK_ACTIONS_P0_V2 ====




# -------------------- VSP_API_DASH_FIND_COMMERCIAL_P0_V1 --------------------
# Commercial read-only APIs for UI:
#  - /api/vsp/findings_latest_v1  (returns top N findings from latest run report/findings.json)
#  - /api/vsp/dashboard_commercial_v1 (build KPI from findings + gate summaries)
try:
    pass
except Exception:
    pass

def _vsp_allowed_prefixes():
    return [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    ]

def _vsp_pick_latest_run_dir():
    import os, glob
    cands=[]
    for base in _vsp_allowed_prefixes():
        if not os.path.isdir(base): 
            continue
        # prefer CI RID style, but accept RUN_ too
        for pat in ("VSP_CI_*", "*RUN_*"):
            for d in glob.glob(os.path.join(base, pat)):
                if os.path.isdir(d):
                    try:
                        cands.append((os.path.getmtime(d), d))
                    except Exception:
                        pass
    cands.sort(reverse=True)
    return cands[0][1] if cands else ""

def _vsp_safe_run_dir(rd: str) -> str:
    import os
    if not rd:
        return ""
    rd=os.path.realpath(rd)
    if not os.path.isdir(rd):
        return ""
    ok=False
    for pref in _vsp_allowed_prefixes():
        pref=os.path.realpath(pref)
        if rd.startswith(pref + os.sep) or rd == pref:
            ok=True
            break
    return rd if ok else ""

def _vsp_read_json(path: str):
    import json
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return json.load(f)

def _vsp_find_report_files(run_dir: str):
    import os
    rep=os.path.join(run_dir, "report")
    f_find=os.path.join(rep, "findings.json")
    f_gate=os.path.join(run_dir, "run_gate_summary.json")
    if not os.path.isfile(f_gate):
        f_gate=os.path.join(run_dir, "run_gate.json")
    return {"report_dir": rep, "findings_json": f_find, "gate_json": f_gate}

@app.get("/api/vsp/findings_latest_v1")
def vsp_findings_latest_v1():
    import os
    rd = request.args.get("run_dir", "").strip()
    rd = _vsp_safe_run_dir(rd) or _vsp_pick_latest_run_dir()
    rd = _vsp_safe_run_dir(rd)
    if not rd:
        return jsonify({"ok":False, "error":"NO_RUN_DIR"}), 404

    limit = int(request.args.get("limit", "200") or "200")
    limit = max(10, min(limit, 2000))

    files=_vsp_find_report_files(rd)
    fp=files["findings_json"]
    if not os.path.isfile(fp):
        # fallback to findings_unified.json if report not materialized
        alt=os.path.join(rd, "reports", "findings_unified.json")
        if os.path.isfile(alt):
            fp=alt
        else:
            return jsonify({"ok":False, "run_dir":rd, "error":"MISSING_FINDINGS_JSON"}), 404

    try:
        j=_vsp_read_json(fp)
    except Exception as e:
        return jsonify({"ok":False, "run_dir":rd, "error":"BAD_JSON", "detail":str(e)}), 500

    items = j.get("items") if isinstance(j, dict) else (j if isinstance(j, list) else [])
    if items is None: items=[]
    out_items = items[:limit]
    return jsonify({
        "ok": True,
        "run_dir": rd,
        "source": fp,
        "limit": limit,
        "total_items": len(items),
        "items": out_items,
    })

@app.get("/api/vsp/dashboard_commercial_v1")
def vsp_dashboard_commercial_v1():
    import os
    rd = request.args.get("run_dir", "").strip()
    rd = _vsp_safe_run_dir(rd) or _vsp_pick_latest_run_dir()
    rd = _vsp_safe_run_dir(rd)
    if not rd:
        return jsonify({"ok":False, "error":"NO_RUN_DIR"}), 404

    files=_vsp_find_report_files(rd)
    sev_counts={"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0,"total":0}
    tools=set()

    # findings -> severity counts
    fp=files["findings_json"]
    if not os.path.isfile(fp):
        alt=os.path.join(rd, "reports", "findings_unified.json")
        if os.path.isfile(alt): fp=alt

    degraded=[]
    if os.path.isfile(fp):
        try:
            j=_vsp_read_json(fp)
            items = j.get("items") if isinstance(j, dict) else (j if isinstance(j, list) else [])
            if items is None: items=[]
            for it in items:
                sev=str((it.get("severity") or it.get("sev") or "")).upper()
                if sev in sev_counts:
                    sev_counts[sev]+=1
                    sev_counts["total"]+=1
                t=it.get("tool") or it.get("engine")
                if t: tools.add(str(t))
        except Exception:
            degraded.append("findings_parse")
    else:
        degraded.append("findings_missing")

    # gate summary (best-effort)
    gate={}
    gp=files["gate_json"]
    if os.path.isfile(gp):
        try:
            gate=_vsp_read_json(gp) or {}
        except Exception:
            degraded.append("gate_parse")
    else:
        degraded.append("gate_missing")

    overall = {
        "rid": os.path.basename(rd),
        "run_dir": rd,
        "verdict": gate.get("overall_verdict") or gate.get("verdict") or gate.get("status") or "N/A",
        "severity": sev_counts,
        "degraded": degraded,
    }

    return jsonify({
        "ok": True,
        "overall": overall,
        "gate": gate,
        "tools": sorted(list(tools)),
        "source": {"findings": fp if os.path.isfile(fp) else "", "gate": gp if os.path.isfile(gp) else ""},
    })
# ------------------ end VSP_API_DASH_FIND_COMMERCIAL_P0_V1 ------------------



# -------------------- VSP_DASH_COMMERCIAL_V2_DEGRADED_STRICT_P1_V1 --------------------
# v2: DEGRADED only when findings missing/parse fail. gate issues => warnings (not degraded)
@app.get("/api/vsp/dashboard_commercial_v2")
def vsp_api_dashboard_commercial_v2():
    """Commercial dashboard API (v2) - hardened.
    Always returns stable JSON model derived from findings_unified.json.
    """
    from pathlib import Path
    import json, traceback

    base = Path(__file__).resolve().parent
    fp = base / "findings_unified.json"

    payload = {"ok": False, "notes": ["missing findings_unified.json"], "counts_by_severity": {}, "items": [], "findings": []}
    if fp.exists():
        try:
            payload = json.loads(fp.read_text(encoding="utf-8", errors="replace"))
        except Exception as e:
            payload = {"ok": False, "notes": [f"invalid findings_unified.json: {e}"], "counts_by_severity": {}, "items": [], "findings": []}

    try:
        counts = payload.get("counts_by_severity") or {}
        items  = payload.get("items") or []
        by_tool_sev = payload.get("by_tool_severity") or {}

        total = payload.get("total")
        if not isinstance(total, int):
            total = 0
            for it in items:
                c = it.get("count")
                if isinstance(c, int):
                    total += c
            if total == 0:
                total = sum(int(counts.get(k,0) or 0) for k in ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"])

        notes = payload.get("notes") or []
        summary_only = False
        if isinstance(notes, list) and any("placeholder generated" in str(x).lower() for x in notes):
            summary_only = True
        if (payload.get("findings") == []) and (len(items) > 0):
            summary_only = True

        model = {
            "ok": True,
            "ts": payload.get("generated_at"),
            "run_dir": payload.get("run_dir"),
            "summary_only": summary_only,
            "notes": notes,
            "counts_by_severity": {
                "CRITICAL": int(counts.get("CRITICAL", 0) or 0),
                "HIGH": int(counts.get("HIGH", 0) or 0),
                "MEDIUM": int(counts.get("MEDIUM", 0) or 0),
                "LOW": int(counts.get("LOW", 0) or 0),
                "INFO": int(counts.get("INFO", 0) or 0),
                "TRACE": int(counts.get("TRACE", 0) or 0),
            },
            "total_findings": int(total),
            "by_tool_severity": by_tool_sev,
            "items": items,
        }
        return Response(json.dumps(model, ensure_ascii=False), mimetype="application/json")
    except Exception as e:
        tb = traceback.format_exc().splitlines()[-10:]
        model = {"ok": False, "error": str(e), "trace_tail": tb}
        return Response(json.dumps(model, ensure_ascii=False), mimetype="application/json"), 500

    files=_vsp_find_report_files(rd)

    sev_counts={"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0,"total":0}
    tools=set()

    degraded=[]   # strict: only critical data missing/bad
    warnings=[]   # non-fatal: gate missing/parse

    # findings (critical)
    fp=files["findings_json"]
    if not os.path.isfile(fp):
        alt=os.path.join(rd, "reports", "findings_unified.json")
        if os.path.isfile(alt): fp=alt
    if os.path.isfile(fp):
        try:
            j=_vsp_read_json(fp)
            items = j.get("items") if isinstance(j, dict) else (j if isinstance(j, list) else [])
            if items is None: items=[]
            for it in items:
                sev=str((it.get("severity") or it.get("sev") or "")).upper()
                if sev in sev_counts:
                    sev_counts[sev]+=1
                    sev_counts["total"]+=1
                t=it.get("tool") or it.get("engine")
                if t: tools.add(str(t))
        except Exception:
            degraded.append("findings_parse")
    else:
        degraded.append("findings_missing")

    # gate (warning only)
    gate={}
    gp=files["gate_json"]
    if os.path.isfile(gp):
        try:
            gate=_vsp_read_json(gp) or {}
        except Exception:
            warnings.append("gate_parse")
    else:
        warnings.append("gate_missing")

    overall = {
        "rid": os.path.basename(rd),
        "run_dir": rd,
        "verdict": gate.get("overall_verdict") or gate.get("verdict") or gate.get("status") or "N/A",
        "severity": sev_counts,
        "degraded": degraded,
        "warnings": warnings,
        "degraded_yes": True if degraded else False,
    }
    return jsonify({
        "ok": True,
        "overall": overall,
        "gate": gate,
        "tools": sorted(list(tools)),
        "source": {"findings": fp if os.path.isfile(fp) else "", "gate": gp if os.path.isfile(gp) else ""},
    })
# ------------------ end VSP_DASH_COMMERCIAL_V2_DEGRADED_STRICT_P1_V1 ------------------

# VSP_SWITCH_ENTERPRISE_TEMPLATE_P0_V1

# --- BEGIN AUTO-ADDED: API fallback to serve findings_unified.json ---
try:
    _app_ref = app
except NameError:
    try:
        _app_ref = application
    except NameError:
        _app_ref = None

if _app_ref and 'vsp_findings_latest_fallback_v1' not in _app_ref.view_functions:
    @_app_ref.route("/api/vsp/findings_latest_v1")
    def vsp_findings_latest_fallback_v1():
        # safe fallback: return canonical findings_unified.json if present
        import os, json
        candidates = [
            os.path.join(current_app.root_path, "findings_unified.json"),
            "/home/test/Data/SECURITY_BUNDLE/findings_unified.json",
            os.path.join("/home/test/Data/SECURITY_BUNDLE","release","findings_unified.json"),
        ]
        # if app has run_dir attr, try it first
        try:
            run_dir = getattr(current_app, "vsp_run_dir", None)
            if run_dir:
                candidates.insert(0, os.path.join(run_dir, "findings_unified.json"))
        except Exception:
            pass
        for p in candidates:
            try:
                if p and os.path.isfile(p):
                    with open(p, "r", encoding="utf-8") as fh:
                        j = json.load(fh)
                    # Normalize output shape expected by frontend
                    out = {"ok": True, "run_dir": run_dir or "", "findings": None}
                    if isinstance(j, dict):
                        # try common keys
                        if "findings" in j:
                            out["findings"] = j["findings"]
                        elif "items" in j:
                            out["findings"] = j["items"]
                        elif "total" in j and j.get("total",0)==0:
                            out["findings"] = j.get("items",[]) or []
                        else:
                            # unknown shape -> return entire payload under 'unified'
                            out["findings"] = j.get("findings") if isinstance(j.get("findings"), list) else []
                    else:
                        out["findings"] = []
                    out["total"] = len(out["findings"])
                    return jsonify(out)
            except Exception as e:
                return jsonify(error="failed_read_unified", detail=str(e)), 500
        return jsonify(error="MISSING_FINDINGS_JSON", ok=False), 404
# --- END AUTO-ADDED ---

# ----- Auto-added: safe route to serve findings_unified.json for UI fallback -----
# This block was appended to ensure the UI can fetch the unified JSON even if other routes fail.
try:
    from pathlib import Path
    def _register_findings_route(app):
        @app.route('/findings_unified.json')
        def _vsp_findings_unified():
            p = Path('/home/test/Data/SECURITY_BUNDLE/ui/findings_unified.json')
            if p.is_file():
                # flask's send_file will set correct headers; conditional True allows 304 handling
                return send_file(str(p), mimetype='application/json', conditional=True)
            # fallback: 404 so UI can still handle missing
            abort(404)
    # try to register for common app variable names
    try:
        _register_findings_route(application)   # some wsgi use 'application'
    except Exception:
        try:
            _register_findings_route(app)       # fallback to 'app'
        except Exception:
            # if neither is available at import time, do nothing; the route will be present if app variable exists later
            pass
except Exception:
    # do not break imports if something unexpected happens
    pass

# ----- end auto-added block -----



# === VSP_RUNS_REPORTS_BP_SAFE_P0_V1 ===
try:
    from vsp_runs_reports_bp import bp as vsp_runs_reports_bp
    app.register_blueprint(vsp_runs_reports_bp)
    print("[VSP_RUNS_REPORTS_BP] mounted /runs + /api/vsp/runs + /api/vsp/run_file")
except Exception as _e:
    try:
        print("[VSP_RUNS_REPORTS_BP][WARN] not mounted:", _e)
    except Exception:
        pass
# === /VSP_RUNS_REPORTS_BP_SAFE_P0_V1 ===


# === VSP_SETTINGS_STUB_P0_V1 ===
@app.get("/settings")
def vsp_settings_page():

    # VSP_FORCE_ALLOW_SHA256SUMS_RUN_FILE_V1: always allow reports/SHA256SUMS.txt download (commercial audit)
    try:
        _rid = (request.args.get("rid","") or request.args.get("run_id","") or request.args.get("run","") or "").strip()
        _rel = (request.args.get("name","") or request.args.get("path","") or request.args.get("rel","") or "").strip().lstrip("/")
        if _rid and _rel == "reports/SHA256SUMS.txt":
            from pathlib import Path as _P
            from flask import send_file as _send_file, jsonify as _jsonify
            # try common run roots
            _roots = [
                _P("/home/test/Data/SECURITY_BUNDLE/out"),
                _P("/home/test/Data/SECURITY_BUNDLE/out_ci"),
                _P("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
                _P("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            ]
            for _root in _roots:
                _fp = (_root / _rid / "reports" / "SHA256SUMS.txt")
                if _fp.exists():
                    return _send_file(str(_fp), as_attachment=True)
            return _jsonify({"ok": False, "error": "NO_FILE"}), 404
    except Exception:
        pass

    return render_template("vsp_settings_v1.html")
# === /VSP_SETTINGS_STUB_P0_V1 ===


# === VSP_SELFCHECK_P0_V2_HARDEN ===
import time as _VSP_time
from pathlib import Path as _VSP_Path

@app.get("/api/vsp/selfcheck_p0")
def vsp_selfcheck_p0_v2_harden():
    """
    Commercial-safe selfcheck:
    - Must not fail due to optional pages/templates
    - Primary evidence: findings_unified.json readability + count
    """
    notes=[]
    warnings=[]
    src = _VSP_Path("/home/test/Data/SECURITY_BUNDLE/ui/findings_unified.json")
    total = 0
    ok = True
    try:
        import json
        if src.exists():
            j = json.loads(src.read_text(encoding="utf-8", errors="replace") or "{}")
            # support both {"items":[...]} or {"findings":[...]} shapes
            items = j.get("items") or j.get("findings") or []
            if isinstance(items, list):
                total = len(items)
            else:
                warnings.append("findings list missing or wrong type")
        else:
            warnings.append("findings_unified.json missing (ui path)")
    except Exception as e:
        ok = False
        warnings.append("exception reading findings_unified.json")
        notes.append(str(e))

    # soft-check: key api endpoints (should exist if UI healthy)
    api = {}
    try:
        api["dashboard_v2"] = True
    except Exception:
        api["dashboard_v2"] = False

    return jsonify({
        "ok": ok,
        "who": "VSP_SELFCHECK_P0_V2_HARDEN",
        "ts": int(_VSP_time.time()),
        "findings_src": str(src),
        "findings_total": int(total),
        "api": api,
        "warnings": warnings,
        "notes": notes,
    })
# === /VSP_SELFCHECK_P0_V2_HARDEN ===


# === VSP_RULE_OVERRIDES_EDITOR_P0_V1 ===
from pathlib import Path as _VSP_Path
import time as _VSP_time
import json as _VSP_json

_VSP_RULE_OVR_PATH = _VSP_Path("out_ci/rule_overrides.json").resolve()
_VSP_RULE_OVR_PATH.parent.mkdir(parents=True, exist_ok=True)

def _vsp_rule_ovr_default():
    return {
        "enabled": True,
        "updated_by": "system",
        "updated_at": int(_VSP_time.time()),
        "overrides": []
    }

@app.get("/rule_overrides")
def vsp_rule_overrides_page():
    return render_template("vsp_rule_overrides_v1.html")

@app.get("/api/vsp/rule_overrides")
def vsp_api_rule_overrides_get():
    try:
        if _VSP_RULE_OVR_PATH.exists():
            data = _VSP_json.loads(_VSP_RULE_OVR_PATH.read_text(encoding="utf-8", errors="replace") or "{}")
        else:
            data = _vsp_rule_ovr_default()
        return jsonify({
            "ok": True,
            "who": "VSP_RULE_OVERRIDES_EDITOR_P0_V1",
            "ts": int(_VSP_time.time()),
            "path": str(_VSP_RULE_OVR_PATH),
            "data": data,
        })
    except Exception as e:
        return jsonify({"ok": False, "who":"VSP_RULE_OVERRIDES_EDITOR_P0_V1", "error": "READ_FAIL", "exc": str(e)}), 500

@app.post("/api/vsp/rule_overrides")
def vsp_api_rule_overrides_post():
    try:
        body = request.get_json(silent=True) or {}
        data = body.get("data")
        if data is None:
            return jsonify({"ok": False, "error": "MISSING_DATA"}), 400

        # backup old if exists
        backup = None
        if _VSP_RULE_OVR_PATH.exists():
            ts = _VSP_time.strftime("%Y%m%d_%H%M%S", _VSP_time.localtime())
            backup = str(_VSP_RULE_OVR_PATH) + ".bak_" + ts
            _VSP_Path(backup).write_text(_VSP_RULE_OVR_PATH.read_text(encoding="utf-8", errors="replace"), encoding="utf-8")

        # stamp
        try:
            if isinstance(data, dict):
                data.setdefault("updated_at", int(_VSP_time.time()))
        except Exception:
            pass

        _VSP_RULE_OVR_PATH.write_text(_VSP_json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return jsonify({
            "ok": True,
            "who": "VSP_RULE_OVERRIDES_EDITOR_P0_V1",
            "path": str(_VSP_RULE_OVR_PATH),
            "backup": backup,
            "ts": int(_VSP_time.time()),
        })
    except Exception as e:
        return jsonify({"ok": False, "who":"VSP_RULE_OVERRIDES_EDITOR_P0_V1", "error": "WRITE_FAIL", "exc": str(e)}), 500
# === /VSP_RULE_OVERRIDES_EDITOR_P0_V1 ===


# === VSP_DATA_SOURCE_TAB_P0_V1 ===
@app.get("/data")
def vsp_data_source_tab_p0_v1():
    # Commercial Data Source tab (safe: purely reads via /api/vsp/findings on the client)
    return render_template("vsp_data_source_2025.html")
# === /VSP_DATA_SOURCE_TAB_P0_V1 ===


# === VSP_FINDINGS_API_SOURCE_P0_V1 ===
def _vsp_sb_root_p0_v1():
    # ui/ is under SECURITY_BUNDLE/ui; SECURITY_BUNDLE is parent dir
    try:
        return Path(__file__).resolve().parent.parent
    except Exception:
        return Path.cwd().parent

def _vsp_pick_latest_findings_unified_json_p0_v1():
    """Pick best findings_unified.json source.
    Priority:
      1) latest RUN_*/reports/findings_unified.json
      2) latest RUN_*/findings_unified.json
      3) ui/out_ci/findings_unified.json
      4) ui/findings_unified.json (legacy)
    """
    ui_dir = Path(__file__).resolve().parent
    sb = _vsp_sb_root_p0_v1()
    out_dir = sb / "out"

    candidates = []

    # (1)(2) from out/RUN_*
    try:
        if out_dir.is_dir():
            runs = [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_")]
            runs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            for rd in runs[:50]:
                a = rd / "reports" / "findings_unified.json"
                b = rd / "findings_unified.json"
                if a.is_file():
                    return a
                if b.is_file():
                    return b
    except Exception:
        pass

    # (3)(4) local fallbacks
    c = ui_dir / "out_ci" / "findings_unified.json"
    if c.is_file():
        return c
    d = ui_dir / "findings_unified.json"
    if d.is_file():
        return d

    return None

def _vsp_load_findings_unified_p0_v1():
    p = _vsp_pick_latest_findings_unified_json_p0_v1()
    if not p:
        return {"ok": True, "items": [], "findings": [], "total": 0, "notes": ["missing findings_unified.json"], "src": None}
    try:
        data = json.loads(p.read_text(encoding="utf-8", errors="replace") or "{}")
    except Exception as e:
        return {"ok": False, "items": [], "findings": [], "total": 0, "notes": [f"parse error: {e}"], "src": str(p)}

    # normalize items
    items = []
    if isinstance(data, dict):
        if isinstance(data.get("items"), list):
            items = data.get("items") or []
        elif isinstance(data.get("findings"), list):
            items = data.get("findings") or []
        else:
            # sometimes nested
            x = data.get("data") or {}
            if isinstance(x, dict) and isinstance(x.get("items"), list):
                items = x.get("items") or []
    elif isinstance(data, list):
        items = data

    if isinstance(data, dict):
        data["items"] = items
        data["items_len"] = len(items)
        data["total"] = int(data.get("total") or len(items) or 0)
        data["src"] = str(p)
        data.setdefault("ok", True)
        return data

    return {"ok": True, "items": items, "items_len": len(items), "total": len(items), "src": str(p)}

# Explicit endpoint to stop fallback shadowing
@app.get("/api/vsp/findings")
def vsp_findings_api_p0_v1():
    d = _vsp_load_findings_unified_p0_v1()
    items = d.get("items") if isinstance(d, dict) else []
    return jsonify({
        "ok": bool(d.get("ok", True)) if isinstance(d, dict) else True,
        "items": items if isinstance(items, list) else [],
        "items_len": int(d.get("items_len") or (len(items) if isinstance(items, list) else 0)),
        "src": d.get("src") if isinstance(d, dict) else None,
        "run_dir": d.get("run_dir") if isinstance(d, dict) else None,
        "notes": d.get("notes", []) if isinstance(d, dict) else [],
    })

# Make /findings_unified.json consistent (commercial): always serve latest source, not stale local file
@app.get("/findings_unified.json")
def findings_unified_json_p0_v1():
    return jsonify(_vsp_load_findings_unified_p0_v1())
# === /VSP_FINDINGS_API_SOURCE_P0_V1 ===

# === VSP_EXPORT_ZIP_P0_V3 ===
from flask import send_file, request
import json as _json
import time as _time
import zipfile as _zipfile
from pathlib import Path as _Path

def _vsp_export_find_candidates_p0_v3(run_dir: _Path):
    """Return list of (src_path, arcname). Auto-discover key artifacts with guards."""
    picks = []
    seen = set()

    def add(p: _Path, arc: str):
        if arc in seen:
            return
        try:
            if not p.is_file():
                return
            # size guard per file
            if p.stat().st_size > 50_000_000:
                return
        except Exception:
            return
        seen.add(arc)
        picks.append((p, arc))

    # (A) exact common locations
    for name in [
        "SUMMARY.txt", "SHA256SUMS.txt","run_gate.json","run_gate_summary.json","run_manifest.json","run_evidence_index.json",
        "findings_unified.json","findings_unified.csv","findings_unified.sarif",
        "verdict_4t.json","nurl_audit_latest.json"
    ]:
        add(run_dir / name, name)
        add(run_dir / "reports" / name, f"reports/{name}")
        add(run_dir / "report" / name, f"report/{name}")

    # (B) auto-discover summaries & reports (depth-limited)
    # allowlist patterns
    allow_names = set([
        "SUMMARY.txt", "SHA256SUMS.txt",
        "findings_unified.json","findings_unified.csv","findings_unified.sarif",
        "run_gate.json","run_gate_summary.json",
        "run_manifest.json","run_evidence_index.json",
        "index.html","report.html",
    ])

    # also include *_summary.json small files
    try:
        for p in run_dir.rglob("*_summary.json"):
            if p.is_file():
                try:
                    if p.stat().st_size <= 5_000_000:
                        add(p, str(p.relative_to(run_dir)))
                except Exception:
                    pass
    except Exception:
        pass

    # include allow_names anywhere under run_dir (first N hits each)
    counts = {}
    try:
        for p in run_dir.rglob("*"):
            if not p.is_file():
                continue
            nm = p.name
            if nm in allow_names:
                counts[nm] = counts.get(nm, 0) + 1
                # cap per filename to avoid explosion
                if counts[nm] <= 10:
                    add(p, str(p.relative_to(run_dir)))
    except Exception:
        pass

    # (C) always add a compact listing for audit (we will write separately too)
    return picks

def _vsp_export_build_listing_p0_v3(run_dir: _Path, max_lines: int = 8000) -> str:
    lines = []
    lines.append(f"run_dir={run_dir}")
    try:
        items = []
        for p in run_dir.rglob("*"):
            try:
                if p.is_file():
                    sz = p.stat().st_size
                    rp = str(p.relative_to(run_dir))
                    items.append((rp, sz))
            except Exception:
                pass
        items.sort(key=lambda x: x[0])
        lines.append(f"files={len(items)}")
        for i,(rp,sz) in enumerate(items[:max_lines]):
            lines.append(f"{sz}\t{rp}")
        if len(items) > max_lines:
            lines.append(f"... truncated: {len(items)-max_lines} more")
    except Exception as e:
        lines.append(f"listing_error={e}")
    return "\n".join(lines) + "\n"

@app.get("/api/vsp/export_zip")
def vsp_export_zip_p0_v3():
    run_id = (request.args.get("run_id") or "").strip()
    if not run_id:
        return jsonify({"ok": False, "error": "missing run_id"}), 400

    ui_dir = _Path(__file__).resolve().parent
    sb = ui_dir.parent
    out_dir = sb / "out"
    run_dir = out_dir / run_id
    if not run_dir.is_dir():
        return jsonify({"ok": False, "error": "run_id not found", "run_dir": str(run_dir)}), 404

    exp_dir = ui_dir / "out_ci" / "exports"
    exp_dir.mkdir(parents=True, exist_ok=True)
    ts = _time.strftime("%Y%m%d_%H%M%S")
    zip_path = exp_dir / f"VSP_EXPORT_{run_id}_{ts}.zip"

    # selfcheck snapshot (best-effort)
    try:
        sc = selfcheck_p0().get_json()  # type: ignore
    except Exception as e:
        sc = {"ok": False, "error": f"selfcheck snapshot failed: {e}"}

    # findings fallback (UI unified) if run has none
    fallback_findings = None
    try:
        fallback_findings = _vsp_load_findings_unified_p0_v1()  # type: ignore
    except Exception:
        fallback_findings = None

    picks = _vsp_export_find_candidates_p0_v3(run_dir)
    listing = _vsp_export_build_listing_p0_v3(run_dir)

    # total guard (avoid huge zip)
    MAX_FILES = 250
    MAX_TOTAL = 80_000_000
    total = 0
    kept = []
    for src, arc in picks:
        try:
            sz = src.stat().st_size
        except Exception:
            continue
        if len(kept) >= MAX_FILES:
            break
        if total + sz > MAX_TOTAL:
            continue
        kept.append((src, arc))
        total += sz

    with _zipfile.ZipFile(zip_path, "w", compression=_zipfile.ZIP_DEFLATED) as zf:
        man = {
            "ok": True,
            "run_id": run_id,
            "run_dir": str(run_dir),
            "generated_at": ts,
            "picked_files": [arc for _, arc in kept],
            "picked_count": len(kept),
            "picked_total_bytes": total,
        }
        zf.writestr("MANIFEST.json", _json.dumps(man, indent=2, ensure_ascii=False) + "\n")
        zf.writestr("AUDIT/selfcheck_p0_snapshot.json", _json.dumps(sc, indent=2, ensure_ascii=False) + "\n")
        zf.writestr("AUDIT/run_dir_listing.tsv", listing)

        for src, arc in kept:
            try:
                zf.write(str(src), arc)
            except Exception:
                pass

        has_findings = any(arc.endswith("findings_unified.json") for _, arc in kept)
        if (not has_findings) and isinstance(fallback_findings, dict):
            try:
                zf.writestr("findings_unified.json", _json.dumps(fallback_findings, indent=2, ensure_ascii=False) + "\n")
            except Exception:
                pass

    return send_file(str(zip_path), as_attachment=True, download_name=zip_path.name, mimetype="application/zip")
# === /VSP_EXPORT_ZIP_P0_V3 ===

# VSP_P1_EXPORT_TGZ_CSV_SHA_V1
from flask import request, jsonify, send_file
import tarfile, hashlib, tempfile, time
from pathlib import Path

def _vsp_try_resolve_run_dir(rid: str):
    # Prefer existing resolver if present
    for name in ("resolve_run_dir", "vsp_resolve_run_dir", "get_run_dir_by_rid", "resolve_rid_to_dir"):
        fn = globals().get(name)
        if callable(fn):
            try:
                d = fn(rid)
                if d:
                    d = Path(d)
                    if d.exists():
                        return d
            except Exception:
                pass

    # Fallback scan
    bases = [
        Path("/home/test/Data/SECURITY_BUNDLE/out"),
        Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
    ]
    env = os.environ.get("VSP_RUNS_ROOT")
    if env:
        bases.insert(0, Path(env))
    for b in bases:
        try:
            d = b / rid
            if d.exists():
                return d
            # search shallow
            for cand in b.glob(f"**/{rid}"):
                if cand.is_dir():
                    return cand
        except Exception:
            continue
    return None

def _sha256_path(fp: Path) -> str:
    h = hashlib.sha256()
    with fp.open("rb") as f:
        for ch in iter(lambda: f.read(1024*1024), b""):
            h.update(ch)
    return h.hexdigest()

@app.route("/api/vsp/export_tgz")
def vsp_export_tgz():
    rid = request.args.get("rid","").strip()
    scope = (request.args.get("scope","reports") or "reports").strip()
    if not rid:
        return jsonify({"ok": False, "err": "missing rid"}), 400
    run_dir = _vsp_try_resolve_run_dir(rid)
    if not run_dir:
        return jsonify({"ok": False, "err": "rid not found", "rid": rid}), 404

    src = run_dir if scope == "run" else (run_dir / "reports")
    if not src.exists():
        return jsonify({"ok": False, "err": "scope not found", "scope": scope}), 404

    out_dir = Path("out_ci/exports")
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    out = out_dir / f"{rid}.{scope}.{ts}.tgz"

    with tarfile.open(out, "w:gz") as tar:
        tar.add(src, arcname=src.name)

    return send_file(out, mimetype="application/gzip", as_attachment=True, download_name=out.name)

@app.route("/api/vsp/export_csv")
def vsp_export_csv():
    rid = request.args.get("rid","").strip()
    if not rid:
        return jsonify({"ok": False, "err": "missing rid"}), 400
    run_dir = _vsp_try_resolve_run_dir(rid)
    if not run_dir:
        return jsonify({"ok": False, "err": "rid not found", "rid": rid}), 404

    # Prefer existing CSV
    csvp = run_dir / "reports" / "findings_unified.csv"
    if csvp.exists():
        return send_file(csvp, mimetype="text/csv", as_attachment=True, download_name=f"{rid}.findings_unified.csv")

    # Generate minimal CSV from findings_unified.json
    import csv, json
    jp = run_dir / "reports" / "findings_unified.json"
    if not jp.exists():
        jp = run_dir / "findings_unified.json"
    items = []
    try:
        obj = json.loads(jp.read_text(encoding="utf-8", errors="replace"))
        items = obj.get("items") if isinstance(obj, dict) else []
        if items is None: items=[]
    except Exception:
        items = []

    out_dir = Path("out_ci/exports")
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    out = out_dir / f"{rid}.findings_unified.{ts}.csv"

    cols = ["tool","severity","title","rule_id","file","line","message"]
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for it in items:
            if not isinstance(it, dict): 
                continue
            w.writerow({
                "tool": it.get("tool",""),
                "severity": it.get("severity",""),
                "title": it.get("title","") or it.get("name",""),
                "rule_id": it.get("rule_id","") or it.get("id",""),
                "file": it.get("path","") or it.get("file",""),
                "line": it.get("line","") or it.get("start_line",""),
                "message": it.get("message","") or it.get("description",""),
            })

    return send_file(out, mimetype="text/csv", as_attachment=True, download_name=out.name)

@app.route("/api/vsp/sha256")
def vsp_sha256():
    rid = request.args.get("rid","").strip()
    name = request.args.get("name","").strip()
    if not rid or not name:
        return jsonify({"ok": False, "err": "missing rid or name"}), 400
    run_dir = _vsp_try_resolve_run_dir(rid)
    if not run_dir:
        return jsonify({"ok": False, "err": "rid not found", "rid": rid}), 404

    # allow only relative under run_dir
    rel = name.lstrip("/").replace("..","")
    fp = (run_dir / rel).resolve()
    if not str(fp).startswith(str(run_dir.resolve())):
        return jsonify({"ok": False, "err": "invalid name"}), 400
    if not fp.exists():
        return jsonify({"ok": False, "err": "file not found", "name": rel}), 404

    return jsonify({"ok": True, "rid": rid, "name": rel, "sha256": _sha256_path(fp), "bytes": fp.stat().st_size})


# VSP_FORCE_ALLOW_SHA256SUMS_RUN_FILE_V1

# VSP_P1_FIX_SUMMARY_SHA_SYNTAX_V1


# ===== VSP_P0_ROUTE_ALIAS_VSP5_RUNS_V1 =====
try:
    @app.route("/vsp5/runs")
    def vsp5_runs_alias_v1():
        # keep commercial UX: no 404; unify to /runs
        return redirect("/runs", code=302)
except Exception:
    pass
# ===== end VSP_P0_ROUTE_ALIAS_VSP5_RUNS_V1 =====


# ===== VSP_P0_ROUTE_ALIAS_VSP5_RUNS_V2 =====
try:
    # prefer app if exists
    _app = globals().get("app", None)
    if _app is not None:
        @_app.route("/vsp5/runs")
        def vsp5_runs_alias_v2():
            from flask import redirect
            return redirect("/runs", code=302)
    # or blueprint if app not present
    _bp = globals().get("bp", None) or globals().get("runs_bp", None)
    if _bp is not None:
        @_bp.route("/vsp5/runs")
        def vsp5_runs_alias_bp_v2():
            from flask import redirect
            return redirect("/runs", code=302)
except Exception:
    pass
# ===== end VSP_P0_ROUTE_ALIAS_VSP5_RUNS_V2 =====



# --- VSP_P1_RUN_FILE_WHITELIST_V1: safe read-only run_file endpoint (whitelist; no traversal) ---
def _vsp_p1_register_run_file_whitelist_v1():
    try:
        import os, mimetypes
        from pathlib import Path
        from flask import request, jsonify, abort, send_file
    except Exception:
        return

    app_obj = globals().get("app", None)
    if app_obj is None or not hasattr(app_obj, "add_url_rule"):
        # fallback: some deployments might expose `application`
        app_obj = globals().get("application", None)
    if app_obj is None or not hasattr(app_obj, "add_url_rule"):
        return

    # avoid double-register
    try:
        if hasattr(app_obj, "view_functions") and ("vsp_run_file_whitelist_v1" in app_obj.view_functions):
            return
    except Exception:
        pass

    # base dirs to locate runs (best-effort; adjust by env if needed)
    BASE_DIRS = [
        os.environ.get("VSP_OUT_DIR", "") or "",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    ]
    BASE_DIRS = [d for d in BASE_DIRS if d and os.path.isdir(d)]

    # strict whitelist of readable files (relative to run_dir)
    ALLOW = {
        "run_gate.json",
        "run_gate_summary.json",
        "findings_unified.json",
        "findings_unified.sarif",
        "reports/findings_unified.csv",
      "reports/run_gate_summary.json",
      "reports/run_gate.json",
        "reports/findings_unified.html",
        "reports/findings_unified.tgz",
        "reports/findings_unified.zip",
        "SUMMARY.txt",
    }

    _CACHE = {"rid2dir": {}}

    def _safe_rel(path: str) -> str:
        if not path:
            return ""
        path = path.strip().lstrip("/")  # no absolute
        if ".." in path.split("/"):
            return ""
        # collapse repeated slashes
        while "//" in path:
            path = path.replace("//", "/")
        return path

    def _find_run_dir(rid: str) -> Path | None:
        rid = (rid or "").strip()
        if not rid:
            return None
        if rid in _CACHE["rid2dir"]:
            pr = _CACHE["rid2dir"][rid]
            return Path(pr) if pr else None

        # 1) direct join base/rid
        for b in BASE_DIRS:
            cand = Path(b) / rid
            if cand.is_dir():
                _CACHE["rid2dir"][rid] = str(cand)
                return cand

        # 2) shallow search: base/*/rid and base/*/*/rid (bounded)
        for b in BASE_DIRS:
            base = Path(b)
            try:
                # depth 1
                for d1 in base.iterdir():
                    if not d1.is_dir():
                        continue
                    cand = d1 / rid
                    if cand.is_dir():
                        _CACHE["rid2dir"][rid] = str(cand)
                        return cand
                # depth 2
                for d1 in base.iterdir():
                    if not d1.is_dir():
                        continue
                    for d2 in d1.iterdir():
                        if not d2.is_dir():
                            continue
                        cand = d2 / rid
                        if cand.is_dir():
                            _CACHE["rid2dir"][rid] = str(cand)
                            return cand
            except Exception:
                continue

        _CACHE["rid2dir"][rid] = ""
        return None

    def _max_bytes(rel: str) -> int:
        # keep safe limits
        if rel.endswith(".tgz") or rel.endswith(".zip"):
            return 200 * 1024 * 1024
        if rel.endswith(".html"):
            return 80 * 1024 * 1024
        return 25 * 1024 * 1024

    def vsp_run_file_whitelist_v1():
        rid = (request.args.get("rid") or "").strip()
        rel = _safe_rel(request.args.get("path") or "")
        if not rid or not rel:
            return jsonify({"ok": False, "err": "missing rid/path"}), 400
        if rel not in ALLOW:
            return jsonify({"ok": False, "err": "path not allowed", "allow": sorted(ALLOW)}), 403

        run_dir = _find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "run_dir not found", "rid": rid}), 404

        fp = (run_dir / rel)
        try:
            # prevent escape via symlink / traversal
            fp_res = fp.resolve()
            rd_res = run_dir.resolve()
            if rd_res not in fp_res.parents and fp_res != rd_res:
                return jsonify({"ok": False, "err": "blocked escape"}), 403
        except Exception:
            return jsonify({"ok": False, "err": "resolve failed"}), 403

        if not fp.exists() or not fp.is_file():
            return jsonify({"ok": False, "err": "file not found", "path": rel}), 404

        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        if sz >= 0 and sz > _max_bytes(rel):
            return jsonify({"ok": False, "err": "file too large", "size": sz, "limit": _max_bytes(rel)}), 413

        mime, _ = mimetypes.guess_type(str(fp))
        mime = mime or "application/octet-stream"

        # inline for json/html/csv, attachment for archives
        as_attach = rel.endswith(".tgz") or rel.endswith(".zip")
        dl_name = f"{rid}__{rel.replace('/','_')}"

        return send_file(str(fp), mimetype=mime, as_attachment=as_attach, download_name=dl_name)

    try:
        app_obj.add_url_rule("/api/vsp/run_file", "vsp_run_file_whitelist_v1", vsp_run_file_whitelist_v1, methods=["GET"])
        print("[VSP_RUN_FILE] registered /api/vsp/run_file (whitelist)")
    except Exception as e:
        print("[VSP_RUN_FILE] register failed:", e)

# register on import
try:
    _vsp_p1_register_run_file_whitelist_v1()
except Exception:
    pass
# --- end VSP_P1_RUN_FILE_WHITELIST_V1 ---


# VSP_P1_RUN_FILE_WHITELIST_V2_MOUNT
# --- VSP_P1_RUN_FILE_WHITELIST_V2_MOUNT: safe run_file endpoint (whitelist + no traversal) ---
def _vsp_p1_run_file_register_v2(app_obj):
    try:
        import os, mimetypes
        from pathlib import Path
        from flask import request, jsonify, send_file
    except Exception:
        return False

    if not app_obj or not hasattr(app_obj, "add_url_rule"):
        return False

    try:
        if hasattr(app_obj, "view_functions") and ("vsp_run_file_whitelist_v2" in app_obj.view_functions):
            return True
    except Exception:
        pass

    BASE_DIRS = [
        os.environ.get("VSP_OUT_DIR", "") or "",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    ]
    BASE_DIRS = [d for d in BASE_DIRS if d and os.path.isdir(d)]

    ALLOW = {
        "run_gate.json",
        "run_gate_summary.json",
        "findings_unified.json",
        "findings_unified.sarif",
        "reports/findings_unified.csv",
        "reports/findings_unified.html",
        "reports/findings_unified.tgz",
        "reports/findings_unified.zip",
        "SUMMARY.txt",
    }

    _CACHE = {"rid2dir": {}}

    def _safe_rel(path: str) -> str:
        if not path:
            return ""
        path = path.strip().lstrip("/")
        if ".." in path.split("/"):
            return ""
        while "//" in path:
            path = path.replace("//", "/")
        return path

    def _max_bytes(rel: str) -> int:
        if rel.endswith(".tgz") or rel.endswith(".zip"):
            return 200 * 1024 * 1024
        if rel.endswith(".html"):
            return 80 * 1024 * 1024
        return 25 * 1024 * 1024

    def _find_run_dir(rid: str):
        rid = (rid or "").strip()
        if not rid:
            return None
        if rid in _CACHE["rid2dir"]:
            v = _CACHE["rid2dir"][rid]
            return Path(v) if v else None

        for b in BASE_DIRS:
            cand = Path(b) / rid
            if cand.is_dir():
                _CACHE["rid2dir"][rid] = str(cand)
                return cand

        # bounded shallow search
        for b in BASE_DIRS:
            base = Path(b)
            try:
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    cand = d1 / rid
                    if cand.is_dir():
                        _CACHE["rid2dir"][rid] = str(cand)
                        return cand
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    for d2 in d1.iterdir():
                        if not d2.is_dir(): continue
                        cand = d2 / rid
                        if cand.is_dir():
                            _CACHE["rid2dir"][rid] = str(cand)
                            return cand
            except Exception:
                continue

        _CACHE["rid2dir"][rid] = ""
        return None

    def vsp_run_file_whitelist_v2():
        rid = (request.args.get("rid") or "").strip()
        rel = _safe_rel(request.args.get("path") or "")
        if not rid or not rel:
            return jsonify({"ok": False, "err": "missing rid/path"}), 400
        if rel not in ALLOW:
            return jsonify({"ok": False, "err": "path not allowed", "allow": sorted(ALLOW)}), 403

        run_dir = _find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "run_dir not found", "rid": rid, "roots_used": BASE_DIRS}), 404

        fp = (run_dir / rel)
        try:
            fp_res = fp.resolve()
            rd_res = run_dir.resolve()
            if rd_res not in fp_res.parents and fp_res != rd_res:
                return jsonify({"ok": False, "err": "blocked escape"}), 403
        except Exception:
            return jsonify({"ok": False, "err": "resolve failed"}), 403

        if not fp.exists() or not fp.is_file():
            return jsonify({"ok": False, "err": "file not found", "path": rel}), 404

        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        lim = _max_bytes(rel)
        if sz >= 0 and sz > lim:
            return jsonify({"ok": False, "err": "file too large", "size": sz, "limit": lim}), 413

        mime, _ = mimetypes.guess_type(str(fp))
        mime = mime or "application/octet-stream"
        as_attach = rel.endswith(".tgz") or rel.endswith(".zip")
        dl_name = f"{rid}__{rel.replace('/','_')}"
        return send_file(str(fp), mimetype=mime, as_attachment=as_attach, download_name=dl_name)

    try:
        app_obj.add_url_rule("/api/vsp/run_file", "vsp_run_file_whitelist_v2", vsp_run_file_whitelist_v2, methods=["GET"])
        print("[VSP_RUN_FILE] mounted /api/vsp/run_file (v2 whitelist)")
        return True
    except Exception as e:
        print("[VSP_RUN_FILE] mount failed:", e)
        return False
# --- end VSP_P1_RUN_FILE_WHITELIST_V2_MOUNT ---

# auto-register run_file on import (best-effort)
try:
    _app = globals().get("app", None) or globals().get("application", None)
    _vsp_p1_run_file_register_v2(_app)
except Exception:
    pass


# VSP_P1_RUN_FILE_FINDER_FALLBACK_V3
# --- VSP_P1_RUN_FILE_FINDER_FALLBACK_V3: upgrade run_file handler to find run_dir robustly + fallback gate ---
def _vsp_p1_run_file_upgrade_v3(app_obj):
    try:
        import os, time, mimetypes
        from pathlib import Path
        from flask import request, jsonify, send_file
    except Exception:
        return False

    if not app_obj or not hasattr(app_obj, "add_url_rule"):
        return False

    # base roots (fast path)
    BASE_DIRS = [
        os.environ.get("VSP_OUT_DIR", "") or "",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",  # common in your env (safe to include)
    ]
    BASE_DIRS = [d for d in BASE_DIRS if d and os.path.isdir(d)]

    # bounded deep finder root (slow path, only on demand)
    DEEP_ROOT = os.environ.get("VSP_DEEP_RUN_ROOT", "/home/test/Data")
    if not os.path.isdir(DEEP_ROOT):
        DEEP_ROOT = ""

    ALLOW = {
        "run_gate.json",
        "run_gate_summary.json",
        "findings_unified.json",
        "findings_unified.sarif",
        "reports/findings_unified.csv",
        "reports/findings_unified.html",
        "reports/findings_unified.tgz",
        "reports/findings_unified.zip",
        "SUMMARY.txt",
    }

    _CACHE = {"rid2dir": {}}

    def _safe_rel(path: str) -> str:
        if not path:
            return ""
        path = path.strip().lstrip("/")
        if ".." in path.split("/"):
            return ""
        while "//" in path:
            path = path.replace("//", "/")
        return path

    def _max_bytes(rel: str) -> int:
        if rel.endswith(".tgz") or rel.endswith(".zip"):
            return 200 * 1024 * 1024
        if rel.endswith(".html"):
            return 80 * 1024 * 1024
        return 25 * 1024 * 1024

    def _deep_find_dir(rid: str):
        """Bounded os.walk: depth<=6, stop after ~40k dirs or 2.5s."""
        if not DEEP_ROOT:
            return None
        start = time.time()
        max_secs = 2.5
        max_dirs = 40000
        seen = 0

        root = Path(DEEP_ROOT)
        root_depth = len(root.parts)

        try:
            for cur, dirs, files in os.walk(root, topdown=True):
                seen += 1
                if seen > max_dirs or (time.time() - start) > max_secs:
                    return None
                pcur = Path(cur)
                depth = len(pcur.parts) - root_depth
                if depth > 6:
                    dirs[:] = []
                    continue
                # prune heavy dirs (safe)
                prune = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build"}
                dirs[:] = [d for d in dirs if d not in prune]
                if pcur.name == rid:
                    return pcur
        except Exception:
            return None
        return None

    def _find_run_dir(rid: str):
        rid = (rid or "").strip()
        if not rid:
            return None
        if rid in _CACHE["rid2dir"]:
            v = _CACHE["rid2dir"][rid]
            return Path(v) if v else None

        # fast: direct join
        for b in BASE_DIRS:
            cand = Path(b) / rid
            if cand.is_dir():
                _CACHE["rid2dir"][rid] = str(cand)
                return cand

        # fast: shallow search depth 2
        for b in BASE_DIRS:
            base = Path(b)
            try:
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    cand = d1 / rid
                    if cand.is_dir():
                        _CACHE["rid2dir"][rid] = str(cand)
                        return cand
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    for d2 in d1.iterdir():
                        if not d2.is_dir(): continue
                        cand = d2 / rid
                        if cand.is_dir():
                            _CACHE["rid2dir"][rid] = str(cand)
                            return cand
            except Exception:
                pass

        # slow: deep find (bounded)
        cand = _deep_find_dir(rid)
        if cand and cand.is_dir():
            _CACHE["rid2dir"][rid] = str(cand)
            return cand

        _CACHE["rid2dir"][rid] = ""
        return None

    def _resolve_safe(run_dir: Path, rel: str) -> Path | None:
        fp = (run_dir / rel)
        try:
            fp_res = fp.resolve()
            rd_res = run_dir.resolve()
            if rd_res not in fp_res.parents and fp_res != rd_res:
                return None
            return fp_res
        except Exception:
            return None

    def vsp_run_file_handler_v3():
        rid = (request.args.get("rid") or "").strip()
        rel = _safe_rel(request.args.get("path") or "")
        if not rid or not rel:
            return jsonify({"ok": False, "err": "missing rid/path"}), 400
        if rel not in ALLOW:
            return jsonify({"ok": False, "err": "path not allowed", "allow": sorted(ALLOW)}), 403

        run_dir = _find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "run_dir not found", "rid": rid, "roots_used": BASE_DIRS, "deep_root": DEEP_ROOT}), 404

        # fallback: if asking run_gate.json but missing, try summary
        rel_try = [rel]
        if rel == "run_gate.json":
            rel_try = ["run_gate.json", "run_gate_summary.json", "SUMMARY.txt"]

        picked = None
        for rr in rel_try:
            fp = _resolve_safe(run_dir, rr)
            if fp and fp.exists() and fp.is_file():
                picked = (rr, fp)
                break

        if not picked:
            # return helpful list of what exists among allowed
            exists = []
            for rr in sorted(ALLOW):
                fp = _resolve_safe(run_dir, rr)
                if fp and fp.exists() and fp.is_file():
                    exists.append(rr)
            return jsonify({"ok": False, "err": "file not found", "rid": rid, "path": rel, "run_dir": str(run_dir), "has": exists}), 404

        rr, fp = picked
        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        lim = _max_bytes(rr)
        if sz >= 0 and sz > lim:
            return jsonify({"ok": False, "err": "file too large", "size": sz, "limit": lim, "path": rr}), 413

        mime, _ = mimetypes.guess_type(str(fp))
        mime = mime or "application/octet-stream"
        as_attach = rr.endswith(".tgz") or rr.endswith(".zip")
        dl_name = f"{rid}__{rr.replace('/','_')}"
        resp = send_file(str(fp), mimetype=mime, as_attachment=as_attach, download_name=dl_name)
        try:
            if rr != rel:
                resp.headers["X-VSP-Fallback-Path"] = rr
        except Exception:
            pass
        return resp

    # prefer upgrade existing endpoint (your URL rule is already there)
    try:
        vf = getattr(app_obj, "view_functions", {}) or {}
        if "vsp_run_file_whitelist_v2" in vf:
            vf["vsp_run_file_whitelist_v2"] = vsp_run_file_handler_v3
            print("[VSP_RUN_FILE] upgraded endpoint v2 -> v3 handler")
            return True
    except Exception:
        pass

    # otherwise mount fresh
    try:
        app_obj.add_url_rule("/api/vsp/run_file", "vsp_run_file_handler_v3", vsp_run_file_handler_v3, methods=["GET"])
        print("[VSP_RUN_FILE] mounted /api/vsp/run_file (v3)")
        return True
    except Exception as e:
        print("[VSP_RUN_FILE] mount v3 failed:", e)
        return False
# --- end VSP_P1_RUN_FILE_FINDER_FALLBACK_V3 ---

try:
    _vsp_p1_run_file_upgrade_v3(globals().get('app') or globals().get('application'))
except Exception:
    pass


# VSP_P1_FORCE_RUN_FILE_HANDLER_V4
# --- VSP_P1_FORCE_RUN_FILE_HANDLER_V4: force-bind /api/vsp/run_file to whitelist handler (override any "not allowed") ---
def _vsp_p1_force_run_file_handler_v4(app_obj):
    try:
        import os, time, mimetypes
        from pathlib import Path
        from flask import request, jsonify, send_file
    except Exception:
        return False

    if not app_obj or not hasattr(app_obj, "url_map") or not hasattr(app_obj, "view_functions"):
        return False

    BASE_DIRS = [
        os.environ.get("VSP_OUT_DIR", "") or "",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]
    BASE_DIRS = [d for d in BASE_DIRS if d and os.path.isdir(d)]

    DEEP_ROOT = os.environ.get("VSP_DEEP_RUN_ROOT", "/home/test/Data")
    if not os.path.isdir(DEEP_ROOT):
        DEEP_ROOT = ""

    ALLOW = {
        "run_gate.json",
        "run_gate_summary.json",
        "findings_unified.json",
        "findings_unified.sarif",
        "reports/findings_unified.csv",
        "reports/findings_unified.html",
        "reports/findings_unified.tgz",
        "reports/findings_unified.zip",
        "SUMMARY.txt",
    }

    _CACHE = {"rid2dir": {}}

    def _safe_rel(path: str) -> str:
        if not path:
            return ""
        path = path.strip().lstrip("/")
        if ".." in path.split("/"):
            return ""
        while "//" in path:
            path = path.replace("//", "/")
        return path

    def _max_bytes(rel: str) -> int:
        if rel.endswith(".tgz") or rel.endswith(".zip"):
            return 200 * 1024 * 1024
        if rel.endswith(".html"):
            return 80 * 1024 * 1024
        return 25 * 1024 * 1024

    def _deep_find_dir(rid: str):
        if not DEEP_ROOT:
            return None
        start = time.time()
        max_secs = 2.5
        max_dirs = 40000
        seen = 0
        root = Path(DEEP_ROOT)
        root_depth = len(root.parts)
        prune = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build"}

        try:
            for cur, dirs, files in os.walk(root, topdown=True):
                seen += 1
                if seen > max_dirs or (time.time() - start) > max_secs:
                    return None
                pcur = Path(cur)
                depth = len(pcur.parts) - root_depth
                if depth > 6:
                    dirs[:] = []
                    continue
                dirs[:] = [d for d in dirs if d not in prune]
                if pcur.name == rid:
                    return pcur
        except Exception:
            return None
        return None

    def _find_run_dir(rid: str):
        rid = (rid or "").strip()
        if not rid:
            return None
        if rid in _CACHE["rid2dir"]:
            v = _CACHE["rid2dir"][rid]
            return Path(v) if v else None

        # direct
        for b in BASE_DIRS:
            cand = Path(b) / rid
            if cand.is_dir():
                _CACHE["rid2dir"][rid] = str(cand)
                return cand

        # shallow depth 2
        for b in BASE_DIRS:
            base = Path(b)
            try:
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    cand = d1 / rid
                    if cand.is_dir():
                        _CACHE["rid2dir"][rid] = str(cand)
                        return cand
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    for d2 in d1.iterdir():
                        if not d2.is_dir(): continue
                        cand = d2 / rid
                        if cand.is_dir():
                            _CACHE["rid2dir"][rid] = str(cand)
                            return cand
            except Exception:
                pass

        # deep bounded
        cand = _deep_find_dir(rid)
        if cand and cand.is_dir():
            _CACHE["rid2dir"][rid] = str(cand)
            return cand

        _CACHE["rid2dir"][rid] = ""
        return None

    def _resolve_safe(run_dir: Path, rel: str):
        fp = (run_dir / rel)
        try:
            fp_res = fp.resolve()
            rd_res = run_dir.resolve()
            if rd_res not in fp_res.parents and fp_res != rd_res:
                return None
            return fp_res
        except Exception:
            return None

    def vsp_run_file_v4():
        rid = (request.args.get("rid") or "").strip()
        rel = _safe_rel(request.args.get("path") or "")
        if not rid or not rel:
            return jsonify({"ok": False, "err": "missing rid/path"}), 400

        # keep "no auto probe" policy at UI-level; backend remains read-only whitelist
        if rel not in ALLOW:
            return jsonify({"ok": False, "err": "path not allowed", "allow": sorted(ALLOW)}), 403

        run_dir = _find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "run_dir not found", "rid": rid, "roots_used": BASE_DIRS, "deep_root": DEEP_ROOT}), 404

        rel_try = [rel]
        if rel == "run_gate.json":
            rel_try = ["run_gate.json", "run_gate_summary.json", "SUMMARY.txt"]

        picked = None
        for rr in rel_try:
            fp = _resolve_safe(run_dir, rr)
            if fp and fp.exists() and fp.is_file():
                picked = (rr, fp)
                break

        if not picked:
            exists = []
            for rr in sorted(ALLOW):
                fp = _resolve_safe(run_dir, rr)
                if fp and fp.exists() and fp.is_file():
                    exists.append(rr)
            return jsonify({"ok": False, "err": "file not found", "rid": rid, "path": rel, "run_dir": str(run_dir), "has": exists}), 404

        rr, fp = picked
        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        lim = _max_bytes(rr)
        if sz >= 0 and sz > lim:
            return jsonify({"ok": False, "err": "file too large", "size": sz, "limit": lim, "path": rr}), 413

        mime, _ = mimetypes.guess_type(str(fp))
        mime = mime or "application/octet-stream"
        as_attach = rr.endswith(".tgz") or rr.endswith(".zip")
        dl_name = f"{rid}__{rr.replace('/','_')}"
        resp = send_file(str(fp), mimetype=mime, as_attachment=as_attach, download_name=dl_name)
        try:
            if rr != rel:
                resp.headers["X-VSP-Fallback-Path"] = rr
        except Exception:
            pass
        return resp

    # FORCE override any existing endpoint bound to path "/api/vsp/run_file"
    endpoints = []
    try:
        for rule in app_obj.url_map.iter_rules():
            if getattr(rule, "rule", "") == "/api/vsp/run_file":
                endpoints.append(rule.endpoint)
    except Exception:
        endpoints = []

    ok = False
    for ep in set(endpoints):
        try:
            app_obj.view_functions[ep] = vsp_run_file_v4
            ok = True
        except Exception:
            pass

    if ok:
        print(f"[VSP_RUN_FILE] V4 force-bound endpoints={sorted(set(endpoints))}")
        return True

    # if no rule existed, mount it
    try:
        app_obj.add_url_rule("/api/vsp/run_file", "vsp_run_file_v4", vsp_run_file_v4, methods=["GET"])
        print("[VSP_RUN_FILE] V4 mounted fresh /api/vsp/run_file")
        return True
    except Exception as e:
        print("[VSP_RUN_FILE] V4 mount failed:", e)
        return False
# --- end VSP_P1_FORCE_RUN_FILE_HANDLER_V4 ---

# auto-bind on import (best-effort)
try:
    _app = globals().get("app", None) or globals().get("application", None)
    _vsp_p1_force_run_file_handler_v4(_app)
except Exception:
    pass


# VSP_P1_RUN_FILE_ALLOW_V5
# --- VSP_P1_RUN_FILE_ALLOW_V5: separate allow endpoint (keeps /api/vsp/run_file policy OFF) ---
def _vsp_p1_register_run_file_allow_v5(app_obj):
    try:
        import os, time, mimetypes
        from pathlib import Path
        from flask import request, jsonify, send_file
    except Exception:
        return False
    if not app_obj or not hasattr(app_obj, "add_url_rule"):
        return False

    # avoid double register
    try:
        if hasattr(app_obj, "view_functions") and ("vsp_run_file_allow_v5" in app_obj.view_functions):
            return True
    except Exception:
        pass

    BASE_DIRS = [
        os.environ.get("VSP_OUT_DIR", "") or "",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
    ]
    BASE_DIRS = [d for d in BASE_DIRS if d and os.path.isdir(d)]

    # bounded deep find root (only on demand)
    DEEP_ROOT = os.environ.get("VSP_DEEP_RUN_ROOT", "/home/test/Data")
    if not os.path.isdir(DEEP_ROOT):
        DEEP_ROOT = ""

    # strict whitelist
    ALLOW = {
        "run_gate.json",
        "run_gate_summary.json",
        "findings_unified.json",
        "findings_unified.sarif",
        "reports/findings_unified.csv",
        "reports/findings_unified.html",
        "reports/findings_unified.tgz",
        "reports/findings_unified.zip",
        "SUMMARY.txt",
    }

    _CACHE = {"rid2dir": {}}

    def _safe_rel(path: str) -> str:
        if not path:
            return ""
        path = path.strip().lstrip("/")
        if ".." in path.split("/"):
            return ""
        while "//" in path:
            path = path.replace("//", "/")
        return path

    def _max_bytes(rel: str) -> int:
        if rel.endswith(".tgz") or rel.endswith(".zip"):
            return 200 * 1024 * 1024
        if rel.endswith(".html"):
            return 80 * 1024 * 1024
        return 25 * 1024 * 1024

    def _deep_find_dir(rid: str):
        if not DEEP_ROOT:
            return None
        start = time.time()
        max_secs = 2.5
        max_dirs = 40000
        seen = 0
        root = Path(DEEP_ROOT)
        root_depth = len(root.parts)
        prune = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build"}
        try:
            for cur, dirs, files in os.walk(root, topdown=True):
                seen += 1
                if seen > max_dirs or (time.time() - start) > max_secs:
                    return None
                pcur = Path(cur)
                depth = len(pcur.parts) - root_depth
                if depth > 6:
                    dirs[:] = []
                    continue
                dirs[:] = [d for d in dirs if d not in prune]
                if pcur.name == rid:
                    return pcur
        except Exception:
            return None
        return None

    def _find_run_dir(rid: str):
        rid = (rid or "").strip()
        if not rid:
            return None
        if rid in _CACHE["rid2dir"]:
            v = _CACHE["rid2dir"][rid]
            return Path(v) if v else None

        for b in BASE_DIRS:
            cand = Path(b) / rid
            if cand.is_dir():
                _CACHE["rid2dir"][rid] = str(cand)
                return cand

        for b in BASE_DIRS:
            base = Path(b)
            try:
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    cand = d1 / rid
                    if cand.is_dir():
                        _CACHE["rid2dir"][rid] = str(cand)
                        return cand
                for d1 in base.iterdir():
                    if not d1.is_dir(): continue
                    for d2 in d1.iterdir():
                        if not d2.is_dir(): continue
                        cand = d2 / rid
                        if cand.is_dir():
                            _CACHE["rid2dir"][rid] = str(cand)
                            return cand
            except Exception:
                pass

        cand = _deep_find_dir(rid)
        if cand and cand.is_dir():
            _CACHE["rid2dir"][rid] = str(cand)
            return cand

        _CACHE["rid2dir"][rid] = ""
        return None

    def _resolve_safe(run_dir: Path, rel: str):
        fp = (run_dir / rel)
        try:
            fp_res = fp.resolve()
            rd_res = run_dir.resolve()
            if rd_res not in fp_res.parents and fp_res != rd_res:
                return None
            return fp_res
        except Exception:
            return None

    def vsp_run_file_allow_v5():
        # ===== VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_DUALPATCH_V4_INJECT =====
        try:
            # Self-contained: no dependency on module-level imports/helpers.
            from flask import request, make_response
            import json, time

            _rid = request.args.get("rid", "") or request.args.get("RID", "")
            _path = request.args.get("path", "") or request.args.get("PATH", "")

            if _path in ("run_manifest.json", "run_evidence_index.json"):
                now = int(time.time())
                served_by = globals().get("__file__", "unknown")

                if _path == "run_manifest.json":
                    payload = {
                        "ok": True,
                        "rid": _rid,
                        "gate_root": (f"gate_root_{_rid}" if _rid else None),
                        "gate_root_path": None,
                        "generated": True,
                        "generated_at": now,
                        "degraded": True,
                        "served_by": served_by,
                        "required_paths": [
                            "run_gate.json",
                            "run_gate_summary.json",
                            "findings_unified.json",
                            "reports/findings_unified.csv",
                            "run_manifest.json",
                            "run_evidence_index.json",
                        ],
                        "optional_paths": [
                            "reports/findings_unified.sarif",
                            "reports/findings_unified.html",
                            "reports/findings_unified.pdf",
                        ],
                        "hints": {
                            "why_degraded": "RUNS root not resolved in filesystem yet (P0 safe mode).",
                            "set_env": "Set VSP_RUNS_ROOT or VSP_RUNS_ROOTS to parent folder that contains gate_root_<RID>.",
                            "example": "VSP_RUNS_ROOT=/home/test/Data/SECURITY-10-10-v4/out_ci",
                        },
                    }
                else:
                    payload = {
                        "ok": True,
                        "rid": _rid,
                        "gate_root": (f"gate_root_{_rid}" if _rid else None),
                        "gate_root_path": None,
                        "generated": True,
                        "generated_at": now,
                        "degraded": True,
                        "served_by": served_by,
                        "evidence_dir": None,
                        "files": [],
                        "missing_recommended": [
                            "evidence/ui_engine.log",
                            "evidence/trace.zip",
                            "evidence/last_page.html",
                            "evidence/storage_state.json",
                            "evidence/net_summary.json",
                        ],
                    }

                resp = make_response(json.dumps(payload, ensure_ascii=False, indent=2), 200)
                resp.mimetype = "application/json"
                return resp

        except Exception as e:
            # Even if Flask helpers fail, return a tuple fallback (never 500).
            try:
                import json
                served_by = globals().get("__file__", "unknown")
                payload = {
                    "ok": False,
                    "generated": True,
                    "degraded": True,
                    "served_by": served_by,
                    "err": f"{type(e).__name__}: {e}",
                    "hint": "P0 SAFE MODE: inject fallback engaged; check service logs for root cause.",
                }
                return (json.dumps(payload, ensure_ascii=False, indent=2), 200, {"Content-Type":"application/json; charset=utf-8"})
            except Exception:
                return ("{}", 200, {"Content-Type":"application/json; charset=utf-8"})
        # ===== /VSP_P0_VIRTUAL_MANIFEST_EVIDENCEINDEX_DUALPATCH_V4_INJECT =====
        # VSP_P0_AUTOGEN_MANIFEST_EVIDENCEINDEX_V1: autogen core audit files if missing (P0)
        try:
            if path in ('run_manifest.json','run_evidence_index.json'):
                import os
                _run_dir = str(run_dir) if 'run_dir' in locals() else None
                # VSP_P0_RUN_DIR_GUARD_V4D
                try:
                  import os, time
                  from flask import jsonify
                  _rd = _run_dir
                  if (not _rd) or (not os.path.isdir(str(_rd))):
                    if path in ('run_manifest.json','run_evidence_index.json'):
                      obj={'rid':str(rid),'generated_at':int(time.time()),'run_dir':str(_rd),'note':'run_dir missing (P0)','required':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'present':[],'missing':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'audit_ready':False}
                      return jsonify(obj), 200
                    return jsonify({'ok':False,'err':'run_dir not found','rid':str(rid),'path':str(path),'run_dir':str(_rd)}), 404
                except Exception:
                  pass
                # VSP_P0_RUN_DIR_GUARD_V4C
                try:
                  import os, time
                  from flask import jsonify
                  _rd = _run_dir
                  if (not _rd) or (not os.path.isdir(str(_rd))):
                    if path in ('run_manifest.json','run_evidence_index.json'):
                      obj={'rid':str(rid),'generated_at':int(time.time()),'run_dir':str(_rd),'note':'run_dir missing (P0)','required':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'present':[],'missing':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'audit_ready':False}
                      return jsonify(obj), 200
                    return jsonify({'ok':False,'err':'run_dir not found','rid':str(rid),'path':str(path),'run_dir':str(_rd)}), 404
                except Exception:
                  pass
                if _run_dir and os.path.isdir(_run_dir):
                    _fp = os.path.join(_run_dir, path)
                    # VSP_P0_MISSING_FILE_GUARD_V4D
                    try:
                      import os, time, json
                      from flask import jsonify
                      if not os.path.exists(_fp):
                        if path in ('run_manifest.json','run_evidence_index.json'):
                          files=[]
                          try:
                            for root, dirs, fns in os.walk(_run_dir):
                              bn=os.path.basename(root)
                              if bn in ('node_modules','.git','__pycache__'): continue
                              for fn in fns:
                                fp2=os.path.join(root, fn)
                                rel=os.path.relpath(fp2, _run_dir).replace('\\','/')
                                try:
                                  st=os.stat(fp2)
                                  files.append({'path':rel,'size':int(st.st_size),'mtime':int(st.st_mtime)})
                                except Exception:
                                  files.append({'path':rel})
                            files.sort(key=lambda x: x.get('path',''))
                          except Exception:
                            files=[]
                          obj={'rid':str(rid),'generated_at':int(time.time()),'run_dir':str(_run_dir),'files_total':len(files),'files':files,'note':'auto-generated (P0)'}
                          if path=='run_evidence_index.json':
                            present=[]; missing=[]
                            for r in ['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html']:
                              (present if os.path.exists(os.path.join(_run_dir, r)) else missing).append(r)
                            obj.update({'required':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'present':present,'missing':missing,'audit_ready':(len(missing)==0)})
                          try:
                            os.makedirs(os.path.dirname(_fp), exist_ok=True)
                            with open(_fp, 'w', encoding='utf-8') as f:
                              json.dump(obj, f, ensure_ascii=False, indent=2)
                          except Exception:
                            pass
                          return jsonify(obj), 200
                        return jsonify({'ok':False,'err':'not found','rid':str(rid),'path':str(path)}), 404
                    except Exception:
                      pass
                    # VSP_P0_MISSING_FILE_GUARD_V4C
                    try:
                      import os, time, json
                      from flask import jsonify
                      if not os.path.exists(_fp):
                        if path in ('run_manifest.json','run_evidence_index.json'):
                          files=[]
                          try:
                            for root, dirs, fns in os.walk(_run_dir):
                              bn=os.path.basename(root)
                              if bn in ('node_modules','.git','__pycache__'): continue
                              for fn in fns:
                                fp2=os.path.join(root, fn)
                                rel=os.path.relpath(fp2, _run_dir).replace('\\','/')
                                try:
                                  st=os.stat(fp2)
                                  files.append({'path':rel,'size':int(st.st_size),'mtime':int(st.st_mtime)})
                                except Exception:
                                  files.append({'path':rel})
                            files.sort(key=lambda x: x.get('path',''))
                          except Exception:
                            files=[]
                          obj={'rid':str(rid), 'generated_at':int(time.time()), 'run_dir':str(_run_dir), 'files_total':len(files), 'files':files, 'note':'auto-generated (P0)'}
                          if path=='run_evidence_index.json':
                            required=['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html']
                            present=[]; missing=[]
                            for r in required:
                              (present if os.path.exists(os.path.join(_run_dir, r)) else missing).append(r)
                            obj.update({'required':required,'present':present,'missing':missing,'audit_ready':(len(missing)==0)})
                          try:
                            os.makedirs(os.path.dirname(_fp), exist_ok=True)
                            with open(_fp, 'w', encoding='utf-8') as f:
                              json.dump(obj, f, ensure_ascii=False, indent=2)
                          except Exception:
                            pass
                          return jsonify(obj), 200
                        return jsonify({'ok':False,'err':'not found','rid':str(rid),'path':str(path)}), 404
                    except Exception:
                      pass
                    # VSP_P0_RUNFILEALLOW_MISSING_GUARD_AUTOGEN_CORE_V3B
                    try:
                      import os, time, json
                      from flask import jsonify
                      if not os.path.exists(_fp):
                        if path in ('run_manifest.json','run_evidence_index.json'):
                          files=[]
                          try:
                            for root, dirs, fns in os.walk(_run_dir):
                              bn=os.path.basename(root)
                              if bn in ('node_modules','.git','__pycache__'): continue
                              for fn in fns:
                                fp2=os.path.join(root, fn)
                                rel=os.path.relpath(fp2, _run_dir).replace('\\','/')
                                try:
                                  st=os.stat(fp2)
                                  files.append({'path':rel,'size':int(st.st_size),'mtime':int(st.st_mtime)})
                                except Exception:
                                  files.append({'path':rel})
                            files.sort(key=lambda x: x.get('path',''))
                          except Exception:
                            files=[]
                          obj={'rid':str(rid), 'generated_at':int(time.time()), 'run_dir':str(_run_dir), 'files_total':len(files), 'files':files, 'note':'auto-generated (P0)'}
                          if path=='run_evidence_index.json':
                            required=['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html']
                            present=[]; missing=[]
                            for r in required:
                              (present if os.path.exists(os.path.join(_run_dir, r)) else missing).append(r)
                            obj.update({'required':required,'present':present,'missing':missing,'audit_ready':(len(missing)==0)})
                          try:
                            os.makedirs(os.path.dirname(_fp), exist_ok=True)
                            with open(_fp, 'w', encoding='utf-8') as f:
                              json.dump(obj, f, ensure_ascii=False, indent=2)
                          except Exception:
                            pass
                          return jsonify(obj), 200
                        return jsonify({'ok':False,'err':'not found','rid':str(rid),'path':str(path)}), 404
                    except Exception:
                      # don't crash into 500 tracebacks for missing paths
                      try:
                        from flask import jsonify
                        return jsonify({'ok':False,'err':'internal error','rid':str(rid),'path':str(path)}), 500
                      except Exception:
                        return ('internal error', 500)
                    if not os.path.exists(_fp):
                        _obj = _vsp_p0_make_run_manifest(_run_dir, str(rid)) if path=='run_manifest.json' else _vsp_p0_make_run_evidence_index(_run_dir, str(rid))
                        _vsp_p0__write_json_if_possible(_fp, _obj)
                        # return 200 even if write failed
                        from flask import jsonify
                        return jsonify(_obj)
        except Exception:
            pass
        # VSP_P0_RUNFILEALLOW_CONTRACT_ALLOW_UPDATE_V5: dashboard contract whitelist
        try:
            ALLOW.update({'run_manifest.json', 'run_evidence_index.json', 'reports/findings_unified.sarif'})
        except Exception:
            pass
        rid = (request.args.get("rid") or "").strip()
        rel = _safe_rel(request.args.get("path") or "")
        # VSP_P0_CORE_ALWAYS200_V5C
        try:
          import time
          from flask import jsonify
          if path in ('run_manifest.json','run_evidence_index.json'):
            _rid = str(rid)
            obj={'rid':_rid,'generated_at':int(time.time()),'note':'P0: core contract always 200; run_dir unresolved (set VSP_RUNS_ROOT later to autogen real files)'}
            if path=='run_manifest.json':
              obj.update({'files_total':0,'files':[]})
            else:
              obj.update({'required':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'present':[],'missing':['run_gate.json','run_gate_summary.json','findings_unified.json','run_manifest.json','run_evidence_index.json','reports/findings_unified.csv','reports/findings_unified.sarif','reports/findings_unified.html'],'audit_ready':False})
            return jsonify(obj), 200
        except Exception:
          pass
                # VSP_P0_DASHBOARD_FASTPATH_V5
        try:
          import os, time, json
          from pathlib import Path as _P
          from flask import jsonify, send_file
        
          _P0_CORE = ("run_manifest.json","run_evidence_index.json")
          _P0_OPT  = ("reports/findings_unified.sarif","reports/findings_unified.html")
          _P0_FAST = set(_P0_CORE + _P0_OPT)
        
          def _vsp_p0_resolve_run_dir(_rid: str) -> str:
            if not _rid:
              return ""
            here = _P(__file__).resolve()
            # repo layout: .../SECURITY_BUNDLE/ui/<file.py>
            bundle_root = here.parent.parent  # SECURITY_BUNDLE
            bases = [
              bundle_root / "out_ci",
              bundle_root / "out",
              bundle_root / "out_ci" / "VSP",
              bundle_root / "out" / "VSP",
            ]
            # direct candidates
            direct = [
              lambda b: b / _rid,
              lambda b: b / f"gate_root_{_rid}",
              lambda b: b / f"RUN_{_rid}",
              lambda b: b / f"VSP_CI_RUN_{_rid}",
            ]
            for b in bases:
              try:
                if not b.exists(): 
                  continue
                for fn in direct:
                  cand = fn(b)
                  if cand.is_dir() and ((cand/"run_gate.json").exists() or (cand/"run_gate_summary.json").exists() or (cand/"findings_unified.json").exists()):
                    return str(cand)
                # 1-level glob (cheap)
                for cand in b.glob(f"*{_rid}*"):
                  try:
                    if cand.is_dir() and ((cand/"run_gate.json").exists() or (cand/"run_gate_summary.json").exists() or (cand/"findings_unified.json").exists()):
                      return str(cand)
                  except Exception:
                    continue
              except Exception:
                continue
            return ""
        
          def _vsp_p0_autogen_manifest(_run_dir: str, _rid: str):
            # keep it cheap: only list top-level + reports/
            files=[]
            try:
              rd=_P(_run_dir)
              for p in sorted(rd.rglob("*")):
                try:
                  if p.is_dir(): 
                    continue
                  rel = str(p.relative_to(rd)).replace("\\","/")
                  st = p.stat()
                  files.append({"path":rel,"size":int(st.st_size),"mtime":int(st.st_mtime)})
                except Exception:
                  continue
            except Exception:
              files=[]
            return {
              "rid": _rid,
              "generated_at": int(time.time()),
              "run_dir": _run_dir,
              "files_total": len(files),
              "files": files,
              "note": "auto-generated (P0 dashboard fast-path)"
            }
        
          def _vsp_p0_autogen_evidence_index(_run_dir: str, _rid: str):
            required = [
              "run_gate.json","run_gate_summary.json","findings_unified.json",
              "run_manifest.json","run_evidence_index.json",
              "reports/findings_unified.csv","reports/findings_unified.sarif","reports/findings_unified.html"
            ]
            present=[]; missing=[]
            for r in required:
              (present if os.path.exists(os.path.join(_run_dir, r)) else missing).append(r)
            return {
              "rid": _rid,
              "generated_at": int(time.time()),
              "run_dir": _run_dir,
              "required": required,
              "present": present,
              "missing": missing,
              "audit_ready": (len(missing)==0),
              "note": "auto-generated (P0 dashboard fast-path)"
            }
        
          if path in _P0_FAST:
            _rid = str(rid)
            _rd = _vsp_p0_resolve_run_dir(_rid)
            if not _rd or (not os.path.isdir(_rd)):
              if path in _P0_CORE:
                # return 200 so Dashboard doesn't break; caller can see run_dir missing
                obj = {
                  "rid": _rid,
                  "generated_at": int(time.time()),
                  "run_dir": str(_rd),
                  "note": "run_dir not found (P0 dashboard fast-path)",
                  "required": [],
                  "present": [],
                  "missing": [],
                  "audit_ready": False
                }
                return jsonify(obj), 200
              return jsonify({"ok": False, "err": "not generated", "rid": _rid, "path": path, "run_dir": str(_rd)}), 404
        
            _fp = os.path.join(_rd, path)
            if not os.path.exists(_fp):
              if path == "run_manifest.json":
                obj = _vsp_p0_autogen_manifest(_rd, _rid)
              elif path == "run_evidence_index.json":
                obj = _vsp_p0_autogen_evidence_index(_rd, _rid)
              else:
                return jsonify({"ok": False, "err": "not generated", "rid": _rid, "path": path}), 404
              # persist best-effort
              try:
                os.makedirs(os.path.dirname(_fp), exist_ok=True)
                with open(_fp, "w", encoding="utf-8") as f:
                  json.dump(obj, f, ensure_ascii=False, indent=2)
              except Exception:
                pass
              return jsonify(obj), 200
        
            # exists => serve; never 500 for dashboard fast paths
            try:
              return send_file(_fp, as_attachment=False)
            except Exception as e:
              return jsonify({"ok": False, "err": "send_file failed", "rid": _rid, "path": path, "detail": str(e)}), 404
        except Exception:
          pass
        
        if not rid or not rel:
            return jsonify({"ok": False, "err": "missing rid/path"}), 400

        if rel not in ALLOW:
            return jsonify({"ok": False, "err": "not allowed", "allow": sorted(ALLOW)}), 403

        run_dir = _find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": "run_dir not found", "rid": rid, "roots_used": BASE_DIRS, "deep_root": DEEP_ROOT}), 404

        rel_try = [rel]
        if rel == "run_gate.json":
            rel_try = ["run_gate.json", "run_gate_summary.json", "SUMMARY.txt"]

        picked = None
        for rr in rel_try:
            fp = _resolve_safe(run_dir, rr)
            if fp and fp.exists() and fp.is_file():
                picked = (rr, fp)
                break

        if not picked:
            exists = []
            for rr in sorted(ALLOW):
                fp = _resolve_safe(run_dir, rr)
                if fp and fp.exists() and fp.is_file():
                    exists.append(rr)
            return jsonify({"ok": False, "err": "file not found", "rid": rid, "path": rel, "run_dir": str(run_dir), "has": exists}), 404

        rr, fp = picked
        try:
            sz = fp.stat().st_size
        except Exception:
            sz = -1
        lim = _max_bytes(rr)
        if sz >= 0 and sz > lim:
            return jsonify({"ok": False, "err": "file too large", "size": sz, "limit": lim, "path": rr}), 413

        mime, _ = mimetypes.guess_type(str(fp))
        mime = mime or "application/octet-stream"
        as_attach = rr.endswith(".tgz") or rr.endswith(".zip")
        dl_name = f"{rid}__{rr.replace('/','_')}"
        resp = send_file(str(fp), mimetype=mime, as_attachment=as_attach, download_name=dl_name)
        try:
            if rr != rel:
                resp.headers["X-VSP-Fallback-Path"] = rr
        except Exception:
            pass
        return resp

    try:
        app_obj.add_url_rule("/api/vsp/run_file_allow", "vsp_run_file_allow_v5", vsp_run_file_allow_v5, methods=["GET"])
        print("[VSP_RUN_FILE_ALLOW] mounted /api/vsp/run_file_allow")
        return True
    except Exception as e:
        print("[VSP_RUN_FILE_ALLOW] mount failed:", e)
        return False
# --- end VSP_P1_RUN_FILE_ALLOW_V5 ---

try:
    _app = globals().get("app", None) or globals().get("application", None)
    _vsp_p1_register_run_file_allow_v5(_app)
except Exception:
    pass


# VSP_P1_ALLOW_GATE_REPORTS_V2


# VSP_P1_ALLOW_GATE_REPORTS_V4

# --- VSP_P1_RUNS_OPEN_AND_META_P1_V2 ---
# Goals:
# 1) Ensure /api/vsp/open* exists to stop 404 spam from Runs tab (SAFE default: no xdg-open).
# 2) Enrich /api/vsp/runs output with per-item has_gate/overall/degraded + rid_latest_gate (prefer gate run).

try:
    from flask import request, jsonify
    import os
    import json
    from pathlib import Path as _Path
    import subprocess
except Exception:
    request = None
    jsonify = None

def _vsp_gate_candidates():
    return [
        "run_gate_summary.json",
        "reports/run_gate_summary.json",
        "run_gate.json",
        "reports/run_gate.json",
    ]

def _vsp_try_read_json(fp: str, max_bytes: int = 2_000_000):
    try:
        p = _Path(fp)
        if (not p.exists()) or (not p.is_file()):
            return None
        if p.stat().st_size > max_bytes:
            return None
        return json.loads(p.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return None

def _vsp_extract_overall_degraded(obj):
    overall = "UNKNOWN"
    degraded = False
    if isinstance(obj, dict):
        overall = obj.get("overall") or obj.get("overall_status") or obj.get("status") or "UNKNOWN"
        if isinstance(obj.get("degraded"), bool):
            degraded = obj.get("degraded")
        bt = obj.get("by_type")
        if degraded is False and isinstance(bt, dict):
            for v in bt.values():
                if isinstance(v, dict) and v.get("degraded") is True:
                    degraded = True
                    break
    return str(overall), bool(degraded)

def _vsp_roots_from_env_or_resp(resp_json=None):
    roots = []
    roots += [os.environ.get("VSP_RUNS_ROOT","")]
    roots += ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/out_ci"]
    if isinstance(resp_json, dict):
        ru = resp_json.get("roots_used")
        if isinstance(ru, list):
            roots = ru + roots
    out = []
    for r in roots:
        if r and r not in out:
            out.append(r)
    return out

def _vsp_find_run_dir(rid: str, roots):
    if not rid:
        return None
    for r in roots or []:
        if not r:
            continue
        base = _Path(r)
        cand = base / rid
        if cand.exists():
            return str(cand.resolve())
    return None

def _vsp_open_payload(rid: str, what: str, roots):
    run_dir = _vsp_find_run_dir(rid, roots)
    allow = os.environ.get("VSP_UI_ALLOW_XDG_OPEN", "0") == "1"
    opened = False
    err = None
    if allow and run_dir and what in ("folder","dir","run_dir"):
        try:
            subprocess.Popen(["xdg-open", run_dir],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            opened = True
        except Exception as e:
            err = str(e)
    payload = {
        "ok": True,
        "rid": rid,
        "what": what,
        "run_dir": run_dir,
        "opened": opened,
        "disabled": (not allow),
        "hint": "SAFE default: opener disabled. Set VSP_UI_ALLOW_XDG_OPEN=1 to enable (dev only).",
    }
    if err:
        payload["error"] = err
    return payload

def _vsp_post_mount_fixups():
    app = globals().get("app") or globals().get("application")
    if app is None or request is None or jsonify is None:
        return

    # 1) Ensure /api/vsp/open endpoints exist
    rules = list(app.url_map.iter_rules())
    has_open = any(r.rule == "/api/vsp/open" for r in rules)
    has_open_folder = any(r.rule == "/api/vsp/open_folder" for r in rules)

    if not has_open:
        def vsp_open_p1_v2():
            rid = (request.args.get("rid","") or "").strip()
            what = (request.args.get("what","folder") or "folder").strip()
            roots = _vsp_roots_from_env_or_resp(None)
            return jsonify(_vsp_open_payload(rid, what, roots))
        app.add_url_rule("/api/vsp/open", endpoint="vsp_open_p1_v2", view_func=vsp_open_p1_v2, methods=["GET"])

    if not has_open_folder:
        def vsp_open_folder_p1_v2():
            rid = (request.args.get("rid","") or "").strip()
            roots = _vsp_roots_from_env_or_resp(None)
            return jsonify(_vsp_open_payload(rid, "folder", roots))
        app.add_url_rule("/api/vsp/open_folder", endpoint="vsp_open_folder_p1_v2", view_func=vsp_open_folder_p1_v2, methods=["GET"])

    # 2) Wrap /api/vsp/runs to enrich per-item gate/overall/degraded + rid_latest_gate
    for r in app.url_map.iter_rules():
        if r.rule != "/api/vsp/runs":
            continue
        ep = r.endpoint
        orig = app.view_functions.get(ep)
        if not orig or getattr(orig, "__vsp_wrapped_runsmeta_v2", False):
            continue

        def wrapped(*args, **kwargs):
            resp = orig(*args, **kwargs)
            status = None
            headers = None
            resp_obj = resp
            if isinstance(resp, tuple) and len(resp) >= 1:
                resp_obj = resp[0]
                if len(resp) >= 2: status = resp[1]
                if len(resp) >= 3: headers = resp[2]

            data = None
            if hasattr(resp_obj, "get_json"):
                data = resp_obj.get_json(silent=True)
            elif isinstance(resp_obj, dict):
                data = resp_obj

            if isinstance(data, dict) and isinstance(data.get("items"), list):
                roots = _vsp_roots_from_env_or_resp(data)
                rid_latest_gate = None

                for it in data["items"]:
                    if not isinstance(it, dict):
                        continue
                    rid = it.get("run_id")
                    run_dir = _vsp_find_run_dir(rid, roots) if rid else None

                    has_gate = False
                    overall = "UNKNOWN"
                    degraded = False

                    if run_dir:
                        for rel in _vsp_gate_candidates():
                            obj = _vsp_try_read_json(str(_Path(run_dir) / rel))
                            if isinstance(obj, dict):
                                has_gate = True
                                overall, degraded = _vsp_extract_overall_degraded(obj)
                                break

                    it.setdefault("has", {})
                    it["has"]["gate"] = bool(has_gate)
                    it["overall"] = str(overall)
                    it["degraded"] = bool(degraded)

                    if rid_latest_gate is None and has_gate:
                        rid_latest_gate = rid

                data["rid_latest_gate"] = rid_latest_gate
                if rid_latest_gate:
                    data["rid_latest"] = rid_latest_gate  # prefer gate run for UI stability

                new_resp = jsonify(data)
                if headers and hasattr(headers, "items"):
                    for k, v in headers.items():
                        new_resp.headers[k] = v
                if status is not None:
                    return new_resp, status
                return new_resp

            return resp

        wrapped.__vsp_wrapped_runsmeta_v2 = True
        app.view_functions[ep] = wrapped
        break

try:
    _vsp_post_mount_fixups()
except Exception:
    pass


# ===================== VSP_P0_API_RID_LATEST_V1 =====================
# Provides /api/vsp/rid_latest so UI can bootstrap RID and stop skeleton loading.
# Commercial: set VSP_RUNS_ROOT or VSP_RUNS_ROOTS (colon/comma separated) to avoid scanning.
try:
    import os, time
    from flask import request, jsonify
except Exception:
    request = None
    jsonify = None

_VSP_P0_RID_LATEST_CACHE = {"ts": 0.0, "rid": None}

def _vsp_p0_guess_roots_v1():
    roots = []
    env = (os.environ.get("VSP_RUNS_ROOTS") or os.environ.get("VSP_RUNS_ROOT") or "").strip()
    if env:
        for part in env.replace(",", ":").split(":"):
            part = part.strip()
            if part:
                roots.append(part)
    # common defaults (no sudo)
    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out",
        "/home/test/Data/SECURITY_BUNDLE",
        "/home/test/Data",
    ]
    # de-dup keep order
    seen = set()
    out = []
    for r in roots:
        if r in seen: 
            continue
        seen.add(r)
        out.append(r)
    return out

def _vsp_p0_pick_latest_rid_v1():
    # cache 5 seconds to avoid repeated scans
    now = time.time()
    if (now - _VSP_P0_RID_LATEST_CACHE["ts"]) < 5 and _VSP_P0_RID_LATEST_CACHE["rid"]:
        return _VSP_P0_RID_LATEST_CACHE["rid"]

    best = (None, -1.0)  # (rid, mtime)
    roots = _vsp_p0_guess_roots_v1()

    for base in roots:
        try:
            if not os.path.isdir(base):
                continue

            # 1) direct gate_root_* under base
            try:
                for name in os.listdir(base):
                    if not name.startswith("gate_root_"):
                        continue
                    p = os.path.join(base, name)
                    if not os.path.isdir(p):
                        continue
                    mt = os.path.getmtime(p)
                    rid = name[len("gate_root_"):]
                    if mt > best[1] and rid:
                        best = (rid, mt)
            except Exception:
                pass

            # 2) one-level down: base/*/gate_root_*
            try:
                for name in os.listdir(base):
                    p1 = os.path.join(base, name)
                    if not os.path.isdir(p1):
                        continue
                    try:
                        for name2 in os.listdir(p1):
                            if not name2.startswith("gate_root_"):
                                continue
                            p = os.path.join(p1, name2)
                            if not os.path.isdir(p):
                                continue
                            mt = os.path.getmtime(p)
                            rid = name2[len("gate_root_"):]
                            if mt > best[1] and rid:
                                best = (rid, mt)
                    except Exception:
                        pass
            except Exception:
                pass

        except Exception:
            continue

    rid = best[0]
    _VSP_P0_RID_LATEST_CACHE["ts"] = now
    _VSP_P0_RID_LATEST_CACHE["rid"] = rid
    return rid

def vsp_rid_latest_v1():
    # Always 200 JSON
    try:
        rid = None
        if request is not None:
            rid = (request.args.get("rid") or request.args.get("run_id") or "").strip() or None
        if not rid:
            rid = _vsp_p0_pick_latest_rid_v1()
        gate_root = f"gate_root_{rid}" if rid else None
        return jsonify({
            "ok": bool(rid),
            "rid": rid,
            "gate_root": gate_root,
            "degraded": (not bool(rid)),
            "served_by": __file__,
        }), 200
    except Exception as e:
        try:
            return jsonify({"ok": False, "err": str(e), "served_by": __file__}), 200
        except Exception:
            return ("{}", 200, {"Content-Type":"application/json"})

# Register route if possible
try:
    _app = globals().get("app") or globals().get("application")
    if _app and hasattr(_app, "add_url_rule"):
        try:
            _app.add_url_rule("/api/vsp/rid_latest", "vsp_rid_latest_v1", vsp_rid_latest_v1, methods=["GET"])
        except Exception:
            pass
except Exception:
    pass
# ===================== /VSP_P0_API_RID_LATEST_V1 =====================



# ===================== VSP_P0_RID_LATEST_ALIAS_SAFE_V4 =====================
# Provide /api/vsp/rid_latest + /api/vsp/latest_rid as aliases of /api/vsp/rid_latest_gate_root
# so JS callers won't get rid=null.
def api_vsp_rid_latest_gate_root():
    # VSP_P0_RID_LATEST_PICK_ANY_DETAILS_V3F
    import os, glob, time, json

    roots = [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
    ]

    def csv_has_2_lines(path: str) -> bool:
        try:
            if not os.path.isfile(path) or os.path.getsize(path) < 120:
                return False
            n = 0
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for _ in f:
                    n += 1
                    if n >= 2:
                        return True
            return False
        except Exception:
            return False

    def sarif_has_results(path: str) -> bool:
        try:
            if not os.path.isfile(path) or os.path.getsize(path) < 200:
                return False
            j = json.load(open(path, "r", encoding="utf-8", errors="ignore"))
            for run in (j.get("runs") or []):
                if (run.get("results") or []):
                    return True
            return False
        except Exception:
            return False

    def has_any_details(run_dir: str) -> str:
        fu = os.path.join(run_dir, "findings_unified.json")
        try:
            if os.path.isfile(fu) and os.path.getsize(fu) > 500:
                return "findings_unified.json"
        except Exception:
            pass

        csvp = os.path.join(run_dir, "reports", "findings_unified.csv")
        if csv_has_2_lines(csvp):
            return "reports/findings_unified.csv"

        sarifp = os.path.join(run_dir, "reports", "findings_unified.sarif")
        if sarif_has_results(sarifp):
            return "reports/findings_unified.sarif"

        pats = [
            "semgrep/**/*.json","grype/**/*.json","trivy/**/*.json","kics/**/*.json",
            "bandit/**/*.json","gitleaks/**/*.json","codeql/**/*.sarif",
            "**/*semgrep*.json","**/*grype*.json","**/*trivy*.json",
            "**/*kics*.json","**/*bandit*.json","**/*gitleaks*.json","**/*codeql*.sarif",
        ]
        for pat in pats:
            for f in glob.glob(os.path.join(run_dir, pat), recursive=True):
                try:
                    if os.path.getsize(f) > 800:
                        rel = os.path.relpath(f, run_dir).replace("\\","/")
                        if rel == "reports/findings_unified.sarif":
                            continue
                        return rel
                except Exception:
                    continue
        return ""

    def pick_latest_with_details(max_scan=260):
        best = None  # (mtime, rid, root, why)
        for root in roots:
            if not os.path.isdir(root):
                continue
            cands = []
            for rid in os.listdir(root):
                if not rid or rid.startswith("."):
                    continue
                run_dir = os.path.join(root, rid)
                if not os.path.isdir(run_dir):
                    continue
                try:
                    mtime = int(os.path.getmtime(run_dir))
                except Exception:
                    mtime = 0
                cands.append((mtime, rid, run_dir))
            cands.sort(reverse=True)
            for mtime, rid, run_dir in cands[:max_scan]:
                why = has_any_details(run_dir)
                if why:
                    cand = (mtime, rid, root, why)
                    if best is None or cand[0] > best[0]:
                        best = cand
                    break
        return best

    def pick_latest_existing():
        best = None
        for root in roots:
            if not os.path.isdir(root):
                continue
            cands=[]
            for rid in os.listdir(root):
                run_dir = os.path.join(root, rid)
                if os.path.isdir(run_dir):
                    try: cands.append((int(os.path.getmtime(run_dir)), rid))
                    except Exception: cands.append((0, rid))
            cands.sort(reverse=True)
            if cands:
                mtime, rid = cands[0]
                cand=(mtime, rid, root)
                if best is None or cand[0] > best[0]:
                    best = cand
        return best

    best = pick_latest_with_details()
    if best:
        _, rid, root, why = best
        return jsonify({
            "ok": True,
            "rid": rid,
            "gate_root": "gate_root_" + rid,
            "roots": roots,
            "reason": "latest_with_details",
            "why": why,
            "ts": int(time.time()),
        })

    fb = pick_latest_existing()
    if fb:
        _, rid, _root = fb
        return jsonify({
            "ok": True,
            "rid": rid,
            "gate_root": "gate_root_" + rid,
            "roots": roots,
            "reason": "latest_existing_fallback_no_details",
            "why": "",
            "ts": int(time.time()),
        })

    return jsonify({
        "ok": False,
        "rid": "",
        "gate_root": "",
        "roots": roots,
        "reason": "no_roots_found",
        "why": "",
        "ts": int(time.time()),
    }), 200

@app.get("/api/vsp/release_probe")
def vsp_release_probe():
    try:
        p = (request.args.get("path") or "").strip()
        u = (request.args.get("url") or "").strip()

        if (not p) and u:
            try:
                pu = _urlparse(u)
                p = (pu.path or "").strip()
            except Exception:
                p = ""

        if p.startswith("/"):
            p = p[1:]

        # strict allowlist (runs-only release packages)
        if (not p) or (".." in p) or (not p.startswith("out_ci/releases/")):
            return jsonify({"ok": True, "exists": None, "allowed": False, "path": p})

        root = _Path(__file__).resolve().parent  # /home/test/Data/SECURITY_BUNDLE/ui
        cand = (root / p).resolve()

        # ensure within root
        if str(cand).startswith(str(root) + "/"):
            exists = cand.exists() and cand.is_file()
            size = cand.stat().st_size if exists else None
            return jsonify({"ok": True, "exists": bool(exists), "allowed": True, "path": p, "size": size})

        return jsonify({"ok": True, "exists": None, "allowed": False, "path": p})
    except Exception as e:
        # always 200
        return jsonify({"ok": True, "exists": None, "allowed": False, "err": str(e)[:200]})

# ===================== /VSP_P1_RELEASE_PROBE_ALWAYS200_V1 =====================

# ===================== VSP_P1_EXPORT_FILENAME_WITH_RELEASE_V4 =====================
# Add "Current Release" metadata into export download filename (CSV/TGZ/HTML)
# Safe: module-level helpers + handler return rewrite (indent-aware)
# =================================================================================

import re as _vsp_rel_re
from pathlib import Path as _vsp_rel_Path

def _vsp__release_meta():
    try:
        root = _vsp_rel_Path(__file__).resolve().parent
        cand = root / "out_ci" / "releases" / "release_latest.json"
        if cand.exists():
            import json
            j = json.loads(cand.read_text(encoding="utf-8", errors="replace"))
        else:
            j = {}
        def pick(*ks):
            for k in ks:
                if k in j and str(j[k]).strip():
                    return str(j[k]).strip()
                for kk in list(j.keys()):
                    if str(kk).lower() == str(k).lower() and str(j[kk]).strip():
                        return str(j[kk]).strip()
            return ""
        ts = pick("ts","timestamp","built_at","created_at")
        sha = pick("sha","sha256","git_sha","commit","commit_sha")
        pkg = pick("pkg_name","package_name","name","filename","PACKAGE")
        if not pkg:
            u = pick("pkg_url","package_url","download_url","url","href","pkg","package","path","tgz","tgz_path","pkg_path","package_path")
            if u:
                pkg = u.split("/")[-1]
        sha12 = (sha[:12] if sha else "")
        pkg_base = _vsp_rel_re.sub(r'[^A-Za-z0-9._-]+','_', pkg)[:60] if pkg else ""
        ts_s = _vsp_rel_re.sub(r'[^0-9A-Za-z._-]+','_', ts)[:32] if ts else ""
        return {"ts": ts_s, "sha12": sha12, "pkg": pkg_base}
    except Exception:
        return {"ts":"", "sha12":"", "pkg":""}

def _vsp__mk_export_name(rid, ext):
    meta = _vsp__release_meta()
    parts = []
    if meta.get("pkg"): parts.append("UI_" + meta["pkg"])
    if meta.get("sha12"): parts.append(meta["sha12"])
    if meta.get("ts"): parts.append(meta["ts"])
    suf = ("__" + "__".join(parts)) if parts else ""
    base = _vsp_rel_re.sub(r'[^A-Za-z0-9._-]+','_', "VSP_EXPORT_" + str(rid))[:120]
    return f"{base}{suf}.{ext}"

def _vsp__rewrite_cd(resp, rid):
    try:
        if not hasattr(resp, "headers"):
            return resp
        cd = resp.headers.get("Content-Disposition","") or ""
        if not cd:
            return resp

        # read filename from Content-Disposition
        m = _vsp_rel_re.search(r'filename\*=UTF-8\x27\x27([^;]+)', cd)
        fn = None
        if m:
            fn = m.group(1)
        else:
            m2 = _vsp_rel_re.search(r'filename="([^"]+)"', cd)
            if m2:
                fn = m2.group(1)
        if not fn:
            return resp

        ext = (fn.split(".")[-1] if "." in fn else "").lower()
        if ext not in ("csv","tgz","html","json"):
            return resp

        new_fn = _vsp__mk_export_name(rid, ext)

        cd2 = _vsp_rel_re.sub(r'filename="[^"]+"', 'filename="' + new_fn + '"', cd)
        cd2 = _vsp_rel_re.sub(r'filename\*=UTF-8\x27\x27[^;]+', "filename*=UTF-8''" + new_fn, cd2)
        resp.headers["Content-Disposition"] = cd2
        return resp
    except Exception:
        return resp
# ===================== /VSP_P1_EXPORT_FILENAME_WITH_RELEASE_V4 =====================

# ===================== VSP_P1_EXPORT_RUNDIR_RESOLVE_FALLBACK_V1 =====================
# Resolve RID -> existing run directory on disk (ui/out_ci, ui/out, bundle/out_ci, bundle/out)
from pathlib import Path as _vsp_rd_Path
import re as _vsp_rd_re

def _vsp__resolve_run_dir_for_export(_rid: str, _rid_norm: str = "") -> str:
    try:
        rid = (_rid or "").strip()
    except Exception:
        rid = ""
    try:
        rid_norm = (_rid_norm or "").strip()
    except Exception:
        rid_norm = ""

    if not rid_norm:
        try:
            m = _vsp_rd_re.search(r'(\d{8}_\d{6})', rid)
            rid_norm = m.group(1) if m else rid.replace("VSP_CI_RUN_","").replace("VSP_CI_","").replace("RUN_","")
            rid_norm = (rid_norm or "").strip()
        except Exception:
            rid_norm = ""

    ui_root = _vsp_rd_Path(__file__).resolve().parent
    bundle_root = ui_root.parent

    roots = [ui_root/"out_ci", ui_root/"out", bundle_root/"out_ci", bundle_root/"out"]

    names = []
    for x in [rid, rid_norm]:
        if x and x not in names:
            names.append(x)
    if rid_norm:
        for pref in ["RUN_", "VSP_CI_RUN_", "VSP_CI_"]:
            n = pref + rid_norm
            if n not in names:
                names.append(n)

    # exact matches
    for root in roots:
        try:
            if not root.exists():
                continue
            for nm in names:
                cand = root / nm
                if cand.exists() and cand.is_dir():
                    return str(cand)
        except Exception:
            continue

    # bounded glob by rid_norm, choose newest
    best = None
    best_m = -1.0
    pats = [f"*{rid_norm}*", f"RUN*{rid_norm}*", f"VSP_CI*{rid_norm}*"] if rid_norm else []
    for root in roots:
        try:
            if not root.exists():
                continue
            for pat in pats:
                c = 0
                for cand in root.glob(pat):
                    if not cand.is_dir():
                        continue
                    c += 1
                    try:
                        mt = cand.stat().st_mtime
                    except Exception:
                        mt = 0.0
                    if mt > best_m:
                        best, best_m = cand, mt
                    if c >= 80:
                        break
        except Exception:
            continue

    return str(best) if best else ""
# ===================== /VSP_P1_EXPORT_RUNDIR_RESOLVE_FALLBACK_V1 =====================


# ===================== VSP_P1_EXPORT_FORCE_OVERRIDE_HOTFIX_V1 =====================
# Force override export endpoint to stop RUN_DIR_NOT_FOUND when run dir exists on disk.
try:
    import os, re as _re, json as _json, tarfile as _tarfile, time as _time
    from pathlib import Path as _Path
    from flask import request as _req, send_file as _send_file, jsonify as _jsonify

    def _vsp__rel_meta_for_name():
        try:
            ui_root = _Path(__file__).resolve().parent
            cands = [
                ui_root/"out_ci"/"releases"/"release_latest.json",
                ui_root/"out"/"releases"/"release_latest.json",
                ui_root.parent/"out_ci"/"releases"/"release_latest.json",
                ui_root.parent/"out"/"releases"/"release_latest.json",
            ]
            for f in cands:
                if f.exists():
                    j = _json.loads(f.read_text(encoding="utf-8", errors="replace"))
                    return {
                        "ts": (j.get("ts") or j.get("timestamp") or ""),
                        "package": (j.get("package") or j.get("pkg") or ""),
                        "sha": (j.get("sha") or j.get("sha256") or ""),
                    }
        except Exception:
            pass
        return {"ts":"", "package":"", "sha":""}

    def _vsp__norm_rid(rid0: str) -> str:
        rid0 = (rid0 or "").strip()
        m = _re.search(r'(\d{8}_\d{6})', rid0)
        return (m.group(1) if m else rid0.replace("VSP_CI_RUN_","").replace("VSP_CI_","").replace("RUN_","")).strip()

    def _vsp__pick_app():
        for k in ("_app","app","application"):
            a = globals().get(k)
            if a is not None and hasattr(a, "view_functions"):
                return a
        return None

    def _vsp__export_build_tgz(run_dir: str, rid_norm: str) -> str:
        rd = _Path(run_dir)
        out = _Path("/tmp") / f"vsp_export_{rid_norm or 'run'}.tgz"
        try:
            if out.exists():
                out.unlink()
        except Exception:
            pass

        # include a conservative subset to keep tar small + useful
        picks = [
            rd/"run_gate.json",
            rd/"run_gate_summary.json",
            rd/"findings_unified.json",
            rd/"reports",
            rd/"SUMMARY.txt",
        ]
        with _tarfile.open(out, "w:gz") as tf:
            base = f"{rid_norm or rd.name}"
            for x in picks:
                try:
                    if not x.exists():
                        continue
                    tf.add(str(x), arcname=f"{base}/{x.name}")
                except Exception:
                    continue
        return str(out)

    def api_vsp_run_export_v3_force_hotfix(rid=None):
        # accept rid from query or path param
        rid0 = (_req.args.get("rid") or _req.args.get("run_id") or _req.args.get("RID") or "").strip()
        if not rid0:
            try:
                rid0 = (str(rid) if rid is not None else "").strip()
            except Exception:
                rid0 = ""

        fmt = (_req.args.get("fmt") or "tgz").strip().lower()
        rid_norm = _vsp__norm_rid(rid0)

        # resolve run_dir via helper if present, else basic fallback
        run_dir = ""
        try:
            if "_vsp__resolve_run_dir_for_export" in globals():
                run_dir = _vsp__resolve_run_dir_for_export(rid0, rid_norm) or ""
        except Exception:
            run_dir = ""

        if not run_dir:
            # very last resort: known root
            cand = _Path("/home/test/Data/SECURITY_BUNDLE/out") / (f"RUN_{rid_norm}" if rid_norm and not str(rid0).startswith("RUN_") else rid0)
            if cand.exists() and cand.is_dir():
                run_dir = str(cand)

        if not run_dir:
            return _jsonify({"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm}), 404

        rel = _vsp__rel_meta_for_name()
        suffix = ""
        if rel.get("ts"):
            t = str(rel["ts"]).replace(":","").replace("-","").replace("T","_")
            suffix += f"_rel-{t[:15]}"
        if rel.get("sha"):
            suffix += f"_sha-{str(rel['sha'])[:12]}"

        if fmt == "tgz":
            fp = _vsp__export_build_tgz(run_dir, rid_norm or rid0)
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.tgz"
            return _send_file(fp, as_attachment=True, download_name=dl, mimetype="application/gzip")

        if fmt == "csv":
            rd = _Path(run_dir)
            cand = rd/"reports"/"findings_unified.csv"
            if not cand.exists():
                cand = rd/"reports"/"findings.csv"
            if not cand.exists():
                return _jsonify({"ok": False, "error": "CSV_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm}), 404
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.csv"
            return _send_file(str(cand), as_attachment=True, download_name=dl, mimetype="text/csv")

        if fmt == "html":
            rd = _Path(run_dir)
            cand = rd/"reports"/"findings_unified.html"
            if not cand.exists():
                cand = rd/"reports"/"index.html"
            if not cand.exists():
                return _jsonify({"ok": False, "error": "HTML_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm}), 404
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.html"
            return _send_file(str(cand), as_attachment=True, download_name=dl, mimetype="text/html")

        return _jsonify({"ok": False, "error": "FMT_UNSUPPORTED", "fmt": fmt}), 400

    # Force override endpoint used by /api/vsp/run_export_v3
    __A = _vsp__pick_app()
    if __A is not None:
        __A.view_functions["api_vsp_run_export_v3_commercial_real_v1"] = api_vsp_run_export_v3_force_hotfix
except Exception:
    pass
# ===================== /VSP_P1_EXPORT_FORCE_OVERRIDE_HOTFIX_V1 =====================


# ===================== VSP_P1_EXPORT_FORCE_OVERRIDE_HOTFIX_V2 =====================
# Robust override: find actual endpoint(s) bound to /api/vsp/run_export_v3 via url_map, then swap view_func.
try:
    import re as _re, json as _json, tarfile as _tarfile
    from pathlib import Path as _Path
    from flask import request as _req, send_file as _send_file, jsonify as _jsonify

    def _vsp__pick_app_v2():
        for k in ("_app","app","application"):
            a = globals().get(k)
            if a is not None and hasattr(a, "view_functions") and hasattr(a, "url_map"):
                return a
        return None

    def _vsp__norm_rid_v2(rid0: str) -> str:
        rid0 = (rid0 or "").strip()
        m = _re.search(r'(\d{8}_\d{6})', rid0)
        return (m.group(1) if m else rid0.replace("VSP_CI_RUN_","").replace("VSP_CI_","").replace("RUN_","")).strip()

    def _vsp__rel_meta_v2():
        try:
            ui_root = _Path(__file__).resolve().parent
            cands = [
                ui_root/"out_ci"/"releases"/"release_latest.json",
                ui_root/"out"/"releases"/"release_latest.json",
                ui_root.parent/"out_ci"/"releases"/"release_latest.json",
                ui_root.parent/"out"/"releases"/"release_latest.json",
            ]
            for f in cands:
                if f.exists():
                    j = _json.loads(f.read_text(encoding="utf-8", errors="replace"))
                    return {
                        "ts": (j.get("ts") or j.get("timestamp") or ""),
                        "sha": (j.get("sha") or j.get("sha256") or ""),
                    }
        except Exception:
            pass
        return {"ts":"", "sha":""}

    def _vsp__resolve_run_dir_v2(rid0: str, rid_norm: str) -> str:
        # prefer existing helper if present
        try:
            if "_vsp__resolve_run_dir_for_export" in globals():
                x = globals()["_vsp__resolve_run_dir_for_export"](rid0, rid_norm)  # type: ignore
                if x:
                    return str(x)
        except Exception:
            pass
        # last resort: known root
        cand = _Path("/home/test/Data/SECURITY_BUNDLE/out") / (rid0 if rid0.startswith("RUN_") else f"RUN_{rid_norm}")
        if cand.exists() and cand.is_dir():
            return str(cand)
        return ""

    def _vsp__export_build_tgz_v2(run_dir: str, rid_norm: str) -> str:
        rd = _Path(run_dir)
        out = _Path("/tmp") / f"vsp_export_{rid_norm or rd.name}.tgz"
        try:
            if out.exists():
                out.unlink()
        except Exception:
            pass

        picks = [
            rd/"run_gate.json",
            rd/"run_gate_summary.json",
            rd/"findings_unified.json",
            rd/"reports",
            rd/"SUMMARY.txt",
        ]
        with _tarfile.open(out, "w:gz") as tf:
            base = f"{rid_norm or rd.name}"
            for x in picks:
                try:
                    if not x.exists():
                        continue
                    tf.add(str(x), arcname=f"{base}/{x.name}")
                except Exception:
                    continue
        return str(out)

    def api_vsp_run_export_v3_force_hotfix_v2(**kwargs):
        rid0 = (_req.args.get("rid") or _req.args.get("run_id") or _req.args.get("RID") or "").strip()
        if not rid0:
            # maybe passed as path arg
            rid0 = (kwargs.get("rid") or kwargs.get("run_id") or "").strip() if isinstance(kwargs, dict) else ""
        fmt = (_req.args.get("fmt") or "tgz").strip().lower()
        rid_norm = _vsp__norm_rid_v2(rid0)

        run_dir = _vsp__resolve_run_dir_v2(rid0, rid_norm)
        if not run_dir:
            return _jsonify({"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix": "v2"}), 404

        rel = _vsp__rel_meta_v2()
        suffix = ""
        if rel.get("ts"):
            t = str(rel["ts"]).replace(":","").replace("-","").replace("T","_")
            suffix += f"_rel-{t[:15]}"
        if rel.get("sha"):
            suffix += f"_sha-{str(rel['sha'])[:12]}"

        if fmt == "tgz":
            fp = _vsp__export_build_tgz_v2(run_dir, rid_norm or rid0)
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.tgz"
            return _send_file(fp, as_attachment=True, download_name=dl, mimetype="application/gzip")

        if fmt == "csv":
            rd = _Path(run_dir)
            cand = rd/"reports"/"findings_unified.csv"
            if not cand.exists():
                cand = rd/"reports"/"findings.csv"
            if not cand.exists():
                return _jsonify({"ok": False, "error": "CSV_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix": "v2"}), 404
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.csv"
            return _send_file(str(cand), as_attachment=True, download_name=dl, mimetype="text/csv")

        if fmt == "html":
            rd = _Path(run_dir)
            cand = rd/"reports"/"findings_unified.html"
            if not cand.exists():
                cand = rd/"reports"/"index.html"
            if not cand.exists():
                return _jsonify({"ok": False, "error": "HTML_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix": "v2"}), 404
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.html"
            return _send_file(str(cand), as_attachment=True, download_name=dl, mimetype="text/html")

        return _jsonify({"ok": False, "error": "FMT_UNSUPPORTED", "fmt": fmt, "hotfix":"v2"}), 400

    __A = _vsp__pick_app_v2()
    if __A is not None:
        eps = set()
        for rule in __A.url_map.iter_rules():
            rr = getattr(rule, "rule", "") or ""
            if rr == "/api/vsp/run_export_v3" or "run_export_v3" in rr:
                eps.add(rule.endpoint)
        # override ALL matched endpoints (most robust)
        for ep in eps:
            try:
                __A.view_functions[ep] = api_vsp_run_export_v3_force_hotfix_v2
            except Exception:
                pass
except Exception:
    pass
# ===================== /VSP_P1_EXPORT_FORCE_OVERRIDE_HOTFIX_V2 =====================


# ===================== VSP_P1_EXPORT_FORCE_OVERRIDE_HOTFIX_V3 =====================
# Apply export override to the *actual* Flask app(s) present in this module.
try:
    import re as _re, json as _json, tarfile as _tarfile
    from pathlib import Path as _Path
    from flask import request as _req, send_file as _send_file, jsonify as _jsonify

    def _vsp__pick_apps_v3():
        apps=[]
        for k,v in list(globals().items()):
            try:
                if hasattr(v, "url_map") and hasattr(v, "view_functions"):
                    apps.append(v)
            except Exception:
                pass
        # also common names
        for k in ("app","application","_app"):
            v = globals().get(k)
            if v is not None and v not in apps:
                try:
                    if hasattr(v, "url_map") and hasattr(v, "view_functions"):
                        apps.append(v)
                except Exception:
                    pass
        return apps

    def _vsp__norm_rid_v3(rid0: str) -> str:
        rid0 = (rid0 or "").strip()
        m = _re.search(r'(\d{8}_\d{6})', rid0)
        return (m.group(1) if m else rid0.replace("VSP_CI_RUN_","").replace("VSP_CI_","").replace("RUN_","")).strip()

    def _vsp__rel_meta_v3():
        try:
            ui_root = _Path(__file__).resolve().parent
            cands = [
                ui_root/"out_ci"/"releases"/"release_latest.json",
                ui_root/"out"/"releases"/"release_latest.json",
                ui_root.parent/"out_ci"/"releases"/"release_latest.json",
                ui_root.parent/"out"/"releases"/"release_latest.json",
            ]
            for f in cands:
                if f.exists():
                    j = _json.loads(f.read_text(encoding="utf-8", errors="replace"))
                    return {
                        "ts": (j.get("ts") or j.get("timestamp") or ""),
                        "sha": (j.get("sha") or j.get("sha256") or ""),
                    }
        except Exception:
            pass
        return {"ts":"", "sha":""}

    def _vsp__resolve_run_dir_v3(rid0: str, rid_norm: str) -> str:
        # prefer existing helper if present
        try:
            if "_vsp__resolve_run_dir_for_export" in globals():
                x = globals()["_vsp__resolve_run_dir_for_export"](rid0, rid_norm)  # type: ignore
                if x:
                    return str(x)
        except Exception:
            pass
        # hard fallback (your confirmed real path)
        cand = _Path("/home/test/Data/SECURITY_BUNDLE/out") / (rid0 if rid0.startswith("RUN_") else f"RUN_{rid_norm}")
        if cand.exists() and cand.is_dir():
            return str(cand)
        # also check CI roots
        for root in [
            _Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
            _Path("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            _Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        ]:
            try:
                if not root.exists():
                    continue
                for nm in [rid0, f"RUN_{rid_norm}", f"VSP_CI_RUN_{rid_norm}", f"VSP_CI_{rid_norm}", rid_norm]:
                    if not nm:
                        continue
                    c = root / nm
                    if c.exists() and c.is_dir():
                        return str(c)
            except Exception:
                pass
        return ""

    def _vsp__export_build_tgz_v3(run_dir: str, rid_norm: str) -> str:
        rd = _Path(run_dir)
        out = _Path("/tmp") / f"vsp_export_{rid_norm or rd.name}.tgz"
        try:
            if out.exists():
                out.unlink()
        except Exception:
            pass
        picks = [
            rd/"run_gate.json",
            rd/"run_gate_summary.json",
            rd/"findings_unified.json",
            rd/"reports",
            rd/"SUMMARY.txt",
        ]
        with _tarfile.open(out, "w:gz") as tf:
            base = f"{rid_norm or rd.name}"
            for x in picks:
                try:
                    if not x.exists():
                        continue
                    tf.add(str(x), arcname=f"{base}/{x.name}")
                except Exception:
                    continue
        return str(out)

    def api_vsp_run_export_v3_force_hotfix_v3(**kwargs):
        rid0 = (_req.args.get("rid") or _req.args.get("run_id") or _req.args.get("RID") or "").strip()
        if not rid0:
            rid0 = (kwargs.get("rid") or kwargs.get("run_id") or "").strip() if isinstance(kwargs, dict) else ""
        fmt = (_req.args.get("fmt") or "tgz").strip().lower()
        rid_norm = _vsp__norm_rid_v3(rid0)

        run_dir = _vsp__resolve_run_dir_v3(rid0, rid_norm)
        if not run_dir:
            return _jsonify({"ok": False, "error": "RUN_DIR_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix": "export_override_v3"}), 404

        rel = _vsp__rel_meta_v3()
        suffix = ""
        if rel.get("ts"):
            t = str(rel["ts"]).replace(":","").replace("-","").replace("T","_")
            suffix += f"_rel-{t[:15]}"
        if rel.get("sha"):
            suffix += f"_sha-{str(rel['sha'])[:12]}"

        if fmt == "tgz":
            fp = _vsp__export_build_tgz_v3(run_dir, rid_norm or rid0)
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.tgz"
            resp = _send_file(fp, as_attachment=True, download_name=dl, mimetype="application/gzip")
            try: resp.headers["X-VSP-HOTFIX"] = "export_override_v3"
            except Exception: pass
            return resp

        if fmt == "csv":
            rd = _Path(run_dir)
            cand = rd/"reports"/"findings_unified.csv"
            if not cand.exists():
                cand = rd/"reports"/"findings.csv"
            if not cand.exists():
                return _jsonify({"ok": False, "error": "CSV_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix": "export_override_v3"}), 404
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.csv"
            resp = _send_file(str(cand), as_attachment=True, download_name=dl, mimetype="text/csv")
            try: resp.headers["X-VSP-HOTFIX"] = "export_override_v3"
            except Exception: pass
            return resp

        if fmt == "html":
            rd = _Path(run_dir)
            cand = rd/"reports"/"findings_unified.html"
            if not cand.exists():
                cand = rd/"reports"/"index.html"
            if not cand.exists():
                return _jsonify({"ok": False, "error": "HTML_NOT_FOUND", "rid": rid0, "rid_norm": rid_norm, "hotfix": "export_override_v3"}), 404
            dl = f"VSP_EXPORT_{rid_norm or rid0}{suffix}.html"
            resp = _send_file(str(cand), as_attachment=True, download_name=dl, mimetype="text/html")
            try: resp.headers["X-VSP-HOTFIX"] = "export_override_v3"
            except Exception: pass
            return resp

        return _jsonify({"ok": False, "error": "FMT_UNSUPPORTED", "fmt": fmt, "hotfix":"export_override_v3"}), 400

    # Bind override to all endpoints whose rule is /api/vsp/run_export_v3 (or contains run_export_v3)
    for __A in _vsp__pick_apps_v3():
        try:
            eps=set()
            for rule in __A.url_map.iter_rules():
                rr = getattr(rule, "rule", "") or ""
                if rr == "/api/vsp/run_export_v3" or "run_export_v3" in rr:
                    eps.add(rule.endpoint)
            for ep in eps:
                try:
                    __A.view_functions[ep] = api_vsp_run_export_v3_force_hotfix_v3
                except Exception:
                    pass
        except Exception:
            pass
except Exception:
    pass
# ===================== /VSP_P1_EXPORT_FORCE_OVERRIDE_HOTFIX_V3 =====================


# ===================== VSP_P1_AFTER_REQUEST_OKWRAP_RUNGATE_SUMMARY_V2 =====================
# Contractize /api/vsp/run_file_allow?path=run_gate_summary.json to always include ok:true (+ rid/run_id)
try:
    from flask import request as _vsp_req
except Exception:
    _vsp_req = None

@app.after_request
def _vsp_after_request_okwrap_rungate_summary(resp):
    try:
        if _vsp_req is None:
            return resp
        if _vsp_req.path != "/api/vsp/run_file_allow":
            return resp

        p = _vsp_req.args.get("path", "") or ""
        if not (str(p).endswith("run_gate_summary.json") or str(p).endswith("run_gate.json")):
            return resp

        rid = _vsp_req.args.get("rid", "") or ""

        try:

            resp.direct_passthrough = False

        except Exception:

            pass

        txt = resp.get_data(as_text=True)
        import json as _json
        j = _json.loads(txt)

        if isinstance(j, dict):
            j.setdefault("ok", True)
            if rid:
                j.setdefault("rid", rid)
                j.setdefault("run_id", rid)
            out = _json.dumps(j, ensure_ascii=False)
            resp.set_data(out)
            resp.headers["Content-Type"] = "application/json; charset=utf-8"
            resp.headers["Cache-Control"] = "no-cache"
            resp.headers["Content-Length"] = str(len(resp.get_data()))
        return resp
    except Exception:
        return resp
# ===================== /VSP_P1_AFTER_REQUEST_OKWRAP_RUNGATE_SUMMARY_V2 =====================


# ===================== VSP_P1_AFTERREQ_OKWRAP_RUNFILEALLOW_V1 =====================
# Contractize /api/vsp/run_file_allow?path=run_gate_summary.json / run_gate.json => always include ok:true (+ rid/run_id)
def _vsp_after_request_okwrap_runfileallow(resp):
    try:
        from flask import request as _req
        if _req.path != "/api/vsp/run_file_allow":
            return resp
        _path = _req.args.get("path", "") or ""
        if not (str(_path).endswith("run_gate_summary.json") or str(_path).endswith("run_gate.json")):
            return resp

        _rid = _req.args.get("rid", "") or ""
        try:
            resp.direct_passthrough = False
        except Exception:
            pass
        txt = resp.get_data(as_text=True)

        import json as _json
        j = _json.loads(txt)
        if isinstance(j, dict):
            j.setdefault("ok", True)
            if _rid:
                j.setdefault("rid", _rid)
                j.setdefault("run_id", _rid)
            out = _json.dumps(j, ensure_ascii=False)
            resp.set_data(out)
            resp.headers["Content-Type"] = "application/json; charset=utf-8"
            resp.headers["Cache-Control"] = "no-cache"
            resp.headers["Content-Length"] = str(len(resp.get_data()))
        return resp
    except Exception:
        return resp

# register to whichever Flask app exists in this module
try:
    _APP = globals().get("app") or globals().get("application")
    if _APP is not None and hasattr(_APP, "after_request"):
        _APP.after_request(_vsp_after_request_okwrap_runfileallow)
except Exception:
    pass
# ===================== /VSP_P1_AFTERREQ_OKWRAP_RUNFILEALLOW_V1 =====================



# ===================== VSP_P0_HEALTHZ_V1 =====================
# Lightweight health endpoint for CI/demo readiness (no heavy IO; safe fallbacks)
import os, json, time
from pathlib import Path
from flask import jsonify, request

def _health_read_release():
    cands = []
    envp = os.environ.get("VSP_RELEASE_LATEST_JSON", "").strip()
    if envp:
        cands.append(envp)
    cands += [
        "/home/test/Data/SECURITY_BUNDLE/out_ci/releases/release_latest.json",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/releases/release_latest.json",
        str(Path(__file__).resolve().parent / "out_ci" / "releases" / "release_latest.json"),
        str(Path(__file__).resolve().parent / "out" / "releases" / "release_latest.json"),
    ]
    for x in cands:
        try:
            rp = Path(x)
            if rp.is_file() and rp.stat().st_size > 0:
                return json.loads(rp.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
    return {}

def _health_release_status(relj):
    pkg = str(relj.get("release_pkg") or "").strip()
    if not pkg:
        return ("STALE", "", False)
    # pkg is usually like out_ci/releases/xxx.tgz -> resolve under SECURITY_BUNDLE root if relative
    if pkg.startswith("/"):
        pp = Path(pkg)
    else:
        pp = Path("/home/test/Data/SECURITY_BUNDLE") / pkg
    ok = pp.is_file() and pp.stat().st_size > 0
    return ("OK" if ok else "STALE", pkg, ok)

def _health_rid_latest_gate_root():
    # Best effort:
    # 1) env VSP_RID_LATEST
    rid = os.environ.get("VSP_RID_LATEST", "").strip()
    if rid:
        return rid

    # 2) pick newest run dir that contains run_gate_summary.json (cheap filesystem scan)
    roots = [
        Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
    ]
    best = None
    best_m = 0.0
    for root in roots:
        try:
            if not root.is_dir():
                continue
            for d in root.iterdir():
                if not d.is_dir():
                    continue
                f = d / "run_gate_summary.json"
                if f.is_file() and f.stat().st_size > 0:
                    mt = f.stat().st_mtime
                    if mt > best_m:
                        best_m = mt
                        best = d.name
        except Exception:
            continue
    return best or ""
def _health_degraded_tools_count():
    # Best effort: read run_gate_summary.json for latest rid if possible, else 0
    rid = _health_rid_latest_gate_root()
    if not rid:
        return 0
    # common locations
    roots = [
        Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        Path("/home/test/Data/SECURITY_BUNDLE"),
    ]
    for r in roots:
        try:
            f = r / rid / "run_gate_summary.json"
            if f.is_file() and f.stat().st_size > 0:
                j = json.loads(f.read_text(encoding="utf-8", errors="replace"))
                by = j.get("by_tool") or {}
                d = 0
                for _, v in by.items():
                    if isinstance(v, dict) and v.get("degraded") is True:
                        d += 1
                return d
        except Exception:
            continue
    return 0
# [DISABLED] @app.get("/api/vsp/healthz")
def vsp_healthz_v1():
    relj = _health_read_release()
    rel_status, rel_pkg, rel_pkg_exists = _health_release_status(relj)
    out = {
        "ok": True,
        "service_up": True,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "rid_latest_gate_root": _health_rid_latest_gate_root(),
        "degraded_tools_count": _health_degraded_tools_count(),
        "release_status": rel_status,
        "release_ts": relj.get("release_ts", ""),
        "release_sha": relj.get("release_sha", ""),
        "release_pkg": rel_pkg,
        "release_pkg_exists": rel_pkg_exists,
    }
    resp = jsonify(out)
    # also mirror in headers for super quick CLI grep
    if out.get("release_ts"):
        resp.headers["X-VSP-RELEASE-TS"] = str(out["release_ts"])
    if out.get("release_sha"):
        resp.headers["X-VSP-RELEASE-SHA"] = str(out["release_sha"])
    if out.get("release_pkg"):
        resp.headers["X-VSP-RELEASE-PKG"] = str(out["release_pkg"])
    resp.headers["X-VSP-HEALTHZ"] = "ok"
    return resp
# ===================== /VSP_P0_HEALTHZ_V1 =====================



# ===================== VSP_P0_ALIAS_RID_LATEST_GATE_ROOT_GATE_ROOT_V1 =====================
try:
    @app.get("/api/vsp/rid_latest_gate_root_gate_root")
    def vsp_alias_rid_latest_gate_root_gate_root():
        # Fetch() will follow redirect and still get JSON.
        return redirect("/api/vsp/rid_latest_gate_root", code=302)
except Exception:
    pass
# ===================== /VSP_P0_ALIAS_RID_LATEST_GATE_ROOT_GATE_ROOT_V1 =====================

# ===================== VSP_P0_HEALTHZ_TRUEFIX_V2_SAFEAPPEND =====================
# Register /api/vsp/healthz at EOF to avoid NameError or mid-statement injection.
import os, json, time
from pathlib import Path
from flask import jsonify

def _vsp_hz_read_release():
    cands = []
    envp = os.environ.get("VSP_RELEASE_LATEST_JSON", "").strip()
    if envp:
        cands.append(envp)
    cands += [
        "/home/test/Data/SECURITY_BUNDLE/out_ci/releases/release_latest.json",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/releases/release_latest.json",
        str(Path(__file__).resolve().parent / "out_ci" / "releases" / "release_latest.json"),
        str(Path(__file__).resolve().parent / "out" / "releases" / "release_latest.json"),
    ]
    for x in cands:
        try:
            rp = Path(x)
            if rp.is_file() and rp.stat().st_size > 0:
                return json.loads(rp.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
    return {}

def _vsp_hz_release_status(relj):
    pkg = str(relj.get("release_pkg") or "").strip()
    if not pkg:
        return ("STALE", "", False)
    pp = Path(pkg) if pkg.startswith("/") else (Path("/home/test/Data/SECURITY_BUNDLE") / pkg)
    ok = pp.is_file() and pp.stat().st_size > 0
    return ("OK" if ok else "STALE", pkg, ok)

def _vsp_hz_pick_latest_rid():
    rid = os.environ.get("VSP_RID_LATEST", "").strip()
    if rid:
        return rid
    roots = [Path("/home/test/Data/SECURITY_BUNDLE/out_ci"), Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci")]
    best = None
    best_m = 0.0
    for root in roots:
        try:
            if not root.is_dir():
                continue
            for d in root.iterdir():
                if not d.is_dir():
                    continue
                f = d / "run_gate_summary.json"
                if f.is_file() and f.stat().st_size > 0:
                    mt = f.stat().st_mtime
                    if mt > best_m:
                        best_m = mt
                        best = d.name
        except Exception:
            continue
    # resolve "latest" symlink if any
    if best == "latest":
        for root in roots:
            lp = root / "latest"
            try:
                if lp.exists() and lp.is_symlink():
                    tgt = lp.resolve()
                    if tgt and tgt.name and tgt.name != "latest":
                        best = tgt.name
                        break
            except Exception:
                pass
    return best or ""

def _vsp_hz_degraded_tools_count(rid: str):
    if not rid:
        return 0
    roots = [
        Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        Path("/home/test/Data/SECURITY_BUNDLE"),
    ]
    for r in roots:
        try:
            f = r / rid / "run_gate_summary.json"
            if f.is_file() and f.stat().st_size > 0:
                j = json.loads(f.read_text(encoding="utf-8", errors="replace"))
                by = j.get("by_tool") or {}
                d = 0
                for _, v in by.items():
                    if isinstance(v, dict) and v.get("degraded") is True:
                        d += 1
                return d
        except Exception:
            continue
    return 0

def _vsp_register_healthz_v2(app):
    if not app:
        return
    if getattr(app, "__vsp_healthz_truefix_v2", False):
        return
    # if rule already exists, don't re-add
    try:
        for r in app.url_map.iter_rules():
            if getattr(r, "rule", "") == "/api/vsp/healthz":
                app.__vsp_healthz_truefix_v2 = True
                return
    except Exception:
        pass

    def _handler():
        relj = _vsp_hz_read_release()
        rel_status, rel_pkg, rel_pkg_exists = _vsp_hz_release_status(relj)
        rid = _vsp_hz_pick_latest_rid()
        out = {
            "ok": True,
            "service_up": True,
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "rid_latest_gate_root": rid,
            "degraded_tools_count": _vsp_hz_degraded_tools_count(rid),
            "release_status": rel_status,
            "release_ts": relj.get("release_ts", ""),
            "release_sha": relj.get("release_sha", ""),
            "release_pkg": rel_pkg,
            "release_pkg_exists": rel_pkg_exists,
        }
        resp = jsonify(out)
        if out.get("release_ts"):  resp.headers["X-VSP-RELEASE-TS"] = str(out["release_ts"])
        if out.get("release_sha"): resp.headers["X-VSP-RELEASE-SHA"] = str(out["release_sha"])
        if out.get("release_pkg"): resp.headers["X-VSP-RELEASE-PKG"] = str(out["release_pkg"])
        resp.headers["X-VSP-HEALTHZ"] = "ok"
        return resp

    try:
        app.add_url_rule("/api/vsp/healthz", "vsp_healthz_truefix_v2", _handler, methods=["GET"])
    except Exception:
        # swallow any add_url_rule conflict
        pass
    app.__vsp_healthz_truefix_v2 = True

# register at EOF (safe)
try:
    _vsp_register_healthz_v2(globals().get("app") or globals().get("application"))
except Exception:
    pass
# ===================== /VSP_P0_HEALTHZ_TRUEFIX_V2_SAFEAPPEND =====================

# ===================== VSP_P1_AUDIT_PACK_API_V1_SAFEAPPEND =====================
# /api/vsp/audit_pack?rid=<RID> -> tgz containing audit evidence + manifest
import os, json, time, tarfile, tempfile
from pathlib import Path
from flask import request, send_file, jsonify

def _vsp_audit_read_release_latest():
    cands = []
    envp = os.environ.get("VSP_RELEASE_LATEST_JSON", "").strip()
    if envp:
        cands.append(envp)
    cands += [
        "/home/test/Data/SECURITY_BUNDLE/out_ci/releases/release_latest.json",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci/releases/release_latest.json",
        str(Path(__file__).resolve().parent / "out_ci" / "releases" / "release_latest.json"),
    ]
    for x in cands:
        try:
            rp = Path(x)
            if rp.is_file() and rp.stat().st_size > 0:
                return json.loads(rp.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
    return {}

def _vsp_audit_sanitize_ts(ts: str) -> str:
    t = (ts or "").strip()
    if not t:
        return ""
    t = t.replace("T", "_").replace(":", "").replace("+", "p")
    t = re.sub(r"[^0-9A-Za-z._-]+", "", t)
    return t

def _vsp_audit_suffix(relj: dict) -> str:
    ts = _vsp_audit_sanitize_ts(str(relj.get("release_ts") or "").strip()) or ("norel-" + time.strftime("%Y%m%d_%H%M%S"))
    sha = str(relj.get("release_sha") or "").strip()
    sha12 = sha[:12] if sha else "unknown"
    if ts.startswith("norel-"):
        return f"_{ts}_sha-{sha12}"
    return f"_rel-{ts}_sha-{sha12}"

def _vsp_find_run_dir(rid: str) -> Path | None:
    rid = (rid or "").strip()
    if not rid:
        return None
    # allow rid to be a path
    try:
        rp = Path(rid)
        if rp.is_dir():
            return rp
    except Exception:
        pass

    roots = [
        Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
        Path("/home/test/Data/SECURITY_BUNDLE/out"),
        Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
        Path("/home/test/Data/SECURITY_BUNDLE/ui/out"),
    ]
    for root in roots:
        try:
            d = root / rid
            if d.is_dir():
                return d
        except Exception:
            continue
    return None

def _vsp_add_path(tar: tarfile.TarFile, src: Path, arc_prefix: str, manifest: dict):
    try:
        if src.is_file():
            tar.add(src.as_posix(), arcname=f"{arc_prefix}/{src.name}")
            manifest["included"].append(str(src))
        elif src.is_dir():
            # add directory recursively under its own name
            tar.add(src.as_posix(), arcname=f"{arc_prefix}/{src.name}")
            manifest["included"].append(str(src) + "/")
        else:
            manifest["missing"].append(str(src))
    except Exception as e:
        manifest["errors"].append({"path": str(src), "err": str(e)})

def _vsp_register_audit_pack_api(app):
    if not app:
        return
    if getattr(app, "__vsp_audit_pack_api_v1", False):
        return

    # avoid duplicate rule
    try:
        for r in app.url_map.iter_rules():
            if getattr(r, "rule", "") == "/api/vsp/audit_pack":
                app.__vsp_audit_pack_api_v1 = True
                return
    except Exception:
        pass

    def _handler():
        rid = (request.args.get("rid") or request.args.get("run_id") or "").strip()
        if not rid:
            return jsonify({"ok": False, "err": "missing rid"}), 400

        run_dir = _vsp_find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "err": f"RUN_DIR_NOT_FOUND rid={rid}"}), 404

        relj = _vsp_audit_read_release_latest()
        suffix = _vsp_audit_suffix(relj)
        fname = f"AUDIT_{rid}{suffix}.tgz"

        tmpd = Path(tempfile.mkdtemp(prefix="vsp_audit_"))
        out = tmpd / fname

        manifest = {
            "ok": True,
            "rid": rid,
            "run_dir": str(run_dir),
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "release": {
                "release_ts": relj.get("release_ts",""),
                "release_sha": relj.get("release_sha",""),
                "release_pkg": relj.get("release_pkg",""),
            },
            "included": [],
            "missing": [],
            "errors": [],
        }

        arc_prefix = f"AUDIT_{rid}"

        # Candidate core files
        candidates = [
            run_dir / "run_gate_summary.json",
            run_dir / "run_gate.json",
            run_dir / "findings_unified.json",
            run_dir / "findings_unified.csv",
            run_dir / "findings_unified.sarif",
            run_dir / "SUMMARY.txt",
            run_dir / "reports",
            run_dir / "evidence",
        ]

        # Also include reports/findings_unified.* if the pipeline puts them there
        candidates += [
            run_dir / "reports" / "findings_unified.csv",
            run_dir / "reports" / "findings_unified.sarif",
            run_dir / "reports" / "findings_unified.html",
        ]

        # release_latest.json
        for rp in [
            Path("/home/test/Data/SECURITY_BUNDLE/out_ci/releases/release_latest.json"),
            Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/releases/release_latest.json"),
            Path(__file__).resolve().parent / "out_ci" / "releases" / "release_latest.json",
        ]:
            if rp.is_file() and rp.stat().st_size > 0:
                candidates.append(rp)
                break

        # build tgz
        with tarfile.open(out.as_posix(), "w:gz") as tar:
            for c in candidates:
                _vsp_add_path(tar, c, arc_prefix, manifest)

            # write manifest into archive
            man_path = tmpd / "AUDIT_MANIFEST.json"
            man_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
            tar.add(man_path.as_posix(), arcname=f"{arc_prefix}/AUDIT_MANIFEST.json")

        resp = send_file(out.as_posix(), as_attachment=True, download_name=fname, mimetype="application/gzip")
        # mirror build identity headers (nice for audit)
        if relj.get("release_ts"):  resp.headers["X-VSP-RELEASE-TS"]  = str(relj.get("release_ts"))
        if relj.get("release_sha"): resp.headers["X-VSP-RELEASE-SHA"] = str(relj.get("release_sha"))
        if relj.get("release_pkg"): resp.headers["X-VSP-RELEASE-PKG"] = str(relj.get("release_pkg"))
        resp.headers["X-VSP-AUDIT"] = "ok"
        return resp

    app.add_url_rule("/api/vsp/audit_pack", "vsp_audit_pack_v1", _handler, methods=["GET"])
    app.__vsp_audit_pack_api_v1 = True

# register at EOF (safe)
try:
    _vsp_register_audit_pack_api(globals().get("app") or globals().get("application"))
except Exception:
    pass
# ===================== /VSP_P1_AUDIT_PACK_API_V1_SAFEAPPEND =====================


# ===================== VSP_P1_RELEASE_PKG_EXISTS_ENDPOINT_V1 =====================
try:
    import os, time
    from pathlib import Path

    @app.get("/api/vsp/release_pkg_exists")
    def vsp_release_pkg_exists_v1():
        """
        Safe verifier for release package existence.
        Only allows relative paths under out_ci/releases/.
        """
        rel = (request.args.get("path") or "").strip()
        # normalize
        rel = rel.lstrip("/")

        allow_prefix = "out_ci/releases/"
        ok = True
        exists = False
        size = 0
        abs_path = ""

        if not rel or not rel.startswith(allow_prefix) or ".." in rel or "\\\\" in rel:
            return jsonify({"ok": False, "err": "bad path", "exists": False}), 400

        root = Path("/home/test/Data/SECURITY_BUNDLE")
        ap = (root / rel).resolve()
        abs_path = str(ap)

        # enforce within releases dir
        releases_dir = (root / "out_ci" / "releases").resolve()
        if not str(ap).startswith(str(releases_dir)):
            return jsonify({"ok": False, "err": "not allowed", "exists": False}), 403

        if ap.exists() and ap.is_file():
            exists = True
            try:
                size = ap.stat().st_size
            except Exception:
                size = 0

        return jsonify({
            "ok": ok,
            "exists": exists,
            "size": size,
            "path": rel,
            "abs": abs_path,
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        })
except Exception as _e:
    # do not break app import if something is odd
    pass
# ===================== /VSP_P1_RELEASE_PKG_EXISTS_ENDPOINT_V1 =====================


# ===================== VSP_P1_RELEASE_PKG_DOWNLOAD_ENDPOINT_V1 =====================
try:
    import os, time
    from pathlib import Path

    @app.get("/api/vsp/release_pkg_download")
    def vsp_release_pkg_download_v1():
        """
        Safe download for release package (.tgz).
        Only allows relative paths under out_ci/releases/.
        """
        rel = (request.args.get("path") or "").strip().lstrip("/")
        allow_prefix = "out_ci/releases/"

        if not rel or not rel.startswith(allow_prefix) or ".." in rel or "\\\\" in rel:
            return jsonify({"ok": False, "err": "bad path"}), 400

        root = Path("/home/test/Data/SECURITY_BUNDLE")
        ap = (root / rel).resolve()

        releases_dir = (root / "out_ci" / "releases").resolve()
        if not str(ap).startswith(str(releases_dir)):
            return jsonify({"ok": False, "err": "not allowed"}), 403

        if not (ap.exists() and ap.is_file()):
            return jsonify({"ok": False, "err": "not found", "path": rel}), 404

        # attachment filename
        fn = ap.name
        resp = send_file(str(ap), as_attachment=True, download_name=fn)
        resp.headers["X-VSP-RELEASE-PKG"] = rel
        resp.headers["X-VSP-RELEASE-PKG-SIZE"] = str(ap.stat().st_size)
        resp.headers["X-VSP-RELEASE-PKG-DL"] = "ok"
        return resp

except Exception:
    pass
# ===================== /VSP_P1_RELEASE_PKG_DOWNLOAD_ENDPOINT_V1 =====================

# ===================== VSP_P1_RELEASE_DIRECT_ROUTE_OUT_CI_V1 =====================
@app.get("/out_ci/releases/<path:fname>")
def vsp_release_pkg_direct_out_ci(fname):
    """
    Compatibility route:
      /out_ci/releases/<tgz>  -> 302 to /api/vsp/release_pkg_download?path=out_ci/releases/<tgz>
    This prevents 404 when user pastes the package URL directly in browser.
    """
    try:
        from flask import abort, redirect
    except Exception:
        # ultra-safe fallback
        return ("not ready", 503)

    # basic hardening
    if not fname or ".." in fname or fname.startswith("/"):
        return abort(400)

    # allow only tgz under releases
    if not fname.endswith(".tgz"):
        return abort(404)

    rel = f"out_ci/releases/{fname}"

    try:
        from urllib.parse import quote
        q = quote(rel, safe="")
    except Exception:
        q = rel.replace(" ", "%20")

    return redirect(f"/api/vsp/release_pkg_download?path={q}", code=302)
# ===================== /VSP_P1_RELEASE_DIRECT_ROUTE_OUT_CI_V1 =====================

# ===================== VSP_P1_RELEASE_LATEST_ADD_URLS_IN_APP_V1 =====================
try:
    from urllib.parse import quote as _vsp_quote
except Exception:
    _vsp_quote = None

@app.after_request
def _vsp_p1_release_latest_add_urls_in_app_v1(resp):
    """
    Enrich /api/vsp/release_latest JSON with:
      - package_url: /out_ci/releases/<name>.tgz (compat link; now 302->download)
      - download_url: /api/vsp/release_pkg_download?path=<release_pkg>
    This avoids touching WSGI gateway intercept logic.
    """
    try:
        if not resp:
            return resp
        # match path (Flask request is available)
        from flask import request
        if request.path != "/api/vsp/release_latest":
            return resp
        ct = (resp.headers.get("Content-Type") or "").lower()
        if "application/json" not in ct:
            return resp

        import json
        data = json.loads(resp.get_data(as_text=True) or "{}")
        if not isinstance(data, dict) or not data.get("ok"):
            return resp

        rel = data.get("release_pkg") or ""
        if rel and isinstance(rel, str):
            name = rel.split("/")[-1]
            # compat URL (browser paste)
            data["package_url"] = f"/out_ci/releases/{name}"
            # canonical download URL
            if _vsp_quote:
                q = _vsp_quote(rel, safe="")
            else:
                q = rel.replace(" ", "%20")
            data["download_url"] = f"/api/vsp/release_pkg_download?path={q}"

        # re-encode response (keep status/headers)
        resp.set_data(json.dumps(data, ensure_ascii=False))
        resp.headers["Content-Length"] = str(len(resp.get_data()))
        resp.headers["X-VSP-REL-URLS"] = "ok"
        return resp
    except Exception:
        return resp
# ===================== /VSP_P1_RELEASE_LATEST_ADD_URLS_IN_APP_V1 =====================


# ===================== VSP_P0_TOPFIND_API_V1 =====================
# API: /api/vsp/top_findings_v1?rid=<RID>&limit=25
# Source priority: findings_unified.json (if exists) -> reports/findings_unified.csv -> reports/findings_unified.sarif
# NOTE: works even when findings_unified.json is missing (your current case).

import os, json, csv

_VSP_SEV_W = {"CRITICAL":600,"HIGH":500,"MEDIUM":400,"LOW":300,"INFO":200,"TRACE":100}

def _vsp_norm(x):
    try:
        return ("" if x is None else str(x)).strip()
    except Exception:
        return ""

def _vsp_norm_sev(x):
    t = _vsp_norm(x).upper()
    if t in _VSP_SEV_W: return t
    if t == "ERROR": return "HIGH"
    if t in ("WARNING","WARN"): return "MEDIUM"
    if t == "NOTE": return "LOW"
    if t == "DEBUG": return "TRACE"
    return t or "INFO"

def _vsp_sort_top(items, limit):
    items.sort(key=lambda it: _VSP_SEV_W.get(str(it.get("severity","")).upper(), 0), reverse=True)
    return items[:max(1,int(limit))]

def _vsp_resolve_run_dir(rid, roots):
    rid = _vsp_norm(rid)
    if not rid: return ""
    for root in roots:
        try:
            d = os.path.join(root, rid)
            if os.path.isdir(d): return d
        except Exception:
            pass
    return ""

def _vsp_csv_to_items(csv_path, limit):
    items=[]
    with open(csv_path, "r", encoding="utf-8", errors="replace", newline="") as f:
        rd = csv.DictReader(f)
        for row in rd:
            if not row: continue
            sev = _vsp_norm_sev(row.get("severity"))
            tool = _vsp_norm(row.get("tool"))
            title = _vsp_norm(row.get("title")) or _vsp_norm(row.get("message")) or _vsp_norm(row.get("rule_id")) or "Finding"
            file = _vsp_norm(row.get("file"))
            line = _vsp_norm(row.get("line"))
            items.append({"severity":sev,"tool":tool,"title":title,"file":file,"line":line})
            if len(items) >= 5000: break
    if not items:
        raise RuntimeError("CSV has no data rows")
    return _vsp_sort_top(items, limit)

def _vsp_sarif_to_items(sarif_path, limit):
    items=[]
    with open(sarif_path, "r", encoding="utf-8", errors="replace") as f:
        j = json.load(f)
    runs = j.get("runs") or []
    for run in runs:
        tool_name = _vsp_norm(((run.get("tool") or {}).get("driver") or {}).get("name"))
        for res in (run.get("results") or []):
            props = res.get("properties") or {}
            sev = _vsp_norm_sev(props.get("severity") or res.get("level"))
            if res.get("level") == "warning" and sev == "INFO": sev = "MEDIUM"
            msg = _vsp_norm(((res.get("message") or {}).get("text"))) or _vsp_norm(res.get("ruleId")) or "Finding"
            loc0 = (((res.get("locations") or [{}])[0]).get("physicalLocation") or {})
            file = _vsp_norm(((loc0.get("artifactLocation") or {}).get("uri")))
            line = _vsp_norm(((loc0.get("region") or {}).get("startLine")))
            items.append({"severity":sev,"tool":_vsp_norm(props.get("tool")) or tool_name,"title":msg,"file":file,"line":line})
            if len(items) >= 8000: break
    if not items:
        raise RuntimeError("SARIF has no results")
    return _vsp_sort_top(items, limit)

def _vsp_unified_json_to_items(json_path, limit):
    with open(json_path, "r", encoding="utf-8", errors="replace") as f:
        j = json.load(f)
    arr = j if isinstance(j, list) else (j.get("findings") or [])
    items=[]
    for fnd in arr:
        meta = fnd.get("meta") or {}
        sev = _vsp_norm_sev(fnd.get("severity") or fnd.get("normalized_severity") or meta.get("severity"))
        tool = _vsp_norm(fnd.get("tool") or meta.get("tool") or fnd.get("source") or fnd.get("engine"))
        title = _vsp_norm(fnd.get("title") or fnd.get("message") or fnd.get("rule_id") or meta.get("title") or meta.get("message") or fnd.get("id")) or "Finding"
        file = _vsp_norm(fnd.get("file") or fnd.get("path") or (fnd.get("location") or {}).get("file") or meta.get("file") or meta.get("path"))
        line = _vsp_norm(fnd.get("line") or (fnd.get("location") or {}).get("line") or meta.get("line"))
        if not title and not file: continue
        items.append({"severity":sev,"tool":tool,"title":title,"file":file,"line":line})
        if len(items) >= 15000: break
    if not items:
        raise RuntimeError("findings_unified.json empty")
    return _vsp_sort_top(items, limit)

@app.get("/api/vsp/top_findings_v1")
def api_vsp_top_findings_v1():
    # rid optional: if missing, reuse rid_latest_gate_root response rid
    rid = request.args.get("rid","")
    limit = request.args.get("limit","25")

    # Use same roots list as rid_latest_gate_root exposes (fallback to defaults)
    roots = [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
    ]

    if not rid:
        # attempt to call existing rid_latest_gate_root function indirectly via internal endpoint
        try:
            # local call (no http): just pick newest folder name lexicographically if nothing else
            # but better: keep old behavior and let user pass rid
            pass
        except Exception:
            pass

    run_dir = _vsp_resolve_run_dir(rid, roots) if rid else ""
    if not run_dir:
        return jsonify({"ok": False, "err": "rid not found on disk", "rid": rid, "roots": roots}), 200

    # try sources
    paths = {
        "json": os.path.join(run_dir, "findings_unified.json"),
        "csv": os.path.join(run_dir, "reports", "findings_unified.csv"),
        "sarif": os.path.join(run_dir, "reports", "findings_unified.sarif"),
    }
    has = []
    for k,v in paths.items():
        try:
            if os.path.isfile(v):
                has.append(k + ":" + os.path.relpath(v, run_dir))
        except Exception:
            pass

    try:
        if os.path.isfile(paths["json"]) and os.path.getsize(paths["json"]) > 200:
            items = _vsp_unified_json_to_items(paths["json"], limit)
            return jsonify({"ok": True, "rid": rid, "source": "findings_unified.json", "items": items, "has": has}), 200
    except Exception:
        pass

    try:
        if os.path.isfile(paths["csv"]) and os.path.getsize(paths["csv"]) > 80:
            items = _vsp_csv_to_items(paths["csv"], limit)
            return jsonify({"ok": True, "rid": rid, "source": "reports/findings_unified.csv", "items": items, "has": has}), 200
    except Exception as e:
        csv_err = str(e)
    else:
        csv_err = ""

    try:
        if os.path.isfile(paths["sarif"]) and os.path.getsize(paths["sarif"]) > 150:
            items = _vsp_sarif_to_items(paths["sarif"], limit)
            return jsonify({"ok": True, "rid": rid, "source": "reports/findings_unified.sarif", "items": items, "has": has}), 200
    except Exception as e:
        sarif_err = str(e)
    else:
        sarif_err = ""

    return jsonify({
        "ok": False,
        "rid": rid,
        "err": "no usable source for top findings",
        "has": has,
        "csv_err": csv_err,
        "sarif_err": sarif_err,
    }), 200

# ===================== /VSP_P0_TOPFIND_API_V1 =====================


# ===================== VSP_P0_TOPFIND_API_V2_HTML_FALLBACK =====================
import re as _vsp_re
import html as _vsp_html

def _vsp__strip_tags(x: str) -> str:
    x = "" if x is None else str(x)
    x = _vsp_re.sub(r"<script\b[^>]*>.*?</script>", " ", x, flags=_vsp_re.I|_vsp_re.S)
    x = _vsp_re.sub(r"<style\b[^>]*>.*?</style>", " ", x, flags=_vsp_re.I|_vsp_re.S)
    x = _vsp_re.sub(r"<[^>]+>", " ", x)
    x = _vsp_html.unescape(x)
    x = _vsp_re.sub(r"\s+", " ", x).strip()
    return x

def _vsp__parse_loc(loc: str):
    loc = _vsp__strip_tags(loc)
    # try "...:123" at the end
    m = _vsp_re.search(r"(.*?):(\d+)\s*$", loc)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return loc, ""

def _vsp_html_to_items(html_path, limit):
    # Parse first reasonable table rows (<tr><td>..)
    txt = Path(html_path).read_text(encoding="utf-8", errors="replace")
    trs = _vsp_re.findall(r"<tr\b[^>]*>(.*?)</tr>", txt, flags=_vsp_re.I|_vsp_re.S)
    items = []
    for tr in trs:
        tds = _vsp_re.findall(r"<td\b[^>]*>(.*?)</td>", tr, flags=_vsp_re.I|_vsp_re.S)
        if len(tds) < 3:
            continue
        cells = [_vsp__strip_tags(x) for x in tds]
        # skip header-like rows
        h0 = (cells[0] or "").lower()
        if h0 in ("severity","sev") or "severity" in h0:
            continue

        # heuristics by column count:
        # 7+: severity, tool, rule_id, title, file, line, message
        # 4+: severity, tool, title, location
        sev = _vsp_norm_sev(cells[0])
        tool = cells[1] if len(cells) > 1 else ""
        if len(cells) >= 7:
            title = cells[3] or cells[6] or "Finding"
            file = cells[4]
            line = cells[5]
        elif len(cells) >= 4:
            title = cells[2] or "Finding"
            file, line = _vsp__parse_loc(cells[3])
        else:
            title = cells[2] or "Finding"
            file = ""
            line = ""
        items.append({"severity": sev, "tool": tool, "title": title, "file": file, "line": line})
        if len(items) >= 20000:
            break
    if not items:
        raise RuntimeError("HTML has no parsable table rows")
    return _vsp_sort_top(items, limit)

@app.get("/api/vsp/top_findings_v2")
def api_vsp_top_findings_v2():
    rid = request.args.get("rid","")
    limit = request.args.get("limit","25")
    roots = [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
    ]
    run_dir = _vsp_resolve_run_dir(rid, roots) if rid else ""
    if not run_dir:
        return jsonify({"ok": False, "err": "rid not found on disk", "rid": rid, "roots": roots}), 200

    paths = {
        "json":  os.path.join(run_dir, "findings_unified.json"),
        "csv":   os.path.join(run_dir, "reports", "findings_unified.csv"),
        "sarif": os.path.join(run_dir, "reports", "findings_unified.sarif"),
        "html":  os.path.join(run_dir, "reports", "findings_unified.html"),
    }
    has=[]
    for k,v in paths.items():
        try:
            if os.path.isfile(v):
                has.append(k+":"+os.path.relpath(v, run_dir))
        except Exception:
            pass

    # json
    try:
        if os.path.isfile(paths["json"]) and os.path.getsize(paths["json"]) > 200:
            items = _vsp_unified_json_to_items(paths["json"], limit)
            return jsonify({"ok": True, "rid": rid, "source":"findings_unified.json", "items": items, "has": has}), 200
    except Exception as e:
        json_err = str(e)
    else:
        json_err = ""

    # csv
    try:
        if os.path.isfile(paths["csv"]) and os.path.getsize(paths["csv"]) > 80:
            items = _vsp_csv_to_items(paths["csv"], limit)
            return jsonify({"ok": True, "rid": rid, "source":"reports/findings_unified.csv", "items": items, "has": has}), 200
    except Exception as e:
        csv_err = str(e)
    else:
        csv_err = ""

    # sarif
    try:
        if os.path.isfile(paths["sarif"]) and os.path.getsize(paths["sarif"]) > 150:
            items = _vsp_sarif_to_items(paths["sarif"], limit)
            return jsonify({"ok": True, "rid": rid, "source":"reports/findings_unified.sarif", "items": items, "has": has}), 200
    except Exception as e:
        sarif_err = str(e)
    else:
        sarif_err = ""

    # html (NEW)
    try:
        if os.path.isfile(paths["html"]) and os.path.getsize(paths["html"]) > 300:
            items = _vsp_html_to_items(paths["html"], limit)
            return jsonify({"ok": True, "rid": rid, "source":"reports/findings_unified.html", "items": items, "has": has}), 200
    except Exception as e:
        html_err = str(e)
    else:
        html_err = ""

    return jsonify({
        "ok": False,
        "rid": rid,
        "err": "no usable source for top findings",
        "has": has,
        "json_err": json_err,
        "csv_err": csv_err,
        "sarif_err": sarif_err,
        "html_err": html_err,
    }), 200
# ===================== /VSP_P0_TOPFIND_API_V2_HTML_FALLBACK =====================


# ===================== VSP_P0_TOPFIND_API_V3_SCAN_ANY_V1 =====================
import os as _os
import json as _json

_VSP3_SEV_W = {"CRITICAL":600,"HIGH":500,"MEDIUM":400,"LOW":300,"INFO":200,"TRACE":100}
def _vsp3_norm(x):
    try: return ("" if x is None else str(x)).strip()
    except Exception: return ""
def _vsp3_norm_sev(x):
    t = _vsp3_norm(x).upper()
    if t in _VSP3_SEV_W: return t
    if t == "ERROR": return "HIGH"
    if t in ("WARNING","WARN"): return "MEDIUM"
    if t == "NOTE": return "LOW"
    if t == "DEBUG": return "TRACE"
    return t or "INFO"
def _vsp3_sort(items, limit):
    items.sort(key=lambda it: _VSP3_SEV_W.get(str(it.get("severity","")).upper(), 0), reverse=True)
    return items[:max(1,int(limit))]

def _vsp3_level_to_sev(level):
    lv = _vsp3_norm(level).lower()
    if lv == "error": return "HIGH"
    if lv == "warning": return "MEDIUM"
    if lv == "note": return "LOW"
    return "INFO"

def _vsp3_pick(obj, keys):
    for k in keys:
        try:
            v = obj.get(k)
        except Exception:
            v = None
        if v is None: 
            continue
        if isinstance(v, (dict,list)):
            continue
        t = _vsp3_norm(v)
        if t: return t
    return ""

def _vsp3_candidates(run_dir):
    # only scan plausible finding files; skip huge + irrelevant
    inc_kw = ("sarif","find","result","semgrep","codeql","bandit","gitleaks","kics","trivy","grype","vuln","issue")
    exc_kw = ("sbom","syft","manifest","evidence","gate","summary","status","settings","license","readme","metrics")
    cands=[]
    for root, dirs, files in _os.walk(run_dir):
        # avoid scanning node_modules/static
        dn = root.lower()
        if "/static/" in dn or "/node_modules/" in dn:
            continue
        for fn in files:
            low = fn.lower()
            if not (low.endswith(".sarif") or low.endswith(".json") or low.endswith(".jsonl") or low.endswith(".ndjson")):
                continue
            full = _os.path.join(root, fn)
            rel = _os.path.relpath(full, run_dir)
            rlow = rel.lower()
            if any(k in rlow for k in exc_kw):
                continue
            if not any(k in rlow for k in inc_kw):
                continue
            try:
                sz = _os.path.getsize(full)
            except Exception:
                continue
            if sz < 120:  # too small
                continue
            if sz > 40*1024*1024:  # too big
                continue
            cands.append((sz, full, rel))
    # prefer smaller first to be fast, but keep reasonable
    cands.sort(key=lambda x: x[0])
    return cands[:120]

def _vsp3_parse_sarif(path, limit):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        j = _json.load(f)
    runs = j.get("runs") or []
    items=[]
    for run in runs:
        tool = _vsp3_norm((((run.get("tool") or {}).get("driver") or {}).get("name")))
        for res in (run.get("results") or []):
            props = res.get("properties") or {}
            sev = _vsp3_norm_sev(props.get("severity")) or _vsp3_level_to_sev(res.get("level"))
            msg = _vsp3_norm(((res.get("message") or {}).get("text"))) or _vsp3_norm(res.get("ruleId")) or "Finding"
            loc0 = (((res.get("locations") or [{}])[0]).get("physicalLocation") or {})
            file = _vsp3_norm(((loc0.get("artifactLocation") or {}).get("uri")))
            line = _vsp3_norm(((loc0.get("region") or {}).get("startLine")))
            items.append({"severity":sev,"tool":tool,"title":msg,"file":file,"line":line})
            if len(items) >= 4000:
                break
    if not items:
        raise RuntimeError("sarif empty results")
    return _vsp3_sort(items, limit)

def _vsp3_parse_generic_json(path, limit):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        j = _json.load(f)

    # list-of-findings style
    if isinstance(j, list) and j and isinstance(j[0], dict):
        items=[]
        for fnd in j[:12000]:
            sev = _vsp3_norm_sev(_vsp3_pick(fnd, ["severity","normalized_severity","level"]))
            tool = _vsp3_pick(fnd, ["tool","source","engine"])
            title = _vsp3_pick(fnd, ["title","message","rule_id","ruleId","id"]) or "Finding"
            file = _vsp3_pick(fnd, ["file","path"])
            line = _vsp3_pick(fnd, ["line","startLine"])
            items.append({"severity":sev or "INFO","tool":tool,"title":title,"file":file,"line":line})
        if items:
            return _vsp3_sort(items, limit)

    # dict formats: try Trivy-like
    if isinstance(j, dict):
        items=[]
        # Trivy: Results -> Vulnerabilities
        if isinstance(j.get("Results"), list):
            for r in j["Results"]:
                for v in (r.get("Vulnerabilities") or []):
                    sev = _vsp3_norm_sev(v.get("Severity"))
                    title = _vsp3_norm(v.get("Title")) or _vsp3_norm(v.get("VulnerabilityID")) or "Vuln"
                    pkg = _vsp3_norm(v.get("PkgName"))
                    file = _vsp3_norm(r.get("Target")) or pkg
                    items.append({"severity":sev,"tool":"trivy","title":title,"file":file,"line":""})
                    if len(items)>=12000: break
        # Grype: matches
        if isinstance(j.get("matches"), list):
            for m in j["matches"]:
                vuln = m.get("vulnerability") or {}
                sev = _vsp3_norm_sev(vuln.get("severity"))
                vid = _vsp3_norm(vuln.get("id")) or "Vuln"
                pkg = ((m.get("artifact") or {}).get("name")) or ""
                items.append({"severity":sev,"tool":"grype","title":vid,"file":_vsp3_norm(pkg),"line":""})
                if len(items)>=12000: break
        if items:
            return _vsp3_sort(items, limit)

    raise RuntimeError("json not recognized as findings")

@app.get("/api/vsp/top_findings_v3")
def api_vsp_top_findings_v3():
    rid = request.args.get("rid","")
    limit = request.args.get("limit","25")
    roots = [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
    ]
    run_dir = _vsp_resolve_run_dir(rid, roots) if rid else ""
    if not run_dir:
        return jsonify({"ok": False, "err": "rid not found on disk", "rid": rid, "roots": roots}), 200

    cands = _vsp3_candidates(run_dir)
    tried=[]
    all_items=[]
    for sz, full, rel in cands:
        tried.append(rel)
        low = rel.lower()
        try:
            if low.endswith(".sarif"):
                items = _vsp3_parse_sarif(full, 300)
            else:
                items = _vsp3_parse_generic_json(full, 300)
            all_items.extend(items)
            if len(all_items) >= 120:
                break
        except Exception:
            continue

    if not all_items:
        return jsonify({
            "ok": False,
            "rid": rid,
            "err": "no findings found in tool outputs (scan)",
            "tried": tried[:25],
            "hint": "This run seems to have counts only; exporters produced empty CSV/SARIF. Check tool raw outputs exist under run dir.",
        }), 200

    top = _vsp3_sort(all_items, limit)
    return jsonify({
        "ok": True,
        "rid": rid,
        "source": "scan:any_tool_outputs",
        "items": top,
        "scanned": len(cands),
        "tried_sample": tried[:12],
    }), 200
# ===================== /VSP_P0_TOPFIND_API_V3_SCAN_ANY_V1 =====================


# ===================== VSP_P0_TOPFIND_API_V4_SEMGREP_PARSE_V1 =====================
# GET /api/vsp/top_findings_v4?rid=...&limit=25
try:
    import os, glob, json, time, re
    from flask import request, jsonify

    _VSP_TOPFIND_ROOTS_V4 = [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
    ]

    def _vsp_topfind_v4_find_run_dir(rid: str):
        if not rid:
            return None
        for root in _VSP_TOPFIND_ROOTS_V4:
            d = os.path.join(root, rid)
            if os.path.isdir(d):
                return d
        return None

    def _vsp_topfind_v4_norm_sev(sev: str):
        if not sev:
            return "INFO"
        s = str(sev).strip().upper()
        # common semgrep: ERROR/WARNING/INFO
        if s in ("ERROR", "ERR"):
            return "HIGH"
        if s in ("WARNING", "WARN"):
            return "MEDIUM"
        if s in ("INFO", "INFORMATION"):
            return "INFO"
        # already normalized?
        if s in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"):
            return s
        return "INFO"

    def _vsp_topfind_v4_pick_semgrep_file(run_dir: str):
        cand = os.path.join(run_dir, "semgrep", "semgrep.json")
        if os.path.isfile(cand) and os.path.getsize(cand) > 200:
            return cand
        # fallback: any semgrep*.json
        hits = []
        for f in glob.glob(os.path.join(run_dir, "**", "*semgrep*.json"), recursive=True):
            try:
                if os.path.getsize(f) > 200:
                    hits.append((os.path.getsize(f), f))
            except Exception:
                continue
        hits.sort(reverse=True)
        return hits[0][1] if hits else None

    def _vsp_topfind_v4_parse_semgrep(path: str, limit: int):
        items = []
        try:
            j = json.load(open(path, "r", encoding="utf-8", errors="ignore"))
        except Exception:
            return items

        results = j.get("results") if isinstance(j, dict) else None
        if not isinstance(results, list):
            return items

        for r in results:
            if not isinstance(r, dict):
                continue
            extra = r.get("extra") or {}
            sev = _vsp_topfind_v4_norm_sev(extra.get("severity") or extra.get("level") or "")
            msg = extra.get("message") or extra.get("metadata", {}).get("message") or ""
            check_id = r.get("check_id") or r.get("rule_id") or ""
            title = (msg or check_id or "Semgrep finding").strip()
            pathf = (r.get("path") or "").strip()
            start = r.get("start") or {}
            line = start.get("line") if isinstance(start, dict) else ""
            # some semgrep outputs have line under "extra"->"lines"
            if not line and isinstance(extra, dict):
                try:
                    line = extra.get("line") or ""
                except Exception:
                    line = ""

            items.append({
                "severity": sev,
                "tool": "semgrep",
                "title": title,
                "file": pathf,
                "line": str(line) if line is not None else "",
            })
            if len(items) >= limit:
                break
        return items

    @app.get("/api/vsp/top_findings_v4")
    def api_vsp_top_findings_v4():
        rid = request.args.get("rid", "").strip()
        try:
            limit = int(request.args.get("limit", "25"))
        except Exception:
            limit = 25
        limit = max(1, min(limit, 200))

        run_dir = _vsp_topfind_v4_find_run_dir(rid)
        if not run_dir:
            return jsonify({"ok": False, "rid": rid, "err": "run_dir not found", "items": [], "ts": int(time.time())}), 200

        sf = _vsp_topfind_v4_pick_semgrep_file(run_dir)
        if not sf:
            return jsonify({
                "ok": False, "rid": rid,
                "err": "semgrep.json not found",
                "hint": "Expected semgrep/semgrep.json or *semgrep*.json under run dir",
                "items": [], "ts": int(time.time())
            }), 200

        items = _vsp_topfind_v4_parse_semgrep(sf, limit)
        if not items:
            return jsonify({
                "ok": False, "rid": rid,
                "err": "semgrep parsed but no results",
                "source": os.path.relpath(sf, run_dir).replace("\\","/"),
                "items": [], "ts": int(time.time())
            }), 200

        return jsonify({
            "ok": True, "rid": rid,
            "source": "semgrep:" + os.path.relpath(sf, run_dir).replace("\\","/"),
            "items": items,
            "ts": int(time.time())
        }), 200

    print("[VSP_P0_TOPFIND_API_V4] enabled")
except Exception as _e:
    print("[VSP_P0_TOPFIND_API_V4] ERROR:", _e)
# ===================== /VSP_P0_TOPFIND_API_V4_SEMGREP_PARSE_V1 =====================



# ===================== VSP_P0_VSP5_DIAG_PAGE_V1C =====================
try:
    import os, glob, json
    import html as _html
    from flask import Response

    _VSP_DIAG_ROOTS_V1C = [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
    ]

    def _vsp_diag_find_run_dir_v1c(rid: str):
        if not rid: return None
        for root in _VSP_DIAG_ROOTS_V1C:
            d = os.path.join(root, rid)
            if os.path.isdir(d):
                return d
        return None

    def _vsp_diag_pick_semgrep_v1c(run_dir: str):
        cand = os.path.join(run_dir, "semgrep", "semgrep.json")
        if os.path.isfile(cand) and os.path.getsize(cand) > 200:
            return cand
        hits=[]
        for f in glob.glob(os.path.join(run_dir, "**", "*semgrep*.json"), recursive=True):
            try:
                if os.path.getsize(f) > 200:
                    hits.append((os.path.getsize(f), f))
            except Exception:
                pass
        hits.sort(reverse=True)
        return hits[0][1] if hits else None

    def _vsp_diag_norm_sev_v1c(sev: str):
        if not sev: return "INFO"
        x = str(sev).strip().upper()
        if x in ("ERROR","ERR"): return "HIGH"
        if x in ("WARNING","WARN"): return "MEDIUM"
        if x in ("INFO","INFORMATION"): return "INFO"
        if x in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"): return x
        return "INFO"

    def _vsp_diag_parse_semgrep_v1c(path: str, limit: int = 10):
        items=[]
        try:
            j=json.load(open(path,"r",encoding="utf-8",errors="ignore"))
        except Exception:
            return items
        results = j.get("results") if isinstance(j, dict) else None
        if not isinstance(results, list):
            return items
        for r in results:
            if not isinstance(r, dict):
                continue
            extra = r.get("extra") or {}
            sev = _vsp_diag_norm_sev_v1c(extra.get("severity") or extra.get("level") or "")
            msg = extra.get("message") or ""
            check_id = r.get("check_id") or r.get("rule_id") or ""
            title = (msg or check_id or "Semgrep finding").strip()
            fpath = (r.get("path") or "").strip()
            start = r.get("start") or {}
            line = start.get("line") if isinstance(start, dict) else ""
            items.append({
                "severity": sev,
                "tool": "semgrep",
                "title": title,
                "file": fpath,
                "line": str(line) if line is not None else "",
            })
            if len(items) >= limit:
                break
        return items

    @app.get("/vsp5_diag")
    def vsp5_diag_page_v1c():
        rid = ""
        try:
            ridj = api_vsp_rid_latest_gate_root().get_json()  # type: ignore
            rid = (ridj or {}).get("rid","") or ""
        except Exception:
            rid = ""

        ok = False
        source = ""
        err = ""
        items = []

        run_dir = _vsp_diag_find_run_dir_v1c(rid) if rid else None
        if not run_dir:
            err = "run_dir not found"
        else:
            sf = _vsp_diag_pick_semgrep_v1c(run_dir)
            if not sf:
                err = "semgrep.json not found"
            else:
                items = _vsp_diag_parse_semgrep_v1c(sf, 10)
                rel = os.path.relpath(sf, run_dir).replace("\\","/")
                source = "semgrep:" + rel
                if items:
                    ok = True
                else:
                    err = "semgrep parsed but no results"

        rows=[]
        for it in items[:10]:
            rows.append(
                "<tr>"
                + "<td>" + _html.escape(str(it.get("severity",""))) + "</td>"
                + "<td>" + _html.escape(str(it.get("tool",""))) + "</td>"
                + "<td>" + _html.escape(str(it.get("title",""))) + "</td>"
                + "<td>" + _html.escape(str(it.get("file",""))) + ":" + _html.escape(str(it.get("line",""))) + "</td>"
                + "</tr>"
            )

        body_lines = [
            "<!doctype html>",
            "<html><head><meta charset='utf-8'>",
            "<meta name='viewport' content='width=device-width, initial-scale=1'>",
            "<title>VSP - vsp5_diag</title>",
            "<style>",
            "body{font-family:system-ui,Segoe UI,Arial;margin:18px;background:#0a0e1a;color:#e6e9f2}",
            ".card{border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:12px;background:rgba(255,255,255,.03)}",
            "table{width:100%;border-collapse:collapse;margin-top:10px;font-size:13px}",
            "th,td{padding:8px;border-top:1px solid rgba(255,255,255,.08);text-align:left}",
            "th{opacity:.75}",
            ".muted{opacity:.75}",
            "code{background:rgba(255,255,255,.06);padding:2px 6px;border-radius:8px}",
            "</style>",
            "</head><body>",
            "<div class='card'>",
            "<div><b>vsp5_diag</b> <span class='muted'>(server-render, no JS bundle)</span></div>",
            "<div class='muted'>rid_latest_gate_root: <code>" + _html.escape(rid) + "</code></div>",
            "<div class='muted'>ok: <code>" + _html.escape(str(ok)) + "</code> source: <code>" + _html.escape(source) + "</code></div>",
            "<div class='muted'>err: <code>" + _html.escape(err) + "</code></div>",
            "<table><thead><tr><th>Sev</th><th>Tool</th><th>Title</th><th>Loc</th></tr></thead>",
            "<tbody>",
            ("".join(rows) if rows else "<tr><td colspan='4' class='muted'>No rows</td></tr>"),
            "</tbody></table>",
            "</div>",
            "</body></html>",
        ]
        body = "\n".join(body_lines)
        return Response(body, mimetype="text/html; charset=utf-8")

    print("[VSP_P0_VSP5_DIAG_PAGE_V1C] enabled")
except Exception as _e:
    print("[VSP_P0_VSP5_DIAG_PAGE_V1C] ERROR:", _e)
# ===================== /VSP_P0_VSP5_DIAG_PAGE_V1C =====================


# ===================== VSP_P1_FORCE_STATIC_JS_MIME_AND_TABS3_ALIAS_V1B =====================
# Force /static/js/*.js to always return application/javascript (avoid JSON fallback => Chrome MIME block)
# Also provide alias for client GET /api/vsp/vsp_tabs3_common_v3.js

from flask import Response, abort, send_from_directory
from pathlib import Path as _Path

@app.get("/api/vsp/vsp_tabs3_common_v3.js")
def vsp_tabs3_common_v3_js_alias_api_vsp():
    js = "/* tabs3 common v3 (alias /api/vsp/) */\nwindow.__vsp_tabs3_common_v3_ok=true;\n"
    return Response(js, mimetype="application/javascript")

# keep the original path too (some pages may call it)
@app.get("/api/vsp_tabs3_common_v3.js")
def vsp_tabs3_common_v3_js_direct():
    js = "/* tabs3 common v3 (direct) */\nwindow.__vsp_tabs3_common_v3_ok=true;\n"
    return Response(js, mimetype="application/javascript")

@app.get("/static/js/<path:fname>")
def vsp_static_js_force_mime(fname):
    # security: block traversal
    if not fname or ".." in fname or fname.startswith(("/", "\\")):
        abort(404)

    root = _Path(__file__).resolve().parent
    jsdir = root / "static" / "js"
    fpath = jsdir / fname
    if not fpath.is_file():
        abort(404)

    # send_from_directory sets correct headers; force mimetype for Chrome strict MIME checks
    return send_from_directory(str(jsdir), fname, mimetype="application/javascript")
# ===================== /VSP_P1_FORCE_STATIC_JS_MIME_AND_TABS3_ALIAS_V1B =====================



# ===================== VSP_P1_TABS3_COMMON_NONEMPTY_V1C_FIX =====================
# Make tabs3 common always non-empty; serve real file if present, else stub.
# Works even if prior alias route exists (this should appear later and override).

from flask import Response, send_from_directory

def _vsp_tabs3_js_payload_nonempty():
    try:
        root = _Path(__file__).resolve().parent
        jsdir = root / "static" / "js"
        cand = jsdir / "vsp_tabs3_common_v3.js"
        if cand.is_file():
            return send_from_directory(str(jsdir), "vsp_tabs3_common_v3.js", mimetype="application/javascript")
    except Exception:
        pass

    js = (
        "/* tabs3 common v3 (fallback stub) */\\n"
        "window.__vsp_tabs3_common_v3_ok=true;\\n"
        "window.__vsp_tabs3_common_v3_ping=function(){return true;};\\n"
    )
    return Response(js, mimetype="application/javascript")

@app.get("/api/vsp/vsp_tabs3_common_v3.js")
def vsp_tabs3_common_v3_js_alias_api_vsp_nonempty_fix():
    return _vsp_tabs3_js_payload_nonempty()

@app.get("/api/vsp_tabs3_common_v3.js")
def vsp_tabs3_common_v3_js_direct_nonempty_fix():
    return _vsp_tabs3_js_payload_nonempty()
# ===================== /VSP_P1_TABS3_COMMON_NONEMPTY_V1C_FIX =====================



# ===================== VSP_P1_STATIC_JS_NORMALIZE_V1D =====================
# Normalize broken /static/js URLs (trailing backslash, %22, quotes) and always serve JS with correct MIME.

from urllib.parse import unquote

@app.get("/static/js/<path:fname>")
def vsp_static_js_force_mime_normalize(fname):
    # fname may include encoded junk; normalize hard
    try:
        fname = unquote(fname)
    except Exception:
        pass
    fname = fname.strip().strip('"').strip("'")
    # strip a trailing backslash that often appears in templates
    while fname.endswith("\\"):
        fname = fname[:-1]
    # remove accidental leading %22 artifacts in path segments
    fname = fname.replace("%22", "").replace("\\\"", "")
    # security: block traversal
    if not fname or ".." in fname or fname.startswith(("/", "\\")):
        abort(404)

    root = _Path(__file__).resolve().parent
    jsdir = root / "static" / "js"
    fpath = jsdir / fname
    if not fpath.is_file():
        abort(404)

    return send_from_directory(str(jsdir), fname, mimetype="application/javascript")
# ===================== /VSP_P1_STATIC_JS_NORMALIZE_V1D =====================



# ===================== VSP_P1_API_VSP_PREFIX_ALIAS_V1E =====================
# Alias endpoints that some legacy JS still calls with /api/vsp/ prefix.

@app.get("/api/vsp/run_file_allow")
def vsp_api_vsp_run_file_allow_alias():
    # reuse existing handler if present; else proxy via internal call to query param logic
    try:
        return api_vsp_run_file_allow()
    except Exception:
        # fallback: call the real endpoint via requests would be overkill; return same-style JSON error
        return {"ok": False, "err": "alias failed: api_vsp_run_file_allow not found"}, 404

@app.get("/api/vsp/run_file")
def vsp_api_vsp_run_file_alias():
    try:
        return api_vsp_run_file()
    except Exception:
        return {"ok": False, "err": "alias failed: api_vsp_run_file not found"}, 404
# ===================== /VSP_P1_API_VSP_PREFIX_ALIAS_V1E =====================



# ===================== VSP_P1_QSTATIC_AND_APIVSP_REDIRECT_V1F =====================
# 1) Fix broken script URLs that contain an extra quote -> browser encodes as %22:
#    e.g. /%22/static/js/x.js  => redirect to /static/js/x.js
# 2) Fix legacy JS calling /api/vsp/* (extra /vsp) by redirecting to /api/vsp/*

from flask import redirect, request

@app.get("/%22/static/<path:rest>")
def vsp_qstatic_redirect(rest):
    # keep query string
    qs = request.query_string.decode("utf-8", errors="ignore")
    url = "/static/" + rest
    if qs:
        url = url + "?" + qs
    return redirect(url, code=307)

@app.get("/api/vsp/run_file_allow")
def vsp_apivsp_run_file_allow_redirect():
    qs = request.query_string.decode("utf-8", errors="ignore")
    url = "/api/vsp/run_file_allow"
    if qs:
        url = url + "?" + qs
    return redirect(url, code=307)

@app.get("/api/vsp/run_file")
def vsp_apivsp_run_file_redirect():
    qs = request.query_string.decode("utf-8", errors="ignore")
    url = "/api/vsp/run_file"
    if qs:
        url = url + "?" + qs
    return redirect(url, code=307)

@app.get("/api/vsp/rid_latest_gate_root")
def vsp_apivsp_rid_latest_gate_root_redirect():
    qs = request.query_string.decode("utf-8", errors="ignore")
    url = "/api/vsp/rid_latest_gate_root"
    if qs:
        url = url + "?" + qs
    return redirect(url, code=307)
# ===================== /VSP_P1_QSTATIC_AND_APIVSP_REDIRECT_V1F =====================



# ===================== VSP_P1_DECODED_QUOTE_STATIC_REDIRECT_V1G =====================
# Flask matches routes on DECODED path.
# /%22/static/... becomes /"/static/...
# Also some templates may accidentally append a trailing backslash: ...js%5C -> decoded ...js\

from flask import redirect, request

def _vsp__redir(url_base: str, rest: str):
    qs = request.query_string.decode("utf-8", errors="ignore")
    url = url_base + rest
    if qs:
        url = url + "?" + qs
    return redirect(url, code=307)

# 1) decoded leading quote case: /"/static/...
@app.get('/"/static/<path:rest>')
def vsp_decoded_quote_static_redirect(rest):
    return _vsp__redir("/static/", rest)

# 2) decoded leading backslash case: /\static/...  (rare but seen)
@app.get('/\\static/<path:rest>')
def vsp_decoded_backslash_static_redirect(rest):
    return _vsp__redir("/static/", rest)

# 3) trailing backslash after .js: /static/js/x.js\  (decoded from %5C)
@app.get('/static/js/<path:rest>\\')
def vsp_static_js_trailing_backslash_redirect(rest):
    return _vsp__redir("/static/js/", rest)

# 4) trailing backslash after .css (optional safety)
@app.get('/static/css/<path:rest>\\')
def vsp_static_css_trailing_backslash_redirect(rest):
    return _vsp__redir("/static/css/", rest)

# ===================== /VSP_P1_DECODED_QUOTE_STATIC_REDIRECT_V1G =====================

# ===================== VSP_P0_COMMERCIAL_AUTOREFRESH_GREENBADGE_V1_ENDPOINTS =====================
import os, json
from pathlib import Path

def _vsp_candidate_roots():
    roots = []
    env = os.environ.get("VSP_RUN_ROOTS", "").strip()
    if env:
        for part in re.split(r'[:;,]', env):
            p = part.strip()
            if p:
                roots.append(p)
    roots += [
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    ]
    out=[]
    for r in roots:
        try:
            if Path(r).is_dir():
                out.append(str(Path(r)))
        except Exception:
            pass
    seen=set(); uniq=[]
    for r in out:
        if r not in seen:
            uniq.append(r); seen.add(r)
    return uniq

def _vsp_is_rid_dirname(name: str) -> bool:
    if not name:
        return False
    if name.startswith("RUN_"):
        return True
    if name.startswith("VSP_CI_RUN_"):
        return True
    if name.startswith("VSP_CI_"):
        return True
    if "RUN" in name and "_" in name:
        return True
    return False

def _vsp_pick_latest_rid():
    roots = _vsp_candidate_roots()
    best = None  # (mtime, score, rid, root)
    for root in roots:
        rp = Path(root)
        try:
            for d in rp.iterdir():
                if not d.is_dir():
                    continue
                rid = d.name
                if not _vsp_is_rid_dirname(rid):
                    continue
                try:
                    mtime = d.stat().st_mtime
                except Exception:
                    continue
                score = 0
                if (d/"run_gate_summary.json").is_file(): score += 4
                if (d/"findings_unified.json").is_file(): score += 3
                if (d/"reports").is_dir(): score += 1
                key = (mtime, score, rid, root)
                if best is None or key > best:
                    best = key
        except Exception:
            continue
    if not best:
        return None
    mtime, score, rid, root = best
    return {"rid": rid, "root": root, "mtime": mtime, "score": score, "roots_checked": roots}

def _vsp_find_rid_dir(rid: str):
    if not rid:
        return None
    for root in _vsp_candidate_roots():
        p = Path(root)/rid
        if p.is_dir():
            return p
    return None

@app.route("/api/vsp/rid_latest_gate_root", methods=["GET"])
def vsp_rid_latest_gate_root():
    info = _vsp_pick_latest_rid()
    if not info:
        return jsonify(ok=False, err="no run dir found", roots=_vsp_candidate_roots()), 200
    return jsonify(ok=True, rid=info["rid"], run_root=info["root"],
                   mtime=info["mtime"], score=info["score"],
                   roots_checked=info["roots_checked"]), 200

@app.route("/api/vsp/ui_health_v1", methods=["GET"])
def vsp_ui_health_v1():
    rid = (request.args.get("rid") or "").strip()
    if not rid:
        latest = _vsp_pick_latest_rid()
        return jsonify(ok=False, err="missing rid", latest=latest), 200

    d = _vsp_find_rid_dir(rid)
    if not d:
        latest = _vsp_pick_latest_rid()
        return jsonify(ok=False, err="rid dir not found", rid=rid, latest=latest), 200

    checks = {}
    def _read_json(p: Path):
        try:
            return json.loads(p.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            return None

    p_gate = d/"run_gate_summary.json"
    p_find = d/"findings_unified.json"

    checks["run_gate_summary_exists"] = p_gate.is_file()
    checks["findings_unified_exists"] = p_find.is_file()
    checks["run_gate_summary_json_ok"] = bool(_read_json(p_gate)) if p_gate.is_file() else False
    j_find = _read_json(p_find) if p_find.is_file() else None
    checks["findings_unified_json_ok"] = bool(j_find)

    ok = all([
        checks["run_gate_summary_exists"],
        checks["findings_unified_exists"],
        checks["run_gate_summary_json_ok"],
        checks["findings_unified_json_ok"],
    ])
    return jsonify(ok=ok, rid=rid, run_dir=str(d), checks=checks), 200

@app.after_request
def _vsp_after_request_soft404(resp):
    try:
        path = request.path or ""
    except Exception:
        return resp
    if getattr(resp, "status_code", 0) != 404:
        return resp
    if path.startswith("/api/vsp/run_file_allow") or path.startswith("/api/run_file_allow") or path.startswith("/api/vsp/rid_latest_gate_root") or path.startswith("/api/vsp/ui_health_v1"):
        try:
            return jsonify(ok=False, err="not found (soft404)", path=path), 200
        except Exception:
            return resp
    return resp
# ===================== /VSP_P0_COMMERCIAL_AUTOREFRESH_GREENBADGE_V1_ENDPOINTS =====================

# ===================== VSP_P0_RID_LATEST_HEALTH_V2 =====================
import os, json, re
from pathlib import Path

def _vsp_v2_candidate_roots():
    roots = []
    env = os.environ.get("VSP_RUN_ROOTS", "").strip()
    if env:
        for part in re.split(r'[:;,]', env):
            p = part.strip()
            if p:
                roots.append(p)
    # keep your known roots
    roots += [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    ]
    out=[]
    for r in roots:
        try:
            p = Path(r)
            if p.is_dir():
                out.append(str(p))
        except Exception:
            pass
    # de-dup
    seen=set(); uniq=[]
    for r in out:
        if r not in seen:
            uniq.append(r); seen.add(r)
    return uniq

def _vsp_v2_is_rid(name: str) -> bool:
    if not name: return False
    if name.startswith("RUN_"): return True
    if name.startswith("VSP_CI_RUN_"): return True
    if name.startswith("VSP_CI_"): return True
    if "RUN" in name and "_" in name: return True
    return False

def _vsp_v2_pick_files(run_dir: Path):
    # return (gate_summary_rel, findings_rel) preferred
    cand_gate = [
        "run_gate_summary.json",
        "gate_root_" + run_dir.name + "/run_gate_summary.json",
        "gate_root_" + run_dir.name + "/run_gate.json",
        "run_gate.json",
    ]
    # findings often either root or under reports/ or under gate_root_*/
    cand_find = [
        "findings_unified.json",
        "reports/findings_unified.json",
        "reports/findings_unified_v1.json",
        "gate_root_" + run_dir.name + "/findings_unified.json",
        "gate_root_" + run_dir.name + "/reports/findings_unified.json",
    ]
    g = next((p for p in cand_gate if (run_dir/p).is_file()), None)
    f = next((p for p in cand_find if (run_dir/p).is_file()), None)
    return g, f

def _vsp_v2_latest():
    roots = _vsp_v2_candidate_roots()
    best = None  # (score, mtime, rid, root, gate_rel, find_rel)
    for root in roots:
        rp = Path(root)
        try:
            for d in rp.iterdir():
                if not d.is_dir(): 
                    continue
                rid = d.name
                if not _vsp_v2_is_rid(rid):
                    continue
                try:
                    mtime = d.stat().st_mtime
                except Exception:
                    continue
                gate_rel, find_rel = _vsp_v2_pick_files(d)
                score = 0
                if gate_rel: score += 6
                if find_rel: score += 10
                if (d/"reports").is_dir(): score += 1
                # prefer correctness first, then recency
                key = (score, mtime, rid, root, gate_rel or "", find_rel or "")
                if best is None or key > best:
                    best = key
        except Exception:
            continue

    if not best:
        return None

    score, mtime, rid, root, gate_rel, find_rel = best
    return {
        "rid": rid,
        "run_root": root,
        "mtime": mtime,
        "score": score,
        "gate_summary_rel": gate_rel or None,
        "findings_rel": find_rel or None,
        "roots_checked": roots,
    }

@app.route("/api/vsp/rid_latest_gate_root_v2", methods=["GET"])
def vsp_rid_latest_gate_root_v2():
    info = _vsp_v2_latest()
    if not info:
        return jsonify(ok=False, err="no run dir found", roots=_vsp_v2_candidate_roots()), 200
    # ok=true even if findings missing, but expose flags so UI knows why
    return jsonify(
        ok=True,
        rid=info["rid"],
        run_root=info["run_root"],
        score=info["score"],
        mtime=info["mtime"],
        has_gate_summary=bool(info["gate_summary_rel"]),
        has_findings=bool(info["findings_rel"]),
        gate_summary_path=info["gate_summary_rel"],
        findings_path=info["findings_rel"],
        roots_checked=info["roots_checked"],
    ), 200

@app.route("/api/vsp/ui_health_v2", methods=["GET"])
def vsp_ui_health_v2():
    rid = (request.args.get("rid") or "").strip()
    if not rid:
        latest = _vsp_v2_latest()
        return jsonify(ok=False, err="missing rid", latest=latest), 200

    run_dir = None
    for root in _vsp_v2_candidate_roots():
        p = Path(root)/rid
        if p.is_dir():
            run_dir = p
            break
    if not run_dir:
        latest = _vsp_v2_latest()
        return jsonify(ok=False, err="rid dir not found", rid=rid, latest=latest), 200

    gate_rel, find_rel = _vsp_v2_pick_files(run_dir)

    def _read_json(p: Path):
        try:
            return json.loads(p.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            return None

    checks = {}
    checks["run_dir"] = str(run_dir)
    checks["gate_summary_rel"] = gate_rel
    checks["findings_rel"] = find_rel
    checks["gate_summary_exists"] = bool(gate_rel and (run_dir/gate_rel).is_file())
    checks["findings_exists"] = bool(find_rel and (run_dir/find_rel).is_file())
    checks["gate_summary_json_ok"] = bool(_read_json(run_dir/gate_rel)) if checks["gate_summary_exists"] else False
    checks["findings_json_ok"] = bool(_read_json(run_dir/find_rel)) if checks["findings_exists"] else False

    ok = checks["gate_summary_exists"] and checks["findings_exists"] and checks["gate_summary_json_ok"] and checks["findings_json_ok"]
    return jsonify(ok=ok, rid=rid, checks=checks), 200
# ===================== /VSP_P0_RID_LATEST_HEALTH_V2 =====================

# ===================== VSP_P0_ASSET_V_CTX_V1 =====================
import time as _vsp_time
try:
    _VSP_ASSET_V = str(int(_vsp_time.time()))  # stable per service restart
except Exception:
    _VSP_ASSET_V = ""

@app.context_processor
def _vsp_ctx_asset_v():
    # expose asset_v for templates (cache-bust)
    return {"asset_v": _VSP_ASSET_V}
# ===================== /VSP_P0_ASSET_V_CTX_V1 =====================

# ===================== VSP_P1_TABS4_AFTER_REQUEST_INJECT_AUTORID_V1C =====================
@app.after_request
def _vsp_after_request_tabs4_inject_autorid(resp):
    # Inject autorid JS into non-dashboard tab pages robustly (do not rely on templates).
    try:
        p = (request.path or "").rstrip("/") or "/"
    except Exception:
        return resp

    # DO NOT touch dashboard:
    if p.startswith("/vsp5"):
        return resp

    # only these "4 tabs" + optional /reports if it is actually HTML
    targets = {"/runs", "/runs_reports", "/settings", "/data_source", "/rule_overrides", "/reports"}

    if p not in targets:
        return resp

    # only HTML responses
    try:
        ct = (resp.headers.get("Content-Type") or "").lower()
    except Exception:
        ct = ""
    if "text/html" not in ct:
        return resp

    try:
        body = resp.get_data(as_text=True)
    except Exception:
        return resp

    if "vsp_tabs4_autorid_v1.js" in body:
        return resp

    # IMPORTANT: cannot use Jinja here (response already rendered). Inject real cache-busted URL.
    try:
        v = str(_VSP_ASSET_V)
    except Exception:
        v = str(int(time.time()))
    tag = f'\n<!-- VSP_P1_TABS4_AUTORID_NODASH_V1 -->\n<script src="/static/js/vsp_tabs4_autorid_v1.js?v={v}"></script>\n'

    if "</body>" in body:
        body = body.replace("</body>", tag + "</body>", 1)
    else:
        body = body + tag

    try:
        resp.set_data(body)
        resp.headers.pop("Content-Length", None)
        resp.headers["Cache-Control"] = "no-store"
    except Exception:
        return resp
    return resp
# ===================== /VSP_P1_TABS4_AFTER_REQUEST_INJECT_AUTORID_V1C =====================

# ===================== VSP_P0_RID_LATEST_NEVER_NONE_FORCEBIND_V1C2 =====================
try:
    import json, time, re
    from pathlib import Path
    from flask import jsonify

    _app = globals().get("app") or globals().get("application")
    if _app is None:
        print("[VSP_P0_RID_LATEST_NEVER_NONE_FORCEBIND_V1C2] WARN: cannot find app/application in globals()")
    else:
        def _vsp_is_rid(v: str) -> bool:
            if not v: return False
            v = str(v).strip()
            if len(v) < 6 or len(v) > 120: return False
            if any(c.isspace() for c in v): return False
            if not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.:-]+$", v): return False
            if not any(ch.isdigit() for ch in v): return False
            return True

        def _vsp_pick_latest_rid():
            roots = [
                Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/out"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            ]
            base = Path("/home/test/Data")
            if base.is_dir():
                try:
                    for d in base.iterdir():
                        if d.is_dir() and d.name.startswith("SECURITY"):
                            roots.append(d / "out_ci")
                            roots.append(d / "out")
                except Exception:
                    pass

            cand = []
            def consider_dir(x: Path):
                try:
                    if not x.is_dir(): return
                    rid = x.name
                    if not _vsp_is_rid(rid): return
                    if not (rid.startswith("RUN_") or "VSP" in rid or "_RUN_" in rid):
                        return
                    cand.append((x.stat().st_mtime, rid, str(x)))
                except Exception:
                    return

            for r in roots:
                try:
                    if not r.is_dir(): 
                        continue
                    for x in r.iterdir():
                        consider_dir(x)
                except Exception:
                    continue

            cand.sort(reverse=True, key=lambda t: t[0])
            return (cand[0] if cand else None), len(cand)

        def vsp_rid_latest_never_none_v1c2():
            cache_path = Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/_rid_latest_cache.json")
            cache_path.parent.mkdir(parents=True, exist_ok=True)

            best, n = _vsp_pick_latest_rid()
            if best:
                mt, rid, pth = best
                try:
                    cache_path.write_text(json.dumps({"rid": rid, "path": pth, "mtime": mt, "ts": time.time()}, ensure_ascii=False),
                                          encoding="utf-8")
                except Exception:
                    pass
                return jsonify({"ok": True, "rid": rid, "path": pth, "mtime": mt, "stale": False, "candidates": n})

            # fallback cache
            try:
                if cache_path.is_file():
                    j = json.loads(cache_path.read_text(encoding="utf-8", errors="replace") or "{}")
                    rid = (j.get("rid") or "").strip()
                    if _vsp_is_rid(rid):
                        return jsonify({"ok": True, "rid": rid, "path": j.get("path",""), "mtime": j.get("mtime",0),
                                        "stale": True, "candidates": 0})
            except Exception:
                pass

            return jsonify({"ok": False, "rid": "", "stale": False, "candidates": 0, "err": "no run dir found"})

        # Force-bind by url_map (works even if original was wrapped)
        eps = []
        try:
            for rule in list(_app.url_map.iter_rules()):
                if getattr(rule, "rule", "") == "/api/vsp/rid_latest" and ("GET" in (rule.methods or set())):
                    eps.append(rule.endpoint)
        except Exception as e:
            print("[VSP_P0_RID_LATEST_NEVER_NONE_FORCEBIND_V1C2] WARN url_map scan failed:", repr(e))

        if eps:
            for ep in eps:
                _app.view_functions[ep] = vsp_rid_latest_never_none_v1c2
            print("[VSP_P0_RID_LATEST_NEVER_NONE_FORCEBIND_V1C2] OK rebound existing endpoints:", eps)
        else:
            _app.add_url_rule("/api/vsp/rid_latest", "vsp_rid_latest_never_none_v1c2",
                              vsp_rid_latest_never_none_v1c2, methods=["GET"])
            print("[VSP_P0_RID_LATEST_NEVER_NONE_FORCEBIND_V1C2] OK added new rule endpoint=vsp_rid_latest_never_none_v1c2")

except Exception as _e:
    print("[VSP_P0_RID_LATEST_NEVER_NONE_FORCEBIND_V1C2] FAILED:", repr(_e))
# ===================== /VSP_P0_RID_LATEST_NEVER_NONE_FORCEBIND_V1C2 =====================

# ===================== VSP_P0_RUN_FILE_ALLOW_MULTIROOT_ALWAYS200_V1D =====================
# Commercial-safe run_file_allow:
# - ALWAYS 200 JSON on error (no upstream 5xx wrapping)
# - multi-root run dir resolution
# - special-case findings_unified.json: serve SMALL sample (limit) from reports/findings_unified.csv
# - fallback to reports/ for other files
import os, json, csv, time
from flask import request, jsonify, send_file, Response



# --- VSP_P0_RFA_PROMOTE_FINDINGS_CONTRACT_V2E ---
try:
    from flask import jsonify
except Exception:
    jsonify = None

def __vsp_promote_findings_contract(j):
    """
    Commercial contract: top-level findings must be a list.
    Promotion order:
      findings -> items -> data(list) -> data.findings/items/data (nested)
    """
    try:
        if not isinstance(j, dict):
            return j
        f = j.get("findings")
        if isinstance(f, list) and f:
            return j

        cands = []
        it = j.get("items")
        if isinstance(it, list) and it:
            cands = it

        dt = j.get("data")
        if not cands and isinstance(dt, list) and dt:
            cands = dt

        if not cands and isinstance(dt, dict):
            for k in ("findings","items","data"):
                v = dt.get(k)
                if isinstance(v, list) and v:
                    cands = v
                    break

        j["findings"] = cands if isinstance(cands, list) else []
    except Exception:
        try:
            if isinstance(j, dict) and "findings" not in j:
                j["findings"] = []
        except Exception:
            pass
    return j

def __vsp_rfa_finalize(ret):
    """
    Wrap returns safely:
      - dict -> promote + jsonify + header
      - (resp, code, ...) -> finalize resp then keep code
      - Response-like -> only set header
    """
    try:
        if isinstance(ret, tuple) and ret:
            head = __vsp_rfa_finalize(ret[0])
            return (head, *ret[1:])

        if isinstance(ret, dict):
            ret = __vsp_promote_findings_contract(ret)
            if jsonify is not None:
                resp = jsonify(ret)
                try:
                    resp.headers["X-VSP-RFA-PROMOTE"] = "v2"
                except Exception:
                    pass
                return resp
            return ret

        if hasattr(ret, "headers"):
            try:
                ret.headers["X-VSP-RFA-PROMOTE"] = "v2"
            except Exception:
                pass
            return ret
    except Exception:
        pass
    return ret
# --- /VSP_P0_RFA_PROMOTE_FINDINGS_CONTRACT_V2E ---


_VSP_RF_CACHE_V1D = {}

def _vsp_rf_roots_v1d():
    # Prefer explicit env first
    env = os.environ.get("VSP_RUN_ROOTS") or os.environ.get("VSP_OUT_CI_ROOTS") or ""
    roots = []
    for x in [y.strip() for y in env.split(":") if y.strip()]:
        if os.path.isdir(x) and x not in roots:
            roots.append(x)

    # Known defaults (tuned for your setup)
    defaults = [
        "/home/test/Data/SECURITY-10-10-v4/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/out_ci",
        "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
        "/home/test/Data/SECURITY/out_ci",
    ]
    for d in defaults:
        if os.path.isdir(d) and d not in roots:
            roots.append(d)
    return roots

def _vsp_rf_find_run_dir_v1d(rid: str):
    if not rid or len(rid) > 128:
        return None
    # deny path tricks
    if "/" in rid or "\\" in rid or "\x00" in rid:
        return None
    for root in _vsp_rf_roots_v1d():
        cand = os.path.join(root, rid)
        if os.path.isdir(cand):
            return cand
    return None

def _vsp_rf_safe_relpath_v1d(path: str):
    if not path or len(path) > 512:
        return None
    if "\x00" in path:
        return None
    if path.startswith("/") or path.startswith("\\"):
        return None
    if ".." in path.split("/"):
        return None
    if "\\" in path:
        return None
    return path

def _vsp_rf_guess_mime_v1d(fp: str):
    f = fp.lower()
    if f.endswith(".json"): return "application/json; charset=utf-8"
    if f.endswith(".csv"):  return "text/csv; charset=utf-8"
    if f.endswith(".sarif"):return "application/json; charset=utf-8"
    if f.endswith(".txt") or f.endswith(".log"): return "text/plain; charset=utf-8"
    if f.endswith(".html"): return "text/html; charset=utf-8"
    return "application/octet-stream"

def _vsp_rf_csv_sample_v1d(csv_path: str, limit: int):
    items = []
    counts = {}
    # tolerate weird headers; keep best-effort columns
    with open(csv_path, "r", encoding="utf-8", errors="replace", newline="") as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            if i >= limit:
                break

            def pick(*keys):
                for k in keys:
                    v = row.get(k)
                    if v is not None and str(v).strip() != "":
                        return str(v)
                return ""

            sev  = pick("severity","Severity","SEVERITY","sev","Sev").upper()
            tool = pick("tool","Tool","TOOL","scanner","Scanner").lower()
            title = pick("title","Title","TITLE","rule_name","Rule","name","Name")
            loc = pick("location","Location","LOCATION","path","Path","file","File")
            line = pick("line","Line","LINE")
            if line and loc and ":" not in loc:
                loc = f"{loc}:{line}"

            item = {
                "severity": sev or "INFO",
                "tool": tool or "unknown",
                "title": title or "(no title)",
                "location": loc or "",
            }

            # keep a few optional fields if present
            for k in ("rule_id","rule","cwe","owasp","iso27001","confidence","fingerprint","remediation","category"):
                v = pick(k, k.upper(), k.title())
                if v:
                    item[k] = v

            items.append(item)
            counts[item["severity"]] = counts.get(item["severity"], 0) + 1

    return items, counts

@app.get("/api/vsp/run_file_allow")
def vsp_run_file_allow_v1d():
    rid = (request.args.get("rid") or "").strip()
    path = (request.args.get("path") or "").strip()

    safe = _vsp_rf_safe_relpath_v1d(path)
    run_dir = _vsp_rf_find_run_dir_v1d(rid)

    if not run_dir:
        return jsonify(ok=False, err="unknown rid", rid=rid, path=path, marker="VSP_P0_RUN_FILE_ALLOW_MULTIROOT_ALWAYS200_V1D"), 200
    if not safe:
        return jsonify(ok=False, err="bad path", rid=rid, path=path, marker="VSP_P0_RUN_FILE_ALLOW_MULTIROOT_ALWAYS200_V1D"), 200

    # --- Special-case: findings_unified.json (avoid freezing dashboard) ---
    if safe == "findings_unified.json":
        max_bytes = 6 * 1024 * 1024  # 6MB cap for direct JSON
        limit = request.args.get("limit", "300").strip()
        try:
            limit_i = max(10, min(int(limit), 1000))
        except Exception:
            limit_i = 300

        direct_jsons = [
            os.path.join(run_dir, "findings_unified.json"),
            os.path.join(run_dir, "reports", "findings_unified.json"),
        ]
        for fp in direct_jsons:
            if os.path.isfile(fp):
                try:
                    if os.path.getsize(fp) <= max_bytes:
                        return send_file(fp, mimetype="application/json; charset=utf-8", conditional=False)
                except Exception:
                    pass

        csvp = os.path.join(run_dir, "reports", "findings_unified.csv")
        if os.path.isfile(csvp):
            try:
                mtime = os.path.getmtime(csvp)
            except Exception:
                mtime = 0.0
            ck = (run_dir, csvp, limit_i, mtime)
            cached = _VSP_RF_CACHE_V1D.get(ck)
            if cached and (time.time() - cached["ts"] < 60):
                return Response(cached["body"], mimetype="application/json; charset=utf-8")

            try:
                items, counts = _vsp_rf_csv_sample_v1d(csvp, limit_i)
                body = json.dumps({
                    "meta": {
                        "rid": rid,
                        "generated_from": csvp,
                        "generated_ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                        "truncated": True,
                        "limit": limit_i,
                        "counts_by_severity_sample": counts,
                    },
                    "findings": items
                }, ensure_ascii=False)
                _VSP_RF_CACHE_V1D[ck] = {"ts": time.time(), "body": body}
                return Response(body, mimetype="application/json; charset=utf-8")
            except Exception as e:
                return jsonify(ok=False, err=f"csv parse failed: {e}", rid=rid, path=path, run_dir=run_dir,
                               marker="VSP_P0_RUN_FILE_ALLOW_MULTIROOT_ALWAYS200_V1D"), 200

        return jsonify(ok=False, err="missing file", rid=rid, path=path, run_dir=run_dir,
                       marker="VSP_P0_RUN_FILE_ALLOW_MULTIROOT_ALWAYS200_V1D"), 200

    # --- Generic: serve file in run_dir ---
    full = os.path.join(run_dir, safe)
    if os.path.isfile(full):
        try:
            # guard huge text/json to protect UI
            if full.lower().endswith((".json",".csv",".sarif",".log",".txt")) and os.path.getsize(full) > 20*1024*1024:
                return jsonify(ok=False, err="file too large", rid=rid, path=path, size=os.path.getsize(full), run_dir=run_dir,
                               marker="VSP_P0_RUN_FILE_ALLOW_MULTIROOT_ALWAYS200_V1D"), 200
        except Exception:
            pass
        return send_file(full, mimetype=_vsp_rf_guess_mime_v1d(full), conditional=False)

    # Fallback: reports/<path>
    if not safe.startswith("reports/"):
        alt = os.path.join(run_dir, "reports", safe)
        if os.path.isfile(alt):
            return send_file(alt, mimetype=_vsp_rf_guess_mime_v1d(alt), conditional=False)

    return jsonify(ok=False, err="missing file", rid=rid, path=path, run_dir=run_dir,
                   marker="VSP_P0_RUN_FILE_ALLOW_MULTIROOT_ALWAYS200_V1D"), 200

# ===================== /VSP_P0_RUN_FILE_ALLOW_MULTIROOT_ALWAYS200_V1D =====================


# ===================== VSP_P0_RID_LATEST_PREFER_HAS_FINDINGS_V1 =====================
try:
    import json, time, re
    from pathlib import Path
    from flask import jsonify

    _app = globals().get("app") or globals().get("application")
    if _app is None:
        print("[VSP_P0_RID_LATEST_PREFER_HAS_FINDINGS_V1] WARN: cannot find app/application in globals()")
    else:
        def _rl_is_rid(v: str) -> bool:
            if not v: return False
            v=str(v).strip()
            if len(v)<6 or len(v)>140: return False
            if any(c.isspace() for c in v): return False
            if not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.:-]+$", v): return False
            if not any(ch.isdigit() for ch in v): return False
            return True

        def _rl_roots():
            roots=[
                Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/out"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            ]
            base=Path("/home/test/Data")
            if base.is_dir():
                try:
                    for d in base.iterdir():
                        if d.is_dir() and d.name.startswith("SECURITY"):
                            roots.append(d/"out_ci")
                            roots.append(d/"out")
                except Exception:
                    pass
            return roots

        def _rl_has_core_artifacts(run_dir: Path):
            # prefer root findings_unified.json (dashboard expects this today)
            prefs = [
                run_dir/"findings_unified.json",
                run_dir/"run_gate_summary.json",
                run_dir/"reports"/"findings_unified.json",
                run_dir/"reports"/"findings_unified.csv",
            ]
            for fp in prefs:
                try:
                    if fp.is_file() and fp.stat().st_size > 0:
                        return True, fp.name if fp.parent==run_dir else str(fp.relative_to(run_dir))
                except Exception:
                    pass
            return False, ""

        def _rl_pick_latest_with_artifacts(limit_scan=600):
            cand=[]
            for r in _rl_roots():
                try:
                    if not r.is_dir(): 
                        continue
                    for d in r.iterdir():
                        if not d.is_dir(): 
                            continue
                        rid=d.name
                        if not _rl_is_rid(rid): 
                            continue
                        if not (rid.startswith("RUN_") or "VSP" in rid or "_RUN_" in rid):
                            continue
                        try:
                            cand.append((d.stat().st_mtime, rid, d))
                        except Exception:
                            pass
                except Exception:
                    continue
            cand.sort(reverse=True, key=lambda t: t[0])

            checked=0
            for mt, rid, d in cand[:max(1, int(limit_scan))]:
                ok, why = _rl_has_core_artifacts(d)
                checked += 1
                if ok:
                    return (mt, rid, str(d), why), len(cand), checked
            return None, len(cand), checked

        def vsp_rid_latest_prefer_has_findings_v1():
            cache_path = Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/_rid_latest_cache.json")
            cache_path.parent.mkdir(parents=True, exist_ok=True)

            best, total, checked = _rl_pick_latest_with_artifacts()
            if best:
                mt, rid, pth, why = best
                try:
                    cache_path.write_text(json.dumps({"rid": rid, "path": pth, "mtime": mt, "why": why, "ts": time.time()}, ensure_ascii=False),
                                          encoding="utf-8")
                except Exception:
                    pass
                return jsonify({"ok": True, "rid": rid, "path": pth, "mtime": mt, "stale": False,
                                "candidates": total, "checked": checked, "why": why})

            # fallback cache (still must be valid)
            try:
                if cache_path.is_file():
                    j=json.loads(cache_path.read_text(encoding="utf-8", errors="replace") or "{}")
                    rid=(j.get("rid") or "").strip()
                    pth=(j.get("path") or "").strip()
                    if _rl_is_rid(rid) and pth and Path(pth).is_dir():
                        ok, why = _rl_has_core_artifacts(Path(pth))
                        if ok:
                            return jsonify({"ok": True, "rid": rid, "path": pth, "mtime": j.get("mtime",0), "stale": True,
                                            "candidates": 0, "checked": 0, "why": why})
            except Exception:
                pass

            return jsonify({"ok": False, "rid": "", "stale": False, "candidates": total, "checked": checked,
                            "err": "no run dir with required artifacts found"})

        # Force-bind by url_map (override previous rid_latest handler)
        eps=[]
        try:
            for rule in list(_app.url_map.iter_rules()):
                if getattr(rule, "rule", "") == "/api/vsp/rid_latest" and ("GET" in (rule.methods or set())):
                    eps.append(rule.endpoint)
        except Exception as e:
            print("[VSP_P0_RID_LATEST_PREFER_HAS_FINDINGS_V1] WARN url_map scan failed:", repr(e))

        if eps:
            for ep in eps:
                _app.view_functions[ep] = vsp_rid_latest_prefer_has_findings_v1
            print("[VSP_P0_RID_LATEST_PREFER_HAS_FINDINGS_V1] OK rebound existing endpoints:", eps)
        else:
            _app.add_url_rule("/api/vsp/rid_latest", "vsp_rid_latest_prefer_has_findings_v1",
                              vsp_rid_latest_prefer_has_findings_v1, methods=["GET"])
            print("[VSP_P0_RID_LATEST_PREFER_HAS_FINDINGS_V1] OK added new rule endpoint=vsp_rid_latest_prefer_has_findings_v1")

except Exception as _e:
    print("[VSP_P0_RID_LATEST_PREFER_HAS_FINDINGS_V1] FAILED:", repr(_e))
# ===================== /VSP_P0_RID_LATEST_PREFER_HAS_FINDINGS_V1 =====================

# ===================== VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1 =====================
try:
    import json, re
    from pathlib import Path
    from flask import request, jsonify, send_file, make_response

    _app = globals().get("app") or globals().get("application")
    if _app is None:
        print("[VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1] WARN: cannot find app/application in globals()")
    else:
        def _rf_is_rid(v: str) -> bool:
            if not v: return False
            v=str(v).strip()
            if len(v)<6 or len(v)>140: return False
            if any(c.isspace() for c in v): return False
            if not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.:-]+$", v): return False
            if not any(ch.isdigit() for ch in v): return False
            return True

        def _rf_safe_relpath(pp: str) -> str:
            pp=(pp or "").strip()
            if not pp: return ""
            if pp.startswith("/"): return ""      # forbid abs
            if ".." in pp: return ""             # forbid traversal
            pp = pp.replace("\\", "/")
            while "//" in pp: pp = pp.replace("//","/")
            if pp.startswith("./"): pp = pp[2:]
            if not pp: return ""
            if any(seg.strip()=="" for seg in pp.split("/")): return ""
            return pp

        def _rf_allowed_path(rel: str) -> bool:
            rel=(rel or "").lower().strip()
            if not rel: return False
            exts=(".json",".sarif",".csv",".html",".txt",".log",".zip",".tgz",".gz")
            if not rel.endswith(exts): return False
            deny=("id_rsa","known_hosts",".pem",".key","passwd","shadow","token","secret")
            if any(x in rel for x in deny): return False
            return True

        def _rf_roots():
            roots=[
                Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/out"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            ]
            base=Path("/home/test/Data")
            if base.is_dir():
                try:
                    for d in base.iterdir():
                        if d.is_dir() and d.name.startswith("SECURITY"):
                            roots.append(d/"out_ci")
                            roots.append(d/"out")
                except Exception:
                    pass
            return roots

        def _rf_find_run_dir(rid: str):
            cand=[]
            for r in _rf_roots():
                try:
                    d=r/rid
                    if d.is_dir():
                        cand.append((d.stat().st_mtime, d))
                except Exception:
                    pass
            cand.sort(reverse=True, key=lambda t:t[0])
            return cand[0][1] if cand else None

        def _rf_cache_path():
            return Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/_rid_latest_cache.json")

        def _rf_guess_mime(rel: str) -> str:
            rel=(rel or "").lower()
            if rel.endswith(".json") or rel.endswith(".sarif"): return "application/json"
            if rel.endswith(".csv"): return "text/csv; charset=utf-8"
            if rel.endswith(".html"): return "text/html; charset=utf-8"
            if rel.endswith(".txt") or rel.endswith(".log"): return "text/plain; charset=utf-8"
            return "application/octet-stream"

        def _rf_fallbacks(rel: str):
            # when dashboard requests root but artifacts are under reports/
            if rel == "findings_unified.json":
                return ["reports/findings_unified.json", "reports/findings_unified_full.json"]
            if rel == "run_gate_summary.json":
                return ["reports/run_gate_summary.json"]
            return []

        def vsp_run_file_allow_fallback_reports_findings_v1():
            try:
                rid=(request.args.get("rid","") or "").strip()
                rel=_rf_safe_relpath(request.args.get("path","") or "")

                if not _rf_is_rid(rid):
                    return jsonify({"ok": False, "err": "bad rid", "rid": rid, "path": rel, "marker": "VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1"}), 200
                if not _rf_allowed_path(rel):
                    return jsonify({"ok": False, "err": "not allowed", "rid": rid, "path": rel, "marker": "VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1"}), 200

                run_dir=_rf_find_run_dir(rid)

                # fallback: cached path from rid_latest
                if run_dir is None:
                    cp=_rf_cache_path()
                    try:
                        if cp.is_file():
                            j=json.loads(cp.read_text(encoding="utf-8", errors="replace") or "{}")
                            if (j.get("rid") or "").strip()==rid:
                                pth=(j.get("path") or "").strip()
                                if pth and Path(pth).is_dir():
                                    run_dir=Path(pth)
                    except Exception:
                        pass

                if run_dir is None:
                    return jsonify({"ok": False, "err": "rid dir not found", "rid": rid, "path": rel, "marker": "VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1"}), 200

                # try primary path, then fallbacks if missing
                tried=[rel]
                fpath=run_dir/rel
                if (not fpath.is_file()) and rel in ("findings_unified.json","run_gate_summary.json"):
                    for alt in _rf_fallbacks(rel):
                        alt=_rf_safe_relpath(alt)
                        if not alt: 
                            continue
                        tried.append(alt)
                        ap=run_dir/alt
                        if ap.is_file():
                            rel=alt
                            fpath=ap
                            break

                if not fpath.is_file():
                    return jsonify({"ok": False, "err": "missing file", "rid": rid, "path": tried[0], "tried": tried,
                                    "run_dir": str(run_dir), "marker": "VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1"}), 200

                resp=make_response(send_file(str(fpath), mimetype=_rf_guess_mime(rel), as_attachment=False))
                resp.headers["Cache-Control"]="no-store"
                resp.headers["X-VSP-RUNFILEALLOW"]="VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1"
                return resp
            except Exception as e:
                return jsonify({"ok": False, "err": "exception", "detail": str(e)[:180], "marker": "VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1"}), 200

        # Force-bind by url_map (override previous handler)
        eps=[]
        try:
            for rule in list(_app.url_map.iter_rules()):
                if getattr(rule, "rule", "") == "/api/vsp/run_file_allow" and ("GET" in (rule.methods or set())):
                    eps.append(rule.endpoint)
        except Exception as e:
            print("[VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1] WARN url_map scan failed:", repr(e))

        if eps:
            for ep in eps:
                _app.view_functions[ep] = vsp_run_file_allow_fallback_reports_findings_v1
            print("[VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1] OK rebound existing endpoints:", eps)
        else:
            _app.add_url_rule("/api/vsp/run_file_allow", "vsp_run_file_allow_fallback_reports_findings_v1",
                              vsp_run_file_allow_fallback_reports_findings_v1, methods=["GET"])
            print("[VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1] OK added new rule endpoint=vsp_run_file_allow_fallback_reports_findings_v1")

except Exception as _e:
    print("[VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1] FAILED:", repr(_e))
# ===================== /VSP_P0_RUN_FILE_ALLOW_FALLBACK_REPORTS_FINDINGS_V1 =====================

# ===================== VSP_P0_RID_LATEST_REQUIRE_FINDINGS_V1B =====================
try:
    import json, time, re
    from pathlib import Path
    from flask import jsonify

    _app = globals().get("app") or globals().get("application")
    if _app is None:
        print("[VSP_P0_RID_LATEST_REQUIRE_FINDINGS_V1B] WARN: cannot find app/application in globals()")
    else:
        def _rq_is_rid(v: str) -> bool:
            if not v: return False
            v=str(v).strip()
            if len(v)<6 or len(v)>140: return False
            if any(c.isspace() for c in v): return False
            if not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.:-]+$", v): return False
            if not any(ch.isdigit() for ch in v): return False
            return True

        def _rq_roots():
            roots=[
                Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/out"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            ]
            base=Path("/home/test/Data")
            if base.is_dir():
                try:
                    for d in base.iterdir():
                        if d.is_dir() and d.name.startswith("SECURITY"):
                            roots.append(d/"out_ci")
                            roots.append(d/"out")
                except Exception:
                    pass
            return roots

        def _rq_findings_path(run_dir: Path):
            # REQUIRE any of these to exist and non-empty
            prefs = [
                run_dir/"findings_unified.json",
                run_dir/"reports"/"findings_unified.json",
                run_dir/"reports"/"findings_unified_full.json",
                run_dir/"reports"/"findings_unified.csv",   # still acceptable as “has findings”
            ]
            for fp in prefs:
                try:
                    if fp.is_file() and fp.stat().st_size > 0:
                        rel = fp.name if fp.parent==run_dir else str(fp.relative_to(run_dir))
                        return True, rel
                except Exception:
                    pass
            return False, ""

        def _rq_pick_latest_with_findings(limit_scan=900):
            cand=[]
            for r in _rq_roots():
                try:
                    if not r.is_dir(): 
                        continue
                    for d in r.iterdir():
                        if not d.is_dir(): 
                            continue
                        rid=d.name
                        if not _rq_is_rid(rid): 
                            continue
                        if not (rid.startswith("RUN_") or "VSP" in rid or "_RUN_" in rid):
                            continue
                        try:
                            cand.append((d.stat().st_mtime, rid, d))
                        except Exception:
                            pass
                except Exception:
                    continue
            cand.sort(reverse=True, key=lambda t: t[0])

            checked=0
            for mt, rid, d in cand[:max(1, int(limit_scan))]:
                ok, why = _rq_findings_path(d)
                checked += 1
                if ok:
                    return (mt, rid, str(d), why), len(cand), checked
            return None, len(cand), checked

        def vsp_rid_latest_require_findings_v1b():
            cache_path = Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/_rid_latest_cache.json")
            cache_path.parent.mkdir(parents=True, exist_ok=True)

            best, total, checked = _rq_pick_latest_with_findings()
            if best:
                mt, rid, pth, why = best
                try:
                    cache_path.write_text(json.dumps({"rid": rid, "path": pth, "mtime": mt, "why": why, "ts": time.time()}, ensure_ascii=False),
                                          encoding="utf-8")
                except Exception:
                    pass
                return jsonify({"ok": True, "rid": rid, "path": pth, "mtime": mt, "stale": False,
                                "candidates": total, "checked": checked, "why": why})

            return jsonify({"ok": False, "rid": "", "stale": False, "candidates": total, "checked": checked,
                            "err": "no run dir with findings_unified.* found"})

        # Force-bind by url_map (override previous rid_latest handler)
        eps=[]
        try:
            for rule in list(_app.url_map.iter_rules()):
                if getattr(rule, "rule", "") == "/api/vsp/rid_latest" and ("GET" in (rule.methods or set())):
                    eps.append(rule.endpoint)
        except Exception as e:
            print("[VSP_P0_RID_LATEST_REQUIRE_FINDINGS_V1B] WARN url_map scan failed:", repr(e))

        if eps:
            for ep in eps:
                _app.view_functions[ep] = vsp_rid_latest_require_findings_v1b
            print("[VSP_P0_RID_LATEST_REQUIRE_FINDINGS_V1B] OK rebound existing endpoints:", eps)
        else:
            _app.add_url_rule("/api/vsp/rid_latest", "vsp_rid_latest_require_findings_v1b",
                              vsp_rid_latest_require_findings_v1b, methods=["GET"])
            print("[VSP_P0_RID_LATEST_REQUIRE_FINDINGS_V1B] OK added new rule endpoint=vsp_rid_latest_require_findings_v1b")

except Exception as _e:
    print("[VSP_P0_RID_LATEST_REQUIRE_FINDINGS_V1B] FAILED:", repr(_e))
# ===================== /VSP_P0_RID_LATEST_REQUIRE_FINDINGS_V1B =====================

# ===================== VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1 =====================
try:
    import json, re, time, csv
    from pathlib import Path
    from flask import request, jsonify, send_file, make_response, Response

    _app = globals().get("app") or globals().get("application")
    if _app is None:
        print("[VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1] WARN: cannot find app/application in globals()")
    else:
        def _c2j_is_rid(v: str) -> bool:
            if not v: return False
            v=str(v).strip()
            if len(v)<6 or len(v)>140: return False
            if any(c.isspace() for c in v): return False
            if not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.:-]+$", v): return False
            if not any(ch.isdigit() for ch in v): return False
            return True

        def _c2j_safe_relpath(pp: str) -> str:
            pp=(pp or "").strip()
            if not pp: return ""
            if pp.startswith("/"): return ""
            if ".." in pp: return ""
            pp = pp.replace("\\", "/")
            while "//" in pp: pp = pp.replace("//","/")
            if pp.startswith("./"): pp = pp[2:]
            if not pp: return ""
            if any(seg.strip()=="" for seg in pp.split("/")): return ""
            return pp

        def _c2j_allowed_path(rel: str) -> bool:
            rel=(rel or "").lower().strip()
            if not rel: return False
            exts=(".json",".sarif",".csv",".html",".txt",".log",".zip",".tgz",".gz")
            if not rel.endswith(exts): return False
            deny=("id_rsa","known_hosts",".pem",".key","passwd","shadow","token","secret")
            if any(x in rel for x in deny): return False
            return True

        def _c2j_roots():
            roots=[
                Path("/home/test/Data/SECURITY_BUNDLE/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/out"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci"),
                Path("/home/test/Data/SECURITY_BUNDLE/ui/out"),
            ]
            base=Path("/home/test/Data")
            if base.is_dir():
                try:
                    for d in base.iterdir():
                        if d.is_dir() and d.name.startswith("SECURITY"):
                            roots.append(d/"out_ci")
                            roots.append(d/"out")
                except Exception:
                    pass
            return roots

        def _c2j_find_run_dir(rid: str):
            cand=[]
            for r in _c2j_roots():
                try:
                    d=r/rid
                    if d.is_dir():
                        cand.append((d.stat().st_mtime, d))
                except Exception:
                    pass
            cand.sort(reverse=True, key=lambda t:t[0])
            return cand[0][1] if cand else None

        def _c2j_cache_path():
            return Path("/home/test/Data/SECURITY_BUNDLE/ui/out_ci/_rid_latest_cache.json")

        def _c2j_guess_mime(rel: str) -> str:
            rel=(rel or "").lower()
            if rel.endswith(".json") or rel.endswith(".sarif"): return "application/json"
            if rel.endswith(".csv"): return "text/csv; charset=utf-8"
            if rel.endswith(".html"): return "text/html; charset=utf-8"
            if rel.endswith(".txt") or rel.endswith(".log"): return "text/plain; charset=utf-8"
            return "application/octet-stream"

        def _c2j_fallbacks(rel: str):
            if rel == "findings_unified.json":
                return [
                    "reports/findings_unified.json",
                    "reports/findings_unified_full.json",
                    "reports/findings_unified.csv",
                ]
            if rel == "run_gate_summary.json":
                return ["reports/run_gate_summary.json"]
            return []

        def _c2j_norm_sev(v: str) -> str:
            v=(v or "").strip().upper()
            if v in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"): return v
            m={"INFORMATIONAL":"INFO","INFORMATION":"INFO","WARN":"LOW","WARNING":"LOW","ERROR":"HIGH"}
            return m.get(v, v or "INFO")

        def _c2j_csv_to_unified_json(csv_path: Path, rid: str, max_rows: int = 12000):
            # cache next to csv to avoid re-parse
            cache = csv_path.parent / "_ui_cache_findings_unified_from_csv.json"
            try:
                if cache.is_file() and cache.stat().st_mtime >= csv_path.stat().st_mtime and cache.stat().st_size > 10:
                    return cache.read_text(encoding="utf-8", errors="replace"), True
            except Exception:
                pass

            findings=[]
            counts={"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"INFO":0,"TRACE":0}

            with csv_path.open("r", encoding="utf-8", errors="replace", newline="") as f:
                reader=csv.DictReader(f)
                # normalize headers
                for i,row in enumerate(reader):
                    if i >= max_rows:
                        break
                    r = { (k or "").strip().lower(): (v or "") for k,v in row.items() }

                    sev = _c2j_norm_sev(r.get("severity") or r.get("sev") or r.get("level"))
                    counts[sev] = counts.get(sev,0)+1

                    tool = (r.get("tool") or r.get("scanner") or r.get("engine") or "").strip() or "unknown"
                    title = (r.get("title") or r.get("check_name") or r.get("rule") or r.get("message") or "").strip()
                    loc = (r.get("location") or r.get("path") or r.get("file") or "").strip()
                    line = (r.get("line") or r.get("start_line") or "").strip()
                    rule_id = (r.get("rule_id") or r.get("id") or r.get("check_id") or "").strip()
                    desc = (r.get("description") or r.get("details") or r.get("message") or "").strip()

                    if line and loc and (":" not in loc):
                        loc = f"{loc}:{line}"

                    findings.append({
                        "severity": sev,
                        "tool": tool,
                        "rule_id": rule_id,
                        "title": title,
                        "location": loc,
                        "description": desc,
                        "rid": rid,
                        "source": "csv"
                    })

            meta={
                "rid": rid,
                "generated_from": str(csv_path),
                "generated_ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "counts_by_severity": counts,
                "findings_count": len(findings),
                "marker": "VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1"
            }
            out = json.dumps({"meta": meta, "findings": findings}, ensure_ascii=False)

            try:
                cache.write_text(out, encoding="utf-8")
            except Exception:
                pass
            return out, False

        def vsp_run_file_allow_csv2json_findings_v1():
            try:
                rid=(request.args.get("rid","") or "").strip()
                rel=_c2j_safe_relpath(request.args.get("path","") or "")

                if not _c2j_is_rid(rid):
                    return jsonify({"ok": False, "err": "bad rid", "rid": rid, "path": rel, "marker": "VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1"}), 200
                if not _c2j_allowed_path(rel):
                    return jsonify({"ok": False, "err": "not allowed", "rid": rid, "path": rel, "marker": "VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1"}), 200

                run_dir=_c2j_find_run_dir(rid)

                # fallback: cached path from rid_latest
                if run_dir is None:
                    cp=_c2j_cache_path()
                    try:
                        if cp.is_file():
                            j=json.loads(cp.read_text(encoding="utf-8", errors="replace") or "{}")
                            if (j.get("rid") or "").strip()==rid:
                                pth=(j.get("path") or "").strip()
                                if pth and Path(pth).is_dir():
                                    run_dir=Path(pth)
                    except Exception:
                        pass

                if run_dir is None:
                    return jsonify({"ok": False, "err": "rid dir not found", "rid": rid, "path": rel, "marker": "VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1"}), 200

                tried=[rel]
                fpath=run_dir/rel

                # try fallbacks
                if (not fpath.is_file()) and rel in ("findings_unified.json","run_gate_summary.json"):
                    for alt in _c2j_fallbacks(rel):
                        alt=_c2j_safe_relpath(alt)
                        if not alt:
                            continue
                        tried.append(alt)
                        ap=run_dir/alt
                        if ap.is_file() and ap.stat().st_size > 0:
                            rel=alt
                            fpath=ap
                            break

                if not fpath.is_file() or fpath.stat().st_size <= 0:
                    return jsonify({"ok": False, "err": "missing file", "rid": rid, "path": tried[0], "tried": tried,
                                    "run_dir": str(run_dir), "marker": "VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1"}), 200

                # CSV -> JSON for dashboard contract
                if tried[0] == "findings_unified.json" and rel.endswith(".csv") and fpath.name.lower().endswith(".csv"):
                    body, from_cache = _c2j_csv_to_unified_json(fpath, rid)
                    resp = Response(body, mimetype="application/json")
                    resp.headers["Cache-Control"]="no-store"
                    resp.headers["X-VSP-RUNFILEALLOW"]="VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1"
                    resp.headers["X-VSP-CSV2JSON"]="1"
                    resp.headers["X-VSP-CSV2JSON-CACHED"]="1" if from_cache else "0"
                    return resp

                resp=make_response(send_file(str(fpath), mimetype=_c2j_guess_mime(rel), as_attachment=False))
                resp.headers["Cache-Control"]="no-store"
                resp.headers["X-VSP-RUNFILEALLOW"]="VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1"
                return resp
            except Exception as e:
                return jsonify({"ok": False, "err": "exception", "detail": str(e)[:180], "marker": "VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1"}), 200

        # Force-bind by url_map (override previous handler)
        eps=[]
        try:
            for rule in list(_app.url_map.iter_rules()):
                if getattr(rule, "rule", "") == "/api/vsp/run_file_allow" and ("GET" in (rule.methods or set())):
                    eps.append(rule.endpoint)
        except Exception as e:
            print("[VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1] WARN url_map scan failed:", repr(e))

        if eps:
            for ep in eps:
                _app.view_functions[ep] = vsp_run_file_allow_csv2json_findings_v1
            print("[VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1] OK rebound existing endpoints:", eps)
        else:
            _app.add_url_rule("/api/vsp/run_file_allow", "vsp_run_file_allow_csv2json_findings_v1",
                              vsp_run_file_allow_csv2json_findings_v1, methods=["GET"])
            print("[VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1] OK added new rule endpoint=vsp_run_file_allow_csv2json_findings_v1")

except Exception as _e:
    print("[VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1] FAILED:", repr(_e))
# ===================== /VSP_P0_RUN_FILE_ALLOW_CSV2JSON_FINDINGS_V1 =====================

# ===================== VSP_P0_CONTRACTIZE_RID_LATEST_AND_FINDINGS_V2 =====================
# Wrap existing endpoints to keep UI stable (no route overwrite)
try:
    import os, json, time, csv, hashlib
    from pathlib import Path

    _VSP_RID_CACHE = {"ts": 0.0, "rid": None, "why": None}

    def _safe_json(payload, status=200):
        try:
            from flask import Response
            return Response(json.dumps(payload, ensure_ascii=False), status=status, mimetype="application/json; charset=utf-8")
        except Exception:
            return payload

    def _find_endpoint(app, rule_path: str):
        try:
            for r in app.url_map.iter_rules():
                if getattr(r, "rule", None) == rule_path:
                    return r.endpoint
        except Exception:
            pass
        return None

    def _run_dirs_candidates():
        # reuse your existing roots logic if present, else default known locations
        roots = []
        # common: SECURITY_BUNDLE out_ci mirror, plus SECURITY-* workspace
        roots += ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/out_ci"]
        roots += ["/home/test/Data/SECURITY_BUNDLE/ui/out", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci"]
        # scan SECURITY-* out_ci folders (best-effort)
        try:
            base = Path("/home/test/Data")
            for d in base.glob("SECURITY-*"):
                roots.append(str(d / "out_ci"))
        except Exception:
            pass
        # de-dup + only existing
        out=[]
        seen=set()
        for r in roots:
            if r in seen: 
                continue
            seen.add(r)
            if Path(r).exists():
                out.append(r)
        return out

    def _list_rids(max_n=1200):
        rids=[]
        for root in _run_dirs_candidates():
            rp = Path(root)
            try:
                for d in rp.glob("*"):
                    if not d.is_dir():
                        continue
                    name = d.name
                    # accept common rid shapes
                    if name.startswith(("RUN_", "VSP_", "VSP_CI_", "VSP_CI_RUN_", "VSP_CI")):
                        rids.append((name, str(d)))
            except Exception:
                continue
        # newest first by mtime
        rids.sort(key=lambda t: Path(t[1]).stat().st_mtime if Path(t[1]).exists() else 0, reverse=True)
        return rids[:max_n]

    def _has_good_artifacts(run_dir: str):
        d = Path(run_dir)
        # must have gate summary (KPI)
        gate = d / "run_gate_summary.json"
        if not gate.exists() or gate.stat().st_size < 50:
            return (False, None)
        # must have some form of findings source
        f_json = d / "findings_unified.json"
        f_rpt_json = d / "reports" / "findings_unified.json"
        f_csv = d / "reports" / "findings_unified.csv"
        if f_json.exists() and f_json.stat().st_size > 200:
            return (True, "findings_unified.json")
        if f_rpt_json.exists() and f_rpt_json.stat().st_size > 200:
            return (True, "reports/findings_unified.json")
        if f_csv.exists() and f_csv.stat().st_size > 200:
            return (True, "reports/findings_unified.csv")
        return (False, None)

    def _pick_latest_rid_strict():
        cand = _list_rids()
        checked=0
        for rid, run_dir in cand:
            checked += 1
            ok, why = _has_good_artifacts(run_dir)
            if ok:
                return {"ok": True, "rid": rid, "why": why, "checked": checked, "candidates": len(cand)}
        return {"ok": False, "rid": None, "why": None, "checked": checked, "candidates": len(cand)}

    def _csv2json_sample(csv_path: Path, rid: str, limit: int):
        # cache by (path, mtime, limit)
        mtime = int(csv_path.stat().st_mtime)
        key = f"{rid}|{csv_path}|{mtime}|{limit}"
        h = hashlib.sha1(key.encode("utf-8", errors="ignore")).hexdigest()[:16]
        cache_dir = Path("/tmp/vsp_findings_cache")
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = cache_dir / f"findings_{rid}_{h}.json"
        if cache_file.exists() and cache_file.stat().st_size > 200:
            try:
                return json.loads(cache_file.read_text(encoding="utf-8", errors="replace"))
            except Exception:
                pass

        findings=[]
        counts={}
        total_rows=0

        def norm_sev(x: str):
            if not x: return "INFO"
            x = str(x).strip().upper()
            # normalize to your 6 levels
            if x in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"):
                return x
            # map common variants
            if x in ("ERROR","SEVERE"): return "HIGH"
            if x in ("WARN","WARNING"): return "MEDIUM"
            if x in ("DEBUG",): return "TRACE"
            return "INFO"

        # robust DictReader
        with csv_path.open("r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.DictReader(f)
            cols = [c for c in (reader.fieldnames or []) if c]
            # best-effort column picks
            def pick(row, keys):
                for k in keys:
                    if k in row and row.get(k) not in (None,""):
                        return row.get(k)
                return ""
            for row in reader:
                total_rows += 1
                sev = norm_sev(pick(row, ["severity","severity_norm","sev","level","priority"]))
                counts[sev] = counts.get(sev, 0) + 1
                if len(findings) < limit:
                    tool = pick(row, ["tool","scanner","engine","source"])
                    title = pick(row, ["title","message","rule","check","name"])
                    loc = pick(row, ["location","path","file","file_path","target"])
                    line = pick(row, ["line","line_start","start_line"])
                    if line and loc and (":" not in loc):
                        loc = f"{loc}:{line}"
                    findings.append({
                        "severity": sev,
                        "tool": (tool or "").strip() or "UNKNOWN",
                        "title": (title or "").strip() or "(no title)",
                        "location": (loc or "").strip() or "(no location)",
                    })

        # ensure all 6 levels exist
        for k in ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"]:
            counts.setdefault(k, 0)

        payload = {
            "ok": True,
            "from": "reports/findings_unified.csv",
            "meta": {
                "rid": rid,
                "generated_from": str(csv_path),
                "generated_ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "limit": limit,
                "total_rows": total_rows,
                "truncated": total_rows > limit,
                "counts_by_severity": counts,
            },
            "findings": findings,
        }
        try:
            cache_file.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        return payload

    # ---- wrap rid_latest ----
    _ep_rid = _find_endpoint(app, "/api/vsp/rid_latest")
    if _ep_rid and _ep_rid in app.view_functions:
        _orig = app.view_functions[_ep_rid]
        def _rid_latest_wrapped(*args, **kwargs):
            now = time.time()
            # TTL cache 20s
            if _VSP_RID_CACHE["rid"] and (now - _VSP_RID_CACHE["ts"] < 20.0):
                return _safe_json({"ok": True, "rid": _VSP_RID_CACHE["rid"], "stale": False, "why": _VSP_RID_CACHE["why"], "cached": True})
            res = _pick_latest_rid_strict()
            if res.get("ok") and res.get("rid"):
                _VSP_RID_CACHE.update({"ts": now, "rid": res["rid"], "why": res.get("why")})
            return _safe_json(res)
        app.view_functions[_ep_rid] = _rid_latest_wrapped

    # ---- wrap run_file_allow for findings_unified.json ----
    _ep_rfa = _find_endpoint(app, "/api/vsp/run_file_allow")
    if _ep_rfa and _ep_rfa in app.view_functions:
        _orig_rfa = app.view_functions[_ep_rfa]
        from flask import request
        def _rfa_wrapped(*args, **kwargs):
            # call original first
            resp = _orig_rfa(*args, **kwargs)
            try:
                path = (request.args.get("path") or "").strip()
                rid = (request.args.get("rid") or "").strip()
                if path != "findings_unified.json":
                    return resp
                # if already ok:true json, keep it
                txt = None
                try:
                    txt = resp.get_data(as_text=True)  # type: ignore
                except Exception:
                    pass
                if txt:
                    try:
                        j = json.loads(txt)
                        if isinstance(j, dict) and j.get("ok") is True and (j.get("findings") or j.get("meta")):
                            return resp
                    except Exception:
                        pass

                # generate from reports CSV if possible
                limit = 200
                try:
                    limit = int(request.args.get("limit") or 200)
                except Exception:
                    limit = 200
                limit = max(25, min(limit, 500))  # commercial-safe cap

                # derive run_dir like your system does: best-effort search by RID in known roots
                run_dir = None
                for r, d in _list_rids(max_n=2000):
                    if r == rid:
                        run_dir = d
                        break
                if not run_dir:
                    return _safe_json({"ok": False, "err": "run_dir not found", "rid": rid, "path": path, "marker": "VSP_P0_CONTRACTIZE_RID_LATEST_AND_FINDINGS_V2"}, 200)

                d = Path(run_dir)
                csv_path = d / "reports" / "findings_unified.csv"
                if csv_path.exists() and csv_path.stat().st_size > 200:
                    payload = _csv2json_sample(csv_path, rid, limit)
                    return _safe_json(payload, 200)

                # last resort: if reports/findings_unified.json exists, sample it
                jpath = d / "reports" / "findings_unified.json"
                if jpath.exists() and jpath.stat().st_size > 200:
                    try:
                        j = json.loads(jpath.read_text(encoding="utf-8", errors="replace"))
                        # normalize minimal shape
                        findings = j.get("findings") if isinstance(j, dict) else None
                        if isinstance(findings, list):
                            findings = findings[:limit]
                        return _safe_json({"ok": True, "from":"reports/findings_unified.json", "meta":{"rid":rid,"limit":limit,"truncated": True}, "findings": findings or []}, 200)
                    except Exception:
                        pass

                return _safe_json({"ok": False, "err": "missing findings sources", "rid": rid, "path": path, "marker": "VSP_P0_CONTRACTIZE_RID_LATEST_AND_FINDINGS_V2"}, 200)
            except Exception as e:
                return _safe_json({"ok": False, "err": f"wrapped exception: {e}", "marker": "VSP_P0_CONTRACTIZE_RID_LATEST_AND_FINDINGS_V2"}, 200)

        app.view_functions[_ep_rfa] = _rfa_wrapped

except Exception:
    pass
# ===================== /VSP_P0_CONTRACTIZE_RID_LATEST_AND_FINDINGS_V2 =====================

# ===================== VSP_P0_RUN_FILE_ALLOW_FINDINGS_READER_V1 =====================
# Improve findings_unified.json serving: support root json + reports json(list/dict) + csv sample.
try:
    import json, time, csv, hashlib
    from pathlib import Path
    from flask import request

    def _safe_json_v1(payload, status=200):
        from flask import Response
        return Response(json.dumps(payload, ensure_ascii=False), status=status, mimetype="application/json; charset=utf-8")

    def _find_endpoint_v1(app, rule_path: str):
        for r in app.url_map.iter_rules():
            if getattr(r, "rule", None) == rule_path:
                return r.endpoint
        return None

    def _run_dirs_candidates_v1():
        roots=[]
        roots += ["/home/test/Data/SECURITY_BUNDLE/out", "/home/test/Data/SECURITY_BUNDLE/out_ci"]
        roots += ["/home/test/Data/SECURITY_BUNDLE/ui/out", "/home/test/Data/SECURITY_BUNDLE/ui/out_ci"]
        try:
            base=Path("/home/test/Data")
            for d in base.glob("SECURITY-*"):
                roots.append(str(d/"out_ci"))
        except Exception:
            pass
        out=[]; seen=set()
        for r in roots:
            if r in seen: 
                continue
            seen.add(r)
            if Path(r).exists():
                out.append(r)
        return out

    def _list_rids_v1(max_n=2500):
        rids=[]
        for root in _run_dirs_candidates_v1():
            rp=Path(root)
            try:
                for d in rp.glob("*"):
                    if d.is_dir() and d.name.startswith(("RUN_","VSP_","VSP_CI","VSP_CI_")):
                        rids.append((d.name, str(d)))
            except Exception:
                continue
        rids.sort(key=lambda t: Path(t[1]).stat().st_mtime if Path(t[1]).exists() else 0, reverse=True)
        return rids[:max_n]

    def _find_run_dir_by_rid_v1(rid: str):
        for r, d in _list_rids_v1():
            if r == rid:
                return d
        return None

    def _csv2json_sample_v1(csv_path: Path, rid: str, limit: int):
        mtime=int(csv_path.stat().st_mtime)
        key=f"{rid}|{csv_path}|{mtime}|{limit}"
        h=hashlib.sha1(key.encode("utf-8", errors="ignore")).hexdigest()[:16]
        cache_dir=Path("/tmp/vsp_findings_cache"); cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file=cache_dir/f"findings_{rid}_{h}.json"
        if cache_file.exists() and cache_file.stat().st_size>200:
            try: return json.loads(cache_file.read_text(encoding="utf-8", errors="replace"))
            except Exception: pass

        findings=[]; counts={}; total_rows=0
        def norm_sev(x):
            if not x: return "INFO"
            x=str(x).strip().upper()
            if x in ("CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"): return x
            if x in ("ERROR","SEVERE"): return "HIGH"
            if x in ("WARN","WARNING"): return "MEDIUM"
            if x in ("DEBUG",): return "TRACE"
            return "INFO"

        with csv_path.open("r", encoding="utf-8", errors="replace", newline="") as f:
            reader=csv.DictReader(f)
            def pick(row, keys):
                for k in keys:
                    if k in row and row.get(k) not in (None,""):
                        return row.get(k)
                return ""
            for row in reader:
                total_rows += 1
                sev=norm_sev(pick(row, ["severity","severity_norm","sev","level","priority"]))
                counts[sev]=counts.get(sev,0)+1
                if len(findings) < limit:
                    tool=(pick(row, ["tool","scanner","engine","source"]) or "").strip() or "UNKNOWN"
                    title=(pick(row, ["title","message","rule","check","name"]) or "").strip() or "(no title)"
                    loc=(pick(row, ["location","path","file","file_path","target"]) or "").strip() or "(no location)"
                    line=(pick(row, ["line","line_start","start_line"]) or "").strip()
                    if line and loc and (":" not in loc):
                        loc=f"{loc}:{line}"
                    findings.append({"severity": sev, "tool": tool, "title": title, "location": loc})

        for k in ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"]:
            counts.setdefault(k,0)

        payload={
            "ok": True,
            "from": "reports/findings_unified.csv",
            "meta": {
                "rid": rid,
                "generated_from": str(csv_path),
                "generated_ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "limit": limit,
                "total_rows": total_rows,
                "truncated": total_rows > limit,
                "counts_by_severity": counts,
            },
            "findings": findings,
        }
        try: cache_file.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        except Exception: pass
        return payload

    def _read_findings_json_anyshape_v1(jpath: Path, rid: str, limit: int):
        # supports: list[...] OR dict{findings:[...]} OR dict{data/items/results:[...]}
        raw = jpath.read_text(encoding="utf-8", errors="replace")
        j = json.loads(raw)
        findings=None
        if isinstance(j, list):
            findings = j
        elif isinstance(j, dict):
            for key in ("findings","data","items","results"):
                v = j.get(key)
                if isinstance(v, list):
                    findings = v
                    break
        if not isinstance(findings, list):
            findings=[]
        return {
            "ok": True,
            "from": str(jpath).split("/"+rid+"/",1)[-1] if ("/"+rid+"/") in str(jpath) else jpath.name,
            "meta": {"rid": rid, "limit": limit, "truncated": len(findings) > limit},
            "findings": findings[:limit],
        }

    _ep = _find_endpoint_v1(app, "/api/vsp/run_file_allow")
    if _ep and _ep in app.view_functions:
        _orig = app.view_functions[_ep]

        def _run_file_allow_wrapped_v1(*args, **kwargs):
            resp = _orig(*args, **kwargs)
            try:
                path=(request.args.get("path") or "").strip()
                if path != "findings_unified.json":
                    return resp

                rid=(request.args.get("rid") or "").strip()
                if not rid:
                    return _safe_json_v1({"ok": False, "err":"missing rid", "marker":"VSP_P0_RUN_FILE_ALLOW_FINDINGS_READER_V1"}, 200)

                limit=200
                try: limit=int(request.args.get("limit") or 200)
                except Exception: limit=200
                limit=max(25, min(limit, 500))

                run_dir=_find_run_dir_by_rid_v1(rid)
                if not run_dir:
                    return _safe_json_v1({"ok": False, "err":"run_dir not found", "rid":rid, "marker":"VSP_P0_RUN_FILE_ALLOW_FINDINGS_READER_V1"}, 200)

                d=Path(run_dir)

                # 1) prefer root findings_unified.json (most correct)
                rootj=d/"findings_unified.json"
                if rootj.exists() and rootj.stat().st_size>200:
                    try:
                        raw = rootj.read_text(encoding="utf-8", errors="replace")
                        j = json.loads(raw)
                        if isinstance(j, dict) and isinstance(j.get("findings"), list):
                            return _safe_json_v1({"ok": True, "from":"findings_unified.json", "meta": j.get("meta") or {"rid":rid,"limit":limit,"truncated": len(j["findings"])>limit}, "findings": j["findings"][:limit]}, 200)
                        if isinstance(j, list):
                            return _safe_json_v1({"ok": True, "from":"findings_unified.json", "meta":{"rid":rid,"limit":limit,"truncated": len(j)>limit}, "findings": j[:limit]}, 200)
                    except Exception:
                        pass

                # 2) reports/findings_unified.json any-shape
                rptj=d/"reports"/"findings_unified.json"
                if rptj.exists() and rptj.stat().st_size>50:
                    try:
                        payload=_read_findings_json_anyshape_v1(rptj, rid, limit)
                        return _safe_json_v1(payload, 200)
                    except Exception:
                        pass

                # 3) reports/findings_unified.csv -> sample
                csvp=d/"reports"/"findings_unified.csv"
                if csvp.exists() and csvp.stat().st_size>200:
                    payload=_csv2json_sample_v1(csvp, rid, limit)
                    return _safe_json_v1(payload, 200)

                return _safe_json_v1({"ok": False, "err":"missing findings sources", "rid":rid, "marker":"VSP_P0_RUN_FILE_ALLOW_FINDINGS_READER_V1"}, 200)
            except Exception as e:
                return _safe_json_v1({"ok": False, "err": str(e), "marker":"VSP_P0_RUN_FILE_ALLOW_FINDINGS_READER_V1"}, 200)

        app.view_functions[_ep] = _run_file_allow_wrapped_v1

except Exception:
    pass
# ===================== /VSP_P0_RUN_FILE_ALLOW_FINDINGS_READER_V1 =====================


# === VSP_P0_COMMERCIAL_API_WRAPPERS_V1 ===
# Purpose:
# - FE must NOT call run_file_allow, and must NOT know internal file paths/names.
# - Provide stateless commercial API wrappers with paging + caching headers.

def __vsp__now_iso():
  try:
    import datetime as _dt
    return _dt.datetime.utcnow().isoformat()
  except Exception:
    return ""

def __vsp__run_roots():
  import os
  roots = []
  # Prefer explicit env
  env = os.environ.get("VSP_RUN_ROOTS","").strip()
  if env:
    for x in env.split(":"):
      x = x.strip()
      if x:
        roots.append(x)
  # Known defaults (safe, best-effort)
  defaults = [
    "/home/test/Data/SECURITY_BUNDLE/out_ci",
    "/home/test/Data/SECURITY_BUNDLE/out",
    "/home/test/Data/SECURITY-10-10-v4/out_ci",
    "/home/test/Data/SECURITY-10-10-v4/out",
    "/home/test/Data/SECURITY_BUNDLE/ui/out_ci",
    "/home/test/Data/SECURITY_BUNDLE/ui/out",
  ]
  for d in defaults:
    if d not in roots:
      roots.append(d)
  return roots

def __vsp__find_rundir(rid: str):
  from pathlib import Path
  if not rid:
    return None
  rid = str(rid).strip()
  if not rid:
    return None
  # Direct hit
  for root in __vsp__run_roots():
    p = Path(root) / rid
    if p.is_dir():
      return p
  # Shallow glob fallback (depth <= 3)
  for root in __vsp__run_roots():
    base = Path(root)
    if not base.exists():
      continue
    # avoid huge recursion: only 3 levels
    globs = [
      f"{rid}",
      f"*/{rid}",
      f"*/*/{rid}",
      f"*/*/*/{rid}",
    ]
    for g in globs:
      for cand in base.glob(g):
        if cand.is_dir():
          return cand
  return None

def __vsp__load_json_for_rid(rid: str, relpaths):
  import json
  rd = __vsp__find_rundir(rid)
  if not rd:
    return None, None
  rels = list(relpaths or [])
  # Try exact rel first, then common prefixes
  try_list = []
  for rp in rels:
    rp = (rp or "").lstrip("/")
    if not rp:
      continue
    try_list.append(rp)
    if not rp.startswith("reports/"):
      try_list.append("reports/" + rp)
    if not rp.startswith("report/"):
      try_list.append("report/" + rp)
  # de-dup
  seen=set(); ordered=[]
  for x in try_list:
    if x not in seen:
      seen.add(x); ordered.append(x)

  for rp in ordered:
    fp = rd / rp
    if fp.is_file():
      try:
        obj = json.loads(fp.read_text(encoding="utf-8", errors="ignore"))
      except Exception:
        # try binary json
        try:
          obj = json.loads(fp.read_bytes().decode("utf-8", errors="ignore"))
        except Exception:
          obj = None
      if obj is not None:
        return obj, str(fp)
  return None, None

def __vsp__resp(payload: dict, cache_s: int = 30):
  # set caching headers to reduce XHR spam
  try:
    from flask import make_response, jsonify
    r = make_response(jsonify(payload))
    r.headers["Cache-Control"] = f"public, max-age={int(cache_s)}"
    return r
  except Exception:
    return payload

# --- wrapper: run_gate_summary (no run_file_allow) ---
@app.get("/api/vsp/run_gate_summary_v1")
def vsp_run_gate_summary_v1():
  from flask import request
  rid = (request.args.get("rid") or "").strip()
  j, fp = __vsp__load_json_for_rid(rid, ["run_gate_summary.json"])
  if not isinstance(j, dict):
    return __vsp__resp({"ok": True, "rid": rid, "ts": __vsp__now_iso(), "no_data": True, "counts_total": {"total": 0}, "counts_by_sev": {}, "by_tool": {}, "by_cwe": {}, "by_module": {}}, 15)
  # Commercial: do NOT leak file path; keep payload flat for existing FE.
  j = dict(j)
  j["ok"] = True
  j["rid"] = rid
  j["ts"] = __vsp__now_iso()
  j["no_data"] = False
  # Ensure totals never missing (CIO trust)
  ct = j.get("counts_total") or {}
  if not isinstance(ct, dict):
    ct = {}
  if ct.get("total") is None:
    # derive from counts_by_sev if present
    cbs = j.get("counts_by_sev") or {}
    if isinstance(cbs, dict):
      try:
        ct["total"] = int(sum(int(v or 0) for v in cbs.values()))
      except Exception:
        ct["total"] = 0
    else:
      ct["total"] = 0
  j["counts_total"] = ct
  # Normalize missing sev buckets to 0
  cbs = j.get("counts_by_sev") or {}
  if not isinstance(cbs, dict):
    cbs = {}
  for k in ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"]:
    if cbs.get(k) is None:
      cbs[k] = 0
  j["counts_by_sev"] = cbs
  return __vsp__resp(j, 30)

# --- wrapper: run_manifest (no run_file_allow) ---
@app.get("/api/vsp/run_manifest_v1")
def vsp_run_manifest_v1():
  from flask import request
  rid = (request.args.get("rid") or "").strip()
  j, fp = __vsp__load_json_for_rid(rid, ["run_manifest.json"])
  if not isinstance(j, dict):
    return __vsp__resp({"ok": True, "rid": rid, "ts": __vsp__now_iso(), "no_data": True, "manifest": {}}, 15)
  out = {"ok": True, "rid": rid, "ts": __vsp__now_iso(), "no_data": False, "manifest": j}
  return __vsp__resp(out, 30)

# --- wrapper: findings paging/search/filter (no run_file_allow, no file name leaks) ---
@app.get("/api/vsp/findings_page_v3")
def vsp_findings_page_v3():
  from flask import request
  rid = (request.args.get("rid") or "").strip()
  try: limit = int(request.args.get("limit") or 50)
  except Exception: limit = 50
  try: offset = int(request.args.get("offset") or 0)
  except Exception: offset = 0
  limit = max(1, min(limit, 200))
  offset = max(0, offset)

  q = (request.args.get("q") or "").strip().lower()
  tool = (request.args.get("tool") or "").strip().upper()
  sev  = (request.args.get("severity") or "").strip().upper()
  cwe  = (request.args.get("cwe") or "").strip()
  file_kw = (request.args.get("file") or "").strip().lower()
  mod_kw  = (request.args.get("module") or "").strip().lower()

  j, fp = __vsp__load_json_for_rid(rid, ["findings_unified.json"])
  # Support legacy: sometimes findings are nested under "findings"
  items = []
  if isinstance(j, dict) and isinstance(j.get("findings"), list):
    items = j.get("findings") or []
  elif isinstance(j, list):
    items = j
  else:
    items = []

  def match(it: dict) -> bool:
    try:
      if tool and str(it.get("tool","")).upper() != tool:
        return False
      if sev and str(it.get("severity","")).upper() != sev:
        return False
      if cwe and str(it.get("cwe") or "").strip() != cwe:
        return False
      if file_kw and file_kw not in str(it.get("file","")).lower():
        return False
      if mod_kw and mod_kw not in str(it.get("module","")).lower():
        return False
      if q:
        blob = " ".join([
          str(it.get("title","")),
          str(it.get("tool","")),
          str(it.get("severity","")),
          str(it.get("file","")),
          str(it.get("module","")),
          str(it.get("cwe","") or ""),
        ]).lower()
        if q not in blob:
          return False
      return True
    except Exception:
      return True

  filt = [it for it in items if isinstance(it, dict) and match(it)]
  total = len(filt)
  page = filt[offset: offset + limit]

  # Commercial contract: do NOT include any internal filenames in UI-visible fields
  payload = {
    "ok": True,
    "rid": rid,
    "ts": __vsp__now_iso(),
    "profile": {"mode": "commercial"},
    "filters": {"limit": limit, "offset": offset, "q": q, "tool": tool, "severity": sev, "cwe": cwe, "file": file_kw, "module": mod_kw},
    "data": {"items": page, "total": total},
    "meta": {"paging": {"limit": limit, "offset": offset, "next_offset": (offset + limit if offset + limit < total else None)},
             "no_data": (len(items) == 0),
             "coverage": {"tools_expected": 8}},
  }
  return __vsp__resp(payload, 30)

# === /VSP_P0_COMMERCIAL_API_WRAPPERS_V1 ===



# VSP_P0_API_HITLOG_V1N1: commercial audit logging for /api/vsp/* (no gunicorn accesslog required)
try:
    @app.before_request
    def __vsp_api_hitlog_v1n1():
        try:
            if request.path and request.path.startswith("/api/vsp/"):
                fp = getattr(request, "full_path", request.path) or request.path
                # normalize noisy ts=
                fp = re.sub(r'([?&])ts=\d+', r'\1ts=', fp)
                print(f"[VSP_API_HIT] {request.method} {fp}", flush=True)
        except Exception:
            pass
except Exception:
    pass




# ==================== VSP_P0_RUN_FILE_CONTRACT_V1P3 ====================
# Commercial contract: FE must call /api/vsp/run_file?rid=...&name=...
# Backend maps logical "name" to internal allowed paths and redirects to internal file-allow route.
try:
    from flask import redirect, request, jsonify
except Exception:
    redirect = None
    request = None
    jsonify = None

@app.get("/api/vsp/run_file")
def vsp_run_file_contract_v1p3():
    """
    name:
      - gate_summary -> run_gate_summary.json
      - gate_json    -> run_gate.json
      - findings_unified -> findings_unified.json (internal locations resolved by existing logic)
      - findings_html -> reports/findings_unified.html
      - run_manifest -> run_manifest.json
      - run_evidence_index -> run_evidence_index.json
    """
    try:
        rid = (request.args.get("rid") or "").strip()
        name = (request.args.get("name") or "").strip()
        if not rid or not name:
            return jsonify({"ok": False, "error": "missing rid/name"}), 400

        # logical name -> internal path
        MAP = {
          "gate_summary": "run_gate_summary.json",
          "gate_json": "run_gate.json",
          "findings_unified": "findings_unified.json",
          "findings_html": "reports/findings_unified.html",
          "run_manifest": "run_manifest.json",
          "run_evidence_index": "run_evidence_index.json",
        }
        path = MAP.get(name, "")

        # allow passing raw safe filenames (no slashes) for backward compat
        if not path:
            if "/" in name or "\\" in name:
                return jsonify({"ok": False, "error": "invalid name"}), 400
            # only allow small safe set by extension
            if not re.match(r'^[a-zA-Z0-9_.-]{1,120}$', name):
                return jsonify({"ok": False, "error": "invalid name"}), 400
            path = name

        # Redirect to internal allow endpoint (FE never calls it directly)
        return redirect(f"/api/vsp/run_file_allow?rid={rid}&path={path}", code=302)
    except Exception as e:
        try:
            return jsonify({"ok": False, "error": str(e)}), 500
        except Exception:
            return ("error", 500)
# ==================== /VSP_P0_RUN_FILE_CONTRACT_V1P3 ====================



# VSP_P0_TOPFIND_ROUTE_V2
@app.route("/api/vsp/_disabled_top_findings_v1_legacy", methods=["GET"], endpoint="api_vsp_top_findings_v1_p0")
def api_vsp_top_findings_v1_p0():
    try:
        rid = (request.args.get("rid") or "").strip()
        limit = int(request.args.get("limit") or "5")
        if limit < 1: limit = 1
        if limit > 50: limit = 50

        if not rid:
            rid = _vsp__pick_latest_rid()

        if not rid:
            return jsonify({"ok": False, "rid": "", "total": 0, "items": [], "reason": "NO_RUNS"}), 200

        findings, errc = _vsp__load_unified_findings_anywhere(rid)
        if findings is None:
            return jsonify({"ok": False, "rid": rid, "total": 0, "items": [], "reason": errc}), 200

        items = []
        for f in (findings or []):
            if not isinstance(f, dict):
                continue
            it = {
                "tool": f.get("tool"),
                "severity": (f.get("severity") or "").upper(),
                "title": f.get("title"),
                "cwe": f.get("cwe"),
                "rule_id": f.get("rule_id") or f.get("check_id") or f.get("id"),
                "file": _vsp__sanitize_path(f.get("file") or f.get("path") or ""),
                "line": f.get("line") or f.get("start_line") or f.get("line_start"),
            }
            items.append(it)

        items.sort(key=lambda x: (_vsp__sev_weight(x.get("severity")), str(x.get("title") or "")), reverse=True)
        return jsonify({
            "ok": True,
            "rid": rid,
            "total": len(items),
            "items": items[:limit],
            "ts": datetime.utcnow().isoformat() + "Z",
        }), 200
    except Exception:
        return jsonify({"ok": False, "rid": (request.args.get("rid") or ""), "total": 0, "items": [], "reason": "EXCEPTION"}), 200




# VSP_P0_TOPFIND_ROUTE_V4 (contract+fallback)
@app.route("/api/vsp/top_findings_v1", methods=["GET"], endpoint="vsp_top_findings_v1_p0")
def vsp_top_findings_v1_p0():
    try:
        rid_req = (request.args.get("rid") or "").strip()
        rid = rid_req
        limit = int(request.args.get("limit") or "5")
        limit = 1 if limit < 1 else (50 if limit > 50 else limit)

        if not rid:
            rid = _vsp__pick_latest_rid_with_unified() or _vsp__pick_latest_rid()

        if not rid:
            return jsonify({"ok": False, "rid": "", "rid_requested": rid_req, "rid_used": "", "total": 0, "items": [], "reason": "NO_RUNS"}), 200

        findings, reason = _vsp__load_unified_findings_anywhere(rid)

        # fallback: requested RID has no usable sources -> use latest RID that actually has unified/csv
        if findings is None:
            rid2 = _vsp__pick_latest_rid_with_unified()
            if rid2 and rid2 != rid:
                findings2, reason2 = _vsp__load_unified_findings_anywhere(rid2)
                if findings2 is not None:
                    rid = rid2
                    findings = findings2
                    reason = ""

        if findings is None:
            return jsonify({"ok": False, "rid": rid, "rid_requested": rid_req, "rid_used": "", "total": 0, "items": [], "reason": reason}), 200

        items = []
        for f in (findings or []):
            if not isinstance(f, dict):
                continue
            items.append({
                "tool": f.get("tool"),
                "severity": (f.get("severity") or "").upper(),
                "title": f.get("title"),
                "cwe": f.get("cwe"),
                "rule_id": f.get("rule_id") or f.get("check_id") or f.get("id"),
                "file": _vsp__sanitize_path(f.get("file") or f.get("path") or ""),
                "line": f.get("line") or f.get("start_line") or f.get("line_start"),
            })
        items.sort(key=lambda x: (_vsp__sev_weight(x.get("severity")), str(x.get("title") or "")), reverse=True)

        return jsonify({
            "ok": True,
            "rid": rid,
            "rid_requested": rid_req,
            "rid_used": rid,
            "total": len(items),
            "items": items[:limit],
            "ts": datetime.utcnow().isoformat() + "Z",
        }), 200
    except Exception:
        return jsonify({"ok": False, "rid": (request.args.get("rid") or ""), "rid_requested": (request.args.get("rid") or ""), "rid_used": "", "total": 0, "items": [], "reason": "EXCEPTION"}), 200


@app.route("/api/vsp/_diag_topfind_routes_v1", methods=["GET"])
def vsp__diag_topfind_routes_v1():
    # returns how many live rules still point to /api/vsp/top_findings_v1 (should be 1)
    try:
        rules = []
        for r in app.url_map.iter_rules():
            if "/api/vsp/top_findings_v1" in str(r.rule):
                rules.append({"rule": str(r.rule), "endpoint": r.endpoint, "methods": sorted(list(r.methods or []))})
        return jsonify({"ok": True, "count": len(rules), "rules": rules}), 200
    except Exception:
        return jsonify({"ok": False, "count": 0, "rules": []}), 200

