/**
 * patch_sb_severity_chart.js – NO-OP
 * Tạm thời tắt mọi chỉnh sửa SEVERITY BUCKETS để UI ổn định.
 */
document.addEventListener("DOMContentLoaded", function () {
  console.log("[SB][sev] severity chart patch disabled (NO-OP).");
});
