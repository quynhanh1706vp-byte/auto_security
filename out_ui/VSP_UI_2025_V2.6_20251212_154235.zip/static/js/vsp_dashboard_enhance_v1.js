(function () {
  // VSP 2025 – Dashboard enhance V4 (clean, no patch lỗi)
  console.log('[VSP_DASH] vsp_dashboard_enhance_v1.js (V4 clean) loaded');

  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function safeText(id, value) {
    var el = document.getElementById(id);
    if (!el) return;
    el.textContent = value;
  }

  function fetchDashboard() {
    return fetch('/api/vsp/dashboard_v3', {
      credentials: 'same-origin'
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

  function fillKpis(data) {
    if (!data || typeof data !== 'object') return;
    var bySeverity = data.by_severity || {};
    var total = data.total_findings != null
      ? data.total_findings
      : (bySeverity.CRITICAL || 0) + (bySeverity.HIGH || 0) +
        (bySeverity.MEDIUM || 0) + (bySeverity.LOW || 0) +
        (bySeverity.INFO || 0) + (bySeverity.TRACE || 0);

    safeText('vsp-kpi-total-findings', total);
    safeText('vsp-kpi-critical', bySeverity.CRITICAL != null ? bySeverity.CRITICAL : 0);
    safeText('vsp-kpi-high',     bySeverity.HIGH     != null ? bySeverity.HIGH     : 0);
    safeText('vsp-kpi-medium',   bySeverity.MEDIUM   != null ? bySeverity.MEDIUM   : 0);
    safeText('vsp-kpi-low',      bySeverity.LOW      != null ? bySeverity.LOW      : 0);
    safeText('vsp-kpi-info',     bySeverity.INFO     != null ? bySeverity.INFO     : 0);
    safeText('vsp-kpi-trace',    bySeverity.TRACE    != null ? bySeverity.TRACE    : 0);

    if (data.security_posture_score != null) {
      safeText('vsp-kpi-security-score', data.security_posture_score);
    }

    safeText('vsp-kpi-top-tool',   data.top_risky_tool       || 'N/A');
    safeText('vsp-kpi-top-cwe',    data.top_impacted_cwe     || data.top_cwe || 'N/A');
    safeText('vsp-kpi-top-module', data.top_vulnerable_module || 'N/A');

    var gate = data.ci_gate_status || data.ci_gate || {};
    var gateLabel = gate.label || gate.status || 'N/A';
    var gateDesc  = gate.description || 'Gate dựa trên CRITICAL/HIGH, score & coverage.';
    safeText('vsp-kpi-ci-gate-status',      gateLabel);
    safeText('vsp-kpi-ci-gate-status-desc', gateDesc);
  }

  function hydrateDashboard(data) {
    try {
      fillKpis(data);

      if (window.VSP_CHARTS_V3 && typeof window.VSP_CHARTS_V3.updateFromDashboard === 'function') {
        window.VSP_CHARTS_V3.updateFromDashboard(data);
      } else if (window.VSP_CHARTS_V2 && typeof window.VSP_CHARTS_V2.updateFromDashboard === 'function') {
        window.VSP_CHARTS_V2.updateFromDashboard(data);
      } else {
        console.warn('[VSP_DASH] No charts engine V2/V3 found – only KPIs filled.');
      }

      console.log('[VSP_DASH] Dashboard hydrated OK (V4 clean).');
    } catch (e) {
      console.error('[VSP_DASH] Error hydrating dashboard:', e);
    }
  }

  window.hydrateDashboard = hydrateDashboard;

  onReady(function () {
    var pane = document.getElementById('vsp-dashboard-main');
    if (!pane) {
      console.log('[VSP_DASH] No dashboard pane found, skip auto fetch.');
      return;
    }
    console.log('[VSP_DASH] Hydrating dashboard (auto fetch)…');
    fetchDashboard()
      .then(function (data) {
        console.log('[VSP_DASH] dashboard_v3 data =', data);
        hydrateDashboard(data);
      })
      .catch(function (err) {
        console.error('[VSP_DASH] Failed to load /api/vsp/dashboard_v3:', err);
      });
  });

})();
