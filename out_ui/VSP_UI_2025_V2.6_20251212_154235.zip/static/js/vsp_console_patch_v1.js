// [VSP_HASH_SANITIZE_V1] Fix invalid hash patterns like "#runs:ID" breaking querySelector
(function() {
  try {
    var h = window.location && window.location.hash;
    if (h && h.indexOf(":") !== -1) {
      var clean = h.split(":")[0];
      console.log("[VSP_HASH_SANITIZE_V1] Clean hash", h, "->", clean);
      window.location.hash = clean;
    }
  } catch (e) {
    console.error("[VSP_HASH_SANITIZE_V1] Error:", e);
  }
})();


/**
 * VSP console patch v1
 * Mục tiêu: chặn mọi log / warning chứa "[VSP_RUNS_UI_v1]"
 * để không còn rác console từ legacy stub cũ.
 */

(function () {
  'use strict';

  var origWarn = console.warn;
  var origLog  = console.log;

  function shouldMute(msg) {
    if (!msg || typeof msg !== 'string') return false;
    return msg.indexOf('[VSP_RUNS_UI_v1]') !== -1 ||
           msg.indexOf('tbody#vsp-runs-tbody') !== -1;
  }

  console.warn = function () {
    if (arguments.length > 0 && shouldMute(arguments[0])) {
      // Nuốt luôn log cũ
      return;
    }
    return origWarn.apply(console, arguments);
  };

  console.log = function () {
    if (arguments.length > 0 && shouldMute(arguments[0])) {
      return;
    }
    return origLog.apply(console, arguments);
  };

  origLog('[VSP_CONSOLE_PATCH] Installed console filter for legacy RUNS_UI_v1 logs.');
})();


// VSP_SETTINGS_AUTOBIND_v1
(function() {
  const LOG = "[VSP_SETTINGS_BIND]";
  function bindVspSettingsTab() {
    if (!window.vspInitSettingsTab) {
      console.log(LOG, "vspInitSettingsTab not found – skip.");
      return;
    }
    const btns = Array.from(document.querySelectorAll(
      "[data-vsp-tab='settings'], [data-vsp-target='#tab-settings'], [data-vsp-id='settings']"
    ));
    if (!btns.length) {
      console.warn(LOG, "No Settings tab button found.");
      return;
    }
    btns.forEach(btn => {
      if (btn.dataset.vspSettingsBound === "1") return;
      btn.addEventListener("click", () => {
        try {
          window.vspInitSettingsTab();
        } catch (e) {
          console.error(LOG, "Error in vspInitSettingsTab", e);
        }
      });
      btn.dataset.vspSettingsBound = "1";
    });
    console.log(LOG, "bound", btns.length, "Settings tab buttons.");
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bindVspSettingsTab);
  } else {
    bindVspSettingsTab();
  }
})();

// [VSP_TABS_MAIN_INIT]
(function () {
  "use strict";
  var LOG_PREFIX_TABS = "[VSP_TABS]";

  function logTabs() {
    if (typeof console !== "undefined" && console.log) {
      var args = Array.prototype.slice.call(arguments);
      args.unshift(LOG_PREFIX_TABS);
      console.log.apply(console, args);
    }
  }

  function normalizeLabel(text) {
    if (!text) return "";
    return text.replace(/\s+/g, " ").trim().toLowerCase();
  }

  function initTabs() {
    // Map label -> pane id
    var map = {
      "dashboard": "#vsp-tab-dashboard",
      "runs & reports": "#vsp-tab-runs",
      "data source": "#vsp-tab-datasource",
      "settings": "#vsp-tab-settings",
      "settings (profile / tools)": "#vsp-tab-settings",
      "rule overrides": "#vsp-tab-rules"
    };

    var buttons = [];
    var candidates = document.querySelectorAll("button, a, span");

    for (var i = 0; i < candidates.length; i++) {
      var el = candidates[i];
      var label = normalizeLabel(el.textContent || el.innerText);
      if (map[label]) {
        el.setAttribute("data-vsp-tab-target", map[label]);
        el.classList.add("vsp-tab-link");
        buttons.push(el);
      }
    }

    var panes = document.querySelectorAll(".vsp-tab-pane");
    if (!buttons.length || !panes.length) {
      logTabs("log removed", "buttons", buttons.length, "panes", panes.length);
      return;
    }

    function showTab(targetSelector) {
      if (!targetSelector) return;
      var found = false;

      for (var i = 0; i < panes.length; i++) {
        var pane = panes[i];
        if (pane.matches(targetSelector)) {
          pane.classList.add("vsp-tab-pane-active");
          pane.style.display = "";
          found = true;
        } else {
          pane.classList.remove("vsp-tab-pane-active");
          pane.style.display = "none";
        }
      }

      for (var j = 0; j < buttons.length; j++) {
        var btn = buttons[j];
        var sel = btn.getAttribute("data-vsp-tab-target");
        if (sel === targetSelector) {
          btn.classList.add("vsp-tab-link-active");
        } else {
          btn.classList.remove("vsp-tab-link-active");
        }
      }

      if (!found) {
        logTabs("No pane matched selector:", targetSelector);
      } else {
        logTabs("Switched to tab:", targetSelector);
      }
    }

    buttons.forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        var sel = btn.getAttribute("data-vsp-tab-target");
        if (!sel) return;
        showTab(sel);
      });
    });

    var defaultSelector = "#vsp-tab-dashboard";
    if (window.location.hash && document.querySelector(window.location.hash)) {
      defaultSelector = window.location.hash;
    }
    showTab(defaultSelector);
    logTabs("Initialized, default tab =", defaultSelector);

    // debug: vspTabsShow('#vsp-tab-runs')
    window.vspTabsShow = showTab;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initTabs);
  } else {
    initTabs();
  }
})();

// [VSP_TABS_AUTOWRAP_V1]
(function () {
  "use strict";

  var LOG_WRAP = "[VSP_TABS_WRAP]";
  var LOG_TABS2 = "[VSP_TABS2]";

  function logWrap() {
    if (typeof console !== "undefined" && console.log) {
      var args = Array.prototype.slice.call(arguments);
      args.unshift(LOG_WRAP);
      console.log.apply(console, args);
    }
  }

  function logTabs2() {
    if (typeof console !== "undefined" && console.log) {
      var args = Array.prototype.slice.call(arguments);
      args.unshift(LOG_TABS2);
      console.log.apply(console, args);
    }
  }

  function ensurePanes() {
    // Nếu đã có rồi thì thôi
    var existing = document.querySelectorAll(".vsp-tab-pane");
    if (existing.length) {
      logWrap("Found existing panes, skip autowrap. count =", existing.length);
      return;
    }

    var main = document.querySelector("main");
    if (!main) {
      logWrap("No <main> found – cannot autowrap.");
      return;
    }

    // Bọc main vào pane Dashboard
    var wrap = document.createElement("div");
    wrap.id = "vsp-tab-dashboard";
    wrap.className = "vsp-tab-pane vsp-tab-pane-active";

    main.parentNode.insertBefore(wrap, main);
    wrap.appendChild(main);

    // Tạo thêm 4 pane rỗng
    function addPane(id, text) {
      var pane = document.createElement("div");
      pane.id = id;
      pane.className = "vsp-tab-pane";
      var card = document.createElement("div");
      card.className = "vsp-card";
      var body = document.createElement("div");
      body.className = "vsp-card-body";
      body.textContent = text;
      card.appendChild(body);
      pane.appendChild(card);
      wrap.parentNode.insertBefore(pane, wrap.nextSibling);
      wrap = pane; // để nó nối tiếp nhau
    }

    addPane("vsp-tab-runs", "Runs & Reports tab V1 – content TODO.");
    addPane("vsp-tab-datasource", "Data Source tab V1 – content TODO.");
    addPane("vsp-tab-settings", "Settings tab V1 – content TODO.");
    addPane("vsp-tab-rules", "Rule Overrides tab V1 – content TODO.");

    var after = document.querySelectorAll(".vsp-tab-pane").length;
    logWrap("Created tab panes:", after);
  }

  function initTabs2() {
    var panes = document.querySelectorAll(".vsp-tab-pane");
    if (!panes.length) {
      logTabs2("No panes after autowrap – skip.");
      return;
    }

    var buttons = document.querySelectorAll("[data-vsp-tab-target]");
    if (!buttons.length) {
      logTabs2("No buttons with data-vsp-tab-target – skip.");
      return;
    }

    function showTab(targetSelector) {
      if (!targetSelector) return;
      var found = false;

      panes.forEach(function (pane) {
        if (pane.matches(targetSelector)) {
          pane.classList.add("vsp-tab-pane-active");
          pane.style.display = "";
          found = true;
        } else {
          pane.classList.remove("vsp-tab-pane-active");
          pane.style.display = "none";
        }
      });

      buttons.forEach(function (btn) {
        var sel = btn.getAttribute("data-vsp-tab-target");
        if (sel === targetSelector) {
          btn.classList.add("vsp-tab-link-active");
        } else {
          btn.classList.remove("vsp-tab-link-active");
        }
      });

      if (!found) {
        logTabs2("No pane matched selector:", targetSelector);
      } else {
        logTabs2("Switched to tab:", targetSelector);
      }
    }

    // Gắn click (thêm 1 listener nữa cũng không sao)
    buttons.forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        var sel = btn.getAttribute("data-vsp-tab-target");
        if (!sel) return;
        showTab(sel);
      });
    });

    var defaultSelector = "#vsp-tab-dashboard";
    if (window.location.hash && document.querySelector(window.location.hash)) {
      defaultSelector = window.location.hash;
    }
    showTab(defaultSelector);
    logTabs2("Initialized V2, default tab =", defaultSelector);

    window.vspTabsShow2 = showTab;
  }

  function runAll() {
    ensurePanes();
    initTabs2();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runAll);
  } else {
    runAll();
  }
})();

// [VSP_TABS_LAYOUT_V1]
(function () {
  "use strict";
  var LOG = "[VSP_TABS_LAYOUT]";

  function log() {
    if (typeof console !== "undefined" && console.log) {
      var args = Array.prototype.slice.call(arguments);
      args.unshift(LOG);
      console.log.apply(console, args);
    }
  }

  function setRunsLayout() {
    var root = document.getElementById("vsp-tab-runs");
    if (!root) {
      log("No #vsp-tab-runs, skip.");
      return;
    }
    if (root.dataset.vspLayout === "full") return;
    root.dataset.vspLayout = "full";

    root.innerHTML = [
      '<div class="vsp-two-col">',
      '  <div class="vsp-card">',
      '    <div class="vsp-card-header">',
      '      <div>',
      '        <div class="vsp-card-title">Runs &amp; Reports</div>',
      '        <div class="vsp-card-subtitle">Danh sách scan runs từ thư mục out/</div>',
      '      </div>',
      '    </div>',
      '    <div class="vsp-card-body">',
      '      <div class="vsp-filters-row">',
      '        <select id="vsp-runs-filter-profile" class="vsp-input">',
      '          <option value="">All profiles</option>',
      '          <option value="FAST">FAST</option>',
      '          <option value="EXT">EXT</option>',
      '          <option value="FULL">FULL</option>',
      '        </select>',
      '        <select id="vsp-runs-filter-severity" class="vsp-input">',
      '          <option value="">Any severity</option>',
      '          <option value="CRITICAL">CRITICAL</option>',
      '          <option value="HIGH">HIGH</option>',
      '          <option value="MEDIUM">MEDIUM</option>',
      '          <option value="LOW">LOW</option>',
      '        </select>',
      '        <input id="vsp-runs-filter-daterange" class="vsp-input" placeholder="Date range (optional)" />',
      '      </div>',
      '      <div class="vsp-table-wrapper">',
      '        <table class="vsp-table vsp-table-runs">',
      '          <thead>',
      '            <tr>',
      '              <th>Run ID</th>',
      '              <th>Profile</th>',
      '              <th>Posture</th>',
      '              <th>Total</th>',
      '              <th>Max severity</th>',
      '              <th>Started at</th>',
      '            </tr>',
      '          </thead>',
      '          <tbody id="vsp-runs-tbody"></tbody>',
      '        </table>',
      '      </div>',
      '    </div>',
      '  </div>',
      '  <div class="vsp-card vsp-card-side">',
      '    <div class="vsp-card-header vsp-card-header-actions">',
      '      <div>',
      '        <div class="vsp-card-title">Run detail</div>',
      '        <div class="vsp-card-subtitle">Posture / total / severity tối đa.</div>',
      '      </div>',
      '      <div class="vsp-card-actions">',
      '        <button id="vsp-run-export-html" class="vsp-chip-btn vsp-run-export-btn">Export HTML</button>',
      '        <button id="vsp-run-export-zip" class="vsp-chip-btn vsp-run-export-btn">Export ZIP</button>',
      '      </div>',
      '    </div>',
      '    <div class="vsp-card-body" id="vsp-run-detail"></div>',
      '  </div>',
      '</div>'
    ].join("");

    if (typeof window.vspReloadRuns === "function") {
      try {
        window.vspReloadRuns();
      } catch (e) {
        log("vspReloadRuns error:", e);
      }
    } else {
      log("window.vspReloadRuns not found – runs table sẽ được JS khác lo nếu có.");
    }
  }

  function setDataSourceLayout() {
    var root = document.getElementById("vsp-tab-datasource");
    if (!root) {
      log("No #vsp-tab-datasource, skip.");
      return;
    }
    if (root.dataset.vspLayout === "full") return;
    root.dataset.vspLayout = "full";

    root.innerHTML = [
      '<div id="vsp-ds-root" class="vsp-card">',
      '  <div class="vsp-card-header">',
      '    <div>',
      '      <div class="vsp-card-title">Unified Findings</div>',
      '      <div class="vsp-card-subtitle">Data source từ summary_unified / findings_unified.</div>',
      '    </div>',
      '    <div class="vsp-card-actions">',
      '      <button id="vsp-ds-reload" class="vsp-chip-btn">Reload</button>',
      '    </div>',
      '  </div>',
      '  <div class="vsp-card-body">',
      '    <div class="vsp-filters-row">',
      '      <select id="vsp-ds-filter-severity" class="vsp-input">',
      '        <option value="">Severity: Any</option>',
      '        <option value="CRITICAL">CRITICAL</option>',
      '        <option value="HIGH">HIGH</option>',
      '        <option value="MEDIUM">MEDIUM</option>',
      '        <option value="LOW">LOW</option>',
      '        <option value="INFO">INFO</option>',
      '        <option value="TRACE">TRACE</option>',
      '      </select>',
      '      <select id="vsp-ds-filter-tool" class="vsp-input">',
      '        <option value="">Tool: Any</option>',
      '        <option value="semgrep">Semgrep</option>',
      '        <option value="bandit">Bandit</option>',
      '        <option value="codeql">CodeQL</option>',
      '        <option value="trivy">Trivy</option>',
      '        <option value="grype">Grype</option>',
      '        <option value="kics">KICS</option>',
      '        <option value="gitleaks">Gitleaks</option>',
      '      </select>',
      '      <input id="vsp-ds-filter-text" class="vsp-input" placeholder="Search message / path / CWE..." />',
      '    </div>',
      '    <div class="vsp-table-wrapper vsp-table-wrapper-ds">',
      '      <table class="vsp-table vsp-table-ds">',
      '        <thead>',
      '          <tr>',
      '            <th>Severity</th>',
      '            <th>Tool</th>',
      '            <th>CWE</th>',
      '            <th>Rule</th>',
      '            <th>Path</th>',
      '            <th>Line</th>',
      '            <th>Message</th>',
      '            <th>Run</th>',
      '          </tr>',
      '        </thead>',
      '        <tbody id="vsp-ds-tbody"></tbody>',
      '      </table>',
      '    </div>',
      '    <div class="vsp-ds-pager">',
      '      <button id="vsp-ds-prev" class="vsp-chip-btn">Prev</button>',
      '      <span id="vsp-ds-page-info" class="vsp-ds-page-info">Page 1</span>',
      '      <button id="vsp-ds-next" class="vsp-chip-btn">Next</button>',
      '    </div>',
      '  </div>',
      '</div>'
    ].join("");

    log("Data Source layout ready (chưa gắn API – sẽ làm V2).");
  }

  function setSettingsLayout() {
    var root = document.getElementById("vsp-tab-settings");
    if (!root) {
      log("No #vsp-tab-settings, skip.");
      return;
    }
    if (root.dataset.vspLayout === "full") return;
    root.dataset.vspLayout = "full";

    root.innerHTML = [
      '<div id="vsp-settings-root" class="vsp-card">',
      '  <div class="vsp-card-header">',
      '    <div>',
      '      <div class="vsp-card-title">Profiles &amp; Tools</div>',
      '      <div class="vsp-card-subtitle">settings_v1 – profiles, tool toggles, default profile.</div>',
      '    </div>',
      '    <div class="vsp-card-actions">',
      '      <button id="vsp-settings-reload" class="vsp-chip-btn">Reload</button>',
      '      <button id="vsp-settings-save" class="vsp-chip-btn">Save</button>',
      '    </div>',
      '  </div>',
      '  <div class="vsp-card-body">',
      '    <textarea id="vsp-settings-json" class="vsp-json-editor" spellcheck="false"></textarea>',
      '    <div id="vsp-settings-status" class="vsp-status-line"></div>',
      '  </div>',
      '</div>'
    ].join("");

    if (!window.vspInitSettingsTab) {
      window.vspInitSettingsTab = function () {
        console.log("[VSP_SETTINGS_TAB] stub init – UI only (chưa gắn API).");
      };
    }
  }

  function setRulesLayout() {
    var root = document.getElementById("vsp-tab-rules");
    if (!root) {
      log("No #vsp-tab-rules, skip.");
      return;
    }
    if (root.dataset.vspLayout === "full") return;
    root.dataset.vspLayout = "full";

    root.innerHTML = [
      '<div id="vsp-rules-root" class="vsp-card">',
      '  <div class="vsp-card-header">',
      '    <div>',
      '      <div class="vsp-card-title">Rule Overrides</div>',
      '      <div class="vsp-card-subtitle">Override severity / pattern cho từng tool – rule_overrides_v1.</div>',
      '    </div>',
      '    <div class="vsp-card-actions">',
      '      <button id="vsp-rules-reload" class="vsp-chip-btn">Reload</button>',
      '      <button id="vsp-rules-save" class="vsp-chip-btn">Save</button>',
      '    </div>',
      '  </div>',
      '  <div class="vsp-card-body">',
      '    <div class="vsp-two-col">',
      '      <div>',
      '        <div class="vsp-section-title">Danh sách overrides</div>',
      '        <div class="vsp-table-wrapper vsp-table-wrapper-rules">',
      '          <table class="vsp-table vsp-table-rules">',
      '            <thead>',
      '              <tr>',
      '                <th>ID</th>',
      '                <th>Tool</th>',
      '                <th>Pattern</th>',
      '                <th>Severity</th>',
      '                <th>Reason</th>',
      '              </tr>',
      '            </thead>',
      '            <tbody id="vsp-rules-tbody">',
      '              <tr><td colspan="5">V1 – chưa load dữ liệu.</td></tr>',
      '            </tbody>',
      '          </table>',
      '        </div>',
      '      </div>',
      '      <div>',
      '        <div class="vsp-section-title">JSON rule_overrides_v1</div>',
      '        <textarea id="vsp-rules-json" class="vsp-json-editor" spellcheck="false"></textarea>',
      '        <div id="vsp-rules-status" class="vsp-status-line"></div>',
      '      </div>',
      '    </div>',
      '  </div>',
      '</div>'
    ].join("");

    log("Rule Overrides layout ready (V1, chưa gắn API).");
  }

  function run() {
    setRunsLayout();
    setDataSourceLayout();
    setSettingsLayout();
    setRulesLayout();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", run);
  } else {
    run();
  }
})();

// [VSP_TABS_API_V1]
(function () {
  "use strict";
  var LOG_DS = "[VSP_DS_API]";
  var LOG_SET = "[VSP_SETTINGS_API]";
  var LOG_RULE = "[VSP_RULES_API]";

  function logDs() {
    if (console && console.log) {
      var args = Array.prototype.slice.call(arguments);
      args.unshift(LOG_DS);
      console.log.apply(console, args);
    }
  }
  function logSet() {
    if (console && console.log) {
      var args = Array.prototype.slice.call(arguments);
      args.unshift(LOG_SET);
      console.log.apply(console, args);
    }
  }
  function logRule() {
    if (console && console.log) {
      var args = Array.prototype.slice.call(arguments);
      args.unshift(LOG_RULE);
      console.log.apply(console, args);
    }
  }

  // ---- Data Source /api/vsp/datasource_v2 ----
  function initDataSourceApi() {
    var root = document.getElementById("vsp-ds-root");
    if (!root) {
      logDs("No #vsp-ds-root – skip.");
      return;
    }

    var tbody = document.getElementById("vsp-ds-tbody");
    var selSeverity = document.getElementById("vsp-ds-filter-severity");
    var selTool = document.getElementById("vsp-ds-filter-tool");
    var txtSearch = document.getElementById("vsp-ds-filter-text");
    var btnReload = document.getElementById("vsp-ds-reload");
    var btnPrev = document.getElementById("vsp-ds-prev");
    var btnNext = document.getElementById("vsp-ds-next");
    var lblPage = document.getElementById("vsp-ds-page-info");

    if (!tbody) {
      logDs("Missing tbody #vsp-ds-tbody – skip.");
      return;
    }

    var state = {
      page: 1,
      pageSize: 50,
      total: 0,
      severity: "",
      tool: "",
      q: ""
    };

    function buildUrl() {
      var params = new URLSearchParams();
      if (state.severity) params.set("severity", state.severity);
      if (state.tool) params.set("tool", state.tool);
      if (state.q) params.set("q", state.q);
      params.set("limit", String(state.pageSize));
      params.set("page", String(state.page));
      return "/api/vsp/datasource_v2?" + params.toString();
    }

    function render(data) {
      var items = [];
      if (Array.isArray(data)) {
        items = data;
      } else if (data && Array.isArray(data.items)) {
        items = data.items;
        if (typeof data.total === "number") {
          state.total = data.total;
        }
      }

      tbody.innerHTML = "";
      if (!items.length) {
        var tr = document.createElement("tr");
        var td = document.createElement("td");
        td.colSpan = 8;
        td.textContent = "Không có findings nào (filter quá chặt?).";
        tr.appendChild(td);
        tbody.appendChild(tr);
      } else {
        items.forEach(function (it) {
          var tr = document.createElement("tr");
          function td(text) {
            var c = document.createElement("td");
            c.textContent = text == null ? "" : String(text);
            tr.appendChild(c);
          }

          var sev = it.severity_effective || it.severity || "";
          var tool = it.tool || it.source || "";
          var cwe = it.cwe_id || it.cwe || "";
          var rule = it.rule_id || it.rule || it.check_id || "";
          var path = it.path || it.file || "";
          var line = it.line || it.start_line || "";
          var msg = it.message || it.title || "";
          var run = it.run_id || (data && data.run_id) || "";

          td(sev);
          td(tool);
          td(cwe);
          td(rule);
          td(path);
          td(line);
          td(msg);
          td(run);

          tbody.appendChild(tr);
        });
      }

      var pageInfo = "Page " + state.page;
      if (state.total && state.pageSize) {
        var pages = Math.ceil(state.total / state.pageSize);
        pageInfo = "Page " + state.page + " / " + pages + " (" + state.total + " items)";
      }
      if (lblPage) lblPage.textContent = pageInfo;
    }

    function loadData() {
      var url = buildUrl();
      logDs("Loading", url);
      fetch(url)
        .then(function (res) {
          if (!res.ok) throw new Error("HTTP " + res.status);
          return res.json();
        })
        .then(function (data) {
          logDs("Loaded", data);
          render(data);
        })
        .catch(function (err) {
          logDs("Error", err);
          tbody.innerHTML = "";
          var tr = document.createElement("tr");
          var td = document.createElement("td");
          td.colSpan = 8;
          td.textContent = "Error loading datasource_v2: " + err;
          tr.appendChild(td);
          tbody.appendChild(tr);
        });
    }

    function resetPageAndLoad() {
      state.page = 1;
      loadData();
    }

    if (selSeverity) {
      selSeverity.addEventListener("change", function () {
        state.severity = selSeverity.value || "";
        resetPageAndLoad();
      });
    }
    if (selTool) {
      selTool.addEventListener("change", function () {
        state.tool = selTool.value || "";
        resetPageAndLoad();
      });
    }
    if (txtSearch) {
      txtSearch.addEventListener("keyup", function (e) {
        if (e.key === "Enter") {
          state.q = txtSearch.value || "";
          resetPageAndLoad();
        }
      });
    }
    if (btnReload) {
      btnReload.addEventListener("click", function () {
        resetPageAndLoad();
      });
    }
    if (btnPrev) {
      btnPrev.addEventListener("click", function () {
        if (state.page > 1) {
          state.page -= 1;
          loadData();
        }
      });
    }
    if (btnNext) {
      btnNext.addEventListener("click", function () {
        state.page += 1;
        loadData();
      });
    }

    resetPageAndLoad();
  }

  // ---- Settings /api/vsp/settings_ui_v1 ----
  function initSettingsApi() {
    var root = document.getElementById("vsp-settings-root");
    if (!root) {
      logSet("No #vsp-settings-root – skip.");
      return;
    }

    var txt = document.getElementById("vsp-settings-json");
    var btnReload = document.getElementById("vsp-settings-reload");
    var btnSave = document.getElementById("vsp-settings-save");
    var status = document.getElementById("vsp-settings-status");

    if (!txt) {
      logSet("Missing #vsp-settings-json – skip.");
      return;
    }

    function showStatus(msg, isErr) {
      if (!status) return;
      status.textContent = msg;
      status.style.color = isErr ? "#f97373" : "rgba(148,163,184,0.9)";
    }

    function reloadSettings() {
      showStatus("Loading settings_v1 ...");
      fetch("/api/vsp/settings_ui_v1")
        .then(function (res) {
          if (!res.ok) throw new Error("HTTP " + res.status);
          return res.json();
        })
        .then(function (data) {
          txt.value = JSON.stringify(data, null, 2);
          showStatus("Loaded settings_v1.");
          logSet("Loaded", data);
        })
        .catch(function (err) {
          logSet("Error", err);
          showStatus("Error loading settings_v1: " + err, true);
        });
    }

    function saveSettings() {
      var raw = txt.value;
      var parsed;
      try {
        parsed = JSON.parse(raw);
      } catch (e) {
        showStatus("JSON không hợp lệ: " + e.message, true);
        return;
      }
      showStatus("Saving settings_v1 ...");
      fetch("/api/vsp/settings_ui_v1", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(parsed)
      })
        .then(function (res) {
          if (!res.ok) throw new Error("HTTP " + res.status);
          return res.json();
        })
        .then(function (data) {
          showStatus("Saved settings_v1.");
          logSet("Saved", data);
        })
        .catch(function (err) {
          logSet("Save error", err);
          showStatus("Error saving settings_v1: " + err, true);
        });
    }

    if (btnReload) btnReload.addEventListener("click", reloadSettings);
    if (btnSave) btnSave.addEventListener("click", saveSettings);

    // load lần đầu
    reloadSettings();
  }

  // ---- Rule Overrides /api/vsp/rule_overrides_ui_v1 ----
  function initRulesApi() {
    var root = document.getElementById("vsp-rules-root");
    if (!root) {
      logRule("No #vsp-rules-root – skip.");
      return;
    }

    var txt = document.getElementById("vsp-rules-json");
    var tbody = document.getElementById("vsp-rules-tbody");
    var btnReload = document.getElementById("vsp-rules-reload");
    var btnSave = document.getElementById("vsp-rules-save");
    var status = document.getElementById("vsp-rules-status");

    if (!txt || !tbody) {
      logRule("Missing textarea or tbody – skip.");
      return;
    }

    function showStatus(msg, isErr) {
      if (!status) return;
      status.textContent = msg;
      status.style.color = isErr ? "#f97373" : "rgba(148,163,184,0.9)";
    }

    function renderTable(data) {
      var list = [];
      if (Array.isArray(data)) {
        list = data;
      } else if (data && Array.isArray(data.items)) {
        list = data.items;
      }

      tbody.innerHTML = "";
      if (!list.length) {
        var tr = document.createElement("tr");
        var td = document.createElement("td");
        td.colSpan = 5;
        td.textContent = "Không có rule override nào.";
        tr.appendChild(td);
        tbody.appendChild(tr);
        return;
      }

      list.forEach(function (it) {
        var tr = document.createElement("tr");
        function td(text) {
          var c = document.createElement("td");
          c.textContent = text == null ? "" : String(text);
          tr.appendChild(c);
        }
        td(it.id || it.rule_id || "");
        td(it.tool || "");
        td(it.pattern || "");
        td(it.severity_effective || it.severity || "");
        td(it.reason || "");
        tbody.appendChild(tr);
      });
    }

    function reloadRules() {
      showStatus("Loading rule_overrides_v1 ...");
      fetch("/api/vsp/rule_overrides_ui_v1")
        .then(function (res) {
          if (!res.ok) throw new Error("HTTP " + res.status);
          return res.json();
        })
        .then(function (data) {
          txt.value = JSON.stringify(data, null, 2);
          renderTable(data);
          showStatus("Loaded rule_overrides_v1.");
          logRule("Loaded", data);
        })
        .catch(function (err) {
          logRule("Error", err);
          showStatus("Error loading rule_overrides_v1: " + err, true);
        });
    }

    function saveRules() {
      var raw = txt.value;
      var parsed;
      try {
        parsed = JSON.parse(raw);
      } catch (e) {
        showStatus("JSON không hợp lệ: " + e.message, true);
        return;
      }
      showStatus("Saving rule_overrides_v1 ...");
      fetch("/api/vsp/rule_overrides_ui_v1", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(parsed)
      })
        .then(function (res) {
          if (!res.ok) throw new Error("HTTP " + res.status);
          return res.json();
        })
        .then(function (data) {
          showStatus("Saved rule_overrides_v1.");
          renderTable(data);
          logRule("Saved", data);
        })
        .catch(function (err) {
          logRule("Save error", err);
          showStatus("Error saving rule_overrides_v1: " + err, true);
        });
    }

    if (btnReload) btnReload.addEventListener("click", reloadRules);
    if (btnSave) btnSave.addEventListener("click", saveRules);

    reloadRules();
  }

  function runAll() {
    initDataSourceApi();
    initSettingsApi();
    initRulesApi();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runAll);
  } else {
    runAll();
  }
})();


;(function () {
  const LOG_PREFIX = "[VSP_CONSOLE_EXTRA]";
  const extraScripts = [
    "vsp_runs_tab_kpi_inject_v1.js",
    "vsp_datasource_ext_columns_v1.js",
    "vsp_datasource_export_v1.js",
    "vsp_datasource_charts_v1.js",
    "vsp_settings_tab_v1.js",
    "vsp_rules_tab_v1.js",
    "vsp_runs_fullscan_panel_v1.js"
  ];

  function loadExtra(name) {
    try {
      var url = "/static/js/" + name;
      var s = document.createElement("script");
      s.src = url;
      s.defer = true;
      s.onload = function () {
        try {
          console.log(LOG_PREFIX, "loaded", name);
        } catch (e) {}
      };
      s.onerror = function () {
        try {
          console.warn(LOG_PREFIX, "failed", name);
        } catch (e) {}
      };
      document.head.appendChild(s);
    } catch (e) {
      try {
        console.error(LOG_PREFIX, "error injecting", name, e);
      } catch (e2) {}
    }
  }

  if (typeof window !== "undefined" && document && document.head) {
    extraScripts.forEach(loadExtra);
  } else {
    try {
      console.warn(LOG_PREFIX, "document/head chưa sẵn sàng – skip extra scripts.");
    } catch (e) {}
  }
})();



// === VSP_DS_HEIGHT_FIX_V1 – limit Data Source charts height ===
(function() {
  if (window.VSP_DS_HEIGHT_FIX_V1) return;
  window.VSP_DS_HEIGHT_FIX_V1 = true;
  const LOG = "[VSP_DS_HEIGHT_FIX]";

  function shrinkDsCharts() {
    try {
      const tab = document.querySelector("#vsp-tab-datasource");
      if (!tab) return;
      const canvases = tab.querySelectorAll("canvas");
      if (!canvases.length) return;
      canvases.forEach(cv => {
        cv.style.height = "260px";
        cv.style.maxHeight = "260px";
      });
      console.log(LOG, "Applied height=260px to", canvases.length, "canvas elements.");
    } catch (e) {
      console.warn(LOG, "Error while shrinking charts:", e);
    }
  }

  // Gọi 1 lần khi load
  if (document.readyState === "complete" || document.readyState === "interactive") {
    shrinkDsCharts();
  } else {
    document.addEventListener("DOMContentLoaded", shrinkDsCharts);
  }

  // Dùng MutationObserver để bắt mọi lần Data Source render lại chart
  try {
    const obs = new MutationObserver(() => shrinkDsCharts());
    obs.observe(document.documentElement, { childList: true, subtree: true });
    console.log(LOG, "MutationObserver attached.");
  } catch (e) {
    console.warn(LOG, "Cannot attach MutationObserver:", e);
    // fallback: thỉnh thoảng thu nhỏ lại
    setInterval(shrinkDsCharts, 1500);
  }
})();


// === VSP_DS_HEIGHT_FIX_V2 – stronger override for Data Source charts ===
(function() {
  if (window.VSP_DS_HEIGHT_FIX_V2) return;
  window.VSP_DS_HEIGHT_FIX_V2 = true;
  const LOG = "[VSP_DS_HEIGHT_FIX_V2]";

  function hardShrinkDsCharts() {
    const tab = document.querySelector("#vsp-tab-datasource");
    if (!tab) return;

    const canvases = tab.querySelectorAll("canvas");
    if (!canvases.length) return;

    canvases.forEach(cv => {
      try {
        // Ép height canvas
        cv.style.setProperty("height", "220px", "important");
        cv.style.setProperty("max-height", "220px", "important");
        cv.height = 220;

        // Ép container trực tiếp
        const parent = cv.parentElement;
        if (parent) {
          parent.style.setProperty("height", "230px", "important");
          parent.style.setProperty("max-height", "230px", "important");
          parent.style.overflow = "hidden";
        }

        // Ép card/wrapper lớn quanh chart
        const card = cv.closest(".vsp-card") || cv.closest(".card") || cv.closest(".panel");
        if (card) {
          card.style.setProperty("max-height", "280px", "important");
          card.style.overflow = "hidden";
        }
      } catch (e) {
        console.warn(LOG, "Error shrink chart:", e);
      }
    });

    console.log(LOG, "Hard shrink applied to", canvases.length, "canvas elements.");
  }

  // Gọi khi document sẵn sàng
  if (document.readyState === "complete" || document.readyState === "interactive") {
    hardShrinkDsCharts();
  } else {
    document.addEventListener("DOMContentLoaded", hardShrinkDsCharts);
  }

  // Observer mọi thay đổi để luôn ép lại khi Chart.js re-render
  try {
    const obs = new MutationObserver(() => hardShrinkDsCharts());
    obs.observe(document.querySelector("#vsp-tab-datasource") || document.body, {
      childList: true,
      subtree: true
    });
    console.log(LOG, "MutationObserver attached.");
  } catch (e) {
    console.warn(LOG, "Cannot attach MutationObserver:", e);
    setInterval(hardShrinkDsCharts, 1500);
  }
})();

/* VSP_RUNS_LAYOUT_HELPER_V1
 * Tự động load vsp_runs_overview_layout_v1.js từ console patch.
 */
(function(){
  try {
    var s = document.createElement('script');
    s.src = '/static/js/vsp_runs_overview_layout_v1.js';
    s.defer = true;
    document.head.appendChild(s);
    console.log('[VSP_RUNS_LAYOUT] helper script injected from console patch.');
  } catch (e) {
    console.warn('[VSP_RUNS_LAYOUT] cannot inject layout script:', e);
  }
})();

// [VSP_RUN_FULLSCAN_REBIND] allow EXT_ONLY / URL_ONLY / FULL_EXT
(function() {
  function rebindRunFullscan() {
    var btn = document.querySelector('#vsp-run-fullscan-btn');
    if (!btn) {
      console.log('[VSP_RUN_FULLSCAN_REBIND] Không thấy nút #vsp-run-fullscan-btn');
      return;
    }

    // Chỉ bind 1 lần
    if (btn.dataset.vspRunRebound === '1') {
      console.log('[VSP_RUN_FULLSCAN_REBIND] Đã bind trước đó, skip.');
      return;
    }

    // Clone để xoá hết event listener cũ
    var newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
    newBtn.dataset.vspRunRebound = '1';

    var inputRoot  = document.querySelector('#vsp-source-root');
    var inputUrl   = document.querySelector('#vsp-target-url');
    var selProfile = document.querySelector('#vsp-profile');

    newBtn.addEventListener('click', function() {
      var sourceRoot = (inputRoot && inputRoot.value || '').trim();
      var targetUrl  = (inputUrl  && inputUrl.value  || '').trim();
      var profile    = (selProfile && selProfile.value || '').trim() || 'FULL_EXT';

      // Rule: phải có ÍT NHẤT 1 trong 2
      if (!sourceRoot && !targetUrl) {
        window.alert('Vui lòng nhập ít nhất Source root hoặc Target URL.');
        return;
      }

      var mode;
      if (sourceRoot && targetUrl) {
        mode = 'FULL_EXT';
      } else if (sourceRoot && !targetUrl) {
        mode = 'EXT_ONLY';
      } else {
        mode = 'URL_ONLY';
      }

      var payload = {
        source_root: sourceRoot || null,
        target_url:  targetUrl  || null,
        profile: profile,
        mode: mode
      };

      console.log('[VSP_RUN_FULLSCAN_REBIND] payload', payload);

      fetch('/api/vsp/run_fullscan_v1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      .then(function(r) { return r.json(); })
      .then(function(data) {
        console.log('[VSP_RUN_FULLSCAN_REBIND] resp', data);
        if (!data.ok) {
          window.alert('Run full scan failed: ' + (data.error || 'unknown error'));
        }
      })
      .catch(function(err) {
        console.error('[VSP_RUN_FULLSCAN_REBIND] error', err);
        window.alert('Có lỗi khi gửi yêu cầu run full scan.');
      });
    });

    console.log('[VSP_RUN_FULLSCAN_REBIND] Đã bind lại nút Run full scan.');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', rebindRunFullscan);
  } else {
    rebindRunFullscan();
  }
})();

// [VSP_RUN_FULLSCAN_REBIND_POLL] rebind nút Run full scan sau khi panel được inject
(function() {
  console.log('[VSP_RUN_FULLSCAN_REBIND_POLL] start');

  var tries = 0;
  var maxTries = 30; // ~6s nếu interval = 200ms

  var timer = setInterval(function() {
    tries += 1;

    var btn = document.querySelector('#vsp-run-fullscan-btn');
    if (!btn) {
      if (tries >= maxTries) {
        console.warn('[VSP_RUN_FULLSCAN_REBIND_POLL] Hết số lần thử, không thấy nút.');
        clearInterval(timer);
      }
      return;
    }

    if (btn.dataset.vspRunRebound === '1') {
      console.log('[VSP_RUN_FULLSCAN_REBIND_POLL] Nút đã được bind trước đó, dừng poll.');
      clearInterval(timer);
      return;
    }

    // Clone để xoá toàn bộ listener cũ (bao gồm alert "Vui lòng nhập Target URL")
    var newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
    newBtn.dataset.vspRunRebound = '1';

    var inputRoot  = document.querySelector('#vsp-source-root');
    var inputUrl   = document.querySelector('#vsp-target-url');
    var selProfile = document.querySelector('#vsp-profile');

    newBtn.addEventListener('click', function() {
      var sourceRoot = (inputRoot && inputRoot.value || '').trim();
      var targetUrl  = (inputUrl  && inputUrl.value  || '').trim();
      var profile    = (selProfile && selProfile.value || '').trim() || 'FULL_EXT';

      if (!sourceRoot && !targetUrl) {
        window.alert('Vui lòng nhập ít nhất Source root hoặc Target URL.');
        return;
      }

      var mode;
      if (sourceRoot && targetUrl) {
        mode = 'FULL_EXT';
      } else if (sourceRoot && !targetUrl) {
        mode = 'EXT_ONLY';
      } else {
        mode = 'URL_ONLY';
      }

      var payload = {
        source_root: sourceRoot || null,
        target_url:  targetUrl  || null,
        profile: profile,
        mode: mode
      };

      console.log('[VSP_RUN_FULLSCAN_REBIND_POLL] payload', payload);

      fetch('/api/vsp/run_fullscan_v1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      .then(function(r) { return r.json(); })
      .then(function(data) {
        console.log('[VSP_RUN_FULLSCAN_REBIND_POLL] resp', data);
        if (!data.ok) {
          window.alert('Run full scan failed: ' + (data.error || 'unknown error'));
        }
      })
      .catch(function(err) {
        console.error('[VSP_RUN_FULLSCAN_REBIND_POLL] error', err);
        window.alert('Có lỗi khi gửi yêu cầu run full scan.');
      });
    });

    console.log('[VSP_RUN_FULLSCAN_REBIND_POLL] Đã bind lại nút Run full scan.');
    clearInterval(timer);
  }, 200);
})();
// [VSP_RUN_FULLSCAN_REBIND_POLL_V3] rebind nút Run full scan sau khi panel được inject
(function() {
  console.log('[VSP_RUN_FULLSCAN_REBIND_POLL_V3] start');

  var tries = 0;
  var maxTries = 30; // ~6s nếu interval 200ms

  var timer = setInterval(function() {
    tries += 1;

    var btn = document.querySelector('#vsp-run-fullscan-btn');
    if (!btn) {
      if (tries >= maxTries) {
        console.warn('[VSP_RUN_FULLSCAN_REBIND_POLL_V3] Hết số lần thử, không thấy nút.');
        clearInterval(timer);
      }
      return;
    }

    if (btn.dataset.vspRunReboundV3 === '1') {
      console.log('[VSP_RUN_FULLSCAN_REBIND_POLL_V3] Nút đã được bind V3, dừng poll.');
      clearInterval(timer);
      return;
    }

    // Clone để xoá mọi listener cũ (bao gồm alert cũ)
    var newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
    newBtn.dataset.vspRunReboundV3 = '1';

    console.log('[VSP_RUN_FULLSCAN_REBIND_POLL_V3] Đã clone nút Run full scan.');

    newBtn.addEventListener('click', function() {
      // Lấy input trong cùng card/panel với nút
      var card = newBtn.closest('.vsp-card') || newBtn.closest('section') || document;
      var inputs = card.querySelectorAll('input');

      var sourceRoot = inputs[0] ? (inputs[0].value || '').trim() : '';
      var targetUrl  = inputs[1] ? (inputs[1].value || '').trim() : '';

      var profileSel = card.querySelector('select');
      var profile = profileSel && profileSel.value ? profileSel.value.trim() : 'FULL_EXT';

      console.log('[VSP_RUN_FULLSCAN_REBIND_POLL_V3] current values', {
        sourceRoot: sourceRoot,
        targetUrl: targetUrl,
        profile: profile
      });

      if (!sourceRoot && !targetUrl) {
        window.alert('Vui lòng nhập ít nhất Source root hoặc Target URL.');
        return;
      }

      var mode;
      if (sourceRoot && targetUrl) {
        mode = 'FULL_EXT';
      } else if (sourceRoot && !targetUrl) {
        mode = 'EXT_ONLY';
      } else {
        mode = 'URL_ONLY';
      }

      var payload = {
        source_root: sourceRoot || null,
        target_url:  targetUrl  || null,
        profile: profile,
        mode: mode
      };

      console.log('[VSP_RUN_FULLSCAN_REBIND_POLL_V3] payload', payload);

      fetch('/api/vsp/run_fullscan_v1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      .then(function(r) { return r.json(); })
      .then(function(data) {
        console.log('[VSP_RUN_FULLSCAN_REBIND_POLL_V3] resp', data);
        if (!data.ok) {
          window.alert('Run full scan failed: ' + (data.error || 'unknown error'));
        }
      })
      .catch(function(err) {
        console.error('[VSP_RUN_FULLSCAN_REBIND_POLL_V3] error', err);
        window.alert('Có lỗi khi gửi yêu cầu run full scan.');
      });
    });

    console.log('[VSP_RUN_FULLSCAN_REBIND_POLL_V3] Đã bind lại nút Run full scan.');
    clearInterval(timer);
  }, 200);
})();
// [VSP_RUN_FULLSCAN_CAPTURE_V1] Override click Run full scan (EXT_ONLY / URL_ONLY / FULL_EXT)
(function() {
  console.log('[VSP_RUN_FULLSCAN_CAPTURE_V1] start');

  function bindRunFullscanCapture() {
    var btn = document.querySelector('#vsp-run-fullscan-btn');
    if (!btn) {
      return;
    }
    if (btn.dataset.vspRunCaptureBound === '1') {
      return;
    }
    btn.dataset.vspRunCaptureBound = '1';

    console.log('[VSP_RUN_FULLSCAN_CAPTURE_V1] Bind capture listener cho nút Run full scan.');

    btn.addEventListener('click', function(ev) {
      // Chặn toàn bộ handler cũ (bao gồm alert "Vui lòng nhập Target URL.")
      ev.preventDefault();
      ev.stopImmediatePropagation();

      var card = btn.closest('.vsp-card') || btn.closest('section') || document;
      var inputs = card.querySelectorAll('input');

      var sourceRoot = inputs[0] ? (inputs[0].value || '').trim() : '';
      var targetUrl  = inputs[1] ? (inputs[1].value || '').trim() : '';

      var profileSel = card.querySelector('select');
      var profile = profileSel && profileSel.value ? profileSel.value.trim() : 'FULL_EXT';

      console.log('[VSP_RUN_FULLSCAN_CAPTURE_V1] values', {
        sourceRoot: sourceRoot,
        targetUrl: targetUrl,
        profile: profile
      });

      if (!sourceRoot && !targetUrl) {
        window.alert('Vui lòng nhập ít nhất Source root hoặc Target URL.');
        return;
      }

      var mode;
      if (sourceRoot && targetUrl) {
        mode = 'FULL_EXT';
      } else if (sourceRoot && !targetUrl) {
        mode = 'EXT_ONLY';
      } else {
        mode = 'URL_ONLY';
      }

      var payload = {
        source_root: sourceRoot || null,
        target_url:  targetUrl  || null,
        profile: profile,
        mode: mode
      };

      console.log('[VSP_RUN_FULLSCAN_CAPTURE_V1] payload', payload);

      fetch('/api/vsp/run_fullscan_v1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      .then(function(r) { return r.json(); })
      .then(function(data) {
        console.log('[VSP_RUN_FULLSCAN_CAPTURE_V1] resp', data);
        if (!data.ok) {
          window.alert('Run full scan failed: ' + (data.error || 'unknown error'));
        }
      })
      .catch(function(err) {
        console.error('[VSP_RUN_FULLSCAN_CAPTURE_V1] error', err);
        window.alert('Có lỗi khi gửi yêu cầu run full scan.');
      });
    }, true); // <= CAPTURE = true
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      setTimeout(bindRunFullscanCapture, 800);
    });
  } else {
    setTimeout(bindRunFullscanCapture, 800);
  }

  // Phòng trường hợp panel inject muộn
  var tries = 0;
  var maxTries = 30;
  var timer = setInterval(function() {
    tries += 1;
    bindRunFullscanCapture();
    if (tries >= maxTries) {
      clearInterval(timer);
    }
  }, 200);
})();


// [VSP_CI_GATE_WIDGET] auto load CI gate widget
(function() {
  try {
    console.log("[VSP_CI_GATE_WIDGET] injecting widget script");
    var s = document.createElement("script");
    s.src = "/static/js/vsp_ci_gate_widget_v1.js";
    s.defer = true;
    document.head.appendChild(s);
  } catch (e) {
    console.error("[VSP_CI_GATE_WIDGET] failed to inject widget:", e);
  }
})();



// [VSP_DASH_ENHANCE] load dashboard enhancement script
(function() {
  try {
    console.log("[VSP_DASH_ENHANCE] injecting script");
    var s = document.createElement("script");
    s.src = "/static/js/vsp_dashboard_enhance_v1.js";
    s.defer = true;
    document.head.appendChild(s);
  } catch (e) {
    console.error("[VSP_DASH_ENHANCE] failed to inject:", e);
  }
})();


// [VSP_DASH_DELTA_INLINE_v1] Hiển thị Δ Findings bên cạnh label "Charts"
(function () {
  const LOG = (...args) => console.log("[VSP_DASH_DELTA_INLINE]", ...args);

  function onReady(fn) {
    if (document.readyState === "complete" || document.readyState === "interactive") {
      fn();
    } else {
      document.addEventListener("DOMContentLoaded", fn, { once: true });
    }
  }

  async function fetchDelta() {
    try {
      const res = await fetch("/api/vsp/dashboard_delta_latest", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error", res.status);
        return;
      }
      const data = await res.json();
      if (!data || !data.ok || !data.current || !data.previous) {
        LOG("Không đủ dữ liệu delta", data);
        return;
      }
      injectDelta(data);
    } catch (e) {
      LOG("Exception khi gọi dashboard_delta_latest:", e);
    }
  }

  function injectDelta(data) {
    const current = data.current || {};
    const previous = data.previous || {};

    const curTot = typeof current.total_findings === "number" ? current.total_findings : null;
    const prevTot = typeof previous.total_findings === "number" ? previous.total_findings : null;

    if (curTot === null || prevTot === null) {
      LOG("Thiếu total_findings trong current/previous", { current, previous });
      return;
    }

    const diff = curTot - prevTot;
    const cls =
      diff > 0 ? "vsp-delta-up" :
      diff < 0 ? "vsp-delta-down" :
                 "vsp-delta-flat";

    const diffStr = diff > 0 ? `+${diff}` : `${diff}`;

    const root = document.querySelector("#vsp-dashboard-root") || document;
    if (!root) {
      LOG("Không tìm thấy #vsp-dashboard-root");
      return;
    }

    // Tìm node text "Charts" trong dashboard
    const labels = Array.from(root.querySelectorAll("*")).filter((el) => {
      if (el.childElementCount !== 0) return false;
      const txt = (el.textContent || "").trim();
      return txt === "Charts";
    });

    if (!labels.length) {
      LOG("Không tìm thấy label 'Charts' để chèn delta");
      return;
    }

    const chartsLabel = labels[0];
    if (chartsLabel.querySelector(".vsp-dash-delta-inline")) {
      LOG("Delta đã được chèn trước đó, bỏ qua.");
      return;
    }

    const span = document.createElement("span");
    span.className = "vsp-dash-delta-inline";
    span.innerHTML =
      '<span class="vsp-dash-delta-label"> · Δ Findings </span>' +
      `<span class="vsp-dash-delta-val ${cls}">${diffStr}</span>` +
      `<span class="vsp-dash-delta-runs"> (${curTot} vs ${prevTot})</span>`;

    chartsLabel.appendChild(span);

    LOG(
      "Injected delta:",
      diffStr,
      " (",
      curTot,
      "vs",
      prevTot,
      ") current:",
      current.run_id,
      "previous:",
      previous.run_id
    );
  }

  onReady(fetchDelta);
})();

// [VSP_KPI_SCORE_DELTA_v1] Hiển thị Δ Security Score trong card KPI
(function () {
  const LOG = (...args) => console.log("[VSP_KPI_SCORE_DELTA]", ...args);

  function onReady(fn) {
    if (document.readyState === "complete" || document.readyState === "interactive") {
      fn();
    } else {
      document.addEventListener("DOMContentLoaded", fn, { once: true });
    }
  }

  async function fetchDelta() {
    try {
      const res = await fetch("/api/vsp/dashboard_delta_latest", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error", res.status);
        return;
      }
      const data = await res.json();
      if (!data || !data.ok || !data.current || !data.previous) {
        LOG("Không đủ dữ liệu delta", data);
        return;
      }
      renderScoreDelta(data);
    } catch (e) {
      LOG("Exception khi gọi dashboard_delta_latest:", e);
    }
  }

  function renderScoreDelta(data) {
    const current = data.current || {};
    const previous = data.previous || {};

    const curScore = Number(
      typeof current.security_posture_score === "number"
        ? current.security_posture_score
        : 0
    );
    const prevScore = Number(
      typeof previous.security_posture_score === "number"
        ? previous.security_posture_score
        : 0
    );

    if (Number.isNaN(curScore) || Number.isNaN(prevScore)) {
      LOG("Score không hợp lệ", { curScore, prevScore });
      return;
    }

    const delta = curScore - prevScore;
    const deltaStr = delta > 0 ? `+${delta}` : `${delta}`;

    let cls = "vsp-kpi-delta-flat";
    if (delta > 0) cls = "vsp-kpi-delta-up";
    else if (delta < 0) cls = "vsp-kpi-delta-down";

    const card = document.getElementById("vsp-kpi-security-score");
    if (!card) {
      LOG("Không tìm thấy card #vsp-kpi-security-score");
      return;
    }

    if (card.querySelector(".vsp-kpi-delta-score")) {
      LOG("Score delta đã tồn tại, bỏ qua.");
      return;
    }

    const div = document.createElement("div");
    div.className = `vsp-kpi-delta-score ${cls}`;
    div.textContent = `Δ Score ${deltaStr} (${prevScore} → ${curScore})`;

    card.appendChild(div);

    LOG("Render Δ Score:", {
      delta,
      curScore,
      prevScore,
      run_current: current.run_id,
      run_previous: previous.run_id,
    });
  }

  onReady(fetchDelta);
})();
// ===============================================
// [VSP_TABS_ENHANCE_v1]
// Decorate 4 tabs: Runs, DataSource, Settings,
// Rule Overrides với KPI header
// ===============================================
(function () {
  const LOG = (...args) => console.log("[VSP_TABS_ENHANCE]", ...args);

  function onReadyTabsEnhance(fn) {
    if (document.readyState === "complete" || document.readyState === "interactive") {
      fn();
    } else {
      document.addEventListener("DOMContentLoaded", fn, { once: true });
    }
  }

  function ensureTabHeader(tabEl, title, subtitle) {
    if (!tabEl) return null;

    let header = tabEl.querySelector(".vsp-tab-header");
    if (!header) {
      header = document.createElement("div");
      header.className = "vsp-tab-header vsp-tab-header-grid";
      tabEl.prepend(header);
    }

    if (!header.querySelector(".vsp-tab-title")) {
      const titleBox = document.createElement("div");
      titleBox.className = "vsp-tab-title";
      const h2 = document.createElement("h2");
      h2.textContent = title;
      const p = document.createElement("p");
      p.textContent = subtitle || "";
      titleBox.appendChild(h2);
      titleBox.appendChild(p);
      header.appendChild(titleBox);
    }

    let kpiRow = header.querySelector(".vsp-tab-kpi-row");
    if (!kpiRow) {
      kpiRow = document.createElement("div");
      kpiRow.className = "vsp-tab-kpi-row";
      header.appendChild(kpiRow);
    }
    return kpiRow;
  }

  function makeKpiChip(label, value, extra) {
    const div = document.createElement("div");
    div.className = "vsp-kpi-chip";

    const spanLabel = document.createElement("div");
    spanLabel.className = "vsp-kpi-chip-label";
    spanLabel.textContent = label;

    const spanVal = document.createElement("div");
    spanVal.className = "vsp-kpi-chip-value";
    spanVal.textContent = value;

    div.appendChild(spanLabel);
    div.appendChild(spanVal);

    if (extra) {
      const spanExtra = document.createElement("div");
      spanExtra.className = "vsp-kpi-chip-extra";
      spanExtra.textContent = extra;
      div.appendChild(spanExtra);
    }

    return div;
  }

  // -------- Runs & Reports tab --------
  async function enhanceRunsTab() {
    const tab = document.getElementById("vsp-tab-runs");
    if (!tab) {
      LOG("Không thấy tab Runs (#vsp-tab-runs)");
      return;
    }

    let kpiRow = ensureTabHeader(
      tab,
      "Runs & Reports",
      "Lịch sử các lần scan · Chọn 1 run để xem chi tiết."
    );
    if (!kpiRow) return;
    if (kpiRow.dataset.enhanced === "1") {
      LOG("Runs tab đã enhanced, bỏ qua.");
      return;
    }

    try {
      const res = await fetch("/api/vsp/runs_index_v3?limit=50", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error runs_index_v3:", res.status);
        return;
      }
      const data = await res.json();

      const kpi = data.kpi || {};
      const items = Array.isArray(data.items) ? data.items : [];

      const totalRuns = kpi.total_runs || items.length || 0;
      const avgLastN = kpi.avg_findings_per_run_last_n || 0;
      const lastN = kpi.last_n || (items.length || 0);

      const lastRun = items[0] || {};
      const lastRunId = lastRun.run_id || "N/A";
      const lastRunTotal = lastRun.total_findings || lastRun.total || 0;

      kpiRow.appendChild(
        makeKpiChip("Total runs", String(totalRuns), `Last N = ${lastN}`)
      );
      kpiRow.appendChild(
        makeKpiChip("Avg findings (last N)", String(Math.round(avgLastN)), "")
      );
      kpiRow.appendChild(
        makeKpiChip("Latest run", lastRunId, `Findings = ${lastRunTotal}`)
      );

      kpiRow.dataset.enhanced = "1";
      LOG("Enhanced Runs tab KPI:", { totalRuns, avgLastN, lastN, lastRunId, lastRunTotal });
    } catch (e) {
      LOG("Exception enhanceRunsTab:", e);
    }
  }

  // -------- Data Source tab --------
  async function enhanceDatasourceTab() {
    const tab = document.getElementById("vsp-tab-datasource");
    if (!tab) {
      LOG("Không thấy tab DataSource (#vsp-tab-datasource)");
      return;
    }

    let kpiRow = ensureTabHeader(
      tab,
      "Data Source",
      "Bảng chi tiết các findings đã unify từ nhiều tool."
    );
    if (!kpiRow) return;
    if (kpiRow.dataset.enhanced === "1") {
      LOG("DataSource tab đã enhanced, bỏ qua.");
      return;
    }

    try {
      const res = await fetch("/api/vsp/datasource_v2?limit=1", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error datasource_v2:", res.status);
        return;
      }
      const data = await res.json();
      const total = data.total || 0;
      const bySeverity = data.by_severity || {};
      const crit = bySeverity.CRITICAL || 0;
      const high = bySeverity.HIGH || 0;
      const med = bySeverity.MEDIUM || 0;

      kpiRow.appendChild(
        makeKpiChip("Total findings (all tools)", String(total), "")
      );
      kpiRow.appendChild(
        makeKpiChip("Critical / High", `${crit} / ${high}`, "Xử lý nhóm này trước.")
      );
      kpiRow.appendChild(
        makeKpiChip("Medium", String(med), "Ưu tiên theo business impact.")
      );

      kpiRow.dataset.enhanced = "1";
      LOG("Enhanced DataSource tab KPI:", { total, bySeverity });
    } catch (e) {
      LOG("Exception enhanceDatasourceTab:", e);
    }
  }

  // -------- Settings tab --------
  async function enhanceSettingsTab() {
    const tab = document.getElementById("vsp-tab-settings");
    if (!tab) {
      LOG("Không thấy tab Settings (#vsp-tab-settings)");
      return;
    }

    let kpiRow = ensureTabHeader(
      tab,
      "Settings & Profiles",
      "Cấu hình tool, profile scan và policy gate."
    );
    if (!kpiRow) return;
    if (kpiRow.dataset.enhanced === "1") {
      LOG("Settings tab đã enhanced, bỏ qua.");
      return;
    }

    try {
      const res = await fetch("/api/vsp/settings_ui_v1", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error settings_ui_v1:", res.status);
        return;
      }
      const data = await res.json();
      const settings = data.settings || {};

      const gate = settings.gate_policy || {};
      const maxHigh = typeof gate.max_high === "number" ? gate.max_high : 10;

      const tools = settings.tools_enabled || settings.tools || [];
      const toolsArr = Array.isArray(tools) ? tools : [];
      const toolsLabel = toolsArr.length
        ? toolsArr.join(", ")
        : "Semgrep, Gitleaks, KICS, CodeQL, Bandit, Trivy, Syft, Grype";

      kpiRow.appendChild(
        makeKpiChip("Gate policy", "CRIT = 0", `HIGH ≤ ${maxHigh}`)
      );
      kpiRow.appendChild(
        makeKpiChip("Tools enabled", String(toolsArr.length || 8), toolsLabel)
      );

      kpiRow.dataset.enhanced = "1";
      LOG("Enhanced Settings tab KPI:", { gate, toolsArr });
    } catch (e) {
      LOG("Exception enhanceSettingsTab:", e);
    }
  }

  // -------- Rules / Rule Overrides tab --------
  async function enhanceRulesTab() {
    const tab =
      document.getElementById("vsp-tab-rule-overrides") ||
      document.getElementById("vsp-tab-rules");
    if (!tab) {
      LOG("Không thấy tab Rule Overrides (#vsp-tab-rule-overrides / #vsp-tab-rules)");
      return;
    }

    let kpiRow = ensureTabHeader(
      tab,
      "Rule Overrides",
      "Quản lý ngoại lệ, suppression và tuning rule cho tool."
    );
    if (!kpiRow) return;
    if (kpiRow.dataset.enhanced === "1") {
      LOG("Rules tab đã enhanced, bỏ qua.");
      return;
    }

    try {
      const res = await fetch("/api/vsp/rule_overrides_ui_v1", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error rule_overrides_ui_v1:", res.status);
        return;
      }
      const data = await res.json();

      const total = data.total || 0;
      const active = data.active || data.enabled || 0;
      const byTool = data.by_tool || {};
      const toolNames = Object.keys(byTool);
      const toolsCount = toolNames.length;
      const toolsList = toolNames.slice(0, 4).join(", ");

      kpiRow.appendChild(
        makeKpiChip("Total overrides", String(total), `Active = ${active}`)
      );
      kpiRow.appendChild(
        makeKpiChip("Tools with overrides", String(toolsCount), toolsList || "N/A")
      );

      kpiRow.dataset.enhanced = "1";
      LOG("Enhanced Rules tab KPI:", { total, active, byTool });
    } catch (e) {
      LOG("Exception enhanceRulesTab:", e);
    }
  }

  onReadyTabsEnhance(() => {
    try {
      enhanceRunsTab();
      enhanceDatasourceTab();
      enhanceSettingsTab();
      enhanceRulesTab();
    } catch (e) {
      LOG("Exception top-level:", e);
    }
  });
})();
// ====================================================
// [VSP_TABS_ENHANCE_v2]
// Thêm header + KPI cho 4 tab: Runs, Data, Settings,
// Rule Overrides. Dùng MutationObserver chờ tab sẵn sàng.
// ====================================================
(function () {
  const LOG = (...args) => console.log("[VSP_TABS_ENHANCE_V2]", ...args);

  function whenReady(fn) {
    if (document.readyState === "complete" || document.readyState === "interactive") {
      fn();
    } else {
      document.addEventListener("DOMContentLoaded", fn, { once: true });
    }
  }

  // ---- Helper: chờ cho tới khi có element với id ----
  function waitForEl(id, cb) {
    const existing = document.getElementById(id);
    if (existing) {
      cb(existing);
      return;
    }
    const maxTries = 40;
    let tries = 0;

    const obs = new MutationObserver(() => {
      const el = document.getElementById(id);
      if (el) {
        obs.disconnect();
        cb(el);
      } else if (++tries >= maxTries) {
        obs.disconnect();
        LOG("Timeout chờ element", id);
      }
    });

    obs.observe(document.body, { childList: true, subtree: true });
  }

  function ensureTabHeader(tabEl, title, subtitle) {
    if (!tabEl) return null;

    let header = tabEl.querySelector(".vsp-tab-header");
    if (!header) {
      header = document.createElement("div");
      header.className = "vsp-tab-header vsp-tab-header-grid";
      tabEl.prepend(header);
    }

    if (!header.querySelector(".vsp-tab-title")) {
      const titleBox = document.createElement("div");
      titleBox.className = "vsp-tab-title";
      const h2 = document.createElement("h2");
      h2.textContent = title;
      const p = document.createElement("p");
      p.textContent = subtitle || "";
      titleBox.appendChild(h2);
      titleBox.appendChild(p);
      header.appendChild(titleBox);
    }

    let kpiRow = header.querySelector(".vsp-tab-kpi-row");
    if (!kpiRow) {
      kpiRow = document.createElement("div");
      kpiRow.className = "vsp-tab-kpi-row";
      header.appendChild(kpiRow);
    }
    return kpiRow;
  }

  function makeKpiChip(label, value, extra) {
    const div = document.createElement("div");
    div.className = "vsp-kpi-chip";

    const lab = document.createElement("div");
    lab.className = "vsp-kpi-chip-label";
    lab.textContent = label;

    const val = document.createElement("div");
    val.className = "vsp-kpi-chip-value";
    val.textContent = value;

    div.appendChild(lab);
    div.appendChild(val);

    if (extra) {
      const ext = document.createElement("div");
      ext.className = "vsp-kpi-chip-extra";
      ext.textContent = extra;
      div.appendChild(ext);
    }
    return div;
  }

  // ------------- Runs & Reports ----------------
  async function enhanceRuns(tab) {
    const kpiRow = ensureTabHeader(
      tab,
      "Runs & Reports",
      "Lịch sử scan · chọn 1 run để xem / export."
    );
    if (!kpiRow || kpiRow.dataset.enhanced === "1") return;

    try {
      const res = await fetch("/api/vsp/runs_index_v3?limit=50", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error runs_index_v3:", res.status);
        return;
      }
      const data = await res.json();
      const kpi = data.kpi || {};
      const items = Array.isArray(data.items) ? data.items : [];

      const totalRuns = kpi.total_runs || items.length || 0;
      const lastN = kpi.last_n || (items.length || 0);
      const avgLastN = kpi.avg_findings_per_run_last_n || 0;

      const lastRun = items[0] || {};
      const lastRunId = lastRun.run_id || "N/A";
      const lastRunTotal = lastRun.total_findings || lastRun.total || 0;

      kpiRow.appendChild(
        makeKpiChip("Total runs", String(totalRuns), `Last N = ${lastN}`)
      );
      kpiRow.appendChild(
        makeKpiChip("Avg findings (last N)", String(Math.round(avgLastN)), "")
      );
      kpiRow.appendChild(
        makeKpiChip("Latest run", lastRunId, `Findings = ${lastRunTotal}`)
      );

      kpiRow.dataset.enhanced = "1";
      LOG("Runs tab enhanced.");
    } catch (e) {
      LOG("Runs enhance error:", e);
    }
  }

  // ------------- Data Source -------------------
  async function enhanceDataSource(tab) {
    const kpiRow = ensureTabHeader(
      tab,
      "Data Source",
      "Bảng chi tiết findings unify từ nhiều tool."
    );
    if (!kpiRow || kpiRow.dataset.enhanced === "1") return;

    try {
      const res = await fetch("/api/vsp/datasource_v2?limit=1", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error datasource_v2:", res.status);
        return;
      }
      const data = await res.json();
      const total = data.total || 0;
      const sev = data.by_severity || {};
      const crit = sev.CRITICAL || 0;
      const high = sev.HIGH || 0;
      const med = sev.MEDIUM || 0;

      kpiRow.appendChild(
        makeKpiChip("Total findings", String(total), "Từ tất cả tools")
      );
      kpiRow.appendChild(
        makeKpiChip("Critical / High", `${crit} / ${high}`, "Xử lý nhóm này trước")
      );
      kpiRow.appendChild(
        makeKpiChip("Medium", String(med), "Ưu tiên theo business impact")
      );

      kpiRow.dataset.enhanced = "1";
      LOG("DataSource tab enhanced.");
    } catch (e) {
      LOG("DataSource enhance error:", e);
    }
  }

  // ------------- Settings ----------------------
  async function enhanceSettings(tab) {
    const kpiRow = ensureTabHeader(
      tab,
      "Settings & Profiles",
      "Cấu hình tool, profile scan, gate policy."
    );
    if (!kpiRow || kpiRow.dataset.enhanced === "1") return;

    try {
      const res = await fetch("/api/vsp/settings_ui_v1", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error settings_ui_v1:", res.status);
        return;
      }
      const data = await res.json();
      const settings = data.settings || {};

      const gate = settings.gate_policy || {};
      const maxHigh = typeof gate.max_high === "number" ? gate.max_high : 10;

      const tools = settings.tools_enabled || settings.tools || [];
      const arr = Array.isArray(tools) ? tools : [];
      const toolsLabel = arr.length
        ? arr.join(", ")
        : "Semgrep, Gitleaks, KICS, CodeQL, Bandit, Trivy, Syft, Grype";

      kpiRow.appendChild(
        makeKpiChip("Gate policy", "CRIT = 0", `HIGH ≤ ${maxHigh}`)
      );
      kpiRow.appendChild(
        makeKpiChip("Tools enabled", String(arr.length || 8), toolsLabel)
      );

      kpiRow.dataset.enhanced = "1";
      LOG("Settings tab enhanced.");
    } catch (e) {
      LOG("Settings enhance error:", e);
    }
  }

  // ------------- Rules / Overrides -------------
  async function enhanceRules(tab) {
    const kpiRow = ensureTabHeader(
      tab,
      "Rule Overrides",
      "Quản lý ngoại lệ, suppression, tuning rule."
    );
    if (!kpiRow || kpiRow.dataset.enhanced === "1") return;

    try {
      const res = await fetch("/api/vsp/rule_overrides_ui_v1", { cache: "no-store" });
      if (!res.ok) {
        LOG("HTTP error rule_overrides_ui_v1:", res.status);
        return;
      }
      const data = await res.json();
      const total = data.total || 0;
      const active = data.active || data.enabled || 0;
      const byTool = data.by_tool || {};
      const tools = Object.keys(byTool);
      const toolsList = tools.slice(0, 4).join(", ");

      kpiRow.appendChild(
        makeKpiChip("Total overrides", String(total), `Active = ${active}`)
      );
      kpiRow.appendChild(
        makeKpiChip("Tools with overrides", String(tools.length), toolsList || "N/A")
      );

      kpiRow.dataset.enhanced = "1";
      LOG("Rules tab enhanced.");
    } catch (e) {
      LOG("Rules enhance error:", e);
    }
  }

  whenReady(function () {
    LOG("Init tab enhancements V2...");

    waitForEl("vsp-tab-runs", enhanceRuns);
    waitForEl("vsp-tab-datasource", enhanceDataSource);
    waitForEl("vsp-tab-settings", enhanceSettings);

    // rules tab id có thể là vsp-tab-rule-overrides hoặc vsp-tab-rules
    waitForEl("vsp-tab-rule-overrides", enhanceRules);
    waitForEl("vsp-tab-rules", enhanceRules);
  });
})();


/* == VSP TABS HASH ROUTER LOADER v1 ==
 * Tự động load /static/js/vsp_tabs_hash_router_v1.js
 * trên mọi trang đang dùng vsp_console_patch_v1.js
 * (đã có guard tránh load nhiều lần).
 */
(function () {
  try {
    if (window.VSP_TABS_HASH_ROUTER_LOADER) return;
    window.VSP_TABS_HASH_ROUTER_LOADER = true;

    var s = document.createElement('script');
    s.src = '/static/js/vsp_tabs_hash_router_v1.js';
    s.defer = true;
    s.onload = function () {
      console.log('[VSP_CONSOLE_PATCH] vsp_tabs_hash_router_v1.js loaded.');
    };
    document.head.appendChild(s);
  } catch (e) {
    console.warn('[VSP_CONSOLE_PATCH] Failed to attach hash router loader', e);
  }
})();
