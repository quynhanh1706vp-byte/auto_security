(function () {
  const API_URL = '/api/vsp/settings_ui_v1';
  const INIT_DELAY_MS = 1200;

  function esc(s) {
    if (s == null) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function renderSkeleton(tab) {
    tab.innerHTML = `
      <div class="vsp-tab-inner vsp-tab-settings">
        <div class="vsp-tab-header">
          <h2>Settings</h2>
          <p class="vsp-tab-subtitle">
            Cấu hình chính sách gate, tool và tham số scan. Hiện tại ở chế độ xem (read-only).
          </p>
        </div>

        <div class="vsp-card-grid">
          <div class="vsp-card">
            <h3>Gate policy</h3>
            <p class="vsp-muted">
              Điều kiện để job CI đánh FAIL / PASS. Mặc định: FAIL nếu CRITICAL &gt; 0 hoặc HIGH &gt; 10.
            </p>
            <ul class="vsp-list" id="vsp-settings-gate-list">
              <li>Loading gate policy…</li>
            </ul>
          </div>

          <div class="vsp-card">
            <h3>Tools</h3>
            <p class="vsp-muted">
              Các công cụ security hiện được kích hoạt trong gói VSP (Semgrep, CodeQL, KICS,…).
            </p>
            <ul class="vsp-list" id="vsp-settings-tools-list">
              <li>Loading tools…</li>
            </ul>
          </div>

          <div class="vsp-card">
            <h3>Profiles &amp; thresholds</h3>
            <p class="vsp-muted">
              Một số tham số nâng cao (timeout, max files, profile FULL_EXT/SMOKE…).
            </p>
            <ul class="vsp-list" id="vsp-settings-extra-list">
              <li>Loading…</li>
            </ul>
          </div>
        </div>

        <div class="vsp-card vsp-card-note">
          <h3>Editing roadmap</h3>
          <p>
            Phiên bản hiện tại cho phép xem cấu hình. Bản thương mại tiếp theo sẽ bật:
          </p>
          <ul class="vsp-list">
            <li>Chỉnh gate policy trực tiếp và lưu xuống server.</li>
            <li>Bật/tắt từng tool theo repo hoặc theo pipeline.</li>
            <li>Lưu và restore cấu hình theo profile (STRICT / BALANCED / RELAXED).</li>
          </ul>
        </div>
      </div>
    `;
  }

  async function bindSettings(tab) {
    renderSkeleton(tab);

    const gateList = tab.querySelector('#vsp-settings-gate-list');
    const toolsList = tab.querySelector('#vsp-settings-tools-list');
    const extraList = tab.querySelector('#vsp-settings-extra-list');

    let data;
    try {
      const res = await fetch(API_URL, { cache: 'no-store' });
      data = await res.json();
    } catch (e) {
      console.error('[VSP_SETTINGS_TAB] Failed to load settings_ui_v1', e);
      if (gateList) gateList.innerHTML = '<li class="vsp-error">Không tải được settings từ API.</li>';
      if (toolsList) toolsList.innerHTML = '';
      if (extraList) extraList.innerHTML = '';
      return;
    }

    const settings = data.settings || {};

    // Gate policy
    if (gateList) {
      if (!settings.gate_policy) {
        gateList.innerHTML = `
          <li><strong>Mode:</strong> Default</li>
          <li><strong>Fail if CRITICAL &gt; 0</strong></li>
          <li><strong>Fail if HIGH &gt; 10</strong></li>
          <li>MEDIUM/LOW chỉ cảnh báo, không fail job.</li>
        `;
      } else {
        const gp = settings.gate_policy;
        const lines = [];
        if (gp.mode) lines.push(`<li><strong>Mode:</strong> ${esc(gp.mode)}</li>`);
        if (gp.critical_threshold != null) {
          lines.push(`<li>Fail nếu CRITICAL &gt; ${esc(gp.critical_threshold)}</li>`);
        }
        if (gp.high_threshold != null) {
          lines.push(`<li>Fail nếu HIGH &gt; ${esc(gp.high_threshold)}</li>`);
        }
        if (gp.description) {
          lines.push(`<li>${esc(gp.description)}</li>`);
        }
        gateList.innerHTML = lines.join('') || '<li>Gate policy đang để trống.</li>';
      }
    }

    // Tools
    if (toolsList) {
      const tools = settings.tools || settings.tools_enabled || {};
      const names = Object.keys(tools);
      if (!names.length) {
        toolsList.innerHTML = `
          <li>Semgrep</li>
          <li>Gitleaks</li>
          <li>KICS</li>
          <li>CodeQL</li>
          <li>Trivy / Syft / Grype</li>
        `;
      } else {
        toolsList.innerHTML = names
          .map(name => {
            const v = tools[name];
            const enabled = v === true || v === 'on' || v === 'enabled';
            return `<li><strong>${esc(name)}</strong> – ${enabled ? 'enabled' : 'disabled'}</li>`;
          })
          .join('');
      }
    }

    // Extra
    if (extraList) {
      const extras = settings.extras || settings.profiles || {};
      const keys = Object.keys(extras);
      if (!keys.length) {
        extraList.innerHTML = `
          <li>Profile FULL_EXT: full scan toàn hệ thống.</li>
          <li>Profile SMOKE: scan nhanh (~10–20% trọng tâm) cho mỗi push CI.</li>
          <li>Timeout, số file tối đa: sử dụng giá trị mặc định an toàn.</li>
        `;
      } else {
        extraList.innerHTML = keys
          .map(name => `<li><strong>${esc(name)}:</strong> ${esc(JSON.stringify(extras[name]))}</li>`)
          .join('');
      }
    }

    console.log('[VSP_SETTINGS_TAB] Rendered settings.');
  }

  let initialized = false;

  function tryInit() {
    if (initialized) return;
    const tab = document.querySelector('#vsp-tab-settings');
    if (!tab) {
      setTimeout(tryInit, 500);
      return;
    }
    initialized = true;
    setTimeout(() => bindSettings(tab), INIT_DELAY_MS);
  }

  tryInit();
})();
