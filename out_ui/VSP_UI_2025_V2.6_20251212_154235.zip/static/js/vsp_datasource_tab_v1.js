(function () {
  "use strict";

  const LOG_PREFIX = "[VSP_DATASOURCE_TAB]";
  const DS_API = "/api/vsp/datasource_v2";
  const PAGE_SIZE = 50;

  let state = {
    page: 0,
    total: 0,
    severity: "",
    tool: "",
    q: "",
  };

  function log() {
    // eslint-disable-next-line no-console
    console.log.apply(console, [LOG_PREFIX].concat(Array.from(arguments)));
  }

  function $(id) {
    return document.getElementById(id);
  }

  function buildQuery(params) {
    const usp = new URLSearchParams();
    Object.keys(params || {}).forEach((k) => {
      const v = params[k];
      if (v === undefined || v === null) return;
      const s = String(v).trim();
      if (!s) return;
      usp.set(k, s);
    });
    const qs = usp.toString();
    return qs ? "?" + qs : "";
  }

  async function fetchDataSource() {
    const offset = state.page * PAGE_SIZE;
    const params = {
      limit: PAGE_SIZE,
      offset: offset,
      severity: state.severity || undefined,
      tool: state.tool || undefined,
      q: state.q || undefined,
    };

    const url = DS_API + buildQuery(params);
    log("Fetching datasource from", url);

    const resp = await fetch(url, { credentials: "same-origin" });
    if (!resp.ok) {
      throw new Error("HTTP " + resp.status);
    }

    const data = await resp.json();
    if (data.ok === false) {
      throw new Error("API error: " + (data.error || "unknown"));
    }

    // Thử các key khác nhau
    let items = data.items || data.rows || data.data || [];
    if (!Array.isArray(items) && typeof items === "object") {
      // Nếu là dict, cố gắng lấy values
      items = Object.values(items);
    }

    const total = data.total || data.total_items || items.length;

    state.total = typeof total === "number" ? total : items.length;
    return items;
  }

  function pick(obj, keys, fallback) {
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      if (obj && Object.prototype.hasOwnProperty.call(obj, k)) {
        const v = obj[k];
        if (v !== undefined && v !== null) return v;
      }
    }
    return fallback;
  }

  function renderTable(items) {
    const tbody = $("vsp-ds-tbody");
    if (!tbody) {
      log("Không tìm thấy #vsp-ds-tbody");
      return;
    }

    tbody.innerHTML = "";

    if (!items || !items.length) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 8;
      td.textContent = "No findings.";
      tr.appendChild(td);
      tbody.appendChild(tr);
      updatePager();
      return;
    }

    items.forEach((f) => {
      const tr = document.createElement("tr");

      const severity = pick(f, ["severity_effective", "severity"], "-");
      const tool = pick(f, ["tool", "tool_id"], "-");
      const cwe = pick(f, ["cwe_id", "cwe", "cwe_code"], "-");
      const rule = pick(f, ["rule_id", "rule", "check_id"], "-");
      const file = pick(f, ["file_path", "rel_path", "path"], "-");
      const line = pick(f, ["line", "start_line"], "-");
      const msg = pick(f, ["message", "short_message", "title"], "-");
      const runId = pick(f, ["run_id"], "-");

      function td(text) {
        const cell = document.createElement("td");
        cell.textContent = text == null ? "-" : String(text);
        return cell;
      }

      tr.appendChild(td(severity));
      tr.appendChild(td(tool));
      tr.appendChild(td(cwe));
      tr.appendChild(td(rule));
      tr.appendChild(td(file));
      tr.appendChild(td(line));
      tr.appendChild(td(msg));
      tr.appendChild(td(runId));

      tbody.appendChild(tr);
    });

    updatePager();
  }

  function updatePager() {
    const info = $("vsp-ds-page-info");
    if (!info) return;

    const page = state.page + 1;
    const totalPages =
      state.total > 0 ? Math.ceil(state.total / PAGE_SIZE) : page;
    info.textContent = `Page ${page} / ${totalPages} – total ${state.total}`;
  }

  async function reloadDataSource() {
    try {
      const items = await fetchDataSource();
      renderTable(items);
    } catch (err) {
      log("Lỗi load datasource:", err);
      const tbody = $("vsp-ds-tbody");
      if (tbody) {
        tbody.innerHTML =
          '<tr><td colspan="8">Error loading datasource. Check console.</td></tr>';
      }
      const info = $("vsp-ds-page-info");
      if (info) info.textContent = "Error";
    }
  }

  function bindFilters() {
    const sevEl = $("vsp-ds-filter-severity");
    const toolEl = $("vsp-ds-filter-tool");
    const textEl = $("vsp-ds-filter-text");
    const reloadBtn = $("vsp-ds-reload");

    if (sevEl) {
      sevEl.addEventListener("change", function () {
        state.severity = sevEl.value || "";
        state.page = 0;
        reloadDataSource();
      });
    }

    if (toolEl) {
      toolEl.addEventListener("change", function () {
        state.tool = toolEl.value || "";
        state.page = 0;
        reloadDataSource();
      });
    }

    if (textEl) {
      textEl.addEventListener("keydown", function (e) {
        if (e.key === "Enter") {
          state.q = textEl.value || "";
          state.page = 0;
          reloadDataSource();
        }
      });
    }

    if (reloadBtn) {
      reloadBtn.addEventListener("click", function () {
        state.page = 0;
        reloadDataSource();
      });
    }

    const prevBtn = $("vsp-ds-prev");
    const nextBtn = $("vsp-ds-next");

    if (prevBtn) {
      prevBtn.addEventListener("click", function () {
        if (state.page > 0) {
          state.page -= 1;
          reloadDataSource();
        }
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener("click", function () {
        const totalPages =
          state.total > 0 ? Math.ceil(state.total / PAGE_SIZE) : 1;
        if (state.page + 1 < totalPages) {
          state.page += 1;
          reloadDataSource();
        }
      });
    }
  }

  function init() {
    const root = $("vsp-ds-root");
    if (!root) {
      log("No #vsp-ds-root found, skip Data Source init.");
      return;
    }
    log("initialized");
    bindFilters();
    reloadDataSource();
  }

  document.addEventListener("DOMContentLoaded", init);

  // Cho console/debug dùng
  window.vspReloadDataSource = reloadDataSource;
})();
