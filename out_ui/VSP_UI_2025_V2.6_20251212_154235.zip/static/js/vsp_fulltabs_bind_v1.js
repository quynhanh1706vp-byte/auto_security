var enabledTools = 0;
var totalTools = 0;
/**
 * vsp_fulltabs_bind_v1.js
 * Bind data + Chart + KPI cho 5 tab (Dashboard + Runs + Data Source + Settings).
 */

console.log("[VSP][FULLTABS] vsp_fulltabs_bind_v1.js loaded.");

// Severity palette dùng chung cho chart & badge
const VSP_SEVERITY_COLORS = {
  CRITICAL: "rgba(255, 99, 132, 0.9)",
  HIGH:     "rgba(255, 159, 64, 0.9)",
  MEDIUM:   "rgba(255, 205, 86, 0.9)",
  LOW:      "rgba(75, 192, 192, 0.9)",
  INFO:     "rgba(54, 162, 235, 0.9)",
  TRACE:    "rgba(201, 203, 207, 0.9)"
};

async function vspFullFetch(url) {
  try {
    const resp = await fetch(url, { credentials: "same-origin" });
    if (!resp.ok) {
      console.error("[VSP][FULLTABS] HTTP", resp.status, url);
      return null;
    }
    return await resp.json();
  } catch (e) {
    console.error("[VSP][FULLTABS] Fetch error", url, e);
    return null;
  }
}

/* ===== Helpers DOM chung ===== */

function vspFullFindCardByTitle(labelText) {
  const all = document.querySelectorAll("h1,h2,h3,h4,h5,h6,div,span,p");
  const target = labelText.trim().toUpperCase();
  for (const el of all) {
    const t = (el.textContent || "").trim().toUpperCase();
    if (!t) continue;
    if (t === target) {
      let card =
        el.closest(".kpi-card") ||
        el.closest(".vsp-kpi") ||
        el.closest(".vsp-card") ||
        el.closest(".card") ||
        el.closest(".panel") ||
        el.parentElement;
      if (card) return card;
    }
  }
  return null;
}

function vspFullFormat(n) {
  if (typeof n !== "number" || !isFinite(n)) return "0";
  return n.toLocaleString("en-US");
}

function vspFullEnsureCanvas(card, id) {
  if (!card) return null;
  let canvas = card.querySelector("canvas#" + id);
  if (!canvas) {
    canvas = document.createElement("canvas");
    canvas.id = id;
    const body =
      card.querySelector(".widget-body, .card-body, .vsp-widget, .content") ||
      card;
    body.innerHTML = "";
    body.appendChild(canvas);
  }
  return canvas;
}

function vspFullSetTextInCard(card, selectorList, text) {
  if (!card) return;
  for (const sel of selectorList) {
    const el = card.querySelector(sel);
    if (el) {
      el.textContent = text;
      return;
    }
  }
}

/* ===== 1. Dashboard – KPI + chart + top risk ===== */

const VSP_KPI_SEV_CLASSES = [
  "vsp-kpi-critical",
  "vsp-kpi-high",
  "vsp-kpi-medium",
  "vsp-kpi-low",
  "vsp-kpi-info",
  "vsp-kpi-trace",
  "vsp-kpi-good",
  "vsp-kpi-warn",
  "vsp-kpi-bad"
];

function vspFullApplyKpiSeverityStyles(dashboard) {
  const bySeverity = dashboard.by_severity || {};

  function styleSevCard(title, sevKey) {
    const card = vspFullFindCardByTitle(title);
    if (!card) return;
    card.classList.remove(...VSP_KPI_SEV_CLASSES);
    card.classList.add("vsp-kpi-card", "vsp-kpi-" + sevKey.toLowerCase());
  }

  // Các card severity chính
  styleSevCard("CRITICAL", "CRITICAL");
  styleSevCard("HIGH", "HIGH");
  styleSevCard("MEDIUM", "MEDIUM");
  styleSevCard("LOW", "LOW");
  styleSevCard("INFO + TRACE", "INFO");

  // TOTAL FINDINGS: đỏ nếu có CRIT/HIGH, cam nếu chỉ MED, xanh nếu low-level
  const totalCard = vspFullFindCardByTitle("TOTAL FINDINGS");
  if (totalCard) {
    totalCard.classList.remove(...VSP_KPI_SEV_CLASSES);
    totalCard.classList.add("vsp-kpi-card");
    const crit = Number(bySeverity.CRITICAL || 0);
    const high = Number(bySeverity.HIGH || 0);
    const med  = Number(bySeverity.MEDIUM || 0);
    let cls = "vsp-kpi-good";
    if (crit > 0 || high > 0) cls = "vsp-kpi-critical";
    else if (med > 0) cls = "vsp-kpi-high";
    totalCard.classList.add(cls);
  }

  // SECURITY SCORE: >=80 xanh, 50-79 warn, <50 bad
  const scoreCard = vspFullFindCardByTitle("SECURITY POSTURE SCORE");
  if (scoreCard) {
    scoreCard.classList.remove(...VSP_KPI_SEV_CLASSES);
    scoreCard.classList.add("vsp-kpi-card");
    const score = Number(dashboard.security_score || 0);
    let cls = "vsp-kpi-bad";
    if (score >= 80) cls = "vsp-kpi-good";
    else if (score >= 50) cls = "vsp-kpi-warn";
    scoreCard.classList.add(cls);
  }
}

function vspFullBindDashboard(dashboard, runs, datasource, topCweInsights) {
  if (!dashboard) return;

  const bySeverity = dashboard.by_severity || {};
  const byTool = dashboard.by_tool || {};

  /* ---- TOP RISKY TOOL ---- */
  let topRiskyTool = dashboard.top_risky_tool || "N/A";
  if ((!topRiskyTool || topRiskyTool === "N/A") && byTool) {
    let bestName = null;
    let bestCount = -1;
    Object.entries(byTool).forEach(([name, cnt]) => {
      const n = Number(cnt || 0);
      if (n > bestCount) {
        bestCount = n;
        bestName = name;
      }
    });
    if (bestName) topRiskyTool = bestName;
  }
  const riskyCard = vspFullFindCardByTitle("TOP RISKY TOOL");
  if (riskyCard) {
    vspFullSetTextInCard(
      riskyCard,
      [".kpi-value", ".value", ".kpi-main"],
      topRiskyTool || "N/A"
    );
  }

  /* ---- Severity distribution chart ---- */
  const sevCard = vspFullFindCardByTitle("Severity distribution (6 levels)");
  if (sevCard && window.Chart) {
    const canvas = vspFullEnsureCanvas(sevCard, "vsp_chart_severity");
    if (canvas) {
      const labels = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "TRACE"];
      const data = labels.map(sev => bySeverity[sev] || 0);
      const bgColors = labels.map(
        sev => VSP_SEVERITY_COLORS[sev] || "rgba(255,255,255,0.3)"
      );

      if (canvas._chart) canvas._chart.destroy();
      canvas._chart = new Chart(canvas.getContext("2d"), {
        type: "bar",
        data: {
          labels,
          datasets: [{
            label: "Findings",
            data,
            backgroundColor: bgColors,
            borderColor: bgColors,
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { ticks: { autoSkip: false } },
            y: { beginAtZero: true }
          }
        }
      });
    }
  } else if (sevCard) {
    const text =
      "CRIT " + vspFullFormat(bySeverity.CRITICAL || 0) +
      " • HIGH " + vspFullFormat(bySeverity.HIGH || 0) +
      " • MED " + vspFullFormat(bySeverity.MEDIUM || 0) +
      " • LOW " + vspFullFormat(bySeverity.LOW || 0) +
      " • INFO " + vspFullFormat(bySeverity.INFO || 0) +
      " • TRACE " + vspFullFormat(bySeverity.TRACE || 0);
    const body =
      sevCard.querySelector(".widget-body, .card-body, .vsp-widget, .content") ||
      sevCard;
    body.innerHTML = '<div class="severity-summary-text">' + text + "</div>";
  }

  /* ---- Trend over time (Critical+High) ---- */
  if (Array.isArray(runs) && window.Chart) {
    const trendCard = vspFullFindCardByTitle("Trend over time");
    if (trendCard) {
      const canvas = vspFullEnsureCanvas(trendCard, "vsp_chart_trend");
      if (canvas) {
        const recent = runs.slice().reverse().slice(-10);
        const labels = recent.map(r => {
          const id = r.run_id || "";
          const parts = id.split("_");
          return parts.length >= 4 ? parts[3] : id;
        });
        const data = recent.map(r => {
          const sev = r.by_severity || {};
          return Number(sev.CRITICAL || 0) + Number(sev.HIGH || 0);
        });

        if (canvas._chart) canvas._chart.destroy();
        canvas._chart = new Chart(canvas.getContext("2d"), {
          type: "line",
          data: {
            labels,
            datasets: [{
              label: "Critical + High",
              data,
              fill: false,
              tension: 0.3
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true } }
          }
        });
      }
    }
  }

  /* ---- Critical & High by tool ---- */
  if (datasource && Array.isArray(datasource.items) && window.Chart) {
    const card = vspFullFindCardByTitle("Critical & High by tool");
    if (card) {
      const canvas = vspFullEnsureCanvas(card, "vsp_chart_tool_ch");
      if (canvas) {
        const counts = {};
        datasource.items.forEach(it => {
          const sev = (it.severity || "").toUpperCase();
          if (sev !== "CRITICAL" && sev !== "HIGH") return;
          const tool = it.tool || "unknown";
          counts[tool] = (counts[tool] || 0) + 1;
        });
        const labels = Object.keys(counts);
        const data = labels.map(t => counts[t]);

        if (canvas._chart) canvas._chart.destroy();
        canvas._chart = new Chart(canvas.getContext("2d"), {
          type: "bar",
          data: {
            labels,
            datasets: [{
              label: "Critical+High",
              data
            }]
          },
          options: {
            indexAxis: "y",
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { x: { beginAtZero: true } }
          }
        });
      }
    }
  }

  /* ---- Top CWE exposure ---- */
  if (topCweInsights && Array.isArray(topCweInsights.items) && window.Chart) {
    const card = vspFullFindCardByTitle("Top CWE exposure");
    if (card) {
      const canvas = vspFullEnsureCanvas(card, "vsp_chart_cwe");
      if (canvas) {
        const items = topCweInsights.items.slice(0, 7);
        const labels = items.map(it => it.cwe || "UNKNOWN");
        const data = items.map(it => it.count || 0);

        if (canvas._chart) canvas._chart.destroy();
        canvas._chart = new Chart(canvas.getContext("2d"), {
          type: "bar",
          data: {
            labels,
            datasets: [{
              label: "Findings",
              data
            }]
          },
          options: {
            indexAxis: "y",
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { x: { beginAtZero: true } }
          }
        });
      }
    }
  }

  /* ---- Top risk findings (table) ---- */
  if (datasource && Array.isArray(datasource.items)) {
    const sevRank = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4, TRACE: 5 };
    const items = datasource.items.slice().sort((a, b) => {
      const sa = sevRank[(a.severity || "").toUpperCase()] ?? 99;
      const sb = sevRank[(b.severity || "").toUpperCase()] ?? 99;
      if (sa !== sb) return sa - sb;
      return 0;
    });
    const top = items.slice(0, 5);

    const topCard = vspFullFindCardByTitle("Top risk findings");
    if (topCard) {
      const tbody = topCard.querySelector("tbody");
      if (tbody && !tbody.hasChildNodes()) {
        top.forEach(it => {
          const tr = document.createElement("tr");
          const tdSev  = document.createElement("td");
          const tdTool = document.createElement("td");
          const tdLoc  = document.createElement("td");
          const tdRule = document.createElement("td");
          tdSev.textContent  = it.severity || "";
          tdTool.textContent = it.tool || "";
          tdLoc.textContent  = it.file || it.path || "";
          tdRule.textContent = it.rule_id || it.rule || "";
          tr.appendChild(tdSev);
          tr.appendChild(tdTool);
          tr.appendChild(tdLoc);
          tr.appendChild(tdRule);
          tbody.appendChild(tr);
        });
      }
    }
  }

  // Áp màu heat cho KPI
  vspFullApplyKpiSeverityStyles(dashboard);
}

/* ===== 2. Runs & Reports – KPI & style ===== */

function vspFullBindRuns(runs) {
  if (!Array.isArray(runs) || runs.length === 0) return;

  const totalRuns = runs.length;
  const totalFindingsAll = runs.reduce(
    (sum, r) => sum + Number(r.total_findings || 0),
    0
  );
  const avgFindings = totalRuns > 0
    ? Math.round(totalFindingsAll / totalRuns)
    : 0;

  const totalRunsCard = vspFullFindCardByTitle("TOTAL RUNS");
  if (totalRunsCard) {
    vspFullSetTextInCard(
      totalRunsCard,
      [".kpi-value", ".value", ".kpi-main"],
      vspFullFormat(totalRuns)
    );
  }

  // LAST 10 RUNS success/fail (0 findings = success)
  const last10 = runs.slice(0, 10);
  let successCount = 0;
  let failCount = 0;
  last10.forEach(r => {
    const tf = Number(r.total_findings || 0);
    if (tf === 0) successCount += 1;
    else failCount += 1;
  });

  const lastCard = vspFullFindCardByTitle("LAST 10 RUNS");
  if (lastCard) {
    const txt = successCount + " / " + failCount;
    vspFullSetTextInCard(lastCard, [".kpi-value", ".value", ".kpi-main"], txt);
  }

  const avgCard = vspFullFindCardByTitle("AVG FINDINGS / RUN");
  if (avgCard) {
    vspFullSetTextInCard(
      avgCard,
      [".kpi-value", ".value", ".kpi-main"],
      vspFullFormat(avgFindings)
    );
  }

  // TOOLS ENABLED / RUN – dựa vào settings (global cache)
  const toolsCard = vspFullFindCardByTitle("TOOLS ENABLED / RUN");
  if (toolsCard) {
    let totalTools = 7;
    let enabledTools = 7;
    if (window.vspFullSettingsLast && window.vspFullSettingsLast.tools) {
      const t = window.vspFullSettingsLast.tools;
      totalTools = Object.keys(t).length;
      enabledTools = Object.values(t).filter(cfg => cfg && cfg.enabled).length;
    }
    const txt = enabledTools + " / " + totalTools;
    vspFullSetTextInCard(toolsCard, [".kpi-value", ".value", ".kpi-main"], txt);
  }

  // Style màu cho 4 KPI Runs
  if (totalRunsCard) {
    totalRunsCard.classList.remove(...VSP_KPI_SEV_CLASSES);
    totalRunsCard.classList.add("vsp-kpi-card", "vsp-kpi-info");
  }
  if (lastCard) {
    lastCard.classList.remove(...VSP_KPI_SEV_CLASSES);
    lastCard.classList.add("vsp-kpi-card");
    const cls = failCount === 0 ? "vsp-kpi-good"
      : (failCount <= 3 ? "vsp-kpi-warn" : "vsp-kpi-bad");
    lastCard.classList.add(cls);
  }
  if (avgCard) {
    avgCard.classList.remove(...VSP_KPI_SEV_CLASSES);
    avgCard.classList.add("vsp-kpi-card");
    let cls = "vsp-kpi-good";
    if (avgFindings > 5000) cls = "vsp-kpi-critical";
    else if (avgFindings > 1000) cls = "vsp-kpi-high";
    avgCard.classList.add(cls);
  }
  if (toolsCard) {
    toolsCard.classList.remove(...VSP_KPI_SEV_CLASSES);
    toolsCard.classList.add("vsp-kpi-card");
    const cls = (enabledTools === totalTools) ? "vsp-kpi-good" : "vsp-kpi-warn";
    toolsCard.classList.add(cls);
  }
}

/* ===== 3. Data Source – donut + Top CWE list ===== */

function vspFullBindDatasource(datasource, topCweInsights) {
  if (!datasource || !Array.isArray(datasource.items)) return;

  const sevCounts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0, TRACE: 0 };
  datasource.items.forEach(it => {
    const s = (it.severity || "").toUpperCase();
    if (sevCounts[s] !== undefined) sevCounts[s] += 1;
  });

  const donutCard = vspFullFindCardByTitle("Severity donut - unified");
  if (donutCard && window.Chart) {
    const canvas = vspFullEnsureCanvas(donutCard, "vsp_chart_ds_severity");
    if (canvas) {
      const labels = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "TRACE"];
      const data = labels.map(sev => sevCounts[sev] || 0);
      const bgColors = labels.map(
        sev => VSP_SEVERITY_COLORS[sev] || "rgba(255,255,255,0.3)"
      );

      if (canvas._chart) canvas._chart.destroy();
      canvas._chart = new Chart(canvas.getContext("2d"), {
        type: "doughnut",
        data: {
          labels,
          datasets: [{
            data,
            backgroundColor: bgColors,
            borderColor: bgColors,
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { position: "bottom" } },
          cutout: "60%"
        }
      });
    }
  } else if (donutCard) {
    const body =
      donutCard.querySelector(".widget-body, .card-body, .vsp-widget, .content") ||
      donutCard;
    body.innerHTML =
      "<ul class='sev-donut-text'>" +
      "<li>CRIT: " + vspFullFormat(sevCounts.CRITICAL) + "</li>" +
      "<li>HIGH: " + vspFullFormat(sevCounts.HIGH) + "</li>" +
      "<li>MED: " + vspFullFormat(sevCounts.MEDIUM) + "</li>" +
      "<li>LOW: " + vspFullFormat(sevCounts.LOW) + "</li>" +
      "<li>INFO: " + vspFullFormat(sevCounts.INFO) + "</li>" +
      "<li>TRACE: " + vspFullFormat(sevCounts.TRACE) + "</li>" +
      "</ul>";
  }

  const cweCard = vspFullFindCardByTitle("Top CWE & hot directories");
  if (cweCard && topCweInsights && Array.isArray(topCweInsights.items)) {
    const items = topCweInsights.items.slice(0, 5);
    const body =
      cweCard.querySelector(".widget-body, .card-body, .vsp-widget, .content") ||
      cweCard;
    let html = "<ul class='top-cwe-list'>";
    items.forEach(it => {
      const cwe = it.cwe || "UNKNOWN";
      const count = vspFullFormat(it.count || 0);
      html += "<li>" + cwe + " – " + count + " findings</li>";
    });
    html += "</ul>";
    body.innerHTML = html;
  }
}

/* ===== 4. Settings & Overrides (cache tools cho Runs KPI) ===== */

function vspFullBindSettings(settings) {
  if (!settings || !settings.env || !settings.tools) return;

  window.vspFullSettingsLast = settings;

  const card = vspFullFindCardByTitle("Profile / Tools");
  if (card) {
    const profile = settings.env.profile || "UNKNOWN";
    const tools = Object.entries(settings.tools)
      .filter(([_, cfg]) => cfg && cfg.enabled)
      .map(([name]) => name)
      .join(", ");
    const txt = profile + " – " + tools;
    vspFullSetTextInCard(
      card,
      [".kpi-value", ".value", ".kpi-main", ".content"],
      txt
    );
  }
}

/* ===== 5. Severity badges (Data Source + Top risk table) ===== */

function vspApplySeverityBadges() {
  const map = {
    CRITICAL: "vsp-sev-critical",
    HIGH: "vsp-sev-high",
    MEDIUM: "vsp-sev-medium",
    LOW: "vsp-sev-low",
    INFO: "vsp-sev-info",
    TRACE: "vsp-sev-trace"
  };

  const nodes = document.querySelectorAll("td, span, div");
  nodes.forEach(el => {
    const txt = (el.textContent || "").trim().toUpperCase();
    const cls = map[txt];
    if (!cls) return;
    el.classList.add("vsp-sev-badge", cls);
  });
}

/* ===== 6. Init – call APIs ===== */

async function vspFullTabsInit() {
  console.log("[VSP][FULLTABS] Init...");

  const [dashboard, runs, datasource, topCwe, settings] = await Promise.all([
    vspFullFetch("/api/vsp/dashboard_v3"),
    vspFullFetch("/api/vsp/runs_index_v3_v3?limit=200"),
    vspFullFetch("/api/vsp/datasource_v2?limit=1000"),
    vspFullFetch("/api/vsp/top_cwe_v1?limit=10"),
    vspFullFetch("/api/vsp/settings/get")
  ]);

  if (settings) vspFullBindSettings(settings);
  if (dashboard) vspFullBindDashboard(dashboard, runs || [], datasource || {}, topCwe || null);
  if (runs) vspFullBindRuns(runs);
  if (datasource) vspFullBindDatasource(datasource, topCwe || null);

  vspApplySeverityBadges();

  console.log("[VSP][FULLTABS] Done.");
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", vspFullTabsInit);
} else {
  vspFullTabsInit();
}
