// ======================= VSP_DATASOURCE_V1 – DATA SOURCE =======================
// Dùng /api/vsp/datasource_v2 để:
// - Đổ bảng unified findings
// - Vẽ donut severity
// - Vẽ horizontal bar top CWE

(function () {
  "use strict";

  function qs(sel) { return document.querySelector(sel); }

  function selectDsTbody() {
    return qs("[data-vsp-ds-tbody]") ||
           qs("#vsp-ds-tbody") ||
           (function () {
              var tbl = qs("#vsp-ds-table");
              return tbl ? tbl.querySelector("tbody") : null;
            })();
  }

  function renderTable(items) {
    var tbody = selectDsTbody();
    if (!tbody) {
      console.warn("[VSP][DS] Không tìm thấy tbody unified findings.");
      return;
    }

    tbody.innerHTML = "";
    if (!Array.isArray(items) || !items.length) {
      var trEmpty = document.createElement("tr");
      var tdEmpty = document.createElement("td");
      tdEmpty.colSpan = 10;
      tdEmpty.textContent = "No findings.";
      trEmpty.appendChild(tdEmpty);
      tbody.appendChild(trEmpty);
      return;
    }

    items.forEach(function (f) {
      var tr = document.createElement("tr");
      function td(text) {
        var cell = document.createElement("td");
        cell.textContent = text;
        return cell;
      }

      tr.appendChild(td(f.severity || "–"));
      tr.appendChild(td(f.tool || "–"));
      tr.appendChild(td(f.file || f.path || "–"));
      tr.appendChild(td(f.line != null ? String(f.line) : "–"));
      tr.appendChild(td(f.rule_id || f.rule || "–"));
      tr.appendChild(td(f.message || "–"));
      tr.appendChild(td(f.cwe || "–"));
      tr.appendChild(td(f.cve || "–"));
      tr.appendChild(td(f.module || "–"));
      tr.appendChild(td(Array.isArray(f.tags) ? f.tags.join(",") : (f.tags || "–")));

      tbody.appendChild(tr);
    });
  }

  function buildSeveritySummary(items) {
    var sev = { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0, INFO:0, TRACE:0 };
    items.forEach(function (f) {
      var s = (f.severity || "").toUpperCase();
      if (sev.hasOwnProperty(s)) sev[s]++;
    });
    return sev;
  }

  function buildTopCwe(items, limit) {
    var map = {};
    items.forEach(function (f) {
      var c = f.cwe || f.cwe_id;
      if (!c) return;
      map[c] = (map[c] || 0) + 1;
    });
    var arr = Object.keys(map).map(function (id) {
      return { id: id, count: map[id] };
    });
    arr.sort(function (a, b) { return b.count - a.count; });
    return arr.slice(0, limit || 8);
  }

  function renderSeverityDonut(sev) {
    var canvas = qs("#vsp-ds-severity-donut");
    if (!canvas || typeof Chart === "undefined") {
      if (!canvas) console.warn("[VSP][DS] Không tìm thấy canvas donut.");
      if (typeof Chart === "undefined") console.warn("[VSP][DS] Chart.js chưa được load.");
      return;
    }

    var labels = ["CRITICAL","HIGH","MEDIUM","LOW","INFO","TRACE"];
    var data   = labels.map(function (k) { return sev[k] || 0; });

    new Chart(canvas.getContext("2d"), {
      type: "doughnut",
      data: {
        labels: labels,
        datasets: [{
          data: data
        }]
      },
      options: {
        plugins: { legend: { display: true } }
      }
    });
  }

  function renderTopCweBar(topCwe) {
    var canvas = qs("#vsp-ds-topcwe");
    if (!canvas || typeof Chart === "undefined") {
      if (!canvas) console.warn("[VSP][DS] Không tìm thấy canvas top CWE.");
      if (typeof Chart === "undefined") console.warn("[VSP][DS] Chart.js chưa được load.");
      return;
    }

    var labels = topCwe.map(function (c) { return c.id; });
    var counts = topCwe.map(function (c) { return c.count; });

    new Chart(canvas.getContext("2d"), {
      type: "bar",
      data: {
        labels: labels,
        datasets: [{
          label: "Findings",
          data: counts
        }]
      },
      options: {
        indexAxis: "y",
        plugins: { legend: { display: false } }
      }
    });
  }

  function loadDataSource() {
    var url = "/api/vsp/datasource_v2?limit=500";
    console.log("[VSP][DS] Fetching datasource from", url);

    fetch(url)
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      })
      .then(function (data) {
        console.log("[VSP][DS] Loaded datasource_v2:", data);
        var items = Array.isArray(data.items) ? data.items : [];
        renderTable(items);

        var sev = buildSeveritySummary(items);
        renderSeverityDonut(sev);

        var topCwe = buildTopCwe(items, 8);
        renderTopCweBar(topCwe);
      })
      .catch(function (err) {
        console.error("[VSP][DS] Error loading datasource_v2:", err);
      });
  }

  document.addEventListener("DOMContentLoaded", function () {
    try {
      loadDataSource();
    } catch (err) {
      console.error("[VSP][DS] DOMContentLoaded error:", err);
    }
  });
})();
