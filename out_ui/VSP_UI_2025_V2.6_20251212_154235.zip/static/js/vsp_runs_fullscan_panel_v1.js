;(function () {
  const LOG_PREFIX = "[VSP_RUN_FULLSCAN_PANEL]";

  function $(id) {
    return document.getElementById(id);
  }

  function injectRunPanel() {
    const pane = document.getElementById("vsp-tab-runs");
    if (!pane) {
      console.log(LOG_PREFIX, "Không tìm thấy #vsp-tab-runs – skip inject.");
      return null;
    }

    if (document.getElementById("vsp-run-fullscan-zone")) {
      console.log(LOG_PREFIX, "Run panel đã tồn tại – bỏ qua inject.");
      return $("vsp-run-fullscan-zone");
    }

    const zone = document.createElement("section");
    zone.id = "vsp-run-fullscan-zone";
    zone.className = "vsp-section vsp-section-stack vsp-run-fullscan-zone";

    zone.innerHTML = `
      <div class="vsp-section-header">
        <div>
          <h2 class="vsp-section-title">Run full scan</h2>
          <p class="vsp-section-subtitle">
            Chạy full scan (EXT/FULL) cho một thư mục source và target URL. Kết quả sẽ xuất hiện trong tab Runs &amp; Data Source.
          </p>
        </div>
        <div class="vsp-section-meta">
          <span class="vsp-chip vsp-chip-soft" id="vsp-run-fullscan-last-status">
            Ready
          </span>
        </div>
      </div>

      <div class="vsp-card vsp-card-soft">
        <div class="vsp-card-body vsp-form vsp-grid vsp-grid-3 vsp-run-fullscan-grid">
          <label class="vsp-field vsp-field-wide">
            <span class="vsp-field-label">Source root (thư mục scan)</span>
            <input type="text" id="vsp-run-src-root" class="vsp-input"
                   placeholder="/home/test/Data/khach6">
          </label>

          <label class="vsp-field vsp-field-wide">
            <span class="vsp-field-label">Target URL (app URL)</span>
            <input type="text" id="vsp-run-target-url" class="vsp-input"
                   placeholder="https://demo.demasterpro.com">
          </label>

          <label class="vsp-field">
            <span class="vsp-field-label">Profile</span>
            <select id="vsp-run-profile" class="vsp-input">
              <option value="FULL_EXT">FULL_EXT</option>
              <option value="EXT">EXT</option>
              <option value="FAST">FAST</option>
            </select>
          </label>
        </div>

        <div class="vsp-card-footer vsp-flex vsp-justify-between vsp-items-center vsp-gap-2">
          <div class="vsp-text-xs vsp-text-subtle">
            Profile &amp; mặc định có thể chỉnh trong tab Settings.
          </div>
          <button type="button" class="vsp-btn vsp-btn-primary" id="vsp-run-fullscan-btn">
            Run full scan
          </button>
        </div>
      </div>
    `;

    // Đặt panel lên đầu tab Runs (trước bảng runs)
    if (pane.firstChild) {
      pane.insertBefore(zone, pane.firstChild);
    } else {
      pane.appendChild(zone);
    }

    console.log(LOG_PREFIX, "Injected Run full scan panel.");
    return zone;
  }

  async function loadDefaultsFromSettings() {
    let resp, data;
    try {
      resp = await fetch("/api/vsp/settings_ui_v1", { method: "GET" });
    } catch (e) {
      console.error(LOG_PREFIX, "fetch settings error", e);
      return;
    }

    try {
      data = await resp.json();
    } catch (e) {
      console.error(LOG_PREFIX, "settings JSON parse error", e);
      return;
    }

    if (!data) return;

    let settings = null;
    if (data.ok && data.settings) {
      settings = data.settings;
    } else {
      settings = data;
    }
    if (!settings) return;

    const srcRoot = settings.src_root || settings.source_root || "";
    const runRoot = settings.run_root || settings.out_root || settings.run_dir_root || "";
    const defProfile = settings.default_profile || settings.profile_default || "FULL_EXT";

    const elSrc = $("vsp-run-src-root");
    const elUrl = $("vsp-run-target-url");
    const elProf = $("vsp-run-profile");

    if (elSrc && srcRoot) elSrc.value = srcRoot;
    // target_url không lấy từ settings, người dùng tự nhập theo app
    if (elProf && defProfile) {
      for (const opt of elProf.options) {
        if (opt.value === defProfile) {
          elProf.value = defProfile;
          break;
        }
      }
    }

    console.log(LOG_PREFIX, "Filled defaults from settings.");
  }

  function setStatus(text, mode) {
    const el = $("vsp-run-fullscan-last-status");
    if (!el) return;
    el.textContent = text;
    el.classList.remove("vsp-chip-ok", "vsp-chip-warn", "vsp-chip-error");

    if (mode === "ok") el.classList.add("vsp-chip-ok");
    if (mode === "warn") el.classList.add("vsp-chip-warn");
    if (mode === "err") el.classList.add("vsp-chip-error");
  }

  async function doRunFullScan() {
    const btn = $("vsp-run-fullscan-btn");
    const elSrc = $("vsp-run-src-root");
    const elUrl = $("vsp-run-target-url");
    const elProf = $("vsp-run-profile");

    const srcRoot = elSrc ? elSrc.value.trim() : "";
    const targetUrl = elUrl ? elUrl.value.trim() : "";
    const profile = elProf ? elProf.value.trim() : "FULL_EXT";

    if (!srcRoot) {
      alert("Vui lòng nhập Source root (thư mục scan).");
      return;
    }
    if (!targetUrl) {
      alert("Vui lòng nhập Target URL.");
      return;
    }

    const payload = {
      profile: profile,
      source_root: srcRoot,
      target_url: targetUrl,
    };

    console.log(LOG_PREFIX, "POST /api/vsp/run_full_scan", payload);
    setStatus("Running...", "warn");
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Running...";
    }

    let resp, data;
    try {
      resp = await fetch("/api/vsp/run_full_scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } catch (e) {
      console.error(LOG_PREFIX, "run_full_scan network error", e);
      setStatus("Error (network)", "err");
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Run full scan";
      }
      alert("Lỗi network khi gọi run_full_scan. Xem console.");
      return;
    }

    try {
      data = await resp.json();
    } catch (e) {
      console.error(LOG_PREFIX, "run_full_scan response JSON error", e);
      setStatus("Error (response)", "err");
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Run full scan";
      }
      alert("Scan đã chạy nhưng không đọc được phản hồi JSON.");
      return;
    }

    if (data && data.ok === false) {
      console.error(LOG_PREFIX, "API error", data.error);
      setStatus("Failed: " + (data.error || "unknown"), "err");
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Run full scan";
      }
      alert("Run full scan FAILED: " + (data.error || "unknown"));
      return;
    }

    const runId = data.run_id || data.id || "(unknown)";
    console.log(LOG_PREFIX, "Run started, run_id =", runId);
    setStatus("Started: " + runId, "ok");
    if (btn) {
      btn.disabled = false;
      btn.textContent = "Run full scan";
    }
    alert("Run full scan started: " + runId + "\nBạn có thể xem tiến trình ở tab Runs & Reports / Data Source.");
  }

  function bindRunButton() {
    const btn = $("vsp-run-fullscan-btn");
    if (!btn) {
      console.log(LOG_PREFIX, "Không thấy nút Run full scan.");
      return;
    }
    btn.addEventListener("click", function () {
      doRunFullScan().catch((err) =>
        console.error(LOG_PREFIX, "doRunFullScan error", err)
      );
    });
  }

  async function init() {
    const pane = document.getElementById("vsp-tab-runs");
    if (!pane) {
      console.log(LOG_PREFIX, "Không trong layout Runs – skip init.");
      return;
    }
    injectRunPanel();
    await loadDefaultsFromSettings();
    bindRunButton();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  console.log(LOG_PREFIX, "vsp_runs_fullscan_panel_v1.js loaded.");
})();
