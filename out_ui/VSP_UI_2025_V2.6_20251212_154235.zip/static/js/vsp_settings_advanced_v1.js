(function () {
  console.log('[VSP_SETTINGS_ADV] loaded v1');

  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function fetchJSON(url) {
    return fetch(url, { credentials: 'same-origin' })
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); });
  }

  function renderAdvanced(settings) {
    var pane = document.getElementById('vsp-settings-main');
    if (!pane) return;
    if (pane.querySelector('.vsp-settings-advanced')) return;

    var cfg  = settings && settings.settings ? settings.settings : {};
    var scan = cfg.scan || {};
    var roots = scan.roots || scan.paths || [];
    if (!Array.isArray(roots)) roots = [];

    var toolsCfg = cfg.tools || {};
    var enabledTools = toolsCfg.enabled || toolsCfg.stack || {};
    var enabledNames = Array.isArray(enabledTools)
      ? enabledTools
      : Object.keys(enabledTools).filter(function (k) { return enabledTools[k]; });

    var ciGate = cfg.ci_gate || {};
    var mode   = (cfg.cicd_mode || 'offline').toLowerCase();

    var rootDisplay = roots.length
      ? roots.join('\\n')
      : 'Chưa cấu hình – mặc định: thư mục project LOCAL trên runner CI.';

    var toolsDisplay = enabledNames.length
      ? enabledNames.join(', ')
      : 'Chưa cấu hình – dùng FULL_EXT mặc định.';

    var gateDisplay = [
      'Max CRITICAL: ' + (ciGate.max_critical != null ? ciGate.max_critical : 0),
      'Max HIGH: '     + (ciGate.max_high     != null ? ciGate.max_high     : 10),
      'Min score: '    + (ciGate.min_score    != null ? ciGate.min_score    : 70),
      'Min coverage: ' + (ciGate.min_coverage != null ? ciGate.min_coverage : 80) + '%'
    ].join(' · ');

    var div = document.createElement('div');
    div.className = 'vsp-settings-advanced';
    div.innerHTML = [
      '<div class="vsp-settings-advanced-grid">',
      '  <div class="vsp-card">',
      '    <h3>Scan config &amp; mode</h3>',
      '    <p>',
      '      <strong>Scan LOCAL PATH:</strong> quét thư mục project (SAST / SCA / secrets / IaC).<br>',
      '      <strong>Scan URL / domain (WEB vuln – DAST):</strong> cơ chế riêng kiểu Nessus / OWASP ZAP, ',
      '      phiên bản hiện tại chỉ hiển thị như <em>planned integration</em>, chưa dùng engine AATE/ANY-URL.',
      '    </p>',
      '    <dl>',
      '      <dt>Root paths</dt>',
      '      <dd><pre style="white-space:pre-wrap;font-size:12px;margin-top:4px;">' + rootDisplay + '</pre></dd>',
      '      <dt>CI/CD mode</dt>',
      '      <dd>' + (mode === 'online'
                      ? 'ONLINE – báo trạng thái gate trực tiếp lên CI / ChatOps.'
                      : 'OFFLINE – gate nội bộ, chỉ log & report.') + '</dd>',
      '    </dl>',
      '  </div>',
      '  <div class="vsp-card">',
      '    <h3>Tool stack &amp; CI/CD gate</h3>',
      '    <dl>',
      '      <dt>Tool stack đang dùng</dt>',
      '      <dd>' + toolsDisplay + '</dd>',
      '      <dt>Chính sách gate (đề xuất)</dt>',
      '      <dd>' + gateDisplay + '</dd>',
      '    </dl>',
      '    <button id="vsp-run-local-btn" class="vsp-btn-primary" style="margin-top:8px;">',
      '      <span>▶</span><span style="margin-left:4px;">Run scan now (LOCAL)</span>',
      '    </button>',
      '    <div id="vsp-run-local-status" style="margin-top:4px;font-size:12px;color:#9ca3af;"></div>',
      '  </div>',
      '</div>',
      '<div class="vsp-card" style="margin-top:16px;">',
      '  <h3>Scan URL / Domain (WEB vuln – DAST)</h3>',
      '  <p>',
      '    Nhập URL/domain để quét kiểu Nessus / ZAP. Bản hiện tại chỉ là UI demo, ',
      '    chưa gắn engine DAST thật – tránh “over promise” với khách hàng.',
      '  </p>',
      '  <input id="vsp-dast-url" placeholder="https://example.com" ',
      '         style="width:260px;border-radius:999px;border:none;padding:6px 12px;font-size:13px;background:#020617;color:#e5e7eb;">',
      '  <button class="vsp-btn-secondary" id="vsp-dast-run-btn" disabled>',
      '    Start DAST (coming soon)',
      '  </button>',
      '</div>'
    ].join('');

    pane.appendChild(div);

    var btn  = div.querySelector('#vsp-run-local-btn');
    var stat = div.querySelector('#vsp-run-local-status');
    if (!btn) return;

    btn.addEventListener('click', function () {
      if (btn.disabled) return;
      btn.disabled = true;
      stat.textContent = 'Đang gửi yêu cầu run LOCAL…';

      fetch('/api/vsp/run', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'local', profile: cfg.profile || 'FULL_EXT' })
      }).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json().catch(function () { return {}; });
      }).then(function (res) {
        btn.disabled = false;
        if (res.ok) {
          stat.textContent = 'Đã trigger run: ' + (res.run_id || '(không rõ run_id)');
          stat.style.color = '#bbf7d0';
        } else {
          stat.textContent = 'API /api/vsp/run trả về ok=false hoặc chưa implement đầy đủ.';
          stat.style.color = '#fecaca';
        }
      }).catch(function (err) {
        btn.disabled = false;
        stat.textContent = 'Không gọi được /api/vsp/run: ' + err.message + ' (backend có thể chưa implement).';
        stat.style.color = '#fecaca';
        console.error('[VSP_SETTINGS_ADV] run error', err);
      });
    });
  }

  onReady(function () {
    var pane = document.getElementById('vsp-settings-main');
    if (!pane) return;

    fetchJSON('/api/vsp/settings_ui_v1')
      .then(function (data) {
        console.log('[VSP_SETTINGS_ADV] settings_ui_v1 =', data);
        renderAdvanced(data);
      })
      .catch(function (err) {
        console.error('[VSP_SETTINGS_ADV] failed to load settings_ui_v1:', err);
        renderAdvanced({ settings: {} });
      });
  });

})();
