// VSP 2025 - legacy charts stub
// Các chart chính đã chuyển sang vsp_dashboard_live_v2.js,
// file này chỉ để tránh 404 trong template cũ.
console.log("[VSP] vsp_charts_full_is1.js stub loaded.");
