
function vspNormalizeTopModule(m) {
  if (!m) return 'N/A';
  if (typeof m === 'string') return m;
  try {
    if (m.label) return String(m.label);
    if (m.path) return String(m.path);
    if (m.id)   return String(m.id);
    return String(m);
  } catch (e) {
    return 'N/A';
  }
}

'use strict';

(function () {
  const LOG = '[VSP_DASHBOARD_CHARTS]';

  function percent(part, total) {
    if (!total || total <= 0) return 0;
    return Math.round((part * 100) / total);
  }

  function renderSeverity(model) {
    const host = document.getElementById('vsp-chart-severity');
    if (!host) return;

    const sev =
      model.severity_cards ||
      model.summary_by_severity ||
      {};
    const total =
      model.total_findings ??
      model.total ??
      0;

    const order = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO', 'TRACE'];
    const labels = {
      CRITICAL: 'Critical',
      HIGH: 'High',
      MEDIUM: 'Medium',
      LOW: 'Low',
      INFO: 'Info',
      TRACE: 'Trace'
    };

    const rows = order.map(k => {
      const v = sev[k] ?? 0;
      const p = percent(v, total);
      return `
        <div class="vsp-chart-row">
          <div class="vsp-chart-label">${labels[k]}</div>
          <div class="vsp-chart-bar-wrap">
            <div class="vsp-chart-bar" style="width:${p}%;"></div>
          </div>
          <div class="vsp-chart-value">${v} (${p}%)</div>
        </div>
      `;
    }).join('');

    host.innerHTML = rows || '<div class="vsp-chart-empty">Chưa có dữ liệu severity.</div>';
  }

  function renderTopTool(model) {
    const host = document.getElementById('vsp-chart-tool');
    if (!host) return;

    const top = model.top_risky_tool_detail || model.top_risky_tool;
    if (!top || typeof top === 'string') {
      host.innerHTML = '<div class="vsp-chart-empty">Dữ liệu chi tiết theo tool chưa sẵn có.</div>';
      return;
    }

    const entries = Array.isArray(top) ? top : Object.entries(top);

    const rows = entries.map(([name, count]) => {
      const v = typeof count === 'number' ? count : (count.total || 0);
      return `
        <div class="vsp-chart-row">
          <div class="vsp-chart-label">${name}</div>
          <div class="vsp-chart-bar-wrap">
            <div class="vsp-chart-bar" style="width:100%;"></div>
          </div>
          <div class="vsp-chart-value">${v}</div>
        </div>
      `;
    }).join('');

    host.innerHTML = rows || '<div class="vsp-chart-empty">Không có dữ liệu tool.</div>';
  }

  function renderTopCwe(model) {
    const host = document.getElementById('vsp-chart-cwe');
    if (!host) return;

    const top = model.top_cwe_detail || model.top_impacted_cwe;
    if (!top || typeof top === 'string') {
      host.innerHTML = '<div class="vsp-chart-empty">Dữ liệu chi tiết theo CWE chưa sẵn có.</div>';
      return;
    }

    const entries = Array.isArray(top) ? top : Object.entries(top);

    const rows = entries.map(([name, count]) => {
      const v = typeof count === 'number' ? count : (count.total || 0);
      return `
        <div class="vsp-chart-row">
          <div class="vsp-chart-label">${name}</div>
          <div class="vsp-chart-bar-wrap">
            <div class="vsp-chart-bar" style="width:100%;"></div>
          </div>
          <div class="vsp-chart-value">${v}</div>
        </div>
      `;
    }).join('');

    host.innerHTML = rows || '<div class="vsp-chart-empty">Không có dữ liệu CWE.</div>';
  }

  function render(model) {
    if (!model) return;
    console.log(LOG, 'Render charts from model');
    renderSeverity(model);
    renderTopTool(model);
    renderTopCwe(model);
  }

  window.vspRenderChartsFromDashboard = render;

  document.addEventListener('DOMContentLoaded', function () {
    if (window.VSP_DASHBOARD_MODEL) {
      render(window.VSP_DASHBOARD_MODEL);
    }
  });
})();
