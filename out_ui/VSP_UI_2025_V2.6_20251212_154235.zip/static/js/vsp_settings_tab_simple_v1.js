(function () {
  var API_URL = "/api/vsp/settings_ui_v1";
  var hydrated = false;

  function hydratePane() {
    if (hydrated) return;
    var pane = document.getElementById("vsp-tab-settings");
    if (!pane) return;

    hydrated = true;

    pane.innerHTML =
      '<div class="vsp-section-header">' +
        '<div>' +
          '<h2 class="vsp-section-title">Settings</h2>' +
          '<p class="vsp-section-subtitle">Cấu hình SECURITY_BUNDLE (settings_ui_v1)</p>' +
        '</div>' +
      '</div>' +
      '<div class="vsp-card">' +
        '<pre id="vsp-settings-pre">{\n  "ok": false,\n  "settings": {}\n}</pre>' +
      '</div>';

    var pre = document.getElementById("vsp-settings-pre");
    if (!pre) return;

    fetch(API_URL, { cache: "no-store" })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        console.log("[VSP_SETTINGS_TAB_V2] settings_ui_v1 loaded.", data);
        try {
          pre.textContent = JSON.stringify(data, null, 2);
        } catch (e) {
          pre.textContent = "Lỗi format JSON settings_ui_v1.";
        }
      })
      .catch(function (err) {
        console.error("[VSP_SETTINGS_TAB_V2] Failed to load settings_ui_v1:", err);
        pre.textContent = "Lỗi gọi API settings_ui_v1.";
      });
  }

  window.vspInitSettingsTab = hydratePane;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", hydratePane);
  } else {
    hydratePane();
  }
})();
