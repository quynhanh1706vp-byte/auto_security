;(function () {
  const LOG_PREFIX = "[VSP_DASH_FINDINGS]";
  console.log(LOG_PREFIX, "Stub loaded – Dashboard findings zone is disabled in this build.");
  // Bản thương mại V1: không inject extra findings zone để giữ layout gọn.
  // Khi nào muốn bật lại, sẽ viết lại file này theo spec mới.
})();
