;(function () {
  const LOG_PREFIX = "[VSP_RUNS_KPI_INJECT]";

  function injectRunsKpiZone() {
    const pane = document.getElementById("vsp-tab-runs");
    if (!pane) {
      console.log(LOG_PREFIX, "Không tìm thấy #vsp-tab-runs – skip.");
      return;
    }

    // Tránh chèn trùng nhiều lần
    if (document.getElementById("vsp-runs-kpi-zone")) {
      console.log(LOG_PREFIX, "KPI zone đã tồn tại – bỏ qua.");
      return;
    }

    const wrapper = document.createElement("section");
    wrapper.id = "vsp-runs-kpi-zone";
    wrapper.className = "vsp-section vsp-section-stack vsp-runs-kpi-zone";

    wrapper.innerHTML = `
      <div class="vsp-section-header">
        <div>
          <h2 class="vsp-section-title">Runs overview</h2>
          <p class="vsp-section-subtitle">
            Tổng quan số lần scan, CRIT/HIGH và trung bình findings mỗi run.
          </p>
        </div>
      </div>

      <div class="vsp-grid vsp-grid-3">
        <div class="vsp-card vsp-card-soft">
          <div class="vsp-kpi-label">Total runs</div>
          <div class="vsp-kpi-value" id="vsp-runs-kpi-total">0</div>
        </div>

        <div class="vsp-card vsp-card-soft">
          <div class="vsp-kpi-label">Critical + High</div>
          <div class="vsp-kpi-value" id="vsp-runs-kpi-crit-high">0</div>
        </div>

        <div class="vsp-card vsp-card-soft">
          <div class="vsp-kpi-label">Avg findings / run</div>
          <div class="vsp-kpi-value" id="vsp-runs-kpi-avg">0.0</div>
        </div>
      </div>
    `;

    // Chèn lên đầu nội dung tab Runs (trước bảng, filter đang có)
    if (pane.firstChild) {
      pane.insertBefore(wrapper, pane.firstChild);
    } else {
      pane.appendChild(wrapper);
    }

    console.log(LOG_PREFIX, "Injected KPI zone vào #vsp-tab-runs.");
  }

  function init() {
    injectRunsKpiZone();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  console.log(LOG_PREFIX, "vsp_runs_tab_kpi_inject_v1.js loaded.");
})();
