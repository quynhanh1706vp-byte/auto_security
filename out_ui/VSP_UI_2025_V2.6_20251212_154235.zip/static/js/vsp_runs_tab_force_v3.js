'use strict';

(function () {
  const LOG = '[VSP_RUNS_FORCE_V3]';
  const ROOT_ID = 'vsp-runs-root';

  function $(id) {
    return document.getElementById(id);
  }

  function fmtDate(s) {
    if (!s) return '';
    try {
      // chấp mọi format ISO cơ bản
      const d = new Date(s);
      if (Number.isNaN(d.getTime())) return s;
      return d.toLocaleString();
    } catch (e) {
      return s;
    }
  }

  function renderError(msg) {
    const root = $(ROOT_ID);
    if (!root) return;
    root.innerHTML = `
      <div class="vsp-empty vsp-error">
        <div class="vsp-empty-title">Không tải được danh sách runs</div>
        <div class="vsp-empty-subtitle">${msg}</div>
      </div>
    `;
  }

  function renderEmpty() {
    const root = $(ROOT_ID);
    if (!root) return;
    root.innerHTML = `
      <div class="vsp-empty">
        <div class="vsp-empty-title">Chưa có run nào</div>
        <div class="vsp-empty-subtitle">Hãy chạy VSP FULL / QUICK rồi refresh tab Runs &amp; Reports.</div>
      </div>
    `;
  }

  function renderRuns(model) {
    const root = $(ROOT_ID);
    if (!root) return;

    const items = model && (model.items || model.runs || model.data || []);
    if (!items || !items.length) {
      renderEmpty();
      return;
    }

    const rows = items.map((r, idx) => {
      const id = r.run_id || r.id || `(run #${idx + 1})`;
      const dtStart = fmtDate(r.dt_started || r.dt_started_utc || r.started_at);
      const dtEnd   = fmtDate(r.dt_finished || r.dt_finished_utc || r.finished_at);
      const total   =
        (r.total_findings !== undefined ? r.total_findings :
        r.total ||
        (r.summary && (r.summary.total_findings || r.summary.total)) ||
        '');
      const gate =
        r.gate_color || r.gate || r.status || r.result || '';

      return `
        <tr class="vsp-table-row">
          <td class="vsp-cell-mono">${id}</td>
          <td>${dtStart || '-'}</td>
          <td>${dtEnd || '-'}</td>
          <td class="vsp-cell-number">${total === '' ? '-' : total}</td>
          <td>${gate || '-'}</td>
        </tr>
      `;
    }).join('');

    root.innerHTML = `
      <div class="vsp-table-wrapper">
        <table class="vsp-table">
          <thead>
            <tr>
              <th>Run ID</th>
              <th>Bắt đầu</th>
              <th>Kết thúc</th>
              <th>Tổng findings</th>
              <th>Gate / Status</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>
      </div>
    `;
  }

  async function loadRuns() {
    const root = $(ROOT_ID);
    if (!root) {
      console.warn(LOG, 'Không thấy #'+ROOT_ID+' – bỏ qua.');
      return;
    }

    root.innerHTML = `
      <div class="vsp-empty">
        <div class="vsp-empty-title">Đang tải Runs &amp; Reports...</div>
        <div class="vsp-empty-subtitle">Gọi /api/vsp/runs_index_v3?limit=50</div>
      </div>
    `;

    const url = '/api/vsp/runs_index_v3?limit=50';
    console.log(LOG, 'Fetching', url);
    try {
      const res = await fetch(url, { credentials: 'same-origin' });
      if (!res.ok) {
        throw new Error('HTTP ' + res.status);
      }
      const data = await res.json();
      console.log(LOG, 'Model:', data);
      renderRuns(data);
    } catch (err) {
      console.error(LOG, 'Load runs error:', err);
      renderError(err.message || String(err));
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    const root = $(ROOT_ID);
    if (!root) {
      console.warn(LOG, 'DOMContentLoaded nhưng không thấy #'+ROOT_ID);
      return;
    }
    console.log(LOG, 'initialized, auto load runs.');
    loadRuns();
    // cho phép console / script khác gọi lại nếu cần
    window.vspReloadRuns = loadRuns;
  });
})();
