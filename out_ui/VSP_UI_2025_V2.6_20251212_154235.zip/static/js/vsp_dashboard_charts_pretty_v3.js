(function () {
  console.log("[VSP_CHARTS_V3] pretty charts loaded (FULL)");

  const CH = {};
  window.VSP_CHARTS_V3 = CH;

  CH.updateFromDashboard = function (data) {
    try {
      drawSeverityDonut(data);
      drawFindingsTrend(data);
      drawCriticalHighByTool(data);
      drawTopCweExposure(data);
    } catch (e) {
      console.error("[VSP_CHARTS_V3] update error:", e);
    }
  };

  function getCanvas(id) {
    var el = document.getElementById(id);
    if (!el) return null;
    // Nếu là <div>, tìm <canvas> bên trong
    if (el.tagName && el.tagName.toLowerCase() === 'canvas') return el;
    return el.querySelector('canvas') || el;
  }

  // ===== 1) DONUT SEVERITY =====
  function drawSeverityDonut(data) {
    var sev = data.by_severity || {};
    var labels = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "TRACE"];
    var values = labels.map(function (k) { return sev[k] || 0; });

    var ctx = getCanvas("vsp-chart-severity-donut");
    if (!ctx || typeof Chart === 'undefined') return;

    new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: labels,
        datasets: [{
          data: values,
          backgroundColor: [
            "#fb3748", "#fb923c", "#facc15", "#22c55e", "#3b82f6", "#9ca3af"
          ],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        cutout: "65%"
      }
    });
  }

  // ===== 2) TREND TOTAL FINDINGS =====
  function drawFindingsTrend(data) {
    var trend = data.trend_by_run || data.trend || [];
    if (!Array.isArray(trend)) trend = [];

    var ctx = getCanvas("vsp-chart-findings-trend");
    if (!ctx || typeof Chart === 'undefined') return;

    new Chart(ctx, {
      type: "line",
      data: {
        labels: trend.map(function (r) { return r.run_id || ""; }),
        datasets: [{
          label: "Total findings",
          data: trend.map(function (r) { return r.total_findings || r.total || 0; }),
          tension: 0.3,
          fill: true
        }]
      },
      options: { responsive: true, plugins: { legend: { display: false } } }
    });
  }

  // ===== 3) CRITICAL/HIGH BY TOOL =====
  function drawCriticalHighByTool(data) {
    var tools = data.by_tool || [];
    if (!Array.isArray(tools)) tools = [];

    var labels = tools.map(function (t) { return t.tool || t.name || ""; });
    var crit = tools.map(function (t) { return (t.by_severity && t.by_severity.CRITICAL) || t.CRITICAL || 0; });
    var high = tools.map(function (t) { return (t.by_severity && t.by_severity.HIGH) || t.HIGH || 0; });

    var ctx = getCanvas("vsp-chart-critical-high-by-tool");
    if (!ctx || typeof Chart === 'undefined') return;

    new Chart(ctx, {
      type: "bar",
      data: {
        labels: labels,
        datasets: [
          { label: "CRIT", data: crit },
          { label: "HIGH", data: high }
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: true } }
      }
    });
  }

  // ===== 4) TOP CWE EXPOSURE =====
  function drawTopCweExposure(data) {
    var arr = data.top_cwe_list || [];
    if (!Array.isArray(arr)) arr = [];

    var ctx = getCanvas("vsp-chart-top-cwe-exposure");
    if (!ctx || typeof Chart === 'undefined') return;

    new Chart(ctx, {
      type: "bar",
      data: {
        labels: arr.map(function (x) { return x.cwe || ""; }),
        datasets: [{
          label: "Findings",
          data: arr.map(function (x) { return x.count || x.total || 0; })
        }]
      },
      options: {
        indexAxis: "y",
        responsive: true,
        plugins: { legend: { display: false } }
      }
    });
  }

})();
