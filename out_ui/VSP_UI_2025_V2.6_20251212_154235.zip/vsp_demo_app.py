from api.vsp_run_export_api_v3 import bp_run_export_v3
from api.vsp_settings_rules_v1 import bp_settings_rules
#!/usr/bin/env python
import os
import subprocess
from pathlib import Path

from vsp_run_picker_v1 import pick_dashboard_run, OUT_DIR
from flask import (
    Flask,
    render_template,
    request,
    jsonify,
    Response,
)
import requests

# === Config chung ===
ROOT = Path(__file__).resolve().parents[1]  # /home/test/Data/SECURITY_BUNDLE
CORE_BASE = "http://localhost:8961"         # Core API (dashboard_v3, runs_index_v3, datasource_v2)

app = Flask(
    __name__,
    static_folder="static",
    template_folder="templates",
)


# === Helper proxy sang core 8961 ===
def proxy_get(path: str) -> Response:
    """
    Proxy GET từ 8910 -> 8961, giữ nguyên query string.
    """
    core_url = CORE_BASE + path
    try:
        resp = requests.get(core_url, params=request.args, timeout=60)
    except Exception as e:
        return jsonify(ok=False, error=f"Proxy error to core {core_url}: {e}"), 502

    headers = {}
    ct = resp.headers.get("Content-Type")
    if ct:
        headers["Content-Type"] = ct
    return Response(resp.content, status=resp.status_code, headers=headers)


# === Routes UI chính ===

@app.route("/")
def index():
    # Trang VSP 5 tab (index.html đã là layout mới)
    return render_template('vsp_dashboard_2025.html')


@app.route("/security_bundle")
def security_bundle():
    # Giữ route cũ nếu có chỗ nào gọi
    return render_template('vsp_dashboard_2025.html')


# === Proxy API: dashboard_v3, runs_index_v3, datasource_v2 ===



    try:
        root = pathlib.Path(__file__).resolve().parents[1]
        out_dir = root / "out"
        if not out_dir.is_dir():
            return jsonify(ok=False, error="no_out_dir"), 404

        ci_runs = sorted(
            [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_VSP_CI_")]
        )
        if not ci_runs:
            return jsonify(ok=False, error="no_ci_runs"), 404

        latest = ci_runs[-1]
        snap_path = latest / "report" / "ci_snapshot.json"
        flag_path = latest / "report" / "ci_flag_has_findings.env"

        snap_data = {}
        if snap_path.is_file():
            try:
                snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
            except Exception as e:
                app.logger.error("[CI_SNAPSHOT_API] Lỗi đọc %s: %s", snap_path, e)

        has_flag = None
        if flag_path.is_file():
            try:
                for line in flag_path.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith("has_findings="):
                        v = line.split("=", 1)[1].strip()
                        has_flag = (v == "1")
                        break
            except Exception as e:
                app.logger.error("[CI_SNAPSHOT_API] Lỗi đọc %s: %s", flag_path, e)

        # Ưu tiên has_findings từ snapshot, fallback sang flag
        has_findings = snap_data.get("has_findings", has_flag)

        resp = {
            "ok": True,
            "run_id": snap_data.get("run_id", latest.name),
            "ci_run_dir": latest.name,
            "source": snap_data.get("source", "CI"),
            "has_findings": bool(has_findings) if has_findings is not None else None,
            "total_findings": snap_data.get("total_findings"),
            "by_severity": snap_data.get("by_severity", {}),
            "top_tools": snap_data.get("top_tools", []),
            "top_cwe": snap_data.get("top_cwe", []),
            "generated_at": snap_data.get("generated_at"),
            "raw": snap_data,
        }
        return jsonify(resp)
    except Exception as e:
        app.logger.exception("[CI_SNAPSHOT_API] Exception: %s", e)
        return jsonify(ok=False, error="exception", detail=str(e)), 500




    ci_runs = sorted(
        [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_VSP_CI_")]
    )
    if not ci_runs:
        return jsonify(ok=False, error="no_ci_runs"), 404

    latest = ci_runs[-1]
    snap_path = latest / "report" / "ci_snapshot.json"
    flag_path = latest / "report" / "ci_flag_has_findings.env"

    if not snap_path.is_file():
        return jsonify(ok=False, error="no_ci_snapshot", run_dir=latest.name), 404

    try:
        snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
    except Exception as e:
        app.logger.exception("[CI_SNAPSHOT_API_V2] Lỗi parse %s: %s", snap_path, e)
        return jsonify(ok=False, error="invalid_snapshot_json", run_dir=latest.name), 500

    has_flag = None
    if flag_path.is_file():
        try:
            for line in flag_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("has_findings="):
                    v = line.split("=", 1)[1].strip()
                    has_flag = (v == "1")
                    break
        except Exception as e:
            app.logger.error("[CI_SNAPSHOT_API_V2] Lỗi đọc %s: %s", flag_path, e)

    has_findings = snap_data.get("has_findings", has_flag)

    resp = {
        "ok": True,
        "run_id": snap_data.get("run_id", latest.name),
        "ci_run_dir": latest.name,
        "source": snap_data.get("source", "CI"),
        "has_findings": bool(has_findings) if has_findings is not None else None,
        "total_findings": snap_data.get("total_findings"),
        "by_severity": snap_data.get("by_severity", {}),
        "top_tools": snap_data.get("top_tools", []),
        "top_cwe": snap_data.get("top_cwe", []),
        "generated_at": snap_data.get("generated_at"),
    }
    return jsonify(resp)


@app.route("/api/vsp/ci_snapshot_latest", methods=["GET"])
def vsp_ci_snapshot_latest():
    """
    Trả về snapshot CI mới nhất:
    - Chọn RUN_VSP_CI_* mới nhất trong out/
    - Đọc report/ci_snapshot.json + ci_flag_has_findings.env
    """
    import json
    import pathlib

    root = pathlib.Path(__file__).resolve().parents[1]
    out_dir = root / "out"

    if not out_dir.is_dir():
        return jsonify(ok=False, error="no_out_dir"), 404

    ci_runs = sorted(
        [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_VSP_CI_")]
    )
    if not ci_runs:
        return jsonify(ok=False, error="no_ci_runs"), 404

    latest = ci_runs[-1]
    snap_path = latest / "report" / "ci_snapshot.json"
    flag_path = latest / "report" / "ci_flag_has_findings.env"

    if not snap_path.is_file():
        return jsonify(ok=False, error="no_ci_snapshot", run_dir=latest.name), 404

    try:
        snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
    except Exception as e:
        app.logger.exception("[CI_SNAPSHOT_API_V2] Lỗi parse %s: %s", snap_path, e)
        return jsonify(ok=False, error="invalid_snapshot_json", run_dir=latest.name), 500

    has_flag = None
    if flag_path.is_file():
        try:
            for line in flag_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("has_findings="):
                    v = line.split("=", 1)[1].strip()
                    has_flag = (v == "1")
                    break
        except Exception as e:
            app.logger.error("[CI_SNAPSHOT_API_V2] Lỗi đọc %s: %s", flag_path, e)

    has_findings = snap_data.get("has_findings", has_flag)

    resp = {
        "ok": True,
        "run_id": snap_data.get("run_id", latest.name),
        "ci_run_dir": latest.name,
        "source": snap_data.get("source", "CI"),
        "has_findings": bool(has_findings) if has_findings is not None else None,
        "total_findings": snap_data.get("total_findings"),
        "by_severity": snap_data.get("by_severity", {}),
        "top_tools": snap_data.get("top_tools", []),
        "top_cwe": snap_data.get("top_cwe", []),
        "generated_at": snap_data.get("generated_at"),
    }
    return jsonify(resp)


@app.route("/api/vsp/dashboard_delta_latest", methods=["GET"])
def vsp_dashboard_delta_latest():
    """
    Lightweight API: so sánh run mới nhất với run liền trước
    dựa trên out/summary_by_run.json.
    """
    import os, json, datetime as _dt

    root = os.path.dirname(os.path.dirname(__file__))
    summary_path = os.path.join(root, "out", "summary_by_run.json")

    if not os.path.exists(summary_path):
        return jsonify({"ok": False, "error": "summary_by_run.json not found"}), 404

    try:
        with open(summary_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        return jsonify({"ok": False, "error": "failed to load summary_by_run.json: %s" % e}), 500

    # Chuẩn hoá list run
    if isinstance(data, dict):
        items = list(data.get("runs") or data.get("items") or data.values())
    else:
        items = list(data or [])

    if not items:
        return jsonify({"ok": False, "error": "no runs in summary_by_run.json"}), 200

    def extract_ts(item):
        meta = item.get("meta") or {}
        for key in ("started_at", "created_at", "generated_at"):
            v = meta.get(key) or item.get(key)
            if isinstance(v, str):
                try:
                    return _dt.datetime.fromisoformat(v.replace("Z", ""))
                except Exception:
                    pass
        # Fallback: dùng run_id như timestamp thô
        rid = str(item.get("run_id") or "")
        try:
            return _dt.datetime.strptime(rid[-15:], "%Y%m%d_%H%M%S")
        except Exception:
            return _dt.datetime.min

    def is_full_ext(item):
        profile = (item.get("profile") or item.get("mode") or "").upper()
        rid = (item.get("run_id") or "").upper()
        return ("FULL_EXT" in profile) or ("FULL_EXT" in rid)

    full_ext = [it for it in items if is_full_ext(it)]
    source_items = full_ext if len(full_ext) >= 2 else items

    source_items = [it for it in source_items if isinstance(it, dict)]
    if len(source_items) < 2:
        return jsonify({"ok": False, "error": "not enough runs for delta"}), 200

    source_items.sort(
        key=lambda it: (extract_ts(it), str(it.get("run_id") or "")),
        reverse=True,
    )

    current, previous = source_items[0], source_items[1]

    def pick_num(it, keys, default=0):
        for k in keys:
            v = it.get(k)
            if isinstance(v, (int, float)):
                return v
        summary_all = it.get("summary_all") or {}
        for k in keys:
            v = summary_all.get(k)
            if isinstance(v, (int, float)):
                return v
        return default

    cur_total = pick_num(current, ["total_findings", "findings_total"])
    prev_total = pick_num(previous, ["total_findings", "findings_total"])

    cur_score = pick_num(current, ["security_posture_score", "security_score", "score"])
    prev_score = pick_num(previous, ["security_posture_score", "security_score", "score"])

    delta_total = None if (cur_total is None or prev_total is None) else cur_total - prev_total
    delta_score = None if (cur_score is None or prev_score is None) else cur_score - prev_score

    resp = {
        "ok": True,
        "current": {
            "run_id": current.get("run_id"),
            "total_findings": cur_total,
            "security_posture_score": cur_score,
        },
        "previous": {
            "run_id": previous.get("run_id"),
            "total_findings": prev_total,
            "security_posture_score": prev_score,
        },
        "delta": {
            "total_findings": delta_total,
            "security_posture_score": delta_score,
        },
    }
    return jsonify(resp)
@app.route("/api/vsp/dashboard_v3", methods=["GET"])
def api_vsp_dashboard_v3():

    # [VSP_UI_DASHBOARD_V3_LATEST_JSON_PATCH] Ưu tiên đọc file out/vsp_dashboard_v3_latest.json nếu tồn tại
    try:
        import json, pathlib
        from flask import jsonify
        ui_root = pathlib.Path(__file__).resolve().parent
        root = ui_root.parent  # /home/test/Data/SECURITY_BUNDLE
        latest_path = root / "out" / "vsp_dashboard_v3_latest.json"
        if latest_path.is_file():
            model = json.loads(latest_path.read_text(encoding="utf-8"))
            return jsonify(model)
    except Exception as e:  # noqa: E722
        try:
            from flask import current_app
            current_app.logger.warning("VSP_UI_DASHBOARD_V3_LATEST_JSON_PATCH failed: %r", e)
        except Exception:
            print("VSP_UI_DASHBOARD_V3_LATEST_JSON_PATCH failed:", repr(e))
    return proxy_get("/api/vsp/dashboard_v3")






@app.route("/api/vsp/runs_index_v3")
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    - KPI + trend: cố gắng lấy từ out/summary_by_run.json (nếu có).
    - Danh sách runs (items): *không phụ thuộc* vào summary_by_run.json,
      mà tự quét out/RUN_*/report/findings_unified.json.
    """
    import json
    import datetime
    from pathlib import Path
    from flask import request, jsonify

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    kpi = {}
    trend = []

    # (1) Đọc KPI + trend (nếu có)
    if summary_path.exists():
        try:
            with summary_path.open("r", encoding="utf-8") as f:
                summary = json.load(f)
            if isinstance(summary, dict):
                kpi = summary.get("kpi") or {}
                trend = summary.get("trend_crit_high") or summary.get("trend") or []
        except Exception:
            pass

    # (2) Build items bằng cách duyệt RUN_* + findings_unified.json
    items = []

    run_dirs = [
        p for p in out_dir.iterdir()
        if p.is_dir() and p.name.startswith("RUN_")
    ]
    run_dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    for run_dir in run_dirs:
        run_id = run_dir.name
        report_dir = run_dir / "report"
        findings_file = report_dir / "findings_unified.json"
        summary_file = report_dir / "summary_unified.json"

        if not findings_file.exists() and not summary_file.exists():
            continue

        total_findings = None
        run_type = "UNKNOWN"
        source = "FULL_EXT"
        score = None
        started_at = None

        # (2a) Ưu tiên lấy total_findings từ findings_unified.json
        if findings_file.exists():
            try:
                with findings_file.open("r", encoding="utf-8") as f:
                    fd = json.load(f)
                if isinstance(fd, dict):
                    if isinstance(fd.get("items"), list):
                        items_list = fd["items"]
                        total_findings = int(fd.get("total", len(items_list)))
                    elif isinstance(fd.get("findings"), list):
                        items_list = fd["findings"]
                        total_findings = len(items_list)
                elif isinstance(fd, list):
                    total_findings = len(fd)
            except Exception:
                pass

        # (2b) Nếu vẫn chưa có total_findings, fallback sang summary_unified.json
        if total_findings is None and summary_file.exists():
            try:
                with summary_file.open("r", encoding="utf-8") as f:
                    s = json.load(f)
            except Exception:
                s = None

            if isinstance(s, dict):
                total_findings = (
                    s.get("summary_all", {}).get("total_findings")
                    if isinstance(s.get("summary_all"), dict)
                    else None
                )
                if total_findings is None:
                    total_findings = s.get("total_findings")

                if total_findings is None:
                    sev = None
                    if "summary_all" in s and isinstance(s["summary_all"], dict):
                        sev = s["summary_all"].get("by_severity")
                    if sev is None:
                        sev = s.get("by_severity")
                    if isinstance(sev, dict):
                        try:
                            total_findings = int(sum(int(v) for v in sev.values()))
                        except Exception:
                            total_findings = None

                run_profile = s.get("run_profile") if isinstance(s.get("run_profile"), dict) else {}
                run_type = run_profile.get("type") or run_profile.get("run_type") or run_type
                source = run_profile.get("source") or run_profile.get("source_type") or source
                score = s.get("security_posture_score")
                if score is None and isinstance(s.get("summary_all"), dict):
                    score = s["summary_all"].get("security_posture_score")
                started_at = run_profile.get("started_at") or run_profile.get("started") or started_at

        # (2c) Nếu vẫn không có total_findings thì bỏ run này
        if total_findings is None:
            continue

        # (2d) Nếu chưa có started_at thì lấy mtime thư mục
        if not started_at:
            try:
                dt = datetime.datetime.fromtimestamp(run_dir.stat().st_mtime)
                started_at = dt.isoformat(timespec="seconds")
            except Exception:
                started_at = ""

        item = {
            "run_id": run_id,
            "run_type": run_type,
            "source": source,
            "total_findings": int(total_findings),
            "security_posture_score": score if isinstance(score, (int, float)) else None,
            "started_at": started_at,
        }
        items.append(item)

    # (3) Áp dụng limit
    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50
    items_slice = items[:limit]

    # (4) Nếu chưa có KPI thì tự build
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = total_findings_sum / float(last_n) if last_n > 0 else 0.0
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    Ưu tiên:
    1) Đọc KPI + trend từ out/summary_by_run.json (nếu có).
    2) Tự quét thư mục out/RUN_* để build danh sách items (list run)
       nên không phụ thuộc schema summary_by_run.json nữa.
    """
    import json
    from pathlib import Path
    from flask import request, jsonify
    import os
    import datetime

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    kpi = {}
    trend = []

    # (1) Đọc KPI + trend (nếu có)
    if summary_path.exists():
        try:
            with summary_path.open("r", encoding="utf-8") as f:
                summary = json.load(f)
            if isinstance(summary, dict):
                kpi = summary.get("kpi") or {}
                trend = summary.get("trend_crit_high") or summary.get("trend") or []
        except Exception:
            pass

    # (2) Quét thư mục RUN_* để build items
    items = []

    # Duyệt tất cả thư mục RUN_* trong out/
    run_dirs = [p for p in out_dir.iterdir() if p.is_dir() and p.name.startswith("RUN_")]
    # Sắp xếp theo thời gian sửa đổi mới nhất (mới -> cũ)
    run_dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    for run_dir in run_dirs:
        run_id = run_dir.name
        report_dir = run_dir / "report"
        summary_file = report_dir / "summary_unified.json"
        if not summary_file.exists():
            continue

        try:
            with summary_file.open("r", encoding="utf-8") as f:
                s = json.load(f)
        except Exception:
            continue

        # Lấy total_findings
        total_findings = None
        # Ưu tiên các kiểu phổ biến
        if isinstance(s, dict):
            # Kiểu summary_all.total_findings
            total_findings = (
                s.get("summary_all", {}).get("total_findings")
                if isinstance(s.get("summary_all"), dict)
                else None
            )
            # Kiểu top-level total_findings
            if total_findings is None:
                total_findings = s.get("total_findings")

            # Nếu vẫn None, thử tính từ by_severity
            if total_findings is None:
                sev = None
                if "summary_all" in s and isinstance(s["summary_all"], dict):
                    sev = s["summary_all"].get("by_severity")
                if sev is None:
                    sev = s.get("by_severity")
                if isinstance(sev, dict):
                    try:
                        total_findings = int(sum(int(v) for v in sev.values()))
                    except Exception:
                        total_findings = None

            # Run type / source
            run_profile = s.get("run_profile") if isinstance(s.get("run_profile"), dict) else {}
            run_type = run_profile.get("type") or run_profile.get("run_type") or "UNKNOWN"
            source = run_profile.get("source") or run_profile.get("source_type") or "FULL_EXT"

            # Score nếu có
            score = s.get("security_posture_score")
            if score is None and isinstance(s.get("summary_all"), dict):
                score = s["summary_all"].get("security_posture_score")

            # Time nếu có
            started_at = run_profile.get("started_at") or run_profile.get("started") or None
        else:
            run_type = "UNKNOWN"
            source = "FULL_EXT"
            score = None
            started_at = None

        # Nếu vẫn chưa có total_findings, bỏ qua run này
        if total_findings is None:
            continue

        # Nếu không có started_at thì lấy mtime thư mục
        if not started_at:
            try:
                dt = datetime.datetime.fromtimestamp(run_dir.stat().st_mtime)
                started_at = dt.isoformat(timespec="seconds")
            except Exception:
                started_at = ""

        item = {
            "run_id": run_id,
            "run_type": run_type,
            "source": source,
            "total_findings": int(total_findings),
            "security_posture_score": score if isinstance(score, (int, float)) else None,
            "started_at": started_at,
        }
        items.append(item)

    # (3) Áp dụng limit
    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50
    items_slice = items[:limit]

    # (4) Nếu chưa có KPI thì tự build
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = total_findings_sum / float(last_n) if last_n > 0 else 0.0
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    Đọc summary_by_run.json trong SECURITY_BUNDLE/out và
    expose items + kpi + trend_crit_high cho UI.
    """
    import json
    from pathlib import Path
    from flask import request, jsonify

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    try:
        with summary_path.open("r", encoding="utf-8") as f:
            summary = json.load(f)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Missing {summary_path}"}), 500

    # Chuẩn hóa items theo nhiều kiểu schema khác nhau
    if isinstance(summary, dict):
        raw_items = (
            summary.get("items")
            or summary.get("by_run")
            or summary.get("runs")
            or summary.get("data")
        )
        if isinstance(raw_items, list):
            items = raw_items
        else:
            items = []
        kpi = summary.get("kpi") or {}
        trend = summary.get("trend_crit_high") or summary.get("trend") or []
    else:
        items = summary if isinstance(summary, list) else []
        kpi = {}
        trend = []

    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50

    items_slice = items[:limit]

    # Nếu summary_by_run.json chưa có kpi ⇒ tự tính KPI cơ bản
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = total_findings_sum / float(last_n) if last_n > 0 else 0.0
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    """
    Local implementation cho Runs & Reports tab (VSP 2025 UI demo).

    Đọc summary_by_run.json trong SECURITY_BUNDLE/out và
    expose items + kpi + trend_crit_high cho UI.
    """
    import json
    from pathlib import Path
    from flask import request, jsonify

    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"
    summary_path = out_dir / "summary_by_run.json"

    try:
        with summary_path.open("r", encoding="utf-8") as f:
            summary = json.load(f)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Missing {summary_path}"}), 500

    if isinstance(summary, dict):
        items = summary.get("items") or []
        kpi = summary.get("kpi") or {}
        trend = summary.get("trend_crit_high") or []
    else:
        items = summary
        kpi = {}
        trend = []

    try:
        limit = int(request.args.get("limit", 50))
    except Exception:
        limit = 50

    items_slice = items[:limit]

    # Nếu summary_by_run.json chưa có kpi ⇒ tự tính KPI cơ bản
    if not kpi:
        total_runs = len(items)
        last_n = min(total_runs, 20)
        if last_n > 0:
            last_items = items[:last_n]
            total_findings_sum = 0
            for it in last_items:
                try:
                    total_findings_sum += int(it.get("total_findings", 0))
                except Exception:
                    continue
            avg_last_n = (
                total_findings_sum / float(last_n) if last_n > 0 else 0.0
            )
        else:
            avg_last_n = 0.0

        kpi = {
            "total_runs": total_runs,
            "last_n": last_n,
            "avg_findings_per_run_last_n": avg_last_n,
        }

    return jsonify(
        {
            "ok": True,
            "items": items_slice,
            "kpi": kpi,
            "trend_crit_high": trend,
        }
    )
def api_vsp_runs_index_v3():
    return proxy_get("/api/vsp/runs_index_v3")



@app.route("/api/vsp/datasource_v2")
def api_vsp_datasource_v2():
    """
    Local implementation cho Data Source tab (VSP 2025 UI demo).

    Thay vì proxy sang core, route này đọc trực tiếp
    findings_unified.json của latest FULL_EXT run trong
    SECURITY_BUNDLE/out.
    """
    import json
    from pathlib import Path
    from flask import request, jsonify

    # SECURITY_BUNDLE root = parent của thư mục ui/
    root = Path(__file__).resolve().parent.parent
    out_dir = root / "out"

    dash_path = out_dir / "vsp_dashboard_v3_latest.json"
    try:
        with dash_path.open("r", encoding="utf-8") as f:
            dash = json.load(f)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Missing {dash_path}"}), 500

    latest_run = dash.get("latest_run_id")
    if not latest_run:
        return jsonify(
            {"ok": False, "error": "No latest_run_id in vsp_dashboard_v3_latest.json"}
        ), 500

    findings_path = out_dir / latest_run / "report" / "findings_unified.json"
    try:
        with findings_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return jsonify(
            {
                "ok": False,
                "error": f"Missing findings_unified.json for run {latest_run}",
            }
        ), 500

    # data có thể là list hoặc {items: [...], total: N}
    if isinstance(data, dict) and "items" in data:
        items = data.get("items") or []
        total = int(data.get("total", len(items)))
    else:
        items = data
        total = len(items)

    try:
        limit = int(request.args.get("limit", 100))
    except Exception:
        limit = 100

    items_slice = items[:limit]

    return jsonify(
        {
            "ok": True,
            "run_id": latest_run,
            "total": total,
            "limit": limit,
            "items": items_slice,
        }
    )
def api_vsp_datasource_v2():
    # Proxy đúng sang core, giữ nguyên run_dir, limit, filters,...
    return proxy_get("/api/vsp/datasource_v2")


# === RUN FULL SCAN EXT+ – gọi bin/vsp_selfcheck_full.sh ===

@app.route("/api/vsp/run_full_scan", methods=["POST", "OPTIONS"])
def api_vsp_run_full_scan():
    """
    Nhận JSON:
      {
        "profile": "EXT" | "FAST" | "AGGR" | "FULL" | ...,
        "source_root": "/home/test/Data/khach6",
        "target_url": "https://demo.demasterpro.com"
      }

    Gọi: bin/vsp_selfcheck_full.sh <profile> <source_root> <target_url>
    cwd = /home/test/Data/SECURITY_BUNDLE
    """
    if request.method == "OPTIONS":
        # Đơn giản trả 200 cho preflight nếu có
        return ("", 200)

    data = request.get_json(silent=True) or {}

    profile = data.get("profile") or "FULL_EXT"
    source_root = data.get("source_root") or data.get("src_path") or str(ROOT / "khach6")
    target_url = data.get("target_url") or data.get("url") or "https://demo.demasterpro.com"

    script = ROOT / "bin" / "vsp_selfcheck_full.sh"

    if not script.is_file():
        return jsonify(
            ok=False,
            error=f"Script không tồn tại: {script}",
        ), 500

    # Đảm bảo script có quyền execute
    try:
        os.chmod(str(script), 0o755)
    except Exception:
        pass

    try:
        proc = subprocess.Popen(
            [str(script), profile, source_root, target_url],
            cwd=str(ROOT),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as e:
        return jsonify(ok=False, error=f"Lỗi chạy {script}: {e}"), 500

    return jsonify(
        ok=True,
        pid=proc.pid,
        profile=profile,
        source_root=source_root,
        target_url=target_url,
    )


# === Healthcheck đơn giản (tuỳ chọn) ===
@app.route("/health")
def health():
    return jsonify(ok=True, app="vsp_demo_app", core=CORE_BASE)


# VSP_RUN_EXPORT_DIRECT_V1_BEGIN
from flask import send_file, request, jsonify, render_template
import io, json, zipfile, subprocess, shutil
from pathlib import Path

@app.route("/api/vsp/settings_v1", methods=["GET", "POST"])

def _settings_file_path():
    import os
    # Cho phép override bằng env nếu cần
    path = os.environ.get("VSP_SETTINGS_FILE")
    if path:
        return path
    return os.path.join(os.path.dirname(__file__), "config", "settings_v1.json")


def _load_settings_from_file():
    import json, os
    path = _settings_file_path()
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        # Nếu file hỏng thì trả rỗng để UI còn tự fill mặc định
        return {}


def _save_settings_to_file(data):
    import json, os
    path = _settings_file_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

@app.route("/api/vsp/settings_ui_v1", methods=["GET", "POST"])
def vsp_settings_ui_v1():
    """
    Settings API cho UI:
    - GET  -> trả JSON {ok: true, settings: {...}}
    - POST -> nhận {settings: {...}} hoặc object raw, lưu file rồi trả lại JSON.
    """
    from flask import request, jsonify

    if request.method == "GET":
        settings = _load_settings_from_file()
        return jsonify({"ok": True, "settings": settings})

    payload = request.get_json(silent=True) or {}
    # Nếu payload dạng {settings: {...}} thì lấy bên trong, còn không thì dùng cả object
    if isinstance(payload, dict) and "settings" in payload and isinstance(payload["settings"], dict):
        settings = payload["settings"]
    else:
        settings = payload

    _save_settings_to_file(settings)
    return jsonify({"ok": True, "settings": settings})


def vsp_settings_v1():
    """GET/POST settings trực tiếp trên gateway 8910 (lưu file JSON)."""
    if request.method == "GET":
        settings = _load_settings_from_file()
        return jsonify(ok=True, settings=settings)

    payload = request.get_json(silent=True) or {}
    try:
        _SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        _SETTINGS_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500
    return jsonify(ok=True)




    """
    UI-only wrapper cho file config/rule_overrides_v1.json.
    Dùng riêng cho tab Rules trên VSP_UI 2025.
    """
    import os, json, flask

    cfg_dir = os.path.join(os.path.dirname(__file__), "config")
    cfg_path = os.path.join(cfg_dir, "rule_overrides_v1.json")

    # POST: lưu overrides từ UI
    if flask.request.method == "POST":
        try:
            body = flask.request.get_json(force=True, silent=False)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc)), 400

        # Hỗ trợ các format:
        # - { "items": [...] }
        # - { "overrides": [...] }
        # - [ ... ]
        data = body
        if isinstance(body, dict):
            if "items" in body:
                data = body["items"]
            elif "overrides" in body:
                data = body["overrides"]

        os.makedirs(cfg_dir, exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return flask.jsonify(ok=True)

    # GET: đọc file, nếu chưa có thì trả [] để UI render bảng trống
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc), items=[], overrides=[], raw=None), 200
    else:
        raw = []

    # Chuẩn hóa: luôn có items + overrides
    if isinstance(raw, dict):
        items = raw.get("items") or raw.get("overrides") or raw
    else:
        items = raw

    return flask.jsonify(ok=True, items=items, overrides=items, raw=raw)
@app.route("/api/vsp/rule_overrides_ui_v1", methods=["GET", "POST", "OPTIONS"])
def vsp_rule_overrides_ui_v1():
    """
    UI-only wrapper cho file config/rule_overrides_v1.json.
    Dùng riêng cho tab Rules trên VSP_UI 2025.
    """
    import os, json, flask

    cfg_dir = os.path.join(os.path.dirname(__file__), "config")
    cfg_path = os.path.join(cfg_dir, "rule_overrides_v1.json")

    # POST: lưu overrides từ UI
    if flask.request.method == "POST":
        try:
            body = flask.request.get_json(force=True, silent=False)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc)), 400

        # Hỗ trợ các format:
        # - { "items": [...] }
        # - { "overrides": [...] }
        # - [ ... ]
        data = body
        if isinstance(body, dict):
            if "items" in body:
                data = body["items"]
            elif "overrides" in body:
                data = body["overrides"]

        os.makedirs(cfg_dir, exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return flask.jsonify(ok=True)

    # GET: đọc file, nếu chưa có thì trả [] để UI render bảng trống
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc), items=[], overrides=[], raw=None), 200
    else:
        raw = []

    # Chuẩn hóa: luôn có items + overrides
    if isinstance(raw, dict):
        items = raw.get("items") or raw.get("overrides") or raw
    else:
        items = raw

    return flask.jsonify(ok=True, items=items, overrides=items, raw=raw)

@app.route("/api/vsp/run_export_v3", methods=["GET"])
def vsp_run_export_v3():
    """
    Direct export HTML/ZIP/PDF/CSV cho 1 run - chạy trên UI gateway (8910).
    """
    from flask import request, jsonify, send_file
    import os, io, zipfile, json

    run_id = (request.args.get("run_id") or "").strip()
    fmt = (request.args.get("fmt") or "html").strip().lower()

    if not run_id:
        return jsonify({"ok": False, "error": "Missing run_id"}), 400

    # Thư mục out gốc: ưu tiên env VSP_OUT_ROOT, fallback ../out cạnh ui/
    base_out = os.environ.get("VSP_OUT_ROOT")
    if not base_out:
        base_out = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "out"))

    run_dir = os.path.join(base_out, run_id)
    if not os.path.isdir(run_dir):
        return jsonify({"ok": False, "error": f"Run dir not found: {run_dir}"}), 404

    report_dir = os.path.join(run_dir, "report")

    # HTML export
    if fmt == "html":
        candidates = [
            os.path.join(report_dir, "vsp_run_report_cio_v3.html"),
            os.path.join(report_dir, "vsp_run_report_cio_v2.html"),
            os.path.join(report_dir, "vsp_run_report_cio.html"),
            os.path.join(report_dir, "run_report.html"),
        ]
        for path in candidates:
            if os.path.isfile(path):
                return send_file(
                    path,
                    mimetype="text/html",
                    as_attachment=False,
                    download_name=os.path.basename(path),
                )

        # fallback – render summary_unified.json thành HTML đơn giản
        summary_path = os.path.join(report_dir, "summary_unified.json")
        summary = {}
        if os.path.isfile(summary_path):
            try:
                with open(summary_path, "r", encoding="utf-8") as f:
                    summary = json.load(f)
            except Exception:
                summary = {}

        body = json.dumps(
            summary or {"note": "No summary_unified.json found"},
            indent=2,
            ensure_ascii=False,
        )

        html = (
            "<html><head><meta charset='utf-8'>"
            "<title>VSP run {run_id}</title></head><body>"
            "<h1>VSP run {run_id}</h1>"
            "<pre>{body}</pre>"
            "</body></html>"
        ).format(run_id=run_id, body=body)

        return html

    # CSV export
    if fmt == "csv":
        csv_path = os.path.join(report_dir, "findings_unified.csv")
        if os.path.isfile(csv_path):
            return send_file(
                csv_path,
                mimetype="text/csv",
                as_attachment=True,
                download_name=f"{run_id}_findings.csv",
            )
        return jsonify({"ok": False, "error": "findings_unified.csv not found"}), 404

    # ZIP export
    if fmt == "zip":
        if not os.path.isdir(report_dir):
            return jsonify({"ok": False, "error": "report dir not found"}), 404

        mem = io.BytesIO()
        with zipfile.ZipFile(mem, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(report_dir):
                for fn in files:
                    full = os.path.join(root, fn)
                    rel = os.path.relpath(full, run_dir)
                    zf.write(full, rel)

        mem.seek(0)
        return send_file(
            mem,
            mimetype="application/zip",
            as_attachment=True,
            download_name=f"{run_id}_report.zip",
        )

    # PDF export (nếu có sẵn file PDF trong report/)
    if fmt == "pdf":
        if os.path.isdir(report_dir):
            for name in os.listdir(report_dir):
                if name.lower().endswith(".pdf"):
                    path = os.path.join(report_dir, name)
                    return send_file(
                        path,
                        mimetype="application/pdf",
                        as_attachment=True,
                        download_name=name,
                    )
        return jsonify({"ok": False, "error": "PDF report not found"}), 404

    return jsonify({"ok": False, "error": f"Unsupported fmt={fmt}"}), 400



@app.route("/api/vsp/run_fullscan_v1", methods=["POST"])
def vsp_run_fullscan_v1():
    """
    Nhận source_root / target_url / profile / mode từ UI,
    gọi shell wrapper vsp_run_fullscan_from_api_v1.sh chạy background.
    """
    import subprocess
    from pathlib import Path
    from flask import request, jsonify

    payload = request.get_json(force=True) or {}
    source_root = payload.get("source_root") or ""
    target_url = payload.get("target_url") or ""
    profile = payload.get("profile") or "FULL_EXT"
    mode = payload.get("mode") or "EXT_ONLY"

    wrapper = Path(__file__).resolve().parent.parent / "bin" / "vsp_run_fullscan_from_api_v1.sh"

    proc = subprocess.Popen(
        [str(wrapper), profile, mode, source_root, target_url],
        cwd=str(wrapper.parent.parent),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    app.logger.info("[VSP_RUN_FULLSCAN_API] payload=%s pid=%s", payload, proc.pid)

    return jsonify({
        "ok": True,
        "pid": proc.pid,
        "profile": profile,
        "mode": mode,
    })



@app.route("/api/vsp/rule_overrides_v1", methods=["GET", "POST"], endpoint="vsp_rule_overrides_v1_api_ui")
def vsp_rule_overrides_v1_api():
    """Simple file-based storage cho rule_overrides_v1.

    File lưu tại: ../config/rule_overrides_v1.json (tính từ thư mục ui/).
    """
    root = _VSP_Path2(__file__).resolve().parent.parent  # .../SECURITY_BUNDLE
    cfg_dir = root / "config"
    cfg_dir.mkdir(exist_ok=True)
    cfg_file = cfg_dir / "rule_overrides_v1.json"

    if request.method == "GET":
        if cfg_file.exists():
            try:
                data = _vsp_json2.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception as exc:  # pragma: no cover
                app.logger.warning("Invalid rule_overrides_v1.json: %s", exc)
                data = []
        else:
            data = []
        return jsonify(data)

    payload = request.get_json(force=True, silent=True)
    if payload is None:
        payload = []

    to_save = payload
    try:
        cfg_file.write_text(
            _vsp_json2.dumps(to_save, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception as exc:  # pragma: no cover
        app.logger.error("Cannot write rule_overrides_v1.json: %s", exc)
        return jsonify({"ok": False, "error": str(exc)}), 500

    return jsonify(to_save)

# === VSP Rule Overrides UI API stub V1 ===
from pathlib import Path as _VSP_Path_UI
import json as _vsp_json_ui



@app.route("/api/vsp/rule_overrides_ui_v1", methods=["GET", "POST"])
def vsp_rule_overrides_ui_v1_force():
    app.logger.info("[VSP_RULES_UI] stub handler active (vsp_rule_overrides_ui_v1_force)")
    root = _VSP_Path_UI2(__file__).resolve().parent.parent  # .../SECURITY_BUNDLE
    cfg_dir = root / "config"
    cfg_dir.mkdir(exist_ok=True)
    cfg_file = cfg_dir / "rule_overrides_v1.json"

    if request.method == "GET":
        if cfg_file.exists():
            try:
                data = _vsp_json_ui2.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception as exc:  # pragma: no cover
                app.logger.warning("Invalid rule_overrides_v1.json: %s", exc)
                data = []
        else:
            data = []
        return jsonify(data)

    payload = request.get_json(force=True, silent=True)
    if payload is None:
        payload = []

    to_save = payload
    try:
        cfg_file.write_text(
            _vsp_json_ui2.dumps(to_save, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception as exc:  # pragma: no cover
        app.logger.error("Cannot write rule_overrides_v1.json: %s", exc)
        return jsonify({"ok": False, "error": str(exc)}), 500

    return jsonify(to_save)




    """
    UI-only wrapper cho file config/rule_overrides_v1.json.
    Dùng riêng cho tab Rules trên VSP_UI 2025.
    """
    import os, json, flask

    cfg_dir = os.path.join(os.path.dirname(__file__), "config")
    cfg_path = os.path.join(cfg_dir, "rule_overrides_v1.json")

    # POST: lưu overrides từ UI
    if flask.request.method == "POST":
        try:
            body = flask.request.get_json(force=True, silent=False)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc)), 400

        # Hỗ trợ vài format:
        # - { "items": [...] }
        # - { "overrides": [...] }
        # - [ ... ]
        data = body
        if isinstance(body, dict):
            if "items" in body:
                data = body["items"]
            elif "overrides" in body:
                data = body["overrides"]

        os.makedirs(cfg_dir, exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return flask.jsonify(ok=True)

    # GET: đọc file, nếu chưa có thì trả [] để UI render bảng trống
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except Exception as exc:
            return flask.jsonify(ok=False, error=str(exc), items=[], overrides=[], raw=None), 200
    else:
        raw = []

    # Chuẩn hóa: luôn có items + overrides
    if isinstance(raw, dict):
        items = raw.get("items") or raw.get("overrides") or raw
    else:
        items = raw

    return flask.jsonify(ok=True, items=items, overrides=items, raw=raw)


@app.route("/api/vsp/dashboard_extras_v1")
def vsp_dashboard_extras_v1():
    """Extras cho Dashboard: top findings, noisy paths, CVE, by_tool – stub V1.

    V1 chỉ wrap lại /api/vsp/dashboard_v3 nếu có, để UI có data tối thiểu.
    Sau này có thể mở rộng để đọc trực tiếp findings_unified.json.
    """
    from flask import jsonify

    base = {}
    try:
        # Gọi lại dashboard_v3 để lấy latest_run_id, by_tool...
        with app.test_client() as c:
            r = c.get("/api/vsp/dashboard_v3")
            if r.is_json:
                base = r.get_json() or {}
    except Exception as e:
        base = {"error": str(e)}

    by_tool = (
        base.get("by_tool")
        or base.get("summary_by_tool")
        or {}
    )

    payload = {
        "ok": True,
        "latest_run_id": base.get("latest_run_id"),
        # Các field này V1 có thể rỗng, UI sẽ hiển thị 'No data'
        "top_risky": base.get("top_risky") or [],
        "top_noisy_paths": base.get("top_noisy_paths") or [],
        "top_cves": base.get("top_cves") or [],
        "by_tool_severity": by_tool,
    }
    return jsonify(payload)


@app.route("/api/vsp/datasource_export_v1")
def vsp_datasource_export_v1():
    """Export findings_unified cho Data Source – V1: JSON + CSV.

    - Nếu có run_dir trong query thì dùng run_dir đó.
    - Nếu không, dùng latest_run_id từ /api/vsp/dashboard_v3.
    """

    from flask import request, jsonify, send_file
    import json
    import csv
    import tempfile

    ui_root = Path(__file__).resolve().parent
    bundle_root = ui_root.parent
    out_root = bundle_root / "out"

    fmt = (request.args.get("fmt") or "json").strip().lower()
    run_dir_arg = (request.args.get("run_dir") or "").strip()

    run_dir = None

    if run_dir_arg:
        run_dir = Path(run_dir_arg)
    else:
        # Lấy latest_run_id từ dashboard_v3
        try:
            with app.test_client() as c:
                r = c.get("/api/vsp/dashboard_v3")
                if r.is_json:
                    data = r.get_json() or {}
                else:
                    data = {}
            latest_run_id = data.get("latest_run_id")
            if latest_run_id:
                run_dir = out_root / latest_run_id
        except Exception as e:
            return jsonify(ok=False, error=f"Không lấy được latest_run_id: {e}"), 500

    if run_dir is None:
        return jsonify(ok=False, error="Không xác định được run_dir"), 400

    if not run_dir.is_dir():
        return jsonify(ok=False, error=f"Run dir not found: {run_dir}"), 404

    report_dir = run_dir / "report"
    findings_path = report_dir / "findings_unified.json"

    if not findings_path.is_file():
        return jsonify(ok=False, error=f"Không tìm thấy findings_unified.json trong {report_dir}"), 404

    if fmt == "json":
        # Trả thẳng file JSON
        return send_file(
            findings_path,
            mimetype="application/json",
            as_attachment=True,
            download_name=f"{run_dir.name}_findings_unified.json",
        )

    if fmt == "csv":
        # Convert JSON -> CSV với các cột chuẩn
        try:
            items = json.loads(findings_path.read_text(encoding="utf-8"))
        except Exception as e:
            return jsonify(ok=False, error=f"Không đọc được JSON: {e}"), 500

        if not isinstance(items, list):
            return jsonify(ok=False, error="findings_unified.json không phải là list"), 500

        # Giữ schema giống Data Source ext columns
        fieldnames = [
            "severity",
            "tool",
            "rule",
            "path",
            "line",
            "message",
            "run",
            "cwe",
            "cve",
            "component",
            "tags",
            "fix",
        ]

        def norm_sev(s):
            if not s:
                return ""
            up = str(s).upper()
            known = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "TRACE"]
            return up if up in known else str(s)

        def extract_line(item):
            if "line" in item and item["line"] is not None:
                return item["line"]
            if "line_number" in item and item["line_number"] is not None:
                return item["line_number"]
            loc = item.get("location") or {}
            if isinstance(loc, dict) and "line" in loc:
                return loc["line"]
            return ""

        def extract_rule(item):
            for k in ["rule_id", "rule", "check_id", "check", "rule_name", "id"]:
                if k in item and item[k]:
                    return item[k]
            return ""

        def extract_msg(item):
            for k in ["message", "msg", "description", "title"]:
                if k in item and item[k]:
                    return item[k]
            return ""

        def extract_run(item):
            for k in ["run_id", "run", "run_ref"]:
                if k in item and item[k]:
                    return item[k]
            return ""

        def extract_cwe(item):
            if item.get("cwe"):
                return item["cwe"]
            if item.get("cwe_id"):
                return item["cwe_id"]
            if isinstance(item.get("cwe_list"), list) and item["cwe_list"]:
                return ",".join(map(str, item["cwe_list"]))
            return ""

        def extract_cve(item):
            if item.get("cve"):
                return item["cve"]
            for k in ["cve_list", "cves"]:
                v = item.get(k)
                if isinstance(v, list) and v:
                    return ",".join(map(str, v))
            return ""

        def extract_component(item):
            for k in ["component", "module", "package", "image"]:
                if item.get(k):
                    return item[k]
            return ""

        def extract_tags(item):
            tags = item.get("tags") or item.get("labels")
            if not tags:
                return ""
            if isinstance(tags, list):
                return ",".join(map(str, tags))
            return str(tags)

        def extract_fix(item):
            for k in ["fix", "remediation", "recommendation"]:
                if item.get(k):
                    return item[k]
            return ""

        tmp = tempfile.NamedTemporaryFile(mode="w+", suffix=".csv", delete=False, encoding="utf-8", newline="")
        tmp_path = Path(tmp.name)

        writer = csv.DictWriter(tmp, fieldnames=fieldnames)
        writer.writeheader()

        for it in items:
            if not isinstance(it, dict):
                continue
            row = {
                "severity": norm_sev(it.get("severity") or it.get("level")),
                "tool": it.get("tool") or it.get("source") or it.get("scanner") or "",
                "rule": extract_rule(it),
                "path": it.get("path") or it.get("file") or it.get("location") or "",
                "line": extract_line(it),
                "message": extract_msg(it),
                "run": extract_run(it),
                "cwe": extract_cwe(it),
                "cve": extract_cve(it),
                "component": extract_component(it),
                "tags": extract_tags(it),
                "fix": extract_fix(it),
            }
            writer.writerow(row)

        tmp.flush()
        tmp.close()

        return send_file(
            tmp_path,
            mimetype="text/csv",
            as_attachment=True,
            download_name=f"{run_dir.name}_findings_unified.csv",
        )

    return jsonify(ok=False, error=f"Unsupported fmt={fmt} (chỉ hỗ trợ json|csv trong V1)"), 400

@app.route("/api/vsp/dashboard_v3", methods=["GET"])
def vsp_dashboard_v3():
    """
    Dashboard V3:
      - Chọn run theo:
        + Pin trong vsp_dashboard_pin_v1.json, hoặc
        + FULL_EXT mới nhất có summary_unified.json
      - Trả total_findings + by_severity + by_tool
    """
    import json
    from flask import request, jsonify

    run_id = request.args.get("run_id") or pick_dashboard_run()

    if not run_id:
        return jsonify({
            "ok": False,
            "error": "No FULL_EXT run with summary_unified.json found",
            "latest_run_id": None,
        }), 500

    summary_file = (OUT_DIR / run_id / "report" / "summary_unified.json")

    if not summary_file.is_file():
        return jsonify({
            "ok": False,
            "error": f"summary_unified.json not found for {run_id}",
            "latest_run_id": run_id,
        }), 500

    summary = json.loads(summary_file.read_text(encoding="utf-8"))

    data = {
        "ok": True,
        "latest_run_id": run_id,
        "total_findings": sum(
            s.get("count", 0) for s in summary.get("summary_by_severity", {}).values()
        ),
        "by_severity": summary["summary_by_severity"],
        "by_tool": summary.get("by_tool", {}),
    }
    return jsonify(data)




# ==== VSP_METRICS_AFTER_REQUEST_V1 ====
# Inject KPI cho /api/vsp/dashboard_v3 và /api/vsp/runs_index_v3
# Không phá code cũ – chỉ chỉnh JSON response sau khi route xử lý xong.

from flask import request
import json as _vsp_json
import pathlib as _vsp_pathlib

SEVERITY_BUCKETS = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "TRACE"]

_VSP_ROOT = _vsp_pathlib.Path(__file__).resolve().parents[1]


def _vsp_build_severity_cards(by_sev):
    """Chuẩn hoá by_severity thành đầy đủ 6 bucket."""
    cards = {sev: 0 for sev in SEVERITY_BUCKETS}
    if not isinstance(by_sev, dict):
        return cards
    for sev, v in by_sev.items():
        if sev not in cards:
            continue
        if isinstance(v, dict):
            n = v.get("count") or v.get("total") or 0
        else:
            n = v
        try:
            cards[sev] = int(n)
        except Exception:
            pass
    return cards


def _vsp_security_score_simple(cards):
    """Score 0–100, càng nhiều CRIT/HIGH thì trừ điểm mạnh."""
    crit = cards.get("CRITICAL", 0)
    high = cards.get("HIGH", 0)
    med = cards.get("MEDIUM", 0)
    low = cards.get("LOW", 0)

    # model đơn giản: mỗi CRIT trừ 8, HIGH trừ 4, MED trừ 2, LOW trừ 1
    penalty = crit * 8 + high * 4 + med * 2 + low * 1
    score = 100 - penalty
    if score < 0:
        score = 0
    if score > 100:
        score = 100
    return int(score)


@app.after_request
def vsp_metrics_after_request_v1(resp):
    """Bơm thêm KPI vào dashboard_v3 & runs_index_v3."""
    try:
        path = request.path
    except Exception:
        return resp

    # Chỉ xử lý JSON của namespace /api/vsp/
    if not getattr(resp, "is_json", False):
        return resp
    if not (isinstance(path, str) and path.startswith("/api/vsp/")):
        return resp

    try:
        data = resp.get_json(silent=True)
    except Exception:
        return resp

    changed = False

    # ===== 1) DASHBOARD V3 KPI =====
    if path == "/api/vsp/dashboard_v3" and isinstance(data, dict):
        by_sev = data.get("by_severity") or {}
        cards = _vsp_build_severity_cards(by_sev)

        if not data.get("severity_cards"):
            data["severity_cards"] = cards
            changed = True

        if "security_posture_score" not in data or data.get("security_posture_score") is None:
            data["security_posture_score"] = _vsp_security_score_simple(cards)
            changed = True

        # Alias cho field top_* nếu backend chỉ có top_cwe, top_module
        if "top_risky_tool" not in data:
            data["top_risky_tool"] = data.get("top_risky_tool") or data.get("top_tool")
        if "top_impacted_cwe" not in data:
            data["top_impacted_cwe"] = data.get("top_impacted_cwe") or data.get("top_cwe")
        if "top_vulnerable_module" not in data:
            data["top_vulnerable_module"] = data.get("top_vulnerable_module") or data.get("top_module")
        changed = True

    # ===== 2) RUNS_INDEX V3 KPI (dùng summary_by_run.json) =====
    if path == "/api/vsp/runs_index_v3" and isinstance(data, dict):
        summary_path = _VSP_ROOT / "out" / "summary_by_run.json"
        s = {}
        try:
            if summary_path.is_file():
                s = _vsp_json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[VSP_METRICS] Lỗi đọc {summary_path}: {e}")

        kpi = s.get("kpi")
        trend = s.get("trend_crit_high")

        if "kpi" not in data and kpi is not None:
            data["kpi"] = kpi
            changed = True
        if "trend_crit_high" not in data and trend is not None:
            data["trend_crit_high"] = trend
            changed = True

    if not changed:
        return resp

    # Ghi lại body JSON mới
    try:
        new_body = _vsp_json.dumps(data, ensure_ascii=False)
        resp.set_data(new_body)
        resp.mimetype = "application/json"
        resp.headers["Content-Type"] = "application/json; charset=utf-8"
        resp.headers["Content-Length"] = str(len(new_body.encode("utf-8")))
    except Exception as e:
        print(f"[VSP_METRICS] Lỗi set_data: {e}")
    return resp

# ==== END VSP_METRICS_AFTER_REQUEST_V1 ====



# ========== VSP_METRICS_TOP_V1 START ==========
import json
import logging
from collections import Counter
from pathlib import Path
from flask import request

logger = logging.getLogger(__name__)

_VSP_RISKY_SEVERITIES_TOP = {"CRITICAL", "HIGH"}

def _vsp_root_dir_from_ui_top():
    try:
        return Path(__file__).resolve().parent.parent
    except Exception:
        return Path(".")

def _vsp_find_report_dir_top(latest_run_id):
    try:
        root = _vsp_root_dir_from_ui_top()
        report_dir = root / "out" / latest_run_id / "report"
        if report_dir.is_dir():
            return report_dir
    except Exception as exc:
        logger.warning("[VSP_METRICS_TOP] Cannot resolve report dir for %s: %s", latest_run_id, exc)
    return None

def _vsp_load_findings_top(report_dir):
    f = report_dir / "findings_unified.json"
    if not f.exists():
        logger.info("[VSP_METRICS_TOP] %s không tồn tại – bỏ qua top_*", f)
        return []

    try:
        data = json.loads(f.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("[VSP_METRICS_TOP] Lỗi đọc %s: %s", f, exc)
        return []

    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        if isinstance(data.get("findings"), list):
            return data["findings"]
        if isinstance(data.get("items"), list):
            return data["items"]
    return []

def _vsp_extract_cwe_top(f):
    # 1) Field trực tiếp
    for key in ("cwe_id", "cwe", "cwe_code", "cweid"):
        val = f.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
        if isinstance(val, list) and val:
            first = val[0]
            if isinstance(first, str) and first.strip():
                return first.strip()
            if isinstance(first, dict):
                for kk in ("id", "code", "name"):
                    v2 = first.get(kk)
                    if isinstance(v2, str) and v2.strip():
                        return v2.strip()

    # 2) Danh sách cwes / cwe_ids
    for key in ("cwes", "cwe_ids"):
        val = f.get(key)
        if isinstance(val, list) and val:
            first = val[0]
            if isinstance(first, str) and first.strip():
                return first.strip()
            if isinstance(first, dict):
                for kk in ("id", "code", "name"):
                    v2 = first.get(kk)
                    if isinstance(v2, str) and v2.strip():
                        return v2.strip()

    # 3) Bên trong extra / metadata
    for key in ("extra", "metadata", "details"):
        sub = f.get(key)
        if isinstance(sub, dict):
            for kk in ("cwe_id", "cwe", "cwe_code", "cweid"):
                val = sub.get(kk)
                if isinstance(val, str) and val.strip():
                    return val.strip()
                if isinstance(val, list) and val:
                    first = val[0]
                    if isinstance(first, str) and first.strip():
                        return first.strip()
                    if isinstance(first, dict):
                        for k2 in ("id", "code", "name"):
                            v2 = first.get(k2)
                            if isinstance(v2, str) and v2.strip():
                                return v2.strip()

    # 4) Tìm trong tags/labels có "CWE-"
    for key in ("tags", "labels", "categories"):
        val = f.get(key)
        if isinstance(val, list):
            for item in val:
                if isinstance(item, str) and "CWE-" in item.upper():
                    return item.strip()

    return None

def _vsp_extract_module_top(f):
    # 1) Các key phổ biến cho module/dependency
    for key in (
        "dependency",
        "package",
        "package_name",
        "module",
        "component",
        "image",
        "image_name",
        "target",
        "resource",
        "resource_name",
        "artifact",
    ):
        val = f.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()

    # 2) Một số tool gói trong extra/metadata
    for key in ("extra", "metadata", "details"):
        sub = f.get(key)
        if isinstance(sub, dict):
            for kk in (
                "dependency",
                "package",
                "package_name",
                "module",
                "component",
                "image",
                "image_name",
                "target",
                "resource",
                "resource_name",
                "artifact",
            ):
                val = sub.get(kk)
                if isinstance(val, str) and val.strip():
                    return val.strip()

    # 3) Fallback: dùng đường dẫn file như "module"
    for key in ("file", "filepath", "path", "location"):
        val = f.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()

    return None

def _vsp_accumulate_top_metrics(findings, risky_only):
    by_tool = Counter()
    by_cwe = Counter()
    by_module = Counter()

    for item in findings:
        if not isinstance(item, dict):
            continue
        sev = str(item.get("severity", "")).upper()
        if risky_only and sev not in _VSP_RISKY_SEVERITIES_TOP:
            continue

        # Tool / engine
        tool = (
            item.get("tool")
            or item.get("source")
            or item.get("scanner")
            or item.get("engine")
            or item.get("engine_id")
            or item.get("provider")
        )
        if isinstance(tool, str) and tool.strip():
            by_tool[tool.strip()] += 1

        cwe = _vsp_extract_cwe_top(item)
        if cwe:
            by_cwe[cwe] += 1

        module = _vsp_extract_module_top(item)
        if module:
            by_module[module] += 1

    return by_tool, by_cwe, by_module

def _vsp_compute_top_metrics_top(latest_run_id):
    report_dir = _vsp_find_report_dir_top(latest_run_id)
    if not report_dir:
        return {}

    findings = _vsp_load_findings_top(report_dir)
    if not findings:
        return {}

    # Pass 1: chỉ CRITICAL/HIGH
    by_tool, by_cwe, by_module = _vsp_accumulate_top_metrics(findings, risky_only=True)

    # Nếu CWE/module không có thì fallback dùng tất cả severity
    if not by_cwe or not by_module:
        by_tool_all, by_cwe_all, by_module_all = _vsp_accumulate_top_metrics(findings, risky_only=False)
        if not by_tool and by_tool_all:
            by_tool = by_tool_all
        if not by_cwe and by_cwe_all:
            by_cwe = by_cwe_all
        if not by_module and by_module_all:
            by_module = by_module_all

    result = {}

    if by_tool:
        tool, n = by_tool.most_common(1)[0]
        result["top_risky_tool"] = {
            "id": tool,
            "label": tool,
            "crit_high": int(n),
        }

    if by_cwe:
        cwe, n = by_cwe.most_common(1)[0]
        result["top_impacted_cwe"] = {
            "id": cwe,
            "label": cwe,
            "count": int(n),
        }

    if by_module:
        module, n = by_module.most_common(1)[0]
        result["top_vulnerable_module"] = {
            "id": module,
            "label": module,
            "count": int(n),
        }

    return result

@app.after_request
def vsp_metrics_after_request_top_v1(response):
    # Hậu xử lý riêng cho Dashboard V3 để bơm top_* nếu thiếu.
    try:
        path = request.path
    except RuntimeError:
        return response

    if path != "/api/vsp/dashboard_v3":
        return response

    mimetype = response.mimetype or ""
    if not mimetype.startswith("application/json"):
        return response

    try:
        data = json.loads(response.get_data(as_text=True) or "{}")
    except Exception:
        logger.warning("[VSP_METRICS_TOP] Không parse được JSON từ %s", path)
        return response

    latest_run_id = data.get("latest_run_id")
    if not isinstance(latest_run_id, str) or not latest_run_id:
        return response

    top = _vsp_compute_top_metrics_top(latest_run_id)
    if not top:
        return response

    for key in ("top_risky_tool", "top_impacted_cwe", "top_vulnerable_module"):
        if key in top and not data.get(key):
            data[key] = top[key]

    new_body = json.dumps(data, ensure_ascii=False).encode("utf-8")
    response.set_data(new_body)
    response.headers["Content-Length"] = str(len(new_body))
    return response

# ========== VSP_METRICS_TOP_V1 END ==========
# == VSP_TABS_ROUTER_INJECT_ANY_V1 ==
@app.after_request
def vsp_tabs_router_inject_any(response):
    """Inject router JS vào TẤT CẢ response text/html.
    Không phụ thuộc id vsp-dashboard-main nữa.
    """
    try:
        ctype = response.headers.get("Content-Type", "")
        if "text/html" not in ctype.lower():
            return response

        body = response.get_data(as_text=True)

        # Nếu đã có script rồi thì thôi
        if "vsp_tabs_hash_router_v1.js" in body:
            return response

        if "</body>" not in body:
            return response

        body = body.replace(
            "</body>",
            '  <script src="/static/js/vsp_tabs_hash_router_v1.js" defer></script>\n</body>'
        )
        response.set_data(body)
    except Exception as e:
        print("[VSP_TABS_ROUTER_INJECT_ANY][ERR]", e)
    return response



if __name__ == '__main__':
    # VSP UI Gateway – default port 8910, có thể override bằng biến môi trường VSP_UI_PORT
    port = int(os.environ.get('VSP_UI_PORT', '8910'))
    # debug=False cho gần với bản thương mại; muốn xem log chi tiết thì đổi thành True
    app.run(host='0.0.0.0', port=port, debug=False)
